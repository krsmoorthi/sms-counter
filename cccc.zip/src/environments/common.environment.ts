const PROPERTIES_SERVICE_TIMEOUT = 90000;
const PROFILE_SERVICE_TIMEOUT = 90000;
const AUTO_LOGIN_TIMEOUT = 90000;
const INIT_ADDRESS_TIMEOUT = 90000;
const SUBMIT_TASK_TIMEOUT = 90000;
const LINK_TASK_TIMEOUT = 90000;
const BILL_QUOTE_TIMEOUT = 90000;
const SUBMIT_TASK_SUP1_TIMEOUT = 90000;
const SUBMIT_TASK_SUP2_TIMEOUT = 90000;
const INIT_TASK_SUP1_TIMEOUT = 90000;
const INIT_TASK_SUP2_TIMEOUT = 90000;
const PENDING_SUMMARY_TASK_TIMEOUT = 90000;
const E911_TASK_TIMEOUT = 90000;
const HOLD_ORDER_TIMEOUT = 90000;
const MOVE_SERVICE_TIMEOUT = 90000;
const DISCONNECT_SERVICE_TIMEOUT = 90000;
const CHANGE_SERVICE_TIMEOUT = 90000;
const AVAILABLE_NUMBER_TIMEOUT = 90000;
const AVAILABLE_TN_TIMEOUT = 90000;
const RESERVE_TN_TIMEOUT = 90000;
const RELEASE_TN_TIMEOUT = 90000;
const URL_NPA_NXX_TIMEOUT = 90000;
const ORDER_PROCESS_TIMEOUT = 90000;
const PRODUCT_CONFIG_URL_TIMEOUT = 90000;
const PRODUCT_COMPATIBILITY_TIMEOUT = 90000;
const BILLING_RECORDS_TIMEOUT = 90000;
const GIFTCARD_COMPATIBILITY_TIMEOUT = 90000;
const PENDING_ORDER_REMARK_UPDATE_INIT_TIMEOUT = 90000;
const PARTY_ROLE_ID = 'CSR456';
const PARTY_ROLE_NAME = 'CSR';
const COR_SERVICE_TIMEOUT = 90000;
const TPV_ENGLISH_NUMBER = '(602)-682-3859';
const TPV_SPANISH_NUMBER = '(602)-682-3860';
const SERVICECALL = '/apigeeCall';
const INTRANET = '.intranet';
const CSR_NAME = 'CSRID';
const CSR_PROFILE = 'CSR_PROFILE';
const ENSEMBLEID = 'ENSEMBLEID';
const ENS_OPERATOR = 'ENS_OPERATOR';
const retryIteration = 0;

export const commonConst = {
    
    cms: {
        addressval: {
          welcome_text: "Let's see what's next for your home",
          button_text: "Go"
        }
    },

    SERVICECALL: SERVICECALL,
    INTRANET: INTRANET,

    PARTY_ROLE_ID: PARTY_ROLE_ID,
    PARTY_ROLE_NAME :PARTY_ROLE_NAME,

    CSR_NAME: CSR_NAME,
    CSR_PROFILE: CSR_PROFILE,
    ENSEMBLEID: ENSEMBLEID,
    ENS_OPERATOR: ENS_OPERATOR,

    retryIteration: retryIteration,

    TPV_ENGLISH_NUMBER: TPV_ENGLISH_NUMBER,
    TPV_SPANISH_NUMBER: TPV_SPANISH_NUMBER,

    MASK_KEYS: "ssn,socialSecurityNr,dateOfBirth",

    PROPERTIES_SERVICE_TIMEOUT: PROPERTIES_SERVICE_TIMEOUT,
    PROFILE_SERVICE_TIMEOUT: PROFILE_SERVICE_TIMEOUT,
    AUTO_LOGIN_TIMEOUT: AUTO_LOGIN_TIMEOUT,
    INIT_ADDRESS_TIMEOUT: INIT_ADDRESS_TIMEOUT,
    SUBMIT_TASK_TIMEOUT: SUBMIT_TASK_TIMEOUT,
    LINK_TASK_TIMEOUT: LINK_TASK_TIMEOUT,
    BILL_QUOTE_TIMEOUT: BILL_QUOTE_TIMEOUT,
    SUBMIT_TASK_SUP1_TIMEOUT: SUBMIT_TASK_SUP1_TIMEOUT,
    SUBMIT_TASK_SUP2_TIMEOUT: SUBMIT_TASK_SUP2_TIMEOUT,
    INIT_TASK_SUP1_TIMEOUT: INIT_TASK_SUP1_TIMEOUT,
    INIT_TASK_SUP2_TIMEOUT: INIT_TASK_SUP2_TIMEOUT,
    PENDING_ORDER_REMARK_UPDATE_INIT_TIMEOUT:PENDING_ORDER_REMARK_UPDATE_INIT_TIMEOUT,
    PENDING_SUMMARY_TASK_TIMEOUT: PENDING_SUMMARY_TASK_TIMEOUT,
    E911_TASK_TIMEOUT: E911_TASK_TIMEOUT,
    HOLD_ORDER_TIMEOUT: HOLD_ORDER_TIMEOUT,
    MOVE_SERVICE_TIMEOUT: MOVE_SERVICE_TIMEOUT,
    DISCONNECT_SERVICE_TIMEOUT: DISCONNECT_SERVICE_TIMEOUT,
    CHANGE_SERVICE_TIMEOUT: CHANGE_SERVICE_TIMEOUT,
    AVAILABLE_NUMBER_TIMEOUT: AVAILABLE_NUMBER_TIMEOUT,
    AVAILABLE_TN_TIMEOUT: AVAILABLE_TN_TIMEOUT,
    RESERVE_TN_TIMEOUT: RESERVE_TN_TIMEOUT,
    RELEASE_TN_TIMEOUT: RELEASE_TN_TIMEOUT,
    URL_NPA_NXX_TIMEOUT: URL_NPA_NXX_TIMEOUT,
    ORDER_PROCESS_TIMEOUT: ORDER_PROCESS_TIMEOUT,
    PRODUCT_CONFIG_URL_TIMEOUT: PRODUCT_CONFIG_URL_TIMEOUT,
    PRODUCT_COMPATIBILITY_TIMEOUT: PRODUCT_COMPATIBILITY_TIMEOUT,
    BILLING_RECORDS_TIMEOUT: BILLING_RECORDS_TIMEOUT,
    GIFTCARD_COMPATIBILITY_TIMEOUT: GIFTCARD_COMPATIBILITY_TIMEOUT,
    COR_SERVICE_TIMEOUT: COR_SERVICE_TIMEOUT,

    AUTO_LOGIN: "/Partner/v1/SFDCConsumer/services/apexrest/EShopLaunchService?launchToken=",
    PROFILE_SERVICE : '/Application/v1/BMP/userProfile/bsi/ManageUserProfile/v1/getProfileRestrictions',
    PROPERTIES_SERVICE: '/Application/v1/BMP/orderProcess/v1/orderprocess/order/properties',
    BASE_CHANGE_URL_INIT: '/Application/v1/BMP/orderProcessChange/v1/orderprocess/order/init',
    BASE_CHANGE_URL_SUBMIT_TASK: '/Application/v1/BMP/orderProcessChange/v1/orderprocess/order/submitTask',
    BASE_URL_AVAILABLE_NUMBER: '/Application/v1/BMP/tnManagement/bsi/TnManagement/Available/Number',
    BASE_URL_AVAILABLE_TN: '/Application/v1/BMP/tnManagement/bsi/TnManagement/Available/List',
    BASE_URL_RESERVE_TN: '/Application/v1/BMP/tnManagement/bsi/TnManagement/Reserve/',
    BASE_URL_RELEASE_TN: '/Application/v1/BMP/tnManagement/bsi/TnManagement/Release/',
    BASE_URL_E911: '/Application/v1/BMP/address/bsi/AddressBusinessService/v1/address/submitE911Address',
    BASE_URL_INIT: '/Application/v1/BMP/orderProcess/v1/orderprocess/order/init',
    BASE_URL_SUBMIT_TASK: '/Application/v1/BMP/orderProcess/v1/orderprocess/order/submitTask',
    BASE_URL_NPA_NXX: '/Application/v1/BMP/tnManagement/bsi/TnManagement/npaNxxList/',
    BILL_QUOTE: '/Application/v2/EDS/liveQuote/v1/livequote/',
    DISCONNECT_INIT: '/Application/v1/BMP/orderProcessDisconnect/v1/orderprocess/order/init',
    DISCONNECT_SUBMIT: '/Application/v1/BMP/orderProcessDisconnect/v1/orderprocess/order/submitTask',
    GEOES_URL: '/Customer/v2/Location/',
    GET_ORDER_PROCESS_STATUS: '/Application/v1/BMP/orderManagement/customerOrder/getOrderProgressStatus',
    MOVE_INIT_URL: '/Application/v1/BMP/orderProcessMove/v1/orderprocess/order/init',
    MOVE_SUBMIT: '/Application/v1/BMP/orderProcessMove/v1/orderprocess/order/submitTask',
    PAYMENT_INFO: '/Application/v1/BMP/payment/bsi/PaymentBusinessService/v1/payment/findPaymentStatusById?objectId=',
    PENDING_SUMMARY: '/Application/v1/BMP/orderManagement/customerOrder/retrieveProductsAndServices',
    PRODUCT_CONFIG_URL: '/Application/v1/BMP/productConfiguration/bsi/ServiceProductConfiguration/saveConfigInfo',
    REMOVE_CHANGE: '/Application/v1/BMP/orderManagement/customerOrder/getReasonCode',
    NONPAY_SUSPEND_INIT: '/Application/v1/BMP/orderProcessNonpaySusres/orderprocess/suspendorder/init',
    NONPAY_SUSPEND_SUBMIT: '/Application/v1/BMP/orderProcessNonpaySusres/orderprocess/suspendorder/submitTask',
    SUP1_INIT: '/Application/v1/BMP/orderProcessSup1/v1/orderprocess/order/init',
    SUP1_SUBMIT: '/Application/v1/BMP/orderProcessSup1/v1/orderprocess/order/submitTask',
    SUP2_INIT: '/Application/v1/BMP/orderProcessSup2/v1/orderprocess/order/init',
    SUP2_SUBMIT: '/Application/v1/BMP/orderProcessSup2/v1/orderprocess/order/submitTask',
    SPLUNK_URL: '/services/collector/event',
    HOLD_REASONS: '/Application/v1/BMP/orderManagement/customerOrder/getReasonCode',
    HOLD_ORDER: '/Application/v1/BMP/orderProcess/v1/orderprocess/order/submitTask',
    BASE_URL_TN_PORTING: '/Application/v1/BMP/numberPorting/bsi/NumberPorting/v2/tnPortabilityCheck/',
    PRODUCT_COMPATIBILITY: '/Application/v1/BMP/rule/bsi/RuleService/v1/fetchRules',
    BILLING_RECORDS_INIT: '/Application/v1/BMP/orderProcessBrc/v1/orderprocess/order/init',
    BILLING_RECORDS_SUBMIT: '/Application/v1/BMP/orderProcessBrc/v1/orderprocess/order/submitTask',
    UNHOLD_CHANGE: '/Application/v1/BMP/orderProcessChange/v1/orderprocess/order/submitTask',
    UNHOLD_MOVE: '/Application/v1/BMP/orderProcessMove/v1/orderprocess/order/submitTask',
    DATA_LINK: '/Application/v1/BMP/offerSummary/bsi/offerdatalink/v1/baseURL/',
    OVERRIDE_APPT: '/Application/v1/BMP/appointmentScheduling/appointment/retrieveadditionalslots',
    UNHOLD_DISCONNECT: '/Application/v1/BMP/orderProcessDisconnect/v1/orderprocess/order/submitTask',
    RETRIEVE_DEPOSIT_HISTORY: '/Application/v1/BMP/depositCalculation/bsi/DepositBusinessService/v1/retrieveDepositHistory?ban=',
    RETRIEVE_ARN: '/Application/v1/BMP/orderProcess/v1/orderprocess/order/reserve',
    UNHOLD_BILLANDREC: '/Application/v1/BMP/orderProcessBrc/v1/orderprocess/order/submitTask',
    CLOSERS_PROMOSE_COMPATIBILITY: '/Application/v1/BMP/catalog/bsi/discount/discountCompatibility',
    GET_HOLIDAYS_LIST: '/Application/v1/BMP/dueDate/bsi/v2/getExceptionDaysV2',
    EXISTING_DISCOUNTS: '/Application/v1/BMP/orderManagement/discount/getDiscountsByBan/',
    DTV_INIT: '/Application/v1/BMP/orderProcess/v1/orderDTVprocess/order/DTVinit',
    CAPTURE_DTV_REQUEST: '/Application/v1/BMP/orderProcess/v1/orderDTVprocess/order/submitTask',
    ORDER_DTV_PROCESS: '/Application/v1/BMP/orderProcess/v1/orderDTVprocess/order/submitTask',
    RETRIEVE_DTV_ORDER: '/Application/v1/BMP/direcTvOm/dtvMgmt/retrieveDtvOrder',
    GIFTCARD_COMPATIBILITY: '/Application/v1/BMP/giftCard/bsi/giftcardCompatibility',
    BASE_VACATION_URL_INIT: '/Application/v1/BMP/orderProcessVacsus/orderprocess/suspendorder/init',
    VAC_SUSPEND_SCHEDULING_SUBMIT_TASK:  '/Application/v1/BMP/orderProcessVacsus/orderprocess/suspendorder/submitTask',
    BASE_VACATION_URL_SUBMIT_TASK: '/Application/v1/BMP/orderProcessVacsus/orderprocess/suspendorder/submitTask',
    RETRIEVE_RCC_URL: '/Application/v1/BMP/rcc/bsi/v1/retrieveRcc',
    SWITCH_COMPATIBILITY: '/Application/v1/BMP/tnManagement/bsi/TnManagement/vi/productCompatibilityByTN',
    GET_TECHNOLOGY_TYPES: '/Application/v1/BMP/serviceAvailability/bsi/getTechnologyTypes',
    GET_RCC_DISCLOSURE_URL: '/Application/v1/BMP/rcc/bsi/v1/getRccDisclosure',
    RETRIEVE_DEALER_CODE: '/Application/v1/BMP/orderCheckout/bsi/retrieveProductDealerCodeInfo',
    VALIDATE_DEALER_CODE: '/Application/v1/BMP/accountManagement/accountMgmt/dealer',
    CHECK_POTS_TN_AVAILABILITY: '/Application/v1/BMP/tnManagement/bsi/TnManagement/checkPotsTnAvailability',
    RETRIEVE_GIFTCARDS: '/Application/v1/BMP/giftCard/bsi/getGiftCardsAccordingToQualification',
    COR_INIT_URL: '/Application/v1/BMP/orderProcess/v1/orderprocessCOR/order/init',
    COR_SUBMIT_URL: '/Application/v1/BMP/orderProcess/v1/orderprocessCOR/order/submitTask',
    PREPAID_CANCEL_ORDER: '/Application/v1/BMP/prePaidService/bsi/prepaid/updatePrepaidAccountStatus',
    RETRIEVE_INTERNET_DISCOUNTS: '/Application/v1/BMP/discount/bsi/retrieveDiscounts',
    PENDING_ORDER_REMARK_UPDATE_INIT:'/Application/v1/BMP/orderProcessSup2/v1/orderProcessUpdateRemarks/order/init'
}