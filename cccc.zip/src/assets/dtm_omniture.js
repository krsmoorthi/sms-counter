// All code and conventions are protected by copyright
! function(e, t, n) {
    function a() {
        this.rules = P.filter(P.rules, function(e) {
            return "elementexists" === e.event
        })
    }

    function r(e) {
        this.delay = 250, this.FB = e, P.domReady(P.bind(function() {
            P.poll(P.bind(this.initialize, this), this.delay, 8)
        }, this))
    }

    function s() {
        var e = this.eventRegex = /^hover\(([0-9]+)\)$/,
            t = this.rules = [];
        P.each(P.rules, function(n) {
            var i = n.event.match(e);
            i && t.push([Number(n.event.match(e)[1]), n.selector])
        })
    }

    function o(t) {
        t = t || P.rules, this.rules = P.filter(t, function(e) {
            return "inview" === e.event
        }), this.elements = [], this.eventHandler = P.bind(this.track, this), P.addEventHandler(e, "scroll", this.eventHandler), P.addEventHandler(e, "load", this.eventHandler)
    }

    function c() {
        P.domReady(P.bind(function() {
            P.poll(P.bind(this.initialize, this), this.delay, 8)
        }, this))
    }

    function l() {
        this.lastURL = P.URL(), this._fireIfURIChanged = P.bind(this.fireIfURIChanged, this), this._onPopState = P.bind(this.onPopState, this), this._onHashChange = P.bind(this.onHashChange, this), this._pushState = P.bind(this.pushState, this), this._replaceState = P.bind(this.replaceState, this), this.initialize()
    }

    function u() {
        P.addEventHandler(e, "orientationchange", u.orientationChange)
    }

    function d(t) {
        P.domReady(P.bind(function() {
            this.twttr = t || e.twttr, this.initialize()
        }, this))
    }

    function f() {
        this.rules = P.filter(P.rules, function(e) {
            return "videoplayed" === e.event.substring(0, 11)
        }), this.eventHandler = P.bind(this.onUpdateTime, this)
    }

    function h() {
        this.defineEvents(), this.visibilityApiHasPriority = !0, t.addEventListener ? this.setVisibilityApiPriority(!1) : this.attachDetachOlderEventListeners(!0, t, "focusout");
        P.bindEvent("aftertoolinit", function() {
            P.fireEvent(P.visibility.isHidden() ? "tabblur" : "tabfocus")
        })
    }

    function g(e) {
        P.BaseTool.call(this, e), this.name = e.name || "Basic"
    }

    function p() {
        P.BaseTool.call(this), this.asyncScriptCallbackQueue = [], this.argsForBlockingScripts = []
    }

    function v(e) {
        P.BaseTool.call(this, e)
    }

    function m(e) {
        P.BaseTool.call(this, e)
    }

    function y(e) {
        P.BaseTool.call(this, e), this.defineListeners(), this.beaconMethod = "plainBeacon", this.adapt = new y.DataAdapters, this.dataProvider = new y.DataProvider.Aggregate
    }

    function b(e) {
        P.BaseTool.call(this, e), this.varBindings = {}, this.events = [], this.products = [], this.customSetupFuns = []
    }

    function k(e) {
        P.BaseTool.call(this, e), this.styleElements = {}, this.targetPageParamsStore = {}
    }

    function E(e) {
        P.BaseTool.call(this, e), this.name = e.name || "VisitorID", this.initialize()
    }
    var S = Object.prototype.toString,
        C = e._satellite && e._satellite.override,
        P = {
            initialized: !1,
            $data: function(e, t, i) {
                if (e) {
                    var a = "__satellite__",
                        r = P.dataCache,
                        s = e[a];
                    s || (s = e[a] = P.uuid++);
                    var o = r[s];
                    return o || (o = r[s] = {}), i === n ? o[t] : void(o[t] = i)
                }
            },
            uuid: 1,
            dataCache: {},
            keys: function(e) {
                var t = [];
                for (var n in e) e.hasOwnProperty(n) && t.push(n);
                return t
            },
            values: function(e) {
                var t = [];
                for (var n in e) e.hasOwnProperty(n) && t.push(e[n]);
                return t
            },
            isArray: Array.isArray || function(e) {
                return "[object Array]" === S.apply(e)
            },
            isObject: function(e) {
                return null != e && !P.isArray(e) && "object" == typeof e
            },
            isString: function(e) {
                return "string" == typeof e
            },
            isNumber: function(e) {
                return "[object Number]" === S.apply(e) && !P.isNaN(e)
            },
            isNaN: function(e) {
                return e !== e
            },
            isRegex: function(e) {
                return e instanceof RegExp
            },
            isLinkTag: function(e) {
                return !(!e || !e.nodeName || "a" !== e.nodeName.toLowerCase())
            },
            each: function(e, t, n) {
                for (var i = 0, a = e.length; a > i; i++) t.call(n, e[i], i, e)
            },
            map: function(e, t, n) {
                for (var i = [], a = 0, r = e.length; r > a; a++) i.push(t.call(n, e[a], a, e));
                return i
            },
            filter: function(e, t, n) {
                for (var i = [], a = 0, r = e.length; r > a; a++) {
                    var s = e[a];
                    t.call(n, s, a, e) && i.push(s)
                }
                return i
            },
            any: function(e, t, n) {
                for (var i = 0, a = e.length; a > i; i++) {
                    var r = e[i];
                    if (t.call(n, r, i, e)) return !0
                }
                return !1
            },
            every: function(e, t, n) {
                for (var i = !0, a = 0, r = e.length; r > a; a++) {
                    var s = e[a];
                    i = i && t.call(n, s, a, e)
                }
                return i
            },
            contains: function(e, t) {
                return -1 !== P.indexOf(e, t)
            },
            indexOf: function(e, t) {
                if (e.indexOf) return e.indexOf(t);
                for (var n = e.length; n--;)
                    if (t === e[n]) return n;
                return -1
            },
            find: function(e, t, n) {
                if (!e) return null;
                for (var i = 0, a = e.length; a > i; i++) {
                    var r = e[i];
                    if (t.call(n, r, i, e)) return r
                }
                return null
            },
            textMatch: function(e, t) {
                if (null == t) throw new Error("Illegal Argument: Pattern is not present");
                return null == e ? !1 : "string" == typeof t ? e === t : t instanceof RegExp ? t.test(e) : !1
            },
            stringify: function(e, t) {
                if (t = t || [], P.isObject(e)) {
                    if (P.contains(t, e)) return "<Cycle>";
                    t.push(e)
                }
                if (P.isArray(e)) return "[" + P.map(e, function(e) {
                    return P.stringify(e, t)
                }).join(",") + "]";
                if (P.isString(e)) return '"' + String(e) + '"';
                if (P.isObject(e)) {
                    var n = [];
                    for (var i in e) e.hasOwnProperty(i) && n.push(i + ": " + P.stringify(e[i], t));
                    return "{" + n.join(", ") + "}"
                }
                return String(e)
            },
            trim: function(e) {
                return null == e ? null : e.trim ? e.trim() : e.replace(/^ */, "").replace(/ *$/, "")
            },
            bind: function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            },
            throttle: function(e, t) {
                var n = null;
                return function() {
                    var i = this,
                        a = arguments;
                    clearTimeout(n), n = setTimeout(function() {
                        e.apply(i, a)
                    }, t)
                }
            },
            domReady: function(e) {
                function n(e) {
                    for (f = 1; e = a.shift();) e()
                }
                var i, a = [],
                    r = !1,
                    s = t,
                    o = s.documentElement,
                    c = o.doScroll,
                    l = "DOMContentLoaded",
                    u = "addEventListener",
                    d = "onreadystatechange",
                    f = /^loade|^c/.test(s.readyState);
                return s[u] && s[u](l, i = function() {
                    s.removeEventListener(l, i, r), n()
                }, r), c && s.attachEvent(d, i = function() {
                    /^c/.test(s.readyState) && (s.detachEvent(d, i), n())
                }), e = c ? function(t) {
                    self != top ? f ? t() : a.push(t) : function() {
                        try {
                            o.doScroll("left")
                        } catch (n) {
                            return setTimeout(function() {
                                e(t)
                            }, 50)
                        }
                        t()
                    }()
                } : function(e) {
                    f ? e() : a.push(e)
                }
            }(),
            loadScript: function(e, n) {
                var i = t.createElement("script");
                P.scriptOnLoad(e, i, n), i.src = e, t.getElementsByTagName("head")[0].appendChild(i)
            },
            scriptOnLoad: function(e, t, n) {
                function i(e) {
                    e && P.logError(e), n && n(e)
                }
                "onload" in t ? (t.onload = function() {
                    i()
                }, t.onerror = function() {
                    i(new Error("Failed to load script " + e))
                }) : "readyState" in t && (t.onreadystatechange = function() {
                    var e = t.readyState;
                    ("loaded" === e || "complete" === e) && (t.onreadystatechange = null, i())
                })
            },
            loadScriptOnce: function(e, t) {
                P.loadedScriptRegistry[e] || P.loadScript(e, function(n) {
                    n || (P.loadedScriptRegistry[e] = !0), t && t(n)
                })
            },
            loadedScriptRegistry: {},
            loadScriptSync: function(e) {
                return t.write ? P.domReadyFired ? void P.notify('Cannot load sync the "' + e + '" script after DOM Ready.', 1) : (e.indexOf('"') > -1 && (e = encodeURI(e)), void t.write('<script src="' + e + '"></script>')) : void P.notify('Cannot load sync the "' + e + '" script because "document.write" is not available', 1)
            },
            pushAsyncScript: function(e) {
                P.tools["default"].pushAsyncScript(e)
            },
            pushBlockingScript: function(e) {
                P.tools["default"].pushBlockingScript(e)
            },
            addEventHandler: e.addEventListener ? function(e, t, n) {
                e.addEventListener(t, n, !1)
            } : function(e, t, n) {
                e.attachEvent("on" + t, n)
            },
            removeEventHandler: e.removeEventListener ? function(e, t, n) {
                e.removeEventListener(t, n, !1)
            } : function(e, t, n) {
                e.detachEvent("on" + t, n)
            },
            preventDefault: e.addEventListener ? function(e) {
                e.preventDefault()
            } : function(e) {
                e.returnValue = !1
            },
            stopPropagation: function(e) {
                e.cancelBubble = !0, e.stopPropagation && e.stopPropagation()
            },
            containsElement: function(e, t) {
                return e.contains ? e.contains(t) : !!(16 & e.compareDocumentPosition(t))
            },
            matchesCss: function(n) {
                function i(e, t) {
                    var n = t.tagName;
                    return n ? e.toLowerCase() === n.toLowerCase() : !1
                }
                var a = n.matchesSelector || n.mozMatchesSelector || n.webkitMatchesSelector || n.oMatchesSelector || n.msMatchesSelector;
                return a ? function(n, i) {
                    if (i === t || i === e) return !1;
                    try {
                        return a.call(i, n)
                    } catch (r) {
                        return !1
                    }
                } : n.querySelectorAll ? function(e, t) {
                    var n = t.parentNode;
                    if (!n) return !1;
                    if (e.match(/^[a-z]+$/i)) return i(e, t);
                    try {
                        for (var a = t.parentNode.querySelectorAll(e), r = a.length; r--;)
                            if (a[r] === t) return !0
                    } catch (s) {}
                    return !1
                } : function(e, t) {
                    if (e.match(/^[a-z]+$/i)) return i(e, t);
                    try {
                        return P.Sizzle.matches(e, [t]).length > 0
                    } catch (n) {
                        return !1
                    }
                }
            }(t.documentElement),
            cssQuery: function(e) {
                return e.querySelectorAll ? function(t, n) {
                    var i;
                    try {
                        i = e.querySelectorAll(t)
                    } catch (a) {
                        i = []
                    }
                    n(i)
                } : function(e, t) {
                    if (P.Sizzle) {
                        var n;
                        try {
                            n = P.Sizzle(e)
                        } catch (i) {
                            n = []
                        }
                        t(n)
                    } else P.sizzleQueue.push([e, t])
                }
            }(t),
            hasAttr: function(e, t) {
                return e.hasAttribute ? e.hasAttribute(t) : e[t] !== n
            },
            inherit: function(e, t) {
                var n = function() {};
                n.prototype = t.prototype, e.prototype = new n, e.prototype.constructor = e
            },
            extend: function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            toArray: function() {
                try {
                    var e = Array.prototype.slice;
                    return e.call(t.documentElement.childNodes, 0)[0].nodeType,
                        function(t) {
                            return e.call(t, 0)
                        }
                } catch (n) {
                    return function(e) {
                        for (var t = [], n = 0, i = e.length; i > n; n++) t.push(e[n]);
                        return t
                    }
                }
            }(),
            equalsIgnoreCase: function(e, t) {
                return null == e ? null == t : null == t ? !1 : String(e).toLowerCase() === String(t).toLowerCase()
            },
            poll: function(e, t, n) {
                function i() {
                    P.isNumber(n) && a++ >= n || e() || setTimeout(i, t)
                }
                var a = 0;
                t = t || 1e3, i() //NOSONAR
            },
            escapeForHtml: function(e) {
                return e ? String(e).replace(/\&/g, "&amp;").replace(/\</g, "&lt;").replace(/\>/g, "&gt;").replace(/\"/g, "&quot;").replace(/\'/g, "&#x27;").replace(/\//g, "&#x2F;") : e
            }
        };
    P.availableTools = {}, P.availableEventEmitters = [], P.fireOnceEvents = ["condition", "elementexists"], P.initEventEmitters = function() {
        P.eventEmitters = P.map(P.availableEventEmitters, function(e) {
            return new e
        })
    }, P.eventEmitterBackgroundTasks = function() {
        P.each(P.eventEmitters, function(e) {
            "backgroundTasks" in e && e.backgroundTasks()
        })
    }, P.initTools = function(e) {
        var t = {
                "default": new p
            },
            n = P.settings.euCookieName || "sat_track";
        for (var i in e)
            if (e.hasOwnProperty(i)) {
                var a, r, s;
                if (a = e[i], a.euCookie) {
                    var o = "true" !== P.readCookie(n);
                    if (o) continue
                }
                if (r = P.availableTools[a.engine], !r) {
                    var c = [];
                    for (var l in P.availableTools) P.availableTools.hasOwnProperty(l) && c.push(l);
                    throw new Error("No tool engine named " + a.engine + ", available: " + c.join(",") + ".")
                }
                s = new r(a), s.id = i, t[i] = s
            }
        return t
    }, P.preprocessArguments = function(e, t, n, i, a) {
        function r(e) {
            return i && P.isString(e) ? e.toLowerCase() : e
        }

        function s(e) {
            var c = {};
            for (var l in e)
                if (e.hasOwnProperty(l)) {
                    var u = e[l];
                    P.isObject(u) ? c[l] = s(u) : P.isArray(u) ? c[l] = o(u, i) : c[l] = r(P.replace(u, t, n, a))
                }
            return c
        }

        function o(e, i) {
            for (var a = [], o = 0, c = e.length; c > o; o++) {
                var l = e[o];
                P.isString(l) ? l = r(P.replace(l, t, n)) : l && l.constructor === Object && (l = s(l)), a.push(l)
            }
            return a
        }
        return e ? o(e, i) : e
    }, P.execute = function(e, t, n, i) {
        function a(a) {
            var r = i[a || "default"];
            if (r) try {
                r.triggerCommand(e, t, n)
            } catch (s) {
                P.logError(s)
            }
        }
        if (!_satellite.settings.hideActivity)
            if (i = i || P.tools, e.engine) {
                var r = e.engine;
                for (var s in i)
                    if (i.hasOwnProperty(s)) {
                        var o = i[s];
                        o.settings && o.settings.engine === r && a(s)
                    }
            } else e.tool instanceof Array ? P.each(e.tool, function(e) {
                a(e)
            }) : a(e.tool)
    }, P.Logger = {
        outputEnabled: !1,
        messages: [],
        keepLimit: 100,
        flushed: !1,
        LEVELS: [null, null, "log", "info", "warn", "error"],
        message: function(e, t) {
            var n = this.LEVELS[t] || "log";
            this.messages.push([n, e]), this.messages.length > this.keepLimit && this.messages.shift(), this.outputEnabled && this.echo(n, e)
        },
        getHistory: function() {
            return this.messages
        },
        clearHistory: function() {
            this.messages = []
        },
        setOutputState: function(e) {
            this.outputEnabled != e && (this.outputEnabled = e, e ? this.flush() : this.flushed = !1)
        },
        echo: function(t, n) {
            e.console && e.console[t]("SATELLITE: " + n)
        },
        flush: function() {
            this.flushed || (P.each(this.messages, function(e) {
                e[2] !== !0 && (this.echo(e[0], e[1]), e[2] = !0)
            }, this), this.flushed = !0)
        }
    }, P.notify = P.bind(P.Logger.message, P.Logger), P.cleanText = function(e) {
        return null == e ? null : P.trim(e).replace(/\s+/g, " ")
    }, P.cleanText.legacy = function(e) {
        return null == e ? null : P.trim(e).replace(/\s{2,}/g, " ").replace(/[^\000-\177]*/g, "")
    }, P.text = function(e) {
        return e.textContent || e.innerText
    }, P.specialProperties = {
        text: P.text,
        cleanText: function(e) {
            return P.cleanText(P.text(e))
        }
    }, P.getObjectProperty = function(e, t, i) {
        for (var a, r = t.split("."), s = e, o = P.specialProperties, c = 0, l = r.length; l > c; c++) {
            if (null == s) return n;
            var u = r[c];
            if (i && "@" === u.charAt(0)) {
                var d = u.slice(1);
                s = o[d](s)
            } else if (s.getAttribute && (a = u.match(/^getAttribute\((.+)\)$/))) {
                var f = a[1];
                s = s.getAttribute(f)
            } else s = s[u]
        }
        return s
    }, P.getToolsByType = function(e) {
        if (!e) throw new Error("Tool type is missing");
        var t = [];
        for (var n in P.tools)
            if (P.tools.hasOwnProperty(n)) {
                var i = P.tools[n];
                i.settings && i.settings.engine === e && t.push(i)
            }
        return t
    }, P.setVar = function() {
        var e = P.data.customVars;
        if (null == e && (P.data.customVars = {}, e = P.data.customVars), "string" == typeof arguments[0]) {
            var t = arguments[0];
            e[t] = arguments[1]
        } else if (arguments[0]) {
            var n = arguments[0];
            for (var i in n) n.hasOwnProperty(i) && (e[i] = n[i])
        }
    }, P.dataElementSafe = function(e, t) {
        if (arguments.length > 2) {
            var n = arguments[2];
            "pageview" === t ? P.dataElementSafe.pageviewCache[e] = n : "session" === t ? P.setCookie("_sdsat_" + e, n) : "visitor" === t && P.setCookie("_sdsat_" + e, n, 730)
        } else {
            if ("pageview" === t) return P.dataElementSafe.pageviewCache[e];
            if ("session" === t || "visitor" === t) return P.readCookie("_sdsat_" + e)
        }
    }, P.dataElementSafe.pageviewCache = {}, P.realGetDataElement = function(t) {
        var n;
        return t.selector ? P.hasSelector && P.cssQuery(t.selector, function(e) {
            if (e.length > 0) {
                var i = e[0];
                "text" === t.property ? n = i.innerText || i.textContent : t.property in i ? n = i[t.property] : P.hasAttr(i, t.property) && (n = i.getAttribute(t.property))
            }
        }) : t.queryParam ? n = t.ignoreCase ? P.getQueryParamCaseInsensitive(t.queryParam) : P.getQueryParam(t.queryParam) : t.cookie ? n = P.readCookie(t.cookie) : t.jsVariable ? n = P.getObjectProperty(e, t.jsVariable) : t.customJS && (n = t.customJS()), P.isString(n) && t.cleanText && (n = P.cleanText(n)), n
    }, P.getDataElement = function(e, t, i) {
        if (i = i || P.dataElements[e], null == i) return P.settings.undefinedVarsReturnEmpty ? "" : null;
        var a = P.realGetDataElement(i);
        return a === n && i.storeLength ? a = P.dataElementSafe(e, i.storeLength) : a !== n && i.storeLength && P.dataElementSafe(e, i.storeLength, a), a || t || (a = i["default"] || ""), P.isString(a) && i.forceLowerCase && (a = a.toLowerCase()), a
    }, P.getVar = function(i, a, r) {
        var s, o, c = P.data.customVars,
            l = r ? r.target || r.srcElement : null,
            u = {
                uri: P.URI(),
                protocol: t.location.protocol,
                hostname: t.location.hostname
            };
        if (P.dataElements && i in P.dataElements) return P.getDataElement(i);
        if (o = u[i.toLowerCase()], o === n)
            if ("this." === i.substring(0, 5)) i = i.slice(5), o = P.getObjectProperty(a, i, !0);
            else if ("event." === i.substring(0, 6)) i = i.slice(6), o = P.getObjectProperty(r, i);
        else if ("target." === i.substring(0, 7)) i = i.slice(7), o = P.getObjectProperty(l, i);
        else if ("window." === i.substring(0, 7)) i = i.slice(7), o = P.getObjectProperty(e, i);
        else if ("param." === i.substring(0, 6)) i = i.slice(6), o = P.getQueryParam(i);
        else if (s = i.match(/^rand([0-9]+)$/)) {
            var d = Number(s[1]),
                f = (Math.random() * (Math.pow(10, d) - 1)).toFixed(0);
            o = Array(d - f.length + 1).join("0") + f
        } else o = P.getObjectProperty(c, i);
        return o
    }, P.getVars = function(e, t, n) {
        var i = {};
        return P.each(e, function(e) {
            i[e] = P.getVar(e, t, n)
        }), i
    }, P.replace = function(e, t, n, i) {
        return "string" != typeof e ? e : e.replace(/%(.*?)%/g, function(e, a) {
            var r = P.getVar(a, t, n);
            return null == r ? P.settings.undefinedVarsReturnEmpty ? "" : e : i ? P.escapeForHtml(r) : r
        })
    }, P.escapeHtmlParams = function(e) {
        return e.escapeHtml = !0, e
    }, P.searchVariables = function(e, t, n) {
        if (!e || 0 === e.length) return "";
        for (var i = [], a = 0, r = e.length; r > a; a++) {
            var s = e[a],
                o = P.getVar(s, t, n);
            i.push(s + "=" + escape(o))
        }
        return "?" + i.join("&")
    }, P.fireRule = function(e, t, n) {
        var i = e.trigger;
        if (i) {
            for (var a = 0, r = i.length; r > a; a++) {
                var s = i[a];
                P.execute(s, t, n)
            }
            P.contains(P.fireOnceEvents, e.event) && (e.expired = !0)
        }
    }, P.isLinked = function(e) {
        for (var t = e; t; t = t.parentNode)
            if (P.isLinkTag(t)) return !0;
        return !1
    }, P.firePageLoadEvent = function(e) {
        for (var n = t.location, i = {
                type: e,
                target: n
            }, a = P.pageLoadRules, r = P.evtHandlers[i.type], s = a.length; s--;) {
            var o = a[s];
            P.ruleMatches(o, i, n) && (P.notify('Rule "' + o.name + '" fired.', 1), P.fireRule(o, n, i))
        }
        for (var c in P.tools)
            if (P.tools.hasOwnProperty(c)) {
                var l = P.tools[c];
                l.endPLPhase && l.endPLPhase(e)
            }
        r && P.each(r, function(e) {
            e(i)
        })
    }, P.track = function(e) {
        e = e.replace(/^\s*/, "").replace(/\s*$/, "");
        for (var t = 0; t < P.directCallRules.length; t++) {
            var n = P.directCallRules[t];
            if (n.name === e) return P.notify('Direct call Rule "' + e + '" fired.', 1), void P.fireRule(n, location, {
                type: e
            })
        }
        P.notify('Direct call Rule "' + e + '" not found.', 1)
    }, P.basePath = function() {
        return P.data.host ? ("https:" === t.location.protocol ? "https://" + P.data.host.https : "http://" + P.data.host.http) + "/" : this.settings.basePath
    }, P.setLocation = function(t) {
        e.location = t
    }, P.parseQueryParams = function(e) {
        var t = function(e) {
            var t = e;
            try {
                t = decodeURIComponent(e)
            } catch (n) {}
            return t
        };
        if ("" === e || P.isString(e) === !1) return {};
        0 === e.indexOf("?") && (e = e.substring(1));
        var n = {},
            i = e.split("&");
        return P.each(i, function(e) {
            e = e.split("="), e[1] && (n[t(e[0])] = t(e[1]))
        }), n
    }, P.getCaseSensitivityQueryParamsMap = function(e) {
        var t = P.parseQueryParams(e),
            n = {};
        for (var i in t) t.hasOwnProperty(i) && (n[i.toLowerCase()] = t[i]);
        return {
            normal: t,
            caseInsensitive: n
        }
    }, P.updateQueryParams = function() {
        P.QueryParams = P.getCaseSensitivityQueryParamsMap(e.location.search)
    }, P.updateQueryParams(), P.getQueryParam = function(e) {
        return P.QueryParams.normal[e]
    }, P.getQueryParamCaseInsensitive = function(e) {
        return P.QueryParams.caseInsensitive[e.toLowerCase()]
    }, P.encodeObjectToURI = function(e) {
        if (P.isObject(e) === !1) return "";
        var t = [];
        for (var n in e) e.hasOwnProperty(n) && t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
        return t.join("&")
    }, P.readCookie = function(e) {
        for (var i = e + "=", a = t.cookie.split(";"), r = 0; r < a.length; r++) {
            for (var s = a[r];
                " " == s.charAt(0);) s = s.substring(1, s.length);
            if (0 === s.indexOf(i)) return s.substring(i.length, s.length)
        }
        return n
    }, P.setCookie = function(e, n, i) {
        var a;
        if (i) {
            var r = new Date;
            r.setTime(r.getTime() + 24 * i * 60 * 60 * 1e3), a = "; expires=" + r.toGMTString()
        } else a = "";
        t.cookie = e + "=" + n + a + "; path=/"
    }, P.removeCookie = function(e) {
        P.setCookie(e, "", -1)
    }, P.getElementProperty = function(e, t) {
        if ("@" === t.charAt(0)) {
            var i = P.specialProperties[t.substring(1)];
            if (i) return i(e)
        }
        return "innerText" === t ? P.text(e) : t in e ? e[t] : e.getAttribute ? e.getAttribute(t) : n
    }, P.propertiesMatch = function(e, t) {
        if (e)
            for (var n in e)
                if (e.hasOwnProperty(n)) {
                    var i = e[n],
                        a = P.getElementProperty(t, n);
                    if ("string" == typeof i && i !== a) return !1;
                    if (i instanceof RegExp && !i.test(a)) return !1
                }
        return !0
    }, P.isRightClick = function(e) {
        var t;
        return e.which ? t = 3 == e.which : e.button && (t = 2 == e.button), t
    }, P.ruleMatches = function(e, t, n, i) {
        var a = e.condition,
            r = e.conditions,
            s = e.property,
            o = t.type,
            c = e.value,
            l = t.target || t.srcElement,
            u = n === l;
        if (e.event !== o && ("custom" !== e.event || e.customEvent !== o)) return !1;
        if (!P.ruleInScope(e)) return !1;
        if ("click" === e.event && P.isRightClick(t)) return !1;
        if (e.isDefault && i > 0) return !1;
        if (e.expired) return !1;
        if ("inview" === o && t.inviewDelay !== e.inviewDelay) return !1;
        if (!u && (e.bubbleFireIfParent === !1 || 0 !== i && e.bubbleFireIfChildFired === !1)) return !1;
        if (e.selector && !P.matchesCss(e.selector, n)) return !1;
        if (!P.propertiesMatch(s, n)) return !1;
        if (null != c)
            if ("string" == typeof c) {
                if (c !== n.value) return !1
            } else if (!c.test(n.value)) return !1;
        if (a) try {
            if (!a.call(n, t, l)) return P.notify('Condition for rule "' + e.name + '" not met.', 1), !1
        } catch (d) {
            return P.notify('Condition for rule "' + e.name + '" not met. Error: ' + d.message, 1), !1
        }
        if (r) {
            var f = P.find(r, function(i) {
                try {
                    return !i.call(n, t, l)
                } catch (a) {
                    return P.notify('Condition for rule "' + e.name + '" not met. Error: ' + a.message, 1), !0
                }
            });
            if (f) return P.notify("Condition " + f.toString() + ' for rule "' + e.name + '" not met.', 1), !1
        }
        return !0
    }, P.evtHandlers = {}, P.bindEvent = function(e, t) {
        var n = P.evtHandlers;
        n[e] || (n[e] = []), n[e].push(t)
    }, P.whenEvent = P.bindEvent, P.unbindEvent = function(e, t) {
        var n = P.evtHandlers;
        if (n[e]) {
            var i = P.indexOf(n[e], t);
            n[e].splice(i, 1)
        }
    }, P.bindEventOnce = function(e, t) {
        var n = function() {
            P.unbindEvent(e, n), t.apply(null, arguments)
        };
        P.bindEvent(e, n)
    }, P.isVMLPoisoned = function(e) {
        if (!e) return !1;
        try {
            e.nodeName
        } catch (t) {
            if ("Attribute only valid on v:image" === t.message) return !0
        }
        return !1
    }, P.handleEvent = function(e) {
        if (!P.$data(e, "eventProcessed")) {
            var t = e.type.toLowerCase(),
                n = e.target || e.srcElement,
                i = 0,
                a = P.rules,
                r = (P.tools, P.evtHandlers[e.type]);
            if (P.isVMLPoisoned(n)) return void P.notify("detected " + t + " on poisoned VML element, skipping.", 1);
            r && P.each(r, function(t) {
                t(e)
            });
            var s = n && n.nodeName;
            s ? P.notify("detected " + t + " on " + n.nodeName, 1) : P.notify("detected " + t, 1);
            for (var o = n; o; o = o.parentNode) {
                var c = !1;
                if (P.each(a, function(t) {
                        P.ruleMatches(t, e, o, i) && (P.notify('Rule "' + t.name + '" fired.', 1), P.fireRule(t, o, e), i++, t.bubbleStop && (c = !0))
                    }), c) break
            }
            P.$data(e, "eventProcessed", !0)
        }
    }, P.onEvent = t.querySelectorAll ? function(e) {
        P.handleEvent(e)
    } : function() {
        var e = [],
            t = function(t) {
                t.selector ? e.push(t) : P.handleEvent(t)
            };
        return t.pendingEvents = e, t
    }(), P.fireEvent = function(e, t) {
        P.onEvent({
            type: e,
            target: t
        })
    }, P.registerEvents = function(e, t) {
        for (var n = t.length - 1; n >= 0; n--) {
            var i = t[n];
            P.$data(e, i + ".tracked") || (P.addEventHandler(e, i, P.onEvent), P.$data(e, i + ".tracked", !0))
        }
    }, P.registerEventsForTags = function(e, n) {
        for (var i = e.length - 1; i >= 0; i--)
            for (var a = e[i], r = t.getElementsByTagName(a), s = r.length - 1; s >= 0; s--) P.registerEvents(r[s], n)
    }, P.setListeners = function() {
        var e = ["click", "submit"];
        P.each(P.rules, function(t) {
            "custom" === t.event && t.hasOwnProperty("customEvent") && !P.contains(e, t.customEvent) && e.push(t.customEvent)
        }), P.registerEvents(t, e)
    }, P.getUniqueRuleEvents = function() {
        return P._uniqueRuleEvents || (P._uniqueRuleEvents = [], P.each(P.rules, function(e) {
            -1 === P.indexOf(P._uniqueRuleEvents, e.event) && P._uniqueRuleEvents.push(e.event)
        })), P._uniqueRuleEvents
    }, P.setFormListeners = function() {
        if (!P._relevantFormEvents) {
            var e = ["change", "focus", "blur", "keypress"];
            P._relevantFormEvents = P.filter(P.getUniqueRuleEvents(), function(t) {
                return -1 !== P.indexOf(e, t)
            })
        }
        P._relevantFormEvents.length && P.registerEventsForTags(["input", "select", "textarea", "button"], P._relevantFormEvents)
    }, P.setVideoListeners = function() {
        if (!P._relevantVideoEvents) {
            var e = ["play", "pause", "ended", "volumechange", "stalled", "loadeddata"];
            P._relevantVideoEvents = P.filter(P.getUniqueRuleEvents(), function(t) {
                return -1 !== P.indexOf(e, t)
            })
        }
        P._relevantVideoEvents.length && P.registerEventsForTags(["video"], P._relevantVideoEvents)
    }, P.readStoredSetting = function(t) {
        try {
            return t = "sdsat_" + t, e.localStorage.getItem(t)
        } catch (n) {
            return P.notify("Cannot read stored setting from localStorage: " + n.message, 2), null
        }
    }, P.loadStoredSettings = function() {
        var e = P.readStoredSetting("debug"),
            t = P.readStoredSetting("hide_activity");
        e && (P.settings.notifications = "true" === e), t && (P.settings.hideActivity = "true" === t)
    }, P.isRuleActive = function(e, t) {
        function n(e, t) {
            return t = a(t, {
                hour: e[h](),
                minute: e[g]()
            }), Math.floor(Math.abs((e.getTime() - t.getTime()) / 864e5))
        }

        function i(e, t) {
            function n(e) {
                return 12 * e[d]() + e[f]()
            }
            return Math.abs(n(e) - n(t))
        }

        function a(e, t) {
            var n = new Date(e.getTime());
            for (var i in t)
                if (t.hasOwnProperty(i)) {
                    var a = t[i];
                    switch (i) {
                        case "hour":
                            n[p](a);
                            break;
                        case "minute":
                            n[v](a);
                            break;
                        case "date":
                            n[m](a)
                    }
                }
            return n
        }

        function r(e, t) {
            var n = e[h](),
                i = e[g](),
                a = t[h](),
                r = t[g]();
            return 60 * n + i > 60 * a + r
        }

        function s(e, t) {
            var n = e[h](),
                i = e[g](),
                a = t[h](),
                r = t[g]();
            return 60 * a + r > 60 * n + i
        }
        var o = e.schedule;
        if (!o) return !0;
        var c = o.utc,
            l = c ? "getUTCDate" : "getDate",
            u = c ? "getUTCDay" : "getDay",
            d = c ? "getUTCFullYear" : "getFullYear",
            f = c ? "getUTCMonth" : "getMonth",
            h = c ? "getUTCHours" : "getHours",
            g = c ? "getUTCMinutes" : "getMinutes",
            p = c ? "setUTCHours" : "setHours",
            v = c ? "setUTCMinutes" : "setMinutes",
            m = c ? "setUTCDate" : "setDate";
        if (t = t || new Date, o.repeat) {
            if (r(o.start, t)) return !1;
            if (s(o.end, t)) return !1;
            if (t < o.start) return !1;
            if (o.endRepeat && t >= o.endRepeat) return !1;
            if ("daily" === o.repeat) {
                if (o.repeatEvery) {
                    var y = n(o.start, t);
                    if (y % o.repeatEvery !== 0) return !1
                }
            } else if ("weekly" === o.repeat) {
                if (o.days) {
                    if (!P.contains(o.days, t[u]())) return !1
                } else if (o.start[u]() !== t[u]()) return !1;
                if (o.repeatEvery) {
                    var b = n(o.start, t);
                    if (b % (7 * o.repeatEvery) !== 0) return !1
                }
            } else if ("monthly" === o.repeat) {
                if (o.repeatEvery) {
                    var k = i(o.start, t);
                    if (k % o.repeatEvery !== 0) return !1
                }
                if (o.nthWeek && o.mthDay) {
                    if (o.mthDay !== t[u]()) return !1;
                    var E = Math.floor((t[l]() - t[u]() + 1) / 7);
                    if (o.nthWeek !== E) return !1
                } else if (o.start[l]() !== t[l]()) return !1
            } else if ("yearly" === o.repeat) {
                if (o.start[f]() !== t[f]()) return !1;
                if (o.start[l]() !== t[l]()) return !1;
                if (o.repeatEvery) {
                    var b = Math.abs(o.start[d]() - t[d]());
                    if (b % o.repeatEvery !== 0) return !1
                }
            }
        } else {
            if (o.start > t) return !1;
            if (o.end < t) return !1
        }
        return !0
    }, P.isOutboundLink = function(e) {
        if (!e.getAttribute("href")) return !1;
        var t = e.hostname,
            n = (e.href, e.protocol);
        if ("http:" !== n && "https:" !== n) return !1;
        var i = P.any(P.settings.domainList, function(e) {
            return P.isSubdomainOf(t, e)
        });
        return i ? !1 : t !== location.hostname
    }, P.isLinkerLink = function(e) {
        return e.getAttribute && e.getAttribute("href") ? P.hasMultipleDomains() && e.hostname != location.hostname && !e.href.match(/^javascript/i) && !P.isOutboundLink(e) : !1
    }, P.isSubdomainOf = function(e, t) {
        if (e === t) return !0;
        var n = e.length - t.length;
        return n > 0 ? P.equalsIgnoreCase(e.substring(n), t) : !1
    }, P.getVisitorId = function() {
        var e = P.getToolsByType("visitor_id");
        return 0 === e.length ? null : e[0].getInstance()
    }, P.URI = function() {
        var e = t.location.pathname + t.location.search;
        return P.settings.forceLowerCase && (e = e.toLowerCase()), e
    }, P.URL = function() {
        var e = t.location.href;
        return P.settings.forceLowerCase && (e = e.toLowerCase()), e
    }, P.filterRules = function() {
        function e(e) {
            return P.isRuleActive(e) ? !0 : !1
        }
        P.rules = P.filter(P.rules, e), P.pageLoadRules = P.filter(P.pageLoadRules, e)
    }, P.ruleInScope = function(e, n) {
        function i(e, t) {
            function n(e) {
                return t.match(e)
            }
            var i = e.include,
                r = e.exclude;
            if (i && a(i, t)) return !0;
            if (r) {
                if (P.isString(r) && r === t) return !0;
                if (P.isArray(r) && P.any(r, n)) return !0;
                if (P.isRegex(r) && n(r)) return !0
            }
            return !1
        }

        function a(e, t) {
            function n(e) {
                return t.match(e)
            }
            return P.isString(e) && e !== t ? !0 : P.isArray(e) && !P.any(e, n) ? !0 : P.isRegex(e) && !n(e) ? !0 : !1
        }
        n = n || t.location;
        var r = e.scope;
        if (!r) return !0;
        var s = r.URI,
            o = r.subdomains,
            c = r.domains,
            l = r.protocols,
            u = r.hashes;
        return s && i(s, n.pathname + n.search) ? !1 : o && i(o, n.hostname) ? !1 : c && a(c, n.hostname) ? !1 : l && a(l, n.protocol) ? !1 : u && i(u, n.hash) ? !1 : !0
    }, P.backgroundTasks = function() {
        +new Date;
        P.setFormListeners(), P.setVideoListeners(), P.loadStoredSettings(), P.registerNewElementsForDynamicRules(), P.eventEmitterBackgroundTasks(); + new Date
    }, P.registerNewElementsForDynamicRules = function() {
        function e(t, n) {
            var i = e.cache[t];
            return i ? n(i) : void P.cssQuery(t, function(i) {
                e.cache[t] = i, n(i)
            })
        }
        e.cache = {}, P.each(P.dynamicRules, function(t) {
            e(t.selector, function(e) {
                P.each(e, function(e) {
                    var n = "custom" === t.event ? t.customEvent : t.event;
                    P.$data(e, "dynamicRules.seen." + n) || (P.$data(e, "dynamicRules.seen." + n, !0), P.propertiesMatch(t.property, e) && P.registerEvents(e, [n]))
                })
            })
        })
    }, P.ensureCSSSelector = function() {
        return t.querySelectorAll ? void(P.hasSelector = !0) : (P.loadingSizzle = !0, P.sizzleQueue = [], void P.loadScript(P.basePath() + "selector.js", function() {
            if (!P.Sizzle) return void P.logError(new Error("Failed to load selector.js"));
            var e = P.onEvent.pendingEvents;
            P.each(e, function(e) {
                P.handleEvent(e)
            }, this), P.onEvent = P.handleEvent, P.hasSelector = !0, delete P.loadingSizzle, P.each(P.sizzleQueue, function(e) {
                P.cssQuery(e[0], e[1])
            }), delete P.sizzleQueue
        }))
    }, P.errors = [], P.logError = function(e) {
        P.errors.push(e), P.notify(e.name + " - " + e.message, 5)
    }, P.pageBottom = function() {
        P.initialized && (P.pageBottomFired = !0, P.firePageLoadEvent("pagebottom"))
    }, P.stagingLibraryOverride = function() {
        var e = "true" === P.readStoredSetting("stagingLibrary");
        if (e) {
            for (var n, i, a, r = t.getElementsByTagName("script"), s = /^(.*)satelliteLib-([a-f0-9]{40})\.js$/, o = /^(.*)satelliteLib-([a-f0-9]{40})-staging\.js$/, c = 0, l = r.length; l > c && (a = r[c].getAttribute("src"), !a || (n || (n = a.match(s)), i || (i = a.match(o)), !i)); c++);
            if (n && !i) {
                var u = n[1] + "satelliteLib-" + n[2] + "-staging.js";
                if (t.write) t.write('<script src="' + u + '"></script>');
                else {
                    var d = t.createElement("script");
                    d.src = u, t.head.appendChild(d)
                }
                return !0
            }
        }
        return !1
    }, P.checkAsyncInclude = function() {
        e.satellite_asyncLoad && P.notify('You may be using the async installation of Satellite. In-page HTML and the "pagebottom" event will not work. Please update your Satellite installation for these features.', 5)
    }, P.hasMultipleDomains = function() {
        return !!P.settings.domainList && P.settings.domainList.length > 1
    }, P.handleOverrides = function() {
        if (C)
            for (var e in C) C.hasOwnProperty(e) && (P.data[e] = C[e])
    }, P.privacyManagerParams = function() {
        var e = {};
        P.extend(e, P.settings.privacyManagement);
        var t = [];
        for (var n in P.tools)
            if (P.tools.hasOwnProperty(n)) {
                var i = P.tools[n],
                    a = i.settings;
                if (!a) continue;
                "sc" === a.engine && t.push(i)
            }
        var r = P.filter(P.map(t, function(e) {
            return e.getTrackingServer()
        }), function(e) {
            return null != e
        });
        e.adobeAnalyticsTrackingServers = r;
        for (var s = ["bannerText", "headline", "introductoryText", "customCSS"], o = 0; o < s.length; o++) {
            var c = s[o],
                l = e[c];
            if (l)
                if ("text" === l.type) e[c] = l.value;
                else {
                    if ("data" !== l.type) throw new Error("Invalid type: " + l.type);
                    e[c] = P.getVar(l.value)
                }
        }
        return e
    }, P.prepareLoadPrivacyManager = function() {
        function t(e) {
            function t() {
                r++, r === a.length && (n(), clearTimeout(s), e())
            }

            function n() {
                P.each(a, function(e) {
                    P.unbindEvent(e.id + ".load", t)
                })
            }

            function i() {
                n(), e()
            }
            var a = P.filter(P.values(P.tools), function(e) {
                return e.settings && "sc" === e.settings.engine
            });
            if (0 === a.length) return e();
            var r = 0;
            P.each(a, function(e) {
                P.bindEvent(e.id + ".load", t)
            });
            var s = setTimeout(i, 5e3)
        }
        P.addEventHandler(e, "load", function() {
            t(P.loadPrivacyManager)
        })
    }, P.loadPrivacyManager = function() {
        var e = P.basePath() + "privacy_manager.js";
        P.loadScript(e, function() {
            var e = P.privacyManager;
            e.configure(P.privacyManagerParams()), e.openIfRequired()
        })
    }, P.init = function(t) {
        if (!P.stagingLibraryOverride()) {
            P.configurationSettings = t;
            var i = t.tools;
            delete t.tools;
            for (var a in t) t.hasOwnProperty(a) && (P[a] = t[a]);
            P.data.customVars === n && (P.data.customVars = {}), P.data.queryParams = P.QueryParams.normal, P.handleOverrides(), P.detectBrowserInfo(), P.trackVisitorInfo && P.trackVisitorInfo(), P.loadStoredSettings(), P.Logger.setOutputState(P.settings.notifications), P.checkAsyncInclude(), P.ensureCSSSelector(), P.filterRules(), P.dynamicRules = P.filter(P.rules, function(e) {
                return e.eventHandlerOnElement
            }), P.tools = P.initTools(i), P.initEventEmitters(), P.firePageLoadEvent("aftertoolinit"), P.settings.privacyManagement && P.prepareLoadPrivacyManager(), P.hasSelector && P.domReady(P.eventEmitterBackgroundTasks), P.setListeners(), P.domReady(function() {
                P.poll(function() {
                    P.backgroundTasks()
                }, P.settings.recheckEvery || 3e3)
            }), P.domReady(function() {
                P.domReadyFired = !0, P.pageBottomFired || P.pageBottom(), P.firePageLoadEvent("domready")
            }), P.addEventHandler(e, "load", function() {
                P.firePageLoadEvent("windowload")
            }), P.firePageLoadEvent("pagetop"), P.initialized = !0
        }
    }, P.pageLoadPhases = ["aftertoolinit", "pagetop", "pagebottom", "domready", "windowload"], P.loadEventBefore = function(e, t) {
        return P.indexOf(P.pageLoadPhases, e) <= P.indexOf(P.pageLoadPhases, t)
    }, P.flushPendingCalls = function(e) {
        e.pending && (P.each(e.pending, function(t) {
            var n = t[0],
                i = t[1],
                a = t[2],
                r = t[3];
            n in e ? e[n].apply(e, [i, a].concat(r)) : e.emit ? e.emit(n, i, a, r) : P.notify("Failed to trigger " + n + " for tool " + e.id, 1)
        }), delete e.pending)
    }, P.setDebug = function(t) {
        try {
            e.localStorage.setItem("sdsat_debug", t)
        } catch (n) {
            P.notify("Cannot set debug mode: " + n.message, 2)
        }
    }, P.getUserAgent = function() {
        return navigator.userAgent
    }, P.detectBrowserInfo = function() {
        function e(e) {
            return function(t) {
                for (var n in e)
                    if (e.hasOwnProperty(n)) {
                        var i = e[n],
                            a = i.test(t);
                        if (a) return n
                    }
                return "Unknown"
            }
        }
        var t = e({
                OmniWeb: /OmniWeb/,
                "Opera Mini": /Opera Mini/,
                "Opera Mobile": /Opera Mobi/,
                Opera: /Opera/,
                Chrome: /Chrome|CriOS|CrMo/,
                Firefox: /Firefox|FxiOS/,
                "IE Mobile": /IEMobile/,
                IE: /MSIE|Trident/,
                "Mobile Safari": /Mobile(\/[0-9A-z]+)? Safari/,
                Safari: /Safari/
            }),
            n = e({
                Blackberry: /BlackBerry|BB10/,
                "Symbian OS": /Symbian|SymbOS/,
                Maemo: /Maemo/,
                Android: /Android/,
                Linux: / Linux /,
                Unix: /FreeBSD|OpenBSD|CrOS/,
                Windows: /[\( ]Windows /,
                iOS: /iPhone|iPad|iPod/,
                MacOS: /Macintosh;/
            }),
            i = e({
                Nokia: /Symbian|SymbOS|Maemo/,
                "Windows Phone": /Windows Phone/,
                Blackberry: /BlackBerry|BB10/,
                Android: /Android/,
                iPad: /iPad/,
                iPod: /iPod/,
                iPhone: /iPhone/,
                Desktop: /.*/
            }),
            a = P.getUserAgent();
        P.browserInfo = {
            browser: t(a),
            os: n(a),
            deviceType: i(a)
        }
    }, P.isHttps = function() {
        return "https:" == t.location.protocol
    }, P.BaseTool = function(e) {
        this.settings = e || {}, this.forceLowerCase = P.settings.forceLowerCase, "forceLowerCase" in this.settings && (this.forceLowerCase = this.settings.forceLowerCase)
    }, P.BaseTool.prototype = {
        triggerCommand: function(e, t, n) {
            var i = this.settings || {};
            if (this.initialize && this.isQueueAvailable() && this.isQueueable(e) && n && P.loadEventBefore(n.type, i.loadOn)) return void this.queueCommand(e, t, n);
            var a = e.command,
                r = this["$" + a],
                s = r ? r.escapeHtml : !1,
                o = P.preprocessArguments(e.arguments, t, n, this.forceLowerCase, s);
            r ? r.apply(this, [t, n].concat(o)) : this.$missing$ ? this.$missing$(a, t, n, o) : P.notify("Failed to trigger " + a + " for tool " + this.id, 1)
        },
        endPLPhase: function(e) {},
        isQueueable: function(e) {
            return "cancelToolInit" !== e.command
        },
        isQueueAvailable: function() {
            return !this.initialized && !this.initializing
        },
        flushQueue: function() {
            this.pending && (P.each(this.pending, function(e) {
                this.triggerCommand.apply(this, e)
            }, this), this.pending = [])
        },
        queueCommand: function(e, t, n) {
            this.pending || (this.pending = []), this.pending.push([e, t, n])
        },
        $cancelToolInit: function() {
            this._cancelToolInit = !0
        }
    }, e._satellite = P, a.prototype.backgroundTasks = function() {
        P.each(this.rules, function(e) {
            P.cssQuery(e.selector, function(e) {
                if (e.length > 0) {
                    var t = e[0];
                    if (P.$data(t, "elementexists.seen")) return;
                    P.$data(t, "elementexists.seen", !0), P.onEvent({
                        type: "elementexists",
                        target: t
                    })
                }
            })
        })
    }, P.availableEventEmitters.push(a), r.prototype = {
        initialize: function() {
            return this.FB = this.FB || e.FB, this.FB && this.FB.Event && this.FB.Event.subscribe ? (this.bind(), !0) : void 0
        },
        bind: function() {
            this.FB.Event.subscribe("edge.create", function() {
                P.notify("tracking a facebook like", 1), P.onEvent({
                    type: "facebook.like",
                    target: t
                })
            }), this.FB.Event.subscribe("edge.remove", function() {
                P.notify("tracking a facebook unlike", 1), P.onEvent({
                    type: "facebook.unlike",
                    target: t
                })
            }), this.FB.Event.subscribe("message.send", function() {
                P.notify("tracking a facebook share", 1), P.onEvent({
                    type: "facebook.send",
                    target: t
                })
            })
        }
    }, P.availableEventEmitters.push(r), s.prototype = {
        backgroundTasks: function() {
            var e = this;
            P.each(this.rules, function(t) {
                var n = t[1],
                    i = t[0];
                P.cssQuery(n, function(t) {
                    P.each(t, function(t) {
                        e.trackElement(t, i)
                    })
                })
            }, this)
        },
        trackElement: function(e, t) {
            var n = this,
                i = P.$data(e, "hover.delays");
            i ? P.contains(i, t) || i.push(t) : (P.addEventHandler(e, "mouseover", function(t) {
                n.onMouseOver(t, e)
            }), P.addEventHandler(e, "mouseout", function(t) {
                n.onMouseOut(t, e)
            }), P.$data(e, "hover.delays", [t]))
        },
        onMouseOver: function(e, t) {
            var n = e.target || e.srcElement,
                i = e.relatedTarget || e.fromElement,
                a = (t === n || P.containsElement(t, n)) && !P.containsElement(t, i);
            a && this.onMouseEnter(t)
        },
        onMouseEnter: function(e) {
            var t = P.$data(e, "hover.delays"),
                n = P.map(t, function(t) {
                    return setTimeout(function() {
                        P.onEvent({
                            type: "hover(" + t + ")",
                            target: e
                        })
                    }, t)
                });
            P.$data(e, "hover.delayTimers", n)
        },
        onMouseOut: function(e, t) {
            var n = e.target || e.srcElement,
                i = e.relatedTarget || e.toElement,
                a = (t === n || P.containsElement(t, n)) && !P.containsElement(t, i);
            a && this.onMouseLeave(t)
        },
        onMouseLeave: function(e) {
            var t = P.$data(e, "hover.delayTimers");
            t && P.each(t, function(e) {
                clearTimeout(e)
            })
        }
    }, P.availableEventEmitters.push(s), o.offset = function(n) {
        var i = null,
            a = null;
        try {
            var r = n.getBoundingClientRect(),
                s = t,
                o = s.documentElement,
                c = s.body,
                l = e,
                u = o.clientTop || c.clientTop || 0,
                d = o.clientLeft || c.clientLeft || 0,
                f = l.pageYOffset || o.scrollTop || c.scrollTop,
                h = l.pageXOffset || o.scrollLeft || c.scrollLeft;
            i = r.top + f - u, a = r.left + h - d
        } catch (g) {}
        return {
            top: i,
            left: a
        }
    }, o.getViewportHeight = function() {
        var n = e.innerHeight,
            i = t.compatMode;
        return i && (n = "CSS1Compat" == i ? t.documentElement.clientHeight : t.body.clientHeight), n
    }, o.getScrollTop = function() {
        return t.documentElement.scrollTop ? t.documentElement.scrollTop : t.body.scrollTop
    }, o.isElementInDocument = function(e) {
        return t.body.contains(e)
    }, o.isElementInView = function(e) {
        if (!o.isElementInDocument(e)) return !1;
        var t = o.getViewportHeight(),
            n = o.getScrollTop(),
            i = o.offset(e).top,
            a = e.offsetHeight;
        return null !== i ? !(n > i + a || i > n + t) : !1
    }, o.prototype = {
        backgroundTasks: function() {
            var e = this.elements;
            P.each(this.rules, function(t) {
                P.cssQuery(t.selector, function(n) {
                    var i = 0;
                    P.each(n, function(t) {
                        P.contains(e, t) || (e.push(t), i++)
                    }), i && P.notify(t.selector + " added " + i + " elements.", 1)
                })
            }), this.track()
        },
        checkInView: function(e, t) {
            var n = P.$data(e, "inview");
            if (o.isElementInView(e)) {
                n || P.$data(e, "inview", !0);
                var i = this;
                this.processRules(e, function(n, a, r) {
                    if (t || !n.inviewDelay) P.$data(e, a, !0), P.onEvent({
                        type: "inview",
                        target: e,
                        inviewDelay: n.inviewDelay
                    });
                    else if (n.inviewDelay) {
                        var s = P.$data(e, r);
                        s || (s = setTimeout(function() {
                            i.checkInView(e, !0)
                        }, n.inviewDelay), P.$data(e, r, s))
                    }
                })
            } else {
                if (!o.isElementInDocument(e)) {
                    var a = P.indexOf(this.elements, e);
                    this.elements.splice(a, 1)
                }
                n && P.$data(e, "inview", !1), this.processRules(e, function(t, n, i) {
                    var a = P.$data(e, i);
                    a && clearTimeout(a)
                })
            }
        },
        track: function() {
            for (var e = this.elements.length - 1; e >= 0; e--) this.checkInView(this.elements[e])
        },
        processRules: function(e, t) {
            P.each(this.rules, function(n, i) {
                var a = n.inviewDelay ? "viewed_" + n.inviewDelay : "viewed",
                    r = "inview_timeout_id_" + i;
                P.$data(e, a) || P.matchesCss(n.selector, e) && t(n, a, r)
            })
        }
    }, P.availableEventEmitters.push(o), c.prototype = {
        obue: !1,
        initialize: function() {
            return this.attachCloseListeners(), !0
        },
        obuePrevUnload: function() {},
        obuePrevBeforeUnload: function() {},
        newObueListener: function() {
            this.obue || (this.obue = !0, this.triggerBeacons())
        },
        attachCloseListeners: function() {
            this.prevUnload = e.onunload, this.prevBeforeUnload = e.onbeforeunload, e.onunload = P.bind(function() {
                this.prevUnload && setTimeout(this.prevUnload, 1), this.newObueListener()
            }, this), e.onbeforeunload = P.bind(function() {
                this.prevBeforeUnload && setTimeout(this.prevBeforeUnload, 1), this.newObueListener()
            }, this)
        },
        triggerBeacons: function() {
            P.fireEvent("leave", t)
        }
    }, P.availableEventEmitters.push(c), l.prototype = {
        initialize: function() {
            this.setupHistoryAPI(), this.setupHashChange()
        },
        fireIfURIChanged: function() {
            var e = P.URL();
            this.lastURL !== e && (this.fireEvent(), this.lastURL = e)
        },
        fireEvent: function() {
            P.updateQueryParams(), P.onEvent({
                type: "locationchange",
                target: t
            })
        },
        setupSPASupport: function() {
            this.setupHistoryAPI(), this.setupHashChange()
        },
        setupHistoryAPI: function() {
            var t = e.history;
            t && (t.pushState && (this.originalPushState = t.pushState, t.pushState = this._pushState), t.replaceState && (this.originalReplaceState = t.replaceState, t.replaceState = this._replaceState)), P.addEventHandler(e, "popstate", this._onPopState)
        },
        pushState: function() {
            var e = this.originalPushState.apply(history, arguments);
            return this.onPushState(), e
        },
        replaceState: function() {
            var e = this.originalReplaceState.apply(history, arguments);
            return this.onReplaceState(), e
        },
        setupHashChange: function() {
            P.addEventHandler(e, "hashchange", this._onHashChange)
        },
        onReplaceState: function() {
            setTimeout(this._fireIfURIChanged, 0)
        },
        onPushState: function() {
            setTimeout(this._fireIfURIChanged, 0)
        },
        onPopState: function() {
            setTimeout(this._fireIfURIChanged, 0)
        },
        onHashChange: function() {
            setTimeout(this._fireIfURIChanged, 0)
        },
        uninitialize: function() {
            this.cleanUpHistoryAPI(), this.cleanUpHashChange()
        },
        cleanUpHistoryAPI: function() {
            history.pushState === this._pushState && (history.pushState = this.originalPushState), history.replaceState === this._replaceState && (history.replaceState = this.originalReplaceState), P.removeEventHandler(e, "popstate", this._onPopState)
        },
        cleanUpHashChange: function() {
            P.removeEventHandler(e, "hashchange", this._onHashChange)
        }
    }, P.availableEventEmitters.push(l), u.orientationChange = function(t) {
        var n = 0 === e.orientation ? "portrait" : "landscape";
        t.orientation = n, P.onEvent(t)
    }, P.availableEventEmitters.push(u), d.prototype = {
        initialize: function() {
            var e = this.twttr;
            e && "function" == typeof e.ready && e.ready(P.bind(this.bind, this))
        },
        bind: function() {
            this.twttr.events.bind("tweet", function(e) {
                e && (P.notify("tracking a tweet button", 1), P.onEvent({
                    type: "twitter.tweet",
                    target: t
                }))
            })
        }
    }, P.availableEventEmitters.push(d), f.prototype = {
        backgroundTasks: function() {
            var e = this.eventHandler;
            P.each(this.rules, function(t) {
                P.cssQuery(t.selector || "video", function(t) {
                    P.each(t, function(t) {
                        P.$data(t, "videoplayed.tracked") || (P.addEventHandler(t, "timeupdate", P.throttle(e, 100)), P.$data(t, "videoplayed.tracked", !0))
                    })
                })
            })
        },
        evalRule: function(e, t) {
            var n = t.event,
                i = e.seekable,
                a = i.start(0),
                r = i.end(0),
                s = e.currentTime,
                o = t.event.match(/^videoplayed\(([0-9]+)([s%])\)$/);
            if (o) {
                var c = o[2],
                    l = Number(o[1]),
                    u = "%" === c ? function() {
                        return 100 * (s - a) / (r - a) >= l
                    } : function() {
                        return s - a >= l
                    };
                !P.$data(e, n) && u() && (P.$data(e, n, !0), P.onEvent({
                    type: n,
                    target: e
                }))
            }
        },
        onUpdateTime: function(e) {
            var t = this.rules,
                n = e.target;
            if (n.seekable && 0 !== n.seekable.length)
                for (var i = 0, a = t.length; a > i; i++) this.evalRule(n, t[i])
        }
    }, P.availableEventEmitters.push(f), h.prototype = {
        defineEvents: function() {
            this.oldBlurClosure = function() {
                P.fireEvent("tabblur", t)
            }, this.oldFocusClosure = P.bind(function() {
                this.visibilityApiHasPriority ? P.fireEvent("tabfocus", t) : null != P.visibility.getHiddenProperty() ? P.visibility.isHidden() || P.fireEvent("tabfocus", t) : P.fireEvent("tabfocus", t)
            }, this)
        },
        attachDetachModernEventListeners: function(e) {
            var n = 0 == e ? "removeEventHandler" : "addEventHandler";
            P[n](t, P.visibility.getVisibilityEvent(), this.handleVisibilityChange)
        },
        attachDetachOlderEventListeners: function(t, n, i) {
            var a = 0 == t ? "removeEventHandler" : "addEventHandler";
            P[a](n, i, this.oldBlurClosure), P[a](e, "focus", this.oldFocusClosure)
        },
        handleVisibilityChange: function() {
            P.visibility.isHidden() ? P.fireEvent("tabblur", t) : P.fireEvent("tabfocus", t)
        },
        setVisibilityApiPriority: function(t) {
            this.visibilityApiHasPriority = t, this.attachDetachOlderEventListeners(!1, e, "blur"), this.attachDetachModernEventListeners(!1), t ? null != P.visibility.getHiddenProperty() ? this.attachDetachModernEventListeners(!0) : this.attachDetachOlderEventListeners(!0, e, "blur") : (this.attachDetachOlderEventListeners(!0, e, "blur"), null != P.visibility.getHiddenProperty() && this.attachDetachModernEventListeners(!0))
        },
        oldBlurClosure: null,
        oldFocusClosure: null,
        visibilityApiHasPriority: !0
    }, P.availableEventEmitters.push(h), P.ecommerce = {
        addItem: function() {
            var e = [].slice.call(arguments);
            P.onEvent({
                type: "ecommerce.additem",
                target: e
            })
        },
        addTrans: function() {
            var e = [].slice.call(arguments);
            P.data.saleData.sale = {
                orderId: e[0],
                revenue: e[2]
            }, P.onEvent({
                type: "ecommerce.addtrans",
                target: e
            })
        },
        trackTrans: function() {
            P.onEvent({
                type: "ecommerce.tracktrans",
                target: []
            })
        }
    }, P.visibility = {
        isHidden: function() {
            var e = this.getHiddenProperty();
            return e ? t[e] : !1
        },
        isVisible: function() {
            return !this.isHidden()
        },
        getHiddenProperty: function() {
            var e = ["webkit", "moz", "ms", "o"];
            if ("hidden" in t) return "hidden";
            for (var n = 0; n < e.length; n++)
                if (e[n] + "Hidden" in t) return e[n] + "Hidden";
            return null
        },
        getVisibilityEvent: function() {
            var e = this.getHiddenProperty();
            return e ? e.replace(/[H|h]idden/, "") + "visibilitychange" : null
        }
    }, P.inherit(g, P.BaseTool), P.extend(g.prototype, {
        initialize: function() {
            var e = this.settings;
            if (this.settings.initTool !== !1) {
                var t = e.url;
                t = "string" == typeof t ? P.basePath() + t : P.isHttps() ? t.https : t.http, P.loadScript(t, P.bind(this.onLoad, this)), this.initializing = !0
            } else this.initialized = !0
        },
        isQueueAvailable: function() {
            return !this.initialized
        },
        onLoad: function() {
            this.initialized = !0, this.initializing = !1, this.settings.initialBeacon && this.settings.initialBeacon(), this.flushQueue()
        },
        endPLPhase: function(e) {
            var t = this.settings.loadOn;
            e === t && (P.notify(this.name + ": Initializing at " + e, 1), this.initialize())
        },
        $fire: function(e, t, n) {
            return this.initializing ? void this.queueCommand({
                command: "fire",
                arguments: [n]
            }, e, t) : void n.call(this.settings, e, t)
        }
    }), P.availableTools.am = g, P.availableTools.adlens = g, P.availableTools.__basic = g, P.inherit(p, P.BaseTool), P.extend(p.prototype, {
        name: "Default",
        $loadIframe: function(t, n, i) {
            var a = i.pages,
                r = i.loadOn,
                s = P.bind(function() {
                    P.each(a, function(e) {
                        this.loadIframe(t, n, e)
                    }, this)
                }, this);
            r || s(), "domready" === r && P.domReady(s), "load" === r && P.addEventHandler(e, "load", s)
        },
        loadIframe: function(e, n, i) {
            var a = t.createElement("iframe");
            a.style.display = "none";
            var r = P.data.host,
                s = i.data,
                o = this.scriptURL(i.src),
                c = P.searchVariables(s, e, n);
            r && (o = P.basePath() + o), o += c, a.src = o;
            var l = t.getElementsByTagName("body")[0];
            l ? l.appendChild(a) : P.domReady(function() {
                t.getElementsByTagName("body")[0].appendChild(a)
            })
        },
        scriptURL: function(e) {
            var t = P.settings.scriptDir || "";
            return t + e
        },
        $loadScript: function(t, n, i) {
            var a = i.scripts,
                r = i.sequential,
                s = i.loadOn,
                o = P.bind(function() {
                    r ? this.loadScripts(t, n, a) : P.each(a, function(e) {
                        this.loadScripts(t, n, [e])
                    }, this)
                }, this);
            s ? "domready" === s ? P.domReady(o) : "load" === s && P.addEventHandler(e, "load", o) : o()
        },
        loadScripts: function(e, t, n) {
            function i() {
                if (r.length > 0 && a) {
                    var c = r.shift();
                    c.call(e, t, s)
                }
                var l = n.shift();
                if (l) {
                    var u = P.data.host,
                        d = o.scriptURL(l.src);
                    u && (d = P.basePath() + d), a = l, P.loadScript(d, i)
                }
            }
            try {
                var a, n = n.slice(0),
                    r = this.asyncScriptCallbackQueue,
                    s = t.target || t.srcElement,
                    o = this
            } catch (c) {
                console.error("scripts is", P.stringify(n))
            }
            i()
        },
        $loadBlockingScript: function(e, t, n) {
            var i = n.scripts,
                a = (n.loadOn, P.bind(function() {
                    P.each(i, function(n) {
                        this.loadBlockingScript(e, t, n)
                    }, this)
                }, this));
            a()
        },
        loadBlockingScript: function(e, t, n) {
            var i = this.scriptURL(n.src),
                a = P.data.host,
                r = t.target || t.srcElement;
            a && (i = P.basePath() + i), this.argsForBlockingScripts.push([e, t, r]), P.loadScriptSync(i)
        },
        pushAsyncScript: function(e) {
            this.asyncScriptCallbackQueue.push(e)
        },
        pushBlockingScript: function(e) {
            var t = this.argsForBlockingScripts.shift(),
                n = t[0];
            e.apply(n, t.slice(1))
        },
        $writeHTML: P.escapeHtmlParams(function(e, n) {
            if (P.domReadyFired || !t.write) return void P.notify("Command writeHTML failed. You should try appending HTML using the async option.", 1);
            if ("pagebottom" !== n.type && "pagetop" !== n.type) return void P.notify("You can only use writeHTML on the `pagetop` and `pagebottom` events.", 1);
            for (var i = 2, a = arguments.length; a > i; i++) {
                var r = arguments[i].html;
                r = P.replace(r, e, n), t.write(r)
            }
        }),
        linkNeedsDelayActivate: function(t, n) {
            n = n || e;
            var i = t.tagName,
                a = t.getAttribute("target"),
                r = t.getAttribute("href");
            return i && "a" !== i.toLowerCase() ? !1 : r ? a ? "_blank" === a ? !1 : "_top" === a ? n.top === n : "_parent" === a ? !1 : "_self" === a ? !0 : n.name ? a === n.name : !0 : !0 : !1
        },
        $delayActivateLink: function(e, t) {
            if (this.linkNeedsDelayActivate(e)) {
                P.preventDefault(t);
                var n = P.settings.linkDelay || 100;
                setTimeout(function() {
                    P.setLocation(e.href)
                }, n)
            }
        },
        isQueueable: function(e) {
            return "writeHTML" !== e.command
        }
    }), P.availableTools["default"] = p, P.inherit(v, P.BaseTool), P.extend(v.prototype, {
        name: "GA",
        initialize: function() {
            var t = this.settings,
                n = e._gaq,
                i = t.initCommands || [],
                a = t.customInit;
            if (n || (_gaq = []), this.isSuppressed()) P.notify("GA: page code not loaded(suppressed).", 1);
            else {
                if (!n && !v.scriptLoaded) {
                    var r = P.isHttps(),
                        s = (r ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
                    t.url && (s = r ? t.url.https : t.url.http), P.loadScript(s), v.scriptLoaded = !0, P.notify("GA: page code loaded.", 1)
                }
                var o = (t.domain, t.trackerName),
                    c = T.allowLinker(),
                    l = P.replace(t.account, location);
                P.settings.domainList || [];
                _gaq.push([this.cmd("setAccount"), l]), c && _gaq.push([this.cmd("setAllowLinker"), c]), _gaq.push([this.cmd("setDomainName"), T.cookieDomain()]), P.each(i, function(e) {
                    var t = [this.cmd(e[0])].concat(P.preprocessArguments(e.slice(1), location, null, this.forceLowerCase));
                    _gaq.push(t)
                }, this), a && (this.suppressInitialPageView = !1 === a(_gaq, o)), t.pageName && this.$overrideInitialPageView(null, null, t.pageName)
            }
            this.initialized = !0, P.fireEvent(this.id + ".configure", _gaq, o)
        },
        isSuppressed: function() {
            return this._cancelToolInit || this.settings.initTool === !1
        },
        tracker: function() {
            return this.settings.trackerName
        },
        cmd: function(e) {
            var t = this.tracker();
            return t ? t + "._" + e : "_" + e
        },
        $overrideInitialPageView: function(e, t, n) {
            this.urlOverride = n
        },
        trackInitialPageView: function() {
            if (!this.isSuppressed() && !this.suppressInitialPageView)
                if (this.urlOverride) {
                    var e = P.preprocessArguments([this.urlOverride], location, null, this.forceLowerCase);
                    this.$missing$("trackPageview", null, null, e)
                } else this.$missing$("trackPageview")
        },
        endPLPhase: function(e) {
            var t = this.settings.loadOn;
            e === t && (P.notify("GA: Initializing at " + e, 1), this.initialize(), this.flushQueue(), this.trackInitialPageView())
        },
        call: function(e, t, n, i) {
            if (!this._cancelToolInit) {
                var a = (this.settings, this.tracker()),
                    r = this.cmd(e),
                    i = i ? [r].concat(i) : [r];
                _gaq.push(i), a ? P.notify("GA: sent command " + e + " to tracker " + a + (i.length > 1 ? " with parameters [" + i.slice(1).join(", ") + "]" : "") + ".", 1) : P.notify("GA: sent command " + e + (i.length > 1 ? " with parameters [" + i.slice(1).join(", ") + "]" : "") + ".", 1)
            }
        },
        $missing$: function(e, t, n, i) {
            this.call(e, t, n, i)
        },
        $postTransaction: function(t, n, i) {
            var a = P.data.customVars.transaction = e[i];
            this.call("addTrans", t, n, [a.orderID, a.affiliation, a.total, a.tax, a.shipping, a.city, a.state, a.country]), P.each(a.items, function(e) {
                this.call("addItem", t, n, [e.orderID, e.sku, e.product, e.category, e.unitPrice, e.quantity])
            }, this), this.call("trackTrans", t, n)
        },
        delayLink: function(e, t) {
            var n = this;
            if (T.allowLinker() && e.hostname.match(this.settings.linkerDomains) && !P.isSubdomainOf(e.hostname, location.hostname)) {
                P.preventDefault(t);
                var i = P.settings.linkDelay || 100;
                setTimeout(function() {
                    n.call("link", e, t, [e.href])
                }, i)
            }
        },
        popupLink: function(t, n) {
            if (e._gat) {
                P.preventDefault(n);
                var i = this.settings.account,
                    a = e._gat._createTracker(i),
                    r = a._getLinkerUrl(t.href);
                e.open(r)
            }
        },
        $link: function(e, t) {
            "_blank" === e.getAttribute("target") ? this.popupLink(e, t) : this.delayLink(e, t)
        },
        $trackEvent: function(e, t) {
            var n = Array.prototype.slice.call(arguments, 2);
            if (n.length >= 4 && null != n[3]) {
                var i = parseInt(n[3], 10);
                P.isNaN(i) && (i = 1), n[3] = i
            }
            this.call("trackEvent", e, t, n)
        }
    }), P.availableTools.ga = v, P.inherit(m, P.BaseTool), P.extend(m.prototype, {
        name: "GAUniversal",
        endPLPhase: function(e) {
            var t = this.settings,
                n = t.loadOn;
            e === n && (P.notify("GAU: Initializing at " + e, 1), this.initialize(), this.flushQueue(), this.trackInitialPageView())
        },
        getTrackerName: function() {
            return this.settings.trackerSettings.name || ""
        },
        isPageCodeLoadSuppressed: function() {
            return this.settings.initTool === !1 || this._cancelToolInit === !0
        },
        initialize: function() {
            if (this.isPageCodeLoadSuppressed()) return this.initialized = !0, void P.notify("GAU: Page code not loaded (suppressed).", 1);
            var t = "ga";
            e[t] = e[t] || this.createGAObject(), e.GoogleAnalyticsObject = t, P.notify("GAU: Page code loaded.", 1), P.loadScriptOnce(this.getToolUrl());
            var n = this.settings;
            if (T.allowLinker() && n.allowLinker !== !1 ? this.createAccountForLinker() : this.createAccount(), this.executeInitCommands(), n.customInit) {
                var i = n.customInit,
                    a = i(e[t], this.getTrackerName());
                a === !1 && (this.suppressInitialPageView = !0)
            }
            this.initialized = !0
        },
        createGAObject: function() {
            var e = function() {
                e.q.push(arguments)
            };
            return e.q = [], e.l = 1 * new Date, e
        },
        createAccount: function() {
            this.create()
        },
        createAccountForLinker: function() {
            var e = {};
            T.allowLinker() && (e.allowLinker = !0), this.create(e), this.call("require", "linker"), this.call("linker:autoLink", this.autoLinkDomains(), !1, !0)
        },
        create: function(e) {
            var t = this.settings.trackerSettings;
            t = P.preprocessArguments([t], location, null, this.forceLowerCase)[0], t.trackingId = P.replace(this.settings.trackerSettings.trackingId, location), t.cookieDomain || (t.cookieDomain = T.cookieDomain()), P.extend(t, e || {}), this.call("create", t)
        },
        autoLinkDomains: function() {
            var e = location.hostname;
            return P.filter(P.settings.domainList, function(t) {
                return t !== e
            })
        },
        executeInitCommands: function() {
            var e = this.settings;
            e.initCommands && P.each(e.initCommands, function(e) {
                var t = e.splice(2, e.length - 2);
                e = e.concat(P.preprocessArguments(t, location, null, this.forceLowerCase)), this.call.apply(this, e)
            }, this)
        },
        trackInitialPageView: function() {
            this.suppressInitialPageView || this.isPageCodeLoadSuppressed() || this.call("send", "pageview")
        },
        call: function() {
            return "function" != typeof ga ? void P.notify("GA Universal function not found!", 4) : void(this.isCallSuppressed() || (arguments[0] = this.cmd(arguments[0]), this.log(P.toArray(arguments)), ga.apply(e, arguments)))
        },
        isCallSuppressed: function() {
            return this._cancelToolInit === !0
        },
        $missing$: function(e, t, n, i) {
            i = i || [], i = [e].concat(i), this.call.apply(this, i)
        },
        getToolUrl: function() {
            var e = this.settings,
                t = P.isHttps();
            return e.url ? t ? e.url.https : e.url.http : (t ? "https://ssl" : "http://www") + ".google-analytics.com/analytics.js"
        },
        cmd: function(e) {
            var t = ["send", "set", "get"],
                n = this.getTrackerName();
            return n && -1 !== P.indexOf(t, e) ? n + "." + e : e
        },
        log: function(e) {
            var t = e[0],
                n = this.getTrackerName() || "default",
                i = "GA Universal: sent command " + t + " to tracker " + n;
            if (e.length > 1) {
                P.stringify(e.slice(1));
                i += " with parameters " + P.stringify(e.slice(1))
            }
            i += ".", P.notify(i, 1)
        }
    }), P.availableTools.ga_universal = m;
    var T = {
        allowLinker: function() {
            return P.hasMultipleDomains()
        },
        cookieDomain: function() {
            var t = P.settings.domainList,
                n = P.find(t, function(t) {
                    var n = e.location.hostname;
                    return P.equalsIgnoreCase(n.slice(n.length - t.length), t)
                }),
                i = n ? "." + n : "auto";
            return i
        }
    };
    P.inherit(y, P.BaseTool), P.extend(y.prototype, {
        name: "Nielsen",
        endPLPhase: function(e) {
            switch (e) {
                case "pagetop":
                    this.initialize();
                    break;
                case "pagebottom":
                    this.enableTracking && (this.queueCommand({
                        command: "sendFirstBeacon",
                        arguments: []
                    }), this.flushQueueWhenReady())
            }
        },
        defineListeners: function() {
            this.onTabFocus = P.bind(function() {
                this.notify("Tab visible, sending view beacon when ready", 1), this.tabEverVisible = !0, this.flushQueueWhenReady()
            }, this), this.onPageLeave = P.bind(function() {
                this.notify("isHuman? : " + this.isHuman(), 1), this.isHuman() && this.sendDurationBeacon()
            }, this), this.onHumanDetectionChange = P.bind(function(e) {
                this == e.target.target && (this.human = e.target.isHuman)
            }, this)
        },
        initialize: function() {
            this.initializeTracking(), this.initializeDataProviders(), this.initializeNonHumanDetection(), this.tabEverVisible = P.visibility.isVisible(), this.tabEverVisible ? this.notify("Tab visible, sending view beacon when ready", 1) : P.bindEventOnce("tabfocus", this.onTabFocus), this.initialized = !0
        },
        initializeTracking: function() {
            this.initialized || (this.notify("Initializing tracking", 1), this.addRemovePageLeaveEvent(this.enableTracking), this.addRemoveHumanDetectionChangeEvent(this.enableTracking), this.initialized = !0)
        },
        initializeDataProviders: function() {
            var e, t = this.getAnalyticsTool();
            this.dataProvider.register(new y.DataProvider.VisitorID(P.getVisitorId())), t ? (e = new y.DataProvider.Generic("rsid", function() {
                return t.settings.account
            }), this.dataProvider.register(e)) : this.notify("Missing integration with Analytics: rsid will not be sent.")
        },
        initializeNonHumanDetection: function() {
            P.nonhumandetection ? (P.nonhumandetection.init(), this.setEnableNonHumanDetection(0 == this.settings.enableNonHumanDetection ? !1 : !0), this.settings.nonHumanDetectionDelay > 0 && this.setNonHumanDetectionDelay(1e3 * parseInt(this.settings.nonHumanDetectionDelay))) : this.notify("NHDM is not available.")
        },
        getAnalyticsTool: function() {
            return this.settings.integratesWith ? P.tools[this.settings.integratesWith] : void 0
        },
        flushQueueWhenReady: function() {
            this.enableTracking && this.tabEverVisible && P.poll(P.bind(function() {
                return this.isReadyToTrack() ? (this.flushQueue(), !0) : void 0
            }, this), 100, 20)
        },
        isReadyToTrack: function() {
            return this.tabEverVisible && this.dataProvider.isReady()
        },
        $setVars: function(e, t, n) {
            for (var i in n) {
                var a = n[i];
                "function" == typeof a && (a = a()), this.settings[i] = a
            }
            this.notify("Set variables done", 2), this.prepareContextData()
        },
        $setEnableTracking: function(e, t, n) {
            this.notify("Will" + (n ? "" : " not") + " track time on page", 1), this.enableTracking != n && (this.addRemovePageLeaveEvent(n), this.addRemoveHumanDetectionChangeEvent(n), this.enableTracking = n)
        },
        $sendFirstBeacon: function(e, t, n) {
            this.sendViewBeacon()
        },
        setEnableNonHumanDetection: function(e) {
            e ? P.nonhumandetection.register(this) : P.nonhumandetection.unregister(this)
        },
        setNonHumanDetectionDelay: function(e) {
            P.nonhumandetection.register(this, e)
        },
        addRemovePageLeaveEvent: function(e) {
            this.notify((e ? "Attach onto" : "Detach from") + " page leave event", 1);
            var t = 0 == e ? "unbindEvent" : "bindEvent";
            P[t]("leave", this.onPageLeave)
        },
        addRemoveHumanDetectionChangeEvent: function(e) {
            this.notify((e ? "Attach onto" : "Detach from") + " human detection change event", 1);
            var t = 0 == e ? "unbindEvent" : "bindEvent";
            P[t]("humandetection.change", this.onHumanDetectionChange)
        },
        sendViewBeacon: function() {
            this.notify("Tracked page view.", 1), this.sendBeaconWith()
        },
        sendDurationBeacon: function() {
            if (!P.timetracking || "function" != typeof P.timetracking.timeOnPage || null == P.timetracking.timeOnPage()) return void this.notify("Could not track close due missing time on page", 5);
            this.notify("Tracked close", 1), this.sendBeaconWith({
                timeOnPage: Math.round(P.timetracking.timeOnPage() / 1e3),
                duration: "D",
                timer: "timer"
            });
            var e, t = "";
            for (e = 0; e < this.magicConst; e++) t += "0"
        },
        sendBeaconWith: function(e) {
            this.enableTracking && this[this.beaconMethod].call(this, this.prepareUrl(e))
        },
        plainBeacon: function(e) {
            var t = new Image;
            t.src = e, t.width = 1, t.height = 1, t.alt = ""
        },
        navigatorSendBeacon: function(e) {
            navigator.sendBeacon(e)
        },
        prepareUrl: function(e) {
            var t = this.settings;
            return P.extend(t, this.dataProvider.provide()), P.extend(t, e), this.preparePrefix(this.settings.collectionServer) + this.adapt.convertToURI(this.adapt.toNielsen(this.substituteVariables(t)))
        },
        preparePrefix: function(e) {
            return "//" + encodeURIComponent(e) + ".imrworldwide.com/cgi-bin/gn?"
        },
        substituteVariables: function(e) {
            var t = {};
            for (var n in e) e.hasOwnProperty(n) && (t[n] = P.replace(e[n]));
            return t
        },
        prepareContextData: function() {
            if (!this.getAnalyticsTool()) return void this.notify("Adobe Analytics missing.");
            var e = this.settings;
            e.sdkVersion = _satellite.publishDate, this.getAnalyticsTool().$setVars(null, null, {
                contextData: this.adapt.toAnalytics(this.substituteVariables(e))
            })
        },
        isHuman: function() {
            return this.human
        },
        onTabFocus: function() {},
        onPageLeave: function() {},
        onHumanDetectionChange: function() {},
        notify: function(e, t) {
            P.notify(this.logPrefix + e, t)
        },
        beaconMethod: "plainBeacon",
        adapt: null,
        enableTracking: !1,
        logPrefix: "Nielsen: ",
        tabEverVisible: !1,
        human: !0,
        magicConst: 2e6
    }), y.DataProvider = {}, y.DataProvider.Generic = function(e, t) {
        this.key = e, this.valueFn = t
    }, P.extend(y.DataProvider.Generic.prototype, {
        isReady: function() {
            return !0
        },
        getValue: function() {
            return this.valueFn()
        },
        provide: function() {
            this.isReady() || y.prototype.notify("Not yet ready to provide value for: " + this.key, 5);
            var e = {};
            return e[this.key] = this.getValue(), e
        }
    }), y.DataProvider.VisitorID = function(e, t, n) {
        this.key = t || "uuid", this.visitorInstance = e, this.visitorInstance && (this.visitorId = e.getMarketingCloudVisitorID([this, this._visitorIdCallback])), this.fallbackProvider = n || new y.UUID
    }, P.inherit(y.DataProvider.VisitorID, y.DataProvider.Generic), P.extend(y.DataProvider.VisitorID.prototype, {
        isReady: function() {
            return null === this.visitorInstance ? !0 : !!this.visitorId
        },
        getValue: function() {
            return this.visitorId || this.fallbackProvider.get()
        },
        _visitorIdCallback: function(e) {
            this.visitorId = e
        }
    }), y.DataProvider.Aggregate = function() {
        this.providers = [];
        for (var e = 0; e < arguments.length; e++) this.register(arguments[e])
    }, P.extend(y.DataProvider.Aggregate.prototype, {
        register: function(e) {
            this.providers.push(e)
        },
        isReady: function() {
            return P.every(this.providers, function(e) {
                return e.isReady()
            })
        },
        provide: function() {
            var e = {};
            return P.each(this.providers, function(t) {
                P.extend(e, t.provide())
            }), e
        }
    }), y.UUID = function() {}, P.extend(y.UUID.prototype, {
        generate: function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                var t = 16 * Math.random() | 0,
                    n = "x" == e ? t : 3 & t | 8;
                return n.toString(16)
            })
        },
        get: function() {
            var e = P.readCookie(this.key("uuid"));
            return e ? e : (e = this.generate(), P.setCookie(this.key("uuid"), e), e)
        },
        key: function(e) {
            return "_dtm_nielsen_" + e
        }
    }), y.DataAdapters = function() {}, P.extend(y.DataAdapters.prototype, {
        toNielsen: function(e) {
            var t = (new Date).getTime(),
                i = {
                    c6: "vc,",
                    c13: "asid,",
                    c15: "apn,",
                    c27: "cln,",
                    c32: "segA,",
                    c33: "segB,",
                    c34: "segC,",
                    c35: "adrsid,",
                    c29: "plid,",
                    c30: "bldv,",
                    c40: "adbid,"
                },
                a = {
                    ci: e.clientId,
                    c6: e.vcid,
                    c13: e.appId,
                    c15: e.appName,
                    prv: 1,
                    forward: 0,
                    ad: 0,
                    cr: e.duration || "V",
                    rt: "text",
                    st: "dcr",
                    prd: "dcr",
                    r: t,
                    at: e.timer || "view",
                    c16: e.sdkVersion,
                    c27: e.timeOnPage || 0,
                    c40: e.uuid,
                    c35: e.rsid,
                    ti: t,
                    sup: 0,
                    c32: e.segmentA,
                    c33: e.segmentB,
                    c34: e.segmentC,
                    asn: e.assetName,
                    c29: e.playerID,
                    c30: e.buildVersion
                };
            for (key in a)
                if (a[key] !== n && null != a[key] && a[key] !== n && null != a && "" != a) {
                    var r = encodeURIComponent(a[key]);
                    i.hasOwnProperty(key) && r && (r = i[key] + r), a[key] = r
                }
            return this.filterObject(a)
        },
        toAnalytics: function(e) {
            return this.filterObject({
                "a.nielsen.clientid": e.clientId,
                "a.nielsen.vcid": e.vcid,
                "a.nielsen.appid": e.appId,
                "a.nielsen.appname": e.appName,
                "a.nielsen.accmethod": "0",
                "a.nielsen.ctype": "text",
                "a.nielsen.sega": e.segmentA,
                "a.nielsen.segb": e.segmentB,
                "a.nielsen.segc": e.segmentC,
                "a.nielsen.asset": e.assetName
            })
        },
        convertToURI: function(e) {
            if (P.isObject(e) === !1) return "";
            var t = [];
            for (var n in e) e.hasOwnProperty(n) && t.push(n + "=" + e[n]);
            return t.join("&")
        },
        filterObject: function(e) {
            for (var t in e) !e.hasOwnProperty(t) || null != e[t] && e[t] !== n || delete e[t];
            return e
        }
    }), P.availableTools.nielsen = y, P.inherit(b, P.BaseTool), P.extend(b.prototype, {
        name: "SC",
        endPLPhase: function(e) {
            var t = this.settings.loadOn;
            e === t && this.initialize(e)
        },
        initialize: function(t) {
            if (!this._cancelToolInit)
                if (this.settings.initVars = this.substituteVariables(this.settings.initVars, {
                        type: t
                    }), this.settings.initTool !== !1) {
                    var n = this.settings.sCodeURL || P.basePath() + "s_code.js";
                    "object" == typeof n && (n = "https:" === e.location.protocol ? n.https : n.http), n.match(/^https?:/) || (n = P.basePath() + n), this.settings.initVars && this.$setVars(null, null, this.settings.initVars), P.loadScript(n, P.bind(this.onSCodeLoaded, this)), this.initializing = !0
                } else this.initializing = !0, this.pollForSC()
        },
        getS: function(t, n) {
            var i = n && n.hostname || e.location.hostname,
                a = this.concatWithToolVarBindings(n && n.setVars || this.varBindings),
                r = n && n.addEvent || this.events,
                s = this.getAccount(i),
                o = e.s_gi;
            if (!o) return null;
            if (this.isValidSCInstance(t) || (t = null), !s && !t) return P.notify("Adobe Analytics: tracker not initialized because account was not found", 1), null;
            var t = t || o(s),
                c = "D" + P.appVersion;
            "undefined" != typeof t.tagContainerMarker ? t.tagContainerMarker = c : "string" == typeof t.version && t.version.substring(t.version.length - 5) !== "-" + c && (t.version += "-" + c), t.sa && this.settings.skipSetAccount !== !0 && this.settings.initTool !== !1 && t.sa(this.settings.account), this.applyVarBindingsOnTracker(t, a), r.length > 0 && (t.events = r.join(","));
            var l = P.getVisitorId();
            return l && (t.visitor = P.getVisitorId()), t
        },
        onSCodeLoaded: function(e) {
            this.initialized = !0, this.initializing = !1;
            var t = ["Adobe Analytics: loaded", e ? " (manual)" : "", "."];
            P.notify(t.join(""), 1), P.fireEvent(this.id + ".load", this.getS()), this.loadModules(), e || (this.flushQueueExceptTrackLink(), this.sendBeacon()), this.flushQueue()
        },
        getAccount: function(t) {
            return e.s_account ? e.s_account : t && this.settings.accountByHost ? this.settings.accountByHost[t] || this.settings.account : this.settings.account
        },
        getTrackingServer: function() {
            var t = this,
                n = t.getS();
            if (n) {
                if (n.ssl && n.trackingServerSecure) return n.trackingServerSecure;
                if (n.trackingServer) return n.trackingServer
            }
            var i = t.getAccount(e.location.hostname);
            if (!i) return null;
            var a, r, s, o = "",
                c = n && n.dc;
            return a = i, r = a.indexOf(","), r >= 0 && (a = a.gb(0, r)), a = a.replace(/[^A-Za-z0-9]/g, ""), o || (o = "2o7.net"), c = c ? ("" + c).toLowerCase() : "d1", "2o7.net" == o && ("d1" == c ? c = "112" : "d2" == c && (c = "122"), s = ""), r = a + "." + c + "." + s + o
        },
        sendBeacon: function() {
            var t = this.getS(e[this.settings.renameS || "s"]);
            return t ? this.settings.customInit && this.settings.customInit(t) === !1 ? void P.notify("Adobe Analytics: custom init suppressed beacon", 1) : (this.settings.executeCustomPageCodeFirst && this.applyVarBindingsOnTracker(t, this.varBindings), this.executeCustomSetupFuns(t), t.t(), this.clearVarBindings(), this.clearCustomSetup(), void P.notify("Adobe Analytics: tracked page view", 1)) : void P.notify("Adobe Analytics: page code not loaded", 1)
        },
        pollForSC: function() {
            P.poll(P.bind(function() {
                return "function" == typeof e.s_gi ? (this.onSCodeLoaded(!0), !0) : void 0
            }, this))
        },
        flushQueueExceptTrackLink: function() {
            if (this.pending) {
                for (var e = [], t = 0; t < this.pending.length; t++) {
                    var n = this.pending[t],
                        i = n[0];
                    "trackLink" === i.command ? e.push(n) : this.triggerCommand.apply(this, n)
                }
                this.pending = e
            }
        },
        isQueueAvailable: function() {
            return !this.initialized
        },
        substituteVariables: function(e, t) {
            var n = {};
            for (var i in e)
                if (e.hasOwnProperty(i)) {
                    var a = e[i];
                    n[i] = P.replace(a, location, t)
                }
            return n
        },
        $setVars: function(e, t, n) {
            for (var i in n)
                if (n.hasOwnProperty(i)) {
                    var a = n[i];
                    "function" == typeof a && (a = a()), this.varBindings[i] = a
                }
            P.notify("Adobe Analytics: set variables.", 2)
        },
        $customSetup: function(e, t, n) {
            this.customSetupFuns.push(function(i) {
                n.call(e, t, i)
            })
        },
        isValidSCInstance: function(e) {
            return !!e && "function" == typeof e.t && "function" == typeof e.tl
        },
        concatWithToolVarBindings: function(e) {
            var t = this.settings.initVars || {};
            return P.map(["trackingServer", "trackingServerSecure"], function(n) {
                t[n] && !e[n] && (e[n] = t[n])
            }), e
        },
        applyVarBindingsOnTracker: function(e, t) {
            for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
        },
        clearVarBindings: function() {
            this.varBindings = {}
        },
        clearCustomSetup: function() {
            this.customSetupFuns = []
        },
        executeCustomSetupFuns: function(t) {
            P.each(this.customSetupFuns, function(n) {
                n.call(e, t)
            })
        },
        $trackLink: function(e, t, n) {
            n = n || {};
            var i = n.type,
                a = n.linkName;
            !a && e && e.nodeName && "a" === e.nodeName.toLowerCase() && (a = e.innerHTML), a || (a = "link clicked");
            var r = n && n.setVars,
                s = n && n.addEvent || [],
                o = this.getS(null, {
                    setVars: r,
                    addEvent: s
                });
            if (!o) return void P.notify("Adobe Analytics: page code not loaded", 1);
            var c = o.linkTrackVars,
                l = o.linkTrackEvents,
                u = this.definedVarNames(r);
            n && n.customSetup && n.customSetup.call(e, t, o), s.length > 0 && u.push("events"), o.products && u.push("products"), u = this.mergeTrackLinkVars(o.linkTrackVars, u), s = this.mergeTrackLinkVars(o.linkTrackEvents, s), o.linkTrackVars = this.getCustomLinkVarsList(u);
            var d = P.map(s, function(e) {
                return e.split(":")[0]
            });
            o.linkTrackEvents = this.getCustomLinkVarsList(d), o.tl(!0, i || "o", a), P.notify(["Adobe Analytics: tracked link ", "using: linkTrackVars=", P.stringify(o.linkTrackVars), "; linkTrackEvents=", P.stringify(o.linkTrackEvents)].join(""), 1), o.linkTrackVars = c, o.linkTrackEvents = l
        },
        mergeTrackLinkVars: function(e, t) {
            return e && (t = e.split(",").concat(t)), t
        },
        getCustomLinkVarsList: function(e) {
            var t = P.indexOf(e, "None");
            return t > -1 && e.length > 1 && e.splice(t, 1), e.join(",")
        },
        definedVarNames: function(e) {
            e = e || this.varBindings;
            var t = [];
            for (var n in e) e.hasOwnProperty(n) && /^(eVar[0-9]+)|(prop[0-9]+)|(hier[0-9]+)|campaign|purchaseID|channel|server|state|zip|pageType$/.test(n) && t.push(n);
            return t
        },
        $trackPageView: function(e, t, n) {
            var i = n && n.setVars,
                a = n && n.addEvent || [],
                r = this.getS(null, {
                    setVars: i,
                    addEvent: a
                });
            return r ? (r.linkTrackVars = "", r.linkTrackEvents = "", this.executeCustomSetupFuns(r), n && n.customSetup && n.customSetup.call(e, t, r), r.t(), this.clearVarBindings(), this.clearCustomSetup(), void P.notify("Adobe Analytics: tracked page view", 1)) : void P.notify("Adobe Analytics: page code not loaded", 1)
        },
        $postTransaction: function(t, n, i) {
            var a = P.data.transaction = e[i],
                r = this.varBindings,
                s = this.settings.fieldVarMapping;
            if (P.each(a.items, function(e) {
                    this.products.push(e)
                }, this), r.products = P.map(this.products, function(e) {
                    var t = [];
                    if (s && s.item)
                        for (var n in s.item)
                            if (s.item.hasOwnProperty(n)) {
                                var i = s.item[n];
                                t.push(i + "=" + e[n]), "event" === i.substring(0, 5) && this.events.push(i);
                            }
                    var a = ["", e.product, e.quantity, e.unitPrice * e.quantity];
                    return t.length > 0 && a.push(t.join("|")), a.join(";")
                }, this).join(","), s && s.transaction) {
                var o = [];
                for (var c in s.transaction)
                    if (s.transaction.hasOwnProperty(c)) {
                        var i = s.transaction[c];
                        o.push(i + "=" + a[c]), "event" === i.substring(0, 5) && this.events.push(i)
                    }
                r.products.length > 0 && (r.products += ","), r.products += ";;;;" + o.join("|")
            }
        },
        $addEvent: function(e, t) {
            for (var n = 2, i = arguments.length; i > n; n++) this.events.push(arguments[n])
        },
        $addProduct: function(e, t) {
            for (var n = 2, i = arguments.length; i > n; n++) this.products.push(arguments[n])
        },
        loadModules: function() {
            var e = this.getS();
            e && P.each(this.settings.modules || [], function(t) {
                e.loadModule(t)
            }, this)
        },
        $loadClickMapReporting: function(e, t, n) {
            var i = n.src;
            return i ? void P.loadScript(i, function() {
                P.notify("ClickMap toolbar loaded")
            }) : void P.notify("ClickMap toolbar cannot be loaded because module URL is missing")
        }
    }), P.availableTools.sc = b, P.inherit(k, P.BaseTool), P.extend(k.prototype, {
        name: "tnt",
        endPLPhase: function(e) {
            "aftertoolinit" === e && this.initialize()
        },
        initialize: function() {
            P.notify("Test & Target: Initializing", 1), this.initializeTargetPageParams(), this.load()
        },
        initializeTargetPageParams: function() {
            e.targetPageParams && this.updateTargetPageParams(this.parseTargetPageParamsResult(e.targetPageParams())), this.updateTargetPageParams(this.settings.pageParams), this.setTargetPageParamsFunction()
        },
        load: function() {
            var e = this.getMboxURL(this.settings.mboxURL);
            this.settings.initTool !== !1 ? this.settings.loadSync ? (P.loadScriptSync(e), this.onScriptLoaded()) : (P.loadScript(e, P.bind(this.onScriptLoaded, this)), this.initializing = !0) : this.initialized = !0
        },
        getMboxURL: function(t) {
            var n = t;
            return P.isObject(t) && (n = "https:" === e.location.protocol ? t.https : t.http), n.match(/^https?:/) ? n : P.basePath() + n
        },
        onScriptLoaded: function() {
            P.notify("Test & Target: loaded.", 1), this.flushQueue(), this.initialized = !0, this.initializing = !1
        },
        $addMbox: function(e, t, n) {
            var i = n.mboxGoesAround,
                a = i + "{visibility: hidden;}",
                r = this.appendStyle(a);
            i in this.styleElements || (this.styleElements[i] = r), this.initialized ? this.$addMBoxStep2(null, null, n) : this.initializing && this.queueCommand({
                command: "addMBoxStep2",
                arguments: [n]
            }, e, t)
        },
        $addMBoxStep2: function(n, i, a) {
            var r = this.generateID(),
                s = this;
            P.addEventHandler(e, "load", P.bind(function() {
                P.cssQuery(a.mboxGoesAround, function(n) {
                    var i = n[0];
                    if (i) {
                        var o = t.createElement("div");
                        o.id = r, i.parentNode.replaceChild(o, i), o.appendChild(i), e.mboxDefine(r, a.mboxName);
                        var c = [a.mboxName];
                        a.arguments && (c = c.concat(a.arguments)), e.mboxUpdate.apply(null, c), s.reappearWhenCallComesBack(i, r, a.timeout, a)
                    }
                })
            }, this)), this.lastMboxID = r
        },
        $addTargetPageParams: function(e, t, n) {
            this.updateTargetPageParams(n)
        },
        generateID: function() {
            var e = "_sdsat_mbox_" + String(Math.random()).substring(2) + "_";
            return e
        },
        appendStyle: function(e) {
            var n = t.getElementsByTagName("head")[0],
                i = t.createElement("style");
            return i.type = "text/css", i.styleSheet ? i.styleSheet.cssText = e : i.appendChild(t.createTextNode(e)), n.appendChild(i), i
        },
        reappearWhenCallComesBack: function(e, t, n, i) {
            function a() {
                var e = r.styleElements[i.mboxGoesAround];
                e && (e.parentNode.removeChild(e), delete r.styleElements[i.mboxGoesAround])
            }
            var r = this;
            P.cssQuery('script[src*="omtrdc.net"]', function(e) {
                var t = e[0];
                if (t) {
                    P.scriptOnLoad(t.src, t, function() {
                        P.notify("Test & Target: request complete", 1), a(), clearTimeout(i)
                    });
                    var i = setTimeout(function() {
                        P.notify("Test & Target: bailing after " + n + "ms", 1), a()
                    }, n)
                } else P.notify("Test & Target: failed to find T&T ajax call, bailing", 1), a()
            })
        },
        updateTargetPageParams: function(e) {
            var t = {};
            for (var n in e) e.hasOwnProperty(n) && (t[P.replace(n)] = P.replace(e[n]));
            P.extend(this.targetPageParamsStore, t)
        },
        getTargetPageParams: function() {
            return this.targetPageParamsStore
        },
        setTargetPageParamsFunction: function() {
            e.targetPageParams = P.bind(this.getTargetPageParams, this)
        },
        parseTargetPageParamsResult: function(e) {
            var t = e;
            return P.isArray(e) && (e = e.join("&")), P.isString(e) && (t = P.parseQueryParams(e)), t
        }
    }), P.availableTools.tnt = k, P.extend(E.prototype, {
        getInstance: function() {
            return this.instance
        },
        initialize: function() {
            var e, t = this.settings;
            P.notify("Visitor ID: Initializing tool", 1), e = this.createInstance(t.mcOrgId, t.initVars), null !== e && (t.customerIDs && this.applyCustomerIDs(e, t.customerIDs), t.autoRequest && e.getMarketingCloudVisitorID(), this.instance = e)
        },
        createInstance: function(e, t) {
            if (!P.isString(e)) return P.notify('Visitor ID: Cannot create instance using mcOrgId: "' + e + '"', 4), null;
            P.notify('Visitor ID: Create instance using mcOrgId: "' + e + '"', 1), t = this.parseValues(t);
            var n = Visitor.getInstance(e, t);
            return P.notify("Visitor ID: Set variables: " + P.stringify(t), 1), n
        },
        applyCustomerIDs: function(e, t) {
            e.setCustomerIDs(this.parseIds(t)), P.notify("Visitor ID: Set Customer IDs: " + P.stringify(t), 1)
        },
        parseValues: function(e) {
            if (P.isObject(e) === !1) return {};
            var t = {};
            for (var n in e) e.hasOwnProperty(n) && (t[n] = P.replace(e[n]));
            return t
        },
        parseIds: function(e) {
            if (P.isObject(e) === !1) return {};
            for (var t in e) e.hasOwnProperty(t) && (e[t].id = P.replace(e[t].id), e[t].authState = Visitor.AuthState[e[t].authState]);
            return e
        }
    }), P.availableTools.visitor_id = E, _satellite.init({
        tools: {
            eb5562e547f955336effa0f29c8e28be: {
                engine: "sc",
                loadOn: "pagebottom",
                account: "clinkdev",
                euCookie: !1,
                sCodeURL: "e2f8cd116ff52c784c699a7031ef84a705ee0e03/s-code-contents-c9b482d1d82726b7a4fa760118881bc600071821-staging.js",
                renameS: "s",
                initVars: {
                    trackingServer: "metrics.centurylink.com",
                    trackingServerSecure: "smetrics.centurylink.com",
                    pageName: "%pageName%",
                    channel: "%channel%",
                    trackInlineStats: !0,
                    trackDownloadLinks: !0,
                    linkDownloadFileTypes: "avi,css,csv,doc,docx,eps,exe,jpg,js,m4v,mov,mp3,pdf,png,ppt,pptx,rar,svg,tab,txt,vsd,vxd,wav,wma,wmv,xls,xlsx,xml,zip",
                    trackExternalLinks: !0,
                    linkInternalFilters: "ctltest.intranet,javascript:,mailto:,qintra.com,tel:",
                    linkLeaveQueryString: !1,
                    dynamicVariablePrefix: "D=",
                    eVar53: "%Category 1%",
                    eVar54: "%Category 2%",
                    eVar55: "%Category 3%",
                    eVar57: "%Category 4%",
                    prop24: "%Category 1%",
                    prop25: "%Category 2%",
                    prop26: "%Category 3%",
                    prop27: "%Category 4%"
                },
                modules: []
            }
        },
        pageLoadRules: [{
            name: "ALL - AA - navTracProc",
            trigger: [{
                engine: "sc",
                command: "setVars",
                arguments: [{
                    eVar32: "%navTrack_sourcepagename%",
                    eVar33: "%navTrack_label%",
                    eVar34: "%navTrack_region%",
                    eVar35: "%navTrack_targeturl%",
                    prop32: "%navTrack_sourcepagename%",
                    prop33: "%navTrack_label%",
                    prop34: "%navTrack_region%",
                    prop35: "%navTrack_targeturl%"
                }]
            }, {
                engine: "sc",
                command: "addEvent",
                arguments: ["event10"]
            }],
            conditions: [function(e, t) {
                return "undefined" != typeof _satellite.readCookie("nt_sourcepagename") ? !0 : void 0
            }],
            event: "pagebottom"
        }, {
            name: "ALL - AA - navTrackFunctions",
            trigger: [{
                command: "loadBlockingScript",
                arguments: [{
                    sequential: !0,
                    scripts: [{
                        src: "satellite-563cac7564746d41e0004361-staging.js",
                        data: []
                    }]
                }]
            }],
            event: "pagetop"
        }, {
            name: "ALL Global URL String Cleaning",
            trigger: [{
                command: "loadScript",
                arguments: [{
                    sequential: !1,
                    scripts: [{
                        src: "satellite-5617f38633323400170005fd-staging.js",
                        data: []
                    }]
                }]
            }],
            event: "pagetop"
        }, {
            name: "ALL-AA-navTrack-Binding",
            trigger: [{
                command: "loadScript",
                arguments: [{
                    sequential: !1,
                    scripts: [{
                        src: "satellite-561d5a843839610014000919-staging.js",
                        data: []
                    }, {
                        src: "satellite-561d5dfb37336100140000a3-staging.js",
                        data: []
                    }, {
                        src: "satellite-561d5dfb37336100140000a4-staging.js",
                        data: []
                    }]
                }]
            }],
            event: "pagebottom"
        }, {
            name: "COM - Form Complete - form1",
            trigger: [{
                engine: "sc",
                command: "setVars",
                arguments: [{
                    eVar60: "form1"
                }]
            }, {
                engine: "sc",
                command: "addEvent",
                arguments: ["event70"]
            }, {
                command: "loadBlockingScript",
                arguments: [{
                    sequential: !0,
                    scripts: [{
                        src: "satellite-56463b5364746d755a0074c0-staging.js",
                        data: []
                    }]
                }]
            }],
            scope: {
                URI: {
                    include: [/\/thankyou.html/i]
                }
            },
            conditions: [function() {
                return _satellite.textMatch(_satellite.readCookie("formstart"), "form1")
            }],
            event: "pagebottom"
        }, {
            name: "COM - Form Start - form1",
            trigger: [{
                engine: "sc",
                command: "setVars",
                arguments: [{
                    eVar60: "form1"
                }]
            }, {
                engine: "sc",
                command: "addEvent",
                arguments: ["event60"]
            }, {
                command: "loadBlockingScript",
                arguments: [{
                    sequential: !0,
                    scripts: [{
                        src: "satellite-56463b5364746d755a0074a8-staging.js",
                        data: []
                    }]
                }]
            }],
            scope: {
                URI: {
                    include: ["/formpage.html"]
                }
            },
            event: "pagebottom"
        }],
        rules: [{
            name: "navTrack Postback",
            trigger: [{
                command: "loadScript",
                arguments: [{
                    sequential: !1,
                    scripts: [{
                        src: "satellite-563cac0564746d3f7d004ff4-staging.js",
                        data: []
                    }]
                }]
            }, {
                command: "delayActivateLink"
            }],
            conditions: [function(e, t) {
                return "postback" == jQuery(this).attr("data-linkaction") ? !0 : void 0
            }],
            selector: "*",
            event: "click",
            bubbleFireIfParent: !0,
            bubbleFireIfChildFired: !0,
            bubbleStop: !1
        }, {
            name: "navTrack Route Change",
            trigger: [{
                engine: "sc",
                command: "trackPageView",
                arguments: [{}]
            }, {
                command: "loadScript",
                arguments: [{
                    sequential: !1,
                    scripts: [{
                        src: "satellite-563cac0564746d3f7d004fe2-staging.js",
                        data: []
                    }]
                }]
            }, {
                command: "delayActivateLink"
            }],
            conditions: [function(e, t) {
                return "route-change" == jQuery(this).attr("data-linkaction") ? !0 : void 0
            }],
            selector: "*",
            event: "click",
            bubbleFireIfParent: !0,
            bubbleFireIfChildFired: !0,
            bubbleStop: !1
        }],
        directCallRules: [{
            name: "clearNavTrackVars",
            trigger: [{
                command: "loadScript",
                arguments: [{
                    sequential: !1,
                    scripts: [{
                        src: "satellite-563cacef64746d3f83003f6d-staging.js",
                        data: []
                    }]
                }]
            }]
        }, {
            name: "navTrackPostback",
            trigger: [{
                engine: "sc",
                command: "trackLink",
                arguments: [{
                    setVars: {
                        eVar32: "%navTrack_sourcepagename%",
                        eVar33: "%navTrack_label%",
                        eVar34: "%navTrack_region%",
                        eVar35: "%navTrack_targeturl%",
                        prop32: "%navTrack_sourcepagename%",
                        prop33: "%navTrack_label%",
                        prop34: "%navTrack_region%",
                        prop35: "%navTrack_targeturl%"
                    },
                    addEvent: ["event10"]
                }]
            }]
        }],
        settings: {
            trackInternalLinks: !0,
            libraryName: "satelliteLib-5b7178bc3b01fb290cc4c4d66c5cfbc76b711b7a",
            isStaging: !0,
            allowGATTcalls: !1,
            downloadExtensions: /\.(?:doc|docx|eps|jpg|png|svg|xls|ppt|pptx|pdf|xlsx|tab|csv|zip|txt|vsd|vxd|xml|js|css|rar|exe|wma|mov|avi|wmv|mp3|wav|m4v)($|\&|\?)/i,
            notifications: !1,
            utilVisible: !1,
            domainList: ["centurylink.com", "intranet", "qintra.com"],
            scriptDir: "e2f8cd116ff52c784c699a7031ef84a705ee0e03/scripts/",
            tagTimeout: 3e3
        },
        data: {
            URI: t.location.pathname + t.location.search,
            browser: {},
            cartItems: [],
            revenue: "",
            host: {
                http: "assets.adobedtm.com",
                https: "assets.adobedtm.com"
            }
        },
        dataElements: {
            "Category 1": {
                customJS: function() {
                    function e() {
                        var e = $("meta[name='eBiz_evar53']").attr("value");
                        if ("undefined" != typeof e && e.length > 0) return e;
                        if ("undefined" != typeof eBiz_evar53) return eBiz_evar53;
                        if ("undefined" != typeof CQ_Analytics && CQ_Analytics.PageDataMgr.category1.length > 0) return CQ_Analytics.PageDataMgr.category1;
                        var n = t.location.pathname,
                            i = n.split("/");
                        return i.length > 2 ? i[2] : !1
                    }
                    return e()
                },
                storeLength: "pageview"
            },
            "Category 2": {
                customJS: function() {
                    function e() {
                        var e = $("meta[name='eBiz_evar54']").attr("value");
                        if ("undefined" != typeof e && e.length > 0) return e;
                        if ("undefined" != typeof eBiz_evar54) return eBiz_evar54;
                        if ("undefined" != typeof CQ_Analytics && CQ_Analytics.PageDataMgr.category2.length > 0) return CQ_Analytics.PageDataMgr.category2;
                        var n = t.location.pathname,
                            i = n.split("/");
                        return i.length > 3 ? i[3] : !1
                    }
                    return e()
                },
                storeLength: "pageview"
            },
            "Category 3": {
                customJS: function() {
                    function e() {
                        var e = $("meta[name='eBiz_evar55']").attr("value");
                        if ("undefined" != typeof e && e.length > 0) return e;
                        if ("undefined" != typeof eBiz_evar55) return eBiz_evar55;
                        if ("undefined" != typeof CQ_Analytics && CQ_Analytics.PageDataMgr.category3.length > 0) return CQ_Analytics.PageDataMgr.category3;
                        var n = t.location.pathname,
                            i = n.split("/");
                        return i.length > 4 ? i[4] : !1
                    }
                    return e()
                },
                storeLength: "pageview"
            },
            "Category 4": {
                customJS: function() {
                    function e() {
                        var e = $("meta[name='eBiz_prop27']").attr("value");
                        if ("undefined" != typeof e && e.length > 0) return e;
                        if ("undefined" != typeof eBiz_prop27) return eBiz_prop27;
                        if ("undefined" != typeof CQ_Analytics && CQ_Analytics.PageDataMgr.category4.length > 0) return CQ_Analytics.PageDataMgr.category4;
                        var n = t.location.pathname,
                            i = n.split("/");
                        return i.length > 5 ? i[5] : !1
                    }
                    return e()
                },
                storeLength: "pageview"
            },
            channel: {
                customJS: function() {
                    function e() {
                        var e = $("meta[name='eBiz_channel']").attr("value");
                        if ("undefined" != typeof e && e.length > 0) return e;
                        if ("undefined" != typeof eBiz_channel) return eBiz_channel;
                        if ("undefined" != typeof CQ_Analytics && "undefined" != typeof CQ_Analytics.PageDataMgr.channel) return CQ_Analytics.PageDataMgr.channel;
                        if ("undefined" != typeof _satellite.readCookie("dtm_channel") && _satellite.readCookie("dtm_channel").length > 0) return _satellite.readCookie("dtm_channel");
                        var n = t.location.pathname,
                            i = n.split("/");
                        return "/" == n ? "corporate" : "home" == i[1] ? "residential" : "small-business" == i[1] ? "small business" : "business" == i[1] ? "medium business" : "wholesale" == i[1] ? "wholesale" : void 0
                    }
                    return e()
                },
                storeLength: "pageview"
            },
            navTrack_label: {
                customJS: function() {
                    return "undefined" != typeof _satellite.readCookie("nt_label") ? (label = _satellite.readCookie("nt_label"), _satellite.removeCookie("nt_label"), label) : "undefined" != typeof _satellite.trackclick && "undefined" != typeof _satellite.trackclick.label ? _satellite.trackclick.label : void 0
                },
                storeLength: "pageview"
            },
            navTrack_region: {
                customJS: function() {
                    return "undefined" != typeof _satellite.readCookie("nt_region") ? (region = _satellite.readCookie("nt_region"), _satellite.removeCookie("nt_region"), region) : "undefined" != typeof _satellite.trackclick && "undefined" != typeof _satellite.trackclick.region ? _satellite.trackclick.region : void 0
                },
                storeLength: "pageview"
            },
            navTrack_sourcepagename: {
                customJS: function() {
                    return "undefined" != typeof _satellite.readCookie("nt_sourcepagename") ? (sourcepagename = _satellite.readCookie("nt_sourcepagename"), _satellite.removeCookie("nt_sourcepagename"), sourcepagename) : "undefined" != typeof _satellite.trackclick && "undefined" != typeof _satellite.trackclick.sourcepagename ? _satellite.trackclick.sourcepagename : void 0
                },
                storeLength: "pageview"
            },
            navTrack_targeturl: {
                customJS: function() {
                    return "undefined" != typeof _satellite.readCookie("nt_targeturl") ? (targeturl = _satellite.readCookie("nt_targeturl"), _satellite.removeCookie("nt_targeturl"), targeturl) : "undefined" != typeof _satellite.trackclick && "undefined" != typeof _satellite.trackclick.targeturl ? _satellite.trackclick.targeturl : void 0
                },
                storeLength: "pageview"
            },
            pageName: {
                customJS: function() {
                    function e(e) {
                        if ("defined" == typeof e) return ""; //NOSONAR
                        var t = {
                            corporate: function() {
                                return "corp"
                            },
                            residential: function() {
                                return "rsd"
                            },
                            "small-business": function() {
                                return "smb"
                            },
                            "medium-business": function() {
                                return "mb"
                            },
                            wholesale: function() {
                                return "whl"
                            }
                        };
                        return "function" != typeof t[e] ? e : t[e]()
                    }

                    function n() {
                        var n = $("meta[name='eBiz_pageName']").attr("value");
                        //alert('n '+n);
                        if ("undefined" != typeof n && n.length > 0) return n;
                        if ("undefined" != typeof eBiz_pageName) return eBiz_pageName;
                        if ("undefined" != typeof CQ_Analytics && "undefined" != typeof CQ_Analytics.PageDataMgr.pageName) return CQ_Analytics.PageDataMgr.pageName;
                        var n = "ctl|";
                        n = n + e(_satellite.getVar("channel")) + "|";
                        var a = t.location.pathname,
                            r = a.split("/");
                        if ("/" == a && (n += "home_page"), "undefined" != typeof _satellite.getVar("Category 1") && _satellite.getVar("Category 1").length > 0 && (n += _satellite.getVar("Category 1")), "undefined" != typeof _satellite.getVar("Category 2") && _satellite.getVar("Category 2").length > 0 && (n = n + "|" + _satellite.getVar("Category 2")), "undefined" != typeof _satellite.getVar("Category 3") && _satellite.getVar("Category 3").length > 0 && (n = n + "|" + _satellite.getVar("Category 3")), "undefined" != typeof _satellite.getVar("Category 4") && _satellite.getVar("Category 4").length > 0 && (n = n + "|" + _satellite.getVar("Category 4")), r.length > 6) {
                            var s = "";
                            for (i = 6; i < r.length; i++) s += r[i], i < r.length - 1 && (s += "|");
                            n = n + "|" + s
                        }
                        return n
                    }
                    return n()
                },
                storeLength: "pageview"
            }
        },
        appVersion: "6P4",
        buildDate: "2016-01-14 22:34:41 UTC",
        publishDate: "2015-10-15 18:33:26 UTC"
    })
}(window, document);