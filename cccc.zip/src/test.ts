// This file is required by karma.conf.js and loads recursively all the .spec and framework files

import 'zone.js/dist/zone-testing';
import { getTestBed } from '@angular/core/testing';
import {
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting
} from '@angular/platform-browser-dynamic/testing';

declare const require: any;
// First, initialize the Angular testing environment.
getTestBed().initTestEnvironment(
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting()
);
// Then we find all the tests.
const context = require.context('./app', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/account', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/address', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/change-responsibility', true, /\.spec\.ts$/);

//working-fine
// const context = require.context('./app/review-order', true, /\.spec\.ts$/);

// working fine
// const context = require.context('./app/common', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/ErrorModal', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/existing-products', true, /\.spec\.ts$/);

//working fine - no test case
// const context = require.context('./app/non-pay-suspend', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/nonpay-confirmation', true, /\.spec\.ts$/);

//working fine
// const context = require.context('./app/pending-order', true, /\.spec\.ts$/);

// working fine
// const context = require.context('./app/product', true, /\.spec\.ts$/);

// const context = require.context('./app/review-order', true, /\.spec\.ts$/);

// this module have some issue - disabled few files
// const context = require.context('./app/scheduling', true, /\.spec\.ts$/);

// And load the modules.
context.keys().map(context);
