import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, FormBuilder } from '@angular/forms';
import { EnterpriseAddress } from '../common/models/cart.model';
import { AppStore } from '../common/models/appstore.model';
import { AddressService } from '../common/service/address.service';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../common/service/app-state.service';
import { Logger } from '../common/logging/default-log.service';
import { GenericValues, serverErrorMessages, APIErrorLists } from '../common/models/common.model';
import { SystemErrorService } from '../common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'multipleMatchAddress',
    styleUrls: ['./multimatch.component.scss'],
    templateUrl: './multimatch.component.html'
})

export class MultimatchComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public myForm: FormGroup;
    public yellowAddresses: EnterpriseAddress[] = [];
    public searchAddresses: EnterpriseAddress[] = [];
    public yellowAddress: EnterpriseAddress;
    public finalAddress: EnterpriseAddress;
    public searchFlag: boolean;
    public orderDetails: any;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public orderRefNumber: string;
    public ruralNewAddress: boolean = false;

    constructor(
        private router: Router,
        private fb: FormBuilder,
        private addressService: AddressService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private logger: Logger,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService
    ) {
        this.searchFlag = false;
        this.appStateService.setLocationURLs();
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe(
            (data) => {
                this.yellowAddresses = data.yellowAddress;
                this.finalAddress = data.finalAddress;
                this.orderDetails = data.orderInit;
                if (data && data.orderRefNumber) {
                    this.orderRefNumber = data.orderRefNumber;
                }
            });
        this.myForm = this.fb.group({
            search: ['', []]
        });
    }

    public setFinalAddress(address) {
        this.finalAddress = address;
    }

    public ngOnInit() {
        this.logger.metrics('AddressPage - MultiMatch');
        window.scroll(0, 0);
        this.myForm.valueChanges.debounceTime(750)
            .subscribe((values) => {
                this.yellowAddress = {
                    streetAddress: '',
                    addressLine: '',
                    stateOrProvince: '',
                    city: ''
                };
                let value: string = this.myForm.value.search.toUpperCase();
                if (value && value.trim().length > 0) {
                    this.searchAddresses = [];
                    this.searchFlag = true;
                    this.yellowAddresses && this.yellowAddresses.forEach((item) => {
                        if (item.streetAddress.indexOf(value) !== -1
                            || item.city.indexOf(value) !== -1
                            || item.stateOrProvince.indexOf(value) !== -1
                            || item.postCode.indexOf(value) !== -1
                            || item.country.indexOf(value) !== -1
                            || item.subAddress.combinedDesignator.indexOf(value) !== -1) {
                            this.searchAddresses.push(item);
                        }
                    });
                } else {
                    this.searchFlag = false;
                }
            });
    }

    public selectedMatch() {
        this.loading = true;
        if (this.yellowAddress === undefined) {
            this.errorMsg = serverErrorMessages.selectNearMatch;
            window.scroll(0, 0);
            return false;
        }
        let errorResolved = false;
        this.logger.log("info", "multimatch.component.ts", "multiMatchAddressRequest", JSON.stringify(this.orderDetails ? this.orderDetails : ''));
        this.logger.startTime();
        this.addressService.checkAddress(Object.assign(this.yellowAddress, this.orderDetails),
            false)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "multimatch.component.ts", "multiMatchAddressResponse", error);
                this.logger.log("error", "multimatch.component.ts", "multiMatchAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "submitTask - checkAddress", "multimatch.component.ts", "Multimatch Address Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "multimatch.component.ts", "multiMatchAddressResponse", JSON.stringify(data));
                    this.logger.log("info", "multimatch.component.ts", "multiMatchAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let response = data;
                    if (response && response.taskName === 'Select Product') {
                        this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                        if (this.finalAddress !== null) {
                            let isSingleLine = false;
                            if(this.finalAddress && this.finalAddress.singleLine) {
                                isSingleLine = this.finalAddress.singleLine;
                            }
                            this.yellowAddress = Object.assign({},
                                this.yellowAddress, {
                                singleLine: isSingleLine // true
                            });
                        }
                        this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.yellowAddress });
                        let internetCheck;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (this.addressService.checkCategoryId(GenericValues.sData,
                            response.payload.serviceCategory) !== undefined) {
                            internetCheck = true;

                        }
                        if (this.addressService.checkCategoryId('DATA/VIDEO',
                            response.payload.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: 'DATA/VIDEO',
                                displayName: 'PRISM TV',
                                code: 'PTV',
                                tabName: 'PRISM'
                            });
                        }
                        if (this.addressService.checkCategoryId('VIDEO-DTV',
                            response.payload.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: 'VIDEO-DTV',
                                displayName: 'DIRECTV',
                                code: 'DTV',
                                tabName: 'DIRECTV'
                            });
                        }
                        if (this.addressService.checkCategoryId('VOICE-DHP',
                            response.payload.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: 'VOICE-DHP',
                                displayName: 'Digital(DHP)',
                                code: 'DHP',
                                tabName: 'DHP'
                            });
                        }
                        if (this.addressService.checkCategoryId('VOICE-HP',
                            response.payload.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: 'VOICE-HP',
                                displayName: 'Home Phone',
                                code: 'HMP',
                                tabName: 'Home Phone'
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: response.payload.serviceCategory
                        };
                        this.store.dispatch({ type: 'UPDATE_USER', payload: user });
                        if (response && response.payload && response.payload.addlOrderAttributes && Array.isArray(response.payload.addlOrderAttributes) && response.payload.addlOrderAttributes.length > 0) {
                            response.payload.addlOrderAttributes.forEach((item: any) => {
                                if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                                    item.orderAttributeGroup.forEach((item: any) => {
                                        if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                            item.orderAttributeGroupInfo.forEach((item: any) => {
                                                if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                    item.orderAttributes.forEach((item: any) => {
                                                        if (item.orderAttributeName === "serviceAddressType" && item.orderAttributeValue === "R") {
                                                            this.ruralNewAddress = true;
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                        if (!this.ruralNewAddress) {
                            this.router.navigate(['/product-offer']);
                        } else {
                            this.loading = false;
                        }
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "multimatch.component.ts", "multiMatchAddressResponse", error);
                        this.logger.log("error", "multimatch.component.ts", "multiMatchAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "multimatch.component.ts", "Multi Match Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "multimatch.component.ts", "Multi Match Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    public continueRuralAddress() {
        this.router.navigate(['/product-offer']);
    }

    public onClickYellowAddress(value: EnterpriseAddress) {
        this.yellowAddress = value;
    }
}
