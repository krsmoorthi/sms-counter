import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TypeaheadModule } from 'ngx-bootstrap';
import { CountryStateService } from '../common/service/country-state.service';
import { TextMaskService } from '../common/service/text-mask.service';
import { TrimDirectiveModule } from '../common/trim/trim-directive.module';
import { AddressComponent } from './address.component';
import { SharedModule } from '../shared/shared.module';

const routes: Routes = [
    {
        path: '',
        component: AddressComponent
    }
];

@NgModule({
    imports: [FormsModule,
        CommonModule,
        ReactiveFormsModule,
        SharedCommonModule,
        TextMaskModule,
        TypeaheadModule.forRoot(),
        TrimDirectiveModule,
        RouterModule.forChild(routes),
        SharedModule
    ],
    exports: [
        AddressComponent
    ],
    declarations: [
        AddressComponent
    ],
    providers: [
        CountryStateService,
        TextMaskService
    ]
})

export class AddressModule { }
