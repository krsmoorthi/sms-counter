import { DatePipe } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { cloneDeep } from 'lodash';
// tslint:disable-next-line:no-unused-variable
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { DeviceDetectorService } from 'ngx-device-detector';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AppConstant } from '../app.constant';
import { Logger } from '../common/logging/default-log.service';
import { AppStore } from '../common/models/appstore.model';
import { ContactInfo, EnterpriseAddress, Payload, ShoppingCart } from '../common/models/cart.model';
import { APIErrorLists, GenericValues, serverErrorMessages } from '../common/models/common.model';
import { Country } from '../common/models/country.model';
import { Order } from '../common/models/order.model';
import { State } from '../common/models/state.model';
import { User } from '../common/models/user.model';
import { AddressService } from '../common/service/address.service';
import { AppStateService } from '../common/service/app-state.service';
import { BlueMarbleService } from '../common/service/bm.service';
import { CountryStateService } from '../common/service/country-state.service';
import { DisconnectService } from '../common/service/disconnect.service';
import { PendingOrderService } from '../common/service/pending-order.service';
import { ProductService } from '../common/service/product.service';
import { SystemErrorService } from '../common/service/system-error.service';
import { TextMaskService } from '../common/service/text-mask.service';
import { Validations } from '../common/validations/validations';
import { HelperService } from '../common/service/helper.service';
import { AutoLogin, OAMData } from 'app/common/models/auto-login.model';
import { env } from '../../environments/environment';
import { mergeMap } from 'rxjs/operators';
import "rxjs/add/operator/catch";
import { ProfileService } from 'app/common/service/profile.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';

@Component({
    selector: 'address',
    styleUrls: ['./address.component.scss'],
    templateUrl: './address.component.html'
})

export class AddressComponent implements OnInit, OnDestroy {
    public pendingflow: boolean = false;
    public myForm: FormGroup;
    public myForm1: FormGroup;
    public countries: Country[];
    public states: State[];
    public phoneMask: any;
    public formShow: boolean;
    public existingServicesItem: any;
    public offerId = [];
    public responseFlag: string;
    public orderRefNumber: string;
    public processInstanceId: string;
    public taskId: string;
    public fetchRulAPIDisplayNameDate: any;
    public taskName: string;
    public yellowAddresses: EnterpriseAddress[] = [];
    public yellowAddress: EnterpriseAddress;
    public isNoBuild: boolean;
    public existingError;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public inputAddress: EnterpriseAddress;
    public addressLineShow: boolean = false;
    public existingAddressLineShow: boolean = false;
    public asyncSelected: string;
    public typeaheadLoading: boolean;
    public typeaheadNoResults: boolean;
    public addressSource: Observable<any>;
    public addressComplex: any[] = [];
    public errorMsg: string;
    public loading: boolean = false;
    public ruralNewAddress: boolean = false;
    public apiResponseError: APIErrorLists;
    public payobj: any = {};
    public inRangeResponse: any;
    public selectedRadio;
    public accountNum;
    public orderNum;
    private deviceInfo: any;
    private reEntAccno = '';
    private reEntBanno = '';
    public chatUrl: string = AppConstant.CHAT_SOS_URL;
    public rmOdrOnHoldObservable;
    public rmOdrOnHoldObservableSubscrptn: Subscription;
    public unHoldReasonRemark: string;
    public customerOrderItems: any;
    public refreshSessionObservable;
    public refreshSessionSubscription: Subscription;
    public orderSubscription: Subscription;
    public orderObservable;
    private firstName: string;
    private lastName: string;
    private ensembleId: string;
    private agentCuid: string;
    public existingDiscounts: any = {};
    private profile;
    private autoLoginData: AutoLogin;
    public customerOrderStatus: any;
    public retainObservable: Observable<any>;
    public retainSubscription: Subscription;
    public unhold: any;
    public vsflow: boolean;
    private reuseBan: boolean = false;
    public cms = env.cms;
    public changeProfileShow: boolean = false;
    public ensembleIdUpdated: boolean = false;
    public canUserUpdateProfile: boolean = false;
    public lSDate: string = '';
    public logicalSystemDateEnable: boolean = false;
    public isProd: boolean;
    public legacy: string;
    public workingServinfo: any = [];
    public isWorkingServiceAllowed: boolean = false;
    public currentFlow: any = "";
    public isWliAvailable: boolean = false;

    constructor(
        private router: Router,
        private logger: Logger,
        private fb: FormBuilder,
        private countryStateService: CountryStateService,
        private addressService: AddressService,
        public store: Store<AppStore>,
        private textMask: TextMaskService,
        private appStateService: AppStateService,
        private pendingOrderService: PendingOrderService,
        private systemErrorService: SystemErrorService,
        private deviceService: DeviceDetectorService,
        private productService: ProductService,
        public ctlHelperService: CTLHelperService,
        private disconnectService: DisconnectService,
        private bMService: BlueMarbleService,
        public helperService: HelperService,
        public profileService: ProfileService,
        private propertiesHelperService: PropertiesHelperService
    ) {
        this.orderObservable = <Observable<Order>>this.store.select('order');
        this.user = <Observable<User>>this.store.select('user');
        helperService.startNewOrderWithoutRouting("address");
        this.currentFlow = "NEWINSTALL"
        let userData;
        this.userSubscription = this.user.subscribe((data) => {
            userData = cloneDeep(data);
            this.autoLoginData = cloneDeep(data.autoLogin);
        });
        this.appStateService.setLocationURLs();
        this.formShow = true;
        this.states = this.countryStateService.getStates();
        this.countries = this.countryStateService.getCountries();
        this.phoneMask = this.textMask.getPhoneNumberMaskFormat();
        this.loading = false;
        let payload: Payload;
        if (userData) {
            if (userData.autoLogin) {
                this.firstName = userData.autoLogin && userData.autoLogin.oamData.agentFirstName;
                this.lastName = userData.autoLogin && userData.autoLogin.oamData.agentLastName;
                this.ensembleId = userData.autoLogin && userData.autoLogin.oamData.ensembleId;
                this.agentCuid = userData.autoLogin.oamData.agentCuid ? userData.autoLogin.oamData.agentCuid : '';
                if (userData.autoLogin.sfcData && userData.autoLogin.sfcData.type !== undefined) {
                    this.reuseBan = (userData.autoLogin.sfcData.type === 'ReopenBAN');
                }
            }

            if (userData.previousUrl === '/existing-products') {

                let retainVal = <Observable<any>>store.select('retain');
                let retSubscribe = retainVal.subscribe(
                    (retVal => {
                        let response = retVal.ordernum;
                        if (response) {
                            if (response.ban) {
                                this.existingAddressLineShow = true;
                                this.reEntBanno = response.ban;
                                this.selectedRadio = 'accountnum';
                                this.accountNum = response.ban;
                            }
                            else if (response.customerOrderNumber) {
                                this.existingAddressLineShow = true;
                                this.reEntAccno = response.customerOrderNumber;
                                this.selectedRadio = 'ordernum';
                                this.orderNum = response.customerOrderNumber;
                            }
                        }
                    })
                );
                retSubscribe.unsubscribe();
            }
            else {
                this.existingAddressLineShow = false;
            }
        }

        this.store.dispatch({ type: 'FLUSH_CART', payload: payload });
        let orderFlow = {
            flow: "NEWINSTALL"
        }
        this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvOpus: { taskName: '', accNo: '' } } });
        this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: '', accNo: '' } } });
        this.store.dispatch({ type: 'UPDATE_USER', payload: { isDtvOpus: true } });
        this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
        this.store.dispatch({ type: 'FREEZEPAGE', payload: false });
        this.store.dispatch({ type: 'FREEZEACC', payload: false });
        this.store.dispatch({ type: 'CC_DONE', payload: false });
        this.store.dispatch({ type: 'UPDATE_USER', payload: { oTCustomize: false, reEntrant: false } });

        if (this.profile) {
            userData.profile = this.profile;
            this.store.dispatch({ type: 'UPDATE_USER', payload: userData });
        }
        if (userData && userData.autoLogin && userData.autoLogin !== undefined && userData.autoLogin.sfcData && userData.autoLogin.sfcData.token) {
            if ((userData.autoLogin.sfcData.orderReferenceNumber && userData.autoLogin.sfcData.orderReferenceNumber !== undefined && userData.autoLogin.sfcData.orderReferenceNumber !== null && userData.autoLogin.sfcData.orderReferenceNumber.length > 0 && !this.reuseBan)) {
                this.existingAddressLineShow = true;
                this.orderNum = '';
                this.accountNum = '';
                this.errorMsg = '';
                this.myForm1 = this.myForm;

                this.myForm = this.fb.group({
                    firstName: [userData.autoLogin.sfcData.callerFirstName,
                    [Validators.required, <any>Validations.nameValidator]],
                    lastName: [userData.autoLogin.sfcData.callerLastName,
                    [Validators.required, <any>Validations.nameValidator]],
                    phoneNumber: [userData.autoLogin.sfcData.contactNumber, [Validators.required, <any>Validations.phoneValidator]],
                    number: [''],
                    accountNumber: [''],
                    orderNumber: [userData.autoLogin.sfcData.orderReferenceNumber]
                });

                this.selectedRadio = 'ordernum';
                this.orderNum = userData.autoLogin.sfcData.orderReferenceNumber;
            }
            else if ((userData.autoLogin.sfcData.accountNumber && userData.autoLogin.sfcData.accountNumber !== undefined && userData.autoLogin.sfcData.accountNumber !== null && userData.autoLogin.sfcData.accountNumber.length > 0 && !this.reuseBan)) {
                this.existingAddressLineShow = true;
                this.orderNum = '';
                this.accountNum = '';
                this.errorMsg = '';
                this.myForm1 = this.myForm;

                this.myForm = this.fb.group({
                    firstName: [userData.autoLogin.sfcData.callerFirstName,
                    [Validators.required, <any>Validations.nameValidator]],
                    lastName: [userData.autoLogin.sfcData.callerLastName,
                    [Validators.required, <any>Validations.nameValidator]],
                    phoneNumber: [userData.autoLogin.sfcData.contactNumber, [Validators.required, <any>Validations.phoneValidator]],
                    number: [''],
                    accountNumber: [userData.autoLogin.sfcData.accountNumber],
                    orderNumber: ['']
                });

                this.selectedRadio = 'accountnum';
                this.accountNum = userData.autoLogin.sfcData.accountNumber;
            }
            else if (userData.autoLogin.sfcData.serviceAddress !== undefined && userData.autoLogin.sfcData.serviceAddress !== null && userData.autoLogin.sfcData.serviceAddress.length > 0) {
                this.myForm = this.fb.group({
                    firstName: [userData.autoLogin.sfcData.callerFirstName,
                    [Validators.required, <any>Validations.nameValidator]],
                    lastName: [userData.autoLogin.sfcData.callerLastName,
                    [Validators.required, <any>Validations.nameValidator]],
                    phoneNumber: [userData.autoLogin.sfcData.contactNumber, [Validators.required,
                    <any>Validations.phoneValidator]],
                    addressLine: ['', [Validators.required, <any>Validations.addressLineValidator]],
                    singleAddressLine: [userData.autoLogin.sfcData.serviceAddress, [Validators.required, <any>Validations.addressLineValidator]],
                    singleUnitNumber: userData.autoLogin.sfcData.serviceAddressUnit ? [userData.autoLogin.sfcData.serviceAddressUnit] : [''],
                    state: ['', Validators.required],
                    city: ['', [Validators.required, <any>Validations.nameValidator]],
                    zipCode: ['', Validations.zipCodeValidator],
                    accountNumber: [this.reEntBanno],
                    orderNumber: [this.reEntAccno],
                    number: ['']
                });
                this.asyncSelected = userData.autoLogin.sfcData.serviceAddress;
                this.myForm1 = this.myForm;
            }
            this.store.dispatch({ type: 'UPDATE_USER', payload: userData });
        }
        else if (userData.firstName && userData.finalAddress) {
            if (userData.finalAddress && userData.finalAddress.singleLine) {
                this.addressLineShow = userData.finalAddress.singleLine;
            }
            let unit = userData.finalAddress.unitNumber;
            let streetAddr = userData.finalAddress.addressLine;
            if (!unit && userData.finalAddress.streetNr) {
                unit = userData.finalAddress.streetNr;
            } else if (!unit && userData.enteredUnit) {
                unit = userData.enteredUnit;
            }
            if (!streetAddr && userData.finalAddress.streetName) {
                let streetArray = new Array(userData.finalAddress.streetAddress);
                streetArray.push(userData.finalAddress.city);
                streetArray.push(userData.finalAddress.stateOrProvince);
                streetArray.push(userData.finalAddress.postCode);

                streetArray.push(userData.finalAddress.country);

                streetAddr = streetArray.join();
            }
            // In partial match screen, not handling this scenario
            if (!this.addressLineShow && streetAddr.indexOf(userData.finalAddress.postCode) === -1
                && streetAddr.indexOf(userData.finalAddress.city) === -1) {
                streetAddr = `${streetAddr}`;
            }
            this.myForm = this.fb.group({
                firstName: [userData.firstName,
                [Validators.required, <any>Validations.nameValidator]],
                lastName: [userData.lastName,
                [Validators.required, <any>Validations.nameValidator]],
                phoneNumber: [userData.phoneNumber, [Validators.required,
                <any>Validations.phoneValidator]],
                addressLine: this.addressLineShow ? [streetAddr, [Validators.required,
                <any>Validations.addressLineValidator]] : [''],
                singleAddressLine: this.addressLineShow ? [''] :
                    [streetAddr, [Validators.required, <any>Validations.addressLineValidator]],
                unitNumber: this.addressLineShow ? [unit] : [''],
                singleUnitNumber: this.addressLineShow ? [''] : [unit],
                state: this.addressLineShow ? [userData.finalAddress.stateOrProvince,
                Validators.required] : [''],
                city: this.addressLineShow ? [userData.finalAddress.city,
                [Validators.required, <any>Validations.nameValidator]] : [''],
                zipCode: this.addressLineShow ? [userData.finalAddress.postCode,
                Validations.zipCodeValidator] : [''],
                accountNumber: [this.reEntBanno],
                orderNumber: [this.reEntAccno],
                number: ['']
            });
            this.asyncSelected = streetAddr;
            this.myForm1 = this.myForm;
            this.store.dispatch({ type: 'UPDATE_USER', payload: userData });
        } else {
            if (this.existingAddressLineShow) {
                this.myForm = this.fb.group({
                    firstName: [userData.firstName, [Validators.required, <any>Validations.nameValidator]],
                    lastName: [userData.lastName, [Validators.required, <any>Validations.nameValidator]],
                    phoneNumber: [userData.phoneNumber, [Validators.required, <any>Validations.phoneValidator]],
                    singleAddressLine: this.addressLineShow ? [' '] :
                        [' ', [Validators.required, <any>Validations.addressLineValidator]],
                    addressLine: this.addressLineShow ? [' ', [Validators.required,
                    <any>Validations.addressLineValidator]] : [''],
                    singleUnitNumber: [''],
                    unitNumber: [''],
                    state: this.addressLineShow ? ['', Validators.required] : [''],
                    city: this.addressLineShow ? ['', [Validators.required,
                    <any>Validations.nameValidator]] : [''],
                    zipCode: this.addressLineShow ? ['', Validations.zipCodeValidator] : [''],
                    accountNumber: [this.reEntBanno],
                    orderNumber: [this.reEntAccno],
                    number: ['']
                });
            }
            else {
                this.myForm = this.fb.group({
                    firstName: ['', [Validators.required, <any>Validations.nameValidator]],
                    lastName: ['', [Validators.required, <any>Validations.nameValidator]],
                    phoneNumber: ['', [Validators.required, <any>Validations.phoneValidator]],
                    singleAddressLine: this.addressLineShow ? [''] :
                        ['', [Validators.required, <any>Validations.addressLineValidator]],
                    addressLine: this.addressLineShow ? ['', [Validators.required,
                    <any>Validations.addressLineValidator]] : [''],
                    singleUnitNumber: [''],
                    unitNumber: [''],
                    state: this.addressLineShow ? ['', Validators.required] : [''],
                    city: this.addressLineShow ? ['', [Validators.required,
                    <any>Validations.nameValidator]] : [''],
                    zipCode: this.addressLineShow ? ['', Validations.zipCodeValidator] : [''],
                    accountNumber: [this.reEntBanno],
                    orderNumber: [this.reEntAccno],
                    number: ['']
                });
            }
            this.myForm1 = this.myForm;
            this.store.dispatch({ type: 'UPDATE_USER', payload: userData });
        }


        this.addressSource = Observable
            .create((observer: any) => {
                // Runs on every search
                observer.next(this.asyncSelected);
            })
            .pipe(mergeMap((token: string) => this.getAddressesAsObservable(token)));
        this.isProd = (env.production) ? true : false;

    }

    public ngOnInit() {
        this.logger.metrics('AddressPage');
        let currentUser: User;
        let ensembleId: string;
        let otcData: ShoppingCart;
        otcData = {
            Otc: []
        }
        this.store.dispatch({ type: 'CREATE_CART', payload: otcData });
        var updateMetrics = false;
        this.userSubscription = this.user.subscribe(
            (data) => {
                currentUser = data;
                if (!data.ipAddress) {
                    updateMetrics = true;
                }
                else {
                    updateMetrics = false;
                }

                if (currentUser.autoLogin && currentUser.autoLogin.oamData && currentUser.autoLogin.oamData.ensembleId) {
                    ensembleId = currentUser.autoLogin.oamData.ensembleId;
                }

                if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider)
                    this.legacy = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
        );
        // this.userSubscription.unsubscribe();
        if (updateMetrics) {
            var userAgent = window.navigator.userAgent;
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile|CriOS/i.test(userAgent)) {
                currentUser.mobileIndicator = 'true';
            }
            else {
                currentUser.mobileIndicator = 'false';
            }

            this.deviceInfo = this.deviceService.getDeviceInfo();
            currentUser.browserType = this.deviceInfo.browser;
            currentUser.browserVersion = this.deviceInfo.browser_version;
            currentUser.osType = this.deviceInfo.os;
            currentUser.osVersion = this.deviceInfo.os_version;
            currentUser.eshopChannel = 'customerCare';

            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
        }

        if (currentUser.autoLogin && currentUser.autoLogin.sfcData && currentUser.autoLogin.sfcData.token) {
            this.formShow = true;
            this.onSubmit();
        }
        this.ctlHelperService.removeLocalStorageAtLandingPage();

        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user
            .subscribe((data) => {
                if (data && data.properties && data.properties.properties) {
                    for (let entry of data.properties.properties) {
                        if (entry.name === PropertyEnums.ALLOW_UPDATE_PROFILE) {
                            if (entry.value[0]) {
                                if (entry.value[0].indexOf(ensembleId) > -1) {
                                    this.canUserUpdateProfile = true;
                                }
                            }
                        }
                    }
                }
            });

    }

    // show var will be true: onclick of Show all address fields
    public showAddressLine(show: boolean) {
        this.addressLineShow = show;
        this.typeaheadNoResults = false;
        this.asyncSelected = '';
        this.myForm = this.fb.group({
            firstName: [this.myForm.value.firstName,
            [Validators.required, <any>Validations.nameValidator]],
            lastName: [this.myForm.value.lastName,
            [Validators.required, <any>Validations.nameValidator]],
            phoneNumber: [this.myForm.value.phoneNumber, [Validators.required, <any>Validations.phoneValidator]],
            singleAddressLine: this.addressLineShow ? [''] : ['',
                [Validators.required, <any>Validations.addressLineValidator]],
            singleUnitNumber: [''],
            addressLine: this.addressLineShow ? ['', [Validators.required,
            <any>Validations.addressLineValidator]] : [''],
            unitNumber: [''],
            state: this.addressLineShow ? ['', Validators.required] : [''],
            city: this.addressLineShow ? ['',
                [Validators.required, <any>Validations.nameValidator]] : [''],
            zipCode: this.addressLineShow ? ['', Validations.zipCodeValidator] : [''],
            number: [''],
            accountNumber: [this.reEntBanno],
            orderNumber: [this.reEntAccno]
        });
    }
    // called onKeyUp from single line address field
    public singleLineAPI(inputCharacter: any) {
        if (inputCharacter !== null && inputCharacter !== '' && inputCharacter.length >= 3) {
            this.addressService.getGeoamsrvcl(inputCharacter)
                .subscribe(
                    (data) => {
                        let response = data;
                        this.addressComplex = response && response.responseData && response.responseData.addresses;
                        if (response.responseCode === 200 && (this.addressComplex && (this.addressComplex.length === 0))) {
                            this.typeaheadNoResults = true;
                        } else if (response.responseCode === 200 && (this.addressComplex && (this.addressComplex.length !== 0))) {
                            this.typeaheadNoResults = false;
                            this.typeaheadLoading = false;
                        } else if (response.responseCode === 400) {
                            this.typeaheadNoResults = true;
                        }
                    },
                );
        } else {
            this.typeaheadNoResults = false;
        }
    }

    public getAddressesAsObservable(token: string): Observable<any> {
        let query = new RegExp(token, 'ig');
        return Observable.of(
            this.addressComplex.filter((addressSet: any) => {
                return query.test(addressSet.fullAddress);
            })
        );
    }

    public changeTypeaheadLoading(e: boolean): void {
        this.typeaheadLoading = e;
    }

    public changeTypeaheadNoResults(e: boolean): void {
        this.typeaheadNoResults = e;
    }

    public typeaheadOnSelect(e: TypeaheadMatch): void {
    }

    // to improve the performance, loading module asynchronously
    public loadModule() {
        let body = document.body;
        let script1 = document.createElement('script');
        let script2 = document.createElement('script');

        script1.innerHTML = '';
        script1.src = this.ctlHelperService.distURL + 'product-product-module.js';
        script1.async = true;
        script1.defer = true;
        body.appendChild(script1);

        script2.innerHTML = '';
        script2.src = this.ctlHelperService.distURL + 'default~account-account-module~account-change-account-change-account-module~account-directv-account-~874eb090.js';
        script2.async = true;
        script2.defer = true;
        body.appendChild(script2);
    }
    public WorkingServiceAllowedChk() {
        let allowedFlows = {
            NEWINSTALL: true
        };
        if (this.legacy === 'CENTURYLINK' && this.isWliAvailable) {
            this.isWorkingServiceAllowed = allowedFlows[this.currentFlow] && !this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_WLI_LQ);
        } else {
            this.isWorkingServiceAllowed = false;
        }
    }

    public onSubmit() {
        this.loading = true;
        if (!env.production && !env.aot) this.loadModule();
        let callerInfo: ContactInfo = {
            firstName: this.myForm.value.firstName,
            lastName: this.myForm.value.lastName,
            phoneNumber: this.myForm.value.phoneNumber,
        };
        if (!this.existingAddressLineShow) {
            if (this.formShow) {
                let sla = this.myForm.value.singleAddressLine;
                if (this.addressLineShow) {
                    this.inputAddress = {
                        addressLine: this.myForm.value.addressLine,
                        unitNumber: this.myForm.value.unitNumber,
                        geoAddressId: '',
                        stateOrProvince: this.myForm.value.state,
                        city: this.myForm.value.city,
                        postCode: this.myForm.value.zipCode,
                        singleLine: this.addressLineShow,
                    };
                } else {
                    this.inputAddress = {
                        addressLine: sla,
                        unitNumber: this.myForm.value.singleUnitNumber,
                        singleLine: this.addressLineShow,
                        subAddress: {
                            geoSubAddressId: '',
                        }
                    };
                }

                if (this.autoLoginData && this.autoLoginData.sfcData) {
                    this.inputAddress.geoAddressId = this.autoLoginData.sfcData.geoAddressId ? this.autoLoginData.sfcData.geoAddressId : '';
                    this.inputAddress.subAddress.geoSubAddressId = this.autoLoginData.sfcData.geoSubAddressId ? this.autoLoginData.sfcData.geoSubAddressId : '';
                }

                this.inputAddress.inRangeResponse = this.inRangeResponse;
                let errorResolved = false;
                this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
                this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(this.inputAddress));
                this.logger.startTime();
                this.addressService.checkAddress(this.inputAddress, true)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "initResponse", error);
                        this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        errorResolved = true;
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error", 'Not Applicable',
                            "submitTask - checkAddress", "address.component.ts",
                            "Address Page",
                            error);
                        return throwError(null);
                    })
                    .subscribe(
                        (data) => {
                            this.logger.endTime();
                            this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ''));
                            this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.formShow = false;
                            let response = data;
                            if (response && response.payload && response.payload.locationAttributes && response.payload.locationAttributes.isNoBuild) {
                                this.isNoBuild = response.payload.locationAttributes.isNoBuild;
                            }
                            if (response && response.taskName === 'Select Product') {
                                this.responseFlag = '';
                                if (data.orderRefNumber) {
                                    this.helperService.appendToCookie("eshop_trace", "orderReferenceNumber", data.orderRefNumber);
                                }
                                if (!this.addressLineShow) {
                                    this.inputAddress = Object.assign({},
                                        this.inputAddress, {
                                        addressLine: sla
                                    });
                                }
                                this.serviceAvailability(response);
                                this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                                if (response && response.payload && response.payload.addlOrderAttributes && Array.isArray(response.payload.addlOrderAttributes) && response.payload.addlOrderAttributes.length > 0) {
                                    response.payload.addlOrderAttributes.forEach((item: any) => {
                                        if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                                            item.orderAttributeGroup.forEach((item: any) => {
                                                if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                                    item.orderAttributeGroupInfo.forEach((item: any) => {
                                                        if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                            item.orderAttributes.forEach((item: any) => {
                                                                if (item.orderAttributeName === "serviceAddressType" && item.orderAttributeValue === "R") {
                                                                    this.ruralNewAddress = true;
                                                                }
                                                            });
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    });
                                }
                                if (response && response.payload && response.payload.workingServiceInfo &&
                                    response.payload.workingServiceInfo !== null &&
                                    Array.isArray(response.payload.workingServiceInfo) &&
                                    response.payload.workingServiceInfo.length > 0) {
                                    this.isWliAvailable = true;
                                    this.WorkingServiceAllowedChk();
                                } else {
                                    this.isWliAvailable = false;
                                }
                                if (this.isWliAvailable && this.isWorkingServiceAllowed) {
                                    this.workingServinfo = [];
                                    response.payload.workingServiceInfo.forEach((wsInfo) => {
                                        this.workingServinfo.push(wsInfo);
                                    });
                                    this.store.dispatch({ type: 'WORKING_SERVICE_INFO', payload: this.workingServinfo });
                                    this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.inputAddress });
                                    this.router.navigate(['/workingService']);
                                } else {
                                    if (!this.ruralNewAddress && !this.isWliAvailable) { this.router.navigate(['/product-offer']) };
                                }
                            } else {
                                if (response.taskName === 'Select Matching Address' && response.payload && response.payload.result !== 'Found' && response.payload.result !== 'NotFound') {
                                    let unitNumber = this.myForm.value.singleUnitNumber;
                                    if (!unitNumber) {
                                        unitNumber = this.myForm.value.unitNumber;
                                    }
                                    if (!this.addressLineShow) {
                                        this.inputAddress = Object.assign({},
                                            this.inputAddress, {
                                            addressLine: sla
                                        });
                                    }
                                    this.responseFlag = 'yellow';
                                    this.orderRefNumber = response.orderRefNumber;
                                    this.processInstanceId = response.processInstanceId;
                                    this.taskId = response.taskId;
                                    this.taskName = response.taskName;
                                    this.yellowAddresses = response.payload.nearMatchAddress;
                                    let orderDetails: any = {
                                        orderRefNumber: this.orderRefNumber,
                                        processInstanceId: this.processInstanceId,
                                        taskId: this.taskId,
                                        taskName: this.taskName
                                    };
                                    this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
                                    this.store.dispatch({
                                        type: 'FINAL_ADDRESS',
                                        payload: this.inputAddress
                                    });
                                    this.store.dispatch({ type: 'ENTERED_UNIT', payload: unitNumber });
                                    this.store.dispatch({
                                        type: 'ADD_ORDER_INIT',
                                        payload: orderDetails
                                    });
                                    this.store.dispatch({
                                        type: 'ADD_YELLOW',
                                        payload: response.payload.nearMatchAddress
                                    });
                                    this.router.navigate(['/multipleMatchAddress']);
                                } else if (response.taskName === 'Re-Submit Address' && response.payload.statusCode) {
                                    this.responseFlag = 'resubmitAddress';
                                    this.orderRefNumber = response.orderRefNumber;
                                    this.processInstanceId = response.processInstanceId;
                                    this.taskId = response.taskId;
                                    this.taskName = response.taskName;
                                    this.loading = false;
                                } else if (response.payload && response.payload.result === 'Found' && response.taskName === 'Select Matching Address') {
                                    this.responseFlag = 'AddressAddConfirmation';
                                    this.loading = false;
                                    response.InRangeFlag = this.responseFlag;
                                    this.inRangeResponse = response;
                                } else if (response.payload.result === 'NotFound' && (response.taskName === 'Select Matching Address' || response.taskName === 'Re-Submit Address')) {
                                    this.responseFlag = 'AddressNotInRange';
                                    this.loading = false;
                                    response.InRangeFlag = this.responseFlag;
                                    this.inRangeResponse = response;
                                } else if (response.payload && response.payload.result === 'Found' && response.taskName === 'Re-Submit Address') {
                                    this.responseFlag = 'AddressAddConfirmation';
                                    this.loading = false;
                                    this.inRangeResponse = response;
                                }
                                //NOBuild address should display same page as RED address, using same. 
                                else if (response.payload && (response.payload.result === 'RED - no match' && response.taskName === 'Re-Submit Address') || this.isNoBuild) {
                                    this.responseFlag = 'red';
                                    this.loading = false;
                                } else {
                                    if (response.error !== undefined) {
                                        this.errorMsg = response.error.errorMessage;
                                    } else {
                                        this.errorMsg = serverErrorMessages.serviceDown;
                                    }
                                    this.loading = false;
                                }
                            }
                        },
                        (error) => {
                            if (!errorResolved) {
                                this.logger.endTime();
                                this.logger.log("error", "address.component.ts", "initResponse", error);
                                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            }
                            this.loading = false;
                            if (error === undefined || error === null) return;
                            let currentError;
                            if (this.ctlHelperService.isJson(error)) {
                                currentError = error.json();
                                this.apiResponseError = JSON.parse(currentError);
                            } else if (typeof error === 'object' && error.errorResponse) {
                                this.apiResponseError = error;
                            }

                            if (currentError !== undefined && currentError !== null && currentError.errorResponse && currentError.errorResponse[0] !== null
                                && currentError.errorResponse[0].reasonCode !== null && currentError.errorResponse[0].reasonCode !== null
                                && currentError.errorResponse[0].reasonCode === 'BAD_REQUEST') {
                                let currentUser: User;
                                this.userSubscription = this.user.subscribe((data) => { currentUser = data; });
                                if (currentUser.autoLogin !== undefined && currentUser.autoLogin.sfcData && currentUser.autoLogin.sfcData.token) {
                                    this.myForm.controls.firstName.setValue(currentUser.autoLogin.sfcData.callerFirstName);
                                    this.myForm.controls.lastName.setValue(currentUser.autoLogin.sfcData.callerLastName);
                                    this.myForm.controls.phoneNumber.setValue(currentUser.autoLogin.sfcData.contactNumber);
                                    this.myForm.controls.singleAddressLine.setValue(currentUser.autoLogin.sfcData.serviceAddress);
                                    this.myForm.controls.singleAddressLine.setErrors({ 'autoLoginInvalidAddressLine': true });
                                    this.myForm.controls.singleAddressLine.markAsTouched();
                                }
                            }
                            else {
                                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                    this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", this.apiResponseError);
                                }
                                else {
                                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                                    this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", lAPIErrorLists);
                                }
                            }
                        });
            } else {
                this.loading = true;
                let errorResolved = false;
                this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(this.yellowAddress));
                this.logger.startTime();
                this.addressService.checkAddress(this.yellowAddress, false)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "initResponse", error);
                        this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        errorResolved = true;
                        this.loading = false;
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error", 'Not Applicable',
                            "submitTask - checkAddress", "address.component.ts",
                            "Address Page",
                            error);
                        return Observable.throwError(null);
                    })
                    .subscribe(
                        (data) => {
                            this.logger.endTime();
                            this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ""));
                            this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            let response = data && data[0];
                            if (response && response.taskName === 'Select Product') {
                                this.helperService.appendToCookie("eshop_trace", "orderReferenceNumber", data.orderRefNumber);
                                this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                                this.router.navigate(['/product-offer']);
                            }
                        },
                        (error) => {
                            if (!errorResolved) {
                                this.logger.endTime();
                                this.logger.log("error", "address.component.ts", "initResponse", error);
                                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            }
                            this.loading = false;
                            if (error === undefined || error === null) return;
                            let unexpectedError = false;
                            if (this.ctlHelperService.isJson(error)) {
                                this.apiResponseError = JSON.parse(error);
                                if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", this.apiResponseError);
                                } else unexpectedError = true;
                            } else unexpectedError = true;
                            if (unexpectedError) {
                                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                                this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", lAPIErrorLists);
                            }
                            window.scroll(0, 0);
                        });
            }
        }
        else {
            if (this.myForm.value.orderNumber) {
                let orderNum = this.myForm.value.orderNumber;
                let request;
                if (orderNum.indexOf('ORN') > -1) {
                    request = { "salesChannel": "ESHOP-Customer Care", "orderReferenceNumber": this.myForm.value.orderNumber };
                } else {
                    request = { "salesChannel": "ESHOP-Customer Care", "customerOrderNumber": this.myForm.value.orderNumber };
                }
                this.getOrderByBANOrCOR(request);
            }
            else if (this.myForm.value.accountNumber) {
                let request = { "salesChannel": "ESHOP-Customer Care", "ban": this.myForm.value.accountNumber };
                this.getOrderByBANOrCOR(request);
            } else {
                this.errorMsg = "Please Provide Account/Order Number to proceed!!!";
            }
        }

    }

    private serviceAvailability(response: any) {
        let internetCheck = false;
        let videoAvail;
        let phoneAvail: boolean = false;
        let phoneType = [];
        let videoType = [];
        if (this.addressService.checkCategoryId('DATA', response.payload.serviceCategory) !== undefined) {
            internetCheck = true;
        }
        if (this.addressService.checkCategoryId('DATA/VIDEO', response.payload.serviceCategory) !== undefined) {
            videoAvail = true;
            videoType.push({
                name: 'DATA/VIDEO',
                displayName: 'PRISM TV',
                code: 'PTV',
                tabName: 'PRISM'
            });
        }
        if (this.addressService.checkCategoryId('VIDEO-DTV', response.payload.serviceCategory) !== undefined) {
            videoAvail = true;
            videoType.push({
                name: 'VIDEO-DTV',
                displayName: 'DIRECTV',
                code: 'DTV',
                tabName: 'DIRECTV'
            });
        }
        if (this.addressService.checkCategoryId('VOICE-DHP', response.payload.serviceCategory) !== undefined) {
            phoneAvail = true;
            phoneType.push({
                name: 'VOICE-DHP',
                displayName: 'Digital(DHP)',
                code: 'DHP',
                tabName: 'DHP'
            });
        }
        if (this.addressService.checkCategoryId('VOICE-HP', response.payload.serviceCategory) !== undefined) {
            phoneAvail = true;
            phoneType.push({
                name: 'VOICE-HP',
                displayName: 'Home Phone',
                code: 'HMP',
                tabName: 'Home Phone'
            });
        }
        let user: User = {
            id: 1,
            internetCheck,
            videoCheck: videoAvail,
            phoneCheck: phoneAvail,
            phoneType: phoneType,
            videoType: videoType,
            enabledServiceList: response.payload.serviceCategory
        };
        this.store.dispatch({ type: 'UPDATE_USER', payload: user });
        this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.inputAddress });
    }

    public continueRuralAddress() {
        this.loading = true;
        this.router.navigate(['/product-offer']);
    }
    public selectedAddress() {
        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "address.component.ts", "selectedAddress", JSON.stringify(this.inRangeResponse));
        this.logger.startTime();
        this.addressService.checkAddress(this.inRangeResponse, false, undefined, this.responseFlag)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "initResponse", error);
                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "submitTask - checkAddress", "address.component.ts",
                    "Address Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    if (data && data.taskName === 'Select Product') {
                        this.serviceAvailability(data);
                        this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                        this.router.navigate(['/product-offer']);
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "initResponse", error);
                        this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public getOrderByBANOrCOR(request) {
        this.loading = true;
        this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesRequest", JSON.stringify(request));
        this.logger.startTime();
        let errorResolved = false;
        let notFoundOrder = false;
        this.pendingOrderService.getOrderSummary(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesResponse", error);
                this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                if (error && error.status === 404) {
                    this.errorMsg = "Account/Order Number does not exist!!!";
                    this.existingError = true;
                    this.formShow = false;
                    notFoundOrder = true;
                    this.ctlHelperService.setLocalStorage('getOrderByBANOrCOR-Call', true);
                }
                else {
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", 'Not Applicable',
                        "pendingSummary - getOrderSummary",
                        "address.component.ts", "Address Page",
                        error);
                    return Observable.throwError(null);
                }
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders &&
                        data.existingProductsAndServices[0].pendingOrders[0] && data.existingProductsAndServices[0].pendingOrders[0].orderDocument &&
                        data.existingProductsAndServices[0].pendingOrders[0].orderDocument.serviceAddress) {
                        this.store.dispatch({ type: 'PENDING_ADDRESS', payload: data.existingProductsAndServices[0].pendingOrders[0].orderDocument.serviceAddress });
                    }

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders && data.existingProductsAndServices[0].pendingOrders.length > 0) {
                        this.store.dispatch({ type: 'PENDING_ORDERS', payload: data.existingProductsAndServices[0].pendingOrders });
                    }

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].validateResponse) {
                        let flags = data.existingProductsAndServices[0].validateResponse[0];
                        let isStackAllowed: any;
                        let isAmendAllowed: any;
                        flags && flags.stackValidation && flags.stackValidation.forEach(a => {
                            if(a.attributeName === "stackOrderAllowed") { isStackAllowed = a.attributeValue; }
                        });
                        flags && flags.amendValidation && flags.amendValidation.forEach(a => {
                            if(a.attributeName === "amendOrderAllowed") { isAmendAllowed = a.attributeValue; }
                        });
                        this.store.dispatch({ type: 'STACK_AMEND', payload: { isStackAllowed: isStackAllowed, isAmendAllowed: isAmendAllowed } });
                    }
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].accountInfo &&
                        data.existingProductsAndServices[0].accountInfo.ban) {
                        this.getExistingDiscountsByBan(data.existingProductsAndServices[0].accountInfo.ban);
                    }

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices !== undefined && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices !== undefined && data.existingProductsAndServices[0].existingServices.existingServiceItems && data.existingProductsAndServices[0].existingServices.existingServiceItems !== undefined) {
                        this.existingServicesItem = data.existingProductsAndServices[0].existingServices.existingServiceItems;
                        this.existingServicesItem && this.existingServicesItem.map((data) => {
                            if (data.offerType !== "SUBOFFER" && data.offerType.indexOf("BILLING_COR") === -1) {
                                this.offerId.push(data.productOfferingId);
                            }
                        })
                    }

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders[0] && data.existingProductsAndServices[0].pendingOrders[0].orderDocument && data.existingProductsAndServices[0].pendingOrders[0].orderDocument.customerOrderItems.length > 0) {
                        data.existingProductsAndServices[0].pendingOrders[0].orderDocument.customerOrderItems.forEach(cusorditm => {
                            if (cusorditm.offerType !== "SUBOFFER" && cusorditm.offerType.indexOf("BILLING_COR") === -1) {
                                this.offerId.push(cusorditm.productOfferingId);
                            }
                        });
                    }
                    if (data && data.existingProductsAndServices) {
                        data.existingProductsAndServices && data.existingProductsAndServices.map((items) => {
                            items && items.pendingOrders && items.pendingOrders.map((pending) => {
                                this.customerOrderStatus = pending && pending.orderReference && pending.orderReference.customerOrderStatus;
                                if (this.customerOrderStatus && this.customerOrderStatus === "ONHOLD" && this.customerOrderStatus.toUpperCase() === "PENDING") {
                                    this.pendingflow = true;
                                }
                            })
                        })
                    }
                    if (!this.pendingflow) {

                        let offerDisplayName = {
                            "inputAttribute": [
                                {
                                    "attributeName": "productOfferId",
                                    "attributeValue": this.offerId
                                }
                            ],
                            "outputAttribute": [
                                {
                                    "attributeName": "productOfferId"
                                },
                                {
                                    "attributeName": "offerName"
                                },
                                {
                                    "attributeName": "offerDisplayName"
                                },
                                {
                                    "attributeName": "offerCategory"
                                },
                                {
                                    "attributeName": "offerType"
                                },
                                {
                                    "attributeName": "bundlePromoId"
                                }
                            ],
                            "ruleId": "75"
                        }
                        this.productService.getOfferDisplayName(offerDisplayName)
                            .subscribe(data => {
                                this.store.dispatch({ type: 'FETCH_OFFER_DISNAME', payload: data });
                            })
                    }

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].telephoneNumber) {
                        this.store.dispatch({ type: 'EXISTING_TN', payload: data.existingProductsAndServices[0].telephoneNumber });
                    }

                    if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].existingServices) {

                        let fnm = '', lnm = '', phn = '';
                        if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.accountName) {
                            fnm = data.existingProductsAndServices[0].accountInfo.accountName.firstName;
                            lnm = data.existingProductsAndServices[0].accountInfo.accountName.lastName;
                        }

                        if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.contact) {
                            phn = data.existingProductsAndServices[0].accountInfo.contact.contactNumber;
                        }

                        let callerInfo: ContactInfo = {
                            firstName: fnm,
                            lastName: lnm,
                            phoneNumber: phn,
                        };
                        let orderFlow = {
                            flow: "EXISTING"
                        }
                        this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
                        this.store.dispatch({ type: 'BAN', payload: data.existingProductsAndServices[0].accountInfo.ban });
                        this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
                        this.store.dispatch({ type: 'EXISTING_PRODUCTS', payload: data });
                        if (data && data.existingProductsAndServices) {
                            data.existingProductsAndServices && data.existingProductsAndServices.map((items) => {
                                items && items.pendingOrders && items.pendingOrders.map((pending) => {
                                    let customerOrderStatus = pending && pending.orderReference && pending.orderReference.customerOrderStatus;
                                    let orderDate;
                                    if (pending && pending.orderReference && pending.orderReference.orderDate !== null && pending.orderReference.orderDate !== undefined) {
                                        orderDate = 'NOT NULL';
                                    } else {
                                        orderDate = 'NULL';
                                    }
                                    this.compatibilityAPIcall(customerOrderStatus, orderDate, pending.orderReference.orderDate)
                                });
                            });
                        }
                        this.router.navigate(['/existing-products']);
                    }
                    else if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].pendingOrders && data.existingProductsAndServices[0].pendingOrders.length > 0) {
                        let retrieveData = data;
                        let index = data.existingProductsAndServices[0].pendingOrders.length - 1;
                        data = data.existingProductsAndServices[0].pendingOrders[index];
                        if (data.orderReference && data.orderReference.customerOrderStatus &&
                            (data.orderReference.customerOrderStatus.toUpperCase() === "PENDING" || data.orderReference.customerOrderStatus.toUpperCase() === "IN-JEOPARDY")) {
                            this.dispatchPendingData(data);
                            let existingProductsAndServices = [{
                                accountInfo: data.orderDocument.accountInfo,
                                validateResponse: retrieveData.existingProductsAndServices[0].validateResponse,
                                serviceAddress: data.orderDocument.serviceAddress,
                                pendingOrders: retrieveData.existingProductsAndServices[0].pendingOrders
                            }]
                            this.retainWaivedOtcInfo(data);
                            this.store.dispatch({ type: "CHANGE_ADDRESS_DEPOSIT", payload: data.orderDocument.serviceAddress });
                            this.store.dispatch({ type: 'EXISTING_PRODUCTS', payload: { existingProductsAndServices: existingProductsAndServices } });
                            if ((data.orderReference.lastCustomerOrderNumber === null && retrieveData.existingProductsAndServices[0].existingServices === undefined && data.orderReference && data.orderReference.customerOrderType === "NEWINSTALL" && data.orderReference.customerOrderNumber !== null) ||
                                (data.orderReference.lastCustomerOrderNumber !== null && data.orderReference.customerOrderNumber !== null &&
                                    retrieveData.existingProductsAndServices[0].existingServices === undefined && data.orderReference && data.orderReference.customerOrderType !== "NEWINSTALL")) {
                                if (data && data.orderDocument && data.orderDocument.accountInfo &&
                                    data.orderDocument.accountInfo.ban) {
                                    this.getExistingDiscountsByBan(data.orderDocument.accountInfo.ban);
                                    this.selectedGiftcards(data.orderDocument.addlOrderAttributes);
                                }
                                this.router.navigate(['/pending-order']);
                            } else {
                                let flow: any;
                                let request: any = {
                                    "orderRefNumber": "",
                                    "payload": {
                                        "sfdcAccountId": "",
                                        "salesChannel": "ESHOP-Customer Care",
                                        party: {
                                            id: this.agentCuid,
                                            firstName: this.firstName,
                                            lastName: this.lastName,
                                            type: "CSR",
                                            partyRoles: [
                                                {
                                                    partyRole: env.CSR_NAME,
                                                    sourceSystem: env.CSR_PROFILE,
                                                    id: this.agentCuid
                                                },
                                                {
                                                    partyRole: env.ENSEMBLEID,
                                                    sourceSystem: env.ENS_OPERATOR,
                                                    id: this.ensembleId
                                                }
                                            ]
                                        },
                                        "interruptAction": "UNHOLD",
                                        "reasonType": "HOLD",
                                        "reasonText": "",
                                        "reasonList": [
                                        ]
                                    }
                                };

                                this.rmOdrOnHoldObservable = <Observable<User>>this.store.select('pending');
                                let orderFlow;
                                this.rmOdrOnHoldObservableSubscrptn = this.rmOdrOnHoldObservable.subscribe((data) => {
                                    if (data && data.orderReference && data.orderReference.customerOrderType) flow = data.orderReference.customerOrderType;
                                    if (data && data.orderReference && data.orderReference.orderReferenceNumber) request.orderRefNumber = data.orderReference.orderReferenceNumber;
                                    let payload = {
                                        dueDate: data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.dates,
                                        availableAppointment: data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.appointmentInfo,
                                        apptNotes: data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.apptNotes,
                                        shippingInfo: null,
                                        cart: null
                                    }
                                    let appointmentObj = {
                                        success: true,
                                        orderRefNumber: data && data.orderRefNumber,
                                        processInstanceId: data && data.processInstanceId,
                                        taskId: data && data.taskId,
                                        taskName: data && data.taskName,
                                        payload: payload
                                    }
                                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                                    orderFlow = {
                                        flow: data.orderReference && data.orderReference.customerOrderType && (data.orderReference.customerOrderType.charAt(0).toUpperCase() + data.orderReference.customerOrderType.slice(1).toLowerCase()),
                                        type: 'fromHold'
                                    };
                                    this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });

                                    let selected = '';
                                    if (data && data.orderDocument && data.orderDocument.customerOrderItems) {
                                        for (let i = 0; i < data.orderDocument.customerOrderItems.length; i++) {
                                            let offerCategory = data.orderDocument.customerOrderItems[i].offerCategory;
                                            if (offerCategory === "INTERNET") {
                                                selected = 'Internet,';
                                            } else if (offerCategory === "VOICE-HP") {
                                                selected += 'HMPhone';
                                            } else if (offerCategory === "VOICE-DHP") {
                                                selected += 'DHPhone';
                                            } else if (offerCategory === "VIDEO-DTV") {
                                                selected += 'TV';
                                            }
                                        }
                                    }

                                    let cart: ShoppingCart;
                                    cart = {
                                        selectedService: selected
                                    };
                                    this.store.dispatch({ type: 'CREATE_CART', payload: cart });
                                });
                                let taskNameFromResponse = data.taskName;
                                if (data !== undefined) {
                                    this.store.dispatch({ type: 'HOLD_ORDER', payload: data });
                                    let cartObjToDispatch = {
                                        payload: {
                                            cart: this.customerOrderItems
                                        }
                                    }
                                    this.store.dispatch({ type: 'CREATE_CART', payload: cartObjToDispatch });
                                    let selectProduct = {
                                        taskName: 'Select Product'
                                    }
                                    this.store.dispatch({ type: 'SELECT_PRODUCT', payload: selectProduct });
                                    if (flow === 'MOVE') {
                                        this.existDataDispatch(data, orderFlow);
                                        this.router.navigate(['/move-product']);
                                    } else if (flow === 'CHANGE') {
                                        this.existDataDispatch(data, orderFlow);
                                    } else if (flow === 'BILLANDREC') {
                                        this.existDataDispatch(data, orderFlow);
                                    }
                                    else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
                                        this.vsflow = true;
                                        this.store.dispatch({ type: 'UNHOLD_VACATION_FLOW', payload: this.vsflow });
                                        let request = {
                                            ban: data.orderDocument.accountInfo.ban,
                                            salesChannel: 'ESHOP-Customer Care',
                                            customerOrderType: data.orderReference.customerOrderType,
                                            serviceAddress: data.orderDocument.serviceAddress,
                                            orderRefNumber: data.orderReference.orderReferenceNumber,
                                            sfdcAccountId: '',
                                            party: {
                                                id: this.agentCuid,
                                                firstName: this.firstName,
                                                lastName: this.lastName,
                                                type: "CSR",
                                                partyRoles: [
                                                    {
                                                        partyRole: env.CSR_NAME,
                                                        sourceSystem: env.CSR_PROFILE,
                                                        id: this.agentCuid
                                                    },
                                                    {
                                                        partyRole: env.ENSEMBLEID,
                                                        sourceSystem: env.ENS_OPERATOR,
                                                        id: this.ensembleId
                                                    }
                                                ]
                                            }
                                        }
                                        this.loading = true;

                                        let errorResolved = false;
                                        this.logger.log("info", "address.component.ts", "initVacationRequest", JSON.stringify(request));
                                        this.logger.startTime();
                                        this.bMService.initVacationCall(request)
                                            .catch((error: any) => {
                                                this.logger.endTime();
                                                this.logger.log("error", "address.component.ts", "initVacationResponse", error);
                                                this.logger.log("error", "address.component.ts", "initVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                                this.loading = false;
                                                errorResolved = true;
                                                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                                                return Observable.throwError(null);
                                            })
                                            .subscribe(
                                                (vacationData) => {
                                                    this.logger.endTime();
                                                    this.logger.log("info", "address.component.ts", "initVacationResponse", JSON.stringify(vacationData));
                                                    this.logger.log("info", "address.component.ts", "initVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                                    let vacationscheduleObj = {
                                                        orderRefNumber: vacationData.orderRefNumber,
                                                        processInstanceId: vacationData.processInstanceId,
                                                        taskId: vacationData.taskId,
                                                        taskName: vacationData.taskName,
                                                        payload: {
                                                            cart: vacationData.payload.cart
                                                        }
                                                    };

                                                    this.store.dispatch({ type: 'FINAL_VAC_CART', payload: vacationData.payload.cart });
                                                    this.store.dispatch({ type: 'VACATIONSCHEDULING', payload: vacationscheduleObj });
                                                    this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                                                    let errorResolved = false;
                                                    this.logger.log("info", "address.component.ts", "scheduleVacationRequest", JSON.stringify(vacationscheduleObj));
                                                    this.logger.startTime();
                                                    this.bMService.scheduleVacationCall(vacationscheduleObj)
                                                        .catch((error: any) => {
                                                            this.logger.endTime();
                                                            this.logger.log("error", "address.component.ts", "scheduleVacationResponse", error);
                                                            this.logger.log("error", "address.component.ts", "scheduleVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                                            errorResolved = true;
                                                            this.loading = false;
                                                            this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                                                            return Observable.throwError(null);
                                                        })
                                                        .subscribe(
                                                            (vacsdata) => {
                                                                this.logger.endTime();
                                                                this.logger.log("info", "address.component.ts", "scheduleVacationResponse", JSON.stringify(vacsdata));
                                                                this.logger.log("info", "address.component.ts", "scheduleVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                                                this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: vacsdata });
                                                                this.store.dispatch({ type: 'TASK_ID', payload: vacsdata.taskId });
                                                                this.router.navigate(['/vacation-schedule-appt-ship']);
                                                            });
                                                })
                                    }
                                    else if (flow === "DISCONNECT") {
                                        let request = {
                                            ban: data.orderDocument.accountInfo.ban,
                                            salesChannel: 'ESHOP-Customer Care',
                                            customerOrderType: 'DISCONNECT',
                                            serviceAddress: data.orderDocument.serviceAddress,
                                            orderRefNumber: data.orderReference.orderReferenceNumber,
                                            sfdcAccountId: '',
                                            party: {
                                                id: this.agentCuid,
                                                firstName: this.firstName,
                                                lastName: this.lastName,
                                                type: "CSR",
                                                partyRoles: [
                                                    {
                                                        partyRole: env.CSR_NAME,
                                                        sourceSystem: env.CSR_PROFILE,
                                                        id: this.agentCuid
                                                    },
                                                    {
                                                        partyRole: env.ENSEMBLEID,
                                                        sourceSystem: env.ENS_OPERATOR,
                                                        id: this.ensembleId
                                                    }
                                                ]
                                            }
                                        }
                                        this.loading = true;
                                        let errorResolved = false;
                                        this.logger.log("info", "address.component.ts", "initDisconnectReasonRequest", JSON.stringify(request));
                                        this.logger.startTime();
                                        this.disconnectService.initDisconnect(request)
                                            .catch((error: any) => {
                                                this.logger.endTime();
                                                this.logger.log("error", "address.component.ts", "initDisconnectReasonResponse", error);
                                                this.logger.log("error", "address.component.ts", "initDisconnectReasonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                                errorResolved = true;
                                                this.loading = false;
                                                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                                                return Observable.throwError(null);
                                            })
                                            .subscribe(
                                                (disconnectData) => {
                                                    this.logger.endTime();
                                                    this.logger.log("info", "address.component.ts", "initDisconnectReasonResponse", JSON.stringify(disconnectData));
                                                    this.logger.log("info", "address.component.ts", "initDisconnectReasonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                                    let scheduleObj = {
                                                        orderRefNumber: disconnectData.orderRefNumber,
                                                        processInstanceId: disconnectData.processInstanceId,
                                                        taskId: disconnectData.taskId,
                                                        taskName: disconnectData.taskName,
                                                        payload: disconnectData.payload
                                                    };
                                                    this.store.dispatch({ type: 'SCHEDULING', payload: scheduleObj });
                                                    let appointmentObj = {
                                                        success: true,
                                                        orderRefNumber: disconnectData.orderRefNumber,
                                                        processInstanceId: disconnectData.processInstanceId,
                                                        taskId: disconnectData.taskId,
                                                        taskName: disconnectData.taskName,
                                                        payload: disconnectData.payload
                                                    }
                                                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                                                    this.router.navigate(['/disconnect-schedule']);
                                                })
                                    } else {
                                        this.router.navigate(['/product-offer']);
                                    }
                                    if (taskNameFromResponse === "Confirm Scheduling" || taskNameFromResponse === "Schedule Disconnect Date" || taskNameFromResponse === "Checkout & Scheduling") {
                                        this.customerOrderItems = taskNameFromResponse === "Schedule Disconnect Date" ? data.payload.cart && data.payload.cart.customerOrderItems : data.payload.cart
                                        let cartObjToDispatch = {
                                            payload: {
                                                cart: this.customerOrderItems
                                            }
                                        }
                                        this.store.dispatch({ type: 'CREATE_CART', payload: cartObjToDispatch });
                                        let scheduleObj = {
                                            orderRefNumber: data.orderRefNumber,
                                            processInstanceId: data.processInstanceId,
                                            taskId: data.taskId,
                                            taskName: data.taskName,
                                            payload: data.payload
                                        };
                                        this.store.dispatch({ type: 'SCHEDULING', payload: scheduleObj });
                                        let cartObj = {
                                            orderRefNumber: data.orderRefNumber,
                                            processInstanceId: data.processInstanceId,
                                            taskId: data.taskId,
                                            taskName: data.taskName,
                                            payload: data.payload
                                        };
                                        this.store.dispatch({ type: 'ADD-ONS', payload: cartObj });
                                        let selectProduct = {
                                            taskName: 'Select Product'
                                        }
                                        this.store.dispatch({ type: 'SELECT_PRODUCT', payload: selectProduct });
                                        let appointmentObj = {
                                            success: true,
                                            orderRefNumber: data.orderRefNumber,
                                            processInstanceId: data.processInstanceId,
                                            taskId: data.taskId,
                                            taskName: data.taskName,
                                            payload: data.payload
                                        }
                                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                        this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                                        if (flow === "BILLANDREC") {
                                            this.router.navigate(['/billing-schedule-appt-ship']);
                                        } else if (flow === "DISCONNECT") {
                                            this.router.navigate(['/disconnect-schedule']);
                                        } else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
                                            this.vsflow = true;
                                            this.store.dispatch({ type: 'UNHOLD_VACATION_FLOW', payload: this.vsflow });
                                            this.router.navigate(['/vacation-schedule-appt-ship']);
                                        } else {
                                            if (flow === 'MOVE') {
                                                this.existDataDispatch(data, orderFlow);
                                                this.router.navigate(['/move-product']);
                                            } else if (flow === 'CHANGE') {
                                                this.existDataDispatch(data, orderFlow);
                                            } else if (flow === 'BILLANDREC') {
                                                this.existDataDispatch(data, orderFlow);
                                            }
                                            else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
                                                this.vsflow = true;
                                                this.store.dispatch({ type: 'UNHOLD_VACATION_FLOW', payload: this.vsflow });
                                                this.existDataDispatch(data, orderFlow);
                                                this.router.navigate(['/vacation-schedule-appt-ship']);
                                            } else {
                                                this.router.navigate(['/product-offer']);
                                            }
                                        }
                                        this.store.dispatch({ type: 'UPDATE_USER', payload: { oTCustomize: true } });
                                    }
                                }
                            }
                        } else if (data.orderReference.customerOrderStatus === "ONHOLD") {
                            let fnm = '', lnm = '', phn = '';
                            if (data.orderDocument.accountInfo && data.orderDocument.accountInfo.accountName) {
                                if (data.orderDocument.accountInfo.accountName.firstName) {
                                    fnm = data.orderDocument.accountInfo.accountName.firstName;
                                } else {
                                    data.orderDocument.accountInfo.accountName.firstName = this.myForm.value.firstName;
                                }
                                if (data.orderDocument.accountInfo.accountName.lastName) {
                                    lnm = data.orderDocument.accountInfo.accountName.lastName;
                                } else {
                                    data.orderDocument.accountInfo.accountName.lastName = this.myForm.value.lastName;
                                }
                            }

                            this.selectedDiscountsStoring(data.orderDocument.customerOrderItems);
                            this.selectedGiftcards(data.orderDocument.addlOrderAttributes);

                            if (data.orderDocument.accountInfo && data.orderDocument.accountInfo.contact.contactNumber) {
                                phn = data.orderDocument.accountInfo.contact.contactNumber;
                            } else {
                                data.orderDocument.accountInfo.contact.contactNumber = this.myForm.value.phoneNumber;
                            }
                            let flow: any;
                            let existingProductsAndServices = [{
                                accountInfo: data.orderDocument.accountInfo
                            }];
                            this.retainWaivedOtcInfo(data);
                            this.store.dispatch({ type: 'PENDING_SUMMARY', payload: data });
                            this.store.dispatch({ type: 'EXISTING_PRODUCTS', payload: { existingProductsAndServices: existingProductsAndServices } });
                            this.rmOdrOnHoldObservable = <Observable<any>>this.store.select('pending');
                            let orderFlow: any;
                            flow = data.orderReference.customerOrderType;
                            let payload: any = {
                                dueDate: data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.dates,
                                availableAppointment: data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.appointmentInfo,
                                apptNotes: data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.apptNotes,
                                shippingInfo: null,
                                cart: null
                            }
                            let appointmentObj = {
                                success: true,
                                orderRefNumber: data && data.orderRefNumber,
                                processInstanceId: data && data.processInstanceId,
                                taskId: data && data.taskId,
                                taskName: data && data.taskName,
                                payload: payload
                            }
                            this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                            this.customerOrderItems = {
                                customerOrderItems: data && data.orderDocument && data.orderDocument.customerOrderItems
                            }
                            orderFlow = {
                                flow: data && data.orderReference && data.orderReference.customerOrderType && (data.orderReference.customerOrderType.charAt(0).toUpperCase() + data.orderReference.customerOrderType.slice(1).toLowerCase()),
                                type: 'fromHold'
                            };
                            this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });

                            let selected = '';
                            if (data && data.orderDocument && data.orderDocument.customerOrderItems) {
                                for (let i = 0; i < data.orderDocument.customerOrderItems.length; i++) {
                                    let offerCategory = data.orderDocument.customerOrderItems[i].offerCategory;
                                    if (offerCategory === "INTERNET") {
                                        selected = 'Internet,';
                                    } else if (offerCategory === "VOICE-HP") {
                                        selected += 'HMPhone';
                                    } else if (offerCategory === "VOICE-DHP") {
                                        selected += 'DHPhone';
                                    } else if (offerCategory === "VIDEO-DTV") {
                                        selected += 'TV';
                                    }
                                }
                            }

                            let cart: ShoppingCart;
                            cart = {
                                selectedService: selected
                            };
                            this.store.dispatch({ type: 'CREATE_CART', payload: cart });
                            let customerAddonOfferItems = [];
                            data && data.orderDocument && data.orderDocument.customerOrderItems && data.orderDocument.customerOrderItems.map(item => {
                                if (item.offerType === 'SUBOFFER') {
                                    customerAddonOfferItems.push(item);
                                }
                            })
                            payload = {
                                cart: {
                                    customerOrderItems: data && data.orderDocument && data.orderDocument.customerOrderItems
                                },
                                customerAddonOfferItems: customerAddonOfferItems,
                                productConfiguration: data && data.orderDocument && data.orderDocument.productConfiguration,
                                addOnOffers: customerAddonOfferItems,
                                reservedTN: data && data.orderDocument && data.orderDocument.reservedTN
                            };
                            let cartObject = {
                                payload: payload,
                                selectedService: selected
                            };
                            this.store.dispatch({ type: 'CREATE_CART', payload: cartObject });
                            this.store.dispatch({ type: 'ADD-ONS', payload: cartObject });
                            let cartObjToDispatch = {
                                payload: {
                                    cart: this.customerOrderItems
                                }
                            }
                            this.store.dispatch({ type: 'CREATE_CART', payload: cartObjToDispatch });
                            this.loading = true;
                            let taskNameFromResponse;
                            let selectProduct = {
                                taskName: 'Select Product'
                            }
                            this.store.dispatch({ type: 'SELECT_PRODUCT', payload: selectProduct });
                            if (flow === 'MOVE') {
                                this.existDataDispatch(data, orderFlow);
                                this.router.navigate(['/move-product']);
                            } else if (flow === 'CHANGE') {
                                this.existDataDispatch(data, orderFlow);
                            } else if (flow === 'BILLANDREC') {
                                this.existDataDispatch(data, orderFlow);
                            }
                            else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
                                this.vsflow = true;
                                this.store.dispatch({ type: 'UNHOLD_VACATION_FLOW', payload: this.vsflow });
                                let request = {
                                    ban: data && data.orderDocument && data.orderDocument.accountInfo && data.orderDocument.accountInfo.ban,
                                    salesChannel: 'ESHOP-Customer Care',
                                    customerOrderType: data && data.orderReference && data.orderReference.customerOrderType,
                                    serviceAddress: data && data.orderDocument && data.orderDocument.serviceAddress,
                                    orderRefNumber: data && data.orderReference && data.orderReference.orderReferenceNumber,
                                    sfdcAccountId: '',
                                    party: {
                                        id: this.agentCuid,
                                        firstName: this.firstName,
                                        lastName: this.lastName,
                                        type: "CSR",
                                        partyRoles: [
                                            {
                                                partyRole: env.CSR_NAME,
                                                sourceSystem: env.CSR_PROFILE,
                                                id: this.agentCuid
                                            },
                                            {
                                                partyRole: env.ENSEMBLEID,
                                                sourceSystem: env.ENS_OPERATOR,
                                                id: this.ensembleId
                                            }
                                        ]
                                    }
                                }
                                this.loading = true;
                                let errorResolved = false;
                                this.logger.log("info", "address.component.ts", "initVacationRequest", JSON.stringify(request));
                                this.logger.startTime();
                                this.bMService.initVacationCall(request)
                                    .catch((error: any) => {
                                        this.logger.endTime();
                                        this.logger.log("error", "address.component.ts", "initVacationResponse", error);
                                        this.logger.log("error", "address.component.ts", "initVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                        this.loading = false;
                                        errorResolved = true;
                                        this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                                        return Observable.throwError(null);
                                    })
                                    .subscribe(
                                        (vacationData) => {
                                            this.logger.endTime();
                                            this.logger.log("info", "address.component.ts", "initVacationResponse", JSON.stringify(vacationData));
                                            this.logger.log("info", "address.component.ts", "initVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                            let vacationscheduleObj = {
                                                orderRefNumber: vacationData.orderRefNumber,
                                                processInstanceId: vacationData.processInstanceId,
                                                taskId: vacationData.taskId,
                                                taskName: vacationData.taskName,
                                                payload: {
                                                    cart: vacationData.payload.cart
                                                }
                                            };
                                            this.store.dispatch({ type: 'FINAL_VAC_CART', payload: vacationData.payload.cart });
                                            this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                                            this.store.dispatch({ type: 'VAATIONSCHEDULING', payload: vacationscheduleObj });
                                            this.bMService.scheduleVacationCall(vacationscheduleObj)
                                                .catch((error: any) => {
                                                    this.loading = false;
                                                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                                                    return Observable.throwError(null);
                                                })
                                                .subscribe(

                                                    (vacsdata) => {
                                                        this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: vacsdata });

                                                        this.store.dispatch({ type: 'TASK_ID', payload: vacsdata.taskId });


                                                        this.router.navigate(['/vacation-schedule-appt-ship']);
                                                    });
                                        })
                            } else if (flow === "DISCONNECT") {
                                let request = {
                                    ban: data.orderDocument.accountInfo.ban,
                                    salesChannel: 'ESHOP-Customer Care',
                                    customerOrderType: 'DISCONNECT',
                                    serviceAddress: data.orderDocument.serviceAddress,
                                    orderRefNumber: data.orderReference.orderReferenceNumber,
                                    sfdcAccountId: '',
                                    party: {
                                        id: this.agentCuid,
                                        firstName: this.firstName,
                                        lastName: this.lastName,
                                        type: "CSR",
                                        partyRoles: [
                                            {
                                                partyRole: env.CSR_NAME,
                                                sourceSystem: env.CSR_PROFILE,
                                                id: this.agentCuid
                                            },
                                            {
                                                partyRole: env.ENSEMBLEID,
                                                sourceSystem: env.ENS_OPERATOR,
                                                id: this.ensembleId
                                            }
                                        ]
                                    }
                                }
                                this.loading = true;
                                let errorResolved = false;
                                this.logger.log("info", "address.component.ts", "initDisconnectReasonResponse", JSON.stringify(request));
                                this.logger.startTime();
                                this.disconnectService.initDisconnect(request)
                                    .catch((error: any) => {
                                        this.logger.endTime();
                                        this.logger.log("error", "address.component.ts", "initDisconnectReasonResponse", error);
                                        this.logger.log("error", "address.component.ts", "initDisconnectReasonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                        errorResolved = true;
                                        this.loading = false;
                                        this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                                        return Observable.throwError(null);
                                    })
                                    .subscribe(
                                        (disconnectData) => {
                                            this.logger.endTime();
                                            this.logger.log("info", "address.component.ts", "initDisconnectReasonResponse", JSON.stringify(disconnectData));
                                            this.logger.log("info", "address.component.ts", "initDisconnectReasonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                            let scheduleObj = {
                                                orderRefNumber: disconnectData.orderRefNumber,
                                                processInstanceId: disconnectData.processInstanceId,
                                                taskId: disconnectData.taskId,
                                                taskName: disconnectData.taskName,
                                                payload: disconnectData.payload
                                            };
                                            this.store.dispatch({ type: 'SCHEDULING', payload: scheduleObj });
                                            let appointmentObj = {
                                                success: true,
                                                orderRefNumber: disconnectData.orderRefNumber,
                                                processInstanceId: disconnectData.processInstanceId,
                                                taskId: disconnectData.taskId,
                                                taskName: disconnectData.taskName,
                                                payload: disconnectData.payload
                                            }
                                            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                            this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                                            this.router.navigate(['/disconnect-schedule']);
                                        })
                            } else {
                                this.router.navigate(['/product-offer']);
                            } if (taskNameFromResponse === "Confirm Scheduling" || taskNameFromResponse === "Schedule Disconnect Date") {
                                data.payload.cart = this.customerOrderItems;
                                let cartObjToDispatch = {
                                    payload: {
                                        cart: this.customerOrderItems
                                    }
                                }
                                this.store.dispatch({ type: 'CREATE_CART', payload: cartObjToDispatch });
                                let scheduleObj = {
                                    orderRefNumber: data.orderRefNumber,
                                    processInstanceId: data.processInstanceId,
                                    taskId: data.taskId,
                                    taskName: data.taskName,
                                    payload: data.payload
                                };
                                this.store.dispatch({ type: 'SCHEDULING', payload: scheduleObj });
                                let vacationscheduleObj = {
                                    orderRefNumber: data.orderRefNumber,
                                    processInstanceId: data.processInstanceId,
                                    taskId: data.taskId,
                                    taskName: data.taskName,
                                    payload: data.payload
                                };
                                this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                                this.store.dispatch({ type: 'VACATIONSCHEDULING', payload: vacationscheduleObj });
                                let cartObj = {
                                    orderRefNumber: data.orderRefNumber,
                                    processInstanceId: data.processInstanceId,
                                    taskId: data.taskId,
                                    taskName: data.taskName,
                                    payload: data.payload
                                };
                                this.store.dispatch({ type: 'ADD-ONS', payload: cartObj });
                                let selectProduct = {
                                    taskName: 'Select Product'
                                }
                                this.store.dispatch({ type: 'SELECT_PRODUCT', payload: selectProduct });
                                let appointmentObj = {
                                    success: true,
                                    orderRefNumber: data.orderRefNumber,
                                    processInstanceId: data.processInstanceId,
                                    taskId: data.taskId,
                                    taskName: data.taskName,
                                    payload: data.payload
                                }
                                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                                if (flow === "BILLANDREC") {
                                    this.router.navigate(['/billing-schedule-appt-ship']);
                                } else if (flow === "DISCONNECT") {
                                    this.router.navigate(['/disconnect-schedule']);
                                }
                                else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
                                    this.vsflow = true;
                                    this.store.dispatch({ type: 'UNHOLD_VACATION_FLOW', payload: this.vsflow });
                                    this.router.navigate(['/vacation-schedule-appt-ship']);
                                } else {
                                    if (flow === 'MOVE') {
                                        this.existDataDispatch(data, orderFlow);
                                        this.router.navigate(['/move-product']);
                                    } else if (flow === 'CHANGE') {
                                        this.existDataDispatch(data, orderFlow);
                                    } else if (flow === 'BILLANDREC') {
                                        this.existDataDispatch(data, orderFlow);
                                    } else if (flow === 'VACATIONSUSPEND' || flow === "VACATIONRESTORE") {
                                        this.existDataDispatch(data, orderFlow);
                                        this.router.navigate(['/vacation-schedule-appt-ship']);
                                    } else {
                                        this.router.navigate(['/product-offer']);
                                    }
                                }
                                this.store.dispatch({ type: 'UPDATE_USER', payload: { oTCustomize: true } });
                            }
                            if (flow !== 'CHANGE') this.loading = false;
                        } else if (data.orderReference.customerOrderStatus === "HOLD") {
                            this.dispatchPendingData(data);
                            if (data.orderReference.customerOrderType === 'NEWINSTALL') {
                                this.router.navigate(['/pending-order']);
                            } else {
                                this.router.navigate(['/existing-products']);
                            }
                        } else {
                            this.errorMsg = "No Pending Orders found!!!";
                            this.existingError = true;
                            this.formShow = false;
                        }
                    }
                    else {
                        this.errorMsg = "Account/Order Number does not exist!!!";
                        this.existingError = true;
                        this.formShow = false;
                    }
                },
                (error) => {
                    if (!notFoundOrder) {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesResponse", error);
                            this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        if (error === undefined || error === null) return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "getOrderSummaryError", "address.component.ts", "Address Page", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "getOrderSummaryError", "address.component.ts", "Address Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    }
                });
    }

    private dispatchPendingData(data: any) {
        let fnm = '', lnm = '', phn = '';
        if (data.orderDocument.accountInfo && data.orderDocument.accountInfo.accountName) {
            if (data.orderDocument.accountInfo.accountName.firstName) {
                fnm = data.orderDocument.accountInfo.accountName.firstName;
            }
            else {
                data.orderDocument.accountInfo.accountName.firstName = this.myForm.value.firstName;
                fnm = data.orderDocument.accountInfo.accountName.firstName;
            }
            if (data.orderDocument.accountInfo.accountName.lastName) {
                lnm = data.orderDocument.accountInfo.accountName.lastName;
            }
            else {
                data.orderDocument.accountInfo.accountName.lastName = this.myForm.value.lastName;
                lnm = data.orderDocument.accountInfo.accountName.lastName;
            }
        }
        if (data.orderDocument.accountInfo && data.orderDocument.accountInfo.contact.contactNumber) {
            phn = data.orderDocument.accountInfo.contact.contactNumber;
        }
        else {
            data.orderDocument.accountInfo.contact.contactNumber = this.myForm.value.phoneNumber;
            phn = data.orderDocument.accountInfo.contact.contactNumber;
        }
        let callerInfo: ContactInfo = {
            firstName: fnm,
            lastName: lnm,
            phoneNumber: phn,
        };
        let address = data.orderDocument.serviceAddress.streetAddress + "," + data.orderDocument.serviceAddress.city + "," + data.orderDocument.serviceAddress.stateOrProvince + "," + data.orderDocument.serviceAddress.postCode;
        let finalAddress = {
            singleLine: false,
            addressLine: address
        };
        this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
        this.store.dispatch({ type: 'FINAL_ADDRESS', payload: finalAddress });
        this.store.dispatch({ type: 'PENDING_SUMMARY', payload: data });
    }

    public getExistingDiscountsByBan(ban) {
        let errorResolved = false;
        this.logger.log("info", "address.component.ts", "getDiscountsByBanRequest", JSON.stringify(ban));
        this.logger.startTime();
        this.pendingOrderService.getExistingDiscountsByBan(ban)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "getDiscountsByBanResponse", error);
                this.logger.log("error", "address.component.ts", "getDiscountsByBanSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndeRouteToSystemError("error", "Address page existing discount", "address.component.ts", "Address Page", error);
                return Observable.throwError(null);
            })
            .subscribe(discountdata => {
                this.logger.endTime();
                this.logger.log("info", "address.component.ts", "getDiscountsByBanResponse", JSON.stringify(discountdata ? discountdata : ""));
                this.logger.log("info", "address.component.ts", "getDiscountsByBanSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.existingDiscounts = discountdata;
                if (this.existingDiscounts && this.existingDiscounts.orderDiscounts && this.existingDiscounts.orderDiscounts.length > 0) {
                    for (let i = 0; i < this.existingDiscounts.orderDiscounts.length; i++) {
                        if (!this.existingDiscounts.orderDiscounts[i].latestDiscountDataFlag) {
                            this.existingDiscounts.orderDiscounts.splice(i, 1);
                        }
                    }
                    this.store.dispatch({ type: 'EXISTING_DISCOUNTS', payload: this.existingDiscounts });
                }

            },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "getDiscountsByBanResponse", error);
                        this.logger.log("error", "address.component.ts", "getDiscountsByBanSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    this.ctlHelperService.setLocalStorage('error', error);
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Address page existing discount", "address.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                });
    }

    private selectedDiscountsStoring = (customerOrderItems) => {
        let selectedDiscounts = [];
        customerOrderItems.map(item => {
            item.customerOrderSubItems.map(subitem => {
                subitem.productAttributes.map(productAttribute => {
                    if (productAttribute.isPriceable === true) {
                        if (productAttribute.discounts && productAttribute.discounts.length > 0) {
                            productAttribute.discounts.map(discount => {
                                selectedDiscounts.push(discount);
                            });
                        }
                    }
                });
            });
        });
        this.store.dispatch({ type: 'CLOSERS_PROMOS_DISCOUNTS_ONHOLD', payload: selectedDiscounts });
    }

    private selectedGiftcards = (addlOrderAttributes) => {
        let selectedgiftcards = [];
        addlOrderAttributes.map(addlOrderAttribute => {
            addlOrderAttribute.orderAttributeGroup.map(item => {
                if (item.orderAttributeGroupName === "giftCard") {
                    item.orderAttributeGroupInfo.map(orderAttribut => {
                        orderAttribut.orderAttributes.map(giftcard => {
                            if (giftcard.orderAttributeName === "giftCardOfferName") {
                                selectedgiftcards.push(giftcard.orderAttributeValue)
                            }
                        });

                    });
                }
            });
        });
        this.store.dispatch({ type: 'CLOSERS_PROMOS_GIFTCARDS_ONHOLD', payload: selectedgiftcards });

    }

    public changeExistingDiscountExpiryDateFormat_MDY() {
        if (this.existingDiscounts && this.existingDiscounts.orderDiscounts && this.existingDiscounts.orderDiscounts[0] && this.existingDiscounts.orderDiscounts[0].productDiscounts) {
            for (let i = 0; i < this.existingDiscounts.orderDiscounts[0].productDiscounts.length; i++) {

                for (let j = 0; j < this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails.length; j++) {
                    if (this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'R' && this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDuration > 1) {
                        this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountExpiryDate = new DatePipe('en-US').transform(this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountExpiryDate, 'M/dd/yyyy');
                    }

                }

            }

        }
    }

    public compatibilityAPIcall(customerOrderStatus, orderDateValue, actualOrderDate) {
        let errorResolved = false;
        this.logger.log("info", "address.component.ts", "fetchRulesRequest", JSON.stringify("true"));
        this.logger.startTime();
        this.productService.getCompatibilityRules(true)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "fetchRulesResponse", error);
                this.logger.log("error", "address.component.ts", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "SUBMIT_TASK", "address.component.ts",
                    "Address Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "address.component.ts", "fetchRulesResponse", JSON.stringify(data ? data : ""));
                this.logger.log("info", "address.component.ts", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data && data.outputAttribute) {
                    data && data.outputAttribute && data.outputAttribute.map((outputAtt) => {
                        if (outputAtt && customerOrderStatus && orderDateValue && outputAtt[1] === customerOrderStatus && outputAtt[2] === orderDateValue) {
                            let customerOrderStatusDisplayText = outputAtt[3];
                            this.store.dispatch({ type: 'DISPLAY_TEXT', payload: { displayText: customerOrderStatusDisplayText, orderDate: actualOrderDate } });
                        }
                    })
                }
            },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "fetchRulesResponse", error);
                        this.logger.log("error", "address.component.ts", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "fetchRule16ResponseError", "address.component.ts", "CustomizeService Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "fetchRule16ResponseError", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    private existDataDispatch(existingData: any, orderFlow) {
        let existingObject;
        let pendingSubscription;
        let pendingObject;
        this.refreshSessionObservable = this.store.select('pending');
        let sfdcAccountId, sfdcBillingAccountID, agentFullName, agentCuid, firstName, lastName, ensembleId;
        this.user.subscribe((data) => {
            if (data.autoLogin !== null && data.autoLogin !== undefined) {
                if (data.autoLogin.sfcData && data.autoLogin.sfcData !== undefined) {
                    sfdcAccountId = data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : '';
                    sfdcBillingAccountID = data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID : '';
                }
                if (data.autoLogin.oamData && data.autoLogin.oamData !== undefined) {
                    agentCuid = data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    agentFullName = data.autoLogin.oamData.agentFullName ? data.autoLogin.oamData.agentFullName : '';
                    ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId;
                }
            }
        })
        pendingSubscription = this.refreshSessionObservable.subscribe(pending => {
            existingObject = {
                existingProductsAndServices: [pending && pending.orderDocument]
            }
            existingObject.orderFlow = orderFlow;
        });
        if (pendingSubscription !== undefined) pendingSubscription.unsubscribe();
        let request;
        this.loading = true;
        let serviceCategories;
        let errorResolved = false;
        let banRequest = {
            "ban": existingObject.existingProductsAndServices[0].accountInfo.ban,
            "salesChannel": "ESHOP-Customer Care"
        };
        this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesRequest", JSON.stringify(banRequest));
        this.logger.startTime();
        this.pendingOrderService.getOrderSummary(banRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesResponse", error);
                this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                if (error && error.status === 404) {
                    this.errorMsg = "Account/Order Number does not exist!!!";
                    this.existingError = true;
                    this.formShow = false;
                    this.ctlHelperService.setLocalStorage('getOrderByBANOrCOR-Call', true);
                }
                else {
                    this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "pendingSummary - getOrderSummary", "address.component.ts", "Address Page", error);
                    return Observable.throwError(null);
                }
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders &&
                        data.existingProductsAndServices[0].pendingOrders !== null && data.existingProductsAndServices[0].pendingOrders.length > 0) {
                        pendingObject = data.existingProductsAndServices[0].pendingOrders[data.existingProductsAndServices[0].pendingOrders.length - 1];
                        data.existingProductsAndServices[0].accountInfo = pendingObject.orderDocument.accountInfo;
                        let flow;
                        if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders
                            && data.existingProductsAndServices[0].pendingOrders[0] && data.existingProductsAndServices[0].pendingOrders[0].orderReference
                            && data.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderType) {
                            flow = data.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderType;
                            flow = flow.charAt(0).toUpperCase() + flow.slice(1).toLowerCase();
                        }
                        orderFlow = {
                            flow: flow,
                            type: orderFlow && orderFlow.type
                        };
                        this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
                        existingData = data.existingProductsAndServices[0].pendingOrders[0];
                        if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].validateResponse) {
                            let flags = data.existingProductsAndServices[0].validateResponse[0];
                            let isStackAllowed: any;
                            let isAmendAllowed: any;
                            flags && flags.stackValidation && flags.stackValidation.map(a => {
                                if(a.attributeName === "stackOrderAllowed") { isStackAllowed = a.attributeValue; }
                            })
                            flags && flags.amendValidation && flags.amendValidation.map(a => {
                                if(a.attributeName === "amendOrderAllowed") { isAmendAllowed = a.attributeValue; }
                            })
                            this.store.dispatch({ type: 'STACK_AMEND', payload: { isStackAllowed: isStackAllowed, isAmendAllowed: isAmendAllowed } });
                        }
                        let existingProductsAndServices = [{
                            accountInfo: pendingObject.orderDocument.accountInfo,
                            validateResponse: data.existingProductsAndServices[0].validateResponse,
                            serviceAddress: pendingObject.orderDocument.serviceAddress
                        }]
                        this.store.dispatch({ type: 'EXISTING_PRODUCTS', payload: { existingProductsAndServices: existingProductsAndServices } });
                    }
                    if (orderFlow && (orderFlow.flow === "NEWINSTALL")) {
                        if (pendingObject.orderReference.customerOrderStatus.toUpperCase() === "PENDING" || pendingObject.orderReference.customerOrderStatus.toUpperCase() === "IN-JEOPARDY") {
                            this.dispatchPendingData(pendingObject);
                            this.router.navigate(['/pending-order']);
                        }
                    } else {
                        if (data && data.existingProductsAndServices && data.existingProductsAndServices[0]) {
                        }
                        this.store.dispatch({ type: 'EXISTING_PRODUCTS', payload: data });
                        if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].telephoneNumber) {
                            this.store.dispatch({ type: 'EXISTING_TN', payload: data.existingProductsAndServices[0].telephoneNumber });
                        }
                        serviceCategories = data.existingProductsAndServices[0].serviceCategory;

                        request = {
                            ban: orderFlow && (orderFlow.flow === 'Change') ? data.existingProductsAndServices[0].accountInfo.ban : banRequest.ban,
                            customerOrderType: orderFlow && (orderFlow.flow === 'Change') ? 'CHANGE' : 'BILLANDREC',
                            orderRefNumber: existingData.orderReference.orderReferenceNumber,
                            party: {
                                id: agentCuid,
                                firstName: firstName,
                                lastName: lastName,
                                type: "CSR",
                                partyRoles: [
                                    {
                                        partyRole: env.CSR_NAME,
                                        sourceSystem: env.CSR_PROFILE,
                                        id: agentCuid
                                    },
                                    {
                                        partyRole: env.ENSEMBLEID,
                                        sourceSystem: env.ENS_OPERATOR,
                                        id: ensembleId
                                    }
                                ]
                            },
                            salesChannel: "ESHOP-Customer Care",
                            serviceAddress: {
                                city: "",
                                country: "",
                                geoAddressId: "",
                                locality: "",
                                postCode: "",
                                postCodeSuffix: "",
                                source: "",
                                sourceId: "",
                                stateOrProvince: "",
                                streetAddress: "",
                                streetName: "",
                                streetNrFirst: "",
                                streetNrFirstSuffix: "",
                                streetNrLast: "",
                                streetNrLastSuffix: "",
                                streetType: "",
                                subAddress: {
                                    combinedDesignator: "",
                                    elements: {
                                        designator: "",
                                        value: ""
                                    },
                                    geoSubAddressId: "",
                                    source: "",
                                    sourceId: ""
                                }
                            },
                        }
                        if (sfdcBillingAccountID && sfdcAccountId) {
                            request.sfdcAccountId = (sfdcBillingAccountID ? sfdcBillingAccountID + ':' : '') + (sfdcAccountId ? sfdcAccountId : '');
                        }

                        if (data && data.existingProductsAndServices && data.existingProductsAndServices[0]) {
                            let internetCheck;
                            let videoAvail;
                            let phoneAvail: boolean = false;
                            let phoneType = [];
                            let videoType = [];
                            let lserviceCategory: any = [
                                {
                                    "serviceCategory": "DATA",
                                    "serviceCharacteristic": [
                                        {
                                            "name": "downSpeed",
                                            "value": "12",
                                            "uom": "Mbps"
                                        },
                                        {
                                            "name": "upSpeed",
                                            "value": "896",
                                            "uom": "Kbps"
                                        },
                                        {
                                            "name": "Technology",
                                            "value": "ADSL2+",
                                            "uom": ""
                                        },
                                        {
                                            "name": "prismSupported",
                                            "value": "false",
                                            "uom": ""
                                        },
                                        {
                                            "name": "dhpSupported",
                                            "value": "true",
                                            "uom": ""
                                        }
                                    ]
                                },
                                {
                                    "serviceCategory": "VOICE-DHP",
                                    "serviceCharacteristic": [
                                        {
                                            "name": null,
                                            "value": null,
                                            "uom": null
                                        }
                                    ]
                                },
                                {
                                    "serviceCategory": "VOICE-HP",
                                    "serviceCharacteristic": [
                                        {
                                            "name": null,
                                            "value": null,
                                            "uom": null
                                        }
                                    ]
                                },
                                {
                                    "serviceCategory": "VIDEO-DTV",
                                    "serviceCharacteristic": [
                                        {
                                            "name": null,
                                            "value": null,
                                            "uom": null
                                        }
                                    ]
                                }
                            ];
                            serviceCategories = serviceCategories ? serviceCategories : lserviceCategory;
                            if (serviceCategories !== undefined) {
                                serviceCategories.map((item) => {
                                    if (item.serviceCategory === GenericValues.sData) {
                                        internetCheck = true;
                                    }
                                    if (item.serviceCategory === 'DATA/VIDEO') {
                                        videoAvail = true;
                                        videoType.push({
                                            name: 'DATA/VIDEO',
                                            displayName: 'PRISM TV',
                                            code: 'PTV',
                                            tabName: 'PRISM'
                                        });
                                    }
                                    if (item.serviceCategory === 'VIDEO-DTV') {
                                        videoAvail = true;
                                        videoType.push({
                                            name: 'VIDEO-DTV',
                                            displayName: 'DIRECTV',
                                            code: 'DTV',
                                            tabName: 'DIRECTV'
                                        });
                                    }
                                    if (item.serviceCategory === 'VOICE-DHP') {
                                        phoneAvail = true;
                                        phoneType.push({
                                            name: 'VOICE-DHP',
                                            displayName: 'Digital(DHP)',
                                            code: 'DHP',
                                            tabName: 'DHP'
                                        });
                                    }
                                    if (item.serviceCategory === 'VOICE-HP') {
                                        phoneAvail = true;
                                        phoneType.push({
                                            name: 'VOICE-HP',
                                            displayName: 'Home Phone',
                                            code: 'HMP',
                                            tabName: 'Home Phone'
                                        });
                                    }
                                });
                            }
                            let user: User = {
                                id: 1,
                                internetCheck,
                                videoCheck: videoAvail,
                                phoneCheck: phoneAvail,
                                phoneType: phoneType,
                                videoType: videoType,
                                enabledServiceList: serviceCategories,
                                ban: banRequest.ban
                            };
                            this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
                        }
                        let errorResolved = false;
                        this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(banRequest));
                        this.logger.startTime();
                        if (orderFlow && (orderFlow.flow === 'CHANGE' || orderFlow.flow === 'Change')) {
                            this.addressService.getInitChangeCall(request)
                                .catch((error: any) => {
                                    this.logger.endTime();
                                    this.logger.log("error", "address.component.ts", "initResponse", error);
                                    this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                    errorResolved = true;
                                    this.loading = false;
                                    this.systemErrorService.logAndRouteUnexpectedError(
                                        "error", "Not Applicable",
                                        "INIT", "address.component.ts",
                                        "Existing Products Page",
                                        error);
                                    return Observable.throwError(null);
                                })
                                .subscribe(
                                    (address) => {
                                        this.logger.endTime();
                                        this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(address ? address : ""));
                                        this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                        data.orderInit = address;
                                        this.orderSubscription = this.orderObservable.subscribe(ord => {
                                            if (ord.orderRefNumber) {
                                                this.helperService.appendToCookie("eshop_trace", "orderReferenceNumber", ord.orderRefNumber);
                                                address.orderRefNumber = ord.orderRefNumber;
                                                address.processInstanceId = ord.processInstanceId;
                                                address.taskId = ord.taskId;
                                            }
                                            this.store.dispatch({ type: 'TASK_ID', payload: address.taskId });
                                            this.store.dispatch({ type: 'CHANGE_ORDER_INIT', payload: address });
                                        })
                                        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
                                        this.router.navigate(['/offer-change']);
                                    },
                                    (error) => {
                                        if (!errorResolved) {
                                            this.logger.endTime();
                                            this.logger.log("error", "address.component.ts", "initResponse", error);
                                            this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                        }
                                        this.loading = false;
                                        if (error === undefined || error === null) return;
                                        let unexpectedError = false;
                                        if (this.ctlHelperService.isJson(error)) {
                                            this.apiResponseError = JSON.parse(error);
                                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                                this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", this.apiResponseError);
                                            } else unexpectedError = true;
                                        } else unexpectedError = true;
                                        if (unexpectedError) {
                                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "address.component.ts", "Address Page", lAPIErrorLists);
                                        }
                                    });
                        } else if (existingData && existingData.orderReference && existingData.orderReference.customerOrderType === 'BILLANDREC') {
                            this.store.dispatch({ type: 'BAN', payload: banRequest.ban });
                            let changedAddress = false;
                            let serviceAddress: any;
                            if (existingData.orderDocument && existingData.orderDocument.serviceAddress) {
                                serviceAddress = existingData.orderDocument.serviceAddress;
                                if (existingData.orderDocument && existingData.orderDocument.existingServiceAddress &&
                                    existingData.orderDocument.existingServiceAddress.streetAddress !==
                                    existingData.orderDocument.serviceAddress.streetAddress) {
                                    changedAddress = true;
                                }
                            }
                            let billRequest = {
                                "ban": banRequest.ban,
                                "salesChannel": "ESHOP-Customer Care",
                                "customerOrderType": "BILLANDREC",
                                "orderRefNumber": existingData.orderReference.orderReferenceNumber,
                                "serviceAddressChanged": changedAddress ? 'Yes' : 'No',
                                "serviceAddress": {
                                    "addressLine": "",
                                    "streetAddress": "",
                                    "streetNrFirst": serviceAddress && serviceAddress.streetNrFirst,
                                    "streetNrLast": "",
                                    "streetNrLastSuffix": "",
                                    "streetName": serviceAddress && serviceAddress.streetName,
                                    "streetNamePrefix": "",
                                    "streetType": "",
                                    "locality": serviceAddress && serviceAddress.locality,
                                    "city": serviceAddress && serviceAddress.city,
                                    "stateOrProvince": serviceAddress && serviceAddress.stateOrProvince,
                                    "postCode": serviceAddress && serviceAddress.postCode,
                                    "postCodeSuffix": serviceAddress && serviceAddress.postCodeSuffix,
                                    "geoAddressId": serviceAddress && serviceAddress.geoAddressId,
                                    "sourceId": serviceAddress && serviceAddress.sourceId,
                                    "source": serviceAddress && serviceAddress.source,
                                    "subAddress": serviceAddress && serviceAddress.subAddress,
                                    "country": serviceAddress && serviceAddress.country
                                },
                                "party": {
                                    id: agentCuid,
                                    firstName: firstName,
                                    lastName: lastName,
                                    type: 'CSR',
                                    partyRoles: [
                                        {
                                            partyRole: env.CSR_NAME,
                                            sourceSystem: env.CSR_PROFILE,
                                            id: agentCuid
                                        },
                                        {
                                            partyRole: env.ENSEMBLEID,
                                            sourceSystem: env.ENS_OPERATOR,
                                            id: ensembleId
                                        }
                                    ]
                                }
                            }
                            this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesRequest", JSON.stringify(billRequest));
                            this.logger.endTime();
                            this.loading = true;
                            this.addressService.billingFromHold(billRequest)
                                .catch((error: any) => {
                                    this.logger.endTime();
                                    this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesResponse", error);
                                    this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                    this.loading = false;
                                    errorResolved = true;
                                    if (error && error.status === 404) {
                                        this.errorMsg = "Account/Order Number does not exist!!!";
                                        this.existingError = true;
                                        this.formShow = false;
                                        this.ctlHelperService.setLocalStorage('getOrderByBANOrCOR-Call', true);
                                    }
                                    else {
                                        this.systemErrorService.logAndRouteUnexpectedError(
                                            "error", 'Not Applicable',
                                            "billingandrecords - removeHold",
                                            "address.component.ts", "Address Page",
                                            error);
                                        return Observable.throwError(null);
                                    }
                                })
                                .subscribe(
                                    (data) => {
                                        this.logger.endTime();
                                        this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesResponse", JSON.stringify(data));
                                        this.logger.log("info", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                        let response = data;
                                        let internetCheck;
                                        let videoAvail;
                                        let phoneAvail: boolean = false;
                                        let phoneType = [];
                                        let videoType = [];
                                        if (this.addressService.checkCategoryId('DATA', response.payload.serviceCategory) !== undefined) {
                                            internetCheck = true;
                                        }
                                        if (this.addressService.checkCategoryId('DATA/VIDEO', response.payload.serviceCategory) !== undefined) {
                                            videoAvail = true;
                                            videoType.push({
                                                name: 'DATA/VIDEO',
                                                displayName: 'PRISM TV',
                                                code: 'PTV',
                                                tabName: 'PRISM'
                                            });
                                        }
                                        if (this.addressService.checkCategoryId('VIDEO-DTV', response.payload.serviceCategory) !== undefined) {
                                            videoAvail = true;
                                            videoType.push({
                                                name: 'VIDEO-DTV',
                                                displayName: 'DIRECTV',
                                                code: 'DTV',
                                                tabName: 'DIRECTV'
                                            });
                                        }
                                        if (this.addressService.checkCategoryId('VOICE-DHP', response.payload.serviceCategory) !== undefined) {
                                            phoneAvail = true;
                                            phoneType.push({
                                                name: 'VOICE-DHP',
                                                displayName: 'Digital(DHP)',
                                                code: 'DHP',
                                                tabName: 'DHP'
                                            });
                                        }
                                        if (this.addressService.checkCategoryId('VOICE-HP', response.payload.serviceCategory) !== undefined) {
                                            phoneAvail = true;
                                            phoneType.push({
                                                name: 'VOICE-HP',
                                                displayName: 'Home Phone',
                                                code: 'HMP',
                                                tabName: 'Home Phone'
                                            });
                                        }
                                        let user: User = {
                                            id: 1,
                                            internetCheck,
                                            videoCheck: videoAvail,
                                            phoneCheck: phoneAvail,
                                            phoneType: phoneType,
                                            videoType: videoType,
                                            enabledServiceList: response.payload.serviceCategory
                                        };
                                        this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
                                        this.store.dispatch({ type: 'UPDATE_USER', payload: user });
                                        this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.inputAddress });
                                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                        this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                                        this.store.dispatch({ type: 'INCLUDING_GIFTCARDS', payload: data.payload.giftCardOffers });
                                        this.store.dispatch({ type: 'INCLUDING_OFFERS', payload: data.payload.offers })
                                        this.router.navigate(['/billing-product']);
                                    })
                        }
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesResponse", error);
                        this.logger.log("error", "address.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "existDataDispatch", "address.component.ts", "CustomizeService Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "existDataDispatch", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public onClickYellowAddress(value) {
        this.yellowAddress = this.yellowAddresses[value];
    }


    public popupCenter(url, w, h) {
        var left = (screen.width / 2) - (w / 2);
        var top = (screen.height / 2) - (h / 2);
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    }

    public toAddress() {
        this.formShow = true;
        this.responseFlag = '';
    }

    public accountNumerClick(event, edit) {
        this.selectedRadio = 'accountnum';
        this.myForm.value.number = 'accountnum';
        this.myForm.value.orderNumber = '';
        this.orderNum = '';
        this.errorMsg = '';
        edit.focus();
    }

    public displayAddressFields() {
        this.existingAddressLineShow = true;
        this.myForm.value.orderNumber = '';
        this.orderNum = '';
        this.myForm.value.accountNumber = '';
        this.accountNum = '';
        this.errorMsg = '';
        this.myForm1 = this.myForm;
        this.myForm = this.fb.group({
            firstName: [this.myForm.value.firstName,
            [Validators.required, <any>Validations.nameValidator]],
            lastName: [this.myForm.value.lastName,
            [Validators.required, <any>Validations.nameValidator]],
            phoneNumber: [this.myForm.value.phoneNumber, [Validators.required, <any>Validations.phoneValidator]],
            number: [''],
            accountNumber: this.existingAddressLineShow ? ['', Validations.accountValidator] : [''],
            orderNumber: this.existingAddressLineShow ? ['', Validations.orderNumberValidator] : ['']
        });

    }

    public displayExistingFields() {
        this.existingAddressLineShow = false;
        this.errorMsg = '';
        this.myForm = this.myForm1;
    }


    public orderNumerClick(event, edit) {
        this.selectedRadio = 'ordernum';
        this.myForm.value.number = 'ordernum';
        this.myForm.value.accountNumber = '';
        this.accountNum = '';
        this.errorMsg = '';
        edit.focus();
    }

    public showChangeProfile() {
        this.changeProfileShow = true;
        this.ensembleIdUpdated = false;
    }

    public hideChangeProfile() {
        this.changeProfileShow = false;
    }

    public updateProfile(ensembleId) {
        var currentUser = {} as User;
        var oamData = {} as OAMData;
        this.logger.log("info", "address.component.ts", "updateProfileRequest", JSON.stringify(ensembleId));
        this.logger.startTime();
        this.loading = true;
        this.logger.startTotalTime();
        this.profileService.getProfileByEnsembleOverride(ensembleId)
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "updateProfileResponse", JSON.stringify(data));
                    this.logger.log("info", "address.component.ts", "updateProfileSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let profile = this.helperService.processProfileData(data);
                    currentUser.profile = profile;
                    currentUser.profile.validEshopProfile = true;

                    // get Ensemble Id and update
                    this.user = <Observable<User>>this.store.select('user');
                    var currentUserSubscription = this.user.subscribe((data) => {
                        if (data && data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData) {
                            currentUser.autoLogin = cloneDeep(data.autoLogin);
                            currentUser.autoLogin.oamData.ensembleId = ensembleId;
                        }
                    });

                    if (currentUserSubscription) {
                        currentUserSubscription.unsubscribe();
                    }

                    this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                    this.ensembleIdUpdated = true;
                    this.logger.log("info", "address.component.ts", "updateProfile", "Updated Profile to: " + ensembleId);
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "updateProfileResponse", error);
                    this.logger.log("error", "address.component.ts", "updateProfileSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.ensembleIdUpdated = false;
                    this.loading = false;
                }
            );
    }


    public goBacktoAddress() {
        this.formShow = true;
        this.existingError = false;
        this.errorMsg = '';
        this.existingAddressLineShow = true;
    }

    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacy === 'CENTURYLINK')
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Atrue%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%2216%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22Y5YzQ2MWM0YjIzMTExYmRi%22%2C%22ssid%22%3A%22rI28qh_OTFKTGfGQbOQIFA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
        else
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083512%2C%22eid%22%3A1570086812%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22AzY2QxNDAyNDE2YTdhMGI1%22%2C%22ssid%22%3A%22C-xqYDpuQr692Su1zOt-6Q%22%2C%22lewid%22%3A1570246912%2C%22skill%22%3A%22credit-service-cris%22%7D%7D';
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }

    public ngOnDestroy() {
        if (this.rmOdrOnHoldObservableSubscrptn !== undefined) this.rmOdrOnHoldObservableSubscrptn.unsubscribe();
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
    }

    public updatedLogicalSystemDate(event) {
        this.lSDate = event;
        this.store.dispatch({ type: 'LOGICAL_SYSTEM_DATE', payload: event });
        this.showLogicalSystemDate();
    }
    public showLogicalSystemDate() {
        this.logicalSystemDateEnable = !this.logicalSystemDateEnable;
    }
    public updatelSDate(event) {
        this.lSDate = event;
    }

    public retainWaivedOtcInfo(orderInfo) {
        if (orderInfo && orderInfo.orderDocument && orderInfo.orderDocument.addlOrderAttributes && orderInfo.orderDocument.addlOrderAttributes.length > 0
            && orderInfo.orderDocument.addlOrderAttributes[0].orderAttributeGroup && orderInfo.orderDocument.addlOrderAttributes[0].orderAttributeGroup.length > 0) {
            let otcAdjustmentInfo = orderInfo.orderDocument.addlOrderAttributes[0].orderAttributeGroup.find(group => group.orderAttributeGroupName === 'otcAdjustmentInfo');
            let waivedOtcInfo = {
                totalWaivedOtc: 0,
                otcWaiverList: {
                    reason: {},
                    waivers: []
                }
            };
            if (orderInfo.orderDocument.customerOrderItems && orderInfo.orderDocument.customerOrderItems.length > 0
                && otcAdjustmentInfo && otcAdjustmentInfo.orderAttributeGroupInfo && otcAdjustmentInfo.orderAttributeGroupInfo.length > 0
                && otcAdjustmentInfo.orderAttributeGroupInfo[0].orderAttributes && otcAdjustmentInfo.orderAttributeGroupInfo[0].orderAttributes.length > 0) {
                otcAdjustmentInfo.orderAttributeGroupInfo[0].orderAttributes.map(attr => {
                    if (attr.orderAttributeName === 'productName') {
                        orderInfo.orderDocument.customerOrderItems.map(item => {
                            let subOrderItem = item.customerOrderSubItems.find(subItem => subItem.productName === attr.orderAttributeValue);
                            if (subOrderItem) {
                                let product = {
                                    productName: attr.orderAttributeValue,
                                    waived: true
                                };
                                let productAttr = subOrderItem.productAttributes.find(prodAttr => !!prodAttr.isPriceable);
                                let price = productAttr.prices && productAttr.prices.find(p => p.priceType === 'PRICE');
                                if (price) {
                                    product['otcDetails'] = {
                                        discountedOtc: price.discountedOtc
                                    }
                                }
                                waivedOtcInfo.otcWaiverList.waivers.push(product);
                                waivedOtcInfo.totalWaivedOtc += +price.discountedOtc;
                            }
                        });
                    } else if (attr.orderAttributeName === 'reasonDescription') {
                        waivedOtcInfo.otcWaiverList.reason['description'] = attr.orderAttributeValue;
                    } else if (attr.orderAttributeName === 'reasonCode') {
                        waivedOtcInfo.otcWaiverList.reason['code'] = attr.orderAttributeValue;
                    }
                });
                this.store.dispatch({ type: 'WAIVED_OTC_INFO', payload: waivedOtcInfo });
            }
        }
    }
}