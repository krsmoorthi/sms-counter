import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { CountryStateService } from '../common/service/country-state.service';
import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from '../common/service/text-mask.service';
import { WorkingServiceComponent } from './workingservice.component';
import { TypeaheadModule } from 'ngx-bootstrap';
import { TrimDirectiveModule } from '../common/trim/trim-directive.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: WorkingServiceComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        TextMaskModule,
        TypeaheadModule,
        TrimDirectiveModule],
    exports: [WorkingServiceComponent],
    declarations: [WorkingServiceComponent],
    providers: [CountryStateService, TextMaskService]
})
export class WorkingServiceModule { }
