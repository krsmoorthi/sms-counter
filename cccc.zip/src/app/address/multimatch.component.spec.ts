/* tslint:disable */
import { MockServer } from './../MockServer.test';
import { Observable } from 'rxjs/Observable';
import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { MultimatchComponent } from './multimatch.component';
import { AppStateService } from '../common/service/app-state.service';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AddressService } from '../common/service/address.service';
import { EnterpriseAddress } from '../common/models/cart.model';
import { Logger } from '../common/logging/default-log.service';
import { SystemErrorService } from '../common/service/system-error.service';
import { serverErrorMessages } from '../common/models/common.model';
import { CTLHelperService } from '../common/service/ctlHelperService';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TypeaheadModule } from 'ngx-bootstrap';
import { TrimDirectiveModule } from 'app/common/trim/trim-directive.module';
import {
    MockSystemErrorService,
    MockAppStateService,
    MockAddressService,
    MockLogger,
    MOCK_ROUTES,
} from "../common/service/mockServices.test";
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import "rxjs/add/observable/of";
import { ServiceCategoryId } from 'app/common/models/product.model';

describe('Multi match Component', () => {
    let component: MultimatchComponent;
    let fixture: ComponentFixture<MultimatchComponent>;
    let mockServer = new MockServer();

    const imports = [
        FormsModule,
        ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
        SharedModule,
        SharedCommonModule,
        TextMaskModule,
        TypeaheadModule,
        TrimDirectiveModule,
        RouterTestingModule.withRoutes(MOCK_ROUTES)
    ];

    const req = {
        taskName: 'init'
    }

    const mockRedux: any = { // explicitly saying any here is important
        dispatch(action) { },
        configureStore() { },
        select(reducer) {
            if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('new-user'));
            else if (reducer == 'pending') return Observable.of(mockServer.getResponseForReducerAndApi('pending'));
            return Observable.of(mockServer.getResponseForRequest('submitTask', req));
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    };

    const p2 = FormBuilder;
    const p3 = { provide: AddressService, useClass: MockAddressService };
    const p4 = { provide: Store, useValue: mockRedux };
    const p5 = { provide: AppStateService, useClass: MockAppStateService };
    const p6 = { provide: Logger, useClass: MockLogger };
    const p7 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p8 = CTLHelperService;

    describe('All test cases', () => {

        const baseConfig = {
            imports: imports,
            declarations: [MultimatchComponent],
            providers: [p2, p3, p4, p5, p6, p7, p8]
        };

        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule(baseConfig)
                .compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(MultimatchComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it('should have been defined', () => {
            expect(component.user).toBeDefined();
            expect(component.userSubscription).toBeDefined();
            expect(component.myForm).toBeDefined();
            expect(component.searchAddresses).toBeDefined();
            expect(component.searchFlag).toBeDefined();
        });

        it('call ngOnInit()', () => {
            component.ngOnInit();
            expect(component.myForm).toBeDefined();
        });

        it('should call onClickYellowAddress and yellowAddress should have been defined and assigned', () => {
            let address: EnterpriseAddress = {
                addressLine: 'ETA Navalur',
                unitNumber: 'Unit 3',
                stateOrProvince: 'Tamilnadu',
                city: 'Chennai',
                postCode: '522509',
                singleLine: true
            };
            component.onClickYellowAddress(address);
            expect(component.yellowAddress).toBeDefined();
            expect(component.yellowAddress).toEqual(address);
        });

        it('calling setFinalAddress', () => {
            let address: EnterpriseAddress = {
                addressLine: 'ETA Navalur',
                unitNumber: 'Unit 3',
                stateOrProvince: 'Tamilnadu',
                city: 'Chennai',
                postCode: '522509',
                singleLine: true
            };
            let action = component.setFinalAddress(address);
            expect(component.finalAddress).toBe(address);
        });

        it("should show the error on click on Continue button when not selected any matching address", () => {
            component.yellowAddress = undefined;
            component.selectedMatch();
            expect(component.errorMsg).toEqual(serverErrorMessages.selectNearMatch);
        });

        xit('calling continueRuralAddress', () => {
            let mockRouter = TestBed.get(Router);
            spyOn(mockRouter, 'navigate');
            component.continueRuralAddress();
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/product-offer']);
        });
    });

    describe('On select multimatch address', () => {
        class MockAddressService {
            checkAddress() {
                return Observable.of(mockServer.getResponseForRequest('checkAddressCallAfterMultimacthAddSelect'));
            }
            public checkCategoryId(type: string, specList: ServiceCategoryId[]): ServiceCategoryId {
                return specList.find((item) =>
                    item.serviceCategory.indexOf(type) !== -1);
            }
        }
        const p3 = { provide: AddressService, useClass: MockAddressService };
        const baseConfig = {
            imports: imports,
            declarations: [MultimatchComponent],
            providers: [p2, p3, p4, p5, p6, p7, p8]
        };

        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule(baseConfig)
                .compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(MultimatchComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });


        it('should create component when user selectMatch get called', () => {
            expect(component).toBeTruthy();
        });

        it('should call selectMatch', () => {
            component.yellowAddress = {};
            component.selectedMatch();
            expect(component.loading).toEqual(false);
        });

        it('should call selectMatch on continue from miltimatch component', () => {
            component.yellowAddress = {};
            component.selectedMatch();
            expect(component.loading).toEqual(false);
        });

        it('should have ruralNewAddress as false', () => {
            component.yellowAddress = {};
            component.selectedMatch();
            expect(component.ruralNewAddress).toEqual(false);
            expect(component.loading).toEqual(false);
        });

        xit('should call selectMatch and checkAddress with throw error', () => {
            const data = {};
            const addressService = TestBed.get(AddressService);
            spyOn(addressService, 'checkAddress').and.callFake(() => Observable.throw(data));
        });
    });

});