/* tslint:disable */
import { } from 'jasmine';
import { MockServer } from '../MockServer.test';
import { Observable } from 'rxjs/Observable';
import { inject, TestBed, ComponentFixture, async } from '@angular/core/testing';
import { WorkingServiceComponent } from './workingservice.component';
import { AppStateService } from '../common/service/app-state.service';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, Routes } from '@angular/router';
import { AddressService } from '../common/service/address.service';
import { Logger } from '../common/logging/default-log.service';
import { SystemErrorService } from '../common/service/system-error.service';
import { CTLHelperService } from '../common/service/ctlHelperService';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TypeaheadModule } from 'ngx-bootstrap';
import {
    MockSystemErrorService,
    MockAppStateService,
    MockAddressService,
    MockLogger,
    MockCountryStateService,
    MockRouter,
    MockTextMaskService,
    MockPropertiesHelperService,
    MockProductService,
    MockBlueMarbleService,
    MockHelperService,
    MockProfileService,
} from "../common/service/mockServices.test";
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import "rxjs/add/observable/of";
import { CountryStateService } from 'app/common/service/country-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileService } from 'app/common/service/profile.service';
const routes: Routes = [
    {
        path: '', component: WorkingServiceComponent
    }
];

describe('workingService Component', () => {
    let component: WorkingServiceComponent;
    let fixture: ComponentFixture<WorkingServiceComponent>;
    let mockServer = new MockServer();

    const mockRedux: any = {
        dispatch(obj) { return obj },
        configureStore() { },
        select(reducer) {
            return Observable.of(
                mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    };

    const p1 = FormBuilder;
    const p2 = CTLHelperService;
    const p3 = { provide: Router, useClass: MockRouter };
    const p4 = { provide: Logger, useClass: MockLogger };
    const p5 = { provide: Store, useValue: mockRedux };
    const p6 = { provide: AddressService, useClass: MockAddressService };
    const p7 = { provide: AppStateService, useClass: MockAppStateService };
    const p8 = { provide: CountryStateService, useClass: MockCountryStateService };
    const p9 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p10 = { provide: TextMaskService, useClass: MockTextMaskService };
    const p11 = { provide: ProductService, useClass: MockProductService };
    const p12 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
    const p13 = { provide: HelperService, useClass: MockHelperService };
    const p14 = { provide: ProfileService, useClass: MockProfileService };
    const p15 = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };


    let baseConfig = {
        imports: [
            FormsModule,
            ReactiveFormsModule,
            SharedModule,
            SharedCommonModule,
            TextMaskModule,
            TypeaheadModule,
            RouterTestingModule
        ],
        declarations: [WorkingServiceComponent],
        providers: [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15]
    }
    beforeEach(async(() => {
        TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(WorkingServiceComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create WorkingService component', () => {
        expect(component).toBeTruthy;
    });
    it('should call ngOnInit()', () => {
        const data = mockServer.getMockStore('user');
        expect(component.myForm).toBeDefined();
        component.ngOnInit();
    });
    it('should call maskPhone() method...', () => {
        let phone = "4056782398";
        expect(component.maskPhone).toBeDefined();
        component.maskPhone(phone);
    });
    it('should call actPopup() method...', () => {
        let width = 400;
        let height = 400;
        expect(component.actPopup).toBeDefined();
        component.actPopup(width, height);
    });
    it("should check invalid scenario of radio buttons when value is undefined ", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.value == undefined;
        expect(radioBtn.invalid).toBeFalsy();
    });
    it("should check invalid scenario of radio buttons when value is empty.", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.setValue("");
        expect(radioBtn.invalid).toBeFalsy();
    });
    it("should check valid scenario of radio buttons when value is 'Yes'...", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.setValue('Yes');
        expect(radioBtn.valid).toBeTruthy();
    });
    it("should check valid scenario of radio buttons when value is 'No'...", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.setValue('No');
        expect(radioBtn.valid).toBeTruthy();
    });
    it("should call onSelected() function when Radio Button Value 'Yes'...", () => {
        let val = "Yes";
        component.onSelected(val);
    });
    it("should call onSelected() function when Radio Button Value 'No'...", () => {
        let val = "No";
        component.onSelected(val);
    });
    it('should call onContinue() method...', () => {
        expect(component.onContinue).toBeDefined();
    });
});
