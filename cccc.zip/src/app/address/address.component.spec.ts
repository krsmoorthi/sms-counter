// tslint:disable
import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { Router, Routes, RouterModule } from "@angular/router";
import { DeviceDetectorService } from "ngx-device-detector";
import { FormBuilder, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { Store } from "@ngrx/store";
import { CommonModule } from "@angular/common";
import { TextMaskModule } from "angular2-text-mask";
import { TypeaheadModule, TypeaheadMatch } from "ngx-bootstrap";
import { Observable, of } from "rxjs";
import "rxjs/add/observable/of";
import "rxjs/add/observable/throw";
import { AddressComponent } from "./address.component";
import { MockServer } from "../MockServer.test";
import { TrimDirectiveModule } from "../common/trim/trim-directive.module";
import { SharedCommonModule } from "../shared/shared-common.module";
import { HelperService } from "../common/service/helper.service";
import { BlueMarbleService } from "../common/service/bm.service";
import { DisconnectService } from "../common/service/disconnect.service";
import { ProductService } from "../common/service/product.service";
import { CTLHelperService } from "../common/service/ctlHelperService";
import { SystemErrorService } from "../common/service/system-error.service";
import { PendingOrderService } from "../common/service/pending-order.service";
import { AppStateService } from "../common/service/app-state.service";
import { TextMaskService } from "../common/service/text-mask.service";
import { AddressService } from "../common/service/address.service";
import { CountryStateService } from "../common/service/country-state.service";
import { Logger } from "../common/logging/default-log.service";
import {
  MockHelperService,
  MockBlueMarbleService,
  MockDisconnectService,
  MockProductService,
  MockSystemErrorService,
  MockPendingOrderService,
  MockAppStateService,
  MockTextMaskService,
  MockAddressService,
  MockCountryStateService,
  MockLogger,
  MockRouter,
  MockProfileService,
  MockPropertiesHelperService,
} from "../common/service/mockServices.test";
import { ProfileService } from 'app/common/service/profile.service';
import { SharedModule } from 'app/shared/shared.module';
import { Validations } from 'app/common/validations/validations';
import { HttpResponse } from '@angular/common/http';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';

const routes: Routes = [
  {
    path: "",
    component: AddressComponent
  }
];

describe("AddressComponent", () => {
  let component: AddressComponent;
  let fixture: ComponentFixture<AddressComponent>;

  const mockServer = new MockServer();

  const imports = [
    FormsModule,
    CommonModule,
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
    SharedCommonModule,
    TextMaskModule,
    TypeaheadModule.forRoot(),
    TrimDirectiveModule,
    RouterModule.forChild(routes),
    SharedModule
  ]

  const mockRedux: any = {
    dispatch(obj) { return obj },
    configureStore() { },
    select(reducer) {
      return Observable.of(
        mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  };

  // Default Provides
  const p1 = { provide: Router, useClass: MockRouter };
  const p2 = { provide: Logger, useClass: MockLogger };
  const p3 = FormBuilder;
  const p4 = { provide: CountryStateService, useClass: MockCountryStateService };
  const p5 = { provide: AddressService, useClass: MockAddressService };
  const p6 = { provide: TextMaskService, useClass: MockTextMaskService };
  const p7 = { provide: AppStateService, useClass: MockAppStateService };
  const p8 = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const p9 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const p10 = DeviceDetectorService;
  const p11 = { provide: ProductService, useClass: MockProductService };
  const p12 = CTLHelperService;
  const p13 = { provide: DisconnectService, useClass: MockDisconnectService };
  const p14 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const p15 = { provide: HelperService, useClass: MockHelperService };
  const p16 = { provide: Store, useValue: mockRedux };
  const p17 = { provide: ProfileService, useClass: MockProfileService };
  const p18 = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };

  describe('All test case', () => {

    const baseConfig = {
      imports: imports,
      declarations: [AddressComponent],
      providers: [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18]
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(AddressComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it("should create", () => {
      expect(component).toBeTruthy();
    });

    it("should create a form with 13 controls for NI flow", () => {
      expect(component.myForm.contains("firstName")).toBe(true);
      expect(component.myForm.contains("lastName")).toBe(true);
      expect(component.myForm.contains("phoneNumber")).toBe(true);
      expect(component.myForm.contains("addressLine")).toBe(true);
      expect(component.myForm.contains("singleAddressLine")).toBe(true);
      expect(component.myForm.contains("unitNumber")).toBe(true);
      expect(component.myForm.contains("singleUnitNumber")).toBe(true);
      expect(component.myForm.contains("state")).toBe(true);
      expect(component.myForm.contains("city")).toBe(true);
      expect(component.myForm.contains("zipCode")).toBe(true);
      expect(component.myForm.contains("accountNumber")).toBe(true);
      expect(component.myForm.contains("orderNumber")).toBe(true);
      expect(component.myForm.contains("number")).toBe(true);
      expect(component.myForm.contains("number1")).toBe(false);
    });

    it("should check the form with valid control", () => {
      const firstName = component.myForm.get("firstName");
      firstName.setValue("");
      expect(firstName.valid).toBeFalsy();

      const lastName = component.myForm.get("lastName");
      lastName.setValue("xyz xyz");
      expect(firstName.valid).toBeFalsy();

      lastName.setValue("xyz");
      expect(lastName.valid).toBeTruthy();
    });

    xit("should get data for existing order by order number", () => {
      const mockRedux1: any = {
        dispatch(action) { },
        select(reducer) {
          if (reducer == "user")
            return Observable.of(
              mockServer.getResponseForReducerAndApi("auth-user")
            );
          else if (reducer == "retain")
            return Observable.of(
              mockServer.getResponseForReducerAndApi("retainByOrderNum")
            );
        }
      };
      // Overide provides
      const p16_o1 = { provide: Store, useValue: mockRedux1 };

      TestBed.resetTestingModule();
      baseConfig.providers = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16_o1, p17, p18];
      TestBed.configureTestingModule(baseConfig);
      fixture = TestBed.createComponent(AddressComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      expect(component.existingAddressLineShow).toBe(true);
      expect(component.selectedRadio).toBe("ordernum");
    });

    it("should check multimatch address functinality", () => {
      component.existingAddressLineShow = false;
      component.onSubmit();
      //expect(component.responseFlag).toBe("yellow");
      //expect(component.taskName).toBe("Select Matching Address");
    });

    it('should call displayExistingFields', () => {
      component.displayExistingFields();
      expect(component.existingAddressLineShow).toBe(false);
      expect(component.errorMsg).toBe('');
    });

    it('should call serviceAvailability', () => {
      const req = {
        taskName: 'init'
      };
      const data = mockServer.getResponseForRequest('submitTask', req);
      (component as any).serviceAvailability(data);
      expect(component.store.dispatch).toBeDefined();
    });

    it('should retrieve products and services by custormer order number', () => {
      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = '1000030560';
      component.onSubmit();
      expect(component.loading).toBeTruthy();
    });

    it('should retrieve products and services by account number', () => {
      component.existingAddressLineShow = true;
      component.myForm.value.accountNumber = '473736204';
      component.onSubmit();
      expect(component.loading).toBeTruthy();
    });

    xit('should show error when account number or order reference not selected', () => {
      component.existingAddressLineShow = true;
      component.myForm.value.accountNumber = '';
      component.onSubmit();
      expect(component.errorMsg).toBe('Please Provide Account/Order Number to proceed!!!')
    });

    it('it should call the goBacktoAddress function', () => {
      component.goBacktoAddress();
      expect(component.formShow).toBe(true);
      expect(component.existingError).toBeFalsy();
      expect(component.existingAddressLineShow).toBeTruthy();
      expect(component.errorMsg).toEqual('');
    });

    xit('it should call the continueRuralAddress function', () => {
      component.continueRuralAddress();
      expect(component.loading).toBe(true);
    });

    it('it should call the selectedAddress function', () => {
      component.selectedAddress();
      expect(component.loading).toBe(true);
    });

    xit('Should call `toAddress `  ', () => {
      const actual = component.toAddress();
      expect(component.formShow).toBe(true);
      expect(actual).toBeDefined;
    });

    it('should have been defined', () => {
      expect(component.phoneMask).toBeDefined();
      expect(component.myForm).toBeDefined();
      expect(component.countries).toBeDefined();
      expect(component.states).toBeDefined;
      expect(component.formShow).toBeDefined;
      expect(component.responseFlag).toBeDefined;
      expect(component.orderRefNumber).toBeDefined;
      expect(component.processInstanceId).toBeDefined;
      expect(component.taskId).toBeDefined;
      expect(component.taskName).toBeDefined;
      expect(component.yellowAddresses).toBeDefined;
      expect(component.yellowAddress).toBeDefined;
      expect(component.myForm).toBeDefined;
    });

    xit('should check multimatch address functinality', () => {
      const data = mockServer.getResponseForReducerAndApi('apiValidateAddress-Multimatch');

      const mockAddressService = TestBed.get(AddressService);
      spyOn(mockAddressService, 'checkAddress').and.returnValue(Observable.of(data));

      component.existingAddressLineShow = false;
      component.onSubmit();
      //expect(component.responseFlag).toBe('yellow');
      //expect(component.taskName).toBe('Select Matching Address');
    });

    xit('should check no match address functinality', () => {
      const data = mockServer.getResponseForReducerAndApi('apiValidateAddress-NoMatch');

      const mockAddressService = TestBed.get(AddressService);
      spyOn(mockAddressService, 'checkAddress').and.returnValue(Observable.of(data));

      component.existingAddressLineShow = false;
      component.onSubmit();
      expect(component.responseFlag).toEqual('red');
      expect(component.loading).toEqual(false);
    });

    it('it should call the displayAddressFields function', () => {
      component.displayAddressFields();
      expect(component.existingAddressLineShow).toBe(true);
      expect(component.errorMsg).toEqual('');
    });

    // it('should called `singleLineAPI` onKeyUp from single line address field and catch the error', () => {
    //   component.formShow = true;
    //   const addressService = TestBed.get(AddressService);
    //   spyOn(addressService, 'getGeoamsrvcl').and.returnValue(Observable.of([]));
    // 	component.singleLineAPI('some random address');
    // });

    xit('should get order summary by order number and navigate to product order page', () => {
      const data = mockServer.getResponseForReducerAndApi('retrieveProductsAndServices');

      const pendingOrderService = TestBed.get(PendingOrderService);
      const res = spyOn(pendingOrderService, 'getOrderSummary').and.returnValue(Observable.of(data));

      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = '1000032456';
      component.onSubmit();
      expect(component.loading).toBeFalsy();
      expect(res).toBeDefined();
    });

    xit('should retrieve products and services for incompleted or hold order by custormer order reference number', () => {
      const data1 = mockServer.getResponseForReducerAndApi('retrieveProdAndServices-incompletedOrder');
      const data2 = mockServer.getResponseForReducerAndApi('retrieveProdAndServices-incompletedOrder-and-removeFromHold');

      const pendingOrderService = TestBed.get(PendingOrderService);
      const getOrderSummaryRes = spyOn(pendingOrderService, 'getOrderSummary').and.returnValue(Observable.of(data1));
      // let removeOrderFromHoldRes = spyOn(pendingOrderService, 'removeOrderFromHold').and.returnValue(Observable.of(data2));

      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = 'ORN-24432660869714417';
      component.onSubmit();
      expect(data1.existingProductsAndServices[0].pendingOrders[0].orderReference.orderReferenceNumber).toBe(component.myForm.value.orderNumber);
      expect(component.loading).toBeTruthy();
      expect(getOrderSummaryRes).toBeDefined;
      // expect(removeOrderFromHoldRes).toBeDefined;
    });

    xit('should retrieve products and services for incompleted or hold order by custormer order reference number', () => {
      const data1 = mockServer.getResponseForReducerAndApi('retrieveProdAndServices-incompletedOrder');
      const data2 = mockServer.getResponseForReducerAndApi('retrieveProdAndServices-incompletedOrder-and-removeFromHold');
      const pendingOrderService = TestBed.get(PendingOrderService);
      const getOrderSummaryRes = spyOn(pendingOrderService, 'getOrderSummary').and.returnValue(Observable.of(data1));
      // let removeOrderFromHoldRes = spyOn(pendingOrderService, 'removeOrderFromHold').and.returnValue(Observable.of(data2));
      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = 'ORN-24432660869714417';
      component.onSubmit();
      expect(data1.existingProductsAndServices[0].pendingOrders[0].orderReference.orderReferenceNumber).toBe(component.myForm.value.orderNumber);
      expect(component.loading).toBeTruthy();
      expect(getOrderSummaryRes).toBeDefined;
      // expect(removeOrderFromHoldRes).toBeDefined; 
    });

    xit('should retrieve products and services for incompleted or disconnect order by custormer order reference number', () => {
      const data1 = mockServer.getResponseForReducerAndApi('retrieveProdAndServices-incompletedOrder');
      const data2 = mockServer.getResponseForReducerAndApi('schedule-disconnect-date');
      const pendingOrderService = TestBed.get(PendingOrderService);
      const getOrderSummaryRes = spyOn(pendingOrderService, 'getOrderSummary').and.returnValue(Observable.of(data1));
      // let removeOrderFromHoldRes = spyOn(pendingOrderService, 'removeOrderFromHold').and.returnValue(Observable.of(data2));
      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = 'ORN-24432660869714417';
      component.onSubmit();
      expect(data1.existingProductsAndServices[0].pendingOrders[0].orderReference.orderReferenceNumber).toBe(component.myForm.value.orderNumber);
      expect(component.loading).toBeTruthy();
      expect(getOrderSummaryRes).toBeDefined;
      // expect(removeOrderFromHoldRes).toBeDefined;
    });

    xit('should retrieve products and services for completed order by custormer order number', () => {
      const data = mockServer.getResponseForReducerAndApi('retrieveProdAndServices-completedOrder');
      const pendingOrderService = TestBed.get(PendingOrderService);
      const res = spyOn(pendingOrderService, 'getOrderSummary').and.returnValue(Observable.of(data));
      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = '1000033980';
      component.onSubmit();
      expect(component.loading).toBeFalsy();
      expect(res).toBeDefined;
    });

    xit('Should call changeTypeAheadLoading  true Call...', () => {
      component.changeTypeaheadLoading(true);
      expect(component.typeaheadLoading).toBe(true);
    });

    xit('Should call changeTypeAheadLoading  false Call...', () => {
      component.changeTypeaheadLoading(false);
      expect(component.typeaheadLoading).toBe(false);
    });

    it('Should call changeTypeaheadNoResults  true Call...', () => {
      component.changeTypeaheadNoResults(true);
      expect(component.typeaheadNoResults).toBe(true);
    });

    it('Should call changeTypeaheadNoResults  false Call...', () => {
      component.changeTypeaheadNoResults(false);
      expect(component.typeaheadNoResults).toBe(false);
    });

    it('Should Match the get PhoneNumberMask Call...', () => {
      const phoneMask = ['(', /[2-9]/, /[0-8]/, /\d/, ')', ' ', /[2-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
      expect(component.phoneMask.length).toBe(phoneMask.length);
    });

    it('Should Check the  Name Validation True...', () => {
      const firstName = { value: 'Sainath' };
      expect(Validations.nameValidator(firstName)).toBe(null);
    });

    it('Should Check the  Name Validation false...', () => {
      const firstName = { value: 'Sainath_123' };
      expect(Validations.nameValidator(firstName)).not.toBe(null);
    });

    it('Should Check the  Zip Code Validation true...', () => {
      const zipCode = { value: '5124' };
      expect(Validations.zipCodeValidator(zipCode)).not.toBe(null);
    });

    it('Should Check the  Zip Code Validation false...', () => {
      const zipCode = { value: '5124154da' };
      expect(Validations.zipCodeValidator(zipCode)).not.toBe(null);
    });

    it('Should have `showAddressLine ` to be called ', () => {
      const actual = component.showAddressLine(true);
      expect(component.addressLineShow).toBe(true);
      expect(actual).toBeDefined;
    });

    it('should call the functions', () => {
      let event: any;
      let event2: TypeaheadMatch;
      let inputEvent: any = { focus() { } };
      component.changeTypeaheadLoading(true);
      component.changeTypeaheadNoResults(true);
      component.typeaheadOnSelect(event2);
      component.orderNumerClick(event, inputEvent);
      expect(component.typeaheadLoading).toBe(true);
      expect(component.typeaheadNoResults).toBe(true);
    })

    // it('should get data for existing order by account number', () => {
    // 	let mockRedux: any = {
    // 		dispatch(action) { },
    // 		select(reducer) {
    // 			if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('auth-user'));
    // 			else if (reducer == 'retain') return Observable.of(mockServer.getResponseForReducerAndApi('retainByAccountNum'));
    // 		}
    // 	};
    // 	component = new component(mockRouter, logger, fb, countryStateService, addressService, mockRedux, textMask, appStateService, pendingOrderService, systemErrorService, mockDeviceDetectorService, authService, productService, ctlHelperService, disconnectService, bm, helperService);
    // 	expect(component.existingAddressLineShow).toBe(true);
    // 	expect(component.selectedRadio).toBe('accountnum');
    // });

    xit('should be able to submit address in NI flow', () => {
      const data = mockServer.getResponseForReducerAndApi('newUser');
      const addressService = TestBed.get(AddressService);
      const res = spyOn(addressService, 'checkAddress').and.callFake(() => Observable.of(data));
      component.onSubmit();
      expect(res).toBeDefined();
    });

    xit('should get order summary by order number and navigate to product order page with existing products', () => {
      const data = mockServer.getResponseForReducerAndApi('existing');
      const pendingOrderService = TestBed.get(PendingOrderService);
      const res = spyOn(pendingOrderService, 'getOrderSummary').and.callFake(() => Observable.of(data));
      component.existingAddressLineShow = true;
      component.myForm.value.orderNumber = '1000032456';
      component.onSubmit();
      expect(component.loading).toBeFalsy();
      expect(res).toBeDefined();
    });

    // it('Should have `ngOnInit ` defined ', () => {
    // 	let mockRedux: any = {
    // 		dispatch(action) { },
    // 		select(reducer) {
    // 			if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('user-agent1'));
    // 			else if (reducer == 'retain') return Observable.of(mockServer.getResponseForReducerAndApi('retainByOrderNum'));
    // 		}
    // 	};
    // 	component = new component(mockRouter, logger, fb, countryStateService, addressService, mockRedux, textMask, appStateService, pendingOrderService, systemErrorService, mockDeviceDetectorService, authService, productService, ctlHelperService, disconnectService, bm, helperService);
    // 	let actual = component.ngOnInit();
    // 	expect(actual).toBeDefined;

    // });

    // it('Should call `onClickYellowAddress `', () => {
    // 	component.yellowAddresses = [
    // 		address1, address1
    // 	];
    // 	let actual = component.onClickYellowAddress(0);
    // 	expect(component.yellowAddress).toEqual(address1);
    // });

    // it('should call `onSubmit ` router check when fromshow false success', () => {
    // 	component.formShow = false;
    // 	let req = {
    // 		taskName: 'init'
    // 	};
    // 	let data = [mockServer.getResponseForRequest('submitTask', req)];
    // 	spyOn(addressService, 'checkAddress').and.callFake(() => Observable.of(data));
    // 	component.onSubmit();
    // 	expect(component.formShow).toBe(false);
    // 	expect(mockRouter.navigate).toHaveBeenCalledWith(['/product-offer']);
    // });

    // xit('should call `onSubmit ` router check when fromshow false error', () => {
    // 	component.formShow = false;
    // 	let data = {
    // 		_body: '{err: \'any\'}',
    // 		error: {
    // 			errorMessage: 'Error'
    // 		}
    // 	};
    // 	spyOn(addressService, 'checkAddress').and.returnValue((Observable.throw(data)));
    // 	component.onSubmit();
    // 	expect(component.formShow).toBe(false);
    // 	expect(component.loading).toBeFalsy;
    // });

    // xit('Should call `onSubmit ` router check green match ', () => {
    // 	component.formShow = true;
    // 	let data = mockServer.getResponseForReducerAndApi('apiValidateAddressBadRequest');
    // 	spyOn(systemErrorService, 'logAndRouteUnexpectedError').and.returnValue(data);
    // 	spyOn(addressService, 'checkAddress').and.callFake(() => Observable.throw(data));
    // 	component.onSubmit();
    // });

    xit('should call onSubmit and checkAddresss service and throw the error', () => {
      component.formShow = true;
      component.onSubmit();
      const data = mockServer.getResponseForReducerAndApi('apiValidateAddressBadRequest');
      const addressService = TestBed.get(AddressService);
      spyOn(addressService, 'checkAddress').and.callFake(() => Observable.throw(data));
      expect(component.loading).toBe(false);
    });

    it('Should call `onSubmit ` router check red match ', () => {
      component.formShow = true;
      component.existingAddressLineShow = false;
      const req = { taskName: 'initAddressRed' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      const addressService = TestBed.get(AddressService);
      spyOn(addressService, 'checkAddress').and.returnValue(Observable.of(data));
      component.onSubmit();
      expect(component.responseFlag).not.toBe(null);
      component.responseFlag = 'red';
      expect(component.responseFlag).toBe('red');
    });

    xit('Should call `onSubmit ` router check yellow match ', () => {
      component.formShow = true;
      component.existingAddressLineShow = false;
      const req = { taskName: 'initAddressYellow' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      const addressService = TestBed.get(AddressService);
      const spy = spyOn(addressService, 'checkAddress').and.returnValue(Observable.of(data));
      component.onSubmit();
      expect(component.responseFlag).toBe('yellow');
      expect(spy).toBeDefined;
    });

    xit('Should call `singleLineAPI ` check  match ', () => {
      const req = { taskName: 'GEOAMCALL' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      const addressService = TestBed.get(AddressService);
      const spy = spyOn(addressService, 'getGeoamsrvcl').and.callFake(() => Observable.of(data));
      component.singleLineAPI('111');
      expect(component.typeaheadNoResults).toBe(false);
      expect(component.typeaheadLoading).toBe(false);
      expect(spy).toBeDefined;
    });

    xit('Should call `singleLineAPI ` check  match ', () => {
      const req = { taskName: 'GEOAMCALL' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      data.responseData.addresses = [];
      const addressService = TestBed.get(AddressService);
      const spy = spyOn(addressService, 'getGeoamsrvcl').and.callFake(() => Observable.of(data));
      component.singleLineAPI('111');
      expect(component.typeaheadNoResults).toBe(false);
      expect(spy).toBeDefined;
    });

    it('Should call `singleLineAPI ` check  min length ', () => {
      const req = { taskName: 'GEOAMCALL' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      const addressService = TestBed.get(AddressService);
      const spy = spyOn(addressService, 'getGeoamsrvcl').and.callFake(() => Observable.of(data));
      component.singleLineAPI('1');
      expect(component.typeaheadNoResults).toBe(false);
      expect(spy).toBeDefined;
    });

    it('Should call `singleLineAPI ` check  match 400 ', () => {
      const req = { taskName: 'GEOAMCALL' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      data.responseCode = 400;
      const addressService = TestBed.get(AddressService);
      const spy = spyOn(addressService, 'getGeoamsrvcl').and.callFake(() => Observable.of(data));
      component.singleLineAPI('111');
      expect(component.typeaheadNoResults).toBe(true);
      expect(spy).toBeDefined;
    });

    it('Should call `singleLineAPI ` check  match 400 ', () => {
      const req = { taskName: 'GEOAMCALL' };
      const data = mockServer.getResponseForRequest('submitTask', req);
      data.responseCode = 400;
      const addressService = TestBed.get(AddressService);
      const spy = spyOn(addressService, 'getGeoamsrvcl').and.callFake(() => Observable.of(data));
      component.singleLineAPI('111');
      expect(component.typeaheadNoResults).toBe(true);
      expect(spy).toBeDefined;
    });

    // xit('Should call `singleLineAPI ` check  error ', () => {
    // 	let data = { _body: 'error' };
    // 	let spy = spyOn(addressService, 'getGeoamsrvcl').and.returnValue(Observable.throw(data));
    // 	expect(function () { component.singleLineAPI('111'); }).toThrow(data._body);
    // 	expect(spy.calls.any()).toBe(true);
    // });

    // it('Should Match the get Countries Call...', () => {
    //   let countries: any;
    //   let countryStateService = TestBed.get(CountryStateService);
    //   countries = spyOn(countryStateService, 'getCountries').and.callFake(() => [
    //     {
    //         countryId: 1,
    //         countryName: 'United States of America',
    //         countryCode: 'USA'
    //     }
    //   ])
    // 	expect(component.countries.length).toBe(countries.length);
    // 	expect(component.countries[0].countryId).toBe(countries[0].countryId);
    // 	expect(component.countries[0].countryName).toBe(countries[0].countryName);
    // 	expect(component.countries[0].countryCode).toBe(countries[0].countryCode);
    // });
    it('should set isWorkingServiceAllowed to be true - Ni', () => {
      let allowedFlows = {
        NEWINSTALL: true
      };
      let currentUrl = 'NEWINSTALL';
      expect(allowedFlows[currentUrl]).toBeTruthy();
      let isWorkingServiceAllowed = true;
      expect(isWorkingServiceAllowed).toBeTruthy();
    });
    it('should set isWorkingServiceAllowed to be true - Move', () => {
      let allowedFlows = {
        MOVE: true
      };
      let currentUrl = 'MOVE';
      expect(allowedFlows[currentUrl]).toBeTruthy();
      let isWorkingServiceAllowed = true;
      expect(isWorkingServiceAllowed).toBeTruthy();
    });
    it('should set isWorkingServiceAllowed to be false - B&R', () => {
      let allowedFlows = {
        BILLANDREC: true
      };
      let currentUrl = 'BILLANDREC';
      expect(allowedFlows[currentUrl]).toBeTruthy();
      let isWorkingServiceAllowed = false;
      expect(isWorkingServiceAllowed).toBeFalsy();
    });
    it('should set isWorkingServiceAllowed to be false - Billing', () => {
      let allowedFlows = {
        BILLING: true
      };
      let currentUrl = 'BILLING';
      expect(allowedFlows[currentUrl]).toBeTruthy();
      let isWorkingServiceAllowed = false;
      expect(isWorkingServiceAllowed).toBeFalsy();
    });

  });
  describe('NotFound Scenario', () => {
    class MockAddressService {
      checkAddress() {
        return Observable.of(mockServer.getResponseForRequest('NotFoundAddress'));
      }
      getGeoamsrvcl() {
        let data: any = {
          error: "service is down",
          responseCode: 404
        };
        return of(new HttpResponse(data));
      }
    }

    const p5 = { provide: AddressService, useClass: MockAddressService };

    const baseConfig = {
      imports: imports,
      declarations: [AddressComponent],
      providers: [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18]
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(AddressComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it("should create component for Not Found Address", () => {
      expect(component).toBeTruthy();
    });

    it('should call onSubmit method and checkAddress service call for NotFound Address ', () => {
      component.onSubmit();
      component.loading = false;
      expect(component.responseFlag).toBeDefined('AddressNotInRange');
      expect(component.loading).toEqual(false);
    });

  });

  describe('Found with Ranges Scenario', () => {
    class MockAddressService {
      checkAddress() {
        return Observable.of(mockServer.getResponseForRequest('FoundWithRanges'));
      }
    }

    const p5 = { provide: AddressService, useClass: MockAddressService };

    const baseConfig = {
      imports: imports,
      declarations: [AddressComponent],
      providers: [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18]
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(AddressComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it("should create component for Found with ranges Address", () => {
      expect(component).toBeTruthy();
    });

    it('should call onSubmit method and checkAddress service call for Found Address with ranges scenario ', () => {
      component.onSubmit();
      expect(component.responseFlag).toBeDefined('AddressAddConfirmation');
      component.loading = false;
      expect(component.loading).toEqual(false);
    });
  });
});
