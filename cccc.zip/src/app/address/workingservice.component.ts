import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { EnterpriseAddress } from '../common/models/cart.model';
import { AppStore } from '../common/models/appstore.model';
import { AddressService } from '../common/service/address.service';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../common/service/app-state.service';
import { Logger } from '../common/logging/default-log.service';
import { GenericValues, serverErrorMessages, APIErrorLists } from '../common/models/common.model';
import { SystemErrorService } from '../common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';

@Component({
    selector: 'workingService',
    styleUrls: ['./workingservice.component.scss'],
    templateUrl: './workingservice.component.html'
})

export class WorkingServiceComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public myForm: FormGroup;
    public finalAddress: EnterpriseAddress;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public legacyTxt: any;
    public ban: any;
    public custName: any;
    public wsinfoList: any = [];
    public prodAvail: any = [];
    public invalidLocation: boolean = false;
    public enableContinue: boolean = false;
    constructor(private router: Router,
        private fb: FormBuilder,
        private addressService: AddressService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private logger: Logger,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService) {
        this.user = <Observable<User>>store.select('user');
        this.myForm = this.fb.group({
            locationChk: ['', []]
        });
    }
    ngOnInit() {
        this.userSubscription = this.user.subscribe((data) => {
            if (data) {
                this.finalAddress = data.finalAddress;
                if (data.workingServiceInfo) {
                    data.workingServiceInfo.forEach((wsi) => {
                        this.prodAvail = [];
                        let obj = Object.assign({}, wsi);
                        wsi.serviceCategory.map((p) => {
                            if (p === "VOICE-HP") {
                                this.prodAvail.push("Home Phone");
                            } else if (p === "DATA") {
                                this.prodAvail.push("Internet");
                            } else if (p === "DTV") {
                                this.prodAvail.push("DIRECTV");
                            } else if (p === "VOICE-DHP") {
                                this.prodAvail.push("Digital Home Phone");
                            }
                        });
                        obj.productAvailable = this.prodAvail.join(', ');
                        if (wsi.ban) {
                            this.ban = wsi.ban;
                        }
                        if (wsi.customerName) {
                            this.custName = wsi.customerName;
                        }
                        this.wsinfoList.push(obj);
                    });
                }
                this.legacyTxt = data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
        });
        this.userSubscription.unsubscribe();
    }

    /**
     * To mask phone number as pe USA format (xxx-xx-xxxx)
     * @param data as response
     */
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }
    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacyTxt === 'CENTURYLINK') {
            url = 'http://rmodkit.corp.intranet/chat/ensHandbook.html';
        } else {
            url = '';
        }
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }
    public onSelected(value: any) {
        this.enableContinue = true;
        if (value === "No") {
            this.invalidLocation = true;
        } else {
            this.invalidLocation = false;
        }
        this.store.dispatch({ type: 'LOCATION_AVAILABLE', payload: value });
    }
    public onContinue() {
        this.router.navigate(['/product-offer']);
    }
}