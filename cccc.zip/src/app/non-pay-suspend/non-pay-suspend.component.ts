import { Component, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { Observable } from 'rxjs';
import { BlueMarbleService } from 'app/common/service/bm.service'
import { AppStateService } from 'app/common/service/app-state.service';
import { GenericValues } from '../common/models/common.model';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { DatePipe } from '@angular/common';
import { cloneDeep } from 'lodash';
import * as moment from 'moment-timezone';

@Component({
  selector: 'nonpay-suspend',
  templateUrl: './non-pay-suspend.component.html',
  styleUrls: ['../product/offer.component.scss']
})
export class nonPaySuspendComponent {  
  public suspendedCarrierList: any;
  public countValue: number;  
  public listCarrierListAll: string;
  public fetechRuleLDRes: any;
  public showReadyToBlockCarrierList: any;
  public restoreCarrierList: boolean = false;
  public hideCarrierListApiCall: boolean = false;
  public retrievalTypesResponse: any;
  public catelogSelectdenailData: boolean = false;
  public restoreScenarioActive: boolean = false;
  public restoreSuspendedValue: boolean = false;
  public nonRestoredValue: boolean = false;
  public newCarrierListLd: boolean = false;
  public selectedList: any;
  public selectiveCarrierDenialData: any;
  public suspendActive: boolean;
  public selectiveCarrierDenialEmpty: boolean = false;
  public nonpaySuspendActive: boolean = false;
  public loading: boolean = false;
  public SuspendedLdCarrierList: any;
  public ldCarrierListSelected: boolean;
  public stateOfAddress: any;
  public nonpayRestoreActive: boolean = false;
  public addAttriResp: any;
  public restoreListOfCarriers: any;
  public listofCarriersAddlAttr: any;
  public restoreonlyLDBlck: boolean;
  public waiveRestoralFee: boolean = false;
  public restoreValApplied: boolean = true;;
  public noChangeRestoredSubItemsAll: boolean = false;
  public RestoredAllSubItems: boolean = false;
  public noChangeRestoreAll: boolean = false;
  public restoreProductsAll: boolean = false;
  public noChangeSuspendSubItemsAll: boolean;
  public noChangeSuspendAll: boolean = false;
  public suspendedAllSubItems: boolean = false;
  public suspendedAll: boolean = false;
  public isSuspendRadioButtonSelected: boolean = true;
  public isRestoreRadioButtonSelected: boolean = false;
  public allProductsSuspened: boolean = false;
  public supendAllInactive: boolean = false;
  public suspendAllAtive: boolean = false;
  public restoreonlyDtvProduct: boolean = false;
  public onlyHsiRestoreEnabled: boolean = false;
  public hideUndoRestoreAll: boolean = false;
  public restorePotsProd: boolean = false;
  public showRestoreOnlyLD: boolean;
  public suspendProdAll: boolean;
  public restoreDhpProd: boolean = false;
  public restoreDtvProd: boolean = false;
  public restoreHsiprod: boolean = false;
  public restoreProdAll: boolean = false;
  public restoreAllAttribute: any;
  public restoreOnlyLD: boolean = false;
  public restoreAllProd: boolean = false;
  public restoreAllSuspenedProducts: boolean = false;
  public showRestoreAll: boolean = false;
  public showDtvRestore: boolean = false;
  public showInternetRestore: boolean = false;
  public showDhpRestore: boolean = false;
  public showLDRestore: boolean = false;
  public showPotsRestore: boolean = false;
  public enableSuspendTab: boolean = false;
  public allSuspendedOrNot: boolean = true;
  public telephoneNumber: any;
  public userData: any;
  public nonPaySuspendInitRequest: any;
  public nonPaySuspendRemarks: string = "";
  public showLDsuspend: boolean = false;
  public suspendOnlyDtv: boolean = false;
  public suspendHsiAndDhp: boolean = false;
  public suspendOnlyLD: boolean = false;
  public suspendAllProd: boolean = false;
  public showDtvSuspend: boolean = false;
  public showInternetSuspend: boolean = false;
  public showDhpSuspend: boolean = false;
  public showPotsSuspend: boolean = false;
  public suspendPotsProductName: any;
  public suspendDtvProductName: any;
  public suspendDhpProductName: any;
  public suspendHsiProductName: any;
  public orderEffectiveDate: any;
  public suspendAllSelected: boolean = false;
  public listofCarriers: any;
  public suspendedProducts: any;
  @ViewChild('validateNonPaySuspend', { static: false, }) public validateNonPaySuspend: DialogComponent;
  @ViewChild('validateNonPayLDSuspend', { static: false, }) public validateNonPayLDSuspend: DialogComponent;
  constructor(
    private store: Store<AppStore>,
    private appStateService: AppStateService,
    private bMService: BlueMarbleService
  ) {
    this.appStateService.setLocationURLs();    
    let nonPaySusData = <Observable<any>>this.store.select('existingProducts');
    nonPaySusData.subscribe((data) => {
      if (data && data.restoreallproducts && data.restoreallproducts !== undefined) {
        this.restoreProdAll = data.restoreallproducts;
      }
      this.orderEffectiveDate = data && data.nonPayInitRes && data.nonPayInitRes !== undefined && data.nonPayInitRes.payload && data.nonPayInitRes.payload !== undefined && data.nonPayInitRes.payload.orderEffectiveDate;
      this.orderEffectiveDate = moment().format('L');
      this.telephoneNumber = data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].telephoneNumber;
      this.suspendedProducts = data && data.nonPayInitRes && data.nonPayInitRes !== undefined && data.nonPayInitRes.payload && data.nonPayInitRes.payload.cart && data.nonPayInitRes.payload.cart !== undefined && data.nonPayInitRes.payload.cart.customerOrderItems;
      this.stateOfAddress = data && data.existingProductsAndServices && data.existingProductsAndServices[0].serviceAddress.stateOrProvince;
      this.SuspendedLdCarrierList = data.nonpayLdRequest;
      this.addAttriResp = data.nonPayInitRes.payload.addlOrderAttributes;
      this.retrievalTypesResponse = data.nonPayInitRes.payload.retrievalTypes;
      this.suspendedProducts && this.suspendedProducts !== undefined && this.suspendedProducts.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          this.suspendPotsProductName = data.offerCategory;
          if (data.action !== "SUSPEND") {
            this.showPotsSuspend = true;
          } else {
            this.showPotsRestore = true;
          }
          data.customerOrderSubItems.map(subData => {
            if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
              this.addAttriResp.map(addAtt => {
                addAtt.orderAttributeGroup.map(attrList => {
                  if (attrList.orderAttributeGroupName === "selectiveCarrierRestore") {
                    if (attrList.orderAttributeGroupInfo[0].orderAttributes.length === 0) {
                      this.nonpayRestoreActive = true;
                    }
                  }
                  if (attrList.orderAttributeGroupName === "selectiveCarrierDenial") {
                    if (attrList.orderAttributeGroupInfo[0].orderAttributes.length > 0) {
                      this.suspendActive = true;
                    }
                  }
                })
              })
              if (subData.action !== "SUSPEND" && !this.suspendActive) {
                this.showLDsuspend = true;
              } else {
                this.showLDRestore = true;
              }
            }
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          this.suspendDhpProductName = data.offerCategory;
          if (data.action !== "SUSPEND") {
            this.showDhpSuspend = true;
          } else {
            this.showDhpRestore = true;
          }
        }
        if (data.offerCategory === GenericValues.iData) {
          this.suspendHsiProductName = data.offerCategory;
          if (data.action !== "SUSPEND") {
            this.showInternetSuspend = true;
          } else {
            this.showInternetRestore = true;
          }
        }
        if (data.offerCategory === GenericValues.cDTV) {
          this.suspendDtvProductName = data.offerCategory;
          if (data.action !== "SUSPEND") {
            this.showDtvSuspend = true;
          } else {
            this.showDtvRestore = true;
          }
        }
      })
      this.suspendedProducts && this.suspendedProducts !== undefined && this.suspendedProducts.length > 0 && this.suspendedProducts.map(susData => {
        if (susData.action !== "SUSPEND") {
          this.suspendAllAtive = true;
        } else {
          this.supendAllInactive = true;
        }
        if (susData.offerCategory === GenericValues.cHP) {
          susData.customerOrderSubItems.map(data => {
            this.showRestorePage();
            if (data.action !== "SUSPEND" && !this.suspendActive) {
              this.suspendAllAtive = true;
            } else {
              this.supendAllInactive = true;
            }
            if (data.action !=="SUSPEND" && this.allSuspendedOrNot){
              this.allSuspendedOrNot = false;
            }
          });
        }
        this.showRestorePage();
      })
      if (this.suspendAllAtive && !this.supendAllInactive) {
        this.allProductsSuspened = true;
      }
      if (this.showPotsRestore || this.showLDRestore || this.showDhpRestore || this.showDtvRestore) {
        this.showRestoreAll = true;
      }
      this.nonPaySuspendInitRequest = cloneDeep(data && data.nonPayInitRes);
    });
  }
  public suspendAll() {
    this.suspendAllSelected = true;
    this.suspendAllProd = false;
    this.suspendOnlyLD = false;
    this.suspendHsiAndDhp = false;
    this.suspendOnlyDtv = false;
    this.store.dispatch({ type: 'NON_PAY_LD_REQUEST', payload: '' });
  }
  public restoreAll() {
    this.restoreAllSuspenedProducts = true;
    this.restoreHsiprod = false;
    this.restorePotsProd = true;
    this.hideUndoRestoreAll = false;
  }
  public suspendPots() {
    this.suspendAllProd = true;
    this.suspendAllSelected = true;
    this.suspendOnlyLD = false;
    this.suspendHsiAndDhp = false;
    this.suspendOnlyDtv = false
  }
  public restorePots() {
    this.restorePotsProd = true;
    this.hideUndoRestoreAll = true;
    this.restoreAllSuspenedProducts = true;
  }
  public flag: boolean = false;
  public suspendLD(value?) {
    this.flag = false;
    this.addAttriResp.map(addAtt => {
      addAtt.orderAttributeGroup.map(attrList => {
        if (attrList.orderAttributeGroupName === "selectiveCarrierRestore") {
          if (attrList.orderAttributeGroupInfo[0].orderAttributes.length === 0) {
            this.nonpayRestoreActive = true;
          }
        }
        if (attrList.orderAttributeGroupName === "selectiveCarrierDenial") {
          if (attrList.orderAttributeGroupInfo[0].orderAttributes.length === 0) {
            this.nonpaySuspendActive = true;
          }
        }
      })
    })
    if (this.retrievalTypesResponse && this.retrievalTypesResponse.retrievalTypes && this.retrievalTypesResponse.retrievalTypes.length > 0 && this.retrievalTypesResponse.retrievalTypes[0].offers.length > 0 && this.retrievalTypesResponse.retrievalTypes[0].offers[0].catalogs && this.retrievalTypesResponse.retrievalTypes[0].offers[0].catalogs.length > 0 && this.retrievalTypesResponse.retrievalTypes[0].offers[0].catalogs[0].catalogItems.length > 0) {
      this.hideCarrierListApiCall = true;
    } else {
      this.hideCarrierListApiCall = false;
    }
    let req = {
      "inputAttribute": [
        {
          "attributeName": "RULE_NAME",
          "attributeValue": [
            "selectiveCarrierDenial"
          ]
        },
        {
          "attributeName": "STATE",
          "attributeValue": [
            this.stateOfAddress
          ]
        }
      ],
      "outputAttribute": [
        {
          "attributeName": "CARRIER_CODE"
        },
        {
          "attributeName": "CARRIER_NAME"
        }
      ],
      "requestDate": null,
      "ruleId": "176"
    }
    if (this.hideCarrierListApiCall && this.nonpaySuspendActive) {
      this.loading = true;
      this.bMService.getCarrierList(req)
        .subscribe(data => {
          this.fetechRuleLDRes = data;
          this.newCarrierListLd = true;
          this.store.dispatch({ type: 'NON-PAY-SUSPEND_LD_RES', payload: data });
          this.loading = false;
        });
      this.validateNonPayLDSuspend.open();
    }
    this.suspendOnlyLD = true;
  }

  public dislayLD(value) {    
     if (!this.flag) {
      this.flag = true;
      return value.substring(value.indexOf("-")+1)
    } else {
      return ", " + value.substring(value.indexOf("-")+1)
    } 
  }
  public saveupdatesSelected(value) {
    if (value && !this.suspendOnlyLD) {
      this.restoreOnlyLD = false;
      this.restoreonlyLDBlck = true;
    } else {
      this.restoreonlyLDBlck = false;
    }
    if (this.suspendOnlyLD && value) {
      this.suspendOnlyLD = true;
    } else {
      this.suspendOnlyLD = false;
    }    
    let nonPaySusData = <Observable<any>>this.store.select('existingProducts');
    nonPaySusData.subscribe((data) => {
      this.showReadyToBlockCarrierList = data.nonpayLdRequest;     
    });    
  }
  public restoreLD() {
    this.flag = false;
    this.addAttriResp.map(addAtt => {
      addAtt.orderAttributeGroup.map(attrList => {
        if (attrList.orderAttributeGroupName === "selectiveCarrierRestore") {
          if (attrList.orderAttributeGroupInfo[0].orderAttributes.length === 0) {
            this.nonpayRestoreActive = true;
          }
        }
        if (attrList.orderAttributeGroupName === "selectiveCarrierDenial") {
          if (attrList.orderAttributeGroupInfo[0].orderAttributes.length === 0) {
            this.nonpaySuspendActive = true;
          } else if (attrList.orderAttributeGroupInfo[0].orderAttributes.length > 0) {
            this.restoreCarrierList = true;
            this.suspendedCarrierList = attrList.orderAttributeGroupInfo[0].orderAttributes;
            this.store.dispatch({ type: 'NON_PAY_LD_CARRIER_LIST', payload: attrList.orderAttributeGroupInfo[0].orderAttributes });
          }
        }
      })
    })
    this.suspendedProducts && this.suspendedProducts !== undefined && this.suspendedProducts.map(data =>{      
         if(data.customerOrderSubItems[0].productName === "Selective Carrier Denial"){
          this.nonpaySuspendActive = false;
         } else {
          this.nonpaySuspendActive = true;
         }      
    })
    if (!this.nonpaySuspendActive) {
      this.validateNonPayLDSuspend.open();
    }
    this.restoreOnlyLD = false;
    this.restoreonlyLDBlck = true;
  }
  public suspendHsi() {
    this.suspendHsiAndDhp = true;
  }
  public restoreHsi() {
    this.restoreHsiprod = false;
    this.onlyHsiRestoreEnabled = true;
  }
  public suspendDtv() {
    this.suspendOnlyDtv = true;
  }
  public restoreDtv() {
    this.restoreDtvProd = false;
    this.restoreonlyDtvProduct = true;
  }
  public selectExisting() {
    this.enableSuspendTab = true;
    this.store.dispatch({ type: 'NONSUSPEND_EXISTING_TAB', payload: this.enableSuspendTab });
  }
  public showRestorePage() {
    this.isRestoreRadioButtonSelected = true;
    this.isSuspendRadioButtonSelected = false;
  }
  public showSuspendPage() {
    this.isSuspendRadioButtonSelected = true;
    this.isRestoreRadioButtonSelected = false;
  }
  public undoHsi() {
    this.suspendHsiAndDhp = false;
  }
  public undoRestoreHsi() {
    this.restoreHsiprod = true;
    this.onlyHsiRestoreEnabled = false;
  }
  public undoLD() {    
    this.suspendOnlyLD = false;
    this.store.dispatch({ type: 'NON_PAY_LD_REQUEST', payload: '' });
  }
  public undoDtv() {
    this.suspendOnlyDtv = false;
  }
  public undoRestoreAll() {
    this.restoreAllSuspenedProducts = false;
    this.restorePotsProd = false;
    this.restoreDtvProd = false;
    this.restoreHsiprod = false;
    this.restoreOnlyLD = false;
    this.onlyHsiRestoreEnabled = false;
  }
  public undoAll() {
    this.suspendAllSelected = false;
  }
  public undoRestorePotsAll() {
    this.restorePotsProd = false;
    this.restoreAllSuspenedProducts = false;
    this.restoreDtvProd = false;
    this.restoreHsiprod = false;
    this.restoreOnlyLD = false;
  }
  public undoRestoreLD() {    
    this.restoreOnlyLD = true;
    this.showRestoreOnlyLD = true;
    this.restoreonlyLDBlck = false;
    this.store.dispatch({ type: 'NON_PAY_LD_REQUEST', payload: '' });
  }
  public undoRestoreDtv() {
    this.restoreDtvProd = true;
    this.restoreonlyDtvProduct = false;
  }
  public undoRestoreDhp() {
    this.restoreDhpProd = false;
  }
  public selectRestoralFee(restoralVal) {
    if (restoralVal === "Will be applied") {
      this.restoreValApplied = true;
    } else if (restoralVal === "Waive restoral fee") {
      this.waiveRestoralFee = true;
      this.restoreValApplied = false;
    }
  }
  public submitNonPaySuspend() {
    if ((this.suspendAllSelected || this.suspendAllProd) || (this.restorePotsProd || this.restoreAllSuspenedProducts)) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (this.suspendAllSelected || this.suspendAllProd) {
          if (data.offerCategory === GenericValues.iData) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              if(subData.productName === GenericValues.secureWifiComponent) {
                subData.action = "NOCHANGE";
              } else {
                subData.action = "SUSPEND";
              }
            })
          }
          if (data.offerCategory === GenericValues.cHP) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              subData.action = "SUSPEND";
            })
          }
          if (data.offerCategory === GenericValues.cDTV) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              subData.action = "SUSPEND";
            })
          }
          if (data.offerCategory === GenericValues.cDHP) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              subData.action = "SUSPEND";
            })
          }
        }
        if (this.restorePotsProd || this.restoreAllSuspenedProducts) {
          if (data.offerCategory === GenericValues.iData && this.showInternetRestore) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              if(subData.productName === GenericValues.secureWifiComponent) {
                subData.action = "NOCHANGE";
              } else {
                subData.action = "RESTORE";
              }
            })
          } else if (!this.showInternetRestore) {
            if (data.offerCategory === GenericValues.iData) {
              data.action = "NOCHANGE";
              data.customerOrderSubItems.map(subData => {
                subData.action = "NOCHANGE";
              })
            }
          }
          if (data.offerCategory === GenericValues.cHP && this.showPotsRestore) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              subData.action = "RESTORE";
            })
          }
          if (data.offerCategory === GenericValues.cDTV && this.showDtvRestore) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              subData.action = "RESTORE";
            })
          }
          if (data.offerCategory === GenericValues.cDHP && this.showDhpRestore) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              subData.action = "RESTORE";
            })
          }
        }
      })
    } else if (!this.suspendOnlyLD && !this.suspendHsiAndDhp && !this.suspendOnlyDtv && (!this.onlyHsiRestoreEnabled && !this.restorePotsProd && !this.restoreAllSuspenedProducts && !this.restoreonlyDtvProduct && !this.restoreonlyLDBlck && !this.restoreonlyLDBlck)) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.iData) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      })
    }

    if (this.suspendOnlyLD || this.restoreOnlyLD || this.restoreonlyLDBlck) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "CHANGE";
          if (this.suspendOnlyLD && !this.newCarrierListLd) {
            data.customerOrderSubItems.map(subData => {
              if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
                subData.action = "SUSPEND";
              } else {
                subData.action = "NOCHANGE";
              }
            })
          } else {
            data.customerOrderSubItems.map(subData => {
              if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
                subData.action = "NOCHANGE";
              }
            })
          }
          if ((this.restoreOnlyLD || this.restoreonlyLDBlck) && !this.restoreCarrierList) {
            data.customerOrderSubItems.map(subData => {
              if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
                subData.action = "RESTORE";
              } else {
                subData.action = "NOCHANGE";
              }
            })
          } else if (this.restoreCarrierList) {
            data.customerOrderSubItems.map(subData => {
              if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
                subData.action = "NOCHANGE";
              }
            })
          }
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      });
    } else if (!this.suspendAllSelected && !this.suspendAllProd && !this.suspendHsiAndDhp && !this.suspendOnlyDtv && (!this.onlyHsiRestoreEnabled && !this.restorePotsProd && !this.restoreAllSuspenedProducts && !this.restoreonlyDtvProduct && !this.restoreonlyLDBlck)) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      });
    }

    if (this.suspendHsiAndDhp || this.onlyHsiRestoreEnabled) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (this.suspendHsiAndDhp) {
          if (data.offerCategory === GenericValues.iData) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              if(subData.productName === GenericValues.secureWifiComponent) {
                subData.action = "NOCHANGE";
              } else {
                subData.action = "SUSPEND";
              }
            })
          }
          if (data.offerCategory === GenericValues.cDHP) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              subData.action = "SUSPEND";
            })
          }
        }
        if (this.onlyHsiRestoreEnabled) {
          if (data.offerCategory === GenericValues.iData) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              if(subData.productName === GenericValues.secureWifiComponent) {
                subData.action = "NOCHANGE";
              } else {
                subData.action = "RESTORE";
              }
            })
          }
          if (data.offerCategory === GenericValues.cDHP) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              subData.action = "RESTORE";
            })
          }
        }
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      });
    } else if ((!this.suspendAllSelected && !this.suspendAllProd && !this.suspendOnlyDtv && !this.suspendOnlyLD) && (!this.onlyHsiRestoreEnabled && !this.restorePotsProd && !this.restoreAllSuspenedProducts && !this.restoreonlyDtvProduct && !this.restoreonlyLDBlck)) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.iData) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      });
    }
    if (this.suspendOnlyDtv || this.restoreonlyDtvProduct) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cDTV) {
          if (this.suspendOnlyDtv) {
            data.action = "SUSPEND";
            data.customerOrderSubItems.map(subData => {
              subData.action = "SUSPEND";
            })
          }
          if (this.restoreonlyDtvProduct) {
            data.action = "RESTORE";
            data.customerOrderSubItems.map(subData => {
              subData.action = "RESTORE";
            })
          }
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      });
    } else if ((!this.suspendAllSelected && !this.suspendAllProd && !this.suspendHsiAndDhp && !this.suspendOnlyLD) && (!this.onlyHsiRestoreEnabled && !this.restorePotsProd && !this.restoreAllSuspenedProducts && !this.restoreonlyLDBlck)) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }

      });
    }
    if (this.suspendOnlyLD && this.suspendHsiAndDhp && this.suspendOnlyDtv) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
              subData.action = "SUSPEND";
            } else {
              subData.action = "NOCHANGE";
            }
          })
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            if(subData.productName === GenericValues.secureWifiComponent) {
              subData.action = "NOCHANGE";
            } else {
              subData.action = "SUSPEND";
            }
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
      });
    } else if (this.suspendOnlyLD && this.suspendHsiAndDhp) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
              subData.action = "SUSPEND";
            } else {
              subData.action = "NOCHANGE";
            }
          })
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            if(subData.productName === GenericValues.secureWifiComponent) {
              subData.action = "NOCHANGE";
            } else {
              subData.action = "SUSPEND";
            }
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
      });
    } else if (this.suspendHsiAndDhp && this.suspendOnlyDtv) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            if(subData.productName === GenericValues.secureWifiComponent) {
              subData.action = "NOCHANGE";
            } else {
              subData.action = "SUSPEND";
            }
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
      });
    } else if (this.suspendOnlyLD && this.suspendOnlyDtv) {
      this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
        if (data.offerCategory === GenericValues.cHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
              subData.action = "SUSPEND";
            } else {
              subData.action = "NOCHANGE";
            }
          })
        }
        if (data.offerCategory === GenericValues.iData) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
        if (data.offerCategory === GenericValues.cDTV) {
          data.action = "SUSPEND";
          data.customerOrderSubItems.map(subData => {
            subData.action = "SUSPEND";
          })
        }
        if (data.offerCategory === GenericValues.cDHP) {
          data.action = "NOCHANGE";
          data.customerOrderSubItems.map(subData => {
            subData.action = "NOCHANGE";
          })
        }
      });
    }
    let userData = <Observable<any>>this.store.select('user');
    userData.subscribe((data) => {
      if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload !== undefined && this.nonPaySuspendInitRequest.payload.notes !== undefined) {
        this.nonPaySuspendInitRequest.payload.notes[0].author = (data.autoLogin && data.autoLogin.oamData.ensembleId) ? data.autoLogin.oamData.ensembleId : "EnsembleID";
      }
    });
    this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.cart !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
      if (data.action === "SUSPEND") {
        this.suspendedAll = true;
      } else if (data.action === "NOCHANGE") {
        this.noChangeSuspendAll = true;
      }
      data.customerOrderSubItems.map(subData => {
        if (subData.action === "SUSPEND") {
          this.suspendedAllSubItems = true;
        } else {
          this.noChangeSuspendSubItemsAll = true;
        }
      })
    })
    this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.cart !== undefined && this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
      if (data.action === "RESTORE") {
        this.restoreProductsAll = true;
      } else if (data.action === "NOCHANGE") {
        this.noChangeRestoreAll = true;
      }
      data.customerOrderSubItems.map(subData => {
        if (subData.action === "RESTORE") {
          this.RestoredAllSubItems = true;
        } else {
          this.noChangeRestoredSubItemsAll = true;
        }
      })
    })
    if ((this.suspendedAllSubItems && !this.noChangeSuspendAll) && this.suspendedAll && !this.noChangeSuspendSubItemsAll) {
      if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.addlOrderAttributes) {
        this.nonPaySuspendInitRequest.payload.addlOrderAttributes[0].orderAttributeGroup.map(data => {
          data.orderAttributeGroupInfo[0].orderAttributes.map(susprod => {
            if (susprod.orderAttributeName === "suspendAll") {
              susprod.orderAttributeValue = true;
            }
            if (susprod.orderAttributeName === "restoreAll") {
              susprod.orderAttributeValue = false;
            }
          });
        })
      }
    }
    if ((this.RestoredAllSubItems && !this.noChangeRestoreAll) && this.restoreProductsAll && !this.noChangeRestoredSubItemsAll) {
      if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.addlOrderAttributes) {
        this.nonPaySuspendInitRequest.payload.addlOrderAttributes[0].orderAttributeGroup.map(data => {
          data.orderAttributeGroupInfo[0].orderAttributes.map(susprod => {
            if (susprod.orderAttributeName === "restoreAll") {
              susprod.orderAttributeValue = true;
            }
            if (susprod.orderAttributeName === "suspendAll") {
              susprod.orderAttributeValue = false;
            }
          });
        })
      }
    }
    if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.addlOrderAttributes) {
      this.nonPaySuspendInitRequest.payload.addlOrderAttributes[0].orderAttributeGroup.map(data => {
        data.orderAttributeGroupInfo[0].orderAttributes.map(susprod => {
          if (susprod.orderAttributeName === "restoralFee") {
            if ((this.restoreProdAll && this.restoreValApplied) || (this.isRestoreRadioButtonSelected && this.restoreValApplied)) {
              susprod.orderAttributeValue = true;
            } else {
              susprod.orderAttributeValue = false;
            }
          }
        });
      })
    }
    if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.notes !== undefined) {
      this.nonPaySuspendInitRequest.payload.notes[0].value = ((this.allProductsSuspened && !this.restoreProdAll) || (!this.restoreProdAll && !this.restoreProductsAll && !this.RestoredAllSubItems)) ? "Suspending due to non-pay by ESHOP" : "restoring from ESHOP";
      this.nonPaySuspendInitRequest.payload.notes[0].date = new DatePipe('en-US').transform(this.orderEffectiveDate, 'shortDate');
      this.nonPaySuspendInitRequest.payload.notes[0].name = this.nonPaySuspendRemarks;
    }
    let nonPaySusData = <Observable<any>>this.store.select('existingProducts');
    nonPaySusData.subscribe((data) => {
      this.SuspendedLdCarrierList = data.nonpayLdRequest;
      if (data && data.nonpayLdRequest && data.nonpayLdRequest.length > 0) {
        this.ldCarrierListSelected = true;
      }
    });
    if (this.ldCarrierListSelected) {
      if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.addlOrderAttributes) {
        this.nonPaySuspendInitRequest.payload.addlOrderAttributes[0].orderAttributeGroup.map(data => {
          if (data.orderAttributeGroupName === "selectiveCarrierDenial") {
            this.SuspendedLdCarrierList && this.SuspendedLdCarrierList !== undefined && this.SuspendedLdCarrierList.map(dat => {
              if (data.orderAttributeGroupInfo[0].orderAttributes && data.orderAttributeGroupInfo[0].orderAttributes.length > 0 && !this.selectiveCarrierDenialEmpty) {
                for (let i = 0; i < data.orderAttributeGroupInfo[0].orderAttributes.length; i++) {
                  if (dat.orderAttributeValue === data.orderAttributeGroupInfo[0].orderAttributes[i].orderAttributeValue) {
                    data.orderAttributeGroupInfo[0].orderAttributes.splice(i, 1);
                  }
                }
              } else {
                this.selectiveCarrierDenialEmpty = true;
                data.orderAttributeGroupInfo[0].orderAttributes.push(dat);
              }
            })
          }
          if (data.orderAttributeGroupName === "selectiveCarrierRestore" && !this.newCarrierListLd) {
            this.SuspendedLdCarrierList && this.SuspendedLdCarrierList !== undefined && this.SuspendedLdCarrierList.map(dat => {
              if (data.orderAttributeGroupInfo[0].orderAttributes && (data.orderAttributeGroupInfo[0].orderAttributes.length === 0 || data.orderAttributeGroupInfo[0].orderAttributes.length > 0)) {
                data.orderAttributeGroupInfo[0].orderAttributes.push(dat);
              }
            })
          }

        })
      }
    }
    this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(data => {
      if (data.customerOrderSubItems[0].productName === "Home Phone Directory Listing") {
        this.selectiveCarrierDenialData = data;
      }
    })
    if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest !== undefined && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.addlOrderAttributes) {
      this.nonPaySuspendInitRequest.payload.addlOrderAttributes[0].orderAttributeGroup.map(data => {
        if (data.orderAttributeGroupName === "selectiveCarrierDenial") {
          if (data.orderAttributeGroupInfo[0].orderAttributes.length > 0) {
            this.nonRestoredValue = true;
          } else {
            this.nonRestoredValue = false;
          }
        }
        if (data.orderAttributeGroupName === "selectiveCarrierRestore") {
          if (data.orderAttributeGroupInfo[0].orderAttributes.length > 0) {
            this.restoreSuspendedValue = true;
          } else {
            this.restoreSuspendedValue = false;
          }
        }

      })
    }
    this.selectedList = cloneDeep(this.selectiveCarrierDenialData);
    if (this.nonPaySuspendInitRequest && this.nonPaySuspendInitRequest.payload && this.nonPaySuspendInitRequest.payload.retrievalTypes && this.nonPaySuspendInitRequest.payload.retrievalTypes.retrievalTypes[0] && this.nonPaySuspendInitRequest.payload.retrievalTypes.retrievalTypes[0].offers[0] && this.nonPaySuspendInitRequest.payload.retrievalTypes.retrievalTypes[0].offers[0].catalogs.length > 0) {
      this.restoreScenarioActive = false;
      this.nonPaySuspendInitRequest.payload.retrievalTypes.retrievalTypes[0].offers[0].catalogs.map(data => {
        if (data.catalogItems && data.catalogItems !== undefined && data.catalogItems.length > 0) {
          this.catelogSelectdenailData = true;
          this.selectedList.customerOrderSubItems.map(dat => {
            dat.productName = data.catalogItems[0].productOffer.offerName;
            if (this.nonRestoredValue && this.restoreSuspendedValue) {
              dat.action = "ADD";
            } else if (this.nonRestoredValue && !this.restoreSuspendedValue) {
              dat.action = "ADD";
            } else if (!this.nonRestoredValue && this.restoreSuspendedValue) {
              dat.action = "ADD";
            }
            dat.productAttributes = data.catalogItems[0].productOffer.productComponents[0].product.productAttributes;
            dat.productCategory = data.catalogItems[0].productOffer.productComponents[0].product.productCategory;
            dat.productId = data.catalogItems[0].productOffer.productComponents[0].product.productId;
            dat.productType = data.catalogItems[0].productOffer.productComponents[0].product.productType;
            dat.productAttributes.map(prodAttr => {
              prodAttr.compositeAttribute.map(data => {
                delete data["attributeDisplayName"]
              })
            })
          })
        }
      })
    } else {
      this.restoreScenarioActive = true;
    }
    if (this.suspendOnlyLD && !this.restoreScenarioActive && this.catelogSelectdenailData && !this.suspendAllSelected) {
      this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.push(this.selectedList);
    }
    this.nonPaySuspendInitRequest.payload.cart.customerOrderItems.map(custSub => {
      if (custSub.customerOrderSubItems[0].productName === "Selective Carrier Denial") {
        if (this.nonRestoredValue && this.restoreSuspendedValue) {
          custSub.action = "CHANGE";
          custSub.customerOrderSubItems[0].action = "CHANGE";
        } else if (this.nonRestoredValue && !this.restoreSuspendedValue) {
          custSub.action = "ADD";
          custSub.customerOrderSubItems[0].action = "ADD";
        } else if (!this.nonRestoredValue && this.restoreSuspendedValue) {
          custSub.action = "REMOVE";
          custSub.customerOrderSubItems[0].action = "REMOVE";
        }
      }
    })
    this.store.dispatch({ type: 'NON-PAY-SUSPEND_SUBMIT_RES', payload: this.nonPaySuspendInitRequest });    
    this.validateNonPaySuspend.open();
  }  
} 