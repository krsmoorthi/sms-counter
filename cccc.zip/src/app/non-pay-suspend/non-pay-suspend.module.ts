import { NgModule } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { nonPaySuspendComponent } from './non-pay-suspend.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: nonPaySuspendComponent
    }
];

@NgModule({
    imports: [
        // CommonModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,
        // CustomDatepickerModule,
        SharedCommonModule,
        SharedModule
    ],
    exports: [nonPaySuspendComponent],
    declarations: [nonPaySuspendComponent],
    providers: [
        
    ]
})
export class NonPaySuspendModule { }
