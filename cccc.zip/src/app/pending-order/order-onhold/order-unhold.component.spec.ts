import { Routes, RouterModule, Router } from "@angular/router";
import { OrderUnHold } from './order-unhold.component';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { DebugElement, NgZone } from '@angular/core';
import { MockServer } from 'app/MockServer.test';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { TabsModule, AccordionModule, TypeaheadModule } from 'ngx-bootstrap';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { Observable } from 'rxjs/Observable';
import { MockLogger, MockAppStateService, MockReviewOrderService, MockPendingOrderService, MockRouter, MockAccountService, MockDisconnectService, MockProductService, MockAddressService, MockBlueMarbleService, MockSystemErrorService, MockCountryStateService, MockTextMaskService, MockCTLHelperService, MockDirectvService, MockPropertiesHelperService } from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DomSanitizer } from '@angular/platform-browser';
import { AccountService } from 'app/common/service/account.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { By } from '@angular/platform-browser';


const routes: Routes = [
    {
      path: "",
      component: OrderUnHold
    }
];

    describe("Order Unhold scenario", () => {
        let component: OrderUnHold;
        let fixture: ComponentFixture<OrderUnHold>;
        let debugElement: DebugElement;
        const mockServer = new MockServer();
      
        const imports = [
            FormsModule,
            ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
            TabsModule.forRoot(),
            AccordionModule.forRoot(),
            SharedModule,
            SharedCommonModule,
            TextMaskModule,
            TypeaheadModule,
            RouterModule.forChild(routes),
        ]
      
        const mockRedux: any = {
          dispatch(obj) {return obj},
          configureStore() {},
          select(reducer) {
              return Observable.of(
                mockServer.getMockStore("ONHOLD-PENDING-ORDER")[reducer]
              );
          },
          take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
          }
        };
    
    
         // Default Provides
      const p1 = { provide: Logger, useClass: MockLogger}
      const p2 = { provide: Store, useValue: mockRedux }
      const p3 = { provide: AppStateService, useClass: MockAppStateService }
      const p4 = { provide: ReviewOrderService, useClass: MockReviewOrderService }
      const p5 = { provide: PendingOrderService, useClass: MockPendingOrderService };
      const p6 = { provide: Router, useClass: MockRouter };
      
      const p8 = DomSanitizer;
      const p9 = { provide: AccountService , useClass: MockAccountService};
      const p10 = { provide: DisconnectService , useClass: MockDisconnectService};
      const p11 = { provide: ProductService , useClass: MockProductService};
      const p12 = { provide: AddressService , useClass: MockAddressService};
      const p13 = { provide: BlueMarbleService , useClass: MockBlueMarbleService};
      const p14 = FormBuilder;
      const p15 = { provide: SystemErrorService , useClass: MockSystemErrorService};
      const p16 = { provide: CountryStateService , useClass: MockCountryStateService};
      const p17 = { provide: TextMaskService , useClass: MockTextMaskService};
      const p18 = { provide: CTLHelperService , useClass: MockCTLHelperService};
      const p19 = { provide: DirectvService , useClass: MockDirectvService};
      const p20 = { provide: PropertiesHelperService , useClass: MockPropertiesHelperService};
        
    
    
      const baseConfig = {
        imports: imports,
        declarations: [OrderUnHold],
        providers: [p1,p2,p3,p4,p5,p6,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20]
      };
    
      beforeEach(async(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule(baseConfig).compileComponents();
      }));


      beforeEach(() => {
        fixture = TestBed.createComponent(OrderUnHold);
        component = fixture.componentInstance;
        debugElement = fixture.debugElement;
        fixture.detectChanges();
      });


      it("should create order unhold component", () => {
        expect(component).toBeTruthy();
      });
    
      it("should display unholdReason in the UI", ()=> {
        component.unholdReason = "Need Clarification";
        fixture.detectChanges();
        const unholdReason = debugElement.query(By.css('.installservicestextstyle')).nativeElement;
        expect(unholdReason.innerHTML).toContain('Need Clarification');
      });

      it("should display New Tech Remark in the UI when shippingInfo is not available", ()=> {
        const cardBlock = debugElement.query(By.css('.card-block')).nativeElement;
        expect(cardBlock.innerHTML).toContain('New Tech Remark');
      });

      it("should display shippingInfo in the UI when shippingInfo is available", ()=> {
        component.shippingInfo = {
          isShipAddrSameAsServiceAddress : true,
            shippingAddress: {
              streetAddress: "8832 S CARR WAY",
              city: "LITTLETON",
              stateOrProvince: "CO",
              postCode: "80128",
              country: "USA"
            }
          }
        fixture.detectChanges();
        const cardBlock = debugElement.query(By.css('.card-block')).nativeElement;
        expect(cardBlock.innerHTML).toContain('8832 S CARR WAY');
        expect(cardBlock.innerHTML).toContain('LITTLETON');
        expect(cardBlock.innerHTML).toContain('CO');
        expect(cardBlock.innerHTML).toContain('80128');
      });

    });
