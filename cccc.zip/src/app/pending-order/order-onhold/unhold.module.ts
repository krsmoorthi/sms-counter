import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'app/shared/shared.module';
import { CountryStateService } from 'app/common/service/country-state.service';
import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TypeaheadModule } from 'ngx-bootstrap';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { OrderUnHold } from './order-unhold.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: OrderUnHold
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        TextMaskModule,
        TypeaheadModule
    ],
    exports: [
        OrderUnHold
    ],
    declarations: [
        OrderUnHold
    ],
    providers: [
        CountryStateService,
        TextMaskService,
        PendingOrderService
    ]
})
export class OrderUnholdModule { }
