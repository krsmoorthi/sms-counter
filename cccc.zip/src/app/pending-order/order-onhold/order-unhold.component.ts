import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStateService } from '../../common/service/app-state.service';
import { Subscription } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { ShippingInfo } from '../../common/models/schedule-shipping.model';
import "rxjs/add/observable/of";

@Component({
    selector: 'order-unhold',
    templateUrl: './order-unhold.html',
    styleUrls: ['./order-unhold.scss']
  })
  export class OrderUnHold implements OnInit{

    public pendingObservable;
    public pendingSubscription: Subscription
    public showShipDiv: boolean = false;
    public shippingInfo: ShippingInfo;
    public unholdReason: string;

    constructor(
      private logger: Logger,
      public store: Store<AppStore>, private appStateService: AppStateService ){
        this.appStateService.setLocationURLs();
        this.pendingObservable = <Observable<any>>this.store.select('pending');
        
        this.pendingSubscription = this.pendingObservable.subscribe((data) => {
          
            this.shippingInfo = data && data.orderDocument && data.orderDocument.schedule && data.orderDocument.schedule.shippingInfo;
            if(data && data.orderReference && data.orderReference.reason && data.orderReference.reason[0] && data.orderReference.reason[0].description){
              this.unholdReason = data.orderReference.reason[0].description;
            }
        })
    }

    public ngOnInit() {
      this.logger.metrics('Order-UnHold');
      window.scroll(0, 0);
    }
  }