import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../common/models/user.model';
import { AppStore } from '../common/models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../common/service/app-state.service';
import { AddressService } from '../common/service/address.service';
import { Logger } from '../common/logging/default-log.service';
import { PendingOrderService } from '../common/service/pending-order.service';
import { SchedulingService } from '../common/service/scheduling.service';
import {
    serverErrorMessages, GenericValues, APIErrorLists,
    ErrorResponse,
    Switch
} from '../common/models/common.model';
import { ExistingProducts } from '../common/models/existing-products.model';
import { SystemErrorService } from "app/common/service/system-error.service";
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import * as moment from 'moment-timezone';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { HelperService } from 'app/common/service/helper.service';
import { OfferVariables } from 'app/common/models/offers.model';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { env } from '../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
    selector: 'pending-order',
    templateUrl: './pending-order.html',
    styleUrls: ['./pending-order.scss']
})
export class PendingOrderComponent implements OnInit, OnDestroy, AfterViewInit {
    public isOrderRemarksFailure: boolean = false;
    public isOrderRemarksSuccess: boolean = false;
    public suspendActive: boolean = false;
    public pendingExistingFlows: boolean = false;
    public existingFlow: any;
    public isExistingProductsSelected = true;
    public isDisconnectLandLineSelected = false;
    public apiResponseError: APIErrorLists;
    public reasonsList: any = [];
    private scheduleResponse: any;
    private isnotNiOrder: boolean = false;
    private respData: any;
    public errorMsg: string;
    public newRemark: any;
    public loading: boolean = false;
    //   private existingProductsResponse: ExistingProducts;
    private existingProducts: Observable<ExistingProducts>;
    public existingProductsSubscription: Subscription;
    public firstName: string;
    public serviceStatus;
    public schedulingStatus;
    public pendingSummaryObservable: Observable<any>;
    public pendingSummarySubscription: Subscription;
    public responseData: any;
    public existingProdResponse: any;
    public isExistingProd: any;
    public isNewinstallFlag: boolean = false;
    public accountInfo: any;
    public orderReference: any;
    public serviceAddress: any;
    public exisitngProduct: any;
    public scheduleDetails: any;
    public legacy: string = '';
    public productItems: any;
    public internetItems: any;
    public userProductList: any = [];
    public enableSups: boolean;
    public customerOrderType: string = '';
    public dataTN;
    public potsTN;
    public potsTNshow: boolean = false;
    public reqDeposit: boolean = false;
    public isportedTNExists: boolean = false;
    public ban: any;
    public customerOrderStatus: any;
    public isLCAddress: boolean = false;
    public recommendedItems: any;
    @ViewChild('Cancel', { static: false, }) public cancelSup1Dialog: DialogComponent;
    @ViewChild('ponrTrueScheduling', { static: false, }) public schedulingPONRDialog: DialogComponent;
    @ViewChild('ponrTrueCancel', { static: false, }) public cancelOrderPONRDialog: DialogComponent;
    @ViewChild('ponrTrueHold', { static: false, }) public onHoldOrderPONRDialog: DialogComponent;
    @ViewChild('cancelOrderDeposit', { static: false, }) public cancelSup1DialogDeposit: DialogComponent;
    @ViewChild('suspendProdActive', { static: false, }) public suspendProdActive: DialogComponent;
    @ViewChild('recommendedError', { static: false, }) public recommendedError: DialogComponent;
    @ViewChild('cancelPrepaidOrder', { static: false, }) public cancelPrepaidOrder: DialogComponent;
    //billing Records Correction
    @ViewChild('billingRecordsCorrectionMultiple', { static: false, }) public billingRecordsCorrectionMultiple: DialogComponent;
    @ViewChild('billingRecordsCorrection', { static: false, }) public billingRecordsCorrection: DialogComponent;
    public multiplePending: any;
    public multiPending: any;
    public invokeCall: any;
    private lastName: string;
    private ensembleId: string;
    private agentCuid: string;
    public user: Observable<User>;
    private userSubscription: Subscription;
    public isFinalDueDateZero: boolean = false;
    public userFriendlyHoldReason: string;
    public showOldLocation: boolean = false;
    public oldLocationDueDate: any;
    public currUrl: string;
    private flagStackOrder: boolean = false;
    private flagAmendOrder: boolean = false;
    public flagIsStackAmendCall: boolean = false;
    private sfdcAccountId: string;
    private sfdcBillingAccountID: string;
    private callStartTime: string;
    public ucid: string;
    public tfn: string;
    public unabletoStackMsg: string = '';
    public unabletoAmendMsg: string = '';
    public orderType: string = '';
    public unabletoCancelMsg: string = '';
    @ViewChild('stackAmendPopup', { static: false, }) public stackAmendPopupDialog: DialogComponent;
    @ViewChild('unableToStack', { static: false, }) public unableToStack: DialogComponent;
    @ViewChild('unableToAmend', { static: false, }) public unableToAmend: DialogComponent;
    @ViewChild('unableToCancel', { static: false, }) public unableToCancel: DialogComponent;
    public pendingOrders: any = [];
    public userData: any;
    public stackAllowed: any;
    public amendAllowed: any;
    public stackedOrders: any = [];
    public isStack: boolean = false;
    public showStackedOrder: boolean = false;
    @ViewChild('orderOnHold', { static: false, }) public orderOnHold: DialogComponent;
    public isCOR: boolean = false;
    public offerVariables: OfferVariables;
    public sup3AllowedOnCon: any;
    public pendingDueDate: any;
    public isOrderNIPending = false;
    public orderRemarks:any = [];
    public isBRProfile: boolean = false;

    constructor(
        private logger: Logger,
        private cancelService: PendingOrderService,
        private schedulingService: SchedulingService,
        private router: Router,
        private helperService: HelperService,
        private appStateService: AppStateService,
        public store: Store<AppStore>,
        private systemErrorService: SystemErrorService,
        private addressService: AddressService,
        private ctlHelperService: CTLHelperService,
        private offerHelperService: OfferHelperService) {
        this.appStateService.setLocationURLs();
        this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);
        this.isBRProfile = helperService.isAuthorized(ProfileEnums.ALLOW_B_AND_R_ORDER);
        this.existingProducts = <Observable<any>>store.select('existingProducts');
        this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
            if (data && data !== undefined && data.stackamend && data.stackamend !== undefined && data.stackamend.isStackAllowed && data.stackamend.isStackAllowed !== undefined) {
                this.stackAllowed = data.stackamend.isStackAllowed;
            }
            if (data && data !== undefined && data.stackamend && data.stackamend !== undefined && data.stackamend.isAmendAllowed && data.stackamend.isAmendAllowed !== undefined) {
                this.amendAllowed = data.stackamend.isAmendAllowed;
            }
            this.existingProdResponse = data;

            this.isExistingProd = data.existingProductsAndServices;
            if (this.existingProdResponse.orderFlow && this.existingProdResponse.orderFlow.flow) {
                this.existingFlow = this.existingProdResponse.orderFlow.flow;
                if (((this.existingFlow === "EXISTING") || (this.existingFlow === "Change" && this.stackAllowed)) && data.stackamend.stackAmendFlag !== "amendOrder") {
                    this.pendingExistingFlows = true;
                } else {
                    this.pendingExistingFlows = false;
                }
            }
            if (this.existingProdResponse && this.existingProdResponse.pendingOrders && this.existingProdResponse.pendingOrders.length > 0) {
                //record number of pending order pass to dialog component
                this.multiplePending = this.existingProdResponse.pendingOrders.length;
                if (this.existingProdResponse.pendingOrders.length > 1) {
                    this.unabletoStackMsg = 'multiple';
                    this.existingProdResponse.pendingOrders.map((order) => {
                        if (order.orderReference.customerOrderType !== "NEWINSTALL" && (order.orderReference.customerOrderStatus === "PENDING" || order.orderReference.customerOrderStatus === "IN-JEOPARDY")) {
                            this.stackedOrders = [order];
                            this.isStack = true;
                            // this.isCOR = true;
                        }
                        if (order.orderReference.customerOrderType === "NEWINSTALL" && order.orderReference.customerOrderStatus === "PENDING") {
                            this.isNewinstallFlag = true;
                            if (!this.isnotNiOrder) {
                                this.isnotNiOrder = true;
                                this.store.dispatch({ type: 'PENDING_SUMMARY', payload: order });
                            }
                        }

                    })
                }
            }
            if(this.existingProdResponse && this.existingProdResponse.pendingOrders) {
                this.existingProdResponse.pendingOrders.sort((b, a) => new Date(b.orderReference.orderDate).getTime() - new Date(a.orderReference.orderDate).getTime());
                this.pendingOrders = this.existingProdResponse.pendingOrders;
            }
            if(this.pendingOrders && 
                    (this.pendingOrders.length > 0) && 
                        this.pendingOrders[this.pendingOrders.length-1].orderDocument && 
                            this.pendingOrders[this.pendingOrders.length-1].orderDocument.schedule && 
                                this.pendingOrders[this.pendingOrders.length-1].orderDocument.schedule.dates && 
                                    this.pendingOrders[this.pendingOrders.length-1].orderDocument.schedule.dates.finalDueDate) {
                                        this.pendingDueDate = this.pendingOrders[this.pendingOrders.length-1].orderDocument.schedule.dates.finalDueDate;
            }
            if(this.existingProdResponse && this.existingProdResponse.pendingOrders) {
                this.store.dispatch({ type: 'B_AND_R_PENDING_SUMMARY', payload: this.existingProdResponse.pendingOrders[this.existingProdResponse.pendingOrders.length-1] });
            }
            if (this.existingProdResponse && this.existingProdResponse.existingProductsAndServices
                && this.existingProdResponse.existingProductsAndServices.length > 0 && this.existingProdResponse.existingProductsAndServices[0]
                && this.existingProdResponse.existingProductsAndServices[0] !== undefined
                && this.existingProdResponse.existingProductsAndServices[0].pendingOrders !== null
                && this.existingProdResponse.existingProductsAndServices[0].pendingOrders !== undefined
                && this.existingProdResponse.existingProductsAndServices[0].pendingOrders.length > 0) {
                if (this.existingProdResponse.existingProductsAndServices[0].pendingOrders[0].orderReference
                    && this.existingProdResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus === "PENDING"
                    && this.existingProdResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderType === "NONPAYSUSPEND") {
                    this.suspendActive = true;
                }
                if (this.existingProdResponse.existingProductsAndServices[0].pendingOrders[0].orderReference
                    && this.existingProdResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderType === "CHANGERESP") {
                    this.isCOR = true;
                }

            }

            //set NI Pending flag
            if (this.existingProdResponse && this.existingProdResponse.pendingOrders && this.existingProdResponse.pendingOrders.length > 0) {
                this.existingProdResponse.pendingOrders.map((po) => {
                    if (po.orderReference && po.orderReference.customerOrderStatus.toUpperCase() === "PENDING"
                        && po.orderReference.customerOrderType.toUpperCase() === "NEWINSTALL") {
                        this.isOrderNIPending = true;
                    }
                });
            }
        });
        this.pendingSummaryObservable = <Observable<any>>store.select('pending');
        this.pendingSummarySubscription = this.pendingSummaryObservable.subscribe((data) => {
            this.pendingSummarySplit(data);
        });
        this.pendingSummarySubscription.unsubscribe();
        this.getOrderProgressStatus();
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.currUrl = data.currentUrl;
            this.userData = data;
            if (data.autoLogin !== null && data.autoLogin !== undefined) {
                if (data.autoLogin.sfcData) {
                    this.sfdcAccountId = data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : '';
                    this.sfdcBillingAccountID = data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID : '';

                    if (data.autoLogin.sfcData.orderActivity) {
                        if (data.autoLogin.sfcData.orderActivity.callStartTime) {
                            this.callStartTime = data.autoLogin.sfcData.orderActivity.callStartTime;
                            if (this.callStartTime && this.callStartTime.length > 0 && this.callStartTime !== "NA") {
                                var UTCTime = moment.utc(this.callStartTime).toDate();
                                var MSTTime = moment(UTCTime).tz('America/Denver').format('YYYY-MM-DD HH:mm:ss');
                                this.callStartTime = MSTTime;
                            }
                            else {
                                this.callStartTime = "NA";
                            }
                        }
                        else {
                            this.callStartTime = "NA";
                        }
                        if (data.autoLogin.sfcData.orderActivity.ucid) {
                            this.ucid = data.autoLogin.sfcData.orderActivity.ucid;
                        }
                        else {
                            this.ucid = "NA";
                        }
                        if (data.autoLogin.sfcData.orderActivity.tfn) {
                            this.tfn = data.autoLogin.sfcData.orderActivity.tfn;
                        }
                        else {
                            this.tfn = "NA";
                        }
                    }
                    else {
                        this.callStartTime = "NA";
                        this.ucid = "NA";
                        this.tfn = "NA";
                    }
                    if (data.autoLogin && data.autoLogin.sfcData && data.autoLogin.sfcData.recommendedItems) {
                        this.recommendedItems = data.autoLogin.sfcData.recommendedItems;
                    }
                }
                if (data.autoLogin.oamData) {
                    this.agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    this.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    this.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    this.ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                }
            }
        })
        this.showStackedOrder = this.existingProdResponse && this.existingProdResponse.showStackedOrder ? this.existingProdResponse.showStackedOrder : false;
    }
    private maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }
    public gotoReviewOrder() {
        this.router.navigate(['/po-review-order']);
    }
    public getCustomerNameLabel() {
        switch (this.customerOrderType) {
            case 'NEWINSTALL': return 'New Customer';
            case 'CHANGE': return this.isStack ? 'Change Services' : 'Existing Customer';
            case 'MOVE': return 'Move Services';
            case 'DISCONNECT': return 'Existing Customer';
            case 'BILLANDREC': return 'Billing & Records Correction';
            case 'CHANGERESP': return 'Change Responsibility';
            default: return 'New Customer'
        }
    }
    public getToSuspendText() {
        this.suspendProdActive.open()
    }
    //determine which service address dialog or billing record dialog by number of pending orders
    public billingRecords() {
        if (this.multiplePending > 1) {
            this.invokeCall = "Billing Records Correction";
            this.billingRecordsCorrectionMultiple.open();
        } else {
            this.invokeCall = "Service Address";
            this.billingRecordsCorrection.open();
        }
    }
    public getServicActivationLabel() {
        switch (this.customerOrderType) {
            case 'NEWINSTALL': return 'Service Activation';
            case 'CHANGE': return 'Service Change';
            case 'MOVE': return 'Service Move';
            case 'DISCONNECT': return 'Service Disconnection';
            case 'BILLANDREC': return 'Scheduled for';
            default: return 'Service Activation'
        }
    }
    public getImagePath(productCategory) {
        if (productCategory) {
            switch (productCategory) {
                case 'INTERNET': return './assets/img/internet_sm.png';
                case GenericValues.sData || GenericValues.iData: return './assets/img/internet_sm.png';
                case GenericValues.cVideo: return './assets/img/prism_sm.png';
                case GenericValues.cDATVID: return './assets/img/prism_sm.png';
                case GenericValues.cDHP: return './assets/img/phone_sm.png';
                case GenericValues.cHP: return './assets/img/phone_sm.png';
                case GenericValues.cDTV: return './assets/img/directv-icon-small.png';
            }
        }
    }
    
    public getStatusInfo(statusObj, column) {
        let statusString = '';
        if (statusObj) {
            for (let i = 0; i < statusObj.length; i++) {
                if (column === 'pending' && !statusObj[i].isComplete) {
                    statusString = statusString + statusObj[i].status + ',';
                }
                else if (column === 'complete' && statusObj[i].isComplete) {
                    statusString = statusString + statusObj[i].status + ',';
                }
            }
        }
        if (statusString === '') {
            statusString = '----';
        }
        return statusString.substring(0, statusString.length - 1);
    }
    private retrieveSecurityDepositHistory() {
        this.loading = true;
        this.logger.log("info", "pending-order.component.ts", "getSecurityDepositHistoryRequest", JSON.stringify(this.ban));
        this.logger.startTime();
        this.cancelService.getSecurityDepositHistory(this.ban)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "pending-order.component.ts", "getSecurityDepositHistoryResponse", JSON.stringify(error));
                this.logger.log("error", "pending-order.component.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "retrieveSecurityDepositHistoryCall", "pending-order.component.ts", "Pending Order Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "pending-order.component.ts", "getSecurityDepositHistoryResponse", JSON.stringify(data));
                this.logger.log("info", "pending-order.component.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data && data.depositInfo && data.depositInfo.length > 0) {
                    this.store.dispatch({ type: 'SECURITY_DEPOSIT', payload: { deposit: data } });
                    this.reqDeposit = true;
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "pending-order.component.ts", "getSecurityDepositHistoryResponse", error);
                    this.logger.log("error", "pending-order.component.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "pending-order.component.ts", "Pending Order Page", this.apiResponseError);
                    } else {
                        let errorResponseArray: ErrorResponse[] = [];
                        let localErrorResponse: ErrorResponse = {
                            orderRefNumber: error.payload.orderReferenceNumber,
                            statusCode: serverErrorMessages.statusCode,
                            reasonCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDownSchedule01,
                            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                            serverDown: serverErrorMessages.serverDown
                        }
                        errorResponseArray.unshift(localErrorResponse);
                        let lAPIErrorLists: APIErrorLists = {
                            errorResponse: errorResponseArray
                        };
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "pending-order.component.ts", "Pending Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                })
    }
    private getOrderProgressStatus() {
        let requestObj = {
            requestOrderStatusInfo: [
                {
                    orderReferenceNumber: this.orderReference.orderReferenceNumber
                }
            ]
        }
        if (this.customerOrderType === 'BILLANDREC') {
            // Not Calling getOrderProgressStatus Service for B&R
        } else {
            this.loading = true;
            this.logger.log("info", "pending-order.component.ts", "getOrderProgressStatusRequest", JSON.stringify(requestObj));
            this.logger.startTime();
            let errorResolved = false;
            this.cancelService.getOrderProgressStatus(requestObj)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "pending-order.component.ts", "getOrderProgressStatusResponse", JSON.stringify(error));
                    this.logger.log("error", "pending-order.component.ts", "getOrderProgressStatusSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorResolved = true;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", 'Not Applicable',
                        "pendingOrderCancelServiceCall",
                        "pending-order.component.ts", "Pending Order Page",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "pending-order.component.ts", "getOrderProgressStatusResponse", JSON.stringify(data ? data : ''));
                        this.logger.log("info", "pending-order.component.ts", "getOrderProgressStatusSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        this.respData = data;
                        if (this.respData && this.respData.orderStatus && this.respData.orderStatus.length > 0) {
                            this.serviceStatus = this.respData.orderStatus[0].serviceStatus;
                            this.schedulingStatus = this.respData.orderStatus[0].schedulingStatus;
                            localStorage.setItem('serviceStatus', JSON.stringify(this.serviceStatus));
                        }
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("info", "pending-order.component.ts", "getOrderProgressStatusResponse", error);
                            this.logger.log("info", "pending-order.component.ts", "getOrderProgressStatusSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        if (error === undefined || error === null)
                            return;
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "PendinOrderCancelError", "pending-order.component.ts", "Pending Order Page", this.apiResponseError);
                        } else {
                            let errorResponseArray: ErrorResponse[] = [];
                            let localErrorResponse: ErrorResponse = {
                                orderRefNumber: error.payload.orderReferenceNumber,
                                statusCode: serverErrorMessages.statusCode,
                                reasonCode: serverErrorMessages.statusCode,
                                message: serverErrorMessages.serverDownSchedule01,
                                messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                                serverDown: serverErrorMessages.serverDown
                            }
                            errorResponseArray.unshift(localErrorResponse);
                            let lAPIErrorLists: APIErrorLists = {
                                errorResponse: errorResponseArray
                            };
                            this.systemErrorService.logAndeRouteToSystemError("error", "PendinOrderCancelError", "pending-order.component.ts", "Pending Order Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    });
        }
    }

    public findObjByName(list, fieldName, fieldVal, fieldName1 = undefined,
        fieldVal1 = undefined, prefix = undefined) {
        let foundObj;
        try {
            if (fieldName1 && fieldVal1 && prefix) {
                foundObj = list.find((obj) => {
                    return obj[prefix][fieldName] === fieldVal &&
                        obj[prefix][fieldName1].indexOf(fieldVal1) !== -1;
                });
            } else {
                foundObj = list.find((obj) => {
                    return obj[fieldName] === fieldVal;
                });
            }
        } catch (exception) {
        }
        return foundObj;
    }

    public clickedContinue(event) {
        this.isExistingProductsSelected = false;
        this.isDisconnectLandLineSelected = true;
    }

    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }
    public ngOnInit() {
        this.logger.metrics('PendingOrderPage');
        this.isLCAddress = this.helperService.isLCAddress();
        window.scroll(0, 0);
    }
    public ngAfterViewInit() {
        if (this.recommendedItems) {
            this.loading = false;
            this.recommendedError.open();
        }
        this.showStackedOrder = false;
    }
    public addRemarks() {
        this.scheduleDetails.apptNotes.notes = [];
        this.loading = true;
        let today = this.ctlHelperService.convertDateFormat(new Date())
        let newNote = {
            name:"Order Remarks",
            value: this.newRemark,
            date: today,
            author: this.firstName + ' ' + this.lastName,
        }
        if(newNote.value !== "" && newNote.name !== "" && newNote.date !== "" && newNote.author !== ""){
        this.scheduleDetails.apptNotes.notes.push(newNote);
        this.orderRemarks.push(newNote);
        }
        this.newRemarkUpdate(this.scheduleDetails.apptNotes.notes);
    }
    
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
    }

    public getScheduleInformation() {
        if (this.isCOR) {
            this.unabletoStackMsg = '';
            this.unableToStack.open();
            return;
        }

        let scheduleObj: any = {
            customerOrderNumber: this.responseData.orderReference.customerOrderNumber,
            salesChannel: "ESHOP-Customer Care",
            orderAction: "DUEDATECHANGE",
            sfdcAccountId: "123",
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            },
            addlOrderAttributes: [
                {
                    orderAttributeGroup: [
                        {
                            orderAttributeGroupName: "sfcAttrData",
                            orderAttributeGroupInfo: [
                                {
                                    orderAttributes: [
                                        {
                                            orderAttributeName: "tfn",
                                            orderAttributeValue: "NA"
                                        },
                                        {
                                            orderAttributeName: "ucid",
                                            orderAttributeValue: "NA"
                                        },
                                        {
                                            orderAttributeName: "callStartTime",
                                            orderAttributeValue: "NA"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        this.loading = true;
        this.logger.log("info", "pending-order.component.ts", "pendingReschduleAppointmentRequest", JSON.stringify(scheduleObj));
        this.logger.startTime();
        this.schedulingService.pendingRescheduleAppointment(scheduleObj)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "pending-order.component.ts", "pendingReschduleAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "pending-order.component.ts", "pendingReschduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "initSup2 - pendingRescheduleAppointment",
                    "pending-order.component.ts", "Pending Order Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((respData) => {
                this.logger.endTime();
                this.logger.log("info", "pending-order.component.ts", "pendingReschduleAppointmentResponse", JSON.stringify(respData));
                this.logger.log("info", "pending-order.component.ts", "pendingReschduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.scheduleResponse = respData;
                let PONRResponse = respData;
                if (PONRResponse.errorResponse !== null && PONRResponse.errorResponse !== undefined && PONRResponse.errorResponse) {
                    this.schedulingPONRDialog.open();
                } else {
                    this.store.dispatch({ type: 'DUE_DATE_SCHEDULE', payload: { schedule: respData } });
                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: this.scheduleResponse });
                    let orderFlow = { flow: "SUP2" }
                    this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
                    this.router.navigate(['/pending-schedule-appt']);
                }
                this.loading = false;
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "pending-order.component.ts", "pendingReschduleAppointmentResponse", JSON.stringify(error));
                    this.logger.log("error", "pending-order.component.ts", "pendingReschduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "pendingRescheduleAppointError", "pending-order.component.ts", "Pending Order Page", this.apiResponseError);
                    } else {
                        let errorResponseArray: ErrorResponse[] = [];
                        let localErrorResponse: ErrorResponse = {
                            orderRefNumber: error.payload.orderReferenceNumber,
                            statusCode: serverErrorMessages.statusCode,
                            reasonCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDownSchedule01,
                            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                            serverDown: serverErrorMessages.serverDown
                        }
                        errorResponseArray.unshift(localErrorResponse);
                        let lAPIErrorLists: APIErrorLists = {
                            errorResponse: errorResponseArray
                        };
                        this.systemErrorService.logAndeRouteToSystemError("error", "pendingRescheduleAppointError", "pending-order.component.ts", "Pending Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });

    }
    public getCancelOrder() {
        if (this.isCOR) {
            this.unabletoStackMsg = '';
            this.unableToStack.open();
            return;
        }
        if (this.existingProdResponse && this.existingProdResponse.pendingOrders && this.existingProdResponse.pendingOrders.length === 1)
            this.getCancelOrderCall();
        else if (this.existingProdResponse && this.existingProdResponse.existingProductsAndServices
            && this.existingProdResponse.existingProductsAndServices[0]
            && this.existingProdResponse.existingProductsAndServices[0].validateResponse
            && this.existingProdResponse.existingProductsAndServices[0].validateResponse[0]
            && this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].stackValidation
            && this.responseData
            && this.responseData.orderReference
            && this.responseData.orderReference.customerOrderNumber) {
            let sup1flag: boolean = false;
            if (this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].stackValidation.length > 0)
                this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].stackValidation.map((sup1Allowed) => {
                    if (sup1Allowed.attributeName === 'sup1AllowedOnStack') {
                        sup1flag = true;
                        if (sup1Allowed.attributeValue === this.responseData.orderReference.customerOrderNumber) {
                            this.getCancelOrderCall()
                        } else {
                            this.unabletoCancelMsg = "CancelNotAllowed"
                            this.unableToCancel.open();
                        }
                    }
                });
            else if (!sup1flag) {
                this.unabletoCancelMsg = "CancelNotAllowed"
                this.unableToCancel.open();
            } else {
                this.unabletoCancelMsg = "CancelNotAllowed"
                this.unableToCancel.open();
            }
        } else {
            this.unabletoCancelMsg = "CancelNotAllowed"
            this.unableToCancel.open();
        }
    }
    
    public splitDueDateEligibleCheck(addlOrderAttributes: any) {
        if (addlOrderAttributes && addlOrderAttributes[0].orderAttributeGroup.length > 0) {
            addlOrderAttributes[0].orderAttributeGroup.map((chkDueDate) => {
                if (chkDueDate.orderAttributeGroupName === "splitDueDateInfo") {
                    chkDueDate.orderAttributeGroupInfo.map((groupInfo => {
                        groupInfo.orderAttributes.map(odrAttributes => {
                            if (odrAttributes.orderAttributeName === "isSplitDueDateEligible" && (odrAttributes.orderAttributeValue === "Y" || odrAttributes.orderAttributeValue === "y")) {
                                this.showOldLocation = true;
                            }
                            if (odrAttributes.orderAttributeName === "fromFinalDueDate") {
                                this.oldLocationDueDate = odrAttributes.orderAttributeValue;
                            }
                        })
                    }))
                }
            })
        }
    }
    public serviceCategory() {
        if (this.existingProdResponse
            && this.existingProdResponse.existingProductsAndServices && this.existingProdResponse.existingProductsAndServices[0]) {
            let serviceCategories = this.existingProdResponse.existingProductsAndServices[0].serviceCategory;
            let internetCheck = false;
            let videoAvail = false;
            let phoneAvail: boolean = false;
            let phoneType = [];
            let videoType = [];
            if (serviceCategories !== undefined) {
                serviceCategories.map((item) => {
                    if (item.serviceCategory === GenericValues.sData) {
                        internetCheck = true;
                    }
                    if (item.serviceCategory === 'DATA/VIDEO') {
                        videoAvail = true;
                        videoType.push({
                            name: 'DATA/VIDEO',
                            displayName: 'PRISM TV',
                            code: 'PTV',
                            tabName: 'PRISM'
                        });
                    }
                    if (item.serviceCategory === 'VIDEO-DTV') {
                        videoAvail = true;
                        videoType.push({
                            name: 'VIDEO-DTV',
                            displayName: 'DIRECTV',
                            code: 'DTV',
                            tabName: 'DIRECTV'
                        });
                    }
                    if (item.serviceCategory === 'VOICE-DHP') {
                        phoneAvail = true;
                        phoneType.push({
                            name: 'VOICE-DHP',
                            displayName: 'Digital(DHP)',
                            code: 'DHP',
                            tabName: 'DHP'
                        });
                    }
                    if (item.serviceCategory === 'VOICE-HP') {
                        phoneAvail = true;
                        phoneType.push({
                            name: 'VOICE-HP',
                            displayName: 'Home Phone',
                            code: 'HMP',
                            tabName: 'Home Phone'
                        });
                    }
                });
            }
            let user: User = {
                id: 1,
                internetCheck,
                videoCheck: videoAvail,
                phoneCheck: phoneAvail,
                phoneType: phoneType,
                videoType: videoType,
                enabledServiceList: serviceCategories,
                ban: this.existingProdResponse.existingProductsAndServices[0].accountInfo.ban
            };
            let orderFlow = {
                flow: "Change"
            }
            this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
            this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
        }
    }
    public stackAmendPopupDecider() {
        let flagPonr = "AnyThingButPENDING_ORDER_CROSSED_PONR";
        this.unabletoStackMsg = '';
        //Getting the CON allowed for amend in case of multiple pending orders
        if (this.existingProdResponse.pendingOrders.length > 1 && Switch.amendMultiple) {
            if (this.existingProdResponse.existingProductsAndServices
                && this.existingProdResponse.existingProductsAndServices.length > 0
                && this.existingProdResponse.existingProductsAndServices[0].validateResponse
                && this.existingProdResponse.existingProductsAndServices[0].validateResponse.length > 0
                && this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].stackValidation) {
                this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].stackValidation.map((supAllowed) => {
                    if (supAllowed.attributeName === 'sup3AllowedOnStack') {
                        this.sup3AllowedOnCon = supAllowed.attributeValue;
                    }
                });
            }
            this.store.dispatch({ type: 'SUP3_ALLOWED_CON', payload: this.sup3AllowedOnCon });
        }
        if (this.isCOR) {
            this.unabletoStackMsg = '';
            this.unableToStack.open();
        } else if (this.existingProdResponse.pendingOrders.length > 2) {
            this.unabletoStackMsg = 'multiple';
            this.unableToStack.open();
        } else if (this.responseData && this.responseData.orderReference && this.responseData.orderReference.customerOrderStatus && this.responseData.orderReference.customerOrderStatus === 'IN-JEOPARDY') {
            this.unabletoStackMsg = 'jeopardy';
            this.unableToStack.open();
        } else if (this.responseData && this.responseData.orderReference && this.responseData.orderReference.customerOrderStatus && this.responseData.orderReference.customerOrderStatus === 'HOLD') {
            this.unabletoStackMsg = 'hold';
            this.unableToStack.open();
        } else if (this.responseData && this.responseData.orderReference && (this.responseData.orderReference.customerOrderType === "VACATIONSUSPEND" || this.responseData.orderReference.customerOrderType === "NONPAYSUSPEND" || this.responseData.orderReference.customerOrderType === "NONPAYRESTORE" || this.responseData.orderReference.customerOrderType === "DISCONNECT" || this.responseData.orderReference.customerOrderType === "MOVE" || this.responseData.orderReference.customerOrderType === "BILLANDREC")) {
            if (this.responseData.orderReference.customerOrderType === "VACATIONSUSPEND") this.unabletoStackMsg = 'vacation';
            if (this.responseData.orderReference.customerOrderType === "NONPAYSUSPEND" || this.responseData.orderReference.customerOrderType === "NONPAYRESTORE") this.unabletoStackMsg = 'nopay';
            if (this.responseData.orderReference.customerOrderType === "DISCONNECT") this.unabletoStackMsg = 'disconnect';
            if (this.responseData.orderReference.customerOrderType === "MOVE") this.unabletoStackMsg = 'move';
            if (this.responseData.orderReference.customerOrderType === "BILLANDREC") this.unabletoStackMsg = 'billandrec';
            this.orderType = this.cancelService.setOrderTypeText(this.responseData.orderReference.customerOrderType);
            this.unableToStack.open();
        } else if (this.existingProdResponse.pendingOrders.length === 2 && this.sup3AllowedOnCon !== this.orderReference.customerOrderNumber) {
            if (Switch.amendMultiple) {
                this.unabletoAmendMsg = 'laterorder';
                this.unableToAmend.open();
            } else {
                this.unabletoStackMsg = 'multiple';
                this.unableToStack.open();
            }
        } else if (this.responseData && this.responseData.orderReference && this.responseData.orderReference.customerOrderStatus
            && this.responseData.orderReference.customerOrderStatus.toUpperCase() === 'PENDING' && flagPonr !== "PENDING_ORDER_CROSSED_PONR") {
            if (this.existingProdResponse.pendingOrders.length === 2 && this.sup3AllowedOnCon && this.sup3AllowedOnCon === this.orderReference.customerOrderNumber) {
                this.onEmitStackAmend('amendOrder');
                this.loading = true;
            } else if (this.existingProdResponse.stackamend.isStackAllowed === 'true' && this.existingProdResponse.stackamend.isAmendAllowed === 'true') {
                this.stackAmendPopupDialog.open();
            } else if (this.existingProdResponse.stackamend.isStackAllowed === 'true' && this.existingProdResponse.stackamend.isAmendAllowed === 'false') {
                let amendCheckForAgents: boolean = this.amendEligibilityCheckForAgents();
                if (amendCheckForAgents) {
                    this.stackAmendPopupDialog.open();
                } else {
                    if (this.existingProdResponse.stackamend.isStackAllowed === 'true' && this.existingProdResponse.stackamend.isAmendAllowed === 'false' && !this.enableSups && !this.offerVariables.isPrepaid) {
                        this.onEmitStackAmend('stackOrder')
                        this.loading = true;
                    } else if (this.existingProdResponse.stackamend.isStackAllowed === 'true' && this.existingProdResponse.stackamend.isAmendAllowed === 'false' && this.enableSups) {
                        this.unabletoAmendMsg = 'default';
                        this.unableToAmend.open();
                    } else {
                        this.unabletoAmendMsg = 'default';
                        this.unableToAmend.open();
                    }
                }
            } else if (this.existingProdResponse.stackamend.isStackAllowed === 'false' && this.existingProdResponse.stackamend.isAmendAllowed === 'true') {
                this.onEmitStackAmend('amendOrder')
                this.loading = true;
            } else if (this.existingProdResponse.stackamend.isStackAllowed === 'false' && this.existingProdResponse.stackamend.isAmendAllowed === 'false') {
                let amendCheckForAgents: boolean = this.amendEligibilityCheckForAgents();
                if (amendCheckForAgents) {
                    this.onEmitStackAmend('amendOrder')
                    this.loading = true;
                } else {
                    this.orderType = this.cancelService.setOrderTypeText(this.responseData.orderReference.customerOrderType);
                    let exsPrdRes = this.existingProdResponse.existingProductsAndServices[0].validateResponse[0];
                    exsPrdRes && exsPrdRes.stackValidation && exsPrdRes.stackValidation.map(a => {
                        if (a.attributeName === "stackIneligibleReasonCode" && a.attributeValue.indexOf("PORTIN") !== -1) {
                            this.unabletoStackMsg = 'portin';
                        } else if (a.attributeName === "stackIneligibleReasonCode" && a.attributeValue.indexOf("ORDER_TYPE_NOT_SUPPORTED") !== -1) {
                            this.unabletoStackMsg = 'orderNotSupport';
                        }
                    })
                    this.unableToStack.open();
                }
            } else {
                this.goToChangeProduct();
            }
        } else {
            this.goToChangeProduct();
        }
    }
    public amendEligibilityCheckForAgents(): boolean {
        let amendIneligiblecheck: boolean = false;
        let amendProfileCheck: boolean = false;
        this.existingProdResponse && this.existingProdResponse.existingProductsAndServices && this.existingProdResponse.existingProductsAndServices[0] &&
            this.existingProdResponse.existingProductsAndServices[0].validateResponse && this.existingProdResponse.existingProductsAndServices[0].validateResponse[0] &&
            this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].amendValidation &&
            this.existingProdResponse.existingProductsAndServices[0].validateResponse[0].amendValidation.map(amend => {
                if (amend.attributeName.trim() === 'amendIneligibleExceptionCode' && amend.attributeValue.trim() === 'DueTodayOrPast') {
                    amendIneligiblecheck = true;
                }
            });
        amendProfileCheck = this.helperService.isAuthorized(ProfileEnums.ALLOW_CURRENT_DUE_DATE);
        if (amendIneligiblecheck && amendProfileCheck) {
            return true;
        } else {
            this.unabletoAmendMsg = 'Order is PONR';
            return false;
        }
    }
    public onEmitStackAmend(stackAmendFlag) {
        let payload = this.existingProdResponse.stackamend
        payload['stackAmendFlag'] = stackAmendFlag;
        if (stackAmendFlag === 'stackOrder') {
            this.flagStackOrder = true;
            this.flagAmendOrder = false;
        } else if (stackAmendFlag === 'amendOrder') {
            this.flagStackOrder = false;
            this.flagAmendOrder = true;
        }
        this.store.dispatch({ type: 'STACK_AMEND', payload: payload });
        this.store.dispatch({ type: 'NI_PENDING_STACK_AMEND', payload: this.isOrderNIPending });
        this.flagIsStackAmendCall = true;
        this.goToChangeProduct();
    }
    public checkMultiPendingOrOthers() {
        if (this.isCOR) {
            this.unabletoStackMsg = '';
            this.unableToStack.open();
        } else {
            this.schedulingPONRDialog.open()
        }
    }
    // Stack Amend API method, redirect to offer page
    public goToChangeProduct() {
        this.loading = true;
        let request;
        request = {
            ban: this.existingProdResponse.existingProductsAndServices[0].accountInfo.ban,
            customerOrderType: this.flagStackOrder ? 'CHANGE' : this.responseData.orderReference.customerOrderType,
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            },
            salesChannel: "ESHOP-Customer Care",
            serviceAddress: {
                city: "",
                country: "",
                geoAddressId: "",
                locality: "",
                postCode: "",
                postCodeSuffix: "",
                source: "",
                sourceId: "",
                stateOrProvince: "",
                streetAddress: "",
                streetName: "",
                streetNrFirst: "",
                streetNrFirstSuffix: "",
                streetNrLast: "",
                streetNrLastSuffix: "",
                streetType: "",
                subAddress: {
                    combinedDesignator: "",
                    elements: {
                        designator: "",
                        value: ""
                    },
                    geoSubAddressId: "",
                    source: "",
                    sourceId: ""
                }
            },
        }
        if (this.sfdcBillingAccountID && this.sfdcAccountId) {
            request.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
        }
        this.serviceCategory();
        request['isStackOrder'] = this.flagStackOrder;
        request['isAmendOrder'] = this.flagAmendOrder;
        request['customerOrderNumber'] = this.responseData.orderReference.customerOrderNumber;
        this.logger.log("info", "pendingOrder.component.ts", "getInitChangeCallRequest", JSON.stringify(request));
        this.logger.startTime();
        this.addressService.getInitChangeCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "pendingOrder.component.ts", "getInitChangeCallResponse", error);
                this.logger.log("error", "pendingOrder.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "pendingOrder.component.ts", "Pending Order Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "pendingOrder.component.ts", "getInitChangeCallResponse", JSON.stringify(data));
                this.logger.log("info", "pendingOrder.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.store.dispatch({ type: 'CHANGE_ORDER_INIT', payload: data });
                this.updateAvail(data);
                this.router.navigate(['/stack-amend-product']);
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "pendingOrder.component.ts", "getInitChangeCallResponse", error);
                    this.logger.log("error", "pendingOrder.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "pendingOrder.component.ts", "Pending Order Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.responseData.orderReference.orderReferenceNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "pendingOrder.component.ts", "Pending Order Page", lAPIErrorLists);
                    }
                });
    }
    public updateAvail(data) {
        let internetCheck;
        let videoAvail;
        let phoneAvail: boolean = false;
        let phoneType = [];
        let videoType = [];
        let serviceCategory;
        if (data && data.payload && data.payload.existingServices && data.payload.existingServices.existingServiceItems) {
            data.payload.existingServices.existingServiceItems.map((existsItem) => {
                if (((existsItem.offerCategory === 'VOICE-HP') || (existsItem.offerCategory === 'INTERNET' || existsItem.offerCategory === 'DATA') || (existsItem.offerCategory === 'VOICE-DHP') || (existsItem.offerCategory === 'VIDEO-DTV')) && (existsItem.offerType !== 'SUBOFFER')) {
                    this.store.dispatch({ type: 'EXISTING_OFFER_NAME', payload: existsItem.offerName });
                }
            });
        }
        if (data && data.payload && data.payload.serviceCategory) {
            serviceCategory = data.payload.serviceCategory;
            serviceCategory.map((item) => {
                if (item.serviceCategory === GenericValues.sData || item.serviceCategory === GenericValues.iData) {
                    internetCheck = true;
                }
                if (item.serviceCategory === GenericValues.cDTV) {
                    videoAvail = true;
                    videoType.push({
                        name: 'VIDEO-DTV',
                        displayName: 'DIRECTV',
                        code: 'DTV',
                        tabName: 'DIRECTV'
                    });
                }
                if (item.serviceCategory === GenericValues.cDHP) {
                    phoneAvail = true;
                    phoneType.push({
                        name: 'VOICE-DHP',
                        displayName: 'Digital(DHP)',
                        code: 'DHP',
                        tabName: 'DHP'
                    });
                }
                if (item.serviceCategory === GenericValues.cHP) {
                    phoneAvail = true;
                    phoneType.push({
                        name: 'VOICE-HP',
                        displayName: 'Home Phone',
                        code: 'HMP',
                        tabName: 'Home Phone'
                    });
                }
            });
        }
        let user: User = {
            id: 1,
            internetCheck,
            videoCheck: videoAvail,
            phoneCheck: phoneAvail,
            phoneType: phoneType,
            videoType: videoType,
            enabledServiceList: serviceCategory,
            ban: data.ban ? data.ban : ""
        };
        this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
    }
    public pendingSummarySplit(data) {
        if (data && data.orderDocument && data.orderDocument.schedule) {
            if (data.orderDocument.schedule.dates && data.orderDocument.schedule.dates.finalDueDate && data.orderDocument.schedule.dates.finalDueDate === '0000-00-00T00:00:00.000Z') {
                this.isFinalDueDateZero = true;
            }
        };
        if (data && data.orderReference && data.orderReference.reason && data.orderReference.reason[0] && data.orderReference.reason[0].description) {
            this.userFriendlyHoldReason = data.orderReference.reason[0].description;
        };
        this.responseData = data;
        this.accountInfo = data.orderDocument.accountInfo;
        this.accountInfo.billingType === 'PREPAID' ? this.offerVariables.isPrepaid = true : this.offerVariables.isPrepaid = false;
        this.store.dispatch({ type: 'PREPAID_FLAG', payload: this.accountInfo.billingType });
        this.orderReference = data.orderReference;
        this.enableSups = this.orderReference.pointOfNoReturn;
        this.customerOrderType = this.orderReference.customerOrderType;
        this.customerOrderStatus = this.orderReference.customerOrderStatus;
        this.serviceAddress = data.orderDocument.serviceAddress;
        this.legacy = this.serviceAddress.locationAttributes.legacyProvider;
        this.scheduleDetails = data.orderDocument.schedule;
        this.orderRemarks = this.scheduleDetails.apptNotes.notes;
        this.productItems = data.orderDocument.customerOrderItems;
        this.internetItems = this.productItems[0].customerOrderSubItems;
        this.splitDueDateEligibleCheck(data.orderDocument.addlOrderAttributes);
        data.orderDocument.reservedTN && data.orderDocument.reservedTN.map(item => {
            if (item.productType === GenericValues.sData || item.productType === GenericValues.iData) {
                this.dataTN = this.maskPhone(item.requestedTelephoneNumber);
            }
            if ((item.productType === GenericValues.cDHP || item.productType === GenericValues.cHP) && item.tnType === 'EXTPORTED') {
                this.isportedTNExists = true;
            }
            if (item.productType === 'VOICE-HP') {
                this.potsTN = this.maskPhone(item.requestedTelephoneNumber);
                this.potsTNshow = true;
            }
        })
        let a = this.findObjByName(this.internetItems, 'componentType', 'PRIMARY');
        this.userProductList.push(a);
        if (data.orderDocument.creditReview.depositInfo.depositRequired) {
            this.ban = data.orderDocument.accountInfo.ban;
            this.retrieveSecurityDepositHistory();
        }
    }
    public summaryClicked(event, ni?: any) {
        this.potsTNshow = false;
        if (!ni) {
            this.showStackedOrder = true;
            this.store.dispatch({ type: 'PENDING_SUMMARY', payload: this.stackedOrders[event] });
            this.store.dispatch({ type: 'SHOW_STACKED_ORDER', payload: { showStackedOrder: this.showStackedOrder } });
            this.pendingSummarySplit(this.stackedOrders[event]);
            this.getOrderProgressStatus();
        } else {
            this.existingProdResponse.pendingOrders.map((order) => {
                if (order.orderReference.customerOrderType === "NEWINSTALL" && order.orderReference.customerOrderStatus === "PENDING") {
                    this.showStackedOrder = false;
                    this.store.dispatch({ type: 'PENDING_SUMMARY', payload: order });
                    this.store.dispatch({ type: 'SHOW_STACKED_ORDER', payload: { showStackedOrder: this.showStackedOrder } });
                    this.pendingSummarySplit(order);
                    this.getOrderProgressStatus();
                }
            })
        }
    }
    public getOrderTypeText(value: any) {
        return this.cancelService.setOrderTypeText(value);
    }
    public placeOnHold() {
        if (this.isCOR) {
            this.unabletoStackMsg = '';
            this.unableToStack.open();
        } else if (this.enableSups && this.customerOrderStatus !== 'HOLD' && this.suspendActive) {
            this.getToSuspendText();
        } else if (!this.enableSups && this.customerOrderStatus !== 'HOLD' && this.suspendActive) {
            this.getToSuspendText();
        } else if (this.enableSups && this.customerOrderStatus !== 'HOLD' && !this.suspendActive) {
            this.onHoldOrderPONRDialog.open(); // if PONR as true
        } else if (!this.enableSups && this.customerOrderStatus !== 'HOLD' && !this.suspendActive) {
            this.orderOnHold.open();
        }
    }
    public getCancelOrderCall() {
        let cancelobj: any = {
            customerOrderNumber: this.responseData.orderReference.customerOrderNumber,
            salesChannel: "ESHOP-Customer Care",
            orderAction: "CANCEL",
            sfdcAccountId: "123",
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            }
        };
        this.loading = true;
        this.logger.log("info", "pending-order.component.ts", "getCancelOrderInformationRequest", JSON.stringify(cancelobj));
        this.logger.startTime();
        this.cancelService.getCancelOrderInformation(cancelobj)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "pending-order.component.ts", "getCancelOrderInformationResponse", JSON.stringify(error));
                this.logger.log("error", "pending-order.component.ts", "getCancelOrderInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "initSup1 - getCancelOrderInformation", "pending-order.component.ts", "Pending Order Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "pending-order.component.ts", "getCancelOrderInformationResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "pending-order.component.ts", "getCancelOrderInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.respData = data;
                    this.loading = false;
                    this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: data.orderRefNumber });
                    let PONRResponse = data;
                    if (PONRResponse.errorResponse !== null && PONRResponse.errorResponse !== undefined && PONRResponse.errorResponse) {
                        this.cancelOrderPONRDialog.open();
                    }
                    if (this.respData && this.respData.payload && this.respData.payload.reason !== undefined) {
                        this.reasonsList = this.respData.payload.reason;
                        if (this.reqDeposit) {
                            this.cancelSup1DialogDeposit.open();
                        } else if (this.offerVariables.isPrepaid) {
                            this.cancelPrepaidOrder.open();
                        } else {
                            this.cancelSup1Dialog.open();
                        }
                        this.store.dispatch({ type: 'CANCEL_ORDER', payload: data });
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "pending-order.component.ts", "getCancelOrderInformationResponse", error);
                    this.logger.log("error", "pending-order.component.ts", "getCancelOrderInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "CancelOrderReqError", "pending-order.component.ts", "Pending Order Page", this.apiResponseError);
                    } else {
                        let errorResponseArray: ErrorResponse[] = [];
                        let localErrorResponse: ErrorResponse = {
                            orderRefNumber: error.payload.orderReferenceNumber,
                            statusCode: serverErrorMessages.statusCode,
                            reasonCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDownSchedule01,
                            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                            serverDown: serverErrorMessages.serverDown
                        }
                        errorResponseArray.unshift(localErrorResponse);
                        let lAPIErrorLists: APIErrorLists = {
                            errorResponse: errorResponseArray
                        };
                        this.systemErrorService.logAndeRouteToSystemError("error", "CancelOrderReqError", "pending-order.component.ts", "Pending Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public newRemarkUpdate(notes) {
        this.isOrderRemarksSuccess = false;
        this.isOrderRemarksFailure   = false;        
        let remarkUpdate: any = {
            customerOrderNumber: this.responseData.orderReference.customerOrderNumber,
            salesChannel: "ESHOP-Customer Care",
            orderAction: "REMARKUPDATE",
            sfdcAccountId: "123",
            notes: notes,
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            }
        };
        this.loading = false;
        this.logger.log("info", "pending-order.component.ts", "newRemarkUpdateRequest", JSON.stringify(remarkUpdate));
        this.logger.startTime();
        this.cancelService.getremarkUpdateInformation(remarkUpdate)
        .catch ((error: any) => {
            this.logger.endTime();
            this.logger.log("error", "pending-order.component.ts", "newRemarkUpdateResponse", JSON.stringify(error));
            this.logger.log("error", "pending-order.component.ts", "newRemarkUpdateSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;
            this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "newRemarkUpdate", "pending-order.component.ts", "Pending Order Page", error);
            return Observable.throwError(null);
        })
        .subscribe(data => {
            this.logger.endTime();
            this.logger.log("info", "dialog.component.ts", "newRemarkUpdateResponse", JSON.stringify(data ? data : ""));
            this.logger.log("info", "dialog.component.ts", "newRemarkUpdateSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
            this.loading = false;
            if(data && data.payload && data.payload !== undefined && data.payload.message && data.payload.message !== undefined && data.payload.message === "Order Remarks Updated Successfully"){
                this.isOrderRemarksSuccess = true;
            } else{
                this.isOrderRemarksFailure   = true;               
            }
            if (!this.isOrderRemarksSuccess) {
                this.scheduleDetails.apptNotes.notes.pop();            
            }
        }, error => {
            this.logger.endTime();
            this.logger.log("error", "pending-order.component.ts", "newRemarkUpdateResponse", JSON.stringify(error));
            this.logger.log("error", "pending-order.component.ts", "newRemarkUpdateSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;
            if (!this.isOrderRemarksSuccess) {
                this.scheduleDetails.apptNotes.notes.pop();            
            }
        })
    }
}