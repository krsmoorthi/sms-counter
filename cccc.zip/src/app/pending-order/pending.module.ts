import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { PendingOrderComponent } from './pending-order.component';
import { SharedModule } from '../shared/shared.module';
import { CountryStateService } from '../common/service/country-state.service';
import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from '../common/service/text-mask.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TypeaheadModule } from 'ngx-bootstrap';
import { PendingOrderService } from '../common/service/pending-order.service';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { FirstCustomizePipeSharedModule } from 'app/shared/first-customize-pipe-shared.module';
 
export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: PendingOrderComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        TextMaskModule,
        TypeaheadModule,
        FirstCustomizePipeSharedModule
    ],
    exports: [
        PendingOrderComponent,
    ],
    declarations: [
        PendingOrderComponent
    ],
    providers: [
        CountryStateService,
        TextMaskService,
        PendingOrderService
    ]
})
export class PendingModule { }
