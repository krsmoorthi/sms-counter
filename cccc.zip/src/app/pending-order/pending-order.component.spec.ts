import { PendingOrderComponent } from "./pending-order.component";
import { ComponentFixture, async, TestBed } from '@angular/core/testing';
import { MockServer } from 'app/MockServer.test';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger, MockAppStateService, MockPendingOrderService, MockSchedulingService, MockRouter, MockHelperService, MockAddressService, MockOfferHelperService, MockReviewOrderService, MockAccountService, MockDisconnectService, MockProductService, MockBlueMarbleService, MockDirectvService, MockAuthService } from 'app/common/service/mockServices.test';
import { AppStateService } from 'app/common/service/app-state.service';
import { Store } from '@ngrx/store';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { SchedulingService } from 'app/common/service/scheduling.service';
import { Router, Routes } from '@angular/router';
import { HelperService } from 'app/common/service/helper.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { AddressService } from 'app/common/service/address.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { DomSanitizer } from '@angular/platform-browser';
import { AccountService } from 'app/common/service/account.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { DirectvService } from 'app/common/service/directv.services';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CountryStateService } from 'app/common/service/country-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { AccordionModule, TabsModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of, Observable, throwError } from 'rxjs';
import { FirstCustomizePipe } from 'app/common/pipes/firstcapcustom.pipe';
import { FirstCustomizePipeSharedModule } from 'app/shared/first-customize-pipe-shared.module';
import { AuthService } from 'app/common/service/auth.service';
import { GenericValues } from 'app/common/models/common.model';
import { HttpResponse } from '@angular/common/http';

describe('PendingOrder', () => {
    let component: PendingOrderComponent;
    let fixture: ComponentFixture<PendingOrderComponent>;
    let cancelService: PendingOrderService;
    const mockServer = new MockServer();
    const routes: Routes = [
        {
          path: "",
          component: PendingOrderComponent
        }
    ];

    let mockRouter = {
        navigate: jasmine.createSpy('navigate')
      }

    const imports = [
      FormsModule,
      ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
      TabsModule.forRoot(),
      AccordionModule.forRoot(),
      TextMaskModule,
      SharedCommonModule,
      SharedModule,
      RouterTestingModule.withRoutes(routes),
      BrowserAnimationsModule,
      FirstCustomizePipeSharedModule
    ];
  
    const mockRedux: any = {
      dispatch() { },
      configureStore() { },
      select(reducer) {
        return of(
          mockServer.getMockStore("HSI-pending-order")[reducer]
        );
      },
      take<T>(this: Observable<T>, count: number) {
        return of(null);
      }
    };
  
    class MockPendingOrderService {
      getremarkUpdateInformation() {
        return of(mockServer.getResponseForReducerAndApi('pending-add-remarks'));
      }

      getCancelOrderInformation(){
        return of(mockServer.getResponseForReducerAndApi('pending-cancel-order'));
      }
      getOrderSummary() {
        return of(new HttpResponse({}));
      }
      getExistingDiscountsByBan() {
          return of(new HttpResponse({}));
      }
      getOrderProgressStatus() {
        return of(mockServer.getResponseForReducerAndApi('pending-getorderprogressstatus'));
      }
    }
    
    class MockAddressService {
      getInitChangeCall(){
        return of(mockServer.getResponseForReducerAndApi('pending-stackamend-init'));
      }
    }

    class MockSchedulingService {
      pendingRescheduleAppointment(){
        return of(mockServer.getResponseForReducerAndApi('pending-scheduling-init'));
      }
    }

  
    const p1 = {provide: Logger, useClass: MockLogger};
    const p2 = {provide: AppStateService, useClass: MockAppStateService};
    const p3 = {provide: Store, useValue: mockRedux};
    const p4 = {provide: PendingOrderService, useClass: MockPendingOrderService};
    const p5 = {provide: SchedulingService, useClass: MockSchedulingService};
    const p6 = {provide: Router, useValue: mockRouter};
    const p7 = HelperService
    const p8 = SystemErrorService;
    const p9 = {provide: AddressService, useClass: MockAddressService};
    const p10 =  CTLHelperService;
    const p11 = {provide: OfferHelperService, useClass: MockOfferHelperService};
    const p12 = { provide: ReviewOrderService, useClass: MockReviewOrderService }
    const p13 = { provide: DomSanitizer,useValue: {sanitize: (ctx, val) => val, bypassSecurityTrustResourceUrl: val => val,},};
    const p14 = { provide: AccountService , useClass: MockAccountService};
    const p15 = { provide: DisconnectService , useClass: MockDisconnectService};
    const p16 = { provide: ProductService , useClass: MockProductService};
    const p17 = { provide: BlueMarbleService , useClass: MockBlueMarbleService};
    const p18 = FormBuilder;
    const p19 = CountryStateService;
    const p20 = TextMaskService;
    const p21 = { provide: DirectvService , useClass: MockDirectvService};
    const p22 = PropertiesHelperService;
    const p23 = FirstCustomizePipe;
    const p24 = { provide: AuthService , useClass: MockAuthService };
    const providers = [p1,p2,p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24];
    
    describe('HSI Pending Order Summary', () => {
      beforeEach(async(() => {
        
      }));
    
      beforeEach(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
          imports: imports,
          declarations: [ PendingOrderComponent ],
          providers: providers
        })
        .compileComponents();
        fixture = TestBed.createComponent(PendingOrderComponent);
        component = fixture.componentInstance;
        cancelService = TestBed.get(PendingOrderService);
        fixture.detectChanges();
      });

      it("should create Pending Order Component", () => {
        expect(component).toBeTruthy();
      });

      it("should navigate to porevieworder when gotoReviewOrder is called", () => {
        component.gotoReviewOrder();
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/po-review-order']);
      });

      it("should return customer label when getCustomerNameLabel is called", ()=> {
          component.customerOrderType = "NEWINSTALL";
          let returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("New Customer");
          component.customerOrderType = "CHANGE";
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("Existing Customer");
          component.customerOrderType = "CHANGE";
          component.isStack = true;
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("Change Services");
          component.customerOrderType = "MOVE";
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("Move Services");
          component.customerOrderType = "DISCONNECT";
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("Existing Customer");
          component.customerOrderType = "BILLANDREC";
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("Billing & Records Correction");
          component.customerOrderType = "CHANGERESP";
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("Change Responsibility");
          component.customerOrderType = "NOFLOW";
          returnValue = component.getCustomerNameLabel();
          expect(returnValue).toBe("New Customer");
      })

      it("should open suspendProdActive Dialog when getToSuspendText is called", ()=> {
          spyOn(component.suspendProdActive, 'open');
          component.getToSuspendText();
          expect(component.suspendProdActive.open).toHaveBeenCalled();
      });

      it("should open respective service adddress dialog based on multiplepending when billingRecords is called", ()=>{
        spyOn(component.billingRecordsCorrectionMultiple, 'open');
        spyOn(component.billingRecordsCorrection, 'open');
        component.multiplePending = 2;
        component.billingRecords();
        expect(component.invokeCall).toBe("Billing Records Correction");
        expect(component.billingRecordsCorrectionMultiple.open).toHaveBeenCalled();
        expect(component.billingRecordsCorrection.open).toHaveBeenCalledTimes(0);
        
        component.multiplePending = 1;
        component.billingRecords();
        expect(component.invokeCall).toBe("Service Address");
        expect(component.billingRecordsCorrection.open).toHaveBeenCalled();
      })

      it("should return service activation label when getServicActivationLabel is called", ()=> {
        component.customerOrderType = "NEWINSTALL";
        let returnValue = component.getServicActivationLabel();
        expect(returnValue).toBe("Service Activation");
        component.customerOrderType = "CHANGE";
        returnValue = component.getServicActivationLabel();
        expect(returnValue).toBe("Service Change");
        component.customerOrderType = "MOVE";
        returnValue = component.getServicActivationLabel();
        expect(returnValue).toBe("Service Move");
        component.customerOrderType = "DISCONNECT";
        returnValue = component.getServicActivationLabel();
        expect(returnValue).toBe("Service Disconnection");
        component.customerOrderType = "BILLANDREC";
        returnValue = component.getServicActivationLabel();
        expect(returnValue).toBe("Scheduled for");
        component.customerOrderType = "NOFLOW";
        returnValue = component.getServicActivationLabel();
        expect(returnValue).toBe("Service Activation");
    })

    it("should return image path when getImagePath is called", ()=> {
      let returnValue = component.getImagePath('INTERNET');
      expect(returnValue).toBe("./assets/img/internet_sm.png");
      returnValue = component.getImagePath(GenericValues.sData);
      expect(returnValue).toBe("./assets/img/internet_sm.png");
      returnValue = component.getImagePath(GenericValues.iData);
      expect(returnValue).toBe("./assets/img/internet_sm.png");
      returnValue = component.getImagePath(GenericValues.cVideo);
      expect(returnValue).toBe("./assets/img/prism_sm.png");
      returnValue = component.getImagePath(GenericValues.cDATVID);
      expect(returnValue).toBe("./assets/img/prism_sm.png");
      returnValue = component.getImagePath(GenericValues.cDHP);
      expect(returnValue).toBe("./assets/img/phone_sm.png");
      returnValue = component.getImagePath(GenericValues.cHP);
      expect(returnValue).toBe("./assets/img/phone_sm.png");
      returnValue = component.getImagePath(GenericValues.cDTV);
      expect(returnValue).toBe("./assets/img/directv-icon-small.png");
  })


  it("should status string when getStatusInfo is called", ()=>{
    let statusObj = [{isComplete: false, status: "NewInstall"}]
    let returnValue = component.getStatusInfo(statusObj, 'pending');
    expect(returnValue).toBe('NewInstall');
    statusObj = [{isComplete: true, status: "Change"}]
    returnValue = component.getStatusInfo(statusObj, 'complete');
    expect(returnValue).toBe('Change');
    statusObj = [{isComplete: false, status: "Change"}]
    returnValue = component.getStatusInfo(statusObj, 'complete');
    expect(returnValue).toBe('---');
  })

  it("should update flags when clickedContinue is called", ()=>{
    let event  = new Event('hello');
    component.clickedContinue(event);
    expect(component.isExistingProductsSelected).toBe(false);
    expect(component.isDisconnectLandLineSelected ).toBe(true);

  })

  it("should open recommendError model when recommendedItems is available", ()=>{
    let recommendedItems  = [{
      "transactionDate": "string",
      "transactionId": "12122",
      "recommendedSubitems": [{
              "propIdentifier": "New_2019_12moPure_DISCOUNT5_ESHOP",
              "propIdentiferType": "DISCOUNT",
              "propDescription": "string",
              "discounts": [{
                      "discountId": "string"
                  }
              ],
              "bundlePromoId": "87EQ",
              "priceTier": "TIER2",
              "downSpeedMin": 20000,
              "downSpeedMax": 39000
          }],
          "downSpeedMin": 20000,
                        "downSpeedMax": 39000
                    }
                ];
    spyOn(component.recommendedError , 'open')
    component.recommendedItems = recommendedItems;           
    component.ngAfterViewInit();
    expect(component.loading).toBe(false);
    expect(component.recommendedError.open).toHaveBeenCalled();

  });

  it("should call  newRemarkUpdate when addRemarks is called", ()=>{
    spyOn(component, 'newRemarkUpdate')
    component.newRemark = "Technician required";
    component.firstName = "John";
    component["lastName"] = "Doe";
    component.addRemarks();
    expect(component.newRemarkUpdate).toHaveBeenCalled();
  });

  it('should call getremarkUpdateInformation and get success response', ()=>{
    let notes = "Technician available";
    component.newRemarkUpdate(notes);
    expect(component.isOrderRemarksSuccess).toBe(true);
  })

  it('should update store when servicecategory is called',() => {
    spyOn(component.store, 'dispatch');
    component.serviceCategory();
    expect(component.store.dispatch).toHaveBeenCalled();
  });

  it('should open stackAmendPopup when stackAmendPopupDecider is called', ()=> {
    spyOn(component.stackAmendPopupDialog , 'open');
    component.stackAmendPopupDecider();
    expect(component.stackAmendPopupDialog.open).toHaveBeenCalled();
  });

  it('should check for higher profile access when amendEligibilityCheckForAgents is called', ()=>{
    let returnValue = component.amendEligibilityCheckForAgents();
    expect(returnValue).toBe(false);
    expect(component.unabletoAmendMsg).toEqual('Order is PONR');
  });

  it('should open unable to stack dialog  when placeOnHold is called on COR', ()=> {
    spyOn(component.unableToStack , 'open');
    component.isCOR = true;
    component.placeOnHold();
    expect(component.unabletoStackMsg).toEqual('');
    expect(component.unableToStack.open).toHaveBeenCalled();
  });


  it('should open respective dialog  when placeOnHold is called with different conditions ', ()=> {
    spyOn(component , 'getToSuspendText');
    spyOn(component.onHoldOrderPONRDialog , 'open');
    spyOn(component.orderOnHold, 'open');
    component.enableSups = true;
    component.customerOrderStatus = "Pending";
    component.suspendActive = true;
    component.placeOnHold();
    expect(component.getToSuspendText).toHaveBeenCalled();
    component.enableSups = false;
    component.customerOrderStatus = "Pending";
    component.suspendActive = true;
    component.placeOnHold();
    expect(component.getToSuspendText).toHaveBeenCalled();
    component.enableSups = true;
    component.customerOrderStatus = "Pending";
    component.suspendActive = false;
    component.placeOnHold();
    expect(component.onHoldOrderPONRDialog.open).toHaveBeenCalled();
    component.enableSups = false;
    component.customerOrderStatus = "Pending";
    component.suspendActive = false;
    component.placeOnHold();
    expect(component.orderOnHold.open).toHaveBeenCalled();
  });

  it('should open unableToStack popup when getCancelOrder is called in COR', ()=>{
    spyOn(component.unableToStack,'open');
    component.isCOR = true;
    component.getCancelOrder();
    expect(component.unableToStack.open).toHaveBeenCalled();
  });

  it('should call cancelorderinformation API and return success when cancel order is called', ()=>{
    spyOn(component.cancelSup1Dialog, 'open');
    spyOn(component.cancelSup1DialogDeposit, 'open');
    spyOn(component.cancelPrepaidOrder, 'open');
    component.getCancelOrder();
    expect(component.cancelSup1Dialog.open).toHaveBeenCalled();
    component.reqDeposit = true;
    component.getCancelOrder();
    expect(component.cancelSup1DialogDeposit.open).toHaveBeenCalled();
    component.reqDeposit = false;
    component.offerVariables.isPrepaid = true;
    component.getCancelOrder();
    expect(component.cancelPrepaidOrder.open).toHaveBeenCalled();
  });

  it('should set stackamend flags  and call change product when onEmitStackAmend is called', ()=>{
    component.onEmitStackAmend('stackOrder');
    expect(component['flagStackOrder']).toBe(true);
    expect(component['flagAmendOrder']).toBe(false);
    expect(component['flagIsStackAmendCall']).toBe(true); 
    component.onEmitStackAmend('amendOrder');
    expect(component['flagStackOrder']).toBe(false);
    expect(component['flagAmendOrder']).toBe(true);
    expect(component['flagIsStackAmendCall']).toBe(true); 
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/stack-amend-product'])
  });

  it('should open respective dialog when checkMultiPendingOrOthers is called', ()=>{
    spyOn(component.unableToStack , 'open');
    spyOn(component.schedulingPONRDialog, 'open');
    component.isCOR = true;
    component.checkMultiPendingOrOthers();
    expect(component.unabletoStackMsg).toEqual('');
    expect(component.unableToStack.open).toHaveBeenCalled();
    component.isCOR = false;
    component.checkMultiPendingOrOthers();
    expect(component.schedulingPONRDialog.open).toHaveBeenCalled();
  });

  it('should call getScheduleInformation and get response if not COR', ()=>{
    spyOn(component.unableToStack,'open');
    component.isCOR = true;
    component.getScheduleInformation();
    expect(component.unableToStack.open).toHaveBeenCalled();
    component.isCOR =  false;
    component.getScheduleInformation();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/pending-schedule-appt'])
  });

  });

  describe('HSI Pending Order Summary Failure API', () => {
    

    class MockPendingOrderService {
      getremarkUpdateInformation() {
        const data: any = {errorResponse: []};
        return throwError(new HttpResponse(data));
      }

      getCancelOrderInformation(){
        const data: any = {errorResponse: []};
        return throwError(new HttpResponse(data));
      }

      getOrderSummary() {
        return of(new HttpResponse({}));
      }
      getExistingDiscountsByBan() {
          return of(new HttpResponse({}));
      }
      getOrderProgressStatus() {
          return of(new HttpResponse({}));
      }
    }

    class MockAddressService {
      getInitChangeCall(){
        const data: any = {errorResponse: []};
        return throwError(new HttpResponse(data));
      }
    }

    class MockSchedulingService {
      pendingRescheduleAppointment(){
        const data: any = {errorResponse: []};
        return throwError(new HttpResponse(data));
      }
    }

    const p1 = {provide: PendingOrderService, useClass: MockPendingOrderService};
    const p2 = {provide: AddressService, useClass: MockAddressService};
    const p3 = {provide: SchedulingService, useClass: MockSchedulingService};
    const _providers = [ ...providers, p1 , p2, p3];
    beforeEach(async(() => {
      
    }));
  
    beforeEach(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ PendingOrderComponent ],
        providers: _providers
      })
      .compileComponents();
      fixture = TestBed.createComponent(PendingOrderComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    
it('should call getremarkUpdateInformation and get failure response', ()=>{
  let notes = "Technician available";
  component.newRemarkUpdate(notes);
  expect(component.loading).toBe(false);
});

it('should call cancelorderinformation API and return failure when cancel order is called', ()=>{
  spyOn(component['systemErrorService'], 'logAndeRouteToSystemError');
  component.getCancelOrder();
  expect(component['systemErrorService'].logAndeRouteToSystemError).toHaveBeenCalled();
})

it('should set stackamend flags  and call change product when onEmitStackAmend is called API failure', ()=>{
  component.onEmitStackAmend('stackOrder');
  expect(component['flagStackOrder']).toBe(true);
  expect(component['flagAmendOrder']).toBe(false);
  expect(component['flagIsStackAmendCall']).toBe(true); 
});

it('should call getScheduleInformation and get response failure', ()=>{
    component.isCOR =  false;
    component.getScheduleInformation();
    expect(component.apiResponseError).toBeFalsy;
  });

});

describe('HSI Pending Order Summary API empty response', () => {
    

  class MockPendingOrderService {
    getremarkUpdateInformation() {
      return of({});
    }

    getCancelOrderInformation(){
      return of({});
    }
    getOrderSummary() {
      return of(new HttpResponse({}));
    }
    getExistingDiscountsByBan() {
        return of(new HttpResponse({}));
    }
    getOrderProgressStatus() {
        return of(new HttpResponse({}));
    }
  }

  const p4 = {provide: PendingOrderService, useClass: MockPendingOrderService};

  const _providers = [ ...providers, p4];
  beforeEach(async(() => {
    
  }));

  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      imports: imports,
      declarations: [ PendingOrderComponent ],
      providers: _providers
    })
    .compileComponents();
    fixture = TestBed.createComponent(PendingOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  
it('should call getremarkUpdateInformation and get failure response', ()=>{
let notes = "Technician available";
component.newRemarkUpdate(notes);
expect(component.isOrderRemarksFailure).toBe(true);
});


it('should call cancelorderinformation API and return empty when cancel order is called', ()=>{
  component.getCancelOrder();
  expect(component['respData']).toEqual({});
});


});



});
    