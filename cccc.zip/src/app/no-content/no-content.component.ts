import { Component } from '@angular/core';

@Component({
  selector: 'no-content',
  template: `
    <spinner [loading]="true"></spinner>
  `
})
export class NoContentComponent {

}
