export class MockServer {
    public data: any = require('../mock-data/db2.json');
    public data2: any = require('../mock-data/data.json');
    public store: any = require('../mock-data/store.json');
    public nonpayStore: any = require('../mock-data/store-nonpaysuspend.json');
    public billingstore: any = require('../mock-data/store-billingrecord.json');
    public moveStore: any = require('../mock-data/store-move.json');
    public pendingStore: any = require('../mock-data/store-pending.json')
    public vacationData: any = require('../mock-data/vacation-mock-data.json');
    public offerHelperData: any = require('../mock-data/offer-helper-data.json');
    public changeStore: any = require('../mock-data/store-change.json');
    public disconnectStore: any = require('../mock-data/store-disconnect.json');

    public getResponseForRequest(methodName, req?) {
        let response: any;
        if (methodName === 'init') {

            var AddrLine;
            if (req.address && req.address.streetType && (req.address.streetType === 'P.O. Box'
                || req.address.streetType === 'Rural Route' || req.address.streetType === 'Military' || req.address.streetType === 'International')) {
                response = this.data['init'];
            } else {
                if (req.address !== undefined && req.address.addressLine) {
                    AddrLine = req.address.addressLine;
                }
                if (AddrLine === undefined && req.sourceSystem) {
                    //green always
                    response = this.data['init'];
                } else if (AddrLine.startsWith("7")) {
                    //send green
                    response = this.data['initAddressRed'];
                } else if (AddrLine.startsWith("8")) {
                    //send yellow
                    response = this.data['initAddressYellow'];
                } else if (AddrLine.startsWith("5")) {
                    response = "Error";
                    //return server exception
                } else {
                    //green always
                    response = this.data['init'];
                }
            }
        }
        else if (methodName === 'submitTask') {            
            var TaskName = req.taskName;
            if (TaskName === 'Account Information') {
                let ssn = req.payload.personalDetails.ssn;
                if (ssn.startsWith("1")) {
                    response = this.data['depositAndPast'];
                } else if (ssn.startsWith("2")) {
                    response = this.data['onlyPast'];
                } else if (ssn.startsWith("3")) {
                    response = this.data['noDepositNoPast'];
                } else {
                    response = this.data['depositNoPast'];
                }
            } else if (TaskName === 'Checkout') {
                response = this.data['Shipping'];
            } else if (TaskName === 'Ship_Appointments') {
                response = this.data['Ship_Appointments'];
            } else if (TaskName === 'existingProducts') {
                response = this.data['existing'];
            } else if (TaskName === 'Get Addon Offers') {
                response = this.data['Get Addon Offers'];
            }else if(TaskName === 'initAddressGreen'){
                response = this.data['initAddressGreen'];
            } else {
                response = this.data[TaskName];
            }
        } else if (methodName === 'init2') {
            response = this.data['init'];
        } else if (methodName === 'existing') {
            response = this.data['existing'];
        } else if(methodName === 'NotFoundAddress') {
            response = this.data['NotFoundAddress'];
        } else if(methodName === 'FoundWithRanges') {
            response = this.data['FoundWithRanges'];
        } else if(methodName === 'checkAddressCallAfterMultimacthAddSelect') {
            response = this.data['checkAddressCallAfterMultimacthAddSelect'];
        } else if(methodName === 'schedulingDisclosure') {
            response = this.data['schedulingDisclosure'];
        } else if(methodName === 'move-account-submitTask') {
            response = this.data['move-account-submitTask'];
        } else if(methodName === 'fetchRule131') {
            response = this.data['fetchRule131'];
        } else if(methodName === 'portabilityCheck_portableNo') {
            response = this.data['portabilityCheck_portableNo'];
        } else if(methodName === 'portabilityCheck_portableYes') {
            response = this.data['portabilityCheck_portableYes'];
        } else if(methodName === 'listing_details') {
            response = this.data['listing_details'];
        } else if(methodName === 'getOptionsForDirectoryListing') {
            response = this.data['getOptionsForDirectoryListing'];
        } else if(methodName === 'onContinueFromNiScheduling') {
            response = this.data['onContinueFromNiScheduling'];
        } else if(methodName === 'removeProductRes') {
            response = this.data['removeProductRes'];
        } else if(methodName === 'getReasonCode') {
            response = this.data['getReasonCode'];
        } else if(methodName === 'changePOTSSelectProduct') {
            response = this.data['changePOTSSelectProduct'];
        } else if(methodName === 'getTechnologyType') {
            response = this.data['getTechnologyType'];
        } else if(methodName === 'getCSCompatibilityRules_fetchRules') {
            response = this.data['getCSCompatibilityRules_fetchRules'];
        } else if(methodName === 'changeAccountPageContinueReq') {
            response = this.data['changeAccountPageContinueReq'];
        } else if(methodName === 'changeAccountPageContinueRes') {
            response = this.data['changeAccountPageContinueRes'];
        } else if(methodName === 'checkoutAndSchedulingRes_HSI_POTS_NI') {
            response = this.data['checkoutAndSchedulingRes_HSI_POTS_NI'];
        } else if(methodName === 'changeResponsibilityInitReq') {
            response = this.data2['changeResponsibilityInitReq'];
        } else if(methodName === 'changeResponsibilityInitRes') {
            response = this.data2['changeResponsibilityInitRes'];
        } else if(methodName === 'nonPaySuspendReq') {
            response = this.data2['nonPaySuspendReq'];
        } else if(methodName === 'nonPaySuspendRes') {
            response = this.data2['nonPaySuspendRes'];
        } else if(methodName === 'callDisconnectReasonsInitReq') {
            response = this.data2['callDisconnectReasonsInitReq'];
        } else if(methodName === 'callDisconnectReasonsInitRes') {
            response = this.data2['callDisconnectReasonsInitRes'];
        } else if(methodName === 'getInitChangeCallReq') {
            response = this.data2['getInitChangeCallReq'];
        } else if(methodName === 'getInitChangeCallRes') {
            response = this.data2['getInitChangeCallRes'];
        } else if(methodName === 'depositInfoRes') {
            response = this.data2['depositInfoRes'];
        } else if(methodName === 'propertiesRes') {
            response = this.data2['propertiesRes'];
        }
        return response;
    }

    public getResponseForReducerAndApi(param) {
        let response: any;
        if (param === 'new-user') {
            response = this.data['new-user'];
        } else if (param === 'auth-user') {
            response = this.data['auth-user'];
        } else if (param === 'retainByOrderNum') {
            response = this.data['retainByOrderNum'];
        } else if (param === 'retainByAccountNum') {
            response = this.data['retainByAccountNum'];
        } else if (param === 'newUser') {
            response = this.data['newUser'];
        } else if (param === 'retrieveProductsAndServices') {
            response = this.data['retrieveProductsAndServices'];
        } else if (param === 'pending') {
            response = this.data['pending'];
        } else if (param === "userState1") {
            response = this.data['userState1'];
        } else if (param === "existingProductState1") {
            response = this.data['existingProductState1'];
        } else if (param === "retainState1") {
            response = this.data['retainState1'];
        } else if (param === 'user-agent1') {
            response = this.data['user-agent1'];
        } else if (param === 'user-agent2') {
            response = this.data['user-agent2'];
        } else if (param === 'user-agent3') {
            response = this.data['user-agent3'];
        } else if (param === 'user-agent4') {
            response = this.data['user-agent4'];
        } else if (param === 'apiValidateAddress-Multimatch') {
            response = this.data['apiValidateAddress-Multimatch'];
        } else if (param === 'apiValidateAddress-NoMatch') {
            response = this.data['apiValidateAddress-NoMatch'];
        } else if (param === 'reducer-creditReview') {
            response = this.data['reducer-creditReview'];
        } else if (param === 'goes-address') {
            response = this.data['goes-address'];
        } else if (param ==='apiValidateAddressBadRequest') {
            response = this.data['apiValidateAddressBadRequest'];
        } else if (param === 'retrieveProdAndServices-incompletedOrder') {
            response = this.data['retrieveProdAndServices-incompletedOrder'];
        } else if (param === 'retrieveProdAndServices-incompletedOrder-and-removeFromHold') {
            response = this.data['retrieveProdAndServices-incompletedOrder-and-removeFromHold'];
        } else if (param === 'retrieveProdAndServices-completedOrder') {
            response = this.data['retrieveProdAndServices-completedOrder'];
        } else if (param === 'pending-reducer-on-hold') {
            response = this.data['pending-reducer-on-hold'];
        } else if (param === 'schedule-disconnect-date') {
            response = this.data['schedule-disconnect-date'];
        } else if (param === 'fromHold-flow-existingProducts') {
            response = this.data['fromHold-flow-existingProducts'];
        } else if (param === 'fromHold-flow-cart') {
            response = this.data['fromHold-flow-cart'];
        } else if (param === 'fromHold-flow-customize') {
            response = this.data['fromHold-flow-customize'];
        } else if (param === 'new-flow-fetchRules') {
            response = this.data['new-flow-fetchRules'];
        } else if (param === 'billing-flow-user-reducer') {
            response = this.data['billing-flow-user-reducer'];
        } else if (param === 'billing-flow-existingProducts-reducer') {
            response = this.data['billing-flow-existingProducts-reducer'];
        } else if (param === 'billing-flow-cart-reducer') {
            response = this.data['billing-flow-cart-reducer'];
        } else if (param === 'billing-flow-customize-reducer') {
            response = this.data['billing-flow-customize-reducer'];
        } else if (param === 'billing-flow-retain-reducer') {
            response = this.data['billing-flow-retain-reducer'];
        } else if (param === 'move-flow-hsi-pots-user-reducer') {
            response = this.data['move-flow-hsi-pots-user-reducer'];
        } else if (param === 'move-flow-hsi-pots-cart-reducer') {
            response = this.data['move-flow-hsi-pots-cart-reducer'];
        } else if (param === 'move-flow-hsi-pots-customize-reducer') {
            response = this.data['move-flow-hsi-pots-customize-reducer'];
        } else if (param === 'move-flow-hsi-pots-order-reducer') {
            response = this.data['move-flow-hsi-pots-order-reducer'];
        } else if (param === 'move-flow-hsi-pots-systemErrorReducer-reducer') {
            response = this.data['move-flow-hsi-pots-systemErrorReducer-reducer'];
        } else if (param === 'move-flow-hsi-pots-existingProducts-reducer') {
            response = this.data['move-flow-hsi-pots-existingProducts-reducer'];
        } else if (param === 'move-flow-hsi-pots-retain-reducer') {
            response = this.data['move-flow-hsi-pots-retain-reducer'];
        } else if (param === 'change-flow-hsi-pots-user-reducer') {
            response = this.data['change-flow-hsi-pots-user-reducer'];
        } else if (param === 'change-flow-hsi-pots-cart-reducer') {
            response = this.data['change-flow-hsi-pots-cart-reducer'];
        } else if (param === 'change-flow-hsi-pots-customize-reducer') {
            response = this.data['change-flow-hsi-pots-customize-reducer'];
        } else if (param === 'change-flow-hsi-pots-order-reducer') {
            response = this.data['change-flow-hsi-pots-order-reducer'];
        } else if (param === 'change-flow-hsi-pots-systemErrorReducer-reducer') {
            response = this.data['change-flow-hsi-pots-systemErrorReducer-reducer'];
        } else if (param === 'change-flow-hsi-pots-existingProducts-reducer') {
            response = this.data['change-flow-hsi-pots-existingProducts-reducer'];
        } else if (param === 'change-flow-hsi-pots-retain-reducer') {
            response = this.data['change-flow-hsi-pots-retain-reducer'];
        } else if (param === 'lifeline-customize-reducer') {
            response = this.data['lifeline-customize-reducer'];
        } else if (param === 'existing-product-change-flow-hsi-pots-user-reducer') {
            response = this.data['existing-product-change-flow-hsi-pots-user-reducer'];
        } else if (param === 'existing-product-change-flow-hsi-pots-retain-reducer') {
            response = this.data['existing-product-change-flow-hsi-pots-retain-reducer'];
        } else if (param === 'existing-product-change-flow-hsi-pots-existingProducts-reducer') {
            response = this.data['existing-product-change-flow-hsi-pots-existingProducts-reducer'];
        } else if (param === 'appointmentResponse'){
            response = this.data['appointmentResponse'];
        } else if (param === 'Appointments') {
            response = this.data['Appointments'];
        } else if (param === 'change-order-review-page-internet-remove-and-pots-add-order-reducer') {
            response = this.data['change-order-review-page-internet-remove-and-pots-add-order-reducer'];
        } else if (param === 'NI-HSI-POTS-Quote') {
            response = this.data['NI-HSI-POTS-Quote'];
        } else if (param === 'NI-HSI-POTS-retrieveProductDealerCodeInfo') {
            response = this.data['NI-HSI-POTS-retrieveProductDealerCodeInfo'];
        } else if (param === 'getCompRules') {
            response = this.data['getCompRules'];
        } else if (param === 'getLATA') {
            response = this.data['getLATA'];
        } else if (param === 'existing') {
            response = this.data['existing'];
        } else if (param === 'mo-review-submit') {
            response = this.data['mo-review-submit'];
        } else if (param === 'pending-add-remarks'){
            response = this.data['addorderremarks'];
        } else if (param === 'pending-cancel-order'){
            response = this.data['pendingcancelorder'];
        } else if (param === 'pending-stackamend-init'){
            response = this.data['pending-stackamend-init'];
        } else if (param === 'pending-scheduling-init'){
            response = this.data['pending-scheduling-init']
        } else if (param === 'pending-getorderprogressstatus'){
            response = this.data['pending-getorderprogressstatus'];
        }
        return response;
    }

    public getResponseFromStoreForVacationService(param) {
        let response: any;
        if (param === 'vacation-suspend-hsi-standalone-user-reducer') {
            response = this.vacationData['vacation-suspend-hsi-standalone-user-reducer'];
        } else if (param === 'vacation-suspend-hsi-standalone-existingProducts-reducer') {
            response = this.vacationData['vacation-suspend-hsi-standalone-existingProducts-reducer'];
        } else if (param === 'vacation-suspend-hsi-standalone-vacation-reducer') {
            response = this.vacationData['vacation-suspend-hsi-standalone-vacation-reducer'];
        }
        return response;
    }

    public getMockStore(param) {
        let response: any;
        if (param === 'NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE') {
            response = this.store['NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE'];
        } 
        if (param === 'onload-addressPage') {
            response = this.store['onload-addressPage'];
        }
        if (param === 'onload-vacationOption') {
            response = this.store['onload-vacationOption'];
        }
        if (param === 'onload-BRPage') {
            response = this.store['onload-BRPage'];
        }
        if (param === 'onload-accountPage') {
            response = this.store['onload-accountPage'];
        }
        if (param === 'onload-customize') {
            response = this.store['onload-customize'];
        }
        if(param === 'NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE') {
            response = this.store['NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE'];
        }
        if (param === 'onload-reviewOrder-NI-HSI-POTS') {
            response = this.store['onload-reviewOrder-NI-HSI-POTS'];
        }
        if(param === 'onload-cart') {
            response = this.store['onload-cart'];
        }
        if(param === 'onload-move-scheduling') {
            response = this.store['onload-move-scheduling'];
        }
        if( param === 'NONPAY-SUSPEND-CONFIRMATION'){
            response = this.nonpayStore['nonpay-suspend-confirmation'];
        }
        if( param === 'NONPAY-RESTORE-CONFIRMATION'){
            response = this.nonpayStore['nonpay-restore-confirmation'];
        }
        if(param === 'NONPAY-HSIONLY-CONFIRMATION'){
            response = this.nonpayStore['nonpay-hsionly-confirmation'];
        }
        if(param === 'ONHOLD-PENDING-ORDER'){
            response = this.pendingStore['onhold-pending-order'];
        }
        if(param === 'MOVE_HSI_TILL_REVIEW_ORDER') {
            response = this.moveStore['MOVE_HSI_TILL_REVIEW_ORDER'];
        }
        if(param === 'MOVE_POTS_TILL_REVIEW_ORDER') {
            response = this.moveStore['MOVE_POTS_TILL_REVIEW_ORDER'];
        }
        if(param === 'MOVE_HSI_POTS_TILL_CONFIRMATION') {
            response = this.moveStore['MOVE_HSI_POTS_TILL_CONFIRMATION'];
        }
        if(param === 'CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE') {
            response = this.changeStore['CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE'];
        }
        if(param === 'onload-cancelled-order') {
            response = this.store['onload-cancelled-order'];
        }
        if(param === 'onload-cancelled-order-else') {
            response = this.store['onload-cancelled-order-else'];
        }
        if(param === 'onload-cancelled-order-orderInit') {
            response = this.store['onload-cancelled-order-orderInit'];
        }
        if(param === 'NI_HSI_TILL_ORDER_CONFIRMATION_PAGE') {
            response = this.store['NI_HSI_TILL_ORDER_CONFIRMATION_PAGE'];
        }
        if(param === 'error-display'){
            response = this.nonpayStore['error-display'];
        }
        if(param === 'VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE') {
            response = this.vacationData['VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE'];
        }
        if(param === 'HSI-pending-order'){
            response = this.pendingStore['HSI-pending-order'];
        }
        return response;
    }

    public getOfferHelperDetails (param) {
        let response: any;
        if(param === 'offer-variable') {
            response = this.offerHelperData['offer-variable'];
        } else if(param === 'submit-offerPage') {
            response = this.offerHelperData['submit-offerPage'];
        } else if(param === 'change-offerVariables') {
            response = this.offerHelperData['change-offerVariables'];
        }
        return response;
    }

    public getBillingMockStore(param){
        let response: any;
        if(param === 'onload-billing-scheduling') {
            response = this.billingstore['onload-billing-scheduling'];
        }
        if(param === "BILLING_HSI_TILL_ORDER_COFIRMATION") {
            response = this.billingstore["BILLING_HSI_TILL_ORDER_COFIRMATION"];
        }
        if(param === "BILLING_POTS_TILL_REVIEW_ORDER") {
            response = this.billingstore["BILLING_POTS_TILL_REVIEW_ORDER"];
        }
        return response;
    }

    public getDisconnectStore(param){
        let response:any
        if(param === 'HSI_POTS_DISCONNECT_TILL_REVIEWORDER') {
            response = this.disconnectStore['HSI_POTS_DISCONNECT_TILL_REVIEWORDER'];
        }
        return response
    }

    public getVariables(key) {
        switch(key) {
            case "scheduleVariableFor_reserveAppointment": 
            case "dhp_ni_phoneConfigurationParentCompoData": 
            case "oneTimeChargeVarFor-addNremoveproducts": 
                return this.data[key]
            default: return null;
        }
    }

    getVacationStoreOrApiData(key) {
        switch(key) {
            case "HSI_STANDALONE_VS_RESPONSE": 
                return this.vacationData[key]
            default: return null;
        }
    }

}