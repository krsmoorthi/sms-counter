import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MockServer } from 'app/MockServer.test';
import { Observable, of, throwError } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { MockLogger,MockSystemErrorService, MockHelperService, MockProfileService } from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Store, StoreModule } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { AppComponent } from './app.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpResponse } from '@angular/common/http';
import { AccordionModule, ModalModule } from 'ngx-bootstrap';
import { CoreModule } from './common/core.module';
import { AppRoutingModule } from './app-routing.module';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { rootReducer } from './common/store/root-reducer';
import { env } from 'environments/environment';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreLogMonitorModule, useLogMonitor } from '@ngrx/store-log-monitor';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularDraggableModule } from 'angular2-draggable';
import { AuthService } from './common/service/auth.service';
import { PropertiesService } from './common/service/properties.service';
import { ProfileService } from './common/service/profile.service';
import { PropertiesHelperService } from './common/service/propertiesHelper.service';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  const mockServer = new MockServer();

  const imports = [
    BrowserModule,
        FormsModule,
        ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
        HttpClientModule,
        AccordionModule.forRoot(),
        ModalModule.forRoot(),
        CoreModule,
        AppRoutingModule,
        SimpleNotificationsModule.forRoot(),
        StoreModule.forRoot(rootReducer, {
            
        }),
        (!env.production && !env.aot) ? 
        StoreDevtoolsModule.instrument({
            monitor: useLogMonitor({
                visible: false,
                position: 'right'
            })
            
        })
        : [],
        StoreLogMonitorModule,
        DeviceDetectorModule.forRoot(),
        BrowserAnimationsModule,
        AngularDraggableModule,
        SharedCommonModule
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }
  class MockAppStateService {
	setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE');
    }
  }
  
  class MockPropertiesService {
    getProperties() {
      return of(new HttpResponse(mockServer.getResponseForRequest('propertiesRes')))
    }
  }

  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const authService = AuthService;
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const profileService = { provide: ProfileService, useClass: MockProfileService };
  const propertiesService = { provide: PropertiesService, useClass: MockPropertiesService };
  const helperService = { provide: HelperService, useClass: MockHelperService };

  const providers = [
    logger, store, appStateService, systemErrorService, CTLHelperService , authService, 
    profileService, propertiesService, helperService, CountryStateService, PropertiesHelperService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [
        AppComponent
    ],
    providers: providers
  }

  describe('', () => {

    beforeEach(async(() => {
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(AppComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create app component', () => {
      expect(component).toBeTruthy();
    });
  
    it('should call retrieveProperties', () => {
      (component as any).retrieveProperties();
      expect(component.user).toBeDefined();
    });
  });

  describe('retrieveProperties with error response', () => {
    class MockPropertiesService {
      getProperties() {
        return throwError(new HttpResponse(mockServer.getResponseForRequest('propertiesRes')))
      }
    }

    const propertiesService = { provide: PropertiesService, useClass: MockPropertiesService };

    const _providers = [...providers, propertiesService];

    const baseConfig = {
      imports: imports,
      declarations: [
          AppComponent
      ],
      providers: _providers
    }
  
    beforeEach(async(() => {
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(AppComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should call retrieveProperties', () => {
      (component as any).retrieveProperties();
      expect(component.user).toBeDefined();
    });
  });
  
});
