import { TestBed } from '@angular/core/testing';
import { PaymentGuard } from './payment.guard';
import { AppStateService } from './common/service/app-state.service';
import { MockAppStateService } from './common/service/mockServices.test';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

describe('PaymentGuard', () => {
    let paymentGuard: PaymentGuard;
    let router = {
        navigate: jasmine.createSpy('navigate')
    }

    beforeEach(async() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, CommonModule, HttpClientModule],
            providers: [
                PaymentGuard,
                {provide: AppStateService, useClass: MockAppStateService},
                {provide: Router, useValue: router}
            ]
        }).compileComponents();
        
    });

    beforeEach(() => {
        paymentGuard = TestBed.get(PaymentGuard);
    });

    it('should call canActivate', () => {
        const service = paymentGuard.canActivate()
        expect(service).toBeDefined;
    });

});