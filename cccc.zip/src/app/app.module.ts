import { CUSTOM_ELEMENTS_SCHEMA, NgModule, ErrorHandler } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreLogMonitorModule, useLogMonitor } from '@ngrx/store-log-monitor';
import { AngularDraggableModule } from 'angular2-draggable';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { ErrorModal } from 'app/ErrorModal/ErrorModal.component';
import { AccordionModule, ModalModule } from "ngx-bootstrap";
import { DeviceDetectorModule } from 'ngx-device-detector';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { CoreModule } from './common/core.module';
import { Logger } from './common/logging/default-log.service';
import { SplunkLogService } from './common/logging/splunk-log.service';
import { SystemErrorService } from './common/service/system-error.service';
import { ProfileService } from './common/service/profile.service';
import { PropertiesService } from './common/service/properties.service';
import { PropertiesHelperService } from './common/service/propertiesHelper.service';
import { SharedCommonModule } from './shared/shared-common.module';

import { ComponentErrorModal } from './ErrorModal/ComponentErrorModal';
import { NoContentComponent } from './no-content';
import { PaymentGuard } from './payment.guard';
import { DisclosuresService } from './common/service/disclosures.service';
import { env } from '../environments/environment';

import { rootReducer } from './common/store/root-reducer';
import { metaReducers } from './common/store/meta-reducers';
import { User } from './common/models/user.model';
import { ORNInterceptorService } from './common/service/ORNInterceptorService';
import { GlobalErrorHandler } from './common/global-error.service';


// Application wide providers
const APP_PROVIDERS = [
    [
        {
            provide: Logger,
            useClass: SplunkLogService
        }
    ],
];

const initialUserState: User = {
    id: 0,
    email: ''
};

@NgModule({
    bootstrap: [AppComponent],
    declarations: [
        AppComponent,
        NoContentComponent,
        ErrorModal,
        ComponentErrorModal
    ],
    exports: [ErrorModal, ComponentErrorModal],
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
        HttpClientModule,
        AccordionModule.forRoot(),
        ModalModule.forRoot(),
        CoreModule,
        AppRoutingModule,
        SimpleNotificationsModule.forRoot(),
        StoreModule.forRoot(rootReducer, {
            metaReducers,
            initialState: { user: initialUserState } as any
        }),
        (!env.production && !env.aot) ? 
        StoreDevtoolsModule.instrument({
            monitor: useLogMonitor({
                visible: false,
                position: 'right'
            })
            
        })
        : [],
        StoreLogMonitorModule,
        DeviceDetectorModule.forRoot(),
        BrowserAnimationsModule,
        AngularDraggableModule,
        SharedCommonModule
    ],
    providers: [
        [{provide: ErrorHandler, useClass: GlobalErrorHandler}],
        APP_PROVIDERS,
        SystemErrorService,
        ProfileService,
        PropertiesService,
        PaymentGuard,
        DisclosuresService,
        PropertiesHelperService,
        {provide: HTTP_INTERCEPTORS, useClass: ORNInterceptorService, multi: true}
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class AppModule { }
