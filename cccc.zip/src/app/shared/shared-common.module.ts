import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TextMaskModule } from 'angular2-text-mask';
import { BuildDetailsComponent } from 'app/common/build-details';
import { SecurityErrorComponent } from 'app/common/security-error/security-error.component';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { SpinnerComponent } from 'app/common/spinner.component';
import { ControlMessagesComponent } from 'app/common/validations/control-messages.component';
import { TypeaheadModule } from 'ngx-bootstrap';

@NgModule({
    imports: [
        CommonModule,
        TypeaheadModule.forRoot(),
        TextMaskModule
    ],
    declarations: [
        SpinnerComponent,
        ControlMessagesComponent,
        BuildDetailsComponent,
        SecurityErrorComponent
    ],
    exports: [
        SpinnerComponent,
        ControlMessagesComponent,
        BuildDetailsComponent,
        SecurityErrorComponent
    ],
    providers: [
        TextMaskService
    ]
})

// To improve the performance for first page we have created another Shared Module
export class SharedCommonModule { }
