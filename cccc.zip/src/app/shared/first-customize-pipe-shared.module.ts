import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FirstCustomizePipe } from 'app/common/pipes/firstcapcustom.pipe';


@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        FirstCustomizePipe
    ],
    exports: [
        FirstCustomizePipe
    ]
})

export class FirstCustomizePipeSharedModule { }
