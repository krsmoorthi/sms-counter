import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AngularDraggableModule } from 'angular2-draggable';
import { TextMaskModule } from 'angular2-text-mask';
import { CreditCheckComponent } from 'app/account/credit-check/credit-check.component';
import { DirectTvComponent } from 'app/account/directv-account/directv-account.component';
import { ValidateBillingAddressComponent } from 'app/account/validate-billing-address-component/validate-billing-address.component';
import { MultimatchBillingComponent } from 'app/common/address/multimatch-billing.component';
import { MultimatchMoveComponent } from 'app/common/address/multimatch-move.component';
import { WorkingServiceMoveComponent } from "app/common/address/workingservice-move.component";
import { EndDatePickerComponent } from 'app/common/datepicker-endate/datepicker-endate.component';
import { AppointmentDatePickerComponent } from 'app/common/datepicker.appointment/datepicker.appointment.component';
import { CustomDatePickerComponent } from 'app/common/datepicker/datepicker.component';
import { MACDDropdown } from 'app/common/macddropdown/macd.dropdown';
import { AlphabetizePipe } from 'app/common/pipes/alphabetize.pipe';
import { CustomPipe } from 'app/common/pipes/custom-filter.pipe';
import { CurrencyPipe } from 'app/common/pipes/currency-filter.pipe';
import { CustomizePipe } from 'app/common/pipes/customize.pipe';
import { SortByPipe } from 'app/common/pipes/sortby.pipe';
import { SafeHtmlPipe } from 'app/common/pipes/safe-html.pipe';
import { SSNPipe } from 'app/common/pipes/ssn.pipe';
import { MaskSsnPipe } from 'app/common/pipes/ssnmasking.pipe';
import { allowedOtcWaivedReasonListPipe } from 'app/common/pipes/allowed-otc-waived-reasonList.pipe';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { PastdueDialogComponent } from 'app/common/popup/pastdue-dialog.component';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { speedFilterPipe } from 'app/product/change-product/offer-change.pipe';
import { AccountInfoComponent } from 'app/review-order/account-info/account-info.component';
import { BillEstimateComponent } from 'app/review-order/bill-estimate/bill-estimate.component';
import { DisconnectPricingComponent } from 'app/review-order/disconnect-pricing/disconnect-pricing.component';
import { DisconnectRemarksComponent } from 'app/review-order/disconnect-remarks/disconnect-remarks.component';
import { InfoBoxComponent } from 'app/review-order/info-box/info-box.component';
import { OrderSummaryComponent } from 'app/review-order/order-summary/order-summary.component';
import { SubmitPanelComponent } from 'app/review-order/submit-panel/submit-panel.component';
import { TPVReminderComponent } from 'app/review-order/tpv-reminder/tpv-reminder.component';
import { PopoverModule, TypeaheadModule } from 'ngx-bootstrap';
import { DatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { SharedCommonModule } from './shared-common.module';
import { TvProductOfferComponent } from 'app/product/tv-product-offer/tv-product-offer.component';
import { PerpaidPaymentDialogComponent } from '../common/popup/prepaidpayment-dialog.component';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        TypeaheadModule.forRoot(),
        SharedCommonModule,
        RouterModule,
        TextMaskModule,
        ReactiveFormsModule,
        BsDropdownModule.forRoot(),
        PopoverModule.forRoot(),
        DatepickerModule.forRoot(),
        AngularDraggableModule
    ],
    declarations: [
        DialogComponent,
        PastdueDialogComponent,
        MultimatchMoveComponent,
        WorkingServiceMoveComponent,
        MultimatchBillingComponent,
        PerpaidPaymentDialogComponent,
        AlphabetizePipe,
        speedFilterPipe,
        CustomizePipe,
        SortByPipe,
        SafeHtmlPipe,
        MACDDropdown,
        CustomDatePickerComponent,
        AppointmentDatePickerComponent,
        InfoBoxComponent,
        CustomPipe,
        CurrencyPipe,
        allowedOtcWaivedReasonListPipe,
        AccountInfoComponent,
        SubmitPanelComponent,
        BillEstimateComponent,
        OrderSummaryComponent,
        TPVReminderComponent,
        DisconnectPricingComponent,
        DisconnectRemarksComponent,
        ValidateBillingAddressComponent,
        SSNPipe,
        MaskSsnPipe,
        CreditCheckComponent,
        DirectTvComponent,
        EndDatePickerComponent,
        TvProductOfferComponent
    ],
    exports: [
        DialogComponent,
        PastdueDialogComponent,
        CommonModule,
        RouterModule,
        FormsModule,
        MultimatchMoveComponent,
        WorkingServiceMoveComponent,
        MultimatchBillingComponent,
        PerpaidPaymentDialogComponent,
        AlphabetizePipe,
        speedFilterPipe,
        CustomizePipe,
        SortByPipe,
        SafeHtmlPipe,
        MACDDropdown,
        CustomDatePickerComponent,
        AppointmentDatePickerComponent,
        InfoBoxComponent,
        CustomPipe,
        CurrencyPipe,
        AccountInfoComponent,
        SubmitPanelComponent,
        BillEstimateComponent,
        OrderSummaryComponent,
        TPVReminderComponent,
        DisconnectPricingComponent,
        DisconnectRemarksComponent,
        ValidateBillingAddressComponent,
        SSNPipe,
        MaskSsnPipe,
        CreditCheckComponent,
        DirectTvComponent,
        EndDatePickerComponent,
        TvProductOfferComponent
    ],
    providers: [
        TextMaskService
    ]
})

/**
 * Shared Module - Used to import reusable component's for different modules
 * eg. ControlMessagesComponent, SpinnerComponent, DialogComponent
 * import shared module in corresponding module and use the component
 */
export class SharedModule { }
