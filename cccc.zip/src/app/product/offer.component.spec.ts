import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OfferComponent } from './offer.component';
import { MockServer } from 'app/MockServer.test';
import { Observable } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes, Router } from '@angular/router';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TooltipModule } from 'ngx-bootstrap';
import { MockRouter, MockLogger, MockProductService, MockAppStateService, MockSystemErrorService, MockAddressService, MockHelperService, MockOfferHelperService, MockReviewOrderService, MockPendingOrderService, MockAccountService, MockBlueMarbleService, MockCountryStateService, MockDirectvService, MockPropertiesHelperService, MockDisconnectService } from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { ProductService } from 'app/common/service/product.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { AddressService } from 'app/common/service/address.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { DisconnectService } from 'app/common/service/disconnect.service';

describe('OfferComponent', () => {
  let component: OfferComponent;
  let fixture: ComponentFixture<OfferComponent>;
  let mockServer = new MockServer();

  const routes: Routes = [
    {
        path: '', component: OfferComponent, 
    }
  ];

  // NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE page having NI flow store, we can use this store since customize page comes after offer
  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }

  // component provides
  let p1 = { provide: Logger, useClass: MockLogger };
  let p2 = { provide: Store, useValue: mockRedux };
  let p3 = { provide: Router, useClass: MockRouter };
  let p4 = { provide: ProductService, useClass: MockProductService };
  let p5 = { provide: AppStateService, useClass: MockAppStateService };
  let p6 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  let p7 = { provide: AddressService, useClass: MockAddressService };
  let p8 = CTLHelperService;
  let p9 = { provide: HelperService, useClass: MockHelperService };
  let p10 = { provide: OfferHelperService, useClass: MockOfferHelperService };
  let p11 = PropertiesHelperService;

  // dialog component providers list
  let dp1 = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  let dp2 = {provide: PendingOrderService, useClass: MockPendingOrderService};
  let dp3 = {provide: AccountService, useClass: MockAccountService};
  let dp4 = {provide: AddressService, useClass: MockAddressService};
  let dp5 = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  let dp6 = {provide: CountryStateService, useClass: MockCountryStateService};
  let dp7 = {provide: DirectvService, useClass: MockDirectvService};
  let dp8 = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  let dp9 = {provide: DisconnectService, useClass: MockDisconnectService};

  let baseConfig = {
    imports: [
      FormsModule,
        ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
        RouterModule.forChild(routes),
        SharedModule,
        SharedCommonModule,
        TooltipModule.forRoot()
    ],
    declarations: [OfferComponent],
    providers: [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,dp1,dp2,dp3,dp4,dp5,dp6,dp7,dp8,dp9]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create offer component', () => {
    expect(component).toBeTruthy();
  });

  it('checking ngOnInit...', () => {
    expect(component.ngOnInit()).toBeDefined;
  });

  it('checking ngOnDestroy...', () => {
    expect(component.ngOnDestroy()).toBeDefined;
  });
  
});
