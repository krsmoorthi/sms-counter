import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClosersPromosComponent } from './closers-promos.component';
import { Observable } from 'rxjs';
import { MockServer } from 'app/MockServer.test';
import { Store } from '@ngrx/store';
import { MockAppStateService, MockProductService, MockSystemErrorService, MockHelperService, MockLogger } from 'app/common/service/mockServices.test';
import { AppStateService } from 'app/common/service/app-state.service';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TabsModule, AccordionModule, TooltipModule } from 'ngx-bootstrap';
import "rxjs/add/observable/of";

describe('ClosersPromosComponent', () => {
  let component: ClosersPromosComponent;
  let fixture: ComponentFixture<ClosersPromosComponent>;
  let mockServer = new MockServer();
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    SharedCommonModule,
    TextMaskModule,
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    TooltipModule.forRoot()
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }

  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const ctlHelperService = CTLHelperService;
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const logger = { provide: Logger, useClass: MockLogger };

  const providers = [
    store, appStateService, productService, systemErrorService, ctlHelperService,
    helperService, logger
  ]

  const baseConfig = {
    imports: imports,
    declarations: [ClosersPromosComponent],
    providers: providers
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClosersPromosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create closers promos component', () => {
    expect(component).toBeTruthy();
  });

  it('should be NI flow', () => {
    expect(component.isNewInstall).toBeTruthy();
    expect(component.isAmend).toBeFalsy();
    expect(component.pendingBillingFlow ).toBeFalsy();
    expect((component as any).isVacResFlow).toBeFalsy();
    expect((component as any).isVacSusFlow).toBeFalsy();
  });

});
