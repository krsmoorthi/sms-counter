import { AppStore } from '../../common/models/appstore.model';
import { Store } from '@ngrx/store';
import { DatePipe } from '@angular/common';
import { Cart, ShoppingCart } from '../../common/models/cart.model';
// tslint:disable-next-line:no-unused-variable
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppStateService } from '../../common/service/app-state.service';
import { GenericValues } from '../../common/models/common.model';
import { ProductService } from '../../common/service/product.service';
import { APIErrorLists } from '../../common/models/common.model';
import { SystemErrorService } from '../../common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { User } from 'app/common/models/user.model';
import { CustomizeServicesComponent } from '../customize-services.component';
import { HelperService } from 'app/common/service/helper.service';
import { Logger } from 'app/common/logging/default-log.service';
import "rxjs/add/operator/catch";

@Component({
    selector: 'closers-promos',
    templateUrl: './closers-promos.component.html',
    styleUrls: ['../customize-services.component.scss']
})
// tslint:disable
export class ClosersPromosComponent implements OnInit {
    public pendingBillingFlow: boolean = false;
    public potsActionValueType: any;
    public hsiExistingDiscountsData: any;
    @Input() public undoQty;
    @Input() public selectedObjectsList = [];
    @Input() public isReEntrant;
    @Input() public giftCards;
    @Input() public isPrepaid: boolean;
    @Output() public CPTab = new EventEmitter();
    @Output() public selGiftCard = new EventEmitter();
    @Output() public CloserPromoTab = new EventEmitter<any>();
    @Output() public isBypassed = new EventEmitter<any>();
    public gCardsList: any = [];
    public retriveCompatibilityLoading = false;
    public refObj = [];
    public CPCartObj: Cart;
    public pType: string[] = [];
    private repeat: boolean = false;
    public selectedProducs: string[] = [];
    public hsiRcDiscObj = [];
    public potsRcDiscObj = [];
    public otcDiscWaiveObj = [];
    public hsiRcAlertMsg: string;
    public potsRcAlertMsg: string;
    public OtcDiscWaiveAlertMsg: string;
    public hsiTotDiscRate: number;
    public potsTotDiscRate: number;
    public OtcTotDiscWaiveRate: number;
    public hsiMaxDiscountAmount: number;
    public potsMaxDiscountAmount: number;
    public otcDiscWaiveMaxDiscountAmount: number;
    public closersandPromosDiscountIds: any;
    public closersPromosCompatibleRes: any;
    public allDiscounts: any[] = [];
    public allDiscountsArray: any[] = [];
    public selectedDiscounts: any[] = [];
    public isExistingDiscounts: any[] = [];
    public existingDiscounts: any = {};
    public existingRetentionDiscounts: any[] = [];
    public discountIDToolTipStr: any;
    public lastSelectedDiscountObj: any;

    public existingObservable: any;
    public existingSubscription: any;
    public retainObservable: any;
    public retainSubscription: any;
    public gCardCRules: any;
    public isNewInstall: boolean = false;
    public apiResponseError: APIErrorLists;
    private orderRefNumber: string;
    private checkedGiftCard: any;
    public targetGiftCard: any = [];
    public flag: boolean = false;
    public isChked: boolean = false;
    public isOverrideOrderType: any;
    public bypassOption: boolean = false;
    public isOverrideOrderTypeDiscounts: boolean;
    public paperlessBilling: any;
    public recommendation: boolean = false;
    private vacationObservable: any;
    private vacationSubscription: any;
    private isVacResFlow: boolean = false;
    private isVacSusFlow: boolean = false;
    public expDiscArray: any = [];
    public productId: any;
    public productType: any;
    public internetDiscountList: any = [];
    public bypassDiscountCalled: boolean = false;

    public isBundleFlag: any;
    existingOTCDiscounts: any[] = [];
    isAmend: boolean;
    public loading: boolean;
    public isChangeFlow: boolean;
    public billingFlow: boolean;
    public isMove: boolean;

    @Input() set cartObjData(cart: Cart) {
        this.CPCartObj = cart;
        let userStore = <Observable<User>>this.store.select('user');
        userStore.subscribe((data) => {
            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['undoQty']) {
            if (this.undoQty !== undefined && this.undoQty) {
                for (let i = 0; i < this.refObj.length; i++) {
                    for (let prodname of Object.keys(this.refObj[i].selectedItems)) {
                        delete this.refObj[i].selectedItems[prodname];
                    }
                }
            }
        }

        if (this.undoQty === false) {
            this.lastSelectedDiscountObj = '';
            this.selectedDiscounts = [];
            this.hsiRcDiscObj.forEach((element) => {

                (<HTMLInputElement>document.getElementById(element.discountId)).checked = false;
                this.discountIDToolTipStr = "";

            });

            this.otcDiscWaiveObj.forEach((element) => {

                (<HTMLInputElement>document.getElementById(element.discountId)).checked = false;
                this.discountIDToolTipStr = "";

            });

            this.flag = false;
            for (let i = 0; i < this.gCardsList.length; i++) {
                if (this.gCardsList[i].isChecked === true) {
                    this.gCardsList[i].isChecked = false;
                }
            }

        }
    }

    constructor(private store: Store<AppStore>,
        public appStateService: AppStateService,
        private productService: ProductService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        public helperService: HelperService,
        private logger: Logger,
    ) {
        this.isOverrideOrderTypeDiscounts = helperService.isAuthorizedGiftAndDiscounts();
    }

    public ngOnInit() {
        this.logger.metrics('CloserPromosPage');
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacResFlow) this.isVacResFlow = true;
                else this.isVacResFlow = false;
                if (data.vacFlowName.isVacSusFlow) this.isVacSusFlow = true;
                else this.isVacSusFlow = false;
            }
        });
        if (!this.isVacSusFlow) {
            this.allDiscountsArray = this.getAllDiscounts(this.CPCartObj);
        }
        if (this.vacationSubscription) this.vacationSubscription.unsubscribe();
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            if (data && data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.accountPreferences && data.existingProductsAndServices[0].accountInfo.accountPreferences.paperlessBilling) {
                this.paperlessBilling = true;
            }
            if (data && data.existingDiscounts) {
                this.existingDiscounts = data.existingDiscounts;
            }
            if (data && data.potsActionType && data.potsActionType !== undefined) {
                this.potsActionValueType = data.potsActionType;
            }
            if (data && data.orderFlow && data.orderFlow !== undefined && data.orderFlow.flow === "NEWINSTALL") {
                this.isNewInstall = true;
            } else if (data && data.orderFlow && data.orderFlow !== undefined && data.orderFlow.flow === "billing" && data.orderFlow.type === "pending") {
                this.pendingBillingFlow = true;
            }
            if (data && data.orderFlow && data.orderFlow.flow) {
                if (data.orderFlow.flow === 'Change') { this.isChangeFlow = true; }
                if (data.orderFlow.flow === 'billing') { this.billingFlow = true; }
                if (data.orderFlow.flow === 'Move') { this.isMove = true; }
            }
            if (data && data.stackamend && data.stackamend.stackAmendFlag) {
                if (data.stackamend.stackAmendFlag === "amendOrder") {
                    this.isAmend = true;
                }
            }
        });
        this.retainSubscription = this.retainObservable.subscribe((data) => {
            if (data && data.gcardcompatibility && data.gcardcompatibility.giftCardCompatibility) {
                this.gCardCRules = data.gcardcompatibility.giftCardCompatibility;
            }
            if (data && data.isBypassedDiscount && data.isBypassedDiscount === true) {
                this.bypassOption = true;
                this.isBypassed.emit(this.bypassOption);
            }
            if (this.bypassOption && this.isReEntrant) {
                if (data && data.internetDiscounts && data.internetDiscounts.products && data.internetDiscounts.products.length > 0) {
                    this.bypassDiscountCalled = true;
                    data.internetDiscounts.products.map((discount) => {
                        if (discount && discount.discounts && discount.discounts.length > 0) {
                            discount.discounts.map((internetDiscounts) => {
                                this.internetDiscountList.push({ "productId": discount.productId, "isBypassed": true, "discount": internetDiscounts });
                            })
                        }
                    })
                }
                this.discountsObject(null);
            }
        });
        this.retainSubscription.unsubscribe();
        if (this.giftCards && (this.giftCards.length !== undefined)) {
            for (let c = 0; c < this.giftCards.length; c++) {
                this.gCardsList.push({ "giftCardName": this.giftCards[c], "isEnable": true, "isChecked": false, "isBypassed": false });
            }
        }
        this.createClosersPromos();
        this.setDiscountsFromExistingDiscounts(this.existingDiscounts);
        // checking the Closure and Promos Tab Visibility        
        if ((this.hsiRcDiscObj && this.hsiRcDiscObj.length) || (this.potsRcDiscObj && this.potsRcDiscObj.length) || (this.giftCards && this.giftCards.length) || (this.otcDiscWaiveObj && this.otcDiscWaiveObj.length)) {
            this.CloserPromoTab.emit(false);
        } else {
            this.CloserPromoTab.emit(true);
        }
        let customizeService = <Observable<any>>this.store.select('customize');
        customizeService.subscribe((data) => {
            this.expDiscArray = data.expDiscArray;
        });
        let discountIds = [];
        for (let i = 0; i < this.hsiRcDiscObj.length; i++) {
            discountIds.push(this.hsiRcDiscObj[i].discountId);
            this.isExistingDiscounts[this.hsiRcDiscObj[i].discountId] = false;
            this.allDiscounts[this.hsiRcDiscObj[i].discountId] = this.hsiRcDiscObj[i];
        }
        for (let i = 0; i < this.potsRcDiscObj.length; i++) {
            discountIds.push(this.potsRcDiscObj[i].discountId);
            this.isExistingDiscounts[this.potsRcDiscObj[i].discountId] = false;
            this.allDiscounts[this.potsRcDiscObj[i].discountId] = this.potsRcDiscObj[i];
        }
        for (let i = 0; i < this.otcDiscWaiveObj.length; i++) {
            discountIds.push(this.otcDiscWaiveObj[i].discountId);
            this.isExistingDiscounts[this.otcDiscWaiveObj[i].discountId] = false;
            this.allDiscounts[this.otcDiscWaiveObj[i].discountId] = this.otcDiscWaiveObj[i];
        }
        if (this.expDiscArray !== undefined && this.expDiscArray.length > 0) {
            for (let i = 0; i < this.expDiscArray.length; i++) {
                for (let j = 0; j < discountIds.length; j++) {
                    if (this.expDiscArray[i].discountId === discountIds[j]) {
                        discountIds.splice(j, 1);
                    }
                }

            }
        }
        let discountscompatableReq = {
            discountIds
        }

        this.closersandPromosDiscountIds = discountscompatableReq;
        let customize = <Observable<any>>this.store.select('customize');
        customize.subscribe((data) => {
            this.checkedGiftCard = data.selectedGiftCard
            this.reEntrantOfferSelected(this.checkedGiftCard);
            if (data.selectedGiftcardsfromHold) {
                this.reEntrantOfferSelected(data.selectedGiftcardsfromHold);
                data.selectedGiftcardsfromHold = [];
            }
            if (data.recommendationFlag && data.recommendationFlag == true) {
                this.recommendation = true;
            }
        });
        if (discountIds.length > 0) {
            this.retriveCompatibilityLoading = true;
            this.productService.getCompatibilityRulesforClosers(this.closersandPromosDiscountIds)
                .subscribe(data => {
                    this.retriveCompatibilityLoading = false;
                    if (this.isPrepaid && (this.isChangeFlow || this.billingFlow || this.isMove))  // NOTE: this section is temperory fix to avoide adding more than one discount in prepaid change and B&R once roules are fixed we need to remove.
                    {
                        if (data && data.discountCompatibility) {
                            data.discountCompatibility.map(item => { item.message = "INCOMPATIBLE" })
                        }
                    }
                    this.closersPromosCompatibleRes = JSON.stringify(data);
                    if (this.isReEntrant === false && !this.recommendation) {

                        for (let i = 0; i < this.existingRetentionDiscounts.length; i++) {
                            //compare existing discount and the current discount for the offer. If exist pre select
                            for (let j = 0; j < this.hsiRcDiscObj.length; j++) {
                                if (this.hsiRcDiscObj[j].discountId === this.existingRetentionDiscounts[i].discountId && this.existingRetentionDiscounts[i].autoAttachInd !== "Y") {
                                    this.selectedDiscounts.push(this.existingRetentionDiscounts[i]);
                                    this.lastSelectedDiscountObj = this.existingRetentionDiscounts[i];
                                    this.isExistingDiscounts[this.existingRetentionDiscounts[i].discountId] = true;
                                }
                            }
                            for (let k = 0; k < this.potsRcDiscObj.length; k++) {
                                if (this.potsRcDiscObj[k].discountId === this.existingRetentionDiscounts[i].discountId && this.existingRetentionDiscounts[i].autoAttachInd !== "Y") {
                                    this.selectedDiscounts.push(this.existingRetentionDiscounts[i]);
                                    this.lastSelectedDiscountObj = this.existingRetentionDiscounts[i];
                                    this.isExistingDiscounts[this.existingRetentionDiscounts[i].discountId] = true;
                                }
                            }
                            for (let l = 0; l < this.otcDiscWaiveObj.length; l++) {
                                if (this.otcDiscWaiveObj[l].discountId === this.existingRetentionDiscounts[i].discountId && this.existingRetentionDiscounts[i].autoAttachInd !== "Y") {
                                    this.selectedDiscounts.push(this.existingRetentionDiscounts[i]);
                                    this.lastSelectedDiscountObj = this.existingRetentionDiscounts[i];
                                    this.isExistingDiscounts[this.existingRetentionDiscounts[i].discountId] = true;
                                }
                            }
                        }
                        if (this.isAmend) {  // One time charges need to  pre-select only in Amend flow.
                            for (let i = 0; i < this.existingOTCDiscounts.length; i++) {
                                for (let l = 0; l < this.otcDiscWaiveObj.length; l++) {
                                    if (this.otcDiscWaiveObj[l].discountId === this.existingOTCDiscounts[i].discountId && this.existingOTCDiscounts[i].autoAttachInd !== "Y") {
                                        this.selectedDiscounts.push(this.existingOTCDiscounts[i]);
                                        this.lastSelectedDiscountObj = this.existingOTCDiscounts[i];
                                        this.isExistingDiscounts[this.existingOTCDiscounts[i].discountId] = true;
                                    }
                                }
                            }
                        }
                        this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.selectedDiscounts });
                    }
                    if ((this.isReEntrant && this.isReEntrant === true) || this.recommendation) {

                        let cart = <Observable<ShoppingCart>>this.store.select('cart');
                        let reenttrantcartSubscription;
                        reenttrantcartSubscription = cart.subscribe(
                            (data) => {
                                if (data.recommendedDiscounts && data.recommendedDiscounts.length > 0) {
                                    data.recommendedDiscounts.map(data => {
                                        this.selectedDiscounts.push(data);
                                    });
                                }
                                if (data && data.payload && data.payload.discountItems !== undefined && data.payload.discountItems) {
                                    data.payload.discountItems.map((d) => {
                                        this.addselectedDiscounts(d);
                                        if (d.autoAttachInd !== "Y")
                                            this.lastSelectedDiscountObj = d;
                                    }
                                    );

                                    this.hsiRcDiscObj && this.hsiRcDiscObj.map((dHSIObj) => {
                                        this.existingRetentionDiscounts && this.existingRetentionDiscounts.map((dExistRetObj) => {
                                            if (dHSIObj.discountId === dExistRetObj.discountId) {
                                                this.isExistingDiscounts[dExistRetObj.discountId] = true;
                                            }
                                        });
                                    });

                                    this.potsRcDiscObj && this.potsRcDiscObj.map((dPOTsObj) => {
                                        this.existingRetentionDiscounts && this.existingRetentionDiscounts.map((dExistRetObj) => {
                                            if (dPOTsObj.discountId === dExistRetObj.discountId) {
                                                this.isExistingDiscounts[dExistRetObj.discountId] = true;
                                            }
                                        });
                                    });

                                } else {
                                    let customize = <Observable<any>>this.store.select('customize');
                                    let customizesub = customize.subscribe((data) => {
                                        if (data && data.closersandpromosDiscounts) {
                                            data.closersandpromosDiscounts.map((d) => {
                                                this.addselectedDiscounts(d);
                                                this.lastSelectedDiscountObj = d;
                                            }
                                            );
                                        }
                                        if (data && data.selectedDiscountsfromHold) {
                                            let flag = false;
                                            data.selectedDiscountsfromHold.map((d) => {
                                                this.addselectedDiscounts(d);
                                                this.lastSelectedDiscountObj = d;
                                                this.isExistingDiscounts[d.discountId] = true;
                                                flag = true;
                                            });
                                            if (flag) {
                                                this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.selectedDiscounts });
                                            }
                                            data.selectedDiscountsfromHold = [];
                                        }
                                    });
                                    customizesub.unsubscribe();
                                }

                            }
                        );
                        reenttrantcartSubscription.unsubscribe();

                    }

                },
                    (error) => {
                        this.retriveCompatibilityLoading = false;
                        if (error === undefined || error === null)
                            return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                                this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        }
                    });
        }
    }

    public setDiscountsFromExistingDiscounts(existingDiscounts) {
        this.existingRetentionDiscounts = [];
        this.existingOTCDiscounts = [];
        if (existingDiscounts && existingDiscounts.orderDiscounts && existingDiscounts.orderDiscounts[0] && existingDiscounts.orderDiscounts[0].productDiscounts) {
            for (let k = 0; k < existingDiscounts.orderDiscounts.length; k++) {
                for (let i = 0; i < existingDiscounts.orderDiscounts[k].productDiscounts.length; i++) {
                    for (let j = 0; j < existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails.length; j++) {
                        if ((existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j].discountType === 'R' || existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j].discountType === 'P') && (existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j].discountDuration > 1 || this.pendingBillingFlow)) {
                            var tempDiscDetail = existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j];
                            tempDiscDetail.discountExpiryDate = this.getYMDTStoMDY(tempDiscDetail.discountExpiryDate);
                            tempDiscDetail.productId = this.existingDiscounts.orderDiscounts[k].productDiscounts[i].productId;
                            tempDiscDetail.productType = this.existingDiscounts.orderDiscounts[k].productDiscounts[i].productType;
                            this.existingRetentionDiscounts.push(tempDiscDetail);
                        } else {
                            if ((existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j].discountType === 'R' || existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j].discountType === 'P') && (existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j].discountDuration == 1)) {
                                let tempDiscDetail = existingDiscounts.orderDiscounts[k].productDiscounts[i].discountDetails[j];
                                tempDiscDetail.discountExpiryDate = this.getYMDTStoMDY(tempDiscDetail.discountExpiryDate);
                                tempDiscDetail.productId = this.existingDiscounts.orderDiscounts[k].productDiscounts[i].productId;
                                tempDiscDetail.productType = this.existingDiscounts.orderDiscounts[k].productDiscounts[i].productType;
                                this.existingOTCDiscounts.push(tempDiscDetail);
                            }
                        }

                    }
                }
            }

        }
        if ((this.hsiExistingDiscountsData && this.hsiExistingDiscountsData.action !== undefined && this.hsiExistingDiscountsData.action === "NOCHANGE" && this.existingRetentionDiscounts) || (this.potsActionValueType && this.potsActionValueType !== undefined && this.potsActionValueType === "NOCHANGE" && this.existingRetentionDiscounts)) {
            this.existingRetentionDiscounts.forEach((d) => {
                let disFlag = false;
                if (this.hsiRcDiscObj && this.hsiRcDiscObj !== undefined && (this.hsiExistingDiscountsData && this.hsiExistingDiscountsData.action !== undefined && this.hsiExistingDiscountsData.action === "NOCHANGE")) {
                    this.hsiRcDiscObj.forEach((data) => {
                        if (d.discountId === data.discountId) {
                            disFlag = true;
                        }
                    });
                    if (!disFlag && d.discountDuration > 1 && d.productType.toUpperCase() === "INTERNET") {
                        let tempD =

                        {
                            "productId": d.productId,
                            "productType": d.productType,
                            "priceKey": d.priceKey,
                            "autoAttachInd": d.autoAttachInd,
                            "discountId": d.discountId,
                            "discountDescription": d.discountDescription,
                            "discountRate": d.discountRate,
                            "discountMethod": d.discountMethod,
                            "discountLevel": d.discountLevel,
                            "discountDuration": d.discountDuration,
                            "discountType": d.discountType,
                            "discountCategory": d.discountCategory,
                            "discountMaxAmount": d.discountMaxAmount,
                            "discountMinimumAmount": d.discountMinimumAmount,
                            "discountRule": d.discountRule,
                            "discountIdSequence": d.discountIdSequence,
                            "discountStartDate": d.discountStartDate,
                            "discountExpiryDate": d.discountExpiryDate
                        };
                        this.hsiRcDiscObj.push(tempD);
                    }
                    else if (d.discountDuration === 1) {
                        //for OTC , discountDuration will be 1 as communicated by Michael
                        let tempD =
                        {
                            "productId": d.productId,
                            "productType": d.productType,
                            "priceKey": d.priceKey,
                            "autoAttachInd": d.autoAttachInd,
                            "discountId": d.discountId,
                            "discountDescription": d.discountDescription,
                            "discountRate": d.discountRate,
                            "discountMethod": d.discountMethod,
                            "discountLevel": d.discountLevel,
                            "discountDuration": d.discountDuration,
                            "discountType": d.discountType,
                            "discountCategory": d.discountCategory,
                            "discountMaxAmount": d.discountMaxAmount,
                            "discountMinimumAmount": d.discountMinimumAmount,
                            "discountRule": d.discountRule,
                            "discountIdSequence": d.discountIdSequence
                        };
                        this.otcDiscWaiveObj.push(tempD);
                    }
                } else if (this.potsRcDiscObj && this.potsRcDiscObj !== undefined) {
                    this.potsRcDiscObj.forEach((data) => {
                        if (d.discountId === data.discountId) {
                            disFlag = true;
                        }
                    });
                    if (!disFlag && d.discountDuration > 1 && d.productType.toUpperCase() === "VOICE-HP") {
                        let tempD =

                        {
                            "productId": d.productId,
                            "productType": d.productType,
                            "priceKey": d.priceKey,
                            "autoAttachInd": d.autoAttachInd,
                            "discountId": d.discountId,
                            "discountDescription": d.discountDescription,
                            "discountRate": d.discountRate,
                            "discountMethod": d.discountMethod,
                            "discountLevel": d.discountLevel,
                            "discountDuration": d.discountDuration,
                            "discountType": d.discountType,
                            "discountCategory": d.discountCategory,
                            "discountMaxAmount": d.discountMaxAmount,
                            "discountMinimumAmount": d.discountMinimumAmount,
                            "discountRule": d.discountRule,
                            "discountIdSequence": d.discountIdSequence,
                            "discountStartDate": d.discountStartDate,
                            "discountExpiryDate": d.discountExpiryDate
                        };
                        this.potsRcDiscObj.push(tempD);
                    }
                    else if (d.discountDuration === 1) {
                        //for OTC , discountDuration will be 1 as communicated by Michael
                        let tempD =
                        {
                            "productId": d.productId,
                            "productType": d.productType,
                            "priceKey": d.priceKey,
                            "autoAttachInd": d.autoAttachInd,
                            "discountId": d.discountId,
                            "discountDescription": d.discountDescription,
                            "discountRate": d.discountRate,
                            "discountMethod": d.discountMethod,
                            "discountLevel": d.discountLevel,
                            "discountDuration": d.discountDuration,
                            "discountType": d.discountType,
                            "discountCategory": d.discountCategory,
                            "discountMaxAmount": d.discountMaxAmount,
                            "discountMinimumAmount": d.discountMinimumAmount,
                            "discountRule": d.discountRule,
                            "discountIdSequence": d.discountIdSequence
                        };
                        this.otcDiscWaiveObj.push(tempD);
                    }
                }
            })
        }
    }
    public BypassOptionChangeGiftCard = (e: any) => {
        this.bypassOption = <boolean>e.target.checked;
        this.isBypassed.emit(this.bypassOption);
        let bypassGiftCars;
        if (this.bypassOption) {
            let payload = {
                "giftCardRequestedType": "Unqualified",
                "orderRefNumber": ""
            }
            payload.orderRefNumber = this.orderRefNumber
            this.loading = true;
            this.logger.log("info", "closers-promos.component.ts", "getBypassGiftCardsRequest", JSON.stringify(payload));
            this.logger.startTime();
            this.productService.getBypassGiftCards(payload)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "closers-promos.component.ts", "getBypassGiftCardsResponse", error);
                    this.logger.log("error", "closers-promos.component.ts", "getBypassGiftCardsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", "Not Applicable",
                        "SUBMIT_TASK", "closers-promos.component.ts - getGiftCardsAccordingToQualification",
                        "CustomizeService Page",
                        error);
                    return Observable.throwError(null);
                }).subscribe(data => {
                    this.logger.endTime();
                    this.logger.log("info", "closers-promos.component.ts", "getBypassGiftCardsResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "closers-promos.component.ts", "getBypassGiftCardsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    bypassGiftCars = data;
                    this.addBypassedGiftCards(bypassGiftCars)
                });
        } else {
            this.gCardsList = this.gCardsList.filter(item => {
                if (item.isChecked && item.isBypassed) {
                    this.selGiftCard.emit(item.giftCardName);
                }
                return !item.isBypassed;
            })
        }

    }

    public BypassOptionChangeDiscount = (e: any) => {
        this.bypassOption = <boolean>e.target.checked;
        this.isBypassed.emit(this.bypassOption);
        if (this.bypassOption && !this.bypassDiscountCalled) {
            let payload = {
                "orderDetail": { "orderRefNumber": this.orderRefNumber },
                "discountRequestedType": "All",
                "salesChannel": "eSHOP",

            }
            this.loading = true;
            this.logger.log("info", "closers-promos.component.ts", "getBypassInternetDiscountsRequest", JSON.stringify(payload));
            this.logger.startTime();
            this.productService.getBypassInternetDiscounts(payload)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "closers-promos.component.ts", "getBypassInternetDiscountsResponse", error);
                    this.logger.log("error", "closers-promos.component.ts", "getBypassInternetDiscountsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", "Not Applicable",
                        "SUBMIT_TASK", "closers-promos.component.ts - getBypassInternetDiscountsAccordingToQualification",
                        "CustomizeService Page",
                        error);
                    return Observable.throwError(null);
                }).subscribe(data => {
                    this.logger.endTime();
                    this.logger.log("info", "closers-promos.component.ts", "getBypassInternetDiscountsResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "closers-promos.component.ts", "getBypassInternetDiscountssSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'BYPASSED_INTERNET_DISCOUNTS', payload: data });
                    this.loading = false;
                    this.bypassDiscountCalled = true;
                    if (data && data.products) {
                        data.products.forEach((discount) => {
                            if (discount && discount.discounts && discount.discounts.length > 0) {
                                discount.discounts.forEach((internetDiscounts) => {
                                    this.internetDiscountList.push({ "productId": discount.productId, "isBypassed": true, "discount": internetDiscounts });
                                })
                            }
                        })
                    }
                    this.discountsObject(null);
                });
        } else {
            this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: [] });
            this.discountsObject(null);
        }
    }


    public addBypassedGiftCards = (gCards) => {
        gCards.offers.map(item => {
            item.eligibleGiftCardOffer.map(card => this.addGiftCards(card));
        });
    }
    public addGiftCards = (gCard) => {
        let flag = false;
        this.gCardsList.map(card => {
            if (card.giftCardName === gCard.giftcardDisplayName) {
                flag = true;
            }
        })
        if (!flag) {
            this.gCardsList.push({ "giftCardName": gCard.giftcardDisplayName, "isEnable": true, "isChecked": false, "isBypassed": true });
        }
    }

    public getYMDTStoMDY(datetimestamp) {
        return new DatePipe('en-US').transform(datetimestamp, 'M/dd/yyyy');
    }

    public getYMDTStoMDYFromExistingDiscounts(discountID) {
        var expryDate = "";
        if (this.existingRetentionDiscounts && this.existingRetentionDiscounts.length > 0) {

            for (let j = 0; j < this.existingRetentionDiscounts.length; j++) {
                if (discountID === this.existingRetentionDiscounts[j].discountId) {
                    expryDate = this.existingRetentionDiscounts[j].discountExpiryDate
                    break;
                }

            }

        } else {
            expryDate = "";
        }
        return expryDate;
    }

    public reEntrantChecked(discountObj): boolean {
        let isSelected = false;
        for (let i = 0; i < this.selectedDiscounts.length; i++) {
            if (this.selectedDiscounts[i].discountId === discountObj.discountId) {
                this.lastSelectedDiscountObj = this.selectedDiscounts[i];
                isSelected = true;
            }
        }
        return isSelected;
    }

    public reEntrantOfferSelected(giftcards) {
        if (giftcards && giftcards.length) {
            giftcards.forEach(item => {
                this.gCardsList.forEach((card, index) => {
                    if (card && card.giftCardName === item && card.isEnable) {
                        let found = this.gCardsList.splice(index, 1)
                        found[0].isChecked = true;
                        this.gCardsList.splice(index, 0, found[0]);
                    }
                });
            })

        }

    }

    public createClosersPromos() {

        if (this.CPCartObj) {
            let hsiCPObj;
            let potsCPObj;
            let cptabFlag = true;
            hsiCPObj = this.productService.findObjByName(this.CPCartObj.customerOrderItems, 'productType', GenericValues.sData);
            potsCPObj = this.productService.findObjByName(this.CPCartObj.customerOrderItems, 'productType', GenericValues.cHP);
            if (this.isVacSusFlow) {
                if (this.CPCartObj && this.CPCartObj.customerOrderItems && this.CPCartObj.customerOrderItems.length > 0) {
                    this.CPCartObj.customerOrderItems.forEach((obj) => {
                        if (obj.action === 'VACSUS-ADD' && obj.offerCategory === GenericValues.iData) {
                            hsiCPObj = obj;
                        }
                        if (obj.action === 'VACSUS-ADD' && obj.offerCategory === GenericValues.cHP) {
                            potsCPObj = obj;
                        }
                    });
                }
            }
            this.hsiExistingDiscountsData = hsiCPObj;
            this.createHSIClosersPromos(hsiCPObj);
            this.createPOTSClosersPromos(potsCPObj);
            this.hsiMaxDiscountAmount = Math.max(...this.hsiRcDiscObj.map(o => o.discountMaxAmount));
            this.potsMaxDiscountAmount = Math.max(...this.potsRcDiscObj.map(o => o.discountMaxAmount));
            this.otcDiscWaiveMaxDiscountAmount = Math.max(...this.otcDiscWaiveObj.map(o => o.discountMaxAmount));

        }

    }

    public createHSIClosersPromos(hsiCPObj) {
        if (hsiCPObj !== undefined && hsiCPObj.customerOrderSubItems !== undefined) {
            hsiCPObj.customerOrderSubItems.map((item) => {
                this.productId = item.productId;
                this.productType = item.productType;
                let flag = true;
                if (item && item.action && ((item.action.toUpperCase() === 'VACSUS-ADD' && this.isVacResFlow) || (item.action.toUpperCase() === 'VACSUS-REMOVE' && this.isVacSusFlow))) {
                    flag = false;
                }
                if (item.componentType === GenericValues.cPrimary || item.componentType === GenericValues.component) {
                    item.productAttributes.map((attr) => {
                        if (attr.isPriceable && flag) {
                            let disFlag = false;
                            if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                                attr.discounts.map((d) => {
                                    disFlag = false;
                                    this.hsiRcDiscObj.forEach((data) => {
                                        if (d.discountId === data.discountId) {
                                            disFlag = true;
                                        }
                                    })
                                    //filter logic to remove retention from NI flow
                                    if (((this.isNewInstall === true && d.discountType !== 'R') || this.isNewInstall !== true) && d.autoAttachInd === 'N') {
                                        if (disFlag === false) {
                                            this.internetDiscountList.push({ "productId": item.productId, "isBypassed": false, "discount": d });
                                            disFlag = false;
                                        }

                                    }
                                })
                            }
                            this.discountsObject(attr);
                        }
                    })
                }
            })
            /** Discount sorting */
            this.hsiRcDiscObj.sort(function (a, b) {
                return a.discountIdSequence - b.discountIdSequence
            })
        }
    }

    private discountsObject(attr?: any) {
        this.hsiRcDiscObj = [];
        this.otcDiscWaiveObj = [];
        this.internetDiscountList.map((discounts) => {
            if (this.bypassOption && discounts.isBypassed) {
                this.addInternetDiscount(discounts.discount, discounts.productId, attr);
            } else if (!this.bypassOption && !discounts.isBypassed) {
                this.addInternetDiscount(discounts.discount, discounts.productId, attr);
            }
        })
    }

    private addInternetDiscount(d: any, productId: any, attr?: any) {
        if (d.discountDuration > 1) {
            let tempD = {
                "productId": productId,
                "productType": this.productType,
                "priceKey": d.priceId ? d.priceId : attr && attr.prices && attr.prices[0] && attr.prices[0].priceKey,
                "autoAttachInd": d.autoAttachInd,
                "discountId": d.discountId,
                "discountDescription": d.discountDescription,
                "discountRate": d.discountRate,
                "discountMethod": d.discountMethod,
                "discountLevel": d.discountLevel,
                "discountDuration": d.discountDuration,
                "discountType": d.discountType,
                "discountCategory": d.discountCategory,
                "discountMaxAmount": d.discountMaxAmount,
                "discountMinimumAmount": d.discountMinimumAmount,
                "discountRule": d.discountRule,
                "discountIdSequence": d.discountIdSequence
            };
            this.hsiRcDiscObj.push(tempD);
        }
        else if (d.discountDuration === 1) {
            //for OTC , discountDuration will be 1 as communicated by Michael
            let tempD = {
                "productId": productId,
                "productType": this.productType,
                "priceKey": d.priceId ? d.priceId : attr && attr.prices && attr.prices[0] && attr.prices[0].priceKey,
                "autoAttachInd": d.autoAttachInd,
                "discountId": d.discountId,
                "discountDescription": d.discountDescription,
                "discountRate": d.discountRate,
                "discountMethod": d.discountMethod,
                "discountLevel": d.discountLevel,
                "discountDuration": d.discountDuration,
                "discountType": d.discountType,
                "discountCategory": d.discountCategory,
                "discountMaxAmount": d.discountMaxAmount,
                "discountMinimumAmount": d.discountMinimumAmount,
                "discountRule": d.discountRule,
                "discountIdSequence": d.discountIdSequence
            };
            this.otcDiscWaiveObj.push(tempD);
        }
    }

    public getAllDiscounts(CPCartObj) {
        let discountsArray: any[] = [];
        CPCartObj && CPCartObj.customerOrderItems && CPCartObj.customerOrderItems.map((orderItems) => {
            orderItems && orderItems.customerOrderSubItems && orderItems.customerOrderSubItems.map((subItems) => {
                subItems && subItems.productAttributes && subItems.productAttributes.map((prodAttr) => {
                    if (prodAttr && prodAttr.discounts && prodAttr.discounts.length > 0) {
                        prodAttr.discounts.map((discount) => {
                            discountsArray.push(discount);
                        });
                    }
                });
            });
        });
        return discountsArray;
    }

    public createPOTSClosersPromos(potsCPObj) {
        if (potsCPObj !== undefined && potsCPObj.customerOrderSubItems !== undefined) {
            potsCPObj.customerOrderSubItems.map((item) => {
                let productId = item.productId;
                let productType = item.productType;
                let flag = true;
                if (item && item.action && (item.action.toUpperCase() === 'VACSUS-REMOVE' && this.isVacSusFlow)) {
                    flag = false;
                }
                if (item.componentType === GenericValues.cPrimary) {
                    item.productAttributes.forEach((attr) => {
                        if (attr.isPriceable && flag) {
                            let disFlag = false;
                            if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                                attr.discounts.forEach((d) => {
                                    this.potsRcDiscObj.forEach((data) => {
                                        if (d.discountId === data.discountId) {
                                            disFlag = true;
                                        }
                                    });
                                    if (d.autoAttachInd === 'N') {
                                        if (disFlag === false) {
                                            if (d.discountDuration > 1) {
                                                let tempD =
                                                {
                                                    "productId": productId,
                                                    "productType": productType,
                                                    "priceKey": attr.prices[0].priceKey,
                                                    "autoAttachInd": d.autoAttachInd,
                                                    "discountId": d.discountId,
                                                    "discountDescription": d.discountDescription,
                                                    "discountRate": d.discountRate,
                                                    "discountMethod": d.discountMethod,
                                                    "discountLevel": d.discountLevel,
                                                    "discountDuration": d.discountDuration,
                                                    "discountType": d.discountType,
                                                    "discountCategory": d.discountCategory,
                                                    "discountMaxAmount": d.discountMaxAmount,
                                                    "discountMinimumAmount": d.discountMinimumAmount,
                                                    "discountRule": d.discountRule,
                                                    "discountIdSequence": d.discountIdSequence
                                                };
                                                this.potsRcDiscObj.push(tempD);
                                            } else if (d.discountDuration === 1) {
                                                //for OTC , discountDuration will be 1 as communicated by Michael
                                                let tempD =
                                                {
                                                    "productId": productId,
                                                    "productType": productType,
                                                    "priceKey": attr.prices[0].priceKey,
                                                    "autoAttachInd": d.autoAttachInd,
                                                    "discountId": d.discountId,
                                                    "discountDescription": d.discountDescription,
                                                    "discountRate": d.discountRate,
                                                    "discountMethod": d.discountMethod,
                                                    "discountLevel": d.discountLevel,
                                                    "discountDuration": d.discountDuration,
                                                    "discountType": d.discountType,
                                                    "discountCategory": d.discountCategory,
                                                    "discountMaxAmount": d.discountMaxAmount,
                                                    "discountMinimumAmount": d.discountMinimumAmount,
                                                    "discountRule": d.discountRule,
                                                    "discountIdSequence": d.discountIdSequence
                                                };
                                                this.otcDiscWaiveObj.push(tempD);
                                            }
                                            disFlag = false;
                                        }
                                    }
                                })
                            }
                        }
                    })
                }
            })
        }
    }

    public selectedGIftcard(giftcard: any, e: any) {
        this.selGiftCard.emit(giftcard);
        this.flag = e.target.checked;
        this.targetGiftCard = [];
        for (let i = 0; i < this.gCardsList.length; i++) {
            if (giftcard === this.gCardsList[i].giftCardName) {
                this.gCardsList[i].isChecked = true;
            }
        }
    }
    public getGCardCompatibilityRules(item: any) {
        if (this.gCardCRules && this.gCardCRules !== undefined) {
            for (let i = 0; i < this.gCardCRules.length; i++) {
                if (this.gCardCRules[i].sourceGiftCardOfferName === item.giftCardName && this.gCardCRules[i].message === "Incompatiable") {
                    this.targetGiftCard.push(this.gCardCRules[i].targetGiftCardOfferName);
                }
            }
        }
        this.targetGiftCard.map((c) => {
            for (let p = 0; p < this.gCardsList.length; p++) {
                if (this.flag === true && c === this.gCardsList[p].giftCardName) {
                    if (this.gCardsList[p].isChecked === true) {
                        this.gCardsList[p].isChecked = false;
                        this.gCardsList[p].isEnable = false;
                    } else {
                        this.gCardsList[p].isEnable = false;
                    }
                }
                if (this.flag === false) {
                    this.gCardsList[p].isEnable = true;
                }
            }
        })
    }

    public addselectedDiscounts = (discountObj) => {

        let index = this.selectedDiscounts.findIndex(d => d.discountId === discountObj.discountId);
        if (index === -1) {
            // Need to add child discounts if parent discount is selected
            if (discountObj.discountRule === null || (discountObj.discountRule && discountObj.discountRule === "Parent Discount")) {
                this.allDiscountsArray.forEach((cDiscount) => {
                    if (cDiscount && cDiscount.discountRule && cDiscount.discountRule === "Child Discount") {
                        let cIndex = this.selectedDiscounts.findIndex(cd => cd.discountId === cDiscount.discountId);
                        if (cIndex === -1) {
                            this.selectedDiscounts.push(cDiscount);
                        }
                    }
                });
            }

            this.selectedDiscounts.push(discountObj);
        }
    }

    public setUnsetSelectedDiscount(discountObj: any, e: any) {
        if (e.target.checked === true) {
            
            let isDiscountPushed = false;

            if (this.hsiRcDiscObj.length > 0 && isDiscountPushed === false) {

                this.addselectedDiscounts(discountObj);
                this.lastSelectedDiscountObj = discountObj;
                isDiscountPushed = true;
                // this.custom.undoChanges();
                this.ctlHelperService.setUndoChanges(true);
            } else {
                this.ctlHelperService.setUndoChanges(false);
            }

            if (this.potsRcDiscObj.length > 0 && isDiscountPushed === false) {
                this.addselectedDiscounts(discountObj);
                this.lastSelectedDiscountObj = discountObj;
                isDiscountPushed = true;
            }

            if (this.otcDiscWaiveObj.length > 0 && isDiscountPushed === false) {
                this.addselectedDiscounts(discountObj);
                this.lastSelectedDiscountObj = discountObj;
            }
        } else if (e.target.checked === false) {


            this.selectedDiscounts.splice(this.selectedDiscounts.findIndex(x => x.discountId === discountObj.discountId), 1);

            // Need to remove child discounts if parent discount is un-selected
            if (discountObj.discountRule === null || (discountObj.discountRule && discountObj.discountRule === "Parent Discount")) {
                this.allDiscountsArray.forEach((cDiscount) => {
                    if (cDiscount && cDiscount.discountRule && cDiscount.discountRule === "Child Discount") {
                        let cIndex = this.selectedDiscounts.findIndex(cd => cd.discountId === cDiscount.discountId);
                        if (cIndex !== -1) {
                            this.selectedDiscounts.splice(cIndex, 1);
                        }
                    }
                });
            }

            this.hsiRcAlertMsg = '';
            this.potsRcAlertMsg = '';
            this.OtcDiscWaiveAlertMsg = '';
            this.lastSelectedDiscountObj = '';

        }
        this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.selectedDiscounts });

    }
    public unsetChanges() {
        this.selectedDiscounts = [];
    }

    public isDiscountInCompatibleWithSelectedDiscounts(discountObj): boolean {

        let isDiscIncompatible = false;
        let tempIncompatibleToolTipStr = '';
        if (this.lastSelectedDiscountObj !== undefined && this.lastSelectedDiscountObj !== '') {
            isDiscIncompatible = this.isDiscountInCompatible(this.lastSelectedDiscountObj.discountId, discountObj.discountId);
        }
        for (let i = 0; i < this.selectedDiscounts.length; i++) {
            //in case the current watcher triggered discount id incompatible with many selected
            isDiscIncompatible = this.isDiscountInCompatible(this.selectedDiscounts[i].discountId, discountObj.discountId);
            if (isDiscIncompatible) {
                if (tempIncompatibleToolTipStr !== '') {
                    tempIncompatibleToolTipStr = tempIncompatibleToolTipStr + ' , ' + this.allDiscounts[this.selectedDiscounts[i].discountId].discountDescription;
                } else {
                    tempIncompatibleToolTipStr = this.allDiscounts[this.selectedDiscounts[i].discountId].discountDescription;
                }
                break;
            }
        }
        this.discountIDToolTipStr = '';
        if (tempIncompatibleToolTipStr !== '') {
            this.discountIDToolTipStr = 'Cannot combine with ' + tempIncompatibleToolTipStr;
        }
        return isDiscIncompatible;

    }

    public isDiscountInCompatible(sourceDiscountID, targetDiscountID): boolean {
        let compatibleResobj = JSON.parse(this.closersPromosCompatibleRes);
        let isSelectedDiscount = false;
        let isDiscIncompatible = false;
        if (this.selectedDiscounts.findIndex(x => x.discountId === targetDiscountID) !== -1) {
            isSelectedDiscount = true;
        }
        compatibleResobj.discountCompatibility.map((compatibleObj) => {
            if (isSelectedDiscount === false && (compatibleObj.discountCode === sourceDiscountID || compatibleObj.discountCode === targetDiscountID) && (compatibleObj.targetDiscountCode === targetDiscountID || compatibleObj.targetDiscountCode === sourceDiscountID) && compatibleObj.message === "INCOMPATIBLE") {
                isDiscIncompatible = true;
            }
        });
        return isDiscIncompatible;

    }
}