import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStore } from 'app/common/models/appstore.model';
import { ContactInfo, CustomerOrderItems, ShoppingCart } from 'app/common/models/cart.model';
import { GenericValues } from 'app/common/models/common.model';
import { OfferVariables } from 'app/common/models/offers.model';
import { Products } from 'app/common/models/product.model';
import { User } from 'app/common/models/user.model';
import { AddressService } from 'app/common/service/address.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { HelperService } from "app/common/service/helper.service";
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import * as _ from 'lodash';
import "rxjs/add/operator/catch";
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';

@Component({
    selector: 'product-offer',
    styleUrls: ['./offer.component.scss'],
    templateUrl: './offer.component.html'
})
export class OfferComponent implements OnInit, OnDestroy {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public offerVariables: OfferVariables;
    public cartOrd: CustomerOrderItems;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public pendingObservable: Observable<any>;
    public pendingSubscription: Subscription;
    public orderObservable: Observable<any>;
    public orderSubscription: Subscription;
    public prodConfig: any;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    public reqDeposit: boolean = false;
    public flowType: string;
    public loadedReEntrant: boolean = false;
    public retainVal: Observable<any>;
    public customize: Observable<ShoppingCart>;
    public isExpiredOffer: boolean = false;

    // below var exists in html but not declared in ts file -> temp fix for AOT build
    public directvAccountId: any;
    public dtvExisting: any;
    public isOptedOut: any;
    public isChange: any;
    public isMove: any;
    public ban: any;
    public fromHold: any;
    public hdPrice: any;
    public availSpeeds: any;
    public technologyTypes: any;
    public apiResponseError: any;
    public configSubmited: any;
    public isContinueClickedError = false;
    @ViewChild('expiredOffer', { static: false, }) public expiredOffer: DialogComponent;
    public addOfferExpiredflag: boolean;

    constructor(
        public logger: Logger,
        public store: Store<AppStore>,
        public router: Router,
        public productService: ProductService,
        public appStateService: AppStateService,
        public systemErrorService: SystemErrorService,
        public addressService: AddressService,
        public ctlHelperService: CTLHelperService,
        public helperService: HelperService,
        public offerHelperService: OfferHelperService,
        public propertiesHelperService: PropertiesHelperService,
    ) {
        this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);
        this.offerVariables.newInternetCheck = undefined;
        this.offerVariables.hsiCatalogId = undefined;
        this.appStateService.setLocationURLs();
        this.offerVariables.speedList = [{
            productName: '',
            productDisplayName: ''
        }];
        this.user = this.store.select('user');
        this.existingObservable = this.store.select('existingProducts');
        this.offerVariables.discountedPriceList = [];
        this.offerVariables.currentFlow = "NI";
        let addons: CustomerOrderItems[];
        const cart = this.store.select('cart');
        const cartSubscription = cart.subscribe((data) => {
            if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
                addons = data.payload.cart.customerOrderItems;
                addons[0].customerOrderSubItems.forEach((data) => {
                    if (data.componentType === "PRIMARY")
                        this.offerVariables.selectedValues = data.productName;
                });
                this.cartOrd = this.offerHelperService.findCustomerOrderProduct(addons, GenericValues.iData, true);
            }
            if (data && data.payload && data.payload.discountItems) {
                this.offerVariables.discountsAdded = data.payload.discountItems
            }
        })
        if (cartSubscription !== undefined)
            cartSubscription.unsubscribe();

        this.offerVariables.isProfileBypassLoopQual = this.helperService.isAuthorized(ProfileEnums.BYPASS_LOOP_QUAL);
        this.offerVariables.isProfileBypassHSISpeeds = this.helperService.isAuthorized(ProfileEnums.BYPASS_HSI_SPEEDS);
        this.offerVariables.isProfileBypassModemCheck = this.helperService.isAuthorized(ProfileEnums.BYPASS_MODEM_CHECK);
        this.offerVariables.internetOffer = true;
        this.offerVariables.videoSelectedTemp = '';
        this.offerVariables.internetAvail = false;
        this.offerVariables.videoAvail = false;
        this.offerVariables.phoneAvail = false;
        this.offerVariables.videoSelected = 'NoTV';
        this.offerVariables.phoneSelected = GenericValues.noPhone;
        this.offerVariables.offersGenerated = true;
        this.offerVariables.serviceUnavailable = 'Service not available for your Address';
        this.offerVariables.currentComponentName = "offer.component.ts";
        this.offerVariables.flow = 'NEWINSTALL';
        const prod: Products = {
            productId: '608',
            productName: 'Intrastate Service Fee',
            productType: 'Service',
            isRegulated: false
        };
        let state: boolean = false;
        this.offerVariables.intraStateFee = prod;
        this.offerVariables.holdCalled = false;
        this.existingSubscription = this.existingObservable.subscribe(
            (exist) => {
                this.offerVariables.selectedSalesExpiredOfferId = exist.offerId;
                if (exist.orderFlow.type === 'fromHold') {
                    this.offerVariables.fromHold = true;
                }

                // for held orders, perform BM init call for service address
                // There should have a retrieveProductsAndServices call before this BM init service call
                state = this.offerHelperService.initialize(this.offerVariables, exist, state, store);
            });
            if(this.existingSubscription !== undefined) {
                this.existingSubscription.unsubscribe();
            }
        this.isExpiredOffer = this.helperService.isAuthorized(ProfileEnums.ALLOW_SALE_EXPIRED_OFFERS) && this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_EXPIRED_OFFERS);
    }

    public ngOnInit() {
        this.offerHelperService.getReentrantFlags(this.offerVariables);
        this.offerHelperService.getTechnologyTypes(this.offerVariables);
        this.offerHelperService.compatibilityAPIcall(this.offerVariables);
        this.offerHelperService.checkCSCompatibitlity(this.offerVariables);
        window.scroll(0, 0);
        this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: { type: '', selected: '' } } });
        this.logger.metrics('OfferPage');
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
        if (this.pendingSubscription !== undefined) this.pendingSubscription.unsubscribe();
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
    }

    public addOfferExpired(event) {
        this.addOfferExpiredflag = event;
    }

    public getExpiredOffers() {
        this.offerHelperService.retrieveExpiredOffers(this.offerVariables, (data) => { this.expiredOffer.open(); });
    }
}