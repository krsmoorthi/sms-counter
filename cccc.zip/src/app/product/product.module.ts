import { TextMaskService } from './../common/service/text-mask.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { OfferComponent } from './offer.component';
import { SharedModule } from '../shared/shared.module';
import { TooltipModule } from 'ngx-bootstrap';
import { SharedCommonModule } from 'app/shared/shared-common.module';

const routes: Routes = [
    {
        path: '', component: OfferComponent, 
    }
];

@NgModule({
    imports: [FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        SharedModule,
        SharedCommonModule,
        TooltipModule.forRoot()
    ],
    exports: [
        OfferComponent,
    ],
    declarations: [
        OfferComponent,
    ],
    providers: [TextMaskService]
})

export class ProductModule { }
