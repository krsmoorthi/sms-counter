import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferChangeComponent } from './offer-change.component';
import { MockServer } from 'app/MockServer.test';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TooltipModule } from 'ngx-bootstrap';
import { Observable } from 'rxjs';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger, MockProductService, MockAppStateService, MockSystemErrorService, MockAddressService, MockHelperService, MockOfferHelperService, MockReviewOrderService, MockPendingOrderService, MockAccountService, MockBlueMarbleService, MockCountryStateService, MockDirectvService, MockPropertiesHelperService, MockDisconnectService, MockDisclosuresService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { Store } from '@ngrx/store';
import { ProductService } from 'app/common/service/product.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { AddressService } from 'app/common/service/address.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { RouterTestingModule } from '@angular/router/testing';
import "rxjs/add/observable/of";
import { DisclosuresService } from 'app/common/service/disclosures.service';

describe('OfferChangeComponent', () => {
  let component: OfferChangeComponent;
  let fixture: ComponentFixture<OfferChangeComponent>;
  const mockServer = new MockServer();
  
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    SharedCommonModule,
    TooltipModule.forRoot(),
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ]

  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }

  class MockAppStateService {
    setLocationURLs() {}
    getState() {
      return mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE");
    }
  }

  // component provides
  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const productService = { provide: ProductService, useClass: MockProductService };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const cTLHelperService = CTLHelperService;
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const offerHelperService = { provide: OfferHelperService, useClass: MockOfferHelperService };
  const propertiesHelperService = PropertiesHelperService;

  // dialog component providers list
  const reviewOrderService = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService};
  const accountService = {provide: AccountService, useClass: MockAccountService};
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const directvService = {provide: DirectvService, useClass: MockDirectvService};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const disclosuresService = {provide: DisclosuresService, useClass: MockDisclosuresService};

  const providers = [
    logger, store, productService, appStateService, systemErrorService, addressService, cTLHelperService,
    helperService, offerHelperService, propertiesHelperService, reviewOrderService, pendingOrderService,
    accountService, blueMarbleService, countryStateService, directvService, disconnectService, disclosuresService
  ];

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      imports: imports,
      declarations: [ OfferChangeComponent ],
      providers: providers
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferChangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  xit('should call setDeposit for billingType POSTPAID', () => {
    component.setDeposit('POSTPAID');
    expect(component).toBeTruthy();
  });

  xit('should call setDeposit for billingType PREPAID', () => {
    component.setDeposit('PREPAID');
    expect(component).toBeTruthy();
  });

  // it('should call doUndo', () => {
  //   component.offerVariables.isDHPRemoved = true;
  //   component.doUndo();
  //   expect(component.offerVariables.undoChanges).not.toBeTruthy();
  //   expect(component.offerVariables.phoneOffer).toBeTruthy();
  //   expect(component.offerVariables.isDHPRemoved).not.toBeTruthy();
  // });

  // it('should call removeExistingProduct', () => {
  //   component.removeExistingProduct({type: 'removeInternetNotLast'});
  //   expect(component.offerVariables.undoFlag).toBeTruthy();
  // });

});
