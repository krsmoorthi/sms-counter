import { Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { OfferVariables } from 'app/common/models/offers.model';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { HelperService } from "app/common/service/helper.service";
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStore } from 'app/common/models/appstore.model';
import { CustomerOrderItems, ShoppingCart } from 'app/common/models/cart.model';
import { GenericValues } from 'app/common/models/common.model';
import { AttributesCombination, CompositeAttribute, OfferProductComponents, PayloadProduct, Products } from 'app/common/models/product.model';
import { User } from 'app/common/models/user.model';
import { AppStateService } from 'app/common/service/app-state.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { DialogComponent } from 'app/common/popup/dialog.component';
import * as _ from 'lodash';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
    selector: 'change-product',
    styleUrls: ['./../offer.component.scss'],
    templateUrl: './offer-change.component.html'
})

export class OfferChangeComponent implements OnInit, OnDestroy, AfterViewInit {    
    public offerVariables: OfferVariables;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public userSubscription1: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public pendingSubscription: Subscription;
    public pendingObservable: Observable<any>;
    public existingData:any
    
    @ViewChild("removeProduct", { static: false, }) public removeProduct: any;
    @ViewChild("e911Validation", { static: false, }) public e911Validation: any;
    @ViewChild("removeProduct", { static: false, }) public removeProductOpen: any;
    @ViewChild('voiceMailInput', { static: false, }) public voiceMailInput: ElementRef;
    @ViewChild('wireMaintainanceInput', { static: false, }) public wireMaintainanceInput: ElementRef;
    @ViewChild('portingInput', { static: false, }) public portingInput: ElementRef;
    @ViewChild('easeSelected', { static: false, }) public easeSelected: ElementRef;
    @ViewChild('secureWifiSelected', { static: false, }) public secureWifiSelected: ElementRef;
    public existingTN;
    public orderObservable: Observable<any>;
    public orderSubscription: Subscription;
    public cartSubscription: Subscription;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;		
    @ViewChild('recommendedError', { static: false, }) public recommendedError: DialogComponent;
    public isExpiredOffer: boolean = false;

    constructor(
        private logger: Logger,
        public store: Store<AppStore>,
        private router: Router,
        public productService: ProductService,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private disconnectServiceCall: DisconnectService,
        private bMService: BlueMarbleService,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
        public offerHelperService: OfferHelperService
    ) {
        let addons: CustomerOrderItems[];
        this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);  
        let cart = <Observable<ShoppingCart>>this.store.select('cart');
        if(this.offerVariables){ 
            let cartSubscription = cart && cart.subscribe((data) => {
                if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
                    addons = data.payload.cart.customerOrderItems;
                    addons[0].customerOrderSubItems.forEach(data => {
                        if (data.componentType === "PRIMARY")
                    this.offerVariables.discloserPopUpSelected = data.productName;
                    });
                }    
                if (data && data.payload && data.payload.discountItems) {
                    this.offerVariables.discloserPopUpSelected = data.payload.discountItems;
                    this.offerVariables.copyOfDiscountsAdded = this.offerVariables.discloserPopUpSelected;
                }        
            })
            if (cartSubscription !== undefined)
                cartSubscription.unsubscribe();
        }        
        this.offerHelperService.initilizeAll(this.offerVariables);
        this.offerVariables.currentComponentName = 'offer-change.component.ts';
        this.isExpiredOffer = this.helperService.isAuthorized(ProfileEnums.ALLOW_SALE_EXPIRED_OFFERS);      
    }   

    public ngAfterViewInit() {
        this.offerVariables.recommendedError = this.recommendedError;
        this.offerVariables.e911Validation = this.e911Validation;
        this.offerVariables.currentFlow = "CHANGE";
        this.offerVariables.secureWifiSelected = this.secureWifiSelected;
        this.offerVariables.easeSelected= this.easeSelected;
        this.offerVariables.voiceMailInput= this.voiceMailInput;
        this.offerVariables.wireMaintainanceInput= this.wireMaintainanceInput;
        this.offerVariables.portingInput= this.portingInput;
    }                	      

    public ngOnInit() { 
        this.offerHelperService.onInitPage(this.offerVariables);
    }              
 
    /**
     * Populate default component value in dropdowns
     * @param defaultVal
     * @param addons
     */
   
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.userSubscription1 !== undefined) {
            this.userSubscription1.unsubscribe();
        }
        if (this.existingSubscription !== undefined) {
            this.existingSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
    }   

 /*   public removeExistingProduct(removed: any) {
        this.offerVariables.undoFlag = true;
        this.offerVariables.removeSelectedReason = removed.removeReason;
        if (removed.type === 'removeInternetNotLast') {
            //iterate over cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.sData ||
                    item.offerCategory === GenericValues.iData) {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.hsiCatalogId;
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    this.offerVariables.isInternetRemoved = true;

                    this.offerVariables.internetCheck = false;
                    this.offerVariables.newInternetCheck = false;

                    this.offerHelperService.retrieveOffers(this.offerVariables, true);
                }
            });
        }
        if (removed.type === 'optOut') {
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.cDTV) {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.dtvCatalogId;
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    this.offerVariables.isOptedOut = true;

                    this.offerVariables.videoOffer = false;
                    this.offerVariables.videoSelected = 'NoTV';
                    this.offerVariables.newVideoSelected = 'NoTV';

                    this.offerVariables.optedOutCheck = true;

                    this.offerHelperService.retrieveOffers(this.offerVariables,true);
                }
            });
        }
        if (removed.type === 'removePrism') {
            //iterate over cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === 'VIDEO-PRISM') {
                    item.action = 'REMOVE';
                    this.offerVariables.removedProductItem.push(item);
                    this.offerVariables.isRemoved = true;

                    this.offerVariables.videoOffer = false;
                    this.offerVariables.videoSelected = 'NoTV';
                    this.offerVariables.newVideoSelected = 'NoTV';

                    if (this.offerVariables.dataLink === undefined && this.offerVariables.preserveHSI !== undefined) {
                        this.offerVariables.dataLink = this.offerVariables.preserveHSI;
                    }
                    this.offerHelperService.retrieveOffers(this.offerVariables, true);
                }
            });
        }
        if (removed.type === 'removeDhp' || removed.type === 'removeHp') {
            //iterate over cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.phoneCatalogId? this.offerVariables.existingServices[i].catalogId = this.offerVariables.phoneCatalogId : this.offerVariables.hsiCatalogId; 
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    let is911 = false;
                    removed.type === 'removeDhp' ? this.offerVariables.isDHPRemoved = true : this.offerVariables.isHPRemoved = true;
                    if (this.offerVariables.newPhoneSelected === 'DHP' && !this.offerVariables.dhpExisting) {
                        this.e911Validation.open();
                        is911 = true;
                    } else if ((this.offerVariables.newPhoneSelected === 'HMP' && removed.type === 'removeHp') ||
                        (this.offerVariables.newPhoneSelected === 'DHP' && removed.type === 'removeDhp')) {
                        this.offerVariables.phoneOffer = false;
                        this.offerVariables.phoneSelected = GenericValues.noPhone;
                        this.offerVariables.newPhoneSelected = GenericValues.noPhone;
                    }

                    !is911 ? this.offerHelperService.retrieveOffers(this.offerVariables, true) : '';
                }
            });
        }
        if (removed.type === 'removeInternet' || (removed.type === 'removeLastInternet' && removed.subType === 'Remove Internet and Add Home Phone')) {
            //iterate over this.offerVariables.cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory && this.offerVariables.existingServices[i].customerOrderSubItems &&
                            this.offerVariables.existingServices[i].customerOrderSubItems.length > 0) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.existingServices[i].catalogId === null ? this.offerVariables.hsiCatalogId : this.offerVariables.existingServices[i].catalogId;
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    this.offerVariables.isInternetRemoved = true;

                    this.offerVariables.internetCheck = false;
                    this.offerVariables.phoneSelected = 'HMP';
                    this.offerVariables.newInternetCheck = false;
                    this.offerVariables.newPhoneSelected = 'HMP';

                    this.offerHelperService.retrieveOffers(this.offerVariables,true);
                }
            });
        }
        if (removed.type === 'removeLastInternet' && removed.subType === 'Remove Internet and Close') {
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                    this.offerVariables.removedProductItem.push(item);
                }
            });
            let services = [{
                "offerCategory": this.offerVariables.removedProductItem[0].offerCategory,
                "reasonType": this.offerVariables.removeSelectedReason.rsnType,
                "reasonText": null,
                "reasonList": [{
                    "code": this.offerVariables.removeSelectedReason.rsnCode,
                    "description": this.offerVariables.removeSelectedReason.chgDesc,
                    "waiverFlag": "No"
                }],
                "etfInfo": {
                    "terminationFee": "0",
                    "currencyCode": "USD",
                    "contractExpiryDate": null
                }
            }];
            let apiRequest = {
                orderRefNumber: this.offerVariables.orderRefNumber,
                processInstanceId: this.offerVariables.processInstanceId,
                taskId: this.offerVariables.taskId,
                taskName: 'Select Disconnect Reason',
                payload: {
                    disconnectInfo: services
                }
            }

            this.offerVariables.loading = true;
            this.logger.log("info", "offer-change.component.ts", "disconnectSubmitInfoServcRequest", JSON.stringify(apiRequest));
            this.logger.startTime();
            this.disconnectServiceCall.submitInformation(apiRequest)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-change.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-change.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    return Observable.throw(
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error", "Not Applicable",
                            "Submit Task", "offer.component.ts",
                            "Disconnect call - Offers Page",
                            error));
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "offer-change.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(data ? data : ''));
                        this.logger.log("info", "offer-change.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.offerVariables.loading = false;
                        this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                        this.router.navigate(['/disconnect-schedule']);
                    },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "offer-change.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(error));
                        this.logger.log("error", "offer-change.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.offerVariables.loading = false;
                        if (error === undefined || error === null)
                            return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.offerVariables.apiResponseError = JSON.parse(error);
                            if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                                this.offerVariables.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Pending Summary", "offer.component.ts", "Offers Page", this.offerVariables.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Pending Summary", "offer.component.ts", "Offers Page", lAPIErrorLists);
                        }
                        this.offerVariables.retrieveOffersLoading = false;
                        window.scroll(0, 0);
                    });
        }
    }
*/
    public setDeposit(billingType?) {
        if(billingType !== "PREPAID") {

            this.offerHelperService.retrieveSecurityDepositHistory(this.offerVariables,this.removeProduct,this.removeProductOpen);
        }else{
            this.removeProductOpen.open();
        }
    }
}
