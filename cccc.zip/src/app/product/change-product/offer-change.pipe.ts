import { Pipe, PipeTransform } from '@angular/core'

@Pipe({name: 'speedFilter'})
export class speedFilterPipe implements PipeTransform {
    transform(value: any[], filterObj:Object ) : any {
        if(filterObj && (filterObj['name'] === "Self Install Only")) {
            return value.filter(speed => speed.techInstall === filterObj['isExist']);
        }

        if(filterObj && (filterObj['name'] === "Existing modem")) {
            return value.filter(speed => speed.modem === filterObj['isExist']);
        } else {
            return value;
        }
    }

}