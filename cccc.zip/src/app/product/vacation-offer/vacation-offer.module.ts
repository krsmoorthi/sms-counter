import { TextMaskService } from './../../common/service/text-mask.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { TooltipModule } from 'ngx-bootstrap';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { VacationOfferComponent } from './vacation-offer.component';

const routes: Routes = [
    {
        path: '', component: VacationOfferComponent
    }
];

@NgModule({
    imports: [FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        SharedModule,
        SharedCommonModule,
        TooltipModule.forRoot()
    ],
    exports: [
        VacationOfferComponent
    ],
    declarations: [
        VacationOfferComponent
    ],
    providers: [
        TextMaskService
    ]
})

export class VacationOfferModule { }
