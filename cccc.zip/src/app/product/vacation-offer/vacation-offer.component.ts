import { DisconnectService } from './../../common/service/disconnect.service';
import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { User } from './../../common/models/user.model';
import { DatePipe } from '@angular/common';
import { ShoppingCart, Payload, CustomerOrderItems, CustomerOrderSubItem} from './../../common/models/cart.model';
import {
    ServiceCategoryBasedOffers,
    OfferProductComponents, AssociatedOffers,
    ProductOfferings, Products, AttributesCombination, Catalogs,
    Prices, ServiceCategoryId, Product, Discounts,
    OfferGroup, OfferItems, PayloadProduct, CompositeAttribute, filterObjModel
} from './../../common/models/product.model';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { AppStore } from './../../common/models/appstore.model';
import { ProductService } from './../../common/service/product.service';
import { AppStateService } from './../../common/service/app-state.service';
import { Logger } from './../../common/logging/default-log.service';
import { GenericValues, serverErrorMessages, APIErrorLists } from './../../common/models/common.model';
import { SystemErrorService } from './../../common/service/system-error.service';
import { cloneDeep } from 'lodash';
import { BlueMarbleService } from '../../common/service/bm.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { VacationEnums } from 'app/common/enums/vacationEnums';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
    selector: 'vacation-restore-product',
    styleUrls: ['./../offer.component.scss'],
    templateUrl: './vacation-offer.component.html'
})

export class VacationOfferComponent implements OnInit, OnDestroy {
    public internetData: any;
    public selfinstallSelected: boolean = false;
    public enablechangetab: boolean = false;
    public lifelineDHPExisting: boolean = false;
    public lifelinePOTSExisting: boolean = false;
    public lifelineHSIExisting: boolean = false;
    public exisitngData: any;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    public removal: any = {};
    public voiceMailCondi: boolean = false;
    public wireMaintainCondi: boolean = false;
    public currentSpeed: any;
    public modemAvailable: boolean;
    public selfInstallAvailable: boolean;
    public dropName: string = "All Speed options";
    public filterObj: filterObjModel = {
        name: "All Speed options",
        isExist: true
    };
    public selfInstall: boolean;
    public undoFlag: boolean = false;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public userSubscription1: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public pendingSubscription: Subscription;
    public pendingObservable: Observable<any>;
    public isOptedOut: boolean;
    public optedOutCheck: boolean = false;
    private isTan: boolean;
    public internetCheck: boolean;
    public internetAvail: boolean;
    public videoAvail: boolean;
    public phoneAvail: boolean;
    public internetOffer: boolean;
    public videoOffer: boolean;
    public phoneOffer: boolean;
    public serviceSpec: ServiceCategoryId[] = [];
    public videoSelected: string;
    public phoneSelected: string;
    public orderRefNumber: string;
    public processInstanceId: string;
    public taskId: string;
    public taskName: string;
    public offersGenerated: boolean;
    public offerResponse: Product;
    public discountedPrice: number;
    public discountedInternetOtcPrice: number;
    public actualInternetOtcPrice: number;
    public actualPrice: number;
    public actualTVPrice: number;
    public discountedTVPrice: number;
    public actualTVOtcPrice: number;
    public discountedTVOtcPrice: number;
    public selectedInternetOfferdId: string;
    public selectedPhoneOfferdId: string;
    public selectedVideoOfferdId: string;
    public selectedDHPOfferdId: string;
    public serviceUnavailable: string;
    public wireMaintainenceHide = true;
    public directvAccountId: any = '';
    public modemCompatValues: OfferProductComponents;
    public modemValues: OfferProductComponents;
    public easeValues: OfferProductComponents;
    public jackValues: OfferProductComponents;
    public jackValuesForPots: OfferProductComponents;
    public installationValues: OfferProductComponents;
    public productPriceValues: any;
    public matchingOffers: OfferGroup[] = [];
    public selectedGroup: OfferGroup;
    public internerOffer: ProductOfferings[] = [];
    public videorOffer: ProductOfferings[] = [];
    public phoneOfferData: ProductOfferings[] = [];
    public dhpOffer: ProductOfferings[] = [];
    public speedList: any[] = [];
    public tvList: string[] = [];
    public selectedSpeed: string;
    public selectedTV: string;
    public selectedHP: string;
    public selectedOffer: ProductOfferings;
    public selectedTVOffer: ProductOfferings;
    public selectedDHPOffer: ProductOfferings;
    public selectedHPOffer: ProductOfferings;
    public selectedModem: Products;
    public selectedInstallation: Products;
    public selectedEase: Products;
    public selectedModemArr: string[] = [];
    public selectedInstallationArr: string[] = [];
    public selectedEaseArr: string[] = [];
    public selectedJack: Products;
    public selectedJackForPots: Products;
    public intraStateFee: Products;
    public discountedPriceList: Discounts[];
    public totalDiscountAmount: number = 0;
    public loading: boolean = false;
    public maxWSTB: string[] = [];
    public maxTSTB: string[] = [];
    public selectedTotal: string;
    public selectedWire: string;
    public warningMsg: string;
    public cartObject: ShoppingCart;
    public stb: Products;
    public selectedSTB: Products;
    public wiredSTB: Products;
    public wirelessSTB: Products;
    public hdService: Products;
    public hdPrice: number = 0;
    public dvrPrice: number = 0;
    public dvrService: Products;
    public selectedInternetOfferPrice: number;
    public selectedVideoOfferPrice: number;
    public selectedDHPOfferPrice: number;
    public selectedPhoneOfferPrice: number;
    public selected: string;
    public errorMsg: string;
    public isShowRemoveRetentionDiscountMsg: boolean = false;
    public existingDiscounts: any = {};
    public hsiRemovedRetentiondiscounts: any = [];
    public existingRetentionDiscounts: any = [];
    public dataLink: ServiceCategoryBasedOffers;
    public videoLink: ServiceCategoryBasedOffers;
    public dtvLink: ServiceCategoryBasedOffers;
    public dhpLink: ServiceCategoryBasedOffers;
    public phoneLink: ServiceCategoryBasedOffers;
    public attrCombinations: AttributesCombination[] = [];
    public noPrice: AttributesCombination;
    public retriveOffersLoading: boolean = false;
    public apiResponseError: APIErrorLists;
    public catalogSpecId: string;
    public catalogId: any;
    public callingFeatures: OfferProductComponents;
    public dhpOfferPriceDiscountedOtc: number;
    public dhpOfferPriceDiscountedRc: number;
    public includedCallingFeatures = [];
    public e911ValidatedAddress: any;
    public phoneArray: any = [];
    public videoArray: any = [];
    public retentionDiscountsToCart: any = [];
    private initialOfferResponse: Product;
    public removeMessage;
    public productToRemove;
    public existingServices: any;
    public existingProductName: string = '';
    public existingProductContract: number;
    public moreServices: any;
    public removeResponse: any[];
    public removedProductItem: CustomerOrderItems[] = [];
    public isRemoved: boolean = false;
    public isDHPRemoved: boolean = false;
    public isHPRemoved: boolean = false;
    public isInternetRemoved: boolean = false;
    public preserveHSI: any;
    public removeSelectedReason: any;
    public serviceTerminationInfo: any;
    public enabledServiceList: any = [];
    public techInstallExist: boolean = false;
    public easeExist: boolean = false;
    public modemExist: boolean = false;
    public jackExist: boolean = false;
    public wireMaintainanceExist: boolean = false;
    public cartContractTerm: string;
    public cartContractTermDHP: string;
    public cartContractTermDTV: string;
    public dhpExisting: boolean = false;
    public hpExisting: boolean = false;
    public dtvExisting: boolean = false;
    public existingAddonsHSI: any;
    public selectedModemToShow: Products;
    public voiceMail: boolean = false;
    public wireMaintainance: boolean = false;
    public selectedMaintainance: Products;
    public maintainancePrice: number = 0;
    public ban: any;
    public undoChanges: boolean;
    public internationalDialing: OfferProductComponents;
    public internationalPrice: number;
    public isInternational: boolean = false;
    public isPOTS: boolean = false;
    public isDHP: boolean = false;
    public hsiOnlyPresent: boolean = false;
    public disconnectReq: any = {};
    public hsiExisting: boolean = false;
    public dhpIntlCalled: boolean = false;
    public dhpIntlSelected: string = 'No';
    public dhpIntlExisting: string = '';
    public newTechInstall: boolean = false;
    public check: boolean = false;
    public isReEntrant: boolean = false;
    public reEntrant: boolean = false;
    public productConfiguration: any;
    public configSelected: any[] = [];
    public loadedConfig: boolean = false;
    public portingCheck: boolean = false;
    public isModemCompatible: boolean = true;
    public catalogPhoneId: string;
    public dtvCatalogId: string;
    public internetDiscountedRc: any;
    public installError = false;
    public modemError = false;
    public easeError = false;
    public jackError = false;
    public configSubmited = false;
    public retainedPotsBooleans: any;
    public cartCopyObject: ShoppingCart;
    public isE911Called: boolean = false;
    public reentrantUI: boolean = false;
    public deviceSelected: boolean = false;
    public deviceMandatory: boolean = false;
    @ViewChild("removeProduct", { static: false, }) public removeProduct: any;
    @ViewChild("e911Validation", { static: false, }) public e911Validation: any;
    @ViewChild("removeProduct", { static: false, }) public removeProductOpen: any;
    @ViewChild('voiceMailInput', { static: false, }) public voiceMailInput: ElementRef;
    @ViewChild('wireMaintainanceInput', { static: false, }) public wireMaintainanceInput: ElementRef;
    @ViewChild('portingInput', { static: false, }) public portingInput: ElementRef;
    @ViewChild('easeSelected', { static: false, }) public easeSelected: ElementRef;
    public offerNoLongerAvailable: string = '';
    public depositHistory: any;
    public existingTN;
    public calledFromConstructor: boolean = false;
    public deviceQuantitySelected: any;
    public holdCalled: boolean = false;
    public orderObservable: Observable<any>;
    public orderSubscription: Subscription;
    public holdedObjects: any;
    public isCustomize: boolean;
    public selectedVoiceMail: Products;
    public voiceMailPrice: number;
    public selectedQuantity: string = 'na';
    public tempConfig: any;
    public firstName: string;
    private lastName: string;
    private ensembleId: string;
    private agentCuid: string;
    public offerName: string;
    public retainValueForPotsJack: string = '';
    public fromHold: boolean = false;
    public changeAfterReEntrant: boolean = false;
    public EaseDefault: boolean;
    public JacksWireDefault: boolean;
    public compatibilityArray: any;
    public modemMake: string;
    public modemModel: string;
    public showHoverMessage: boolean;
    public isDtvOpus: boolean;
    public newInternetCheck: boolean;
    public newPhoneSelected: string;
    public newPhoneUpdated: boolean;
    public newVideoSelected: string;
    public isSalesExpiredMessageNeedtoHide: boolean = false;
    public speedselected: string;
    public isSpeedSalesExpired: boolean = false;
    public isBundleSalesExpired: boolean = false;
    public isVacRes: boolean = true;
    public isContinueEnabled: boolean = false;
    private vacationObservable: Observable<any>;
    private vacationSubscription: Subscription;
    private vacReconnectOffer: any;
    public offerBillingType: string;
    public vacResCart: any;

    constructor(
        private logger: Logger,
        public store: Store<AppStore>,
        private router: Router,
        private productService: ProductService,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private disconnectServiceCall: DisconnectService,
        private bMService: BlueMarbleService,
        private ctlHelperService: CTLHelperService,
        private offerHelperService: OfferHelperService
    ) {
        this.initilizeAll();
    }

    public initilizeAll() {
        this.appStateService.setLocationURLs();
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.pendingObservable = <Observable<any>>this.store.select('pending');
        this.orderObservable = <Observable<any>>this.store.select('order');
        this.discountedPriceList = [];
        this.internetCheck = false;
        this.isOptedOut = false;
        this.internetOffer = true;
        this.videoOffer = false;
        this.phoneOffer = false;
        this.internetAvail = false;
        this.videoAvail = false;
        this.phoneAvail = false;
        this.videoSelected = 'NoTV';
        this.newVideoSelected = 'NoTV';
        this.phoneSelected = 'NoPhone';
        this.newPhoneSelected = 'NoPhone';
        this.offersGenerated = true;
        this.serviceUnavailable = 'Service not available for your Address';
        let prod: Products = {
            productId: '608',
            productName: 'Intrastate Service Fee',
            productType: 'Service',
            isRegulated: false
        };
        let state: boolean = false;
        this.orderSubscription = this.orderObservable.subscribe(ord => {
            this.isCustomize = ord.taskName === 'Checkout & Scheduling' ? true : false;
        })
        this.intraStateFee = prod;

        this.existingSubscription = this.existingObservable.subscribe(
            (data) => {
                if (data.orderFlow && (data.orderFlow.type === 'fromHold')) {
                    this.fromHold = true;
                }

                if (data) {
                    if (data.existingDiscounts) {
                        this.existingDiscounts = data.existingDiscounts;
                    }
                    if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo
                        && data.existingProductsAndServices[0].accountInfo.billingType) {
                            this.offerBillingType = data.existingProductsAndServices[0].accountInfo.billingType === "PREPAID" ? data.existingProductsAndServices[0].accountInfo.billingType : "POSTPAID";
                    }
                }

                if (data && data.orderFlow && data.orderFlow.flow === 'Change' && this.fromHold && !data.orderFlow.selectProductCalled && !this.holdCalled) {
                    this.holdCalled = true;
                    this.pendingSubscription = this.pendingObservable.subscribe(pending => {
                        let inputAddress: any;
                        inputAddress = {
                            addressLine: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetAddress,
                            unitNumber: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.subAddress
                                && pending.orderDocument.serviceAddress.subAddress.combinedDesignator,
                            stateOrProvince: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.stateOrProvince,
                            city: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.city,
                            postCode: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.zipCode,
                            singleLine: true,
                        };
                        this.holdedObjects = pending;
                        this.loading = true;
                        this.logger.startTime();
                        this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(inputAddress));
                        state = this.callApiForChange(this.store, state, data);
                    })
                    if (this.pendingSubscription !== undefined) this.pendingSubscription.unsubscribe();
                } else {
                    state = this.callApiForChange(this.store, state, data);
                }

            });
    }

    public setDiscountsFromExistingDiscounts(existingDiscounts) {
        this.existingRetentionDiscounts = [];
        if (existingDiscounts && existingDiscounts.orderDiscounts && existingDiscounts.orderDiscounts[0] && existingDiscounts.orderDiscounts[0].productDiscounts) {
            for (let i = 0; i < existingDiscounts.orderDiscounts[0].productDiscounts.length; i++) {

                for (let j = 0; j < existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails.length; j++) {
                    if ((existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'R' || existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'P')
                        && existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDuration > 1) {
                        var tempDiscDetail = existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j];
                        tempDiscDetail.discountExpiryDate = this.getYMDTStoMDY(tempDiscDetail.discountExpiryDate);
                        this.existingRetentionDiscounts.push(tempDiscDetail);
                    }

                }

            }

        }
    }

    public getYMDTStoMDY(datetimestamp) {
        return new DatePipe('en-US').transform(datetimestamp, 'M/dd/yyyy');
    }

    public callApiForChange(store: Store<AppStore>, state: boolean, data: any) {
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription1 = this.user.subscribe(
            (data) => {
                this.isDtvOpus = data.isDtvOpus;
            });
        if (data.orderInit && data.orderInit.payload && data.orderInit.payload.productConfiguration) {
            this.productConfiguration = data.orderInit.payload.productConfiguration;
        }
        //To get Modem make and model
        let products: any;

        products = data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems;
        products && products.map((data) => {
            if (data && data.productName === "MODEM") {
                data && data.productAttributes && data.productAttributes.map((productAttributes) => {
                    productAttributes && productAttributes.compositeAttribute && productAttributes.compositeAttribute.map((values) => {
                        if (values && values.attributeName && values.attributeName === "modemMake" && values.attributeValue !== "null" && values.attributeValue !== null) {
                            this.modemMake = values.attributeValue
                        } else if (values && values.attributeName && values.attributeName === "modemModel" && values.attributeValue !== "null" && values.attributeValue !== null) {
                            this.modemModel = values.attributeValue
                        }
                    })
                })
            }
        })
        this.existingServices = data.orderInit.payload.existingServices.existingServiceItems;
        let exitsServices: any[] = [];
        data.orderInit.payload.existingServices.existingServiceItems.map((exitsService) => {
            if(exitsService && exitsService.action !== 'VACSUS-ADD') {
                exitsServices.push(exitsService);
            }
        })
        this.existingServices = exitsServices;
        this.holdCalled && data && data.existingProductsAndServices && data.existingProductsAndServices.map((item) => {
            let existingItems: any;
            if (data.orderFlow.type === 'fromHold') {
                existingItems = this.holdedObjects.orderDocument.existingServices;
            } else {
                existingItems = item.existingServices.existingServiceItems;
            }
            this.dropDownPopulationforHP(existingItems, false);
            item && item.productConfiguration && item.productConfiguration.map((data) => {

                if (!this.isDtvOpus) {
                    if (data && data.productType === GenericValues.cDTV) {
                       data.configItems && data.configItems.map((config) => {
                            config && config.configDetails && config.configDetails.map((details) => {
                                if (details && details.formName === 'DTV AccountID') {
                                    details.formItems && details.formItems.map((items) => {
                                        if (items && items.attributeName === 'DIRECTV Account ID') {
                                            if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
                                                this.directvAccountId = items.attributeValue[0].value;
                                            }
                                        }
                                    })
                                }
                            })
                        })
                    }
                }

                if (data && data.productType === GenericValues.iData) {
                    data.configItems && data.configItems.map((config) => {
                        config && config.configDetails && config.configDetails.map((details) => {
                            if (details && details.formName === 'Devices') {
                                details.formItems && details.formItems.map((items) => {
                                    if (items && items.attributeName === 'Quantity') {
                                        if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
                                            this.selectedQuantity = items.attributeValue[0].value;
                                            this.deviceSelected = true;
                                        }
                                    }
                                })
                            }
                        })
                    })
                }

            })
        })
        this.retainedPotsBooleans = {
            retainValueForPotsJack: this.retainValueForPotsJack
        }
        if (this.undoSelected) {
            this.voiceMailValue = 'No';
            this.voiceMailCondi = false;
            this.voiceMail = false;
            this.wireMaintainCondi = false;
            this.wireMaintainance = false;
            if (this.retainedPotsBooleans && this.retainedPotsBooleans.retainValueForPotsJack) this.retainedPotsBooleans.retainValueForPotsJack = undefined;
        }

        if (this.holdCalled && this.holdedObjects && this.holdedObjects.orderDocument && this.holdedObjects.orderDocument.customerOrderItems) {
            let existingItems = this.holdedObjects.orderDocument.customerOrderItems;
            this.dropDownPopulationforHP(existingItems, true);
        }
        if (!this.holdCalled && this.existingServices) {
            this.dropDownPopulationforHP(this.existingServices, false);
        }
        this.retainedPotsBooleans = {
            wireMaintainance: this.wireMaintainance,
            voiceMail: this.voiceMail,
            retainValueForPotsJack: this.retainValueForPotsJack
        }
        this.orderRefNumber = data.orderInit.orderRefNumber;
        this.processInstanceId = data.orderInit.processInstanceId;
        this.taskId = data.orderInit.taskId;
        this.taskName = data.orderInit.taskName;
        this.serviceSpec = data.orderInit.payload.serviceCategory;
        this.videoAvail = data.videoCheck;
        this.phoneAvail = data.phoneCheck;
        this.phoneArray = data.phoneType;
        this.videoArray = data.videoType;
        this.internetAvail = data.internetCheck;
        this.enabledServiceList = data.enabledServiceList;
        this.ban = data.ban;
        let offersPreserve = data.orderInit.payload.retrievalTypes[0].offers;
        if (data.orderInit && data.orderInit.payload && data.orderInit.payload !== undefined && data.orderInit.payload.giftCardOffers && (data.orderInit.payload.giftCardOffers !== undefined && data.orderInit.payload.giftCardOffers !== null)) {
            this.store.dispatch({ type: 'INCLUDING_GIFTCARDS', payload: data.orderInit.payload.giftCardOffers });
        }
        if (data.orderInit !== undefined && data.orderInit.payload && data.orderInit.payload.retrievalTypes &&
            data.orderInit.payload.retrievalTypes[0] && (data.orderInit.payload.retrievalTypes[0].offers !== undefined &&
                data.orderInit.payload.retrievalTypes[0].offers !== null)) {
            this.store.dispatch({ type: 'INCLUDING_OFFERS', payload: data.orderInit.payload.retrievalTypes[0].offers })
        }

        if (data.existingTN) {
            this.existingTN = this.maskTelephone(data.existingTN);
        }

        if (offersPreserve !== undefined && offersPreserve.length > 0) {
            offersPreserve.map((item) => {
                if (item.serviceCategory !== undefined && item.serviceCategory === GenericValues.sData) {
                    this.preserveHSI = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.sData);
                    this.dataLink = this.preserveHSI;
                }
                if (item.serviceCategory !== undefined && item.serviceCategory === 'DATA/VIDEO') {
                    this.videoLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDATVID);
                }
                if (item.serviceCategory !== undefined && item.serviceCategory === 'VIDEO-DTV') {
                    this.dtvLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDTV);
                }
                if (item.serviceCategory !== undefined && item.serviceCategory === 'VOICE-DHP') {
                    this.dhpLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDHP);
                }
                if (item.serviceCategory !== undefined && item.serviceCategory === 'VOICE-HP') {
                    this.phoneLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cHP);
                }
            });
        }
        if (this.catalogSpecId === undefined && data.orderInit.payload) {
            this.catalogSpecId = data.orderInit.payload.catalogSpecId;
        }
        this.userSubscription = this.user.subscribe(
            (userData) => {
                if (userData.autoLogin) {
                    if (data && data.autoLogin && data.autoLogin !== undefined && data.autoLogin.oamData && data.autoLogin.oamData !== null && data.autoLogin.oamData !== undefined) {
                        this.agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                        this.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                        this.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                        this.ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                    }
                }
                let disconnectReq = this.disconnectMethod(data);
                let retSubscribe: Subscription;
                this.disconnectReq = JSON.stringify(disconnectReq);
                if (userData.previousUrl !== '/existing-products' || this.fromHold) {
                    this.isReEntrant = true;
                    this.reEntrant = true;
                    this.reentrantUI = true;
                    let retainVal = <Observable<any>>this.store.select('retain');
                    retSubscribe = retainVal.subscribe(
                        (retVal => {
                            if (!state) {
                                this.taskId = userData.taskId;
                                if (retVal.potsBooleans) this.retainedPotsBooleans = retVal.potsBooleans;
                                if (this.retainedPotsBooleans && this.retainedPotsBooleans.wireMaintainance !== undefined) {
                                    this.wireMaintainance = this.retainedPotsBooleans.wireMaintainance;
                                }
                                if (this.retainedPotsBooleans && this.retainedPotsBooleans.voiceMail !== undefined) {
                                    this.voiceMail = this.retainedPotsBooleans.voiceMail;
                                }
                                if (this.retainedPotsBooleans && this.retainedPotsBooleans.portingCheck !== undefined) {
                                    this.portingCheck = this.retainedPotsBooleans.portingCheck;
                                }
                                if (this.retainedPotsBooleans && this.retainedPotsBooleans.selectedMaintainance !== undefined) {
                                    this.selectedMaintainance = this.retainedPotsBooleans.selectedMaintainance;
                                }
                                if (this.retainedPotsBooleans && this.retainedPotsBooleans.isInternational !== undefined) {
                                    this.isInternational = this.retainedPotsBooleans.isInternational;
                                    this.dhpIntlSelected = this.isInternational ? 'Yes' : 'No';
                                }
                                this.cartObject = retVal.addOns;
                                this.cartCopyObject = retVal.addOns;
                                this.e911ValidatedAddress = retVal.e911ValidatedAddress;
                                let custOrderItem: CustomerOrderItems[] = this.holdCalled ? this.holdedObjects && this.holdedObjects.orderDocument &&
                                    this.holdedObjects.orderDocument.customerOrderItems : retVal.addOns.payload.cart.customerOrderItems;

                                if (!this.cartObject) {
                                    this.cartObject = {
                                        payload: {
                                            cart: {
                                                customerOrderItems: custOrderItem
                                            },
                                            productConfiguration: this.holdedObjects && this.holdedObjects.orderDocument &&
                                                this.holdedObjects.orderDocument.productConfiguration
                                        }
                                    }
                                }
                                //to retain jack values
                                this.cartObject.payload && this.cartObject.payload.cart && this.cartObject.payload.cart.customerOrderItems.map(cust => {
                                    if (cust && cust.offerCategory === GenericValues.cHP && cust.offerType !== 'SUBOFFER') {
                                        cust.customerOrderSubItems && cust.customerOrderSubItems.map(exSub => {
                                            if (exSub.productName.indexOf('Jack and Wire') !== -1) {
                                                this.retainValueForPotsJack = exSub.productAttributes[0].compositeAttribute[0].attributeValue
                                            }
                                        });
                                    }
                                })
                                if (this.retainValueForPotsJack !== undefined && this.retainValueForPotsJack) {
                                    this.retainedPotsBooleans.retainValueForPotsJack = this.retainValueForPotsJack;
                                }
                                this.cartCopyObject = cloneDeep(this.cartObject);
                                if (this.cartCopyObject && this.cartCopyObject.payload && this.cartCopyObject.payload.productConfiguration) {
                                    let selectConfigList = this.cartCopyObject.payload.productConfiguration;
                                    if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
                                        for (let i = 0; i < selectConfigList.length; i++) {
                                            selectConfigList[i].configItems && selectConfigList[i].configItems.map(selectedConf => {
                                                this.selectedQuantity = selectedConf.configDetails[0].formItems[0].attributeValue[0].value;
                                                this.deviceSelected = true;
                                            })
                                        }
                                    }
                                }
                                if (this.cartObject) {
                                    if (this.cartObject.payload.cart.customerOrderItems !== undefined && this.cartObject.payload.cart.customerOrderItems.length > 0) {
                                        this.cartObject.payload.cart.customerOrderItems.forEach((item) => {
                                            if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                                if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.hsiExisting = true; }
                                            } else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
                                                this.removedProductItem.push(item);
                                            }
                                            if (item.offerCategory === 'VIDEO-PRISM' && item.action !== 'REMOVE') {
                                                this.videoOffer = true;
                                                this.videoSelected = 'PTV';
                                                this.videoLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDATVID);
                                                state = false;
                                            }
                                            if (item.offerCategory === 'VIDEO-DTV' && item.action !== 'REMOVE') {
                                                if(item.action !== 'ADD') { this.dtvExisting = true; }
                                                this.videoOffer = true;
                                                this.videoSelected = 'DTV';
                                                this.dtvLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDTV);
                                                state = false;
                                            } else if (item.offerCategory === 'VIDEO-DTV' && item.action === 'REMOVE') {
                                                this.removeSelectedReason = retVal.removeReason;
                                                this.removedProductItem.push(item);
                                                this.dtvExisting = true;
                                                this.dtvLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDTV);
                                                state = false;
                                            }
                                            if (item.offerCategory === 'VOICE-DHP' && item.action !== 'REMOVE') {
                                                if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.dhpExisting = true; }
                                                this.phoneOffer = true;
                                                this.phoneSelected = 'DHP';
                                                this.dhpLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDHP);
                                                state = false;
                                            } else if (item.offerCategory === 'VOICE-DHP' && item.action === 'REMOVE') {
                                                this.removeSelectedReason = retVal.removeReason;
                                                this.removedProductItem.push(item);
                                                this.dhpExisting = true;
                                                this.isDHPRemoved = true;
                                                this.dhpLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDHP);
                                                state = false;
                                            }
                                            if (item.offerCategory === 'VOICE-HP' && item.action !== 'REMOVE') {
                                                if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.hpExisting = true; }
                                                if(item.action === 'ADD' && item.offerType !== 'SUBOFFER') { this.hpExisting = false; }
                                                this.phoneOffer = true;
                                                this.phoneSelected = 'HMP';
                                                if (item.offerType !== 'SUBOFFER') {
                                                    this.selectedPhoneOfferdId = item.productOfferingId;
                                                    this.selectedHP = item.productOfferingId;
                                                }
                                                this.phoneLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cHP);
                                                state = false;
                                            } else if (item.offerCategory === 'VOICE-HP' && item.action === 'REMOVE') {
                                                this.removeSelectedReason = retVal.removeReason;
                                                this.removedProductItem.push(item);
                                                this.hpExisting = true;
                                                this.isHPRemoved = true;
                                                this.phoneLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cHP);
                                                state = false;
                                            }
                                            if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                                if (item.offerType === 'SUBOFFER') {
                                                    this.existingAddonsHSI = item;
                                                }
                                                this.internetCheck = true;
                                            } else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
                                                if (item.offerType === 'SUBOFFER') {
                                                    this.removeSelectedReason = retVal.removeReason;
                                                    this.removedProductItem.push(item);
                                                    this.existingAddonsHSI = item;
                                                }
                                            }
                                            if (this.phoneSelected === 'DHP') {
                                                let dhp = this.getExistingProducts(this.cartCopyObject.payload.cart.customerOrderItems, GenericValues.cDHP);
                                                if (dhp && dhp.customerOrderSubItems !== null && dhp.customerOrderSubItems
                                                    && dhp.customerOrderSubItems.length !== 0) {
                                                    dhp.customerOrderSubItems.forEach(subItems => {
                                                        if (subItems && subItems.productName === 'Digital Home Phone Intl Call') {
                                                            subItems.productAttributes.forEach(subAttr => {
                                                                if ((subAttr && subAttr.compositeAttribute !== null && subAttr.compositeAttribute.length !== 0
                                                                   && subAttr.compositeAttribute[0].attributeName === 'Service Status')) {
                                                                    subAttr.compositeAttribute[0].attributeValue === 'Enabled'
                                                                        || subAttr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes' ? this.dhpIntlSelected = 'Yes' :
                                                                        this.dhpIntlSelected = 'No';
                                                                    this.dhpIntlSelected === 'Yes' ? this.isInternational = true : this.isInternational = false;
                                                                }
                                                            })
                                                        }
                                                    })
                                                }
                                                if (this.fromHold && this.holdedObjects && this.holdedObjects.orderDocument &&
                                                    this.holdedObjects.orderDocument.dhpAdditionalInfo && this.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address) {
                                                    this.e911ValidatedAddress = this.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address;
                                                    this.e911ValidatedAddress.acceptedData = this.holdedObjects.orderDocument.dhpAdditionalInfo.dhpDisclaimerAcceptDateTime;
                                                }
                                            }
                                        });
                                    }
                                }
                                state = true;
                                this.calledFromConstructor = true;
                                this.internetCheck ? this.retrieveOffers(false, 'fromSlot') : this.retrieveOffers(false);
                            }
                        })
                    )
                }
                else {
                    if (!state) {
                        let moreServices = data.orderInit.payload.existingServices.existingServiceItems;

                        if (moreServices !== undefined && moreServices.length > 0) {
                            moreServices.map((item) => {
                                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                                    this.hsiExisting = true;
                                    if (item.offerType === 'SUBOFFER') {
                                        this.existingAddonsHSI = item;
                                    }
                                    this.internetCheck = true;
                                }
                            });
                        }

                        if (moreServices !== undefined && moreServices.length > 1) {
                            moreServices.map((item) => {
                                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                                    this.hsiExisting = true;
                                }
                                if (item.offerCategory === 'VIDEO-PRISM') {
                                    this.videoOffer = true;
                                    this.videoSelected = 'PTV';
                                    this.videoLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDATVID);
                                    state = false;
                                }
                                if (item.offerCategory === 'VIDEO-DTV' && item.offerType !== 'SUBOFFER') {
                                    this.dtvExisting = true;
                                    this.videoOffer = true;
                                    this.videoSelected = 'DTV';
                                    this.newVideoSelected = 'DTV';
                                    this.dtvLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDTV);
                                    state = false;
                                }
                                if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER') {
                                    this.dhpExisting = true;
                                    this.phoneOffer = true;
                                    this.phoneSelected = 'DHP';
                                    this.newPhoneSelected = 'DHP';
                                    this.dhpLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cDHP);
                                    state = false;
                                }
                                if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER') {
                                    this.selectedHP = item.productOfferingId;
                                    this.selectedPhoneOfferdId = item.productOfferingId;
                                    this.hpExisting = true;
                                    this.phoneOffer = true;
                                    this.phoneSelected = 'HMP';
                                    this.newPhoneSelected = 'HMP';
                                    this.phoneLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cHP);
                                    state = false;
                                }
                                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                                    if (item.offerType === 'SUBOFFER') {
                                        this.existingAddonsHSI = item;
                                    }
                                    this.internetCheck = true;
                                }
                            });
                        }
                        if (!this.internetCheck && moreServices !== undefined && moreServices.length >= 1) {
                            moreServices.map((item) => {
                                if (item.offerCategory === 'VOICE-HP') {
                                    this.hpExisting = true;
                                    this.phoneOffer = true;
                                    this.phoneSelected = 'HMP';
                                    this.phoneLink = this.filterCategory(data.orderInit.payload.retrievalTypes[0].offers, GenericValues.cHP);
                                    state = false;
                                }
                            });
                        }

                        if (this.catalogId === undefined && moreServices) {
                            moreServices.map((item) => {
                                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                                    this.catalogId = item.catalogId;
                                    this.cartContractTerm = item.contractTerm;
                                }
                                if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
                                    this.catalogPhoneId = item.catalogId;
                                    this.cartContractTermDHP = item.contractTerm;
                                }
                                if (item.offerCategory === 'VIDEO-DTV') {
                                     this.dtvCatalogId = item.catalogId;
                                    this.cartContractTermDTV = item.contractTerm;
                                }
                            });
                        }
                        state = true;
                        this.calledFromConstructor = true;
                        this.retrieveOffers(false, 'fromSlot');
                    }
                }
                if (retSubscribe !== undefined)
                    retSubscribe.unsubscribe();
            }
        );

        this.fetchExistingProducts(this.existingServices);
        return state;
    }
    private disconnectMethod(data: any) {
        return {
            'ban': data.ban,
            'salesChannel': 'ESHOP-Customer Care',
            'customerOrderType': 'DISCONNECT',
            'serviceAddress': data.existingProductsAndServices[0] ? data.existingProductsAndServices[0].serviceAddress : '',
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            }
        };
    }

    private dropDownPopulationforHP(existingItems: any, flag) {
        this.voiceMail = false;
        this.wireMaintainance = false;
        existingItems && existingItems.map((data) => {
            if (data.offerCategory === GenericValues.cHP && data.offerType !== 'SUBOFFER') {
                data.customerOrderSubItems && data.customerOrderSubItems.map((voiceData) => {
                    if (voiceData.productName === "Voice Messaging") {
                        if (!flag) this.voiceMailCondi = true;
                        this.voiceMail = true;
                        this.voiceMailValue = 'Yes';
                    }
                    else if (voiceData.productName.indexOf('Wire Maintenance Plan') !== -1) {
                        this.wireMaintainance = true;
                        if (!flag) this.wireMaintainCondi = true;
                    } else if (voiceData.productName.indexOf('Jack and Wire') !== -1) {
                        this.retainValueForPotsJack = voiceData.productAttributes[0].compositeAttribute[0].attributeValue;
                        if (this.retainValueForPotsJack !== undefined && this.retainValueForPotsJack) {
                            this.retainedPotsBooleans.retainValueForPotsJack = this.retainValueForPotsJack;
                        }
                    }
                });
            }
        });
    }
    public existingProductsSelected() {
        this.enablechangetab = true;
        this.store.dispatch({ type: 'CHANGE_EXISTING_TAB', payload: this.enablechangetab });
        this.store.dispatch({ type: 'MOVE_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'BILLING_EXISTING_TAB', payload: false });
    }

    public ngOnInit() {
        window.scroll(0, 0);
        this.compatibilityAPIcall();
        if (!this.isReEntrant) this.setDiscountsFromExistingDiscounts(this.existingDiscounts);
        this.existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            this.exisitngData = respData
            if (this.exisitngData && this.exisitngData.existingProductsAndServices && this.exisitngData.existingProductsAndServices[0] &&
                this.exisitngData.existingProductsAndServices[0].lifelineInfo) {
                respData.existingProductsAndServices[0].lifelineInfo.map((data) => {
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "INTERNET") {
                        this.lifelineHSIExisting = true;
                    }
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-HP") {
                        this.lifelinePOTSExisting = true;
                    }
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-DHP") {
                        this.lifelineDHPExisting = true;
                    }
                })
            }
        });
        this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: { type: '', selected: '' } } });
        this.logger.metrics('OfferVacationPage');
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            if(data && data.isContinueEnabled) {
                this.isContinueEnabled = data.isContinueEnabled;
            }
            if(data && data.vacReconnectOffer) {
                this.vacReconnectOffer = data.vacReconnectOffer;
                this.cartRequest();
            }
            if(data && data.vacResCart) {
                this.vacResCart = data.vacResCart;
                this.cartRequest();
            }
        });
    }
    
    public maskTelephone(number: string) {
        if (number && number.indexOf('-') === -1) {
            return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
        }
        else if (number) {
            return number;
        }
    }

    public fetchExistingProducts(services) {
        this.existingProductContract = services[0].contractTerm;
        this.existingProductName = '';
        this.internetDiscountedRc = '';
        if (services !== undefined) {
            services.map((item) => {
                if (item !== undefined && item.customerOrderSubItems !== undefined) {
                    item.customerOrderSubItems.map((subItem) => {
                        if (subItem.componentType === 'PRIMARY') {
                            this.existingProductName += subItem.productName + ' ';
                        }
                        if (subItem.productName.toUpperCase() === VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                            this.internetDiscountedRc += item.discountedRc;
                        }
                    });
                }
            });
        }
    }

    public checkInternet(check: boolean) {
        if (this.newVideoSelected !== 'NoTV' && this.phoneSelected !== 'HMP') {
            this.warningMsg = 'Internet/POTS is Mandatory for Video Bundle';
        } else {
            this.newInternetCheck = check;
            this.internetCheck = check;
            this.undoFlag = true;
        }
    }

    public checkTV(value: string) {
        this.newVideoSelected = value;
        if (this.newVideoSelected !== 'NoTV' && (!this.internetCheck && (!this.phoneOffer || (this.phoneOffer && this.phoneSelected !== 'HMP')))) {
            this.newInternetCheck = true;
            this.internetCheck = true;
        }
        if (!this.dtvExisting && this.newVideoSelected !== 'NoTv') {
            this.undoFlag = true;
        }
    }

    public selectPhone(value: string) {
        if (value === 'NoPhone' && this.newVideoSelected !== 'NoTV' && !this.internetCheck) {
            this.warningMsg = 'Internet/POTS is Mandatory for Video Bundle';
        } else {
            if ((value !== 'NoPhone' || value === 'NoPhone') && ((this.dhpExisting && !this.isDHPRemoved) || (this.hpExisting && !this.isHPRemoved))) {
                this.setMessage('More information is needed', this.dhpExisting ? 'removeDhp' : this.hpExisting ? 'removeHp' : '');
                this.removeProduct.open()
            }
            this.newPhoneSelected = value;
            if (this.newPhoneSelected !== 'NoPhone' && this.newPhoneSelected === 'DHP') {
                this.newPhoneSelected = value;
                this.newInternetCheck = true;
                this.internetCheck = true;
            }
            if (!this.hpExisting && this.newPhoneSelected !== 'NoPhone' && this.newPhoneSelected === 'HMP') {
                this.undoFlag = true;
            }
            if (!this.dhpExisting && this.newPhoneSelected === 'DHP') {
                this.undoFlag = true;
            }
            if (this.newPhoneSelected === 'HMP' && this.hpExisting) this.isHPRemoved = false;
            if (this.newPhoneSelected === 'DHP' && this.dhpExisting) this.isDHPRemoved = false;
        }
        this.newPhoneUpdated = true;
    }

    public e911Response(response) {
        if (response.msagData && response.msagData !== null && response.msagData.length > 0) {
            let resp = response.msagData[0];
            this.e911ValidatedAddress = resp;
            this.e911ValidatedAddress.acceptedData = new Date().toISOString();
        }
        this.retrieveOffers(false);
   }

    public retrieveOffers(flag: boolean, fromSlot?) {
        // Check values that were selected and set the values
        if (this.newInternetCheck && !this.isReEntrant) {
            this.internetCheck = this.newInternetCheck;
        }
        else {
            this.newInternetCheck = this.internetCheck;
        }

        if (this.newPhoneSelected && !this.isReEntrant) {
            this.phoneSelected = this.newPhoneSelected;
        }
        else if (this.newPhoneSelected && this.isReEntrant && this.newPhoneUpdated) {
            this.phoneSelected = this.newPhoneSelected;
        }
        else {
            this.newPhoneSelected = this.phoneSelected;
        }

        if (this.newVideoSelected && !this.isReEntrant) {
            this.videoSelected = this.newVideoSelected;
        }
        else {
            this.newVideoSelected = this.videoSelected;
        }
        if (this.hpExisting && this.voiceMailValue === 'na') this.voiceMailValue = 'No';
        if (!flag && !fromSlot) this.calledFromConstructor = false;
        this.filterSpeed("All Speed options", true);
        this.modemAvailable = false;
        this.selfInstallAvailable = false;
        if (this.removedProductItem && this.removedProductItem.length > 0) {
            for (let i = 0; i < this.removedProductItem.length; i++) {
                if ((this.removedProductItem[i].offerCategory === GenericValues.sData || this.removedProductItem[i].offerCategory === GenericValues.iData) && this.internetCheck) {
                    this.removedProductItem.splice(i, 1);
                } else if (this.removedProductItem[i].offerCategory === GenericValues.cHP && this.phoneSelected === 'HMP') {
                    this.removedProductItem.splice(i, 1);
                } else if (this.removedProductItem[i].offerCategory === GenericValues.cDHP && this.phoneSelected === 'DHP') {
                    this.removedProductItem.splice(i, 1);
                } else if (this.removedProductItem[i].offerCategory === GenericValues.cDTV && this.phoneSelected === 'DTV') {
                    this.removedProductItem.splice(i, 1);
                }
            }
        }
        this.errorMsg = '';
        this.warningMsg = '';
        this.retriveOffersLoading = true;
        this.matchingOffers = [];
        this.videoOffer = false;
        this.phoneOffer = false;
        this.isDHP = false;
        this.isPOTS = false;
        this.easeError = false;
        this.jackError = false;
        this.modemError = false;
        this.installError = false;
        this.deviceMandatory = false;
        this.offerBillingType = this.offerBillingType === "PREPAID" ? this.offerBillingType : "POSTPAID";
        
        let item: any = {
            offerBillingType: this.offerBillingType,
            internet: this.internetCheck,
            tv: this.videoAvail,
            phone: this.phoneAvail,
            orderRefNumber: this.orderRefNumber,
           taskId: this.taskId,
            processInstanceId: this.processInstanceId,
            taskName: this.taskName,
            enabledServiceList: this.enabledServiceList
        };
        this.selected = '';
        if (this.internetCheck) {
            this.selected = 'Internet,';
        }
        this.internetOffer = this.internetCheck;
        if (this.videoSelected !== 'NoTV') {
            this.videoOffer = true;
            this.selected += 'TV';
        }
        if (this.phoneSelected !== 'NoPhone') {
            this.phoneOffer = true;
            if (this.phoneSelected === 'DHP') {
                this.selected += 'DHPhone';
                this.isDHP = true;
            } else {
                this.selected += 'HMPhone';
                this.isPOTS = true;
            }
        }
        let cart: ShoppingCart;
        cart = {
            selectedService: this.selected
        };
        this.store.dispatch({ type: 'CREATE_CART', payload: cart });

        if (flag) {
            this.loading = true;
            this.hsiOnlyPresent = true;
            this.logger.log("info", "vacation-offer.component.ts", "getOffersRequest", JSON.stringify(item));
            this.logger.startTime();
            this.productService.getOffers(item)
                .catch((error: any) => {
                    this.logger.log("error", "vacation-offer.component.ts", "getOffersResponse", JSON.stringify(error));
                    this.logger.log("error", "vacation-offer.component.ts", "getOffersSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.logger.endTime();
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", 'Not Applicable',
                        "Submit task - Offer ", "offer.component.ts",
                        "Create Cart - Offer Page",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "vacation-offer.component.ts", "geOffersResponse", JSON.stringify(data ? data : ''));
                        this.logger.log("info", "vacation-offer.component.ts", "getOffersSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        this.offerResponse = data;
                        if (this.offerResponse && this.offerResponse.payload && this.offerResponse.payload !== undefined &&
                            this.offerResponse.payload.retrievalTypes !== undefined && this.offerResponse.payload.retrievalTypes[0] !== undefined) {
                            this.offerResponse.payload.offers = this.offerResponse.payload.retrievalTypes[0].offers;
                        }
                        this.initialOfferResponse = data;
                        if (this.initialOfferResponse && this.initialOfferResponse.payload && this.initialOfferResponse.payload !== undefined &&
                            this.initialOfferResponse.payload.retrievalTypes !== undefined && this.initialOfferResponse.payload.retrievalTypes[0] !== undefined) {
                            this.initialOfferResponse.payload.offers = this.initialOfferResponse.payload.retrievalTypes[0].offers;
                        }
                        this.framingSlot(this.offerResponse.payload.offers);
                        this.catalogSpecId = this.offerResponse.payload.cart.catalogSpecId;

                        this.offersGenerated = true;
                    },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "vacation-offer.component.ts", "getOffersResponse", JSON.stringify(error));
                        this.logger.log("error", "vacation-offer.component.ts", "getOffersSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}'); 
                        this.loading = false;
                        if (error === undefined || error === null)
                            return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                                this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.component.ts", "Offers Page", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.component.ts", "Offers Page", lAPIErrorLists);
                        }
                        this.retriveOffersLoading = false;
                    });
        } else {
            let payload: PayloadProduct;
            if (this.internetCheck && this.videoOffer && this.phoneOffer) {
                this.hsiOnlyPresent = false;
                let link: any;
                this.loading = true;
                this.retriveOffersLoading = true;
                this.logger.log("info", "vacation-offer.component.ts", "selectProductFromDataLinkRequest", JSON.stringify(this.dataLink));
                this.logger.startTime();
                link = this.phoneSelected === 'DHP' ? this.dhpLink : this.phoneLink;
                this.getDATAoffers(payload, link);
            }
            else if (this.internetCheck && !this.videoOffer && !this.phoneOffer) {
                this.hsiOnlyPresent = true;
                this.logger.log("info", "vacation-offer.component.ts", "selectProductFromDataLinkRequest", JSON.stringify(this.dataLink));
                this.logger.startTime();
                this.getDATAoffers(payload);

            } else if ((this.internetCheck && this.videoOffer && !this.phoneOffer) || (!this.internetCheck && this.videoOffer && this.phoneOffer && this.phoneSelected === 'HMP')) {
                if (this.internetCheck) this.hsiOnlyPresent = false;

                let link: any;
                link = this.videoSelected === 'DTV' ? this.dtvLink : this.videoLink;
                if (!link) {
                    this.errorMsg = 'Cannot find Selected Offer in Response';
                    this.retriveOffersLoading = false;
                    return;
                }
                if (this.videoSelected === 'DTV') {
                    this.loading = true;
                    this.internetCheck ? this.getDATAoffers(payload) : this.getPhoneOffers(payload, this.phoneLink);
                }
                if (this.internetCheck) payload = this.retriveVideoOffers(link, payload);
            } else if ((this.internetCheck && !this.videoOffer && this.phoneOffer) || (!this.internetCheck && this.phoneSelected === 'HMP')) {
                this.hsiOnlyPresent = false;
                let link: any;
                link = this.phoneSelected === 'HMP' ? this.phoneLink : this.dhpLink;
                this.retriveOffersLoading = true;
                // calling interner offer for existing change hsi+DHP
                if (this.internetCheck) {
                    this.loading = true;
                    this.getDATAoffers(payload, link);
                } else {
                    this.getPhoneOffers(payload, link);
                    this.dhpIntlSelected = 'No';
                }


            }
        }
    }

    private retriveVideoOffers(link: ServiceCategoryBasedOffers, payload: PayloadProduct) {
        this.logger.log("info", "offer.component.ts", "selectProductFromVideoLinkRequest", JSON.stringify(link));
        this.logger.startTime();
        let videoOffer: ServiceCategoryBasedOffers[] = [];
        videoOffer.push(link);
        this.logger.endTime();
        this.logger.log("info", "vacation-offer.component.ts", "selectProductFromVideoLinkResponse", JSON.stringify(link ? link : ''));
        this.logger.log("info", "vacation-offer.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        payload = {
            offers: videoOffer
        };
        this.offerResponse = Object.assign({}, this.offerResponse, {
            payload: payload
        });
        let data = {
            offers: this.sortSpeeds(videoOffer)
        }
        if (this.videoSelected === 'DTV') {
            if(link.catalogs.length > 0) { this.dtvCatalogId = link.catalogs[0].catalogId; }
        } else {
            this.internerOffer = this.filterBundleCategory(data.offers, GenericValues.cDATVID, GenericValues.sData);
            let offers: any[] = [];
            this.internerOffer && this.internerOffer.map((offer) => {
                if(offer && offer.productOffer && offer.productOffer.offerName.toUpperCase() !== VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                    offers.push(offer);
                }
            });
            this.internerOffer = offers;
        }
        this.videorOffer = this.getOfferByCategory(this.videoSelected, data);
        if (this.internerOffer.length === 0) {
            this.errorMsg = 'Catalogs are coming as empty';
            this.retriveOffersLoading = false;
        }
        else if (this.videorOffer.length === 0) {
            this.errorMsg = 'No Offers with respect to PRISM found';
            this.retriveOffersLoading = false;
        }
        this.createSlot();
        return payload;
    }

    public getPhoneOffers(payload, link: ServiceCategoryBasedOffers) {
        this.logger.startTime();
        let phoneoffer: ServiceCategoryBasedOffers[] = [];
        phoneoffer.push(link);
        if (this.phoneSelected === 'HMP') {
            if (!link || !link.catalogs || !link.catalogs[0] || link.catalogs[0].catalogItems === null
                || link.catalogs[0].catalogItems === undefined
                || link.catalogs[0].catalogItems.length === 0) {
                this.errorMsg = 'POTS Catalog coming as null';

            }
        }
        this.catalogPhoneId = link.catalogs[0].catalogId;
        this.logger.endTime();
        this.logger.log("info", "vacation-offer.component.ts", "getOffersFromLinkResponse", JSON.stringify(link ? link : ''));
        this.logger.log("info", "vacation-offer.component.ts", "getOffersFromLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        payload = {
            offers: link
        };
        this.offerResponse = Object.assign({},
            this.offerResponse, {
                payload: payload
            }
        );

        let phData;
        phData = {
            offers: phoneoffer
        }

        this.phoneOfferData = this.getOfferByCategory(this.phoneSelected, phData);
        if (this.phoneOfferData.length === 0) {
            this.retriveOffersLoading = false;
        }

        if (this.videoOffer) payload = this.retriveVideoOffers(this.dtvLink, payload);
        if (!this.videoOffer) this.createSlot();
    }

    public addincludedCallingFeatures(productComponents, type, flag) {
        let callingFeatures = [];
        if (!this.hpExisting) {
            this.store.dispatch({ type: 'INCLUDING_FEATURE', payload: productComponents });
        }
        productComponents.map((item) => {
            if ((item && item.componentType === type && flag && item.displayOrder !== 0 && item.isDefault !== 0 && item.additionalUiAttrProduct &&
                item.additionalUiAttrProduct.includedFlag && item.additionalUiAttrProduct.includedFlag.toLowerCase() === 'yes') ||
                (item.componentType === type && !flag && item.isDefault !== 0 && item.displayOrder !== 0 && item.product.productCategory === 'VAS')) {
                callingFeatures.push(item.product.productDisplayName);
            }
        });
        return callingFeatures;
    }

    /**
     * Filtering Speeds and getting Default offer to be loaded onInit
     * @param offerResponse
     */
    public framingSlot(offerResponse: ServiceCategoryBasedOffers[]) {
        if (this.internetOffer) {

            // Sorting internet Speeds
            offerResponse = this.sortSpeeds(offerResponse);

            let hsi: ServiceCategoryBasedOffers = this.filterCategory(offerResponse, GenericValues.sData);
            this.dataLink = hsi;
            if (hsi.catalogs !== null && hsi.catalogs[0] !== undefined && hsi.catalogs.length > 0
                && hsi.catalogs[0].catalogItems !== null && hsi.catalogs[0].catalogItems.length > 0) {
                this.internerOffer = hsi.catalogs[0].catalogItems;
                let offers: any[] = [];
                this.internerOffer && this.internerOffer.map((offer) => {
                    if(offer && offer.productOffer && offer.productOffer.offerName.toUpperCase() !== VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                        offers.push(offer);
                    }
                });
                this.internerOffer = offers;
                let primaryProdduct;
                if(offers && offers.length > 0) {
                    primaryProdduct = this.offerHelperService.searchforPrimary(offers[0].productOffer.productComponents, GenericValues.cPrimary)
                }
                this.store.dispatch({ type: 'CART_MAX_SPEED', payload: primaryProdduct });
                this.catalogId = hsi.catalogs[0].catalogId;
                this.catalogSpecId = this.offerResponse.payload.cart.catalogSpecId;
            } else {
                this.errorMsg = 'Catalogs Array coming as null';
                this.retriveOffersLoading = false;
            }
            if (this.videoAvail && this.internetOffer) {
                this.videoLink = this.filterCategory(offerResponse, GenericValues.cDATVID);
            }
            if (this.phoneAvail && this.internetOffer) {
                this.dhpLink = this.filterCategory(offerResponse, GenericValues.cDHP);
            }
            this.createSlot();
        }
    }

    private sortSpeeds(offerResponse: ServiceCategoryBasedOffers[]) {
        let newOfferResponse = offerResponse;


        if (typeof newOfferResponse !== 'undefined' && newOfferResponse.length > 0) {
            for (var i = 0; i < newOfferResponse.length; i++) {
                if (typeof newOfferResponse[i].catalogs !== 'undefined' && newOfferResponse[i].catalogs.length > 0) {
                    if (typeof newOfferResponse[i].catalogs !== 'undefined' && newOfferResponse[i].catalogs.length > 0) {
                        let catalogItems = newOfferResponse[i].catalogs[0].catalogItems;
                        catalogItems.sort(this.offerHelperService.dynamicSort("displayOrder"))
                    }
                }
            }
        }
        return newOfferResponse
    }

    public findCustomerOrderObject(custObj: CustomerOrderItems[], filterBy, flag?): CustomerOrderItems {
        let val: CustomerOrderItems;
        if (custObj !== undefined) {
            custObj.forEach(obj => {
                if ((flag && (obj.offerCategory === filterBy || obj.offerCategory === GenericValues.sData))
                    && obj.offerType !== 'SUBOFFER') {
                    val = obj;
                } else if (!flag && obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER') {
                    val = obj;
                }
            });
        }
        return val;
    }

    public primaryFromRetain(customerOrderSubItems: Products[], filterBy) {
        let product: Products = {};
        let flag: boolean = false;
        customerOrderSubItems.forEach((prod) => {
            if (!flag && prod.componentType === filterBy) {
                flag = true;
                return product = prod;
            }
        });
        return product;
    }

    public filterSpeed(name: string, isExist: boolean) {
        this.filterObj = {
            name: name,
            isExist: isExist
        }

        this.dropName = name;
        if (name === 'Self Install Only') {
            let flg = false;
            for (let i = 0; i < this.selfInstallOffers.length; i++) {
                if (this.selfInstallOffers[i] === this.selectedSpeed) flg = true;
            }
            if (!flg) this.availSpeedChecked(this.selfInstallOffers[0]);
        } else if (name === 'Existing modem') {
            let flg = false;
            for (let i = 0; i < this.existingModemOffers.length; i++) {
                if (this.existingModemOffers[i] === this.selectedSpeed) flg = true;
            }
            if (!flg) this.availSpeedChecked(this.existingModemOffers[0]);
        }
    }

    public selfInstallOffers: string[] = [];
    public existingModemOffers: string[] = [];

    public createSlot() {
        // Looping the OfferList
        this.speedList = [];
        let speedList = [];
        this.speedList = [{
            productName: '',
            productDisplayName: '',
            techInstall: false,
            modem: false,
            tan: false
        }];
        speedList = [{
            productName: '',
            productDisplayName: '',
            techInstall: false,
            modem: false,
            tan: false
        }];
        let flag: boolean = false;
        let speedTemp: string = '';

        if (this.internerOffer !== undefined && this.internerOffer.length > 0 && this.internetCheck) {
            let custObj: CustomerOrderItems;
            if (!this.isReEntrant) {
                custObj = this.findCustomerOrderObject(this.existingServices, GenericValues.iData, true);
                if (custObj && custObj !== null && custObj !== undefined) {
                    let existingSpeed: string = this.primaryFromRetain(custObj.customerOrderSubItems, GenericValues.cPrimary).productName;
                    this.currentSpeed = existingSpeed;
                }
            }
            this.internerOffer.forEach((item) => {
                let speed = this.offerHelperService.searchforPrimary(item.productOffer.productComponents,
                    GenericValues.cPrimary);
                let flg = false;
                let name: any = {
                    productName: speed.productName,
                    productDisplayName: speed.productDisplayName,
                    tan: false
                };
                for (let i = 0; i < speedList.length; i++) {
                    if (speedList[i].productName === speed.productName) {
                        flg = true;
                    }
                }
                // Adding Unique Speed to the list by filtering from OfferList
                if (!flg) {
                    if (item.productOffer.offerAttributes !== null && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length !== 0) {
                        let offerAdded: boolean = false;
                        item.productOffer.offerAttributes.forEach(attr => {
                            this.isTan=false;
                            if (!offerAdded && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'yes') {
                                item.productOffer.offerAttributes.forEach(checkAttr => {
                                    if(checkAttr.attributeName === 'qualificationColorName' && checkAttr.attributeValue.toLowerCase() === 'tan') 
                                    {
                                       this.isTan=true;
                                       name.tan= this.isTan;
                                    }
                                    if (this.phoneSelected === 'NoPhone' && this.videoSelected === 'NoTV' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'no') {
                                        name = this.filterLogic(item, speed);
                                        if (speedList[0].productName === '') {
                                            speedList[0] = name;
                                        } else {
                                            speedList.push(name);
                                        }
                                        if (name.productName === this.selectedSpeed) flag = true;
                                        if (name.techInstall) this.selfInstallOffers.push(name.productName);
                                        if (name.modem) this.existingModemOffers.push(name.productName);
                                        offerAdded = true;
                                    } else if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                                        name = this.filterLogic(item, speed);
                                        if (speedList[0].productName === '') {
                                            speedList[0] = name;
                                        } else {
                                            speedList.push(name);
                                        }
                                        if (name.productName === this.selectedSpeed) flag = true;
                                        if (name.techInstall) this.selfInstallOffers.push(name.productName);
                                        if (name.modem) this.existingModemOffers.push(name.productName);
                                        offerAdded = true;
                                    } else if ((this.phoneSelected === 'DHP' || this.videoSelected !== 'NoTV') && (checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'no')) {
                                        name = this.filterLogic(item, speed);
                                        if (speedList[0].productName === '') {
                                            speedList[0] = name;
                                        } else {
                                            speedList.push(name);
                                        }
                                        if (name.productName === this.selectedSpeed) flag = true;
                                        if (name.techInstall) this.selfInstallOffers.push(name.productName);
                                        if (name.modem) this.existingModemOffers.push(name.productName);
                                        offerAdded = true;
                                    }
                                });
                            }
                        });
                    }
                }
                // Highlighting Offer by checking for isDefault as true from OfferList
                if (!flag && item.isDefault && !this.oneTimeLoading && speedList && speedList[0] && speedList[0].productName !== '') {

                    flag = true;
                    this.selectedSpeed = speed.productName;
                    speedTemp = speed.productName;
                }
            });
            this.speedList = speedList;
            if(!this.oneTimeLoading) { flag = false; }
            if (this.oneTimeLoading && flag) { this.availSpeedChecked(this.selectedSpeed); }
            if (!flag && !this.isReEntrant) {
                if (custObj && custObj !== null && custObj !== undefined) {
                    let existingSpeed: string = this.primaryFromRetain(custObj.customerOrderSubItems, GenericValues.cPrimary).productName;
                    this.currentSpeed = existingSpeed;
                    for (let i = 0; i < this.speedList.length; i++) {
                        if (this.speedList[i].productName === existingSpeed) {
                            this.availSpeedChecked(existingSpeed);
                            flag = true;
                            break;
                        }
                    }
                }
                if (!flag) {
                    if(custObj) { this.undoFlag = false; }
                    this.check = true;
                    if (speedTemp === '' && this.speedList && this.speedList.length > 0
                        && this.speedList[0].productName) {
                        this.availSpeedChecked(this.speedList[0].productName, 'true');
                    } else {
                        this.availSpeedChecked(speedTemp, 'true');
                    }
                }

            } else if (this.isReEntrant) {
                this.check = true;
                let custObjRentrant = this.findCustomerOrderObject(this.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
                if (custObjRentrant && custObjRentrant.customerOrderSubItems) {
                    this.availSpeedChecked(this.primaryFromRetain(custObjRentrant.customerOrderSubItems, GenericValues.cPrimary).productName);
                } else if (speedTemp !== '') {
                    this.availSpeedChecked(speedTemp);
                } else {
                    this.availSpeedChecked(this.speedList[0].productName);
                }
            }
        } else {
            this.matchingOffers = [];
            let phoneObj = this.findCustomerOrderObject(this.isReEntrant ? this.cartObject.payload.cart.customerOrderItems : this.existingServices, GenericValues.cHP, true);
            let offerEnable = false;
            this.phoneOfferData.forEach(items => {
                if (!this.videoOffer) {
                    if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
                        items.productOffer.offerAttributes.forEach(attr => {
                            if (this.phoneSelected === 'HMP' && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'no') {
                                items.productOffer.offerAttributes.forEach(checkAttr => {
                                    if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                                        offerEnable = true;
                                    }
                                })
                            }
                        })
                    }
                    if (offerEnable) {
                        let offerItemsPhone: OfferItems[] = [];
                        let offerItem1: OfferItems = {
                            productOfferingId: items.productOfferingId,
                            offerName: items.productOffer.offerName,
                            offerDisplayName: items.productOffer.offerDisplayName,
                            offerCategory: items.productOffer.offerCategory
                        }
                        offerItemsPhone.push(offerItem1);
                        let phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
                        let phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
                        let phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
                        let phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
                        let priceToAdd: Prices = {
                            discountedOtc: phonediscountedOtc,
                            discountedRc: phonediscountedRc,
                            otc: phoneOtcPrice,
                            rc: phoneRcPrice
                        }
                        let group1: OfferGroup;
                        group1 = {
                            offerItems: offerItemsPhone,
                            prices: [priceToAdd]
                        }
                        this.matchingOffers.push(group1);
                        if ((items.isDefault === 1 && !this.reEntrant && !this.hpExisting) || (this.reEntrant && this.reentrantUI && this.hpExisting && phoneObj && items.productOfferingId === phoneObj.productOfferingId)
                            || (!this.reEntrant && this.hpExisting && phoneObj && items.productOfferingId === phoneObj.productOfferingId)) {
                            this.selectedBundle(group1);
                            flag = true;
                        }
                    }
                } else if (this.videoOffer) {
                    this.videorOffer && this.videorOffer.forEach(dtv => {
                        if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
                            items.productOffer.offerAttributes.forEach(attr => {
                                if (this.phoneSelected === 'HMP' && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'no') {
                                    items.productOffer.offerAttributes.forEach(checkAttr => {
                                        if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                                            offerEnable = true;
                                        }
                                    });
                                }
                            });
                        }
                        if (offerEnable) {
                            let offerItemsPhone: OfferItems[] = [];
                            let offerItem1: OfferItems = {
                                productOfferingId: items.productOfferingId,
                                offerName: items.productOffer.offerName,
                                offerDisplayName: items.productOffer.offerDisplayName,
                                offerCategory: items.productOffer.offerCategory
                            }
                            offerItemsPhone.push(offerItem1);
                            offerItem1 = {
                                productOfferingId: dtv.productOfferingId,
                                offerName: this.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName : items.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
                                offerDisplayName: this.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName : items.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
                                offerCategory: dtv.productOffer.offerCategory
                            }
                            offerItemsPhone.push(offerItem1);
                            let phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
                            let phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
                            let phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
                            let phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
                            let priceToAdd: Prices = {
                                discountedOtc: dtv.defaultOfferPrice.discountedOtc + phonediscountedOtc,
                                discountedRc: dtv.defaultOfferPrice.discountedRc + phonediscountedRc,
                                otc: dtv.defaultOfferPrice.otc + phoneOtcPrice,
                                rc: dtv.defaultOfferPrice.rc + phoneRcPrice
                            }
                            let group1: OfferGroup;
                            group1 = {
                                offerItems: offerItemsPhone,
                                prices: [priceToAdd]
                            }
                            this.matchingOffers.push(group1);
                            if ((items.isDefault === 1 && !this.reEntrant && !this.hpExisting) || (this.reEntrant && this.reentrantUI && this.hpExisting && phoneObj && items.productOfferingId === phoneObj.productOfferingId)
                                || (!this.reEntrant && this.hpExisting && phoneObj && items.productOfferingId === phoneObj.productOfferingId)) {
                                this.selectedBundle(group1);
                                flag = true;
                            }
                        }
                    })
                }
            })
            if (!flag) this.selectedBundle(this.matchingOffers[0]);

        }
    }

    /**
     * To get Category by Type from List
     * Eg. DATA or VIDEO
     * @param categoryList
     * @param categoryId
     */
    public filterCategory(categoryList: ServiceCategoryBasedOffers[], categoryId: string):
        ServiceCategoryBasedOffers {
        return categoryList.find((item) => item.serviceCategory === categoryId);
    }
    public filterLogic(item: ProductOfferings, speed: Products): any { // filtering for truck and sorting

        this.selfInstall = false;
        let isCompatible = false;
        if (!this.selfInstallAvailable) {
            this.selfInstallAvailable = this.selfInstall
        }
        this.modemCompatValues = this.filterProductByType(item, 'MODEM', true);
        isCompatible = this.getModemCompatibilty(this.modemCompatValues, true);
        if (!this.modemAvailable) {
            this.modemAvailable = isCompatible;
        }
        let name: any = {
            productName: speed.productName,
            productDisplayName: speed.productDisplayName,
            techInstall: this.selfInstall,
            modem: isCompatible,
            tan: this.isTan
        };
        return name;
    }
    /**
     * To get Category by Type from List
     * Eg. DATA or VIDEO
     * @param categoryList
     * @param categoryId
     */
    public filterBundleCategory(categoryListItems: ServiceCategoryBasedOffers[],
        categoryId: string,
        filterBy: string): ProductOfferings[] {
        let categorys: ProductOfferings[] = [];
        let categoryList = this.sortSpeeds(categoryListItems);
        if (categoryList !== undefined) {
            categoryList.forEach((item) => {
                if (item.serviceCategory === categoryId) {
                    item.catalogs.forEach((catalog) => {
                        catalog.catalogItems.forEach(items => {
                            if (items.productOffer.offerCategory === filterBy) {
                                if (filterBy === GenericValues.cHP && items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes
                                    && items.productOffer.offerAttributes.length !== 0) {
                                    items.productOffer.offerAttributes.forEach(attr => {
                                        if (this.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'yes') {
                                            items.productOffer.offerAttributes.forEach(checkAttr => {
                                                if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                                                    categorys.push(items);
                                                }
                                            });
                                        } else if (!this.internetCheck && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'no') {
                                            items.productOffer.offerAttributes.forEach(checkAttr => {
                                                if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                                                    categorys.push(items);
                                                }
                                            });
                                        }
                                    });
                                } else {
                                    categorys.push(items);
                                }
                            }
                        });
                    });
                }
            });
        }
        return categorys;
    }

    public getActualPrice(filterBySpeed: string, category: string): number {
        let prod: Products;
        let price: number = 0;
        let offer: ProductOfferings[] = [];
        category === GenericValues.sData || category === GenericValues.iData ? offer = this.internerOffer : offer = this.videorOffer;
        offer && (offer.length > 0) && offer.forEach((item) => {
            if (!price && item && item.productOffer && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length > 0) {
                item.productOffer.offerAttributes.forEach(attr => {
                    if (this.internetCheck && (!this.phoneOffer || (this.phoneOffer && this.phoneSelected === 'DHP')) && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'no') {
                        price = this.offerHelperService.getOfferPrice(item, prod, price, filterBySpeed, 'actual');
                    } else if (this.phoneOffer && this.phoneSelected === 'HMP' && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'yes') {
                        price = this.offerHelperService.getOfferPrice(item, prod, price, filterBySpeed, 'actual');
                    }
                });
            }
        });
        return price;
    }

    /**
     * to show discounted price at match offer section
     * @param offer
     */
    public getDiscountedPrice(filterBySpeed: string, category: string): number {
        let prod: Products;
        let price: number = 0;
        let offer: ProductOfferings[] = [];
        category === GenericValues.sData || category === GenericValues.iData ? offer = this.internerOffer : offer = this.videorOffer;
        offer && (offer.length > 0) && offer.forEach((item) => {
            if (!price && item && item.productOffer && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length > 0) {
                item.productOffer.offerAttributes.forEach(attr => {
                    if (this.internetCheck && (!this.phoneOffer || (this.phoneOffer && this.phoneSelected === 'DHP')) && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'no') {
                        price = this.offerHelperService.getOfferPrice(item, prod, price, filterBySpeed, 'disc');
                    } else if (this.phoneOffer && this.phoneSelected === 'HMP' && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'yes') {
                        price = this.offerHelperService.getOfferPrice(item, prod, price, filterBySpeed, 'disc');
                    }
                });
            }
        });
        return price;
    }

    /**
     * Filter each product by Type from Offer Object
     */
    public filterProductByType(inputData: ProductOfferings, type: string, isModem?): OfferProductComponents {
        let data = cloneDeep(inputData)
        let modem: OfferProductComponents;
        data && data.productOffer && (data.productOffer.productComponents.length > 0) &&
        data.productOffer.productComponents 
            .forEach((item) => {
                if (item.product.productName === type) {
                    let value: AttributesCombination;
                    let values: AttributesCombination[] = [];
                    item && item.product && (item.product.productAttributes.length > 0) && 
                    item.product.productAttributes.forEach(val => {
                        let price: Prices[] = [];
                        if (val && val.isPriceable) {
                            let comp: CompositeAttribute[] = [];
                            val.compositeAttribute && (val.compositeAttribute.length > 0) && val.compositeAttribute.map(attr => {
                                if (attr.attributeValue === 'Self Install') {
                                    this.selfInstall = true;
                                }
                                if (attr.attributeName === 'Account Type') {
                                    comp.push(attr);
                                }
                            });
                            val.compositeAttribute && (val.compositeAttribute.length > 0) && val.compositeAttribute.map(attr => {
                                if (attr.attributeName !== 'Account Type') {
                                    comp.push(attr);
                                }
                            });
                            val = Object.assign({},
                                val, {
                                    compositeAttribute: comp
                                }
                            )
                            val && val.prices && (val.prices.length > 0) && val.prices.map(v => {
                                if (v.priceType === GenericValues.pPriceType) {
                                    value = val;
                                    price.push(v);
                                }
                            })
                            value && value.prices && value.prices.map(v => {
                                if (v.priceType !== GenericValues.pPriceType) {
                                    price.push(v);
                                }
                            })
                            if (type === 'MODEM') {
                                value = Object.assign({},
                                    value, {
                                        prices: price,
                                        compositeAttribute: val.compositeAttribute.sort(this.offerHelperService.sortModemComposite)
                                    }
                                )
                            }
                            else {
                                value = Object.assign({},
                                    value, {
                                        prices: price
                                    }
                                )
                            }
                            values.push(value);
                        } else if (isModem && type === 'MODEM') {
                            values.push(val);
                        } else if (isModem && type === 'TECH INSTALL') {
                            values.push(val);
                            val.compositeAttribute.forEach(attr => {
                                if (attr.attributeName === 'TechInstallRecommended') {
                                    this.recommendedTech = val;
                                }
                            });
                        }
                    })
                    let cloneItem = cloneDeep(item);
                    cloneItem.product = Object.assign({},
                        cloneItem.product, {
                            productAttributes: values
                        }
                    )
                    let product = {
                        productId: cloneItem.product.productId,
                        productName: cloneItem.product.productName,
                        productDisplayName: cloneItem.product.productDisplayName,
                        productType: cloneItem.product.productType,
                        componentType: cloneItem.componentType,
                        productAttributes: cloneItem.product.productAttributes,
                        productAssociations: cloneItem.product.productAssociations,
                        productCategory: cloneItem.product.productCategory,
                        quantity: cloneItem.product.quantity
                    };
                    modem = cloneItem;
                    modem = Object.assign({},
                        modem, {
                            product: product
                        }
                    )
                }
            });
        return modem;
    }

    public recommendedTech: AttributesCombination;

    /**
     * Calculate the maximum Discount amount of the offers
     */
    public maxDiscountAmount(data: Discounts[]) {
        let totDiscAmt: number = 0;
        data && (data.length > 0) && data.map((item) => {
                totDiscAmt = totDiscAmt + item.discountRate;
        });
        return totDiscAmt;
    }

    public getPrice(price: Prices): string {
        let cost: string = '';
        if(price) {
            if (price.discountedOtc !== 0) {
                cost = '$' + price.discountedOtc.toFixed(2);
            } else if (price.otc !== 0) {
                cost = '$' + price.otc.toFixed(2);
            } else if (price.discountedRc !== 0) {
                cost = '$' + price.discountedRc.toFixed(2) + '/mo';
            } else if (price.rc !== 0) {
                cost = '$' + price.rc.toFixed(2) + '/mo';
            }
        }
        return cost;
    }

    public recomTechInstall: OfferProductComponents;
    public existingModem: Products;
    /**
     * While click on Offer from Section corresponding Product and Prices to be populated in Panel
     */
    public internetSlot(offer: ProductOfferings) {
        this.isShowRemoveRetentionDiscountMsg = false;
        this.hsiRemovedRetentiondiscounts = [];
        this.retentionDiscountsToCart = [];
        this.selectedInternetOfferdId = offer.productOfferingId;
        this.selfInstall = false;
        this.deviceMandatory = false;
        this.selectedOffer = offer;
        this.speedselected = this.selectedOffer.productOffer.offerName
        this.techInstallExist = false;
        this.newTechInstall = true;
        this.installError = false;
        let internetProduct: Products = this.offerHelperService.searchforPrimary(offer.productOffer
            .productComponents, GenericValues.cPrimary);
        this.selectedSpeed = internetProduct.productName;
        if (offer.defaultOfferPrice !== null && offer.defaultOfferPrice !== undefined) {
            this.actualPrice = offer.defaultOfferPrice.rc;
            this.discountedPrice = offer.defaultOfferPrice.discountedRc === offer.defaultOfferPrice.rc ? 0 : offer.defaultOfferPrice.discountedRc;
            this.actualInternetOtcPrice = offer.defaultOfferPrice.otc;
            this.discountedInternetOtcPrice = offer.defaultOfferPrice.discountedOtc;
            this.errorMsg = serverErrorMessages.empty;
        } else {
            this.errorMsg = serverErrorMessages.priceObjectNull;
        }
        this.modemValues = cloneDeep(this.filterProductByType(offer, 'MODEM'));
        this.modemCompatValues = this.filterProductByType(offer, 'MODEM', true);
        this.modemValues.product.productAttributes.sort(this.offerHelperService.dynamicSort("displayOrder"));
        this.easeValues = this.filterProductByType(offer, 'CENTURYLINK @ EASE');
        if(this.easeValues && this.easeValues.product && this.easeValues.product !== undefined){
            this.easeValues.product.productAttributes.sort(this.offerHelperService.dynamicSort("displayOrder"));            
        }
        this.installationValues = this.filterProductByType(offer, 'TECH INSTALL');
        this.recomTechInstall = this.filterProductByType(offer, 'TECH INSTALL', true);
        this.installationValues.product.productAttributes.sort(this.offerHelperService.dynamicSort("displayOrder"));
        if (!this.phoneOffer || (this.phoneOffer && this.phoneSelected !== 'HMP')) {
            this.jackValues = this.filterProductByType(offer, 'Jack and Wire');
            if (this.jackValues && this.jackValues.product && this.jackValues.product.productAttributes) {
                this.jackValues.product.productAttributes.sort(this.offerHelperService.dynamicSort("displayOrder"));
            }
        }
        let custObj;
        if (this.isReEntrant || this.fromHold) {
            custObj = this.findCustomerOrderObject(this.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
        } else {
            custObj = this.findCustomerOrderObject(this.existingServices, GenericValues.iData, true);
        }
        if (custObj !== undefined) {
            let existingSpeed: string = this.primaryFromRetain(custObj.customerOrderSubItems, GenericValues.cPrimary).productName;
            this.selectedSpeed === existingSpeed ? this.check = false : this.check = true;
        }
        this.isBundleSalesExpired = false;
        this.isSpeedSalesExpired = false;
        if (!this.check && offer && offer.productOffer && offer.productOffer.validFor && offer.productOffer.validFor.saleExpirationDate) {
            let salesExpiryDate = new Date(offer.productOffer.validFor.saleExpirationDate);
            let currentDay = new Date();
            if (salesExpiryDate > currentDay) {
                if (offer.productOffer.validFor.saleExpired && (offer.productOffer.validFor.saleExpired.toUpperCase() === 'Y')) {
                    this.isSpeedSalesExpired = true;
                } else if (offer.productOffer.validFor.saleExpired && (offer.productOffer.validFor.saleExpired.toUpperCase() === 'N')) {
                    this.isSpeedSalesExpired = false;
                }
                if (offer.productOffer.validFor.bundleSaleExpired && (offer.productOffer.validFor.bundleSaleExpired.toUpperCase() === 'Y')) {
                    this.isBundleSalesExpired = true;
                } else if (offer.productOffer.validFor.bundleSaleExpired && (offer.productOffer.validFor.bundleSaleExpired.toUpperCase() === 'N')) {
                    this.isBundleSalesExpired = false;
                }
            } else {
                this.isBundleSalesExpired = false;
                this.isSpeedSalesExpired = false;
            }
        }
        if (!this.check && offer && offer.productOffer && offer.productOffer.validFor) {
            if (offer.productOffer.validFor.saleExpired && (offer.productOffer.validFor.saleExpired.toUpperCase() === 'Y')) {
                this.isSpeedSalesExpired = true;
            } else if (offer.productOffer.validFor.saleExpired && (offer.productOffer.validFor.saleExpired.toUpperCase() === 'N')) {
                this.isSpeedSalesExpired = false;
            }
            if (offer.productOffer.validFor.bundleSaleExpired && (offer.productOffer.validFor.bundleSaleExpired.toUpperCase() === 'Y')) {
                this.isBundleSalesExpired = true;
            } else if (offer.productOffer.validFor.bundleSaleExpired && (offer.productOffer.validFor.bundleSaleExpired.toUpperCase() === 'N')) {
                this.isBundleSalesExpired = false;
            }
        }
        let previousModemSelection = cloneDeep(this.isModemCompatible);
        let isCompatible = this.getModemCompatibilty(this.modemCompatValues);
        if (!this.oneTimeLoading || this.undoSelected) {
            let custSubObj: CustomerOrderSubItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'TECH INSTALL');
            if (custSubObj !== undefined && !this.check) {
                this.newTechInstall = false;
                this.techInstallExist = true;
                if (this.holdCalled) this.selectedInstallation = custSubObj;
            }
            else if (!custSubObj || this.check) {
                this.selectedInstallation = this.searchForDefault(true, this.installationValues);
                this.newTechInstall = true;
            }
            custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'MODEM');
            if (isCompatible) {
                custObj = this.findCustomerOrderObject(this.existingServices, GenericValues.iData, true);
                custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'MODEM');
                if (!this.existingModem) this.existingModem = custSubObj;
                this.selectedModemToShow = custSubObj;
                this.modemExist = true;
            }
            custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'CENTURYLINK @ EASE');
            if (custSubObj !== undefined) {
                this.selectedEase = custSubObj;
                this.easeExist = true;
                this.onChangeEase(this.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue, false);
            }
            else {
                this.selectedEase = this.searchForDefault(true, this.easeValues);
            }
            custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'Jack and Wire');
            if (custSubObj !== undefined) {
                this.selectedJack = custSubObj;
                this.jackExist = true;
            }
            else {
                this.selectedJack = this.searchForDefault(true, this.jackValues);
            }
            if (!this.hpExisting) this.undoSelected = false;
        } else {
            this.retainPreSelected(this.selectedInstallation, this.installationValues, 'install');
            this.retainPreSelected(this.selectedModem, this.modemValues, 'modem', previousModemSelection);
            this.retainPreSelected(this.selectedEase, this.easeValues, 'ease');
            this.retainPreSelected(this.selectedJack, this.jackValues, 'jack');
        }

        if (this.installationValues.isMandatory && !this.selectedInstallation && this.check && this.newTechInstall) {
            this.installError = true;
        }
        this.modemError = false;
        if (this.modemValues.isMandatory && (!this.selectedModem && !this.isModemCompatible)) {
            this.modemError = true;
        }
        if (this.easeValues && this.easeValues !== undefined && this.easeValues.isMandatory && !this.selectedEase) {
            this.easeError = true;
        }


        this.recomTechInstall && this.recomTechInstall.product && this.recomTechInstall.product.productAttributes &&
            this.recomTechInstall.product.productAttributes.map(attr => {
                attr && attr.compositeAttribute && attr.compositeAttribute.map(comp => {
                    if (comp.attributeName === 'TechInstallRecommended') {
                        this.recommendedTech = attr;
                    }
                })
            })
        if (!((!this.selfInstall && this.installationValues.product.productName === 'TECH INSTALL' &&
            (this.recommendedTech && this.recommendedTech.compositeAttribute && this.recommendedTech.compositeAttribute[0] && this.recommendedTech.compositeAttribute[0].attributeValue !== 'Y')) ||
            (this.recommendedTech && this.recommendedTech.compositeAttribute && this.recommendedTech.compositeAttribute[0] && this.recommendedTech.compositeAttribute[0].attributeValue === 'Y'))) {
           this.selectedInstallation = undefined;
        }

        this.retainData();

        let custPotsObj = this.findCustomerOrderObject(this.existingServices, GenericValues.cHP);
        let custPotsSubObj: CustomerOrderSubItem = this.findCustomerSubOrderObjectIndexOf(custPotsObj, 'Wire Maintenance Plan');
        if (custPotsSubObj !== undefined) {
            this.selectedMaintainance = custPotsSubObj;
            this.wireMaintainanceExist = true;
        }

        this.loadedConfig = false;
        if (!this.videoOffer && !this.phoneOffer) {
            this.retriveOffersLoading = false;
            this.cartRequest();
        }
        if (internetProduct.productAttributes !== null && internetProduct.productAttributes.length > 0) {
            this.discountedPriceList = [];
            let attr = this.fetchIsPriceable(internetProduct.productAttributes);
            let discounts: Discounts[] = [];
            attr.discounts === null ? discounts = [] : discounts = attr.discounts;
            for (let discount of discounts) {
                if (discount.autoAttachInd === 'Y') {
                    this.discountedPriceList.push(discount)
                }


            }
            //find the existing discount availble in the current offer
            for (let existdiscount of this.existingRetentionDiscounts) {
                let existingDiscountMatchFound = false;
                for (let discount of discounts) {
                    if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {

                        existingDiscountMatchFound = true;
                    }
                }

                if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0 && (this.isHPRemoved || this.isDHPRemoved)) {
                    this.hsiRemovedRetentiondiscounts.push(existdiscount);     
                    this.isShowRemoveRetentionDiscountMsg = true;
                }
                //send only discounts matching in current offer and not the otc discounts.
                if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
                    this.retentionDiscountsToCart.push(existdiscount);

                }
            }
            if (!this.reEntrant) this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.retentionDiscountsToCart });
            if (this.videoSelected === 'NoTV' && !this.phoneOffer) {
                this.totalDiscountAmount = this.discountedPriceList ?
                    this.maxDiscountAmount(this.discountedPriceList) : 0;
            }
        }
        this.internetData = internetProduct;
        this.oneTimeLoading = true;
    }
    public reEntrantLoaded = false;
    public oneTimeLoading: boolean = false;
    private retainPreSelected(selectedProduct: Products, component: OfferProductComponents, type: string, modemCompatible?: boolean) {
        let prodComp = this.searchForDefault(true, component);
        if (type === 'ease' && this.EaseDefault) {
            selectedProduct = undefined;
            this.selectedEase = undefined;
        }
        if ((selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].compositeAttribute && type !== 'modem')
            || (selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].compositeAttribute && type === 'modem' && modemCompatible === this.isModemCompatible)) {
            if (prodComp && prodComp.productAttributes && prodComp.productAttributes[0] && prodComp.productAttributes[0].compositeAttribute) {
                let exSelection = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                let currentDef = this.offerHelperService.getModemTypeforRetain(prodComp.productAttributes[0].compositeAttribute);
                if (exSelection === currentDef) {
                    let currentPrice, oldPrice;
                    prodComp.productAttributes[0].prices && prodComp.productAttributes[0].prices.map(price => {
                        if (price && price.priceType === GenericValues.pPriceType) {
                            currentPrice = this.populateValues(price);
                        }
                    });
                    selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].prices &&
                        selectedProduct.productAttributes[0].prices.map(price => {
                            if (price && price.priceType === GenericValues.pPriceType) {
                                oldPrice = this.populateValues(price);
                            }
                        });
                    if (currentPrice <= oldPrice) {
                        this.changeSelection(type, exSelection, component);
                    }
                    else {
                        this.makeUndefined(type);
                    }
                }
                else {
                    let exSelection1 = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                    let currentPrice: number = 0, oldPrice: number = 0;
                    selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].prices &&
                        selectedProduct.productAttributes[0].prices.map(price => {
                            if (price && price.priceType === GenericValues.pPriceType) {
                                oldPrice = this.populateValues(price);
                            }
                        });
                    let currentDef1 = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                    let price = currentDef1 === 'na' ? this.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
                        component, currentDef1, type.toUpperCase());
                    if (price && price.prices && price.prices.length > 0) {
                        price.prices.forEach(prize => {
                            if (prize && prize.priceType === GenericValues.pPriceType) {
                                currentPrice = this.populateValues(prize);
                            }
                        });
                    }
                    let isExExist = this.offerHelperService.getPriceDetailsByAttrVal(component, exSelection1, '');
                    if (isExExist) {
                        if (currentPrice <= oldPrice) {
                            this.changeSelection(type, exSelection1, component);
                        } else {
                            this.makeUndefined(type);
                        }
                    } else {
                        if (!this.selfInstall || type === 'install') {
                            this.changeSelection(type, currentDef, component);
                        }
                    }
                }
            }
            else {
                let exSelection = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                this.changeSelection(type, exSelection, component);
            }
        } else {
            this.makeUndefined(type);
        }
    }
    public changeSelection(type: string, exSelection: string, component: OfferProductComponents) {
        switch (type) {
            case 'install': this.onChangeInstallation(exSelection, component.isMandatory); break;
            case 'modem': this.onChangeModem(exSelection, component.isMandatory); break;
            case 'ease': this.onChangeEase(exSelection, component.isMandatory); break;
            case 'jack': this.onChangeJacks(exSelection, component && component.isMandatory); break;
        }
    }
    public makeUndefined(type: string) {
        switch (type) {
            case 'install': this.selectedInstallation = undefined; break;
            case 'modem': this.selectedModem = undefined; break;
            case 'ease': this.selectedEase = undefined; this.EaseDefault = true; break;
            case 'jack': this.selectedJack = undefined; break;
        }
    }
    public populateValues(prices: Prices): number {
        let price: number = 0;
        if (prices.discountedRc === 0) {
            if (prices.rc === 0) {
                if (prices.discountedOtc === 0) {
                    if (prices.otc !== 0) { price = prices.otc; }
                } else {
                    if (prices.discountedOtc !== 0) { price = prices.discountedOtc; }
                }
            }
            else { if (prices.rc !== 0) { price = prices.rc; } }
        } else {
            if (prices.discountedRc !== 0) { price = prices.discountedRc; }
        }

        return price;
    }

    public retainData() {

        if ((this.isReEntrant || this.reentrantUI) && !this.reEntrantLoaded) {
            this.selectedInstallation = undefined;
            this.selectedModem = undefined;
            this.selectedEase = undefined;
            this.installError = false;
            this.modemError = false;
            this.easeError = false;
            this.jackError = false;
            let custObj = this.findCustomerOrderObject(this.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
            if (custObj && custObj.customerOrderSubItems) {
                let custSubObj: CustomerOrderSubItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'TECH INSTALL');

                if (custSubObj !== undefined) {
                    this.selectedInstallation = custSubObj;
                } else if (custSubObj !== undefined && this.holdCalled) {
                    this.selectedInstallation = custSubObj;
                }

                if (this.selectedInstallation && this.installationValues && this.installationValues.isMandatory && !this.selectedInstallation && !custSubObj) {
                    this.installError = true;
                }

                custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'MODEM');
                if (custSubObj !== undefined) {
                    this.selectedModem = custSubObj;
                }

                if (this.modemValues && this.modemValues.isMandatory && !this.selectedModem) {
                    this.modemError = true;
                }

                custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'CENTURYLINK @ EASE');
                if (custSubObj !== undefined) {
                    this.selectedEase = custSubObj;
                }

                if (this.easeValues && this.easeValues.isMandatory && !this.selectedEase) {
                    this.easeError = true;
                }

                if (!this.phoneOffer || (this.phoneOffer && this.phoneSelected === 'DHP')) {
                    custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'Jack and Wire');
                    if (custSubObj !== undefined) {
                        this.selectedJack = custSubObj;
                    }
                    if (this.isReEntrant && this.selectedJack === undefined) {
                        this.JacksWireDefault = true;
                    }
                    if (this.jackValues && this.jackValues.isMandatory && !this.selectedJack) {
                        this.jackError = true;
                   }
                }

            }
            this.reEntrantLoaded = true;
        }
    }

    private getModemCompatibilty(modemValues: OfferProductComponents, flag?): boolean {
        let isModemCompatible = true;
        modemValues = this.modemCompatValues;
        modemValues && modemValues.product && modemValues.product.productAttributes && modemValues.product.productAttributes.map(attr => {
            attr && attr.compositeAttribute && attr.compositeAttribute.map(comp => {
                if (comp && comp.attributeName === 'modemCompatibility' && comp.attributeValue.toLowerCase() === 'false') {
                    isModemCompatible = false;
                }
            })
        })
        if(!flag) this.isModemCompatible = isModemCompatible;
        return isModemCompatible;
    }
    public getModemCompatibiltyMsg(modemValues: OfferProductComponents): string {
        let isModemCompatible = 'true';
        modemValues = this.modemCompatValues;
        modemValues && modemValues.product && modemValues.product.productAttributes && modemValues.product.productAttributes.map(attr => {
            attr && attr.compositeAttribute && attr.compositeAttribute.map(comp => {
                if (isModemCompatible === 'true' && comp && comp.attributeName === 'modemCompatibilityMessage') {
                    isModemCompatible = comp.attributeValue;
                }
            })
        })
        return isModemCompatible;
    }

    private getProductConfig(comp: Products, flag, val?, change?): any {
        let values = [];
        if (this.productConfiguration && this.productConfiguration.length > 0) {
            let configList = this.productConfiguration;
            configList.map(config => {
                let attributeExist = false;
                if (config && config.configItems !== null && config.configItems && config.configItems.length > 0) {
                    config.configItems.map(item => {
                        if (comp && item.productName === comp.productName) {
                            if (item.prodSelectionRule !== null && item.prodSelectionRule && item.prodSelectionRule.length > 0) {
                                item.prodSelectionRule.map(rule => {
                                    if (rule.action === GenericValues.cSelect
                                        && rule.value === comp.productAttributes[0].compositeAttribute[0].attributeValue) {
                                        attributeExist = true;
                                        values = this.tempConfig;
                                        if (flag && item.configDetails !== null && item.configDetails && item.configDetails.length > 0) {
                                            item.configDetails.map(det => {
                                                let isExistConfig = false;
                                                if (det.formName === GenericValues.cDevices) {
                                                    det.formItems && det.formItems.map(form => {
                                                        if (!this.reEntrant || !this.loadedConfig) {
                                                            values = form.attributeValue;
                                                            this.tempConfig = values;
                                                            this.deviceMandatory = form.isMandatory;
                                                        }
                                                        if (this.configSelected.length > 0) {
                                                            for (let i = 0; i < this.configSelected.length; i++) {
                                                                if (this.configSelected[i].configItems[0].productName === comp.productName) {
                                                                    isExistConfig = true;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        if (!isExistConfig && !this.reEntrant) {
                                                            this.configRequest(config, values, true, comp);
                                                        } else if (this.reEntrant && (!this.loadedConfig || change)) {
                                                            let selectConfigList = this.cartCopyObject.payload.productConfiguration;
                                                            if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
                                                                for (let i = 0; i < selectConfigList.length; i++) {
                                                                    selectConfigList[i].configItems && selectConfigList[i].configItems.map(selectedConf => {
                                                                        if (comp && selectedConf.productName === comp.productName) {
                                                                            let tempVal = [];
                                                                            values && values.map(value => {
                                                                                this.deviceMandatory = form.isMandatory;
                                                                                if (selectedConf.configDetails[0].formItems[0].attributeValue[0].value === value.value) {
                                                                                    tempVal.push({ value: value.value, isDefault: true })
                                                                                } else {
                                                                                    tempVal.push({ value: value.value, isDefault: false })
                                                                                }
                                                                            })
                                                                            values = tempVal;
                                                                            this.tempConfig = values;
                                                                        }
                                                                    })
                                                                }
                                                            }
                                                            this.configRequest(config, values, true, comp);
                                                        }
                                                        this.loadedConfig = true;
                                                    })
                                                }
                                            })
                                        } else if (!flag) {
                                            this.configRequest(config, val, false, comp);
                                        }
                                    }
                                })
                            }
                        } else {
                            values = [];
                        }
                    })
                }
                if (!attributeExist) {
                    this.configRequest(config, undefined, false, comp);
                }
            })
        }
        return values;
    }

    public configRequest(config, values, flag, comp: Products) {
        if (values) {
            let select = false;
            if (flag) {
                values.forEach(val => {
                    if (!select && val.isDefault) {
                        this.deviceSelected = true;
                        values = val;
                        select = true;
                    }
                });
            }
            if (!select && flag) {
                values = values[0];
                this.deviceSelected = true;
                this.selectedQuantity = values && values.value;
            }
            if (!flag) {
                this.deviceSelected = true;
                values = {
                    value: values
                }
                this.selectedQuantity = values && values.value;
            }
            if (this.deviceSelected) {
                let productConfiguration = {
                    "configItems": [
                        {
                            "productId": "",
                            "productName": config.configItems[0].productName,
                            "configDetails": [
                                {
                                    "isConfigRequired": config.configItems[0].configDetails[0].isConfigRequired,
                                    "formName": config.configItems[0].configDetails[0].formName,
                                    "formItems": [
                                        {
                                            "attributeName": config.configItems[0].configDetails[0].formItems[0].attributeName,
                                            "attributeType": config.configItems[0].configDetails[0].formItems[0].attributeType,
                                            "isMandatory": config.configItems[0].configDetails[0].formItems[0].isMandatory,
                                            "attributeValue": [values]
                                        }
                                    ]
                                }
                            ]
                        }
                    ],
                    "productType": config.productType
                }
                let pushed = false;
                if (this.configSelected.length > 0) {
                    for (let i = 0; i < this.configSelected.length; i++) {
                        if (comp && this.configSelected[i].configItems[0].productName === comp.productName) {
                            this.configSelected[i] = productConfiguration;
                            pushed = true;
                            break;
                        }
                    }
                    if (!pushed) {
                        this.configSelected.push(productConfiguration);
                    }
                } else if (this.configSelected.length === 0) {
                    this.configSelected.push(productConfiguration);
                }
            }
        } else {
            if (this.configSelected.length > 0) {
                for (let i = 0; i < this.configSelected.length; i++) {
                    if (comp && this.configSelected[i].configItems[0].productName === comp.productName) {
                        this.configSelected.splice(i, 1);
                        break;
                    }
                }
            }
        }
    }

    public fetchIsPriceable(productAttributes: AttributesCombination[]) {
        let prodAttr: AttributesCombination;
        productAttributes && (productAttributes.length > 0) && productAttributes.map(attr => {
            if (attr.isPriceable) {
                prodAttr = attr
            }
        })
        return prodAttr;
    }

    public fetchPriceTypeFromPrimary(productAttributes: AttributesCombination[]): Prices {
        let prices: Prices;
        productAttributes && (productAttributes.length > 0) && productAttributes.map(attr => {
            if (attr && attr.isPriceable) {
                attr.prices && (attr.prices.length > 0) && attr.prices.map(price => {
                    if (price.priceType === GenericValues.pPriceType) {
                        prices = price;
                    }
                })
            }
        })
        return prices;
    }

    /**
     * Populate default component value in dropdowns
     * @param defaultVal
     * @param addons
     */
    public searchForDefault(defaultVal: boolean, cloneAddons: OfferProductComponents,
        priceSelected?: AttributesCombination): Products {
        let addons = cloneDeep(cloneAddons);
        let component: Products;
        let flag: boolean = false;
        let prodAttr: AttributesCombination;
        let prodAttrs: AttributesCombination[] = [];
        let prodAttrTemp: AttributesCombination;
        if (addons !== undefined && addons.product !== undefined) {
            component = addons.product;
            prodAttrs = [];
            if (defaultVal) {
                if (addons.product.productAttributes !== null && addons.product.productAttributes.length > 0) {
                    addons.product.productAttributes.forEach((item) => {
                        let composite: CompositeAttribute[] = [];
                        if (!flag && item.isDefault) {
                            flag = true;
                            prodAttr = item;
                        }
                        composite = [];
                        if (addons.isMandatory && item.isPriceable) {
                            prodAttrTemp = item;
                        }
                    });
                    if (!flag) {
                        prodAttr = prodAttrTemp;
                    }
                }
                !flag ? prodAttrs = [] : prodAttrs.push(prodAttr);
                component = Object.assign({},
                    component, {
                        productAttributes: prodAttrs,
                        componentType: addons.componentType
                    }
                );
                component = {
                    productId: component.productId,
                    productName: component.productName,
                    productType: component.productType,
                    componentType: component.componentType,
                    productAttributes: component.productAttributes,
                    productAssociations: component.productAssociations,
                    productCategory: component.productCategory,
                    quantity: 1,
                    action: component.productName === 'TECH INSTALL' && this.techInstallExist ? 'NOCHANGE' : 'ADD'
                };
                if (prodAttr === undefined || !flag) {
                    component = undefined;
                }
            } else {
                if (priceSelected !== undefined) {
                    prodAttrs.push(priceSelected);
                    component = Object.assign({},
                        component, {
                            productAttributes: prodAttrs,
                            componentType: addons.componentType
                        }
                    );
                    component = {
                        productId: component.productId,
                        productName: component.productName,
                        productType: component.productType,
                        componentType: component.componentType,
                        productAttributes: component.productAttributes,
                        productAssociations: component.productAssociations,
                        productCategory: component.productCategory,
                        quantity: 1,
                        action: this.checkAction(component.productName)
                    }
                } else {
                    component = undefined;
                }
            }
        }
        return component;
    }

    public checkAction(component) {
        let action: string = 'ADD';
        if (component === 'TECH INSTALL') {
            return 'NOCHANGE';
        }

        if (component === 'MODEM' && this.modemExist) {
            return 'CHANGE';
        }

        if (component === 'CENTURYLINK @ EASE' && this.easeExist) {
            return 'CHANGE';
        }

        if (component === 'Jack and Wire' && this.jackExist) {
            return 'CHANGE';
        }

        return action;

    }

    public checkExistingOnlyOfferingId(existingProduct, currentProduct, type) {
        let val = 'CHANGE';
        this.undoChanges = true;
        if (type === 'internet' && existingProduct !== undefined && currentProduct !== undefined) {
            if (existingProduct.customerOrderSubItems !== null && existingProduct.customerOrderSubItems
                && existingProduct.customerOrderSubItems.length > 0) {
                existingProduct.customerOrderSubItems.map(subItems => {
                    if (this.undoChanges && subItems.componentType === GenericValues.cPrimary) {
                        if (currentProduct.productOffer.productComponents) {
                            currentProduct.productOffer.productComponents.map(currentItem => {
                                if (this.undoChanges && currentItem.componentType === GenericValues.cPrimary
                                    && subItems.productId === currentItem.product.productId) {
                                    val = 'NOCHANGE';
                                    this.undoChanges = false;
                                }
                            })
                        }
                    }
                })

            }
            return val;
        } else {
            this.undoChanges = false;
            if (Object.keys(existingProduct).length > 0 && existingProduct.productOfferingId !== currentProduct.productOfferingId) {
                this.undoChanges = true;
                return 'CHANGE';
            }
            else return 'NOCHANGE';
        }
    }

    public checkExistingSubOffers(existingProduct, currentProduct, type, filter, subType) {
        let subOrderItem;
        if (existingProduct !== undefined && currentProduct !== undefined) {
            if (type === 'internet') {
                if (subType === GenericValues.install) {
                    if (this.selectedInstallation !== undefined && this.selectedInstallation.productAttributes !== undefined && subType === GenericValues.install) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'TECH INSTALL');
                        if (subOrderItem !== undefined && this.selectedInstallation !== undefined && this.selectedInstallation.productAttributes !== undefined) {
                            if (this.selectedInstallation.productAttributes.length === 0) return 'CHANGE';
                            if (this.selectedInstallation.productAttributes.length > 0 && this.selectedInstallation.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
                                return 'CHANGE';
                            }
                            if (this.newTechInstall) {
                                return 'ADD';
                            }
                        } else if (subOrderItem === undefined && this.selectedInstallation !== undefined) {
                            return 'ADD';
                        } else if (subOrderItem !== undefined && this.selectedInstallation === undefined) {
                            return 'REMOVE';
                        }
                    }
                }
                if (subType === GenericValues.modem) {
                    subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'MODEM');
                    if (subOrderItem !== undefined && this.selectedModem !== undefined && this.selectedModem.productAttributes !== undefined) {
                        if (this.selectedModem.productAttributes.length === 0) return 'CHANGE';
                        if (this.selectedModem.productAttributes.length > 0 && this.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
                            return 'CHANGE';
                        }
                    } else if (subOrderItem === undefined && this.selectedModem !== undefined) {
                        return 'ADD';
                    } else if (subOrderItem !== undefined && this.selectedModem === undefined) {
                        return 'REMOVE';
                    }
                }
               if (subType === GenericValues.ease) {
                    subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'CENTURYLINK @ EASE');
                    if (this.selectedEase !== undefined && this.selectedEase.productAttributes !== undefined && subOrderItem !== undefined) {
                        if (this.selectedEase.productAttributes.length === 0) return 'CHANGE';
                        if (this.selectedEase.productAttributes.length > 0 && this.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
                            return 'CHANGE';
                        }
                    } else if (subOrderItem === undefined && this.selectedEase !== undefined) {
                        return 'ADD';
                    } else if (subOrderItem !== undefined && this.selectedEase === undefined) {
                        return 'REMOVE';
                    }
                }
            }
        }
        return 'NOCHANGE';
    }

    public checkExistingOfferingId(existingProduct, currentProduct, type, filter) {
        let subOrderItem;
        let val = 'CHANGE';
        this.undoChanges = true;
        if (existingProduct !== undefined && currentProduct !== undefined) {
            if (type === 'internet' && existingProduct !== undefined && currentProduct !== undefined) {
                if (existingProduct.productOfferingId !== currentProduct.productOfferingId) {
                    this.undoChanges = true;
                    val = 'CHANGE';
                }
                else val = 'NOCHANGE';
            } else if (existingProduct.productOfferingId !== currentProduct.productOfferingId) {
                this.undoChanges = true;
                return 'CHANGE';
            } else if (type === 'dhp' && existingProduct.productOfferingId === currentProduct.productOfferingId) {
                this.undoChanges = true;
                return 'NOCHANGE';
            }
            if (val !== 'CHANGE') {
                this.undoChanges = false;
                if (type === 'internet') {
                    if (this.selectedModem !== undefined && this.selectedModem.productAttributes !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'MODEM');
                        if ((subOrderItem !== undefined && this.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) || (subOrderItem !== undefined && this.selectedModem.action && this.selectedModem.action === 'REMOVE')) {
                            this.undoChanges = true;
                            return 'CHANGE';
                        } else if (subOrderItem === undefined) {
                            this.undoChanges = true;
                            return 'CHANGE'
                        }
                    }
                    else if (this.selectedModem === undefined && this.modemExist && !this.isModemCompatible) {
                        this.undoChanges = true;
                        return 'CHANGE';
                    }
                    if (this.selectedEase !== undefined && this.selectedEase.productAttributes !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'CENTURYLINK @ EASE');
                        if ((subOrderItem !== undefined && this.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) || (subOrderItem !== undefined && this.selectedEase.action && this.selectedEase.action === 'REMOVE') || (subOrderItem === undefined)) {
                            this.undoChanges = true;
                            return 'CHANGE';
                        }
                    }
                    else if (this.selectedEase === undefined && this.easeExist) {
                        this.undoChanges = true;
                        return 'CHANGE'
                    }
                    if (this.selectedJack !== undefined && this.selectedJack.productAttributes !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'Jack and Wire');
                        if ((subOrderItem !== undefined && this.selectedJack.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) || (subOrderItem !== undefined && this.selectedJack.action && this.selectedJack.action === 'REMOVE')) {
                            this.undoChanges = true;
                            return 'CHANGE';
                        }
                    }
                    else if (this.selectedJack === undefined && this.jackExist) {
                        this.undoChanges = true;
                        return 'CHANGE'
                    }
                }
                if (type === 'prism' && filter !== undefined) {
                    if ((filter === 'selectedSTB' || filter === 'any-filter') && this.selectedSTB !== null && this.selectedSTB !== undefined && this.selectedSTB.productAttributes[0] !== undefined && this.selectedSTB.productAttributes[0].compositeAttribute[0] !== undefined) {

                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'Prism WSTB Surcharge');

                        if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && this.selectedSTB.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue && this.selectedSTB.productAttributes[0].compositeAttribute[1].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[1].attributeValue) {
                            return 'CHANGE'
                        }
                        else if (subOrderItem === undefined) {
                            return 'CHANGE'
                        }
                    }
                    if ((filter === 'hdService' || filter === 'any-filter') && this.hdService !== null && this.hdService !== undefined && this.hdService.productAttributes[0] !== undefined && this.hdService.productAttributes[0].compositeAttribute[0] !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'HD Service');
                        if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && this.hdService.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
                            return 'CHANGE'
                        }
                        else if (subOrderItem === undefined) {
                            return 'CHANGE'
                        }
                    }
                    if ((filter === 'dvrService' || filter === 'any-filter') && this.dvrService !== null && this.dvrService !== undefined && this.dvrService.productAttributes[0] !== undefined && this.dvrService.productAttributes[0].compositeAttribute[0] !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'DVR Service');
                        if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && this.dvrService.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
                            return 'CHANGE'
                        }
                        else if (subOrderItem === undefined) {
                            return 'CHANGE'
                        }
                    }
                    if ((filter === 'wiredSTB' || filter === 'any-filter') && this.wiredSTB !== null && this.wiredSTB !== undefined && this.wiredSTB.productAttributes[0] !== undefined && this.wiredSTB.productAttributes[0].compositeAttribute[0] !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'Wired Set Top Box');
                        if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && this.wiredSTB.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
                            return 'CHANGE'
                        }
                        else if (subOrderItem === undefined) {
                            return 'CHANGE'
                        }
                    }
                    if ((filter === 'wirelessSTB' || filter === 'any-filter') && this.wirelessSTB !== null && this.wirelessSTB !== undefined && this.wirelessSTB.productAttributes[0] !== undefined && this.wirelessSTB.productAttributes[0].compositeAttribute[0] !== undefined) {
                        subOrderItem = this.offerHelperService.findCustomerSubOrderObject(existingProduct, 'Wireless Set Top Box');
                        if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && this.wirelessSTB.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
                            return 'CHANGE'
                        }
                        else if (subOrderItem === undefined) {
                            return 'CHANGE'
                        }
                    }
                }
                if (type === 'dhp') {
                    if (this.selectedMaintainance !== undefined && this.selectedMaintainance.productAttributes !== undefined && this.wireMaintainance) {
                        this.undoChanges = true;
                        return 'CHANGE'
                    }
                }
            } else if (val === 'CHANGE') {
                return val;
            }
            return 'NOCHANGE';
        }

    }

    public findCustomerSubOrderObjectIndexOf(custObj: CustomerOrderItems, filterBy): Products {
        let val: Products;
        if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
            custObj.customerOrderSubItems.forEach(obj => {
                if (obj.productName.indexOf(filterBy) !== -1) {
                    val = obj;
                }
            });
        }
        return val;
    }
    public potsVoiceMailMandatory: boolean = false;
    public potsWireMainMandatory: boolean = false;
    public potsJacksMandatory: boolean = false;
    public potsPortingMandatory: boolean = false;
    public cartOrderItems: ShoppingCart;
    public cartRequest() {
        let orderItems: Products[] = [];
        let orderItem: CustomerOrderItems = {}
        let orderItemstoSend: CustomerOrderItems[] = [];
        let subOrderItems: Products[] = [];
        let subOrderItemsForCart: Products[] = [];
        let subOrderItemstoSend: Products[] = [];
        let subOrderItem: Products;

        let internetExist = false;
        let prismExist = false;
        let dhpExist = false;
        let hpExist = false;
        let dtvExist = false;

        let internetProduct: CustomerOrderItems = {};
        let prismProduct: CustomerOrderItems = {};
        let dhpProduct: CustomerOrderItems = {};

        let custObj = this.findCustomerOrderObject(this.existingServices, GenericValues.iData, true);

        //Need to compare offeringId from existing & selected offer
        //Check for same offering need to compare modem & other items
        if (this.existingServices !== undefined) {
            this.existingServices.map((item) => {
                if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData)
                    && item.offerType !== 'SUBOFFER') {
                    internetExist = true;
                    internetProduct = item;
                } else if (item.offerCategory === 'VIDEO-PRISM') {
                    prismExist = true;
                    prismProduct = item;
                } else if (item.offerCategory === 'VIDEO-DTV') {
                    dtvExist = true;
                    prismProduct = item;
                } else if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER') {
                    dhpExist = true;
                    dhpProduct = item;
                } else if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER') {
                    hpExist = true;
                    dhpProduct = item;
                }
            });
        }

        if (this.internetCheck) {


            

            let changedAction = false;
            if (this.selectedOffer !== undefined && this.selectedOffer.productOffer !== undefined) {
                subOrderItem = this.offerHelperService.searchforPrimaryCart(this.selectedOffer
                    .productOffer.productComponents, GenericValues.cPrimary, false);
                subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingOnlyOfferingId(internetProduct, this.selectedOffer, 'internet');
                subOrderItems.push(subOrderItem);
                subOrderItemstoSend.push(subOrderItem);
                subOrderItem = this.offerHelperService.searchforPrimaryCart(this.selectedOffer
                    .productOffer.productComponents, GenericValues.cPrimary, true);
                    subOrderItemsForCart.push(subOrderItem);
            }
            let subOrderItemTech: Products;
            if (this.selectedInstallation !== undefined && this.selectedInstallation.productAttributes !== undefined) {
                subOrderItemTech = cloneDeep(this.selectedInstallation);
                subOrderItem = cloneDeep(this.selectedInstallation);
                subOrderItem.productAttributes = [];
                let indx = 0, counter = 0;
                for (let i = 0; i < subOrderItemTech.productAttributes.length; i++) {
                    let attr = subOrderItemTech.productAttributes[i];
                    attr && attr.compositeAttribute && attr.compositeAttribute.map(comp => {
                        if (comp.attributeName !== 'TechInstallRecommended') {
                            subOrderItem.productAttributes.push(attr);
                        }
                    })
                }
                if (this.recommendedTech) subOrderItem.productAttributes.push(this.recommendedTech);
                subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(internetProduct, this.selectedInstallation, 'internet', undefined, GenericValues.install);
                subOrderItems.push(subOrderItem);
                subOrderItemstoSend.push(subOrderItem);
                if(subOrderItem.action === 'CHANGE' || subOrderItem.action === 'ADD') { changedAction = true; }
                if (subOrderItem.action !== 'REMOVE') {
                    subOrderItemsForCart.push(subOrderItem);
                }
            }

            let modemAdded = false;
            if (this.selectedModem === undefined && (this.isModemCompatible)) {
                subOrderItemstoSend.push(this.existingModem);
                if (this.existingModem && this.existingModem.productAttributes) {
                    this.existingModem.productAttributes.forEach(modem => {
                        if (modem.isPriceable && modem.prices && modem.prices.length > 0) {
                            modem.prices.forEach(price => {
                                if (price.priceType === 'PRICE' && (price.discountedRc !== 0 || price.rc !== 0)) {
                                    subOrderItemsForCart.push(this.existingModem);
                                }
                            });
                        }
                    });
                }
                modemAdded = true;
            }
            if (this.selectedModem !== undefined && this.selectedModem.productAttributes !== undefined) {
                subOrderItem = this.selectedModem;
                subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(internetProduct, this.selectedModem, 'internet', undefined, GenericValues.modem);
                if (!this.isModemCompatible) {
                    subOrderItem.action = 'ADD';
                }
                subOrderItems.push(subOrderItem);
                subOrderItemstoSend.push(subOrderItem);
                if(subOrderItem.action === 'CHANGE' || subOrderItem.action === 'ADD') { changedAction = true; }
                if (subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
                    subOrderItemsForCart.push(subOrderItem);
                }
            }
            if (this.selectedEase !== undefined && this.selectedEase.productAttributes !== undefined) {
                subOrderItem = this.selectedEase;
                subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(internetProduct, this.selectedEase, 'internet', undefined, GenericValues.ease);
                subOrderItems.push(subOrderItem);
                subOrderItemstoSend.push(subOrderItem);
                if(subOrderItem.action === 'CHANGE') { changedAction = true; }
                if (subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'VACSUS-ADD') {
                    subOrderItemsForCart.push(subOrderItem);
                }
            }
            if (this.selectedJack !== undefined && (!this.phoneOffer || (this.phoneOffer && this.phoneSelected !== 'HMP'))) {
                subOrderItem = this.selectedJack;
                if (this.selectedJack.productAttributes && this.selectedJack.productAttributes.length > 0) {
                    this.selectedJack.productAttributes.forEach(attr => {
                        attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
                            if (comp.attributeName === 'Installation Number' && comp.attributeValue !== 'No work is needed') {
                                subOrderItem.action = 'ADD';
                                subOrderItems.push(subOrderItem);
                                subOrderItemstoSend.push(subOrderItem);
                                subOrderItemsForCart.push(subOrderItem);
                            }
                        });
                    });
                }
            }
            if(this.vacResCart && this.vacResCart.payload && this.vacResCart.payload.cart && this.vacResCart.payload.cart.customerOrderItems) {
                let custItems = this.vacResCart.payload.cart.customerOrderItems;
                custItems && custItems.forEach(custItem => {
                    if(custItem.action === 'VACRES-ADD' && custItem.offerCategory === GenericValues.iData) {
                        custItem && custItem.customerOrderSubItems && custItem.customerOrderSubItems.map(custSubItem => {
                            if(custSubItem && custSubItem.productName && (custSubItem.productName === GenericValues.secureWifiComponent)) {
                                subOrderItemsForCart.push(custSubItem);
                            }
                        });
                    }
                });
            }
            orderItem = {
                catalogId: this.catalogId,
                productOfferingId: this.selectedOffer === undefined ? '' : this.selectedOffer.productOfferingId,
                productType: GenericValues.sData,
                offerDisplayName: this.selectedOffer === undefined ? '' : this.selectedOffer.productOffer.offerDisplayName,
                quantity: 1,
                rc: this.actualPrice,
                discountedRc: this.selectedOffer && this.selectedOffer.defaultOfferPrice !== null ? this.selectedOffer.defaultOfferPrice.discountedRc : 0,
                customerOrderSubItems: subOrderItemsForCart
            };
            orderItems.push(orderItem);
            if (this.selectedInstallation === undefined && this.techInstallExist) {
                subOrderItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'TECH INSTALL');
                subOrderItem = Object.assign({}, subOrderItem, {
                    action: 'REMOVE'
                });
                subOrderItemstoSend.push(subOrderItem);
            }
            if (this.selectedModem === undefined && this.modemExist && !modemAdded) {
                subOrderItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'MODEM');
                subOrderItem = Object.assign({}, subOrderItem, {
                    action: 'REMOVE'
                });
                subOrderItemstoSend.push(subOrderItem);
            }
            if (this.selectedEase === undefined && this.easeExist) {
                subOrderItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'CENTURYLINK @ EASE');
                subOrderItem = Object.assign({}, subOrderItem, {
                    action: 'REMOVE'
                });
                subOrderItemstoSend.push(subOrderItem);
            }
            if (this.selectedJack === undefined && this.jackExist) {
                subOrderItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'Jack and Wire');
                subOrderItem = Object.assign({}, subOrderItem, {
                    action: 'REMOVE'
                });
                subOrderItemstoSend.push(subOrderItem);
            }

            orderItem = {
                catalogId: this.catalogId,
                productOfferingId: this.selectedOffer === undefined ? '' : this.selectedOffer.productOfferingId,
                offerType: this.selectedOffer === undefined ? '' : this.selectedOffer.productOffer.offerType,
                offerSubType: this.selectedOffer === undefined ? '' : this.selectedOffer.productOffer.offerSubType,
                offerCategory: this.selectedOffer === undefined ? '' : this.selectedOffer.productOffer.offerCategory,
                quantity: 1,
                rc: this.actualPrice,
                discountedRc: this.selectedOffer !== undefined && this.selectedOffer.defaultOfferPrice !== null ? this.selectedOffer.defaultOfferPrice.discountedRc : 0,
                otc: this.actualInternetOtcPrice,
                discountedOtc: this.discountedInternetOtcPrice,
                action: !internetExist ? 'ADD' : changedAction ? 'CHANGE' : this.checkExistingOfferingId(internetProduct, this.selectedOffer, 'internet', undefined),
                contractTerm: this.cartContractTerm ? this.cartContractTerm : '0',
                customerOrderSubItems: subOrderItemstoSend,
                offerName: this.selectedOffer === undefined ? '' : this.selectedOffer.productOffer.offerName
            };
            orderItemstoSend.push(orderItem);
            if (this.isRemoved || this.isDHPRemoved || this.isHPRemoved || this.isOptedOut) {
                this.serviceTerminate();
                this.removedProductItem.forEach(item => {
                    orderItemstoSend.push(item);
                });
            }

        }//internet Check close

        if (this.videoOffer) {
            subOrderItems = [];
            if (this.selectedTVOffer !== undefined && this.selectedTVOffer.productOffer !== undefined) {
                subOrderItem = this.offerHelperService.searchforPrimaryCart(this.selectedTVOffer
                    .productOffer.productComponents, GenericValues.cPrimary);
                if (this.videoSelected === 'PTV') {
                    subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOnlyOfferingId(prismProduct, this.selectedTVOffer, 'prism');
                }
                else {
                    subOrderItem.action = !dtvExist ? 'ADD' : this.checkExistingOnlyOfferingId(prismProduct, this.selectedTVOffer, 'dtv');
                }
                subOrderItems.push(subOrderItem);
            }
            if (this.selectedSTB !== null && this.selectedSTB !== undefined) {
                subOrderItem = this.selectedSTB;
                subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(prismProduct, this.selectedTVOffer, 'prism', 'selectedSTB');
                subOrderItems.push(subOrderItem);
            }
            if (this.hdService !== null && this.hdService !== undefined) {
                subOrderItem = this.hdService;
                subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(prismProduct, this.selectedTVOffer, 'prism', 'hdService');
                subOrderItems.push(subOrderItem);
            }
            if (this.dvrService !== null && this.dvrService !== undefined) {
                subOrderItem = this.dvrService;
                subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(prismProduct, this.selectedTVOffer, 'prism', 'dvrService');
                subOrderItems.push(subOrderItem);
            }
            if (this.wiredSTB !== null && this.wiredSTB !== undefined) {
                subOrderItem = this.wiredSTB;
                subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(prismProduct, this.selectedTVOffer, 'prism', 'wiredSTB');
                subOrderItems.push(subOrderItem);
            }
            if (this.wirelessSTB !== null && this.wirelessSTB !== undefined) {
                subOrderItem = this.wirelessSTB;
                subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(prismProduct, this.selectedTVOffer, 'prism', 'wirelessSTB');
                subOrderItems.push(subOrderItem);
            }
            orderItem = {
                catalogId:  this.dtvCatalogId,
                productOfferingId: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOfferingId,
                productType: GenericValues.cVideo,
                quantity: 1,
               rc: this.actualTVPrice,
                discountedRc: this.discountedTVPrice,
                customerOrderSubItems: subOrderItems,
                offerName: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOffer.offerName
            };
            orderItems.push(orderItem);
            orderItem = {
                catalogId:  this.dtvCatalogId,
                productOfferingId: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOfferingId,
                offerType: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOffer.offerType,
                offerSubType: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOffer.offerSubType,
                offerCategory: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOffer.offerCategory,
                quantity: 1,
                rc: this.actualTVPrice,
                discountedRc: this.discountedTVPrice,
                otc: this.actualTVOtcPrice,
                discountedOtc: this.discountedTVOtcPrice,
                action: !dtvExist ? 'ADD' : 'NOCHANGE',
                customerOrderSubItems: subOrderItems,
                contractTerm: this.cartContractTermDTV ? this.cartContractTermDTV : '0',
                offerName: this.selectedTVOffer === undefined ? '' : this.selectedTVOffer.productOffer.offerName
            };
            orderItemstoSend.push(orderItem);
        }
        if (this.phoneOffer) {
            subOrderItems = [];
            if (this.selectedDHPOffer !== undefined && this.selectedDHPOffer.productOffer !== undefined) {
                subOrderItem = this.offerHelperService.searchforPrimaryCart(this.selectedDHPOffer
                    .productOffer.productComponents, GenericValues.cPrimary);
                subOrderItems.push(subOrderItem);
                let vmAction = this.checkExistingOnlyOfferingId(dhpProduct, this.selectedDHPOffer, 'dhp');
                if (this.voiceMail && this.selectedVoiceMail !== undefined) {
                    subOrderItem = this.selectedVoiceMail;
                    subOrderItem.action = !this.voiceMailCondi ? 'ADD' : 'NOCHANGE';
                    subOrderItem.dontShow = false;
                    if (vmAction === 'CHANGE') subOrderItem.action = vmAction;
                    subOrderItems.push(subOrderItem);
                    this.potsVoiceMailMandatory = false;
                }
                if (this.wireMaintainance && this.selectedMaintainance !== undefined) {
                    subOrderItem = this.selectedMaintainance;
                    subOrderItem.action = !this.wireMaintainCondi ? 'ADD' : 'NOCHANGE';
                    subOrderItems.push(subOrderItem);
                    this.potsWireMainMandatory = false;
                }

                if (this.selectedJackForPots !== undefined) {
                    subOrderItem = this.selectedJackForPots;
                    if (this.selectedJackForPots.productAttributes && this.selectedJackForPots.productAttributes.length > 0) {
                        this.selectedJackForPots.productAttributes.forEach(attr => {
                            attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
                                if (comp.attributeName === 'Installation Number' && comp.attributeValue !== 'No work is needed') {
                                    subOrderItem.action = 'ADD';
                                    subOrderItems.push(subOrderItem);
                                }
                            });
                        });
                        this.potsJacksMandatory = false;
                    }
                }

                this.selectedDHPOffer
                    .productOffer.productComponents.forEach(products => {
                        if (products.componentType !== GenericValues.cPrimary && products.product.productName !== 'Digital Home Phone Intl Call') {
                            if (products && products.isDefault === 0 && products.isMandatory) {
                                subOrderItem = this.getDHPComponents(products);
                                subOrderItem.dontShow = true;
                                subOrderItems.push(subOrderItem);
                            } else if (this.voiceMail && this.selectedVoiceMail !== undefined && products.product.productName === 'Easy Access') {
                                subOrderItem = this.getDHPComponents(products);
                                subOrderItem.action = !this.voiceMailCondi ? 'ADD' : 'NOCHANGE';
                                subOrderItem.dontShow = false;
                                if (vmAction === 'CHANGE') subOrderItem.action = vmAction;
                                if (vmAction === 'NOCHANGE') subOrderItem.dontShow = true;
                                subOrderItems.push(subOrderItem);
                            }
                        }
                    });
            }

            orderItem = {
                catalogId: this.catalogPhoneId,
                productOfferingId: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOfferingId,
                productType: this.phoneSelected === 'DHP' ? GenericValues.cDHP : GenericValues.cHP,
                offerCategory: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerCategory,
                offerDisplayName: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerDisplayName,
                productDisplayName: this.selectedDHPOffer !== undefined ? this.selectedDHPOffer.productOffer.offerDisplayName : '',
                quantity: 1,
                rc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.rc : 0,
                discountedRc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
                otc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.otc : 0,
                discountedOtc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
                customerOrderSubItems: subOrderItems,
                offerName: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerName
            };
            orderItems.push(orderItem);
        }
        let addons: any[] = [];
        if(this.vacReconnectOffer) {
            addons.push(this.vacReconnectOffer);
        }

        let payload: Payload = {
            success: true,
            cart: {
                catalogSpecId: this.catalogSpecId,
                customerOrderItems: orderItems
            },
            customerAddonOfferItems: addons,
            productConfiguration: this.configSelected
        };
        if (this.reEntrant && !this.changeAfterReEntrant) {
            let addons: CustomerOrderItems[] = [];
            let discountsAdded = [];
            let cart = <Observable<ShoppingCart>>this.store.select('cart');
            let cartSubscription = cart.subscribe((data) => {
                data && data.payload && data.payload.customerAddonOfferItems && data.payload.customerAddonOfferItems.map(cartItem => {
                    if (((cartItem.offerCategory === GenericValues.cHP || cartItem.offerCategory === 'WIRINGWORKS') && this.phoneSelected === 'HMP') ||
                        (cartItem.offerCategory === GenericValues.cDHP && this.phoneSelected === 'DHP') ||
                        ((cartItem.offerCategory === GenericValues.iData || cartItem.offerCategory === GenericValues.sData || cartItem.offerCategory === 'WIRINGWORKS') && this.internetCheck)) {
                        addons.push(cartItem);
                    }
                })
                discountsAdded = data.payload.discountItems;
            });
            if(this.vacReconnectOffer) {
                addons.push(this.vacReconnectOffer);
            }
            payload = {
                success: true,
                cart: {
                    catalogSpecId: this.catalogSpecId,
                    customerOrderItems: orderItems
                },
                customerAddonOfferItems: addons,
                productConfiguration: this.configSelected,
                discountItems: discountsAdded
            };
            if (cartSubscription !== undefined)
                cartSubscription.unsubscribe();
        }

        this.cartObject = {
            success: this.offerResponse.success,
            orderRefNumber: this.offerResponse.orderRefNumber,
            processInstanceId: this.offerResponse.processInstanceId,
            taskId: this.offerResponse.taskId,
            taskName: this.offerResponse.taskName,
            payload: payload
        };
        this.cartOrderItems = cloneDeep(this.cartObject);
        this.store.dispatch({ type: 'CREATE_CART', payload: this.cartObject });
        if (this.retentionDiscountsToCart && this.retentionDiscountsToCart.length > 0) {
            this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.retentionDiscountsToCart });
        }



        payload = {
            cart: {
                catalogSpecId: this.catalogSpecId || null,
                customerOrderItems: orderItemstoSend
            },
            productConfiguration: this.configSelected
        };
        if (this.isRemoved && this.serviceTerminationInfo !== undefined) {
            payload = Object.assign({},
                payload, {
                    servicesTerminationInfo: this.serviceTerminationInfo
                }
            );
        }
        if (this.isDHPRemoved && this.serviceTerminationInfo !== undefined) {
            payload = Object.assign({},
                payload, {
                    servicesTerminationInfo: this.serviceTerminationInfo
                }
            );
        }


        if (this.phoneOffer) {
            subOrderItems = [];
            if (this.selectedDHPOffer !== undefined && this.selectedDHPOffer.productOffer !== undefined) {
                subOrderItem = this.offerHelperService.searchforPrimaryCart(this.selectedDHPOffer
                    .productOffer.productComponents, GenericValues.cPrimary);
                subOrderItems.push(subOrderItem);

                subOrderItem.action = (this.phoneSelected === 'DHP' && !dhpExist) || (this.phoneSelected === 'HMP' && !hpExist) ? 'ADD' : this.checkExistingOnlyOfferingId(dhpProduct, this.selectedDHPOffer, 'dhp');

                this.selectedDHPOffer
                    .productOffer.productComponents.forEach(products => {
                        if (products.componentType !== GenericValues.cPrimary && products.product.productName !== 'Digital Home Phone Intl Call') {
                            if (((products.product.productName.indexOf('Voice Messaging') !== -1 || (products.product.productName.indexOf('Easy Access') !== -1))
                                && this.voiceMail)) {
                                subOrderItem = this.getDHPComponents(products);
                               if (this.voiceMailCondi) { subOrderItem.action = 'NOCHANGE' } else { subOrderItem.action = 'ADD'; }
                                subOrderItems.push(subOrderItem);
                            }
                            if ((products.product.productName.indexOf('Wire Maintenance Plan') !== -1 && this.wireMaintainance)) {
                                subOrderItem = this.getDHPComponents(products);
                                if (this.wireMaintainCondi) { subOrderItem.action = 'NOCHANGE' } else { subOrderItem.action = 'ADD'; }
                                subOrderItems.push(subOrderItem);
                            }
                            if (products.product.productName.indexOf('Jack and Wire') !== -1 && this.selectedJackForPots) {
                                subOrderItem = this.selectedJackForPots;
                                if (this.selectedJackForPots.productAttributes && this.selectedJackForPots.productAttributes.length > 0) {
                                    this.selectedJackForPots.productAttributes.forEach(attr => {
                                        attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
                                            if (comp.attributeName === 'Installation Number' && comp.attributeValue !== 'No work is needed') {
                                                subOrderItem.action = 'ADD';
                                                subOrderItems.push(subOrderItem);
                                            }
                                        });
                                    });
                                }
                            }
                            if (products.product.productName.indexOf('Wire Maintenance Plan') === -1 &&
                                products.product.productName.indexOf('Voice Messaging') === -1 && products.product.productName.indexOf('Jack and Wire') === -1
                                && products.product.productName.indexOf('Easy Access') === -1) {
                                subOrderItem = this.getDHPComponents(products);
                                subOrderItems.push(subOrderItem);
                            }
                        }
                    });
                if (this.phoneSelected === 'DHP') {
                    let flgSelected: boolean = false;
                    let attributes: AttributesCombination[] = [];
                    if (this.internationalDialing !== undefined) {
                        this.internationalDialing.product.productAttributes.forEach(attr => {
                            if ((attr && attr.compositeAttribute !== null && attr.compositeAttribute.length === 0)) {
                                attributes.push(attr);
                            }
                            if ((attr && attr.compositeAttribute !== null && attr.compositeAttribute && attr.compositeAttribute.length !== 0
                                && attr.compositeAttribute[0].attributeName !== 'Service Status')) {
                                attributes.push(attr);
                            }
                            if ((attr && attr.compositeAttribute !== null && attr.compositeAttribute && attr.compositeAttribute.length !== 0
                                && attr.compositeAttribute[0].attributeName === 'Service Status')) {
                                if (this.dhpExisting && !this.dhpIntlCalled) {
                                    let dhp = this.getExistingProducts(this.existingServices, GenericValues.cDHP);
                                    if (dhp && dhp.customerOrderSubItems !== null && dhp.customerOrderSubItems
                                        && dhp.customerOrderSubItems.length !== 0) {
                                        dhp.customerOrderSubItems.forEach(subItems => {
                                            if (subItems && subItems.productName === 'Digital Home Phone Intl Call') {
                                                subItems.productAttributes.forEach(subAttr => {
                                                    if ((subAttr && subAttr.compositeAttribute !== null && subAttr.compositeAttribute.length !== 0
                                                        && subAttr.compositeAttribute[0].attributeName === 'Service Status')) {
                                                        attributes.push(subAttr);
                                                        subAttr.compositeAttribute[0].attributeValue === 'Enabled'
                                                            || subAttr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes' ? this.dhpIntlSelected = 'Yes' :
                                                            this.dhpIntlSelected = 'No';
                                                        this.dhpIntlExisting = cloneDeep(this.dhpIntlSelected);
                                                    }
                                                });
                                            }
                                        });
                                    }
                                } else {
                                    if (!flgSelected && this.isInternational && attr.compositeAttribute[0]
                                        && (attr.compositeAttribute[0].attributeValue === 'Enabled' ||
                                            attr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes')) {
                                        attributes.push(attr);
                                        flgSelected = true;
                                    } else if (!flgSelected && !this.isInternational && attr.compositeAttribute[0]
                                        && (attr.compositeAttribute[0].attributeValue === 'Disabled' ||
                                            attr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'no')) {
                                        attributes.push(attr);
                                        flgSelected = true;
                                    }
                                }
                            }
                        })
                        let product = this.internationalDialing.product;
                        product = {
                            productId: product.productId,
                            productName: product.productName,
                            productType: product.productType,
                            componentType: this.internationalDialing.componentType,
                            productAttributes: attributes,
                            productAssociations: product.productAssociations,
                            productCategory: product.productCategory,
                            quantity: 1,
                            action: !this.dhpExisting ? 'ADD' : this.dhpIntlExisting === this.dhpIntlSelected ? 'NOCHANGE' : 'CHANGE'
                        }
                        subOrderItems.push(product);
                    }
                }

            }
            let actn = this.checkExistingOfferingId(dhpProduct, this.selectedDHPOffer, 'dhp', 'any-filter');
            if (actn !== 'CHANGE' && dhpExist) {
                actn = this.dhpIntlExisting === this.dhpIntlSelected ? 'NOCHANGE' : 'CHANGE'
            }
            orderItem = {
                catalogId: this.catalogPhoneId,
                productOfferingId: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOfferingId,
                offerType: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerType,
                offerSubType: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerSubType,
                offerCategory: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerCategory,
                quantity: 1,
                rc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.rc : 0,
                discountedRc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
                otc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.otc : 0,
                discountedOtc: this.selectedDHPOffer !== undefined && this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
                customerOrderSubItems: subOrderItems,
                action: (!dhpExist && this.phoneSelected === 'DHP') || (!hpExist && this.phoneSelected === 'HMP') ? 'ADD' : actn,
                contractTerm: this.cartContractTermDHP ? this.cartContractTermDHP : '0',
                offerName: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerName
            };
            orderItemstoSend.push(orderItem);

            if (this.isDHPRemoved && ((this.removedProductItem[0].offerCategory === GenericValues.cDHP && this.phoneSelected === 'HMP') || (this.removedProductItem[0].offerCategory === GenericValues.cHP && this.phoneSelected === 'DHP'))) {
                orderItem.action = 'ADD';
            }

            let e911 = {};
            let dhpAdditionalInfo = {};
            if (this.phoneSelected === 'DHP' && this.e911ValidatedAddress) {
                e911 = {
                    "streetDirectionPrefix": this.e911ValidatedAddress.streetDirectionPrefix,
                    "streetAddress": this.e911ValidatedAddress.streetAddress,
                    "location": this.e911ValidatedAddress.location,
                    "streetNrFirst": this.e911ValidatedAddress.streetNrFirst,
                    "city": this.e911ValidatedAddress.city,
                    "stateOrProvince": this.e911ValidatedAddress.stateOrProvince,
                    "postCode": this.e911ValidatedAddress.postCode,
                    "postCodeSuffix": this.e911ValidatedAddress.postCodeSuffix
                }
                dhpAdditionalInfo = {
                    e911Address: e911,
                    dhpDisclaimerAcceptDateTime: this.e911ValidatedAddress.acceptedData
                }
            }
            payload = {
                dhpAdditionalInfo: dhpAdditionalInfo,
                cart: {
                    catalogSpecId: this.catalogSpecId,
                    customerOrderItems: orderItemstoSend
                },
                productConfiguration: this.configSelected
            };

            if (this.isInternetRemoved) {
                this.serviceTerminate();
                this.removedProductItem.forEach(item => {
                    orderItemstoSend.push(item);
                });
            }

            if (this.isOptedOut) {
                this.serviceTerminate();
                this.removedProductItem.forEach(item => {
                    orderItemstoSend.push(item);
                });
            }
        }

        if ((this.isInternetRemoved && this.serviceTerminationInfo !== undefined) || (this.isOptedOut && this.serviceTerminationInfo !== undefined)) {
            payload = Object.assign({},
                payload, {
                    servicesTerminationInfo: this.serviceTerminationInfo
                }
            );
        }

        this.cartObject = {
            success: this.offerResponse.success || true,
            orderRefNumber: this.offerResponse.orderRefNumber || this.orderRefNumber,
            processInstanceId: this.offerResponse.processInstanceId || this.processInstanceId,
            taskId: this.offerResponse.taskId || this.taskId,
            taskName: 'Get Addon Offers',
            payload: payload
        };
    }

    public serviceTerminate() {
        this.store.dispatch({ type: 'REMOVAL_REASON', payload: this.removeSelectedReason });
        for (let i = 0; i < this.removedProductItem.length; i++) {
            let addRemoveToAllSubItems = this.removedProductItem[i].customerOrderSubItems.map(item => {
                if (item && item.action) item.action = 'REMOVE'
                return item;
            });
            this.undoChanges = true;
            this.removedProductItem[i].customerOrderSubItems = addRemoveToAllSubItems;
        }
        if (this.removedProductItem && this.removedProductItem[0] && this.removedProductItem[0].offerCategory) {
            this.serviceTerminationInfo = [{
                "serviceCategory": null,
                "offerCategory": this.removedProductItem[0].offerCategory,
                "product": null,
                "reasonList": {
                    "reasonType": this.removeSelectedReason && this.removeSelectedReason.rsnType,
                    "reason": [
                        {
                            "code": this.removeSelectedReason && this.removeSelectedReason.rsnCode,
                            "description": this.removeSelectedReason && this.removeSelectedReason.chgDesc,
                            "waiverFlag": "No",
                            "reasonType": this.removeSelectedReason && this.removeSelectedReason.rsnType,
                            "reasonText": null,
                            "offerCategory": this.removedProductItem[0].offerCategory,
                            "terminationFee": "0",
                            "currencyCode": "USD"
                        }
                    ]
                }
            }]
        }
    }

    public getDHPComponents(products: OfferProductComponents) {
        let product: Products = {};
        products.product = Object.assign({},
            products.product, {
                componentType: products.componentType
            }
        );
        product = products.product;
        product = {
            productId: product.productId,
            productName: product.productName,
            productType: product.productType,
            componentType: product.componentType,
            productAttributes: product.productAttributes,
            productAssociations: product.productAssociations,
            productCategory: product.productCategory,
            quantity: 1,
            action: (this.phoneSelected === 'HMP' && !this.hpExisting) || (!this.dhpExisting && this.phoneSelected === 'DHP') ? 'ADD' : this.checkPOTSAction(product.productName)
        }
        return product;
    }

    public getExistingProducts(custObj, filterBy): any {
        let val: any;
        if (custObj !== undefined) {
            custObj.map(obj => {
                if (obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER') {
                    val = obj;
                }
            })
        }
        return val;
    }

    public checkPOTSAction(product) {
        if (product.indexOf('Wire Maintenance Plan') !== -1 && this.wireMaintainance) {
            if (this.wireMaintainCondi) { return 'NOCHANGE' } else return 'ADD';
        }
        return 'NOCHANGE';
    }

    public removeTV() {
        this.videoSelected = 'NoTV';
        this.newVideoSelected = 'NoTV';
        this.retrieveOffers(false);
    }

    public removePhone() {
        this.phoneSelected = 'NoPhone';
        this.newPhoneSelected = 'NoPhone';
        this.retrieveOffers(false);
    }

    /**
     * 
     * @param data (OfferList)
     * @param filterBySpeed (Selected Speed/TV)
     * @param category (DATA/VIDEO)
     * @param type (PRIMARY)
     */
    public offerFilter(data: ProductOfferings[], filterBySpeed: string,
        category: string, type: string): OfferGroup[] {
        let matchingOffersArray: OfferGroup[] = [];
        if (this.videoOffer) {
            matchingOffersArray = this.getMatchingOffers(this.videoSelected, data, filterBySpeed,
                matchingOffersArray, category, type);
       } else if (this.phoneOffer) {
            matchingOffersArray = this.getMatchingOffers(this.phoneSelected, data, filterBySpeed,
                matchingOffersArray, category, type);
        } else {
            matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
                matchingOffersArray, GenericValues.iData, category, type, true);
        }

        return matchingOffersArray;
    }
    public getMatchingOffers(selectedItem, data: ProductOfferings[], filterBySpeed: string, matchingOffersArray,
        category: string, type: string) {
        switch (selectedItem) {
            case 'DHP':
                matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
                    matchingOffersArray, GenericValues.cDHP, category, type);
                break;
            case 'HMP':
                matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
                    matchingOffersArray, GenericValues.cHP, category, type);
                break;
            case 'DTV':
                matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
                    matchingOffersArray, GenericValues.cDTV, category, type);
                break;
            case 'PTV':
                matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
                    matchingOffersArray, GenericValues.cDATVID, category, type);
                break;
        }
        return matchingOffersArray;
    }
    public makeDefault() {
        let defaultProdOffer: ProductOfferings;
        let defaultProd: Products;
        let defaultOfferProd: OfferProductComponents;
        let defaultCustOrder: CustomerOrderSubItem;
        this.selectedTVOffer = defaultProdOffer;
        this.selectedOffer = defaultProdOffer;
        this.modemValues = defaultOfferProd;
        this.selectedModem = defaultCustOrder;
        this.easeValues = defaultOfferProd;
        this.jackValues = defaultOfferProd;
        this.selectedEase = defaultCustOrder;
        this.installationValues = defaultOfferProd;
        this.selectedInstallation = defaultCustOrder;
        this.tvList = [];
        this.dvrPrice = 0;
        this.hdPrice = 0;
        this.hdService = defaultProd;
        this.dvrService = defaultProd;
        this.discountedPrice = 0;
        this.actualPrice = 0;
        this.cartRequest();
    }

    /**
     * getInternetDefault method
     * @params: filterBySpeed = selectSpeed/tvPackage, filterByCategory = DATA,DATA/VIDEO
     * category = DATA/VIDEO-PRISM, type = PRIMARY
     */
    public getInternetDefault(data: ProductOfferings[], filterBySpeed: string,
        matchingOffersArray: OfferGroup[], filterByCategory: string,
        category: string, type: string, isDATA?) {
        let defaultCheck: boolean = false;
        let flag: boolean = false;
        matchingOffersArray = [];
        data && (data.length > 0) && data
            .map((item) => {
                let offerEnable: boolean = false;
               if (item.productOffer.offerAttributes !== null && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length !== 0) {
                    item.productOffer.offerAttributes.forEach(attr => {
                        if (attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'yes') {
                            if (!offerEnable) {
                                item.productOffer.offerAttributes.forEach(checkAttr => {
                                    if (this.phoneSelected === 'NoPhone' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'no') {
                                        offerEnable = true;
                                    } else if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                                        offerEnable = true;
                                    } else if ((this.phoneSelected === 'DHP' || this.videoSelected !== 'NoTV') && (checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'no')) {
                                        offerEnable = true;
                                    }
                                });
                            }
                        }
                    });
                }
                if (this.offerHelperService.searchforPrimary(item.productOffer.productComponents,
                    GenericValues.cPrimary).productName === filterBySpeed && offerEnable) {
                    let group: OfferGroup;
                    let offerItem: OfferItems;
                    let offerItems: OfferItems[] = [];
                    let price: Prices = {
                        discountedOtc: item.defaultOfferPrice.discountedOtc,
                        discountedRc: item.defaultOfferPrice.discountedRc,
                        otc: item.defaultOfferPrice.otc,
                        rc: item.defaultOfferPrice.rc
                    }
                    offerItem = {
                        productOfferingId: item.productOfferingId,
                        offerName: item.productOffer.offerName,
                        offerDisplayName: item.productOffer.offerDisplayName,
                        offerBillingType: item.productOffer.offerBillingType,
                        offerCategory: item.productOffer.offerCategory
                    }
                    offerItems.push(offerItem);
                    let associatedOffers: AssociatedOffers[] = [];
                    if ((category === GenericValues.sData || category === GenericValues.iData) && this.phoneSelected !== 'NoPhone') {
                        if (this.phoneSelected === 'HMP' && item.productOffer.associatedOffers !== null && item.productOffer.associatedOffers !== undefined
                            && item.productOffer.associatedOffers.length > 0) {
                            associatedOffers = item.productOffer.associatedOffers;
                            associatedOffers.forEach(associated => {
                                if (associated && associated.associatedOfferCategory === GenericValues.cHP && associated.associationType.associationType === GenericValues.bundle) {
                                    associated.associationType && associated.associationType.associatedOfferIds.forEach(assocId => {
                                        // DHP
                                        offerEnable = false;
                                        this.phoneOfferData.forEach(items => {
                                            if (assocId.associatedOfferId === items.productOfferingId) {
                                                ({ offerEnable, defaultCheck } = this.hsiWithVoice(items, offerEnable, offerItem, item, matchingOffersArray, defaultCheck));
                                            }
                                        });
                                    });
                                }
                            });
                        } else {
                            offerEnable = false;
                            this.phoneOfferData.forEach(items => {
                                ({ offerEnable, defaultCheck } = this.hsiWithVoice(items, offerEnable, offerItem, item, matchingOffersArray, defaultCheck));
                            });
                        }

                    } else if ((category === GenericValues.sData || category === GenericValues.iData) && this.videoSelected !== 'NoTV' && this.videoSelected === 'PTV') {
                        if (item.productOffer.associatedOffers !== null && item.productOffer.associatedOffers !== undefined
                            && item.productOffer.associatedOffers.length > 0) {
                            associatedOffers = item.productOffer.associatedOffers;
                            associatedOffers.forEach(items => {
                                if (items.associatedOfferCategory === GenericValues.cVideo) {
                                    items.associationType.associatedOfferIds.forEach(assocId => {
                                        flag = false;
                                        this.videorOffer.forEach(vidOffer => {
                                            if (!flag && vidOffer.productOfferingId === assocId.associatedOfferId) {
                                                flag = true;
                                                let packages: Products = this.offerHelperService.searchforPrimary(vidOffer.productOffer.productComponents,
                                                    GenericValues.cPrimary);
                                                if (this.tvList.indexOf(packages.productName) === -1) {
                                                    // Adding Unique package to the list by filtering from OfferList
                                                    this.tvList.push(packages.productName);
                                                }
                                                let offerItemsVid: OfferItems[] = [];
                                                offerItemsVid.push(offerItem);
                                                let offerItem1: OfferItems = {
                                                    productOfferingId: assocId.associatedOfferId,
                                                    offerName: item.productOffer.offerName,
                                                    offerDisplayName: item.productOffer.offerDisplayName + ' ' + vidOffer.productOffer.offerDisplayName,
                                                    offerCategory: vidOffer.productOffer.offerCategory
                                                }
                                                offerItemsVid.push(offerItem1);
                                                offerItems.push(offerItem);
                                                let priceToAdd: Prices = {
                                                    discountedOtc: item.defaultOfferPrice.discountedOtc + vidOffer.defaultOfferPrice.discountedOtc,
                                                    discountedRc: item.defaultOfferPrice.discountedRc + vidOffer.defaultOfferPrice.discountedRc,
                                                    otc: item.defaultOfferPrice.otc + vidOffer.defaultOfferPrice.otc,
                                                    rc: item.defaultOfferPrice.rc + vidOffer.defaultOfferPrice.rc
                                                }
                                                let group1: OfferGroup;
                                                group1 = {
                                                    offerItems: offerItemsVid,
                                                    prices: [priceToAdd]
                                                }
                                                matchingOffersArray.push(group1);
                                                if (!defaultCheck && this.offerBillingType 
                                                    && group1.offerItems[0].offerBillingType === this.offerBillingType) {
                                                    defaultCheck = true;
                                                    this.selectedBundle(group1);
                                                }
                                            }
                                        });
                                    });
                                }
                            });
                        }
                    } else if ((category === GenericValues.sData || category === GenericValues.iData) && this.videoSelected !== 'NoTV' && this.videoSelected === 'DTV') {
                        this.videorOffer && this.videorOffer.forEach(dtv => {
                            let offerItemsPhone: OfferItems[] = [];
                            offerItemsPhone.push(offerItem);
                            let offerItem1: OfferItems = {
                                productOfferingId: dtv.productOfferingId,
                                offerName: item.productOffer.offerName,
                                offerDisplayName: item.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
                                offerCategory: dtv.productOffer.offerCategory
                            }
                            offerItemsPhone.push(offerItem1);
                            let phonediscountedOtc = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.discountedOtc : 0;
                            let phonediscountedRc = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.discountedRc : 0;
                            let phoneOtcPrice = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.otc : 0;
                            let phoneRcPrice = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.rc : 0;
                            let priceToAdd: Prices = {
                                discountedOtc: item.defaultOfferPrice.discountedOtc + phonediscountedOtc,
                                discountedRc: item.defaultOfferPrice.discountedRc + phonediscountedRc,
                                otc: item.defaultOfferPrice.otc + phoneOtcPrice,
                                rc: item.defaultOfferPrice.rc + phoneRcPrice
                            }
                            let group1: OfferGroup;
                            group1 = {
                                offerItems: offerItemsPhone,
                                prices: [priceToAdd]
                            }
                            matchingOffersArray.push(group1);
                        });
                    } else {
                        offerItems.push(offerItem);
                        group = {
                            offerItems: offerItems,
                            prices: [price]
                        }
                        matchingOffersArray.push(group);
                        if (!defaultCheck && this.offerBillingType 
                            && group.offerItems[0].offerBillingType === this.offerBillingType) {
                            defaultCheck = true;
                            this.selectedBundle(group);
                        }
                    }
                }
            });
        if (!defaultCheck) {
            if (this.offerName === null) {
                this.offerName = matchingOffersArray && matchingOffersArray[0] && matchingOffersArray[0].offerItems[0].offerDisplayName;
            } else {
                let index: any;
                matchingOffersArray && (matchingOffersArray.length > 0) && matchingOffersArray.map((off) => {
                    index = off.offerItems.findIndex(a => a.offerDisplayName === this.offerName)
                })
                if (index === -1) {
                    this.offerName = matchingOffersArray[0].offerItems[0].offerDisplayName
                }
            }
            let isOfferAvail = false;
            matchingOffersArray && (matchingOffersArray.length > 0) && matchingOffersArray.map((offer) => {
                if (offer.offerItems[0].offerDisplayName === this.offerName) {
                    this.selectedBundle(offer);
                    isOfferAvail = true;
                }
            })
            if (!isOfferAvail) this.selectedBundle(matchingOffersArray[0]);
        }
        return matchingOffersArray;
    }

    private hsiWithVoice(items: ProductOfferings, offerEnable: boolean, offerItem: OfferItems, item: ProductOfferings, matchingOffersArray: OfferGroup[], defaultCheck: boolean) {
        if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
            items.productOffer.offerAttributes.forEach(attr => {
                if (this.phoneSelected === 'HMP' && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'yes') {
                    items.productOffer.offerAttributes.forEach(checkAttr => {
                        if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                            offerEnable = true;
                        }
                    });
                }
                else if (this.phoneSelected === 'DHP') {
                    offerEnable = true;
                }
            });
        }
        if (offerEnable) {
            let offerItemsPhone: OfferItems[] = [];
            offerItemsPhone.push(offerItem);
            let offerItem1: OfferItems = {
                productOfferingId: items.productOfferingId,
                offerName: items.productOffer.offerName,
                offerDisplayName: this.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName : item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName,
                offerBillingType: item.productOffer.offerBillingType,
                offerCategory: items.productOffer.offerCategory
            };
            offerItemsPhone.push(offerItem1);
            let group1: OfferGroup;
            if (this.videoOffer) {
                this.videorOffer.forEach(dtv => {
                    let offerItem1: OfferItems = {
                        productOfferingId: dtv.productOfferingId,
                        offerName: this.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName : item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
                        offerDisplayName: this.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName : item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
                        offerCategory: dtv.productOffer.offerCategory
                    }
                    offerItemsPhone.push(offerItem1);
                    let phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
                    let phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
                    let phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
                    let phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
                    let priceToAdd: Prices = {
                        discountedOtc: item.defaultOfferPrice.discountedOtc + phonediscountedOtc,
                        discountedRc: item.defaultOfferPrice.discountedRc + phonediscountedRc,
                        otc: item.defaultOfferPrice.otc + phoneOtcPrice,
                        rc: item.defaultOfferPrice.rc + phoneRcPrice
                    };

                    group1 = {
                        offerItems: offerItemsPhone,
                        prices: [priceToAdd]
                    };
                    matchingOffersArray.push(group1);
                });
            }
            else {
                let phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
                let phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
                let phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
                let phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
                let priceToAdd: Prices = {
                    discountedOtc: item.defaultOfferPrice.discountedOtc + phonediscountedOtc,
                    discountedRc: item.defaultOfferPrice.discountedRc + phonediscountedRc,
                    otc: item.defaultOfferPrice.otc + phoneOtcPrice,
                    rc: item.defaultOfferPrice.rc + phoneRcPrice
                };
                group1 = {
                    offerItems: offerItemsPhone,
                    prices: [priceToAdd]
                };
                matchingOffersArray.push(group1);
            }
            if (!defaultCheck && this.offerBillingType 
                && group1.offerItems[0].offerBillingType === this.offerBillingType) {
                defaultCheck = true;
                this.selectedBundle(group1);
            }
        }
        return { offerEnable, defaultCheck };
    }

    public availSpeedChecked(getSpeed: string, flag?: string) {
        if (!this.isReEntrant && !this.oneTimeLoading) {
            this.EaseDefault = true;
            this.JacksWireDefault = true;
        }
        if (getSpeed !== this.selectedSpeed && (this.offerNoLongerAvailable === '' || flag !== 'true')) {
            this.undoFlag = true;
        }
        this.matchingOffers = [];
        this.selectedSpeed = getSpeed;
        this.matchingOffers = this.offerFilter(this.internerOffer, getSpeed, GenericValues.iData, GenericValues.cPrimary);
        if (this.matchingOffers !== undefined && this.matchingOffers.length === 0) {
            this.makeDefault();
            if (this.videoSelected !== 'NoTV') {
                this.errorMsg += this.videoSelected === ' -PTV' ? 'PRISM' : ' -DIRECTV';
                this.errorMsg += ' Not Avail for Selected Speed'
                window.scroll(0, 0);
            }
        }
    }

    public selectedBundle(group: OfferGroup) {
        this.offerName = group && group.offerItems && group.offerItems[0] && group.offerItems[0].offerDisplayName;
        this.selectedVideoOfferPrice = undefined;
        this.selectedGroup = group;
        if (this.internetCheck) this.selectedInternetOfferdId = this.offerHelperService.getBundledOfferId(group, GenericValues.iData, true);
        if (this.videoSelected !== 'NoTV') {
            let dataVal = this.getBundledOfferIdandPrice(this.videoSelected, group);
            this.selectedVideoOfferdId = dataVal.id;
            this.selectedVideoOfferPrice = dataVal.price;
        }
        if (this.phoneSelected !== 'NoPhone') {
            let dataVal = this.getBundledOfferIdandPrice(this.phoneSelected, group);
            this.selectedPhoneOfferdId = dataVal.id;
            this.selectedPhoneOfferPrice = dataVal.price;
        }
        this.getOfferById();
        this.selectedInternetOfferPrice = this.offerHelperService.getBundleOfferPrice(group, this.internetCheck ? GenericValues.iData : GenericValues.cHP, this.internetCheck ? true : false);
    }

    public getBundledOfferIdandPrice(selectedItem, group) {
        let dataVal = {
            id: null,
            price: null
        };
        switch (selectedItem) {
            case 'DHP':
                dataVal.id = this.offerHelperService.getBundledOfferId(group, GenericValues.cDHP);
                dataVal.price = this.offerHelperService.getBundleOfferPrice(group, GenericValues.cDHP);
                break;
            case 'HMP':
                dataVal.id = this.offerHelperService.getBundledOfferId(group, GenericValues.cHP);
                dataVal.price = this.offerHelperService.getBundleOfferPrice(group, GenericValues.cHP);
                break;
            case 'DTV':
                dataVal.id = this.offerHelperService.getBundledOfferId(group, GenericValues.cDTV);
                dataVal.price = this.offerHelperService.getBundleOfferPrice(group, GenericValues.cDTV);
                break;
            case 'PTV':
                dataVal.id = this.offerHelperService.getBundledOfferId(group, GenericValues.cVideo);
                dataVal.price = this.offerHelperService.getBundleOfferPrice(group, GenericValues.cVideo);
                break;
        }
        return dataVal;
    }


    public getOfferById() {
        let flag: boolean = false;
        this.internerOffer.forEach((offer) => {
            if (!flag && offer.productOfferingId === this.selectedInternetOfferdId) {
                flag = true;
                this.internetSlot(offer);
            }
        });
        if (this.videoOffer) {
            this.videorOffer.forEach((offer) => {
                if (offer.productOfferingId === this.selectedVideoOfferdId) {
                    this.videoSlot(offer);
                }
            });
        }
        if (this.phoneOfferData) {
            this.phoneOfferData.forEach((offer) => {
                if (offer.productOfferingId === this.selectedPhoneOfferdId && this.phoneSelected === 'DHP') {
                    this.dhpSlot(offer);
                } else if (offer.productOfferingId === this.selectedPhoneOfferdId && this.phoneSelected === 'HMP') {
                    this.hmpSlot(offer);
                }
            });
        }
    }

    public onChangeInstallation(attrVal: string, isMandatory: boolean) {
        this.deviceMandatory = false;
        this.deviceSelected = false;
        let price = attrVal === 'na' ? this.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
            this.installationValues, attrVal, '');
        this.selectedInstallation = this.searchForDefault(false, this.installationValues, price);
        if (attrVal === 'na') {
            this.selectedQuantity = 'na';
            this.installError = true;
            this.getProductConfig(this.selectedInstallation, false, undefined);
        } else {
            this.undoFlag = true;
            this.getProductConfig(this.selectedInstallation, false);
            this.installError = false;
            this.newTechInstall = true;

        }
        this.cartRequest();
        if (attrVal === GenericValues.selfInstall) {
            this.selfinstallSelected = true;
        } else {
            this.selfinstallSelected = false;
        }
        this.store.dispatch({ type: 'SELF_INSTALL_SELECTED', payload: this.selfinstallSelected });
    }

    public onChangeModem(attrVal: string, isMandatory: boolean, fromDropDown?) {
        let price = attrVal === 'na' ? this.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
            this.modemValues, attrVal, GenericValues.modem);
        this.selectedModem = this.searchForDefault(false, this.modemValues, price);
        if (attrVal === 'na') {
            isMandatory ? this.modemError = true : this.modemError = false;
            this.selectedModem = undefined;
        } else {
            this.undoFlag = true;
            this.modemError = false;
        }
        this.cartRequest();
    }

    public onChangeEase(attrVal: string, isMandatory: boolean) {
        this.EaseDefault = false;
        if ((attrVal !== 'na' && attrVal !== 'Basic') && this.phoneOffer) {
            this.checkCompatibilityEaseAndWireMaintenance()
        } else if (this.phoneOffer) {
            if (this.wireMaintainanceInput && this.wireMaintainanceInput.nativeElement.value === 'na') {
            this.wireMaintainenceHide = true;
            }
        }
        let price = attrVal === 'na' ? this.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
            this.easeValues, attrVal, '');
        this.selectedEase = this.searchForDefault(false, this.easeValues, price);
        if (attrVal === 'na') {
            isMandatory ? this.easeError = true : this.easeError = false;
            this.selectedEase = undefined;
        } else {
            this.undoFlag = true;
            this.easeError = false;
        }
        this.cartRequest();
    }

    public onChangeJacks(attrVal: string, isMandatory?: boolean) {
        this.JacksWireDefault = false;
        let price = attrVal === 'na' ? this.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
            this.jackValues, attrVal, '');
        this.selectedJack = this.searchForDefault(false, this.jackValues, price);
        if (attrVal === 'na') {
            this.selectedJack = undefined;
            this.potsJacksMandatory = true;
        }
        this.cartRequest();
    }

    public portingValue: string;

    /**
     * VIDEO SECTION
     * @param selectedTVOffer
     */
    public videoSlot(selectedTVOffer: ProductOfferings) {
        this.isShowRemoveRetentionDiscountMsg = false;
        this.selectedTVOffer = selectedTVOffer;
        let price = 0;
        this.discountedPriceList = [];
        this.actualTVPrice = price;
        this.discountedTVPrice = price;
        let prod: Products = this.offerHelperService.searchforPrimary(selectedTVOffer.productOffer
            .productComponents, GenericValues.cPrimary);
        this.selectedTV = prod.productName;
        if (prod.productAttributes !== null && prod.productAttributes.length > 0) {
            this.actualTVPrice = selectedTVOffer.defaultOfferPrice.rc;
            this.discountedTVPrice = selectedTVOffer.defaultOfferPrice.discountedRc;
            this.actualTVOtcPrice = selectedTVOffer.defaultOfferPrice.otc;
            this.discountedTVOtcPrice = selectedTVOffer.defaultOfferPrice.discountedOtc;
            this.errorMsg = serverErrorMessages.empty;
            let attr = this.fetchIsPriceable(prod.productAttributes);
            let discounts: Discounts[] = [];
            attr.discounts === null ? discounts = [] : discounts = attr.discounts;
            for (let discount of discounts) {
                if (discount.autoAttachInd === 'Y') {
                    this.discountedPriceList.push(discount)
                }
            }
            this.totalDiscountAmount = this.discountedPriceList ?
               this.maxDiscountAmount(this.discountedPriceList) : 0;
        } else {
            this.errorMsg = serverErrorMessages.priceObjectNull;
        }
        this.hdPrice = price;
        this.dvrPrice = price;
        let hdvr = this.filterProductByType(selectedTVOffer, GenericValues.cHD);
        if (hdvr !== undefined) {
            this.hdService = hdvr.product;
            if (this.hdService.productAttributes[0].prices !== null && this.hdService.productAttributes[0].prices.length > 0) {
                this.hdService.productAttributes[0].prices[0].discountedOtc === 0 ? this.hdService.productAttributes[0].prices[0].otc === 0 ?
                    this.hdService.productAttributes[0].prices[0].discountedRc === 0 ? this.hdPrice = this.hdService
                       .productAttributes[0].prices[0].rc : this.hdPrice = this.hdService.productAttributes[0].prices[0].discountedRc :
                    this.hdPrice = this.hdService.productAttributes[0].prices[0].otc : this.hdPrice = this.hdService
                        .productAttributes[0].prices[0].discountedOtc;
                this.hdService = hdvr.product;
            }
        }
        hdvr = this.filterProductByType(selectedTVOffer, GenericValues.cDVR);
        if (hdvr !== undefined) {
            this.dvrService = hdvr.product;
            if (this.dvrService.productAttributes[0].prices !== null && this.dvrService.productAttributes[0].prices.length > 0) {
                this.dvrService.productAttributes[0].prices[0].discountedOtc === 0 ? this.dvrService.productAttributes[0].prices[0].otc === 0 ?
                    this.dvrService.productAttributes[0].prices[0].discountedRc === 0 ? this.dvrPrice =
                        this.dvrService.productAttributes[0].prices[0].rc : this.dvrPrice = this.dvrService.productAttributes[0].prices[0]
                            .discountedRc : this.dvrPrice = this.dvrService.productAttributes[0].prices[0].otc : this.dvrPrice
                    = this.dvrService.productAttributes[0].prices[0].discountedOtc;
                this.dvrService = hdvr.product;
            }
        }
        if (prod.productAttributes !== null && prod.productAttributes.length > 0) {
            this.discountedPriceList = [];
            let attr = this.fetchIsPriceable(prod.productAttributes);
            let discounts: Discounts[] = [];
            attr.discounts === null ? discounts = [] : discounts = attr.discounts;
            for (let discount of discounts) {
                if (discount.autoAttachInd === 'Y') {
                    this.discountedPriceList.push(discount)
                }


            }
            //find the existing discount availble in the current offer
            for (let existdiscount of this.existingRetentionDiscounts) {
                let existingDiscountMatchFound = false;
                for (let discount of discounts) {
                    if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {

                        existingDiscountMatchFound = true;
                    }
                }

                if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
                    this.hsiRemovedRetentiondiscounts.push(existdiscount);
                    this.isShowRemoveRetentionDiscountMsg = true;
                }
                //send only discounts matching in current offer and not the otc discounts.
                if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
                    this.retentionDiscountsToCart.push(existdiscount);

                }
            }
            if (!this.reEntrant) this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.retentionDiscountsToCart });
            if (this.videoSelected === 'NoTV' && !this.phoneOffer) {
                this.totalDiscountAmount = this.discountedPriceList ?
                    this.maxDiscountAmount(this.discountedPriceList) : 0;
            }
        }
        let surcharge: OfferProductComponents = this.filterProductByType(selectedTVOffer,
            GenericValues.cSurcharge);
        if (surcharge !== undefined) {
            this.stb = surcharge.product;
            this.maxTSTB = this.offerHelperService.maxValue(this.stb, GenericValues.cTotalSTB, false);
            this.selectedTotal = this.maxTSTB[0];
            this.onChangeTotal(this.selectedTotal);
        } else {
            this.cartRequest();
        }
        this.retriveOffersLoading = false;
    }

    public onChangeTotal(value: string) {
        this.selectedTotal = value;
        this.maxWSTB = this.offerHelperService.maxValue(this.stb, GenericValues.cWSTB, true, value, GenericValues.cTotalSTB);
        this.selectedWire = this.maxWSTB[0];
        this.fetchPriceforSTB();
    }

    public getSTBPrice(prodName: string) {
        if (prodName === 'Wired Set Top Box') {
            this.wiredSTB = this.getProdComponent(prodName, this.selectedTotal);
        } else {
            this.wirelessSTB = this.getProdComponent(prodName, this.selectedWire);
        }
    }
    public getProdComponent(prodName, val) {
        let product: Products;
        let prod = this.filterProductByType(this.selectedTVOffer, prodName);
        prod.product.productAttributes.forEach(attr => {
            if (attr.isPriceable) {
                attr.compositeAttribute.forEach(compAttr => {
                    if (compAttr.attributeName === 'Quantity' && val === compAttr.attributeValue) {
                        product = prod.product;
                        product = Object.assign({},
                            product, {
                                productAttributes: [attr]
                            });
                    }
                });
            }
        });
        return product;
    }

    public fetchPriceforSTB() {
        let flag: boolean = false;
        this.stb.productAttributes.forEach((attrVal) => {
            if (attrVal.isPriceable) {
                if (!flag && this.offerHelperService.getValueofWSTB(attrVal, GenericValues.cWSTB) === this.selectedWire
                    && this.offerHelperService.getValueofWSTB(attrVal, GenericValues.cTotalSTB) === this.selectedTotal) {
                    flag = true;
                    this.selectedSTB = this.stb;
                    this.selectedSTB = Object.assign({},
                        this.selectedSTB, {
                            productAttributes: [attrVal]
                        });
                    this.getSTBPrice('Wired Set Top Box');
                    this.getSTBPrice('Wireless Set Top Box');
                    this.cartRequest();
                }
            }
        });
        this.cartRequest();
    }

    //DHP SLot
    public dhpSlot(offer: ProductOfferings) {    
        this.isShowRemoveRetentionDiscountMsg = false;    
        this.internationalPrice = 0;
        this.selectedDHPOffer = offer;
        this.dhpOfferPriceDiscountedRc = 0;
        this.dhpOfferPriceDiscountedOtc = 0;
        if (offer.defaultOfferPrice !== null && offer.defaultOfferPrice !== undefined) {
            this.dhpOfferPriceDiscountedRc = offer.defaultOfferPrice.discountedRc;
            this.dhpOfferPriceDiscountedOtc = offer.defaultOfferPrice.discountedOtc;
        }
        offer.productOffer.productComponents.forEach(data => {
            if (data.componentType !== GenericValues.cPrimary && data.product.productName === 'Digital Home Phone Intl Call') {
                this.internationalDialing = data;
                if (data.product.productAttributes !== null && data.product.productAttributes && data.product.productAttributes.length !== 0) {
                    data.product.productAttributes.forEach(attr => {
                        if (attr.isPriceable && attr.prices !== null && attr.prices && attr.prices.length !== 0) {
                            attr.prices.forEach(price => {
                                if (price.discountedRc !== 0) {
                                    this.internationalPrice = price.discountedRc;
                                } else if (price.rc !== 0) {
                                    this.internationalPrice = price.rc;
                                } else if (price.discountedOtc !== 0) {
                                    this.internationalPrice = price.discountedOtc;
                                } else if (price.otc !== 0) {
                                    this.internationalPrice = price.otc;
                                }
                            });
                        }
                    });
                }
            }
        });
        this.includedCallingFeatures = this.addincludedCallingFeatures(offer.productOffer.productComponents, 'COMPONENT', false);
        let dhpProduct: Products = this.offerHelperService.searchforPrimary(offer.productOffer
            .productComponents, GenericValues.cPrimary);
           if (dhpProduct.productAttributes !== null && dhpProduct.productAttributes.length > 0) {
                this.discountedPriceList = [];
                let attr = this.fetchIsPriceable(dhpProduct.productAttributes);
                let discounts: Discounts[] = [];
                attr.discounts === null ? discounts = [] : discounts = attr.discounts;
                for (let discount of discounts) {
                    if (discount.autoAttachInd === 'Y') {
                        this.discountedPriceList.push(discount)
                    }
                }
                this.totalDiscountAmount = this.discountedPriceList ?
                this.maxDiscountAmount(this.discountedPriceList) : 0;
                //find the existing discount availble in the current offer
                for (let existdiscount of this.existingRetentionDiscounts) {
                    let existingDiscountMatchFound = false;
                    for (let discount of discounts) {
                        if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {
    
                            existingDiscountMatchFound = true;
                        }
                    }
    
                    if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
                        this.hsiRemovedRetentiondiscounts.push(existdiscount);
                        this.isShowRemoveRetentionDiscountMsg = true;
                    }
                    //send only discounts matching in current offer and not the otc discounts.
                    if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
                        this.retentionDiscountsToCart.push(existdiscount);
    
                    }
                }
                if (!this.reEntrant) this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.retentionDiscountsToCart });
                if (this.videoSelected === 'NoTV' && !this.phoneOffer) {
                    this.totalDiscountAmount = this.discountedPriceList ?
                        this.maxDiscountAmount(this.discountedPriceList) : 0;
                }
            } 
        this.cartRequest();
        this.retriveOffersLoading = false;
    }

    public getPhoneDisplayName(offer: ProductOfferings) {
        return this.productService.getPhoneDisplayName(offer);
    }

    public hmpSlot(offer: ProductOfferings) {
        this.isShowRemoveRetentionDiscountMsg = false;
        this.retriveOffersLoading = false;
        this.selectedPhoneOfferdId = offer.productOfferingId;
        this.errorMsg = serverErrorMessages.empty;
        this.selectedDHPOffer = offer;
        this.selectedHPOffer = offer;
        this.dhpOfferPriceDiscountedRc = 0;
        this.dhpOfferPriceDiscountedOtc = 0;
        this.selectedHP = offer.productOfferingId;
        this.discountedPriceList = [];
        if (offer && offer.productOffer && offer.productOffer.productComponents) {
            offer.productOffer.productComponents.forEach(offData => {
                if (offData && offData.product && offData.product.productAttributes) {
            offData.product.productAttributes.forEach(disArray => {
                if (disArray.isPriceable) {
                    if (disArray && disArray.discounts !== null && disArray.discounts.length > 0) {
                        for(let i=0; i<disArray.discounts.length;i++ ){
                        if (disArray.discounts[i].autoAttachInd === 'Y') {
                            this.discountedPriceList.push(disArray.discounts[i])
                        }
                    }
                    }
                    this.totalDiscountAmount = this.discountedPriceList ?
                        this.maxDiscountAmount(this.discountedPriceList) : 0;
                }
            });
        }
        });
    }
        if (offer.defaultOfferPrice !== null && offer.defaultOfferPrice !== undefined) {
            this.dhpOfferPriceDiscountedRc = offer.defaultOfferPrice.discountedRc;
            this.dhpOfferPriceDiscountedOtc = offer.defaultOfferPrice.discountedOtc;
            this.selectedInternetOfferPrice = offer.defaultOfferPrice.rc;
        }
        this.includedCallingFeatures = this.addincludedCallingFeatures(offer.productOffer.productComponents, 'COMPONENT', true);
        
        this.selectedDHPOffer
            .productOffer.productComponents.forEach(products => {
                if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Voice Messaging') !== -1) {
                    this.selectedVoiceMail = this.getDHPComponents(products);
                    this.voiceMailPrice = this.offerHelperService.fetchPrice(this.selectedVoiceMail);
                }
                if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Wire Maintenance Plan') !== -1) {
                    this.selectedMaintainance = this.getDHPComponents(products);
                    this.maintainancePrice = this.offerHelperService.fetchPrice(this.selectedMaintainance);
                }
                if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Jack and Wire') !== -1) {
                    this.jackValuesForPots = this.filterProductByType(offer, 'Jack and Wire');
                    this.jackValuesForPots.product.productAttributes.sort(this.offerHelperService.dynamicSort("displayOrder"));
                    let attrVal: any;
                    if (this.retainedPotsBooleans !== null && this.retainedPotsBooleans !== undefined) {
                        attrVal = this.retainedPotsBooleans.retainValueForPotsJack;
                    }

                    if (attrVal !== "") {
                        let attrVal = this.retainedPotsBooleans && this.retainedPotsBooleans.retainValueForPotsJack;
                        this.retainValueForPotsJack = attrVal;
                        let price = attrVal === 'na' ? this.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
                            this.jackValuesForPots, attrVal, '');
                        this.selectedJackForPots = this.searchForDefault(false, this.jackValuesForPots, price);
                    } else {
                        this.selectedJackForPots = this.searchForDefault(true, this.jackValuesForPots);
                    }
                }
            });
        this.loading = false;
        this.undoSelected = false;
        if (this.internetData &&  this.internetData.productAttributes !== null && this.internetData.productAttributes.length > 0 && this.isInternetRemoved) {
            this.discountedPriceList = [];            
            let attr = this.fetchIsPriceable(this.internetData.productAttributes);
            let discounts: Discounts[] = [];
            attr.discounts === null ? discounts = [] : discounts = attr.discounts;
            for (let discount of discounts) {
                if (discount.autoAttachInd === 'Y') {
                    this.discountedPriceList.push(discount)
                }


            }
            //find the existing discount availble in the current offer
            for (let existdiscount of this.existingRetentionDiscounts) {
                let existingDiscountMatchFound = false;
                for (let discount of discounts) {
                    if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {

                        existingDiscountMatchFound = true;
                    }
                }

                if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
                    if(this.hsiRemovedRetentiondiscounts && this.hsiRemovedRetentiondiscounts.length > 0){
                        this.hsiRemovedRetentiondiscounts.map(addeddisc =>{
                            if(existdiscount.discountId !== addeddisc.discountId){
                                this.hsiRemovedRetentiondiscounts.push(existdiscount);                                
                            }                                               
                        })
                    } else {
                        this.hsiRemovedRetentiondiscounts.push(existdiscount);   
                    }                    
                    this.isShowRemoveRetentionDiscountMsg = true;                   
                }
                //send only discounts matching in current offer and not the otc discounts.
                if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
                    this.retentionDiscountsToCart.push(existdiscount);

                }
            }
            if (!this.reEntrant) this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: this.retentionDiscountsToCart });
            if (this.videoSelected === 'NoTV' && !this.phoneOffer) {
                this.totalDiscountAmount = this.discountedPriceList ?
                    this.maxDiscountAmount(this.discountedPriceList) : 0;
            }
        }      

        this.cartRequest();
    }

    public wireMaintainanceValue: string;
    public voiceMailValue: string = 'na';

    public showWithHSI(items: ProductOfferings): boolean {
        let flag: boolean = false;
        if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
            items.productOffer.offerAttributes.forEach(attr => {
                if (this.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'yes') {
                    items.productOffer.offerAttributes.forEach(checkAttr => {
                        if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                            flag = true;
                        }
                    });
                } else if (!this.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'no') {
                    items.productOffer.offerAttributes.forEach(checkAttr => {
                        if (this.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
                            flag = true;
                        }
                    });
                }
            });
        }
        return flag;
    }

    public checkCompatibilityEaseAndWireMaintenance() {
        if (this.compatibilityArray && this.compatibilityArray.outputAttribute && this.compatibilityArray.outputAttribute.length > 0) {
            for (let i = this.compatibilityArray.outputAttribute.length - 1; i >= 0; i--) {
                let compArr = [] = this.compatibilityArray && this.compatibilityArray.outputAttribute[i];
                if ((compArr[2] === GenericValues.iData && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.includesNotRequired
                    && compArr[4].trim() === 'CENTURYLINK @ EASE' && compArr[10] === 'Inside Wire Maintenance Plan-R')) {
                    this.wireMaintainenceHide = false;
                    this.wireMaintainance = false;
                    this.selectedMaintainance = undefined;
                }
            }
        }
    }

    public compatibilityAPIcall() {
        this.loading = true;
        this.logger.log("info", "vacation-offer.component.ts - getCompatibilityRules", "fetchRuleRequest", JSON.stringify(""));
        this.logger.startTime();
        this.productService.getCompatibilityRules()
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "vacation-offer.component.ts", "getCompatibilityResponse", JSON.stringify(error));
                this.logger.log("error", "vacation-offer.component.ts", "getCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "SUBMIT_TASK", "customize-services.component.ts",
                    "CustomizeService Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "vacation-offer.component.ts - getCompatibilityRules", "getCompatibilityResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "vacation-offer.component.ts  - getCompatibilityRules", "getCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.compatibilityArray = data;
                this.store.dispatch({ type: 'COMPATIBILITY_RULES', payload: data });
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "vacation-offer.component.ts ", "getCompatibilityResponse", JSON.stringify(error));
                    this.logger.log("error", "vacation-offer.component.ts ", "getCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}'); 
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    public giftCardRules(speed: string) {
        let applicableGiftcard: any = [];
        let catalogName: string;
        let customize = <Observable<any>>this.store.select('customize');
        customize.subscribe((data) => {
            if (data) {
                data.giftcards && data.giftcards.map((x: any) => {
                    x.eligibleGiftCardOffer.map((g: any) => {
                        if(x.offerName === speed && g.relationType === 'M') { 
                            if(applicableGiftcard.indexOf(g.giftcardOfferName) === -1) { applicableGiftcard.push(g.giftcardOfferName); }
                        }
                    });
                })
                data.offers && data.offers.map((items: any) => {
                    if(items.serviceCategory === 'DATA' && items.catalogs && items.catalogs[0].catalogName) { catalogName = items.catalogs[0].catalogName; }
                })
            } else {
                return;
            }
        })
        let eligibilityRequest = {
            "catalogName": catalogName,
            "city": "",
            "giftCardOfferName": applicableGiftcard,
            "state": "",
            "wireCenter": ""
        }
        this.existingObservable.subscribe((data) => {
            if (data && data.existingProductsAndServices && data.existingProductsAndServices !== undefined) {
                eligibilityRequest.wireCenter = data.existingProductsAndServices[0].serviceAddress.locationAttributes.wirecenter
                eligibilityRequest.city = data.existingProductsAndServices[0].serviceAddress.city;
                eligibilityRequest.state = data.existingProductsAndServices[0].serviceAddress.stateOrProvince;
            }
        })
        this.store.dispatch({ type: 'ELIGIBLE_GIFTCARDS', payload: applicableGiftcard });
        if (applicableGiftcard && applicableGiftcard.length > 0) {
            this.loading = true;
            this.logger.log("info", "vacation-offer.component.ts", "giftCardEligibilityAndRelationRequest", JSON.stringify(eligibilityRequest));
            this.logger.startTime();
            this.productService.giftCardEligibilityAndRelation(eligibilityRequest)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "vacation-offer.component.ts", "giftCardEligibilityAndRelationResponse", error);
                    this.logger.log("error", "vacation-offer.component.ts", "giftCardEligibilityAndRelationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", 'Not Applicable',
                        "submitTask - updateCart", "offer.component.ts",
                        "Product Offer Page",
                        error);
                    return Observable.throwError(null);

                })
                .subscribe((data) => {
                    this.logger.endTime();
                    this.logger.log("info", "vacation-offer.component.ts", "giftCardEligibilityAndRelationResponse", JSON.stringify(data));
                    this.logger.log("info", "vacation-offer.component.ts", "giftCardEligibilityAndRelationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.store.dispatch({ type: 'GIFT_COMPATIBILITY_RULES', payload: data });
                },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "vacation-offer.component.ts", "giftCardEligibilityAndRelationResponse", JSON.stringify(error));
                        this.logger.log("error", "vacation-offer.component.ts", "giftCardEligibilityAndRelationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                    })
        }

    }

    public toConfig() {
        this.giftCardRules(this.speedselected);
        if (this.easeSelected && this.easeSelected.nativeElement.value === 'na') {
            this.easeError = true;
        }
        if (!this.selectedModem && !this.isModemCompatible) {
            this.modemError = true;
        }
        this.configSubmited = true;
        if (this.isPOTS && !this.hpExisting) {
            if (this.voiceMailInput && this.voiceMailInput.nativeElement && this.voiceMailInput.nativeElement.value !== 'na') {
                this.potsVoiceMailMandatory = false;
            } else {
                this.potsVoiceMailMandatory = true
            }
            if ((this.wireMaintainanceInput && this.wireMaintainanceInput.nativeElement && this.wireMaintainanceInput.nativeElement.value !== 'na') ||
                (this.internetAvail && this.newInternetCheck && this.newPhoneSelected === 'HMP' && !this.wireMaintainenceHide)) {
                this.potsWireMainMandatory = false;
            } else {
                this.potsWireMainMandatory = true
            }
            if (this.portingInput && this.portingInput.nativeElement && this.portingInput.nativeElement.value !== 'na') {
                this.potsPortingMandatory = false;
            } else {
                this.potsPortingMandatory = true
            }
        }
        if (!this.isPOTS) {
            this.potsJacksMandatory = false;
            this.potsVoiceMailMandatory = false;
            this.potsWireMainMandatory = false;
            this.potsPortingMandatory = false;
        }
        if (this.internetCheck && (this.easeError || this.modemError || this.installError || (this.deviceMandatory && !this.deviceSelected) || this.potsJacksMandatory || this.potsVoiceMailMandatory || this.potsWireMainMandatory || this.potsPortingMandatory)) {
            return;
        }
        this.compatibilityAPIcall();
        this.loading = true;
        let offering: ProductOfferings;
        let offerings: ProductOfferings[] = [];
        let catalog: Catalogs;
        let catalogs: Catalogs[] = [];
        let selectedProducts = [];
        if (this.internetCheck) {
            offerings = [];
            offering = this.selectedOffer;
            offerings.push(offering);
            catalog = {
                offerCategory: GenericValues.sData,
                catalogItems: offerings
            };
            catalogs.push(catalog);
            selectedProducts.push({ type: 'data', selected: GenericValues.sData });
        }
        if (this.videoOffer) {
            offerings = [];
            offering = this.selectedTVOffer;
            offerings.push(offering);
            catalog = {
                offerCategory: 'VIDEO',
                catalogItems: offerings
            };
            catalogs.push(catalog);
            selectedProducts.push({ type: 'video', selected: this.getProductNameFromSelect(this.videoSelected) });
        }
        if (this.phoneOffer) {
            offerings = [];
            offering = this.selectedDHPOffer;
            offerings.push(offering);
            catalog = {
                offerCategory: 'VOICE-DHP',
                catalogItems: offerings
            };
            catalogs.push(catalog);
            selectedProducts.push({ type: 'phone', selected: this.getProductNameFromSelect(this.phoneSelected) });

        }
        this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: selectedProducts } });
        let serviceOffer: ServiceCategoryBasedOffers = {
            serviceCategory: this.selected,
            catalogs: catalogs
        };
        let serviceOffers: ServiceCategoryBasedOffers[] = [];
        serviceOffers.push(serviceOffer);
        let toReview: PayloadProduct = {
            offers: serviceOffers
        };
        this.store.dispatch({ type: 'REVIEW_ORDER', payload: toReview });
        let composite: CompositeAttribute[] = [];
        let customerOrderItems: CustomerOrderItems[] = [];
        let customerOrderSubItems: Products[] = [];
        let productAttributes: AttributesCombination[] = [];
        this.cartObject.payload.cart.customerOrderItems.forEach(cartObj => {
            customerOrderSubItems = [];
            cartObj && cartObj.customerOrderSubItems && cartObj.customerOrderSubItems.forEach(sub => {
                productAttributes = [];
                sub && sub.productAttributes && sub.productAttributes.forEach(subProd => {
                    composite = [];
                    subProd && subProd.compositeAttribute && subProd.compositeAttribute.forEach(comp => {
                        composite.push({
                            attributeName: comp.attributeName,
                            attributeValue: comp.attributeValue,
                            uom: comp.uom
                        });
                    });
                    if (subProd.compositeAttribute) subProd.compositeAttribute = composite;
                    productAttributes.push(subProd);
                });
                if (sub && sub.productAttributes) {
                    sub.productAttributes = productAttributes;
                    customerOrderSubItems.push(sub);
                }
            });
            if (customerOrderSubItems) {
                cartObj.customerOrderSubItems = customerOrderSubItems;
                customerOrderItems.push(cartObj);
            }
        });
        this.cartObject.payload.cart.customerOrderItems = customerOrderItems;
        this.logger.log("info", "offer.component.ts", "updateChangeCartRequest", JSON.stringify(this.cartObject));
        this.logger.startTime();
        const potsBooleans: any = {
            wireMaintainance: this.wireMaintainance,
            selectedMaintainance: this.selectedMaintainance,
            voiceMail: this.voiceMail,
            portingCheck: this.portingCheck,
            isInternational: this.isInternational,
        }
        this.productService.updateChangeCart(this.cartObject, potsBooleans, this.e911ValidatedAddress, true)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "vacation-offer.component.ts", "updateChangeCartResponse", JSON.stringify(error));
                this.logger.log("error", "vacation-offer.component.ts", "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "Submit Task", "offer.component.ts",
                    "Update Cart - Offer Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "vacation-offer.component.ts", "updateChangeCartResponse", JSON.stringify(respData));
                    this.logger.log("info", "vacation-offer.component.ts", "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    if(respData) {
                        let orderRefNumber, taskId, taskName, processInstanceId;
                        if(respData.orderRefNumber) orderRefNumber = respData.orderRefNumber;
                        if(respData.taskId) taskId = respData.taskId;
                        if(respData.taskName) taskName = respData.taskName;
                        if(respData.processInstanceId) processInstanceId = respData.processInstanceId;
                        this.store.dispatch({type: 'ON_CONTINUE_FROM_OFFER_PAGE_RESPONSE_DATA', payload: {orderRefNumber, taskId, taskName, processInstanceId}})
                    }
                    if (this.holdCalled &&
                        this.cartCopyObject && this.cartCopyObject.payload && this.cartCopyObject.payload.cart &&
                        this.cartCopyObject.payload.cart.customerOrderItems && this.cartCopyObject.payload.cart.customerOrderItems.length > 0) {
                        for (let i = 0; i < this.cartCopyObject.payload.cart.customerOrderItems.length; i++) {
                            let cust = this.cartCopyObject.payload.cart.customerOrderItems[i];
                            if (cust.offerType === 'SUBOFFER') {
                                if (cust.customerOrderSubItems && cust.customerOrderSubItems.length > 0) {
                                    cust.existingServiceSubItems = cust.customerOrderSubItems
                                } else if (cust.existingServiceSubItems && cust.existingServiceSubItems.length > 0) {
                                    cust.customerOrderSubItems = cust.existingServiceSubItems
                                }
                                this.cartOrderItems.payload.cart.customerOrderItems.push(cust);
                            } else if (cust.offerType !== 'SUBOFFER' && cust.offerCategory === GenericValues.cHP &&
                                cust.productOfferingId === this.selectedPhoneOfferdId && !this.isCustomize) {
                                if (cust.customerOrderSubItems && cust.customerOrderSubItems.length > 0) {
                                    cust.existingServiceSubItems = cust.customerOrderSubItems
                                } else if (cust.existingServiceSubItems && cust.existingServiceSubItems.length > 0) {
                                    cust.customerOrderSubItems = cust.existingServiceSubItems
                                }
                                for (let j = 0; j < this.cartOrderItems.payload.cart.customerOrderItems.length; j++) {
                                    let cartOrder = this.cartOrderItems.payload.cart.customerOrderItems[j];
                                    if (cartOrder && cartOrder.offerCategory === GenericValues.cHP && cartOrder.offerType !== 'SUBOFFER') {
                                        if (cust && cust.customerOrderSubItems) {
                                            for (let k = 0; k < cust.customerOrderSubItems.length; k++) {
                                                let subs = cust.customerOrderSubItems[k];
                                                if (subs.componentType !== GenericValues.cPrimary && subs.productName.indexOf('Wire Maintenance Plan') === -1 &&
                                                    subs.productName.indexOf('Voice Messaging') === -1 && subs.productName.indexOf('Jack and Wire') === -1) {
                                                    this.cartOrderItems.payload.cart.customerOrderItems[j].customerOrderSubItems.push(subs);
                                                }
                                            }
                                        }
                                    }
                               }
                            }
                        }
                        if (this.isCustomize && this.existingServices) {
                            for (let j = 0; j < this.cartOrderItems.payload.cart.customerOrderItems.length; j++) {
                                let cartOrder = this.cartOrderItems.payload.cart.customerOrderItems[j];
                                if (cartOrder && cartOrder.offerCategory === GenericValues.cHP && cartOrder.offerType !== 'SUBOFFER') {
                                    for (let n = 0; n < this.existingServices.length; n++) {
                                        let cust = this.existingServices[n];
                                        if (cust && cust.customerOrderSubItems) {
                                            for (let k = 0; k < cust.customerOrderSubItems.length; k++) {
                                                let subs = cust.customerOrderSubItems[k];
                                                if (subs.componentType !== GenericValues.cPrimary && subs.productName.indexOf('Wire Maintenance Plan') === -1
                                                    && subs.productName.indexOf('Voice Messaging') === -1 && subs.productName.indexOf('Jack and Wire') === -1) {
                                                    this.cartOrderItems.payload.cart.customerOrderItems[j].customerOrderSubItems.push(subs);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        this.store.dispatch({ type: 'CREATE_CART', payload: this.cartOrderItems });
                        let orderFlow = {
                            flow: 'Change',
                            type: 'fromHold',
                            selectProductCalled: true,
                            customizeCalled: false
                        };
                        this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
                    }
                    if (this.voiceMail && !this.isHPRemoved && this.cartOrderItems && this.cartOrderItems.payload &&
                        this.cartOrderItems.payload.customerAddonOfferItems && this.cartOrderItems.payload.customerAddonOfferItems.length > 0) {
                        for (let i = 0; i < this.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
                            let addOns = this.cartOrderItems.payload.customerAddonOfferItems[i];
                            if (addOns.offerCategory === GenericValues.cHP && addOns.offerType !== 'SUBOFFER') {
                                for (let j = 0; j < addOns.customerOrderSubItems.length; j++) {
                                    if (addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer' ||
                                        addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-Busy') {
                                        addOns.customerOrderSubItems.splice(j, 1);
                                        j--;
                                    }
                                }
                            }
                        }
                        this.store.dispatch({ type: 'CREATE_CART', payload: this.cartOrderItems });
                    }
                    let lifelineData;
                    if (this.reEntrant && !this.changeAfterReEntrant) {
                        let custData = <Observable<any>>this.store.select('customize');
                        let custSubscription = custData.subscribe(data => {
                            lifelineData = data;
                        })
                        if (custSubscription !== undefined)
                            custSubscription.unsubscribe();
                        this.store.dispatch({ type: 'ISRENTRANT', payload: true });
                    } else {
                        this.store.dispatch({ type: 'ISRENTRANT', payload: false });
                    }
                    this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: respData });
                    if (lifelineData && lifelineData.lifelineaddedforinternet) {
                        this.store.dispatch({ type: 'LIFELINE_CONFIG', payload: lifelineData.lifelineConfig });
                        this.store.dispatch({ type: 'LIFELINE_CONFIG_DISCOUNTS', payload: lifelineData.lifelineDiscounts });
                        this.store.dispatch({ type: 'LIFELINE_CONFIG_ADJUSTMENTS', payload: lifelineData.lifelineAdjustment });
                    }
                    if (lifelineData && (lifelineData.lifelinePots || lifelineData.lifelineDHP)) {
                        this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG', payload: lifelineData.lifelinePotsConfig });
                        this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_DISCOUNTS', payload: lifelineData.lifelinePotsDiscounts });
                        this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_ADJUSTMENTS', payload: lifelineData.lifelinePotsAdjustment });
                    }
                    this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                    this.router.navigate(['/customize-services']);
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "vacation-offer.component.ts", "updateChangeCartResponse", JSON.stringify(error));
                    this.logger.log("error", "vacation-offer.component.ts", "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "updateCartResponseError ", "offer.component.ts", "Offers Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "updateCartResponseError ", "offer.component.ts", "Offers Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
        if (this.phoneSelected === 'HMP') {
            let subOrderItem: any;
            let subOrderItems: any[] = [];
            this.phoneOfferData.forEach(hmpOffer => {
                if (hmpOffer.productOfferingId === this.selectedPhoneOfferdId) {
                    hmpOffer.productOffer.productComponents.forEach(products => {
                        if (products.componentType !== GenericValues.cPrimary) {
                            if ((products.product.productName.indexOf('Wire Maintenance Plan') !== -1 && this.wireMaintainance) ||
                                ((products.product.productName.indexOf('Voice Messaging') !== -1)
                                    && this.voiceMail)) {
                                subOrderItem = products;
                                subOrderItems.push(subOrderItem);
                            }
                            if (products.product.productName.indexOf('Wire Maintenance Plan') === -1 && products.product.productName.indexOf('Voice Messaging') === -1
                                && products.product.productName.indexOf('Jack and Wire') === -1 && products.product.productName.indexOf('Easy Access') === -1) {
                                subOrderItem = products;
                                subOrderItems.push(subOrderItem);
                            }
                        }
                    });
                }
            });
            let orderItem = {
                catalogId: this.catalogPhoneId,
                productOfferingId: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOfferingId,
                offerType: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerType,
                offerSubType: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerSubType,
                offerCategory: this.selectedDHPOffer === undefined ? '' : this.selectedDHPOffer.productOffer.offerCategory,
                quantity: 1,
                rc: this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.rc : 0,
                discountedRc: this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
                otc: this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.otc : 0,
                discountedOtc: this.selectedDHPOffer.defaultOfferPrice !== null ? this.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
                customerOrderSubItems: subOrderItems
            };
            this.store.dispatch({ type: 'POTS_OFFER', payload: orderItem });
        }
    }

    public getProductNameFromSelect(selectedService) {

        let offerLink = null;
        switch (selectedService) {
            case 'DHP': offerLink = GenericValues.cDHP; break;
            case 'HMP': offerLink = GenericValues.cHP; break;
            case 'DTV': offerLink = GenericValues.cDTV; break;
            case 'PTV': offerLink = GenericValues.cVideo; break;
        }

        return offerLink;

    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.userSubscription1 !== undefined) {
            this.userSubscription1.unsubscribe();
        }
        if (this.existingSubscription !== undefined) {
            this.existingSubscription.unsubscribe();
        }
        if (this.vacationSubscription !== undefined) {
            this.vacationSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
    }

    public getDATAoffers(payload: PayloadProduct, link?) {
        let dataOffer: ServiceCategoryBasedOffers[] = [];
        dataOffer.push(this.dataLink);
        this.logger.endTime();
        this.logger.log("info", "offer.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(this.dataLink ? this.dataLink : ''));
        this.logger.log("info", "offer.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        payload = {
            offers: this.sortSpeeds(dataOffer)
        };

        this.catalogId = this.dataLink.catalogs[0].catalogId;

        this.offerResponse = Object.assign({},
            this.offerResponse, {
                payload: payload
            });
        this.internerOffer = this.dataLink && this.dataLink.catalogs && this.dataLink.catalogs[0] && this.dataLink.catalogs[0].catalogItems;
        let offers: any[] = [];
        this.internerOffer && this.internerOffer.map((offer) => {
            if(offer && offer.productOffer && offer.productOffer.offerName.toUpperCase() !== VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                offers.push(offer);
            }
        });
        this.internerOffer = offers;
        let primaryProdduct;
        if(offers && offers.length > 0) {
            primaryProdduct = this.offerHelperService.searchforPrimary(offers[0].productOffer.productComponents, GenericValues.cPrimary);
        }
        this.store.dispatch({ type: 'CART_MAX_SPEED', payload: primaryProdduct });
        if (this.videoSelected === 'NoTV' && this.phoneSelected === 'NoPhone') {
            this.createSlot();
        }
        if (link) {
            this.getPhoneOffers(payload, link);
        }
        if (this.loading) {
            this.loading = false;
        }
    }


    public getOfferByCategory(selectedItem, data) {
        let offer = [];
        switch (selectedItem) {
            case 'DHP': offer = this.filterBundleCategory(data.offers,
                GenericValues.cDHP, GenericValues.cDHP);
                this.errorMsg = 'No Offers with respect to DHP found'; break;
            case 'HMP': offer = this.filterBundleCategory(data.offers,
                GenericValues.cHP, GenericValues.cHP);
                this.errorMsg = 'No Offers with respect to Home Phone found'; break;
            case 'PTV': offer = this.filterBundleCategory(data.offers,
                GenericValues.cDATVID, GenericValues.cVideo);
                this.errorMsg = 'No Offers with respect to Prism tv found'; break;
            case 'DTV': offer = this.filterBundleCategory(data.offers,
                GenericValues.cDTV, GenericValues.cDTV);
                this.errorMsg = 'No Offers with respect to DTV tv found'; break
        }
        return offer;

    }

    // removeProduct
    public setMessage(msg: string, removeProduct: string) {
        this.removeMessage = msg;
        this.productToRemove = removeProduct;
    }

    public productRemoved(removed: string) {
        if (removed === 'offerCategory') {
            this.undoFlag = true;
            this.removal.productType = this.hpExisting ? 'VOICE-HP' : 'VOICE-DHP';
        } else {
            this.undoFlag = true;
            this.removal.productType = removed;
        }
    }

    public doUndo() {
        this.undoChanges = false;
        if (this.isDHPRemoved) {
            this.phoneOffer = true;
            this.isDHPRemoved = false;
            this.removedProductItem = undefined;
            this.cartObject.payload.cart.customerOrderItems.forEach(item => {
                if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
                    item.action = 'REMOVE';
                    if (item.offerCategory === 'VOICE-DHP') {
                        this.phoneSelected = 'DHP';
                    }   
                    if (item.offerCategory === 'VOICE-HP') {
                        this.phoneSelected = 'HMP';
                    }
                    this.retrieveOffers(false);
                }
            });
        }
        else
            this.retrieveOffers(false);
    }


    public mouseEnter(div: string) {
        this.showHoverMessage = false;
        if (!((!this.selfInstall && (this.installationValues && this.installationValues.product && this.installationValues.product.productName === 'TECH INSTALL') && (this.recommendedTech && this.recommendedTech.compositeAttribute[0] && this.recommendedTech.compositeAttribute[0].attributeValue !== 'Y')) || (this.recommendedTech && this.recommendedTech.compositeAttribute[0] && this.recommendedTech.compositeAttribute[0].attributeValue === 'Y'))) {
            this.showHoverMessage = true;
        } else if (!this.installationValues) {
            this.showHoverMessage = true;
        }
    }

    public mouseLeave(div: string) {
        this.showHoverMessage = false;
    }

    public undoSelected = false;
    public undoAll() {
        this.loading = true;
        this.undoSelected = true;
        this.initilizeAll();
        this.ngOnInit();
        this.undoFlag = false;
        this.loading = false;
    }

}