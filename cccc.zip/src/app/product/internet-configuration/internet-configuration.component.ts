import { Observable, Subscription } from 'rxjs/Rx';
import { Store } from '@ngrx/store';
import { AppStore } from './../../common/models/appstore.model';
import { FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Logger } from '../../common/logging/default-log.service';
import { Validations } from '../../common/validations/validations';
import { User } from '../../common/models/user.model';
import { DatePipe } from '@angular/common';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';


@Component({
    selector: 'internet-configuration',
    templateUrl: './internet-configuration.component.html',
    styleUrls: ['../phone-configuration/phone-configuration.component.scss']
})

export class InternetConfigurationComponent implements OnInit, OnDestroy {
    public isProfileLifelineDiscount: boolean;
    public disableAllLifelineFields: boolean = false;
    public lifelineProfileExists: boolean = false;
    public custData: any;
    public lifelineConfigData: any;
    public lifelineInternet: any = false;
    public isRentrant: boolean = false;
    public lifelineInternetExpand: boolean = false;
    public azmediOptionSelected: boolean = false;
    public newLifelineRemoved: boolean;
    public lifelineCollapesed: boolean = false;
    public existingLifelineData: boolean = false;
    public lifelineDataAdded: boolean = false;
    public linkupSelected: boolean = false;
    public stateSelected: boolean = false;
    public tribalSelected: boolean = false;
    public fedaralSelected: boolean = false;
    public removeInternetLifeline: boolean = false;
    public federalChecked: boolean = false;
    public adjustmentsResponse: boolean = false;
    public nladDateResponse: boolean = false;
    public discountChanges: boolean = false;
    public expLifelineSelected: boolean;
    public arcrecurringStateCredit: any = "ARC Credit (LLARC)";
    public checkBox: any;
    public validLifelineData: boolean = false;
    public lifelineInternetAdded: boolean = true;
    public lifelineSubmitted: boolean = false;
    public selectedProg: any;
    public selectedQualProg: any;
    public LifeLineAdjustments: { adjustments: any[]; };
    public adjustmentsUpdates: any[];
    public discountsUpdates: any[];
    public discountsLifelineData: any;
    public saveLifelineUpdates: any;
    public lifelineConfigObj: { firstName: any; lastName: any; dateOfBirth: any; ssnLastFour: any; federalInd: any; tribalInd: any; stateInd: any; linkUpInd: any; qualProg: any; effectiveDate: string; iehCertDate: string; expirationDate: string; anniversaryDate: string; caseNumber: any; acpInd: any; ruralInd: any; nladData: any; linkupSvcDate: any };
    public LifeLineDiscounts: { discounts: any; };
    public dateOfBirth: any;
    public ssnNumber: any;
    public existingInfo: any;
    public currentFlow: any;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    @Input() public lifeLineMasterRecurringCredits: any;
    @Input() public lifeLineMasterNonRecurringCredits: any;
    @Input() public lifeLineMasterQualProgList: any;
    @Input() public lifelineReponseData: any;
    @Input() public lifeLineHideInternet: boolean;
    @Input() public lifelineRespData: any;
    @Output() public lifeLineRemove: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public clickLifelineContinue: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public removeLifelineContinue: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public expandLifelineContinue: EventEmitter<boolean> = new EventEmitter<boolean>();
    public loading;
    public nladData: string;
    public isLifelineShow: boolean = true;
    @Input() public isAmendOrStack: boolean;
    public lifelineResponse = {
        "lifelineInd": true,
        "llServiceType": "VOICE",
        "productDetails": {
            "ban": 300021686,
            "productType": "T",
            "csrId": 1061338
        },
        "LifeLineConfig": {
            "firstName": "Whitney",
            "lastName": "Johnson",
            "dateOfBirth": "2018-06-13T10:42:47.749Z",
            "ssnLastFour": 5689,
            "federalInd": true,
            "tribalInd": true,
            "stateInd": true,
            "linkUpInd": true,
            "linkupSvcDate": "10/31/2018",
            "qualProg": "BDS: Badger Care",
            "effectiveDate": "11/22/2017",
            "iehCertDate": "11/22/2017",
            "expirationDate": "12/31/9999",
            "anniversaryDate": "11/22/2017",
            "caseNumber": "1234-01",
            "acpInd": true,
            "ruralInd": false,
            "nladData": {
                "subscriberId": "LLID 3252413, NVID 3025266245, NVAP 3023241",
                "serviceDate": "11/22/2017"
            }
        },
        "LifeLineDiscounts": {
            "discounts": [
                {
                    "llarcCreditInd": true,
                    "discountCode": "MEDTAP",
                    "recurringStateCreditDesc": "ARC Recurring Credit (LLARC)",
                    "startDate": "2/20/2018",
                    "endDate": "12/31/9999",
                    "zone1Ind": true,
                    "zone2Ind": true,
                    "WireMaintanaceInd": true,
                    "actionType": "ADD"
                }
            ]
        },
        "LifeLineAdjustments": {
            "adjustments": [
                {
                    "adjustmentReason": "AJLIFE",
                    "nonRecurringStateCreditDesc": "Lifeline Adjustment (AJLIFE)",
                    "adjustmentAmount": 50,
                    "actionType": "ADD"
                }
            ]
        },
        "LifeLineMasterQualProgList": [
            {
                "lifelineQualifyingProgram": "string"
            }
        ],
        "LifeLineMasterRecurringCredits": [
            {
                "lifelineCreditType": "Recurring Credit",
                "lifeLineCreditCodeDesc": "ARC Recurring Credit (LLARC)",
                "lifeLineCreditCode": "string",
                "isSelected": true
            }
        ],
        "LifeLineMasterNonRecurringCredits": [
            {
                "lifelineCreditType": "Recurring Credit",
                "lifeLineCreditCodeDesc": "ARC Recurring Credit (LLARC)",
                "lifeLineCreditCode": "string",
                "isSelected": true
            }
        ]
    };


    public user: Observable<User>;
    public userSubscription: Subscription;
    public userInfo;
    public federalLinkToggle: boolean = false;
    public lifelineForm: any;

    constructor(private logger: Logger,
        private fb: FormBuilder,
        private helperService: HelperService,
        private store: Store<AppStore>    
    ) {
        this.nladData = '';
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.userInfo = data;
            if (this.userInfo.previousUrl === "/schedule-appt-ship" && this.userInfo.currentUrl === "/customize-services") {
                this.isRentrant = true;
            } else {
                this.isRentrant = false;
                this.isRentrant = data.reEntrant;
            }
            this.isProfileLifelineDiscount = this.helperService.isAuthorized(ProfileEnums.LIFELINE_DISCOUNT);                                           
        });
        this.existingProductStore$ = <Observable<any>>store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            if (respData && respData.orderFlow && respData.orderFlow.flow) {
                this.currentFlow = respData.orderFlow.flow;
            }
            this.existingInfo = respData;
            if (this.currentFlow === 'Change' || this.currentFlow === "Move" || this.currentFlow === "billing" || this.isAmendOrStack) {
                if (respData && respData.existingProductsAndServices && respData.existingProductsAndServices[0] &&
                    respData.existingProductsAndServices[0].accountInfo && respData.existingProductsAndServices[0].accountInfo.personalDetails) {
                    this.ssnNumber = respData.existingProductsAndServices[0].accountInfo.personalDetails.ssn && respData.existingProductsAndServices[0].accountInfo.personalDetails.ssn.slice(5, 9);
                    if (respData.existingProductsAndServices[0].accountInfo.personalDetails.dateOfBirth)
                        this.dateOfBirth = new DatePipe('en-US').transform(respData.existingProductsAndServices[0].accountInfo.personalDetails.dateOfBirth, "MM/dd/yyyy");
                }
            }

        });
    }
    public date: any;
    public removeExpDate: string = "<>9999-12-31";
    public expDate: string;
    public linkupSvcDate: string;
    public effectiveDate: string;
    public iehCertDate: string;
    public expirationDate: string;
    public anniversaryDate: string;
    public ngOnInit() {
        this.logger.metrics('InternetConfigurationPage');
        let lifelineDetainRetain = <Observable<any>>this.store.select('customize');
        lifelineDetainRetain.subscribe((data) => {
            this.lifelineInternet = data.lifelineaddedforinternet;
            this.lifelineConfigData = data.lifelineConfig;
        });
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            this.lifelineDataAdded = true;
        } else {
            this.lifelineDataAdded = false;
        }
        this.date = new Date();
        this.expDate = '9999-12-31';
        if (!this.isRentrant) {
            this.linkupSvcDate = (this.lifelineReponseData && this.lifelineReponseData.linkupSvcDate) ? this.lifelineReponseData.linkupSvcDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
            this.effectiveDate = (this.lifelineReponseData && this.lifelineReponseData.effectiveDate) ? this.lifelineReponseData.effectiveDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
            this.iehCertDate = (this.lifelineReponseData && this.lifelineReponseData.iehCertDate) ? this.lifelineReponseData.iehCertDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
            this.expirationDate = (this.lifelineReponseData && this.lifelineReponseData.expirationDate) ? this.lifelineReponseData.expirationDate : new DatePipe('en-US').transform(this.expDate, "MM/dd/yyyy");
            this.anniversaryDate = (this.lifelineReponseData && this.lifelineReponseData.anniversaryDate) ? this.lifelineReponseData.anniversaryDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
        } else {
            this.linkupSvcDate = new DatePipe('en-US').transform(this.lifelineConfigData && this.lifelineConfigData.linkupSvcDate !== undefined && this.lifelineConfigData.linkupSvcDate, "MM/dd/yyyy");
            this.effectiveDate = new DatePipe('en-US').transform(this.lifelineConfigData && this.lifelineConfigData.effectiveDate !== undefined && this.lifelineConfigData.effectiveDate, "MM/dd/yyyy");
            this.iehCertDate = new DatePipe('en-US').transform(this.lifelineConfigData && this.lifelineConfigData.iehCertDate !== undefined && this.lifelineConfigData.iehCertDate, "MM/dd/yyyy");
            this.expirationDate = new DatePipe('en-US').transform(this.lifelineConfigData && this.lifelineConfigData.expirationDate !== undefined && this.lifelineConfigData.expirationDate, "MM/dd/yyyy");
            this.anniversaryDate = new DatePipe('en-US').transform(this.lifelineConfigData && this.lifelineConfigData.anniversaryDate !== undefined && this.lifelineConfigData.anniversaryDate, "MM/dd/yyyy");
        }
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            this.existingLifelineData = true;
            if (this.lifelineReponseData.federalInd) {
                this.fedaralSelected = true;
            }
            if (this.lifelineReponseData.tribalInd) {
                this.tribalSelected = true;
            }
            if (this.lifelineReponseData.stateInd) {
                this.stateSelected = true;
            }
            if (this.lifelineReponseData.linkUpInd) {
                this.linkupSelected = true;
            }
        }
        if (this.lifelineReponseData && this.lifelineReponseData.federalInd && this.lifelineReponseData.tribalInd && this.lifelineReponseData.linkUpInd) {
            this.federalLinkToggle = true;
        } else {
            this.federalLinkToggle = false;
        }
        if (this.lifelineConfigData && this.lifelineConfigData.federalInd && this.lifelineConfigData.tribalInd && this.lifelineConfigData.linkUpInd) {
            this.federalLinkToggle = true;
        }
        if (!this.isRentrant) {
            this.lifelineForm = this.fb.group({
                firstName: [(this.lifelineReponseData && this.lifelineReponseData.firstName) ? this.lifelineReponseData.firstName : this.userInfo.firstName, [Validators.required, <any>Validations.nameValidator]],
                lastName: [(this.lifelineReponseData && this.lifelineReponseData.lastName) ? this.lifelineReponseData.lastName : this.userInfo.lastName, [Validators.required, <any>Validations.nameValidator]],
                dateOfBirth: [(this.lifelineReponseData && this.lifelineReponseData.dateOfBirth) ? new DatePipe('en-US').transform(this.lifelineReponseData.dateOfBirth, 'shortDate') : this.dateOfBirth, Validators.required],
                ssnLastFour: [(this.lifelineReponseData && this.lifelineReponseData.ssnLastFour) ? this.lifelineReponseData.ssnLastFour : this.ssnNumber, Validators.required],
                qualProg: [(this.lifelineReponseData && this.lifelineReponseData.qualProg) ? this.lifelineReponseData.qualProg : ''],
                effectiveDate: [this.effectiveDate, Validators.required],
                iehCertDate: [this.iehCertDate, Validators.required],
                expirationDate: [this.expirationDate, Validators.required],
                anniversaryDate: [this.anniversaryDate, Validators.required],
                federalInd: [(this.lifelineReponseData && this.lifelineReponseData.federalInd) ? this.lifelineReponseData.federalInd : false],
                tribalInd: [(this.lifelineReponseData && this.lifelineReponseData.tribalInd) ? this.lifelineReponseData.tribalInd : false],
                stateInd: [(this.lifelineReponseData && this.lifelineReponseData.stateInd) ? this.lifelineReponseData.stateInd : false],
                linkUpInd: [(this.lifelineReponseData && this.lifelineReponseData.linkUpInd) ? this.lifelineReponseData.linkUpInd : false],
                linkupSvcDate: [this.linkupSvcDate],
                caseNumber: [(this.lifelineReponseData && this.lifelineReponseData.caseNumber) ? this.lifelineReponseData.caseNumber : ''],
                acpInd: [(this.lifelineReponseData && this.lifelineReponseData.acpInd) ? this.lifelineReponseData.acpInd : false],
                ruralInd: [(this.lifelineReponseData && this.lifelineReponseData.ruralInd) ? this.lifelineReponseData.ruralInd : false],
                nladData: [{
                    serviceDate: [(this.lifelineReponseData && this.lifelineReponseData.nladData.serviceDate) ? this.lifelineReponseData.nladData.serviceDate : ''],
                    subscriberId: [(this.lifelineReponseData && this.lifelineReponseData.nladData.subscriberId) ? this.lifelineReponseData.nladData.subscriberId : ''],
                }]
            });
        } else {
            this.lifelineForm = this.fb.group({
                firstName: this.lifelineConfigData && this.lifelineConfigData.firstName !== undefined && this.lifelineConfigData.firstName,
                lastName: this.lifelineConfigData && this.lifelineConfigData.lastName !== undefined && this.lifelineConfigData.lastName,
                dateOfBirth: this.lifelineConfigData && this.lifelineConfigData.dateOfBirth !== undefined && new DatePipe('en-US').transform(this.lifelineConfigData.dateOfBirth, 'MM/dd/yyyy'),
                ssnLastFour: this.lifelineConfigData && this.lifelineConfigData.ssnLastFour !== undefined && this.lifelineConfigData.ssnLastFour,
                qualProg: this.lifelineConfigData && this.lifelineConfigData.qualProg !== undefined && this.lifelineConfigData.qualProg,
                effectiveDate: [this.effectiveDate, Validators.required],
                iehCertDate: [this.iehCertDate, Validators.required],
                expirationDate: [this.expirationDate, Validators.required],
                anniversaryDate: [this.anniversaryDate, Validators.required],
                federalInd: this.lifelineConfigData && this.lifelineConfigData.federalInd !== undefined && this.lifelineConfigData.federalInd,
                tribalInd: this.lifelineConfigData && this.lifelineConfigData.tribalInd !== undefined && this.lifelineConfigData.tribalInd,
                stateInd: this.lifelineConfigData && this.lifelineConfigData.stateInd !== undefined && this.lifelineConfigData.stateInd,
                linkUpInd: this.lifelineConfigData && this.lifelineConfigData.linkUpInd !== undefined && this.lifelineConfigData.linkUpInd,
                linkupSvcDate: [this.linkupSvcDate],
                caseNumber: this.lifelineConfigData && this.lifelineConfigData.caseNumber !== undefined && this.lifelineConfigData.caseNumber,
                acpInd: this.lifelineConfigData && this.lifelineConfigData.acpInd !== undefined && this.lifelineConfigData.acpInd,
                ruralInd: this.lifelineConfigData && this.lifelineConfigData.ruralInd !== undefined && this.lifelineConfigData.ruralInd,
                nladData: [{
                    serviceDate: this.lifelineConfigData && this.lifelineConfigData.serviceDate !== undefined && this.lifelineConfigData.serviceDate,
                    subscriberId: this.lifelineConfigData && this.lifelineConfigData.subscriberId !== undefined && this.lifelineConfigData.subscriberId,
                }]
            });
        }
    }
    public existinglifelineExpand() {
        this.lifelineInternetExpand = true;
        this.expandLifelineContinue.emit(this.lifelineInternetExpand);
    }
    public errors = {
        tnForm: {
            error: false,
            message: '',
            charterCable: false,
            unVerifiedAddress: false,
            unVerifiedNumber: false,
            notPortable: false,
            tnConfirmClicked: false,
            verifiedNumber: false,
            validateOffline: false,
            showRetainOption: true
        },
        listingForm: { error: false, message: '' },
        ldCarrierForm: { error: false, message: '' },
        additionalConfig: { error: false, message: '' },
        callForwarding: { error: false, message: '' }
    }

    public validate(a, b, c, d, e, f, current) {
        if (this.errors.tnForm.error && current !== 0) {
            a.isOpen = true;
            b.isOpen = current === 1 ? true : false;
            c.isOpen = current === 2 ? true : false;
            d.isOpen = current === 3 ? true : false;
            e.isOpen = current === 4 ? true : false;
            f.isOpen = current === 5 ? true : false;
        } else if (this.errors.tnForm.error) {
            a.isOpen = false;
        }
        if (this.lifelineForm.get("federalInd").value) {
            this.fedaralSelected = true;
        } else {
            this.fedaralSelected = false;
        }
        if (this.lifelineForm.get("tribalInd").value) {
            this.tribalSelected = true;
        } else {
            this.tribalSelected = false;
        }
        if (this.lifelineForm.get("stateInd").value) {
            this.stateSelected = true;
        } else {
            this.stateSelected = false;
        }
        if (this.lifelineForm.get("linkUpInd").value) {
            this.linkupSelected = true;
        } else {
            this.linkupSelected = false;
        }
    }
    public subLifelineData() {
        if (this.lifelineForm.valid) {
            this.submitLifelineData();
        } else {
            this.validLifelineData = true;
            this.lifelineSubmitted = true;
        }
        if (this.federalChecked && this.lifelineForm.get("qualProg").value === "") {
            this.validLifelineData = true;
            this.lifelineSubmitted = true;
        } else if (this.lifelineForm.get("qualProg").value !== "") {
            this.validLifelineData = false;
            this.lifelineSubmitted = false;
        }
        this.clickLifelineContinue.emit(this.validLifelineData);
    }
    public clickDoneButton() {
        if (this.lifelineForm.get("federalInd").value) {
            this.fedaralSelected = true;
        } else {
            this.fedaralSelected = false;
        }
        if (this.lifelineForm.get("tribalInd").value) {
            this.tribalSelected = true;
        } else {
            this.tribalSelected = false;
        }
        if (this.lifelineForm.get("stateInd").value) {
            this.stateSelected = true;
        } else {
            this.stateSelected = false;
        }
        if (this.lifelineForm.get("linkUpInd").value) {
            this.linkupSelected = true;
        } else {
            this.linkupSelected = false;
        }
        this.subLifelineData();
    }
    public submitLifelineData(lifelineRemove?) {
        let lifelineDetainRetain = <Observable<any>>this.store.select('customize');
        lifelineDetainRetain.subscribe((data) => {
            this.custData = data;
        });
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            if (!this.nladDateResponse) {
                this.saveLifelineUpdates = this.lifelineReponseData.nladData ? this.lifelineReponseData.nladData : null;
            }
        }
        if (this.isRentrant) {
            if (!this.nladDateResponse) {
                this.saveLifelineUpdates = this.custData.lifelineConfig.nladData;
            }
            if (!this.adjustmentsResponse) {
                this.discountsUpdates = this.custData.lifelineDiscounts.discounts;
                this.adjustmentsUpdates = this.custData.lifelineAdjustment.adjustments;
            }
        }
        this.lifelineConfigObj = {
            firstName: this.lifelineForm.get('firstName').value,
            lastName: this.lifelineForm.get('lastName').value,
            dateOfBirth: new DatePipe('en-US').transform(this.lifelineForm.get('dateOfBirth').value, "yyyy-MM-dd"),
            ssnLastFour: this.lifelineForm.get('ssnLastFour').value,
            federalInd: this.lifelineForm.get("federalInd").value,
            tribalInd: this.lifelineForm.get("tribalInd").value,
            stateInd: this.lifelineForm.get("stateInd").value,
            linkUpInd: this.lifelineForm.get("linkUpInd").value,
            linkupSvcDate: (this.lifelineForm.get("tribalInd").value === true && this.lifelineForm.get("federalInd").value === true && this.lifelineForm.get("linkUpInd").value === true) ? new DatePipe('en-US').transform(this.linkupSvcDate, "yyyy-MM-dd") : undefined,
            qualProg: this.lifelineForm.get("qualProg").value,
            effectiveDate: new DatePipe('en-US').transform(this.effectiveDate, "yyyy-MM-dd"),
            iehCertDate: new DatePipe('en-US').transform(this.iehCertDate, "yyyy-MM-dd"),
            expirationDate: new DatePipe('en-US').transform(this.expirationDate, "yyyy-MM-dd"),
            anniversaryDate: new DatePipe('en-US').transform(this.anniversaryDate, "yyyy-MM-dd"),
            caseNumber: this.lifelineForm.get('caseNumber').value,
            acpInd: this.lifelineForm.get('acpInd').value,
            ruralInd: this.lifelineForm.get('ruralInd').value,
            nladData: this.saveLifelineUpdates ? this.saveLifelineUpdates : null
        };

        if (this.discountChanges && !this.expLifelineSelected || this.lifelineRespData === null || this.lifelineRespData === undefined) {
            this.LifeLineDiscounts = {
                discounts: this.discountsUpdates ? this.discountsUpdates : null
            }
        } else if (!this.discountChanges && !this.expLifelineSelected && this.lifelineRespData && this.lifelineRespData !== null && !this.removeInternetLifeline) {
            this.lifelineRespData.discounts.map((item) => {
                item.actionType = "NOCHANGE";
            })
            this.LifeLineDiscounts = {
                discounts: this.lifelineRespData.discounts
            }
        } else if ((this.expLifelineSelected || this.removeInternetLifeline) && this.lifelineRespData && this.lifelineRespData !== null) {
            this.lifelineRespData.discounts.map((item) => {
                item.actionType = "REMOVE";
                item.llarcCreditInd = false;
                item.endDate = new DatePipe('en-US').transform(this.expirationDate, "yyyy-MM-dd");
            })
            this.LifeLineDiscounts = {
                discounts: this.lifelineRespData.discounts
            }
        }
        this.LifeLineAdjustments = {
            adjustments: this.adjustmentsUpdates ? this.adjustmentsUpdates : null
        }
        if (lifelineRemove) {
            this.lifelineConfigObj.federalInd = false;
            this.lifelineConfigObj.tribalInd = false;
            this.lifelineConfigObj.stateInd = false;
            this.lifelineConfigObj.linkUpInd = false;
            this.lifelineConfigObj.acpInd = false;
            this.lifelineConfigObj.ruralInd = false;
            this.lifelineConfigObj.qualProg = "EXP:Expire Lifeline";
            this.expLifelineSelected = true;
            this.lifelineConfigObj.expirationDate = this.removeExpDate;
            this.LifeLineDiscounts.discounts.map((data) => {
                data.endDate = this.lifelineConfigObj.expirationDate;
            })
        }
        this.store.dispatch({ type: 'LIFELINE_CONFIG', payload: this.lifelineConfigObj });
        this.store.dispatch({ type: 'LIFELINE_CONFIG_DISCOUNTS', payload: this.LifeLineDiscounts });
        this.store.dispatch({ type: 'LIFELINE_CONFIG_ADJUSTMENTS', payload: this.LifeLineAdjustments });
        this.validLifelineData = false;

    }
    public onSaveNLADUpdate(event) {
        this.nladDateResponse = true;
        this.saveLifelineUpdates = event;
        this.saveLifelineUpdates[0].serviceDate = new DatePipe('en-US').transform(this.saveLifelineUpdates[0].serviceDate, "yyyy-MM-dd");
    }
    public onSaveDiscountsUpdate(event) {
        this.adjustmentsResponse = true;
        this.discountsLifelineData = event;
        let disc;
        let adjustment = {};
        let adjustments = [];
        let one = Object.keys(this.discountsLifelineData.controls);
        for (let field of one) {
            if (field === 'adjustmentReason' || field === 'nonRecurringStateCreditDesc' || field === 'adjustmentAmount' || field === 'actionType') {
                disc = this.discountsLifelineData.get(field).value;
                adjustment[field] = disc;
            }
        }

        adjustments.push(adjustment);
        this.adjustmentsUpdates = adjustments;
        this.adjustmentsUpdates[0].adjustmentReason = this.adjustmentsUpdates[0].nonRecurringStateCreditDesc.substring(this.adjustmentsUpdates[0].nonRecurringStateCreditDesc.lastIndexOf('('), this.adjustmentsUpdates[0].nonRecurringStateCreditDesc.length).replace(/[\(\)]/g, "");
    }
    public onsaveDiscouts(event) {
        this.discountChanges = true;
        this.discountsUpdates = event;
        this.discountsUpdates.forEach((data) => {
            if (data.recurringStateCreditDesc === "AZ Medical (AZMEDI)") {
                this.azmediOptionSelected = true;
            } else {
                this.azmediOptionSelected = false;
            }
        });
    }
    public tribalChange(event) {
        if (event.target.checked) {
            this.lifelineForm.get("federalInd").setValue(true);
        }
        this.federalLinkUp(event);
    }
    public federalChange(event) {
        if (!event.target.checked) {
            this.lifelineForm.get("tribalInd").setValue(false);
        }
        this.federalLinkUp(event);
        if (event.target.checked) {
            this.federalChecked = true;
        } else {
            this.federalChecked = false;
        }
    }
    public federalLinkUp(event) {
        if (this.lifelineForm.get("federalInd").value && this.lifelineForm.get("tribalInd").value && this.lifelineForm.get("linkUpInd").value) {
            this.federalLinkToggle = true;
        } else {
            this.federalLinkToggle = false;
        }
    }
    public effectiveDateUpdated(event) {
        this.effectiveDate = event;
        this.anniversaryDate = event;
        this.iehCertDate = event;
    }
    public IEHCertifiedUpdated(event) {
        this.iehCertDate = event;
    }
    public expirationUpdated(event) {
        this.expirationDate = event;
    }
    public anniversaryUpdated(event) {
        this.anniversaryDate = event;
    }
    public federalLinkDateUpdated(event) {
        this.linkupSvcDate = event;
    }
    public onChangeQualProgList(program) {
        this.federalChecked = false;
        this.lifelineSubmitted = false;
        if (!this.lifelineReponseData && this.lifelineReponseData === null || this.lifelineReponseData === undefined) {
            if (program === "EXP:Expire Lifeline") {
                this.expLifelineSelected = true;
                if (this.expLifelineSelected) {
                    this.expirationDate = new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
                }
            }
        }
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            if (program === "EXP:Expire Lifeline") {
                this.expLifelineSelected = true;
                if (this.expLifelineSelected) {
                    this.lifelineForm.get('federalInd').setValue(false);
                    this.lifelineForm.get('tribalInd').setValue(false);
                    this.lifelineForm.get('stateInd').setValue(false);
                    this.lifelineForm.get('linkUpInd').setValue(false);
                    this.lifelineForm.get('acpInd').setValue(false);
                    this.lifelineForm.get('ruralInd').setValue(false);
                    this.expirationDate = new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
                }
            } else if (program !== "EXP:Expire Lifeline") {
                this.expLifelineSelected = false;
                this.federalChecked = false;
                this.lifelineSubmitted = false;
                if (!this.expLifelineSelected && this.lifelineReponseData && this.lifelineReponseData !== null) {
                    this.lifelineForm.get('federalInd').setValue(this.lifelineReponseData.federalInd);
                    this.lifelineForm.get('tribalInd').setValue(this.lifelineReponseData.tribalInd);
                    this.lifelineForm.get('stateInd').setValue(this.lifelineReponseData.stateInd);
                    this.lifelineForm.get('linkUpInd').setValue(this.lifelineReponseData.linkUpInd);
                    this.lifelineForm.get('acpInd').setValue(this.lifelineReponseData.acpInd);
                    this.lifelineForm.get('ruralInd').setValue(this.lifelineReponseData.ruralInd);
                    this.expirationDate = new DatePipe('en-US').transform(this.lifelineReponseData.expirationDate, "MM/dd/yyyy");
                }
            }
        }
    }
    public enableAZMEDIoption: boolean = false;
    public enableAZMEDIChange(event) {
        if (this.lifelineForm.get("federalInd").value || this.lifelineForm.get("stateInd").value) {
            this.enableAZMEDIoption = true;
        } else {
            this.enableAZMEDIoption = false;
        }
    }
    public hideLifeline() {
        this.lifelineDataAdded = false;
        this.lifeLineHideInternet = false;
        this.lifeLineRemove.emit(false);
        this.newLifelineRemoved = true;
        this.removeInternetLifeline = true;
        this.removeLifelineContinue.emit(this.removeInternetLifeline);
        this.lifelineForm = this.fb.group({
            firstName: [(this.lifelineReponseData && this.lifelineReponseData.firstName) ? this.lifelineReponseData.firstName : this.userInfo.firstName, [Validators.required, <any>Validations.nameValidator]],
            lastName: [(this.lifelineReponseData && this.lifelineReponseData.lastName) ? this.lifelineReponseData.lastName : this.userInfo.lastName, [Validators.required, <any>Validations.nameValidator]],
            dateOfBirth: [(this.lifelineReponseData && this.lifelineReponseData.dateOfBirth) ? new DatePipe('en-US').transform(this.lifelineReponseData.dateOfBirth, 'shortDate') : this.dateOfBirth, Validators.required],
            ssnLastFour: [(this.lifelineReponseData && this.lifelineReponseData.ssnLastFour) ? this.lifelineReponseData.ssnLastFour : this.ssnNumber, Validators.required],
            qualProg: [(this.lifelineReponseData && this.lifelineReponseData.qualProg) ? this.lifelineReponseData.qualProg : ''],
            effectiveDate: [this.effectiveDate, Validators.required],
            iehCertDate: [this.iehCertDate, Validators.required],
            expirationDate: [this.expirationDate, Validators.required],
            anniversaryDate: [this.anniversaryDate, Validators.required],
            federalInd: [(this.lifelineReponseData && this.lifelineReponseData.federalInd) ? this.lifelineReponseData.federalInd : false],
            tribalInd: [(this.lifelineReponseData && this.lifelineReponseData.tribalInd) ? this.lifelineReponseData.tribalInd : false],
            stateInd: [(this.lifelineReponseData && this.lifelineReponseData.stateInd) ? this.lifelineReponseData.stateInd : false],
            linkUpInd: [(this.lifelineReponseData && this.lifelineReponseData.linkUpInd) ? this.lifelineReponseData.linkUpInd : false],
            linkupSvcDate: [this.linkupSvcDate],
            caseNumber: [(this.lifelineReponseData && this.lifelineReponseData.caseNumber) ? this.lifelineReponseData.caseNumber : ''],
            acpInd: [(this.lifelineReponseData && this.lifelineReponseData.acpInd) ? this.lifelineReponseData.acpInd : false],
            ruralInd: [(this.lifelineReponseData && this.lifelineReponseData.ruralInd) ? this.lifelineReponseData.ruralInd : false],
            nladData: [{
                serviceDate: [(this.lifelineReponseData && this.lifelineReponseData.nladData.serviceDate) ? this.lifelineReponseData.nladData.serviceDate : ''],
                subscriberId: [(this.lifelineReponseData && this.lifelineReponseData.nladData.subscriberId) ? this.lifelineReponseData.nladData.subscriberId : ''],
            }]
        });
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
    }
}
