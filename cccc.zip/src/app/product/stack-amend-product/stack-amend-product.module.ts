import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { StackAmendProductComponent } from './stack-amend-product.component';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { SharedModule } from '../../shared/shared.module';
import { TooltipModule } from 'ngx-bootstrap';
import { TextMaskService } from '../../common/service/text-mask.service';

const routes: Routes = [
    {
        path: '', component: StackAmendProductComponent
    }
];

@NgModule({
    imports: [FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        SharedModule,
        SharedCommonModule,
        TooltipModule.forRoot()
    ],
    exports: [
        StackAmendProductComponent
    ],
    declarations: [
        StackAmendProductComponent
    ],
    providers: [TextMaskService]
})

export class StackAmendProductModule { }
