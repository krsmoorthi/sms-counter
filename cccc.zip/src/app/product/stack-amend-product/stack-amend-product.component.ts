import { Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { OfferVariables } from 'app/common/models/offers.model';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { HelperService } from "app/common/service/helper.service";
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStore } from 'app/common/models/appstore.model';
import { CustomerOrderItems, CustomerOrderSubItem, ShoppingCart } from 'app/common/models/cart.model';
import { GenericValues, Switch } from 'app/common/models/common.model';
import { AttributesCombination, CompositeAttribute, filterObjModel, OfferGroup, OfferProductComponents, Product, ProductOfferings, Products, ServiceCategoryBasedOffers, ServiceCategoryId } from 'app/common/models/product.model';
import { User } from 'app/common/models/user.model';
import { AppStateService } from 'app/common/service/app-state.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { AppConstant, RE_ENTRANT_OFFERVARIABLE } from 'app/app.constant';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { VacationEnums } from 'app/common/enums/vacationEnums';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";
import * as _ from 'lodash';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums';
@Component({
    selector: 'stack-amend-product',
    styleUrls: ['./../offer.component.scss'],
    templateUrl: './stack-amend-product.component.html'
})

export class StackAmendProductComponent implements OnInit, OnDestroy, AfterViewInit {
    public amendCurrentSpeed: any;
    public offerVariables: OfferVariables;
    public lifelineDHPExisting: boolean = false;
    public lifelinePOTSExisting: boolean = false;
    public lifelineHSIExisting: boolean = false;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    public removal: any = {};
    public currentTechnology: any;
    public dropName: string = "All Speed options";
    public filterObj: filterObjModel = {
        name: "All Speed options",
        isExist: true
    };
    public user: Observable<User>;
    public userSubscription: Subscription;
    public userSubscription1: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public pendingSubscription: Subscription;
    public pendingObservable: Observable<any>;
    public optedOutCheck: boolean = false;
    public internetOffer: boolean;
    public serviceSpec: ServiceCategoryId[] = [];
    public selectedTech: any = "na";
    public discountedPrice: number;
    public discountedInternetOtcPrice: number;
    public discountedTVOtcPrice: number;
    public selectedVideoOfferdId: string;
    public selectedDHPOfferdId: string;
    public serviceUnavailable: string;
    public directvAccountId: any = '';
    public productPriceValues: any;
    public selectedGroup: OfferGroup;
    // public speedList: any[] = [];
    public tvList: string[] = [];
    public selectedModemArr: string[] = [];
    public selectedInstallationArr: string[] = [];
    public selectedEaseArr: string[] = [];
    public intraStateFee: Products;
    public maxWSTB: string[] = [];
    public selectedVideoOfferPrice: number;
    public selectedDHPOfferPrice: number;
    public selectedPhoneOfferPrice: number;
    public selected: string;
    public isShowRemoveRetentionDiscountMsg: boolean = false;
    public existingDiscounts: any = {};
    public hsiRemovedRetentiondiscounts: any = [];
    public existingRetentionDiscounts: any = [];
    public dataLink: ServiceCategoryBasedOffers;
    public videoLink: ServiceCategoryBasedOffers;
    public dtvLink: ServiceCategoryBasedOffers;
    public attrCombinations: AttributesCombination[] = [];
    public callingFeatures: OfferProductComponents;
    public phoneArray: any = [];
    public videoArray: any = [];
    private initialOfferResponse: Product;
    public removeMessage;
    public productToRemove;
    public existingPreviousServices: any;
    public existingProductName: string = '';
    public existingProductContract: number;
    public moreServices: any;
    public removeResponse: any[];
    public preserveHSI: any;
    public removeSelectedReason: any;
    public wireMaintainanceExist: boolean = false;
    public dtvExisting: boolean = false;
    public existingAddonsHSI: any;
    public selectedModemToShow: Products;
    public isDHP: boolean = false;
    public hsiOnlyPresent: boolean = false;
    public disconnectReq: any = {};
    public hsiExisting: boolean = false;
    public configSubmited = false;
    public cartCopyObject: ShoppingCart;
    public isE911Called: boolean = false;
    public reentrantUI: boolean = false;
    @ViewChild("removeProduct", { static: false, }) public removeProduct: any;
    @ViewChild("e911Validation", { static: false, }) public e911Validation: any;
    @ViewChild("removeProduct", { static: false, }) public removeProductOpen: any;
    @ViewChild('voiceMailInput', { static: false, }) public voiceMailInput: ElementRef;
    @ViewChild('wireMaintainanceInput', { static: false, }) public wireMaintainanceInput: ElementRef;
    @ViewChild('portingInput', { static: false, }) public portingInput: ElementRef;
    @ViewChild('easeSelected', { static: false, }) public easeSelected: ElementRef;
    @ViewChild('optOutPopup', { static: false, }) public optOutPopUp: DialogComponent;
    @ViewChild('secureWifiSelected', { static: false, }) public secureWifiSelected: ElementRef;
    public offerNoLongerAvailable: string = '';
    public existingTN;
    public deviceQuantitySelected: any;
    public orderObservable: Observable<any>;
    public orderSubscription: Subscription;
    public firstName: string;
    private lastName: string;
    private ensembleId: string;
    private agentCuid: string;
    public offerName: string;
    public fromHold: boolean = false;
    public EaseDefault: boolean;
    public secureWifiDefault: boolean;
    public modemClass: string = '';
    public newPhoneUpdated: boolean;
    public newVideoSelected: string;
    public isSalesExpiredMessageNeedtoHide: boolean = false;
    public speedselected: string;
    public qualifiedUnfilter: any;
    public unQualifiedOffers: any;
    public isProfileBypassLoopQual: boolean;
    public isProfileBypassHSISpeeds: boolean;
    public byPassBool = false;
    public amendmessage = AppConstant.AMEND_MESSAGE;
    // public existingData: any;
    public isCanAddPots: string;
    public isCanAddCvoip: string;
    public hasTechnology = false;
    public isCanRemoveCvoip: string;
    public con: any;
    public technologyTypes: any;
    public retainInstallOption: any;
    public retainVoiceMail: any;
    public dTvRemoveAction: boolean = false;

    public disclosureArrList: any[] = [];
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    public disableEase: boolean = false;
    public sup3AllowedOnCon: string;
    public enableAddPotsForAmend: boolean;

    constructor(
        private logger: Logger,
        public store: Store<AppStore>,
        private router: Router,
        private productService: ProductService,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private disconnectServiceCall: DisconnectService,
        private bMService: BlueMarbleService,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
        public offerHelperService: OfferHelperService,
        public propertiesHelperService: PropertiesHelperService
    ) {
        this.initilizeAll();
    }

    public initilizeAll() {
        this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);
        this.isProfileBypassLoopQual = this.helperService.isAuthorized(ProfileEnums.BYPASS_LOOP_QUAL);
        this.isProfileBypassHSISpeeds = this.helperService.isAuthorized(ProfileEnums.BYPASS_HSI_SPEEDS);
        this.offerVariables.amendForHSI = this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_AMEND_ON_HSI);
        //to be removed once property added in db
        this.offerVariables.amendForHSI = true;
        this.appStateService.setLocationURLs();
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.pendingObservable = <Observable<any>>this.store.select('pending');
        this.orderObservable = <Observable<any>>this.store.select('order');
        this.offerVariables.existingModem = undefined;
        this.offerVariables.currentComponentName = "stack-amend-product.component.ts";
        this.offerVariables.discountedPriceList = [];
        this.internetOffer = true;
        this.offerVariables.internetAvail = false;
        this.offerVariables.videoAvail = false;
        this.offerVariables.phoneAvail = false;
        this.offerVariables.selectedModemToShow = null;
        this.offerVariables.videoSelected = 'NoTV';
        this.offerVariables.newVideoSelected = 'NoTV';
        this.offerVariables.phoneSelected = GenericValues.noPhone;
        this.offerVariables.newPhoneSelected = GenericValues.noPhone;
        this.offerVariables.offersGenerated = true;
        this.offerVariables.voiceMailValue = 'na';
        this.serviceUnavailable = 'Service not available for your Address';
        let prod: Products = {
            productId: '608',
            productName: 'Intrastate Service Fee',
            productType: 'Service',
            isRegulated: false
        };
        let state: boolean = false;
        this.enableAddPotsForAmend = Switch.enableAddPotsForAmend;
        this.orderSubscription = this.orderObservable.subscribe(ord => {
            this.offerVariables.isCustomize = ord.taskName === 'Checkout & Scheduling' ? true : false;
        });
        this.intraStateFee = prod;
        this.pendingSubscription = this.pendingObservable.subscribe(pending => {
            if (pending && pending.orderReference && pending.orderReference.customerOrderType === 'NEWINSTALL') {
                this.offerVariables.isLatestPendingOrderNI = true;
            }
            this.con = pending && pending.orderReference && pending.orderReference.customerOrderNumber ? pending.orderReference.customerOrderNumber : "";
            this.offerVariables.holdedObjects = cloneDeep(pending);
        });
        if (this.pendingSubscription !== undefined) this.pendingSubscription.unsubscribe();
        this.existingSubscription = this.existingObservable.subscribe(
            (data) => {
                this.offerVariables.existingData = data;
                if (data && data.sup3AllowedOnCon) {
                    this.sup3AllowedOnCon = data.sup3AllowedOnCon;
                }
                if (data && data.NIPendingStackAmend) {
                    this.offerVariables.NIPendingStackAmend = data.NIPendingStackAmend;
                }
                if (data && data.stackamend && data.stackamend.stackAmendFlag === 'stackOrder') {
                    this.offerVariables.isStack = true;
                    data.existingProductsAndServices[0].validateResponse && data.existingProductsAndServices[0].validateResponse[0].stackValidation.forEach(a => {
                        if (a.attributeName === "canAddCvoip") { this.isCanAddCvoip = a.attributeValue; }
                        if (a.attributeName === "canRemoveCvoip") { this.isCanRemoveCvoip = a.attributeValue; }
                        if (a.attributeName === "canAddPots") { this.isCanAddPots = a.attributeValue; }
                    });
                    if (data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders) {
                        let orderDocument;
                        if (data.existingProductsAndServices[0].pendingOrders.length > 1) {
                            data.existingProductsAndServices[0].pendingOrders.forEach(pendingOrder => {
                                if (pendingOrder.orderReference && pendingOrder.orderReference.customerOrderNumber && this.sup3AllowedOnCon && pendingOrder.orderReference.customerOrderNumber === this.sup3AllowedOnCon) {
                                    orderDocument = pendingOrder.orderDocument;
                                }
                            });
                        } else if (data.existingProductsAndServices[0].pendingOrders.length > 0) {
                            orderDocument = data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders && data.existingProductsAndServices[0].pendingOrders[0].orderDocument;
                        }
                        if (orderDocument && orderDocument.existingServices && (orderDocument.existingServices.length > 0)) {
                            orderDocument.existingServices.forEach(existsService => {
                                if (existsService && existsService.offerCategory === 'INTERNET' && existsService.offerType !== 'SUBOFFER') {
                                    if (existsService.customerOrderSubItems && existsService.customerOrderSubItems.length && (existsService.customerOrderSubItems.length > 0)) {
                                        existsService.customerOrderSubItems.forEach(custOrderItem => {
                                            if (custOrderItem && custOrderItem.productName && (custOrderItem.productName === 'MODEM')) {
                                                if (custOrderItem.action === 'NOCHANGE') {
                                                    this.offerVariables.isExistingModemChanged = false;
                                                } else {
                                                    this.offerVariables.isExistingModemChanged = true;
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    }
                } else if (data && data.stackamend && data.stackamend.stackAmendFlag === 'amendOrder') {
                    if (data.orderFlow && data.orderFlow.flow === "Change" && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].pendingOrders) {
                        if (data.existingProductsAndServices[0].pendingOrders.length > 1) {
                            data.existingProductsAndServices[0].pendingOrders.forEach(pendingOrder => {
                                if (pendingOrder.orderReference && pendingOrder.orderReference.customerOrderNumber && this.sup3AllowedOnCon && pendingOrder.orderReference.customerOrderNumber === this.sup3AllowedOnCon) {
                                    this.offerVariables.holdedObjects = pendingOrder;
                                }
                            });
                        } else if (data.existingProductsAndServices[0].pendingOrders.length > 0) {
                            this.offerVariables.holdedObjects = data.existingProductsAndServices[0].pendingOrders[0];
                        }
                    }
                    this.offerVariables.isAmend = true;
                }
                if (data && data.orderFlow && data.orderFlow.flow)
                    this.offerVariables.flow = 'stackAmend'
                if (data.orderFlow.type === 'fromHold') {
                    this.fromHold = true;
                }
                if (data) {
                    if (data.existingDiscounts) {
                        this.offerVariables.existingDiscounts = data.existingDiscounts;
                    }
                    if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo
                        && data.existingProductsAndServices[0].accountInfo.billingType) {
                        this.offerVariables.offerBillingType = data.existingProductsAndServices[0].accountInfo.billingType === "PREPAID" ? data.existingProductsAndServices[0].accountInfo.billingType : "POSTPAID";
                    }
                }

                if (!this.offerVariables.isLatestPendingOrderNI) {
                    this.getRemoveResponse();
                }
                if (data && data.orderFlow && this.offerVariables.isStack && this.offerVariables.isAmend && this.fromHold && !data.orderFlow.selectProductCalled && !this.offerVariables.holdCalled) {
                    this.offerVariables.holdCalled = true;
                    this.pendingSubscription = this.pendingObservable.subscribe(pending => {
                        let inputAddress: any;
                        inputAddress = {
                            addressLine: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetAddress,
                            unitNumber: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.subAddress
                                && pending.orderDocument.serviceAddress.subAddress.combinedDesignator,
                            stateOrProvince: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.stateOrProvince,
                            city: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.city,
                            postCode: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.zipCode,
                            singleLine: true,
                        };
                        this.offerVariables.holdedObjects = pending;
                        this.offerVariables.loading = true;
                        this.logger.startTime();
                        this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(inputAddress));
                        state = this.callApiForChange(this.store, state, data);
                    })
                    if (this.pendingSubscription !== undefined) this.pendingSubscription.unsubscribe();
                } else {
                    state = this.callApiForChange(this.store, state, data);
                }
                if (data && data.existingOfferName) {
                    this.offerVariables.existingOfferName = data.existingOfferName;
                }

            });
        if (this.existingSubscription !== undefined) {
            this.existingSubscription.unsubscribe();
        }
    }
    public ngAfterViewInit() {
        this.offerVariables.currentFlow = "STACK_AMEND";
    }

    public callApiForChange(store: Store<AppStore>, state: boolean, data: any) {
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription1 = this.user.subscribe(
            (data) => {
                this.offerVariables.isDtvOpus = data.isDtvOpus;
                if (data.selfinstallselected) this.offerVariables.selfinstallSelected = true;
                if (data && data.existsServices && data.existsServices.indexOf('INTERNET') > -1) {
                    this.offerVariables.isHSIExistingProduct = true;
                }
            });
        if (data.orderInit && data.orderInit.payload && data.orderInit.payload.productConfiguration) {
            this.offerVariables.productConfiguration = data.orderInit.payload.productConfiguration;
        }
        //To get Modem make and model
        let products: any;

        if (data && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && !this.offerVariables.NIPendingStackAmend) {
            products = data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems;
            this.retrieveModemModel(products, false);
        }
        if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.existingServices
            && data.orderInit.payload.existingServices.existingServiceItems) {
            this.offerVariables.existingServices = data.orderInit.payload.existingServices.existingServiceItems;
            this.offerVariables.existingServicesForRemove = data.orderInit.payload.existingServices.existingServiceItems;
            if (this.offerVariables.existingServicesForRemove && this.offerVariables.existingServicesForRemove.length > 0) {
                this.offerVariables.existingServicesForRemove.forEach(item => {
                    item.offerCategory === GenericValues.cHP ? this.offerVariables.potsExistingOnCompleted = true: this.offerVariables.hsiExistingOnCompleted = true;
                })
            }
        }
        if (this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument && this.offerVariables.holdedObjects.orderDocument.customerOrderItems) {
            this.offerVariables.existingServices = this.offerVariables.holdedObjects.orderDocument.customerOrderItems;
        }
        if (this.offerVariables.existingData && this.offerVariables.existingData.pendingOrders && this.offerVariables.existingData.pendingOrders.length > 1 && this.offerVariables.isAmend) {
            this.offerVariables.existingServicesForAction = data.orderInit.payload.existingServices.existingServiceItems;
        }
        if (this.offerVariables.NIPendingStackAmend) {
            let existingItems: any;
            if (this.offerVariables.holdCalled && data && data.orderDocument.customerOrderItems) {
                existingItems = data.orderDocument.customerOrderItems;
            } else if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.existingServices && data.orderInit.payload.existingServices.existingServiceItems
                && data.orderInit.payload.existingServices.existingServiceItems !== null && !this.offerVariables.isAmend && this.offerVariables.isStack) {
                existingItems = data.orderInit.payload.existingServices.existingServiceItems;
            } else if (this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument && this.offerVariables.holdedObjects.orderDocument.customerOrderItems && this.offerVariables.isAmend && !this.offerVariables.isStack) {
                existingItems = this.offerVariables.holdedObjects.orderDocument.customerOrderItems;
                if (!this.offerVariables.existingServices || this.offerVariables.existingServices === null) this.offerVariables.existingServices = existingItems;
            }
            if (!existingItems && this.offerVariables.existingServices) existingItems = this.offerVariables.existingServices;
            this.retrieveModemModel(existingItems && existingItems[0] && existingItems[0].customerOrderSubItems, false);
            this.dropDownPopulationforHP(existingItems, false);
            this.offerHelperService.existingProductConfigCheck(this.offerVariables, this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument);
        } else if (this.offerVariables.isAmend && !this.offerVariables.NIPendingStackAmend) {
            let existingItems: any;
            existingItems = this.offerVariables.holdedObjects.orderDocument.customerOrderItems
            this.offerVariables.existingServices = existingItems;
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.existingServices &&
                data.orderInit.payload.existingServices.existingServiceItems && data.orderInit.payload.existingServices.existingServiceItems.length > 0)
                data.orderInit.payload.existingServices.existingServiceItems.forEach(existsService => {
                    if (existsService.offerCategory === 'INTERNET' && existsService.offerType !== 'SUBOFFER') {
                        existsService.customerOrderSubItems && existsService.customerOrderSubItems.length > 0 && existsService.customerOrderSubItems.forEach(custSubItem => {
                            if (custSubItem && custSubItem.componentType === 'PRIMARY') {
                                this.amendCurrentSpeed = custSubItem.productName;
                            }
                        });
                    }
                })
        } else {
            this.offerVariables.holdCalled && data && data.existingProductsAndServices && data.existingProductsAndServices.forEach((item) => {
                let existingItems: any;
                if (data.orderFlow.type === 'fromHold') {
                    existingItems = this.offerVariables.holdedObjects.orderDocument.existingServices;
                } else if (item && item.existingServices && item.existingServices.existingServiceItems &&
                    item.existingServices.existingServiceItems !== null) {
                    existingItems = item.existingServices.existingServiceItems;
                } else if (this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument && this.offerVariables.holdedObjects.orderDocument.existingServices) {
                    existingItems = this.offerVariables.holdedObjects.orderDocument.existingServices;
                    if (!this.offerVariables.existingServices || this.offerVariables.existingServices === null) this.offerVariables.existingServices = existingItems;
                }
                this.dropDownPopulationforHP(existingItems, false);
                this.offerHelperService.existingProductConfigCheck(this.offerVariables, item);
            })
        }

        this.offerVariables.isAmend && this.offerVariables.existingServices && this.offerVariables.existingServices.forEach(item => {
            if (item.action === 'ADD' && (item.offerCategory === GenericValues.iData || item.offerCategory === GenericValues.sData)) {
                this.offerVariables.internetAddAction = true;
            }
            if (item.action === 'ADD' && item.offerCategory === GenericValues.cHP) {
                this.offerVariables.potsAddAction = true;
            }
            if (item.action === 'REMOVE' && item.offerCategory === GenericValues.cHP) {
                this.offerVariables.potsRemoveAction = true;
                this.offerVariables.previousRemovedItems.push(item);
            }
            if (item.action === 'REMOVE' && item.offerCategory === GenericValues.cDHP) {
                this.offerVariables.cvoipRemoveAction = true;
                this.offerVariables.previousRemovedItems.push(item);
            }
            if (item.action === 'REMOVE' && item.offerCategory === GenericValues.cDTV) {
                this.dTvRemoveAction = true;
                this.offerVariables.previousRemovedItems.push(item);
            }
        })
        this.offerVariables.retainedPotsBooleans = {
            retainValueForPotsJack: this.offerVariables.retainValueForPotsJack
        }
        if (this.offerVariables.undoSelected) {
            this.offerVariables.voiceMailValue = 'No';
            this.offerVariables.voiceMailCondi = false;
            this.offerVariables.voiceMail = false;
            this.offerVariables.wireMaintainCondi = false;
            this.offerVariables.wireMaintainance = false;
            if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.retainValueForPotsJack) this.offerVariables.retainedPotsBooleans.retainValueForPotsJack = undefined;
        }

        if (this.offerVariables.holdCalled && this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument && this.offerVariables.holdedObjects.orderDocument.customerOrderItems) {
            let existingItems = this.offerVariables.holdedObjects.orderDocument.customerOrderItems;
            this.dropDownPopulationforHP(existingItems, true);
        }
        if (!this.offerVariables.holdCalled && this.offerVariables.existingServices) {
            this.dropDownPopulationforHP(this.offerVariables.existingServices, false);
        }
        this.offerVariables.retainedPotsBooleans = {
            wireMaintainance: this.offerVariables.wireMaintainance,
            voiceMail: this.offerVariables.voiceMail,
            retainValueForPotsJack: this.offerVariables.retainValueForPotsJack
        }
        this.offerVariables.orderRefNumber = data.orderInit.orderRefNumber;
        this.offerVariables.processInstanceId = data.orderInit.processInstanceId;
        this.offerVariables.taskId = data.orderInit.taskId;
        this.offerVariables.taskName = data.orderInit.taskName;
        this.serviceSpec = data.orderInit.payload.serviceCategory;
        this.offerVariables.videoAvail = this.dTvRemoveAction ? false : data.videoCheck;
        this.offerVariables.phoneAvail = data.phoneCheck;
        this.phoneArray = data.phoneType;
        this.videoArray = data.videoType;
        this.offerVariables.internetAvail = data.internetCheck;
        this.offerVariables.enabledServiceList = data.enabledServiceList;
        if ((!data.ban || data.ban == '') && (this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
            this.offerVariables.holdedObjects.orderDocument.accountInfo && this.offerVariables.holdedObjects.orderDocument.accountInfo.ban)) {
            this.offerVariables.ban = this.offerVariables.holdedObjects.orderDocument.accountInfo.ban;
        } else if (data.ban) {
            this.offerVariables.ban = data.ban;
        } else {
            this.offerVariables.ban = this.con;
        }

        if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.retrievalTypes) {
            this.offerVariables.offersByFilters = this.offerHelperService.retrieveOffersByFilter(data.orderInit.payload.retrievalTypes);
            this.offerVariables.qualifiedFilter = this.offerVariables.offersByFilters.qualifiedFilter;
            this.unQualifiedOffers = this.offerVariables.offersByFilters.unQualifiedOffers;
            this.offerVariables.qualifiedUnfilter = this.offerVariables.offersByFilters.qualifiedUnfilter;
        }
        if (data.existingTN) {
            this.existingTN = this.offerHelperService.maskTelephone(data.existingTN);
        }
        if (this.offerVariables.catalogSpecId === undefined && data.orderInit.payload) {
            this.offerVariables.catalogSpecId = data.orderInit.payload.catalogSpecId;
        }
        this.userSubscription = this.user.subscribe(
            (userData) => {
                if (userData.autoLogin) {
                    if (data && data.autoLogin && data.autoLogin !== undefined && data.autoLogin.oamData && data.autoLogin.oamData !== null && data.autoLogin.oamData !== undefined) {
                        this.agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                        this.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                        this.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                        this.ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                    }
                }
                let disconnectReq = this.disconnectMethod(data);
                let retSubscribe: Subscription;
                this.disconnectReq = JSON.stringify(disconnectReq);
                if ((userData.previousUrl !== '/existing-products' && userData.previousUrl !== '/pending-order') || this.fromHold) {
                    this.offerVariables.isReEntrant = true;
                    this.offerVariables.reEntrant = true;
                    this.reentrantUI = true;
                    let retainVal = <Observable<any>>this.store.select('retain');
                    retSubscribe = retainVal.subscribe(
                        (retVal => {
                            if (!state) {
                                this.offerVariables.isConverted = retVal.isConverted;
                                this.offerVariables.taskId = userData.taskId;
                                if (retVal.potsBooleans) this.offerVariables.retainedPotsBooleans = retVal.potsBooleans;
                                if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.wireMaintainance !== undefined) {
                                    this.offerVariables.wireMaintainance = this.offerVariables.retainedPotsBooleans.wireMaintainance;
                                }
                                if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.voiceMail !== undefined) {
                                    this.offerVariables.voiceMail = this.offerVariables.retainedPotsBooleans.voiceMail;
                                }
                                if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.portingCheck !== undefined) {
                                    this.offerVariables.portingCheck = this.offerVariables.retainedPotsBooleans.portingCheck;
                                }
                                if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.selectedMaintainance !== undefined) {
                                    this.offerVariables.selectedMaintainance = this.offerVariables.retainedPotsBooleans.selectedMaintainance;
                                }
                                if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.isInternational !== undefined) {
                                    this.offerVariables.isInternational = this.offerVariables.retainedPotsBooleans.isInternational;
                                    this.offerVariables.dhpIntlSelected = this.offerVariables.isInternational ? 'Yes' : 'No';
                                }
                                this.offerVariables.cartObject = retVal.addOns;
                                this.offerVariables.cartCopyObject = retVal.addOns;
                                this.offerVariables.e911ValidatedAddress = retVal.e911ValidatedAddress;
                                let custOrderItem: CustomerOrderItems[] = this.offerVariables.holdCalled ? this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
                                    this.offerVariables.holdedObjects.orderDocument.customerOrderItems : retVal.addOns.payload.cart.customerOrderItems;

                                if (!this.offerVariables.cartObject) {
                                    this.offerVariables.cartObject = {
                                        payload: {
                                            cart: {
                                                customerOrderItems: custOrderItem
                                            },
                                            productConfiguration: this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
                                                this.offerVariables.holdedObjects.orderDocument.productConfiguration
                                        }
                                    }
                                }
                                //to retain jack values
                                this.offerVariables.cartObject.payload && this.offerVariables.cartObject.payload.cart && this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(cust => {
                                    if (cust && cust.offerCategory === GenericValues.cHP && cust.offerType !== 'SUBOFFER') {
                                        cust.customerOrderSubItems && cust.customerOrderSubItems.forEach(exSub => {
                                            if (exSub.productName.indexOf('Jack and Wire') !== -1) {
                                                this.offerVariables.retainValueForPotsJack = exSub.productAttributes[0].compositeAttribute[0].attributeValue
                                            }
                                        });
                                    }
                                })
                                if (this.offerVariables.retainValueForPotsJack !== undefined && this.offerVariables.retainValueForPotsJack) {
                                    this.offerVariables.retainedPotsBooleans.retainValueForPotsJack = this.offerVariables.retainValueForPotsJack;
                                }
                                this.offerVariables.cartCopyObject = cloneDeep(this.offerVariables.cartObject);
                                if (this.offerVariables.cartCopyObject && this.offerVariables.cartCopyObject.payload && this.offerVariables.cartCopyObject.payload.productConfiguration) {
                                    let selectConfigList = this.offerVariables.cartCopyObject.payload.productConfiguration;
                                    if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
                                        for (let i = 0; i < selectConfigList.length; i++) {
                                            selectConfigList[i].configItems && selectConfigList[i].configItems.forEach(selectedConf => {
                                                this.offerVariables.selectedQuantity = selectedConf.configDetails[0].formItems[0].attributeValue[0].value;
                                                this.offerVariables.deviceSelected = true;
                                            })
                                        }
                                    }
                                }
                                if (this.offerVariables.cartObject) {
                                    if (this.offerVariables.cartObject.payload.cart.customerOrderItems !== undefined && this.offerVariables.cartObject.payload.cart.customerOrderItems.length > 0) {
                                        this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach((item) => {
                                            if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                                if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.hsiExisting = true; }
                                            } else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
                                                this.offerVariables.removedProductItem.push(item);
                                            }
                                            if (item.offerCategory === 'VIDEO-PRISM' && item.action !== 'REMOVE') {
                                                this.offerVariables.videoOffer = true;
                                                this.offerVariables.videoSelected = 'PTV';
                                                state = false;
                                            }
                                            if (item.offerCategory === 'VIDEO-DTV' && item.action !== 'REMOVE') {
                                                if (item.action !== 'ADD') { this.dtvExisting = true; }
                                                this.offerVariables.videoOffer = true;
                                                this.offerVariables.videoSelected = 'DTV';
                                                state = false;
                                            } else if (item.offerCategory === 'VIDEO-DTV' && item.action === 'REMOVE') {
                                                this.offerVariables.removeSelectedReason = retVal.removeReason;
                                                this.offerVariables.removedProductItem.push(item);
                                                this.dtvExisting = true;
                                                state = false;
                                            }
                                            if (item.offerCategory === 'VOICE-DHP' && item.action !== 'REMOVE') {
                                                if (item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.dhpExisting = true; }
                                                this.offerVariables.phoneOffer = true;
                                                this.offerVariables.phoneSelected = 'DHP';
                                                state = false;
                                            } else if (item.offerCategory === 'VOICE-DHP' && item.action === 'REMOVE') {
                                                this.offerVariables.removeSelectedReason = retVal.removeReason;
                                                this.offerVariables.removedProductItem.push(item);
                                                this.offerVariables.dhpExisting = true;
                                                this.offerVariables.isDHPRemoved = true;
                                                state = false;
                                            }
                                            if (item.offerCategory === 'VOICE-HP' && item.action !== 'REMOVE') {
                                                if (item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.hpExisting = true; }
                                                if (item.action === 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.hpExisting = false; }
                                                if (item.action === 'ADD' && item.offerType !== 'SUBOFFER' && this.offerVariables.isAmend) { this.offerVariables.hpExisting = true; }
                                                this.offerVariables.phoneOffer = true;
                                                this.offerVariables.phoneSelected = 'HMP';
                                                this.offerVariables.hpOfferType = item.offerType;
                                                if (item.offerType !== 'SUBOFFER') {
                                                    this.offerVariables.selectedPhoneOfferdId = item.productOfferingId;
                                                    this.offerVariables.selectedHP = item.productOfferingId;
                                                }
                                                state = false;
                                            } else if (item.offerCategory === 'VOICE-HP' && item.action === 'REMOVE') {
                                                this.offerVariables.removeSelectedReason = retVal.removeReason;
                                                this.offerVariables.removedProductItem.push(item);
                                                this.offerVariables.hpExisting = true;
                                                this.offerVariables.isHPRemoved = true;
                                                state = false;
                                            }
                                            if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                                if (item.offerType === 'SUBOFFER') {
                                                    this.existingAddonsHSI = item;
                                                }
                                                this.offerVariables.internetCheck = true;
                                            } else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
                                                if (item.offerType === 'SUBOFFER') {
                                                    this.offerVariables.removeSelectedReason = retVal.removeReason;
                                                    this.offerVariables.removedProductItem.push(item);
                                                    this.existingAddonsHSI = item;
                                                }
                                            }
                                            if (this.offerVariables.phoneSelected === 'DHP') {
                                                let dhp = this.offerHelperService.getExistingProducts(this.offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.cDHP);
                                                if (dhp && dhp.customerOrderSubItems !== null && dhp.customerOrderSubItems
                                                    && dhp.customerOrderSubItems.length !== 0) {
                                                    dhp.customerOrderSubItems.forEach(subItems => {
                                                        if (subItems && subItems.productName === 'Digital Home Phone Intl Call') {
                                                            subItems.productAttributes.forEach(subAttr => {
                                                                if ((subAttr && subAttr.compositeAttribute !== null && subAttr.compositeAttribute.length !== 0
                                                                    && subAttr.compositeAttribute[0].attributeName === 'Service Status')) {
                                                                    subAttr.compositeAttribute[0].attributeValue === 'Enabled'
                                                                        || subAttr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes' ? this.offerVariables.dhpIntlSelected = 'Yes' :
                                                                        this.offerVariables.dhpIntlSelected = 'No';
                                                                    this.offerVariables.dhpIntlSelected === 'Yes' ? this.offerVariables.isInternational = true : this.offerVariables.isInternational = false;
                                                                }
                                                            })
                                                        }
                                                    })
                                                }
                                                if (this.fromHold && this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
                                                    this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo && this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address) {
                                                    this.offerVariables.e911ValidatedAddress = this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address;
                                                    this.offerVariables.e911ValidatedAddress.acceptedData = this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.dhpDisclaimerAcceptDateTime;
                                                }
                                            }
                                        });
                                    }
                                }
                                state = true;
                                this.offerVariables.calledFromConstructor = true;
                                this.offerVariables.internetCheck ? this.offerHelperService.retrieveOffers(this.offerVariables, false, 'fromSlot') : this.offerHelperService.retrieveOffers(this.offerVariables, false);
                            }
                            if (retVal && retVal.retainInstallOption) {
                                this.retainInstallOption = retVal.retainInstallOption;
                            }
                            if (retVal && retVal.retainVoiceMail) {
                                this.offerVariables.voiceMailValue = retVal.retainVoiceMail;
                            }
                        })
                    )
                }
                else {
                    if (!state) {
                        let moreServices;
                        if ((this.offerVariables.NIPendingStackAmend || data.orderFlow.flow === 'Change') && this.offerVariables.isAmend) {
                            moreServices = this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument && this.offerVariables.holdedObjects.orderDocument.customerOrderItems;
                        } else if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.existingServices
                            && data.orderInit.payload.existingServices.existingServiceItems) {
                            moreServices = data.orderInit.payload.existingServices.existingServiceItems;
                            if (data.pendingOrders && data.pendingOrders[0] && data.pendingOrders[0].orderDocument && data.pendingOrders[0].orderDocument.customerOrderItems) {
                                moreServices = data.pendingOrders[0].orderDocument.customerOrderItems;
                            }
                        }
                        if (!moreServices && this.offerVariables.existingServices) moreServices = this.offerVariables.existingServices;

                        if (moreServices !== undefined && moreServices.length > 0) {
                            moreServices.forEach((item) => {
                                if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                    this.hsiExisting = true;
                                    if (item.offerType === 'SUBOFFER') {
                                        this.existingAddonsHSI = item;
                                    }
                                    this.offerVariables.internetCheck = true;
                                }
                            });
                        }

                        if (moreServices !== undefined && moreServices.length > 1) {
                            moreServices.forEach((item) => {
                                if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                    this.hsiExisting = true;
                                }
                                if (item.offerCategory === 'VIDEO-PRISM') {
                                    this.offerVariables.videoOffer = true;
                                    this.offerVariables.videoSelected = 'PTV';
                                    state = false;
                                }
                                if (item.offerCategory === 'VIDEO-DTV' && item.offerType !== 'SUBOFFER' && !this.dTvRemoveAction) {
                                    this.dtvExisting = true;
                                    this.offerVariables.videoOffer = true;
                                    this.offerVariables.videoSelected = 'DTV';
                                    this.offerVariables.newVideoSelected = 'DTV';
                                    state = false;
                                }
                                if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER' && !this.offerVariables.cvoipRemoveAction) {
                                    this.offerVariables.dhpExisting = true;
                                    this.offerVariables.phoneOffer = true;
                                    this.offerVariables.phoneSelected = 'DHP';
                                    this.offerVariables.newPhoneSelected = 'DHP';
                                    state = false;
                                }
                                if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER' && !this.offerVariables.potsRemoveAction && item.action !== 'REMOVE') {
                                    this.offerVariables.selectedHP = item.productOfferingId;
                                    this.offerVariables.selectedPhoneOfferdId = item.productOfferingId;
                                    this.offerVariables.hpOfferType = item.offerType;
                                    this.offerVariables.hpExisting = true;
                                    this.offerVariables.phoneOffer = true;
                                    this.offerVariables.phoneSelected = 'HMP';
                                    this.offerVariables.newPhoneSelected = 'HMP';
                                    state = false;
                                }
                                if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
                                    if (item.offerType === 'SUBOFFER') {
                                        this.existingAddonsHSI = item;
                                    }
                                    this.offerVariables.internetCheck = true;
                                }
                            });
                        }
                        if (!this.offerVariables.internetCheck && moreServices !== undefined && moreServices.length >= 1) {
                            moreServices.forEach((item) => {
                                if (item.offerCategory === 'VOICE-HP' && item.action !== 'REMOVE') {
                                    this.offerVariables.hpExisting = true;
                                    this.offerVariables.phoneOffer = true;
                                    this.offerVariables.phoneSelected = 'HMP';
                                    state = false;
                                }
                            });
                        }

                        if (this.offerVariables.hsiCatalogId === undefined && moreServices) {
                            moreServices.forEach((item) => {
                                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                                    this.offerVariables.hsiCatalogId = item.catalogId;
                                    this.offerVariables.cartContractTerm = item.contractTerm;
                                }
                                if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
                                    this.offerVariables.phoneCatalogId = item.catalogId;
                                    this.offerVariables.cartContractTermDHP = item.contractTerm;
                                }
                                if (item.offerCategory === 'VIDEO-DTV') {
                                    this.offerVariables.dtvCatalogId = item.catalogId;
                                    this.offerVariables.cartContractTermDTV = item.contractTerm;
                                }
                            });
                        }
                        state = true;
                        this.offerVariables.calledFromConstructor = true;
                        this.offerHelperService.retrieveOffers(this.offerVariables, false, 'fromSlot');
                    }
                }
                if (retSubscribe !== undefined)
                    retSubscribe.unsubscribe();
            }
        );

        this.offerHelperService.fetchExistingProducts(this.offerVariables, this.offerVariables.existingServices);
        return state;
    }
    private retrieveModemModel(products: any, isExtSpeedChanged?) {
        if (!isExtSpeedChanged) {
            products && products.forEach((data) => {
                if (data && data.productName === "MODEM") {
                    data.productAttributes && data.productAttributes.forEach((productAttributes) => {
                        productAttributes && productAttributes.compositeAttribute && productAttributes.compositeAttribute.forEach((values) => {
                            if (!this.offerVariables.modemMakeModelCheck) this.offerVariables.modemMakeModelCheck = true;
                            if (values && values.attributeName && values.attributeName === "modemMake" && values.attributeValue !== "null" && values.attributeValue !== null) {
                                this.offerVariables.modemMake = values.attributeValue;
                            } else if (values && values.attributeName && values.attributeName === "modemModel" && values.attributeValue !== "null" && values.attributeValue !== null) {
                                this.offerVariables.modemModel = values.attributeValue;
                            } else if (this.offerVariables.isHSIExistingProduct && values && values.attributeName && values.attributeName === "Modem Class" && values.attributeValue !== "null" && values.attributeValue !== null) {
                                this.modemClass = values.attributeValue;
                            }
                        });
                    });
                }
            });
        } else {
            products && products.product && products.product.productAttributes && products.product.productAttributes.forEach(data => {
                data.compositeAttribute.forEach(compAttr => {
                    if (this.offerVariables.isHSIExistingProduct && compAttr.attributeName === "Modem Class") {
                        this.modemClass = compAttr.attributeValue;
                    }
                })
            });
            products && products.length && (products.length > 0) && products.forEach(data => {
                if (data && data.productName === "MODEM") {
                    data.productAttributes && data.productAttributes.forEach((productAttributes) => {
                        productAttributes && productAttributes.compositeAttribute && productAttributes.compositeAttribute.forEach((values) => {
                            if (values && values.attributeName && values.attributeName === "Modem Class" && values.attributeValue !== "null" && values.attributeValue !== null) {
                                this.modemClass = values.attributeValue;
                            }
                        });
                    });
                }
            });
        }
    }

    private disconnectMethod(data: any) {
        return {
            'ban': data.ban,
            'salesChannel': 'ESHOP-Customer Care',
            'customerOrderType': 'DISCONNECT',
            'serviceAddress': data.existingProductsAndServices[0] ? data.existingProductsAndServices[0].serviceAddress : '',
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            }
        };
    }

    private dropDownPopulationforHP(existingItems: any, flag) {
        this.offerVariables.voiceMail = false;
        this.offerVariables.wireMaintainance = false;
        this.offerVariables.isWireMaintainanceNoSelected = true;
        this.offerVariables.isWireMaintainanceYesSelected = false;
        existingItems && existingItems.forEach((data) => {
            if (data.offerCategory === GenericValues.cHP && data.offerType !== 'SUBOFFER') {
                if (!this.offerVariables.isReEntrant) {
                    this.offerVariables.voiceMailValue = 'No';
                    this.offerVariables.wireMaintainanceValue = 'No';
                }
                data.customerOrderSubItems && data.customerOrderSubItems.forEach((voiceData) => {
                    if (voiceData.productName === "Voice Messaging") {
                        if (!flag) this.offerVariables.voiceMailCondi = true;
                        this.offerVariables.voiceMail = true;
                        this.offerVariables.voiceMailValue = 'Yes';
                    }
                    else if (voiceData.productName.indexOf('Wire Maintenance Plan') !== -1) {
                        this.offerVariables.wireMaintainance = true;
                        this.offerVariables.isWireMaintainanceYesSelected = true;
                        if (!flag) this.offerVariables.wireMaintainCondi = true;
                        this.offerVariables.isWireMaintainanceNoSelected = false;
                    } else if (voiceData.productName.indexOf('Jack and Wire') !== -1) {
                        this.offerVariables.retainValueForPotsJack = voiceData.productAttributes[0].compositeAttribute[0].attributeValue;
                        if (this.offerVariables.retainValueForPotsJack !== undefined && this.offerVariables.retainValueForPotsJack && this.offerVariables.retainedPotsBooleans) {
                            this.offerVariables.retainedPotsBooleans.retainValueForPotsJack = this.offerVariables.retainValueForPotsJack;
                        }
                    } else if (voiceData.productName.indexOf('Extended Area Calling') !== -1) {
                        if (!flag) this.offerVariables.isExtendedAreaCallingExits = true;
                    }
                });
            }
        });
    }

    public ngOnInit() {
        window.scroll(0, 0);
        this.offerHelperService.getReentrantFlags(this.offerVariables);
        this.offerHelperService.getTechnologyTypes(this.offerVariables);
        this.offerHelperService.compatibilityAPIcall(this.offerVariables);
        this.offerHelperService.checkCSCompatibitlity(this.offerVariables);
        if (!this.offerVariables.isReEntrant) this.offerHelperService.setDiscountsFromExistingDiscounts(this.offerVariables, this.existingDiscounts);
        this.existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            this.offerVariables['exisitngData'] = respData;
            if (this.offerVariables.exisitngData && this.offerVariables.exisitngData.existingProductsAndServices && this.offerVariables.exisitngData.existingProductsAndServices[0] &&
                this.offerVariables.exisitngData.existingProductsAndServices[0].lifelineInfo) {
                respData.existingProductsAndServices[0].lifelineInfo.forEach((data) => {
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "INTERNET") {
                        this.lifelineHSIExisting = true;
                    }
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-HP") {
                        this.lifelinePOTSExisting = true;
                    }
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-DHP") {
                        this.lifelineDHPExisting = true;
                    }
                })
            }
        });
        if (this.existingProductStoreSubscription !== undefined) {
            this.existingProductStoreSubscription.unsubscribe();
        }
        this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: { type: '', selected: '' } } });
        this.logger.metrics('OfferStackAmendPage');
    }

    public selfInstallOffers: string[] = [];
    public existingModemOffers: string[] = [];


    public recomTechInstall: OfferProductComponents;
    /**
     * While click on Offer from Section corresponding Product and Prices to be populated in Panel
     */

    public reEntrantLoaded = false;
    public retainPreSelected(selectedProduct: Products, component: OfferProductComponents, type: string, modemCompatible?: boolean) {
        let prodComp = this.offerHelperService.searchForDefault(this.offerVariables, true, component);
        if (type === 'ease' && this.EaseDefault) {
            selectedProduct = undefined;
            this.offerVariables.selectedEase = undefined;
        }
        if (type === 'secureWifi' && this.secureWifiDefault) {
            selectedProduct = undefined;
            this.offerVariables.selectedSecureWifi = undefined;
        }
        if ((selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].compositeAttribute && type !== 'modem')
            || (selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].compositeAttribute && type === 'modem' && modemCompatible === this.offerVariables.isModemCompatible)) {
            if (prodComp && prodComp.productAttributes && prodComp.productAttributes[0] && prodComp.productAttributes[0].compositeAttribute) {
                let exSelection = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                let currentDef = this.offerHelperService.getModemTypeforRetain(prodComp.productAttributes[0].compositeAttribute);
                if (exSelection === currentDef) {
                    let currentPrice, oldPrice;
                    prodComp.productAttributes[0].prices && prodComp.productAttributes[0].prices.forEach(price => {
                        if (price && price.priceType === GenericValues.pPriceType) {
                            currentPrice = this.offerHelperService.populateValues(price);
                        }
                    });
                    selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].prices &&
                        selectedProduct.productAttributes[0].prices.forEach(price => {
                            if (price && price.priceType === GenericValues.pPriceType) {
                                oldPrice = this.offerHelperService.populateValues(price);
                            }
                        });
                    if (currentPrice <= oldPrice) {
                        this.changeSelection(type, exSelection, component);
                    }
                    else {
                        this.makeUndefined(type);
                    }
                }
                else {
                    let exSelection1 = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                    let currentPrice: number = 0, oldPrice: number = 0;
                    selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].prices &&
                        selectedProduct.productAttributes[0].prices.forEach(price => {
                            if (price && price.priceType === GenericValues.pPriceType) {
                                oldPrice = this.offerHelperService.populateValues(price);
                            }
                        });
                    let currentDef1 = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                    let price = currentDef1 === 'na' ? this.offerVariables.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(
                        component, currentDef1, type.toUpperCase());
                    if (price && price.prices && price.prices.length > 0) {
                        price.prices.forEach(prize => {
                            if (prize && prize.priceType === GenericValues.pPriceType) {
                                currentPrice = this.offerHelperService.populateValues(prize);
                            }
                        })
                    }
                    let isExExist = this.offerHelperService.getPriceDetailsByAttrVal(component, exSelection1, '');
                    if (isExExist) {
                        if (currentPrice <= oldPrice) {
                            this.changeSelection(type, exSelection1, component);
                        } else {
                            this.makeUndefined(type);
                        }
                    } else {
                        if (!this.offerVariables.selfInstall || type === 'install') {
                            this.changeSelection(type, currentDef, component);
                        }
                    }
                }
            }
            else {
                let exSelection = this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
                this.changeSelection(type, exSelection, component);
                this.offerHelperService.getModemTypeforRetain(selectedProduct.productAttributes[0].compositeAttribute);
            }
        } else {
            this.makeUndefined(type);
        }
    }
    public changeSelection(type: string, exSelection: string, component: OfferProductComponents) {
        if (component) {
            switch (type) {
                case 'install': this.offerHelperService.onChangeInstallation(this.offerVariables, exSelection, component.isMandatory); break;
                case 'modem': this.offerHelperService.onChangeModem(this.offerVariables, exSelection, component && component.isMandatory); break;
                case 'ease': this.offerHelperService.onChangeEase(this.offerVariables, exSelection, component && component.isMandatory); break;
                case 'secureWifi': this.offerHelperService.onChangeSecureWifi(this.offerVariables, exSelection, component && component.isMandatory); break;
                case 'jack': this.offerHelperService.onChangeJack(this.offerVariables, exSelection, component && component.isMandatory); break;
            }
        }
    }
    public makeUndefined(type: string) {
        switch (type) {
            case 'install': this.offerVariables.selectedInstallation = undefined; break;
            case 'modem': this.offerVariables.selectedModem = undefined; break;
            case 'ease': this.offerVariables.selectedEase = undefined; this.EaseDefault = true; break;
            case 'secureWifi': this.offerVariables.selectedSecureWifi = undefined; this.secureWifiDefault = true; break;
            case 'jack': this.offerVariables.selectedJack = undefined; break;
        }
    }

    public retainData() {

        if ((this.offerVariables.isReEntrant || this.reentrantUI) && !this.reEntrantLoaded) {
            this.offerVariables.selectedInstallation = undefined;
            this.offerVariables.selectedModem = undefined;
            this.offerVariables.selectedEase = undefined;
            this.offerVariables.selectedSecureWifi = undefined;
            this.offerVariables.installError = false;
            this.offerVariables.modemError = false;
            this.offerVariables.easeError = false;
            this.offerVariables.secureWifiError = false;
            this.offerVariables.jackError = false;
            let custObj = this.offerHelperService.findCustomerOrderObject(this.offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
            if (custObj && custObj.customerOrderSubItems) {
                let custSubObj: CustomerOrderSubItem = this.offerHelperService.findCustomerSubOrderObject(custObj, 'TECH INSTALL');

                if (custSubObj !== undefined && this.retainInstallOption) {
                    this.offerVariables.selectedInstallation = custSubObj;
                } else if (custSubObj !== undefined && this.offerVariables.holdCalled) {
                    this.offerVariables.selectedInstallation = custSubObj;
                }

                if (this.offerVariables.installationValues && this.offerVariables.installationValues.isMandatory && !this.offerVariables.selectedInstallation && !custSubObj) {
                    this.offerVariables.installError = true;
                }

                custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'MODEM');
                if (custSubObj !== undefined) {
                    this.offerVariables.selectedModem = custSubObj;
                }

                if (this.offerVariables.modemValues && this.offerVariables.modemValues.isMandatory && !this.offerVariables.selectedModem) {
                    this.offerVariables.modemError = true;
                }

                custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'CENTURYLINK @ EASE');
                if (custSubObj !== undefined) {
                    this.offerVariables.selectedEase = custSubObj;
                }

                if (this.offerVariables.easeValues && this.offerVariables.easeValues.isMandatory && !this.offerVariables.selectedEase) {
                    this.offerVariables.easeError = true;
                }

                this.offerVariables.canDisplayCS = this.offerHelperService.displayCS(this.offerVariables, this.offerVariables.selectedModem);
                this.offerHelperService.modemDisplayNameForCart(this.offerVariables.selectedModem, this.offerVariables.modemValues);
                if (this.offerVariables.canDisplayCS) {
                    custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, GenericValues.secureWifiComponent);
                    if (custSubObj !== undefined) {
                        this.offerVariables.selectedSecureWifi = custSubObj;
                    } else {
                        this.offerHelperService.selectNotNeeded(this.offerVariables, this.offerVariables.secureWifiValues);
                    }
                    if (this.offerVariables.secureWifiValues && this.offerVariables.secureWifiValues.isMandatory && !this.offerVariables.selectedSecureWifi) {
                        if (this.offerVariables.selectedModem && this.offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() === 'purchase') {
                            this.offerVariables.secureWifiError = true;
                        }
                    }
                }
                if (!this.offerVariables.phoneOffer || (this.offerVariables.phoneOffer && this.offerVariables.phoneSelected === 'DHP')) {
                    custSubObj = this.offerHelperService.findCustomerSubOrderObject(custObj, 'Jack and Wire');
                    if (custSubObj !== undefined) {
                        this.offerVariables.selectedJack = custSubObj;
                    }
                    if (this.offerVariables.isReEntrant && this.offerVariables.selectedJack === undefined) {
                        this.offerVariables.JacksWireDefault = true;
                    }
                    if (this.offerVariables.jackValues && this.offerVariables.jackValues.isMandatory && !this.offerVariables.selectedJack) {
                        this.offerVariables.jackError = true;
                    }
                }

            }

            let reEntrantOfferVariable: OfferVariables = this.ctlHelperService.getLocalStorage(RE_ENTRANT_OFFERVARIABLE);
            this.offerVariables.isExtendedAreaCallingPresent = reEntrantOfferVariable.isExtendedAreaCallingPresent;
            this.offerVariables.isOffer1PtyResLineSelected = reEntrantOfferVariable.isOffer1PtyResLineSelected;
            this.offerVariables.isExtendedAreaCallingYESSelected = reEntrantOfferVariable.isExtendedAreaCallingYESSelected;
            this.offerVariables.isExtendedAreaCallingNASelected = reEntrantOfferVariable.isExtendedAreaCallingNASelected;
            this.offerVariables.selectedExtendedAreaCalling = reEntrantOfferVariable.selectedExtendedAreaCalling;
            this.offerVariables.extendedAreaCallingPrice = reEntrantOfferVariable.extendedAreaCallingPrice;

            this.reEntrantLoaded = true;
        }
    }

    /**
     * Populate default component value in dropdowns
     * @param defaultVal
     * @param addons
     */
    public findCustomerSubOrderObjectIndexOf(custObj: CustomerOrderItems, filterBy): Products {
        let val: Products;
        if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
            custObj.customerOrderSubItems.forEach(obj => {
                if (obj.productName.indexOf(filterBy) !== -1) {
                    val = obj;
                }
            });
        }
        return val;
    }

    public serviceTerminate() {
        this.store.dispatch({ type: 'REMOVAL_REASON', payload: this.offerVariables.removeSelectedReason });
        for (let i = 0; i < this.offerVariables.removedProductItem.length; i++) {
            let addRemoveToAllSubItems = this.offerVariables.removedProductItem[i].customerOrderSubItems.map(item => {
                if (item && item.action) item.action = 'REMOVE'
                return item;
            });
            this.offerVariables.undoChanges = true;
            this.offerVariables.removedProductItem[i].customerOrderSubItems = addRemoveToAllSubItems;
        }
        if (this.offerVariables.removedProductItem && this.offerVariables.removedProductItem[0] && this.offerVariables.removedProductItem[0].offerCategory) {
            this.offerVariables.serviceTerminationInfo = [{
                "serviceCategory": null,
                "offerCategory": this.offerVariables.removedProductItem[0].offerCategory,
                "product": null,
                "reasonList": {
                    "reasonType": this.offerVariables.removeSelectedReason && this.offerVariables.removeSelectedReason.rsnType,
                    "reason": [
                        {
                            "code": this.offerVariables.removeSelectedReason && this.offerVariables.removeSelectedReason.rsnCode,
                            "description": this.offerVariables.removeSelectedReason && this.offerVariables.removeSelectedReason.chgDesc,
                            "waiverFlag": "No",
                            "reasonType": this.offerVariables.removeSelectedReason && this.offerVariables.removeSelectedReason.rsnType,
                            "reasonText": null,
                            "offerCategory": this.offerVariables.removedProductItem[0].offerCategory,
                            "terminationFee": "0",
                            "currencyCode": "USD"
                        }
                    ]
                }
            }]
        }
    }

    public getTitleForAmend(technology: any) {
        if ((this.currentTechnology !== 'GPON' || this.currentTechnology !== 'GPON-ATM') && (technology === 'GPON' || technology === 'GPON-ATM') && this.offerVariables.isAmend) {
            return true;
        }
    }

    public onChangeVoiceMail(value: string) {
        this.offerVariables.voiceMail = false;
        this.offerVariables.undoFlag = true;
        this.offerVariables.voiceMailValue = value;
        this.store.dispatch({ type: 'RETAIN_VOICE_MAIL', payload: value });
        this.offerVariables.potsVoiceMailMandatory = false;
        if (this.offerVariables.voiceMailValue === 'na') {
            this.offerVariables.potsVoiceMailMandatory = true;
            return false;
        } else if (this.offerVariables.voiceMailValue === 'Yes') {
            this.offerVariables.voiceMail = true;
            this.offerHelperService.shoppingCartRequest(this.offerVariables);
        } else {
            this.offerHelperService.shoppingCartRequest(this.offerVariables);
        }
    }

    public showWithHSI(items: ProductOfferings): boolean {
        let flag: boolean = false;
        if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
            items.productOffer.offerAttributes.forEach(attr => {
                if ((this.offerVariables.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'yes') || (!this.offerVariables.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'no')) {
                    items.productOffer.offerAttributes.forEach(checkAttr => {
                        if (this.offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
                            flag = true;
                        }
                    })
                }
            });
        }
        return flag;
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.userSubscription1 !== undefined) {
            this.userSubscription1.unsubscribe();
        }
        if (this.existingSubscription !== undefined) {
            this.existingSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
    }

    public getRemoveResponse() {

        let request: any = {
            "rsnType": "DISCONNECT"
        }
        this.offerVariables.loading = true;
        this.logger.log("info", "stack-amend-product.component.ts", "getResponseForRemoveRequest", JSON.stringify(request));
        this.logger.startTime();
        this.productService.getResponseForRemove(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "stack-amend-product.component.ts", "getResponseForRemoveResponse", JSON.stringify(error));
                this.logger.log("error", "stack-amend-product.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.offerVariables.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "Submit Task", "stack-amend-product.component.ts",
                    "Remove Response - Offer Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "stack-amend-product.component.ts", "getResponseForRemoveResponse", JSON.stringify(respData));
                    this.logger.log("info", "stack-amend-product.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.removeResponse = respData.bmReasonCodes;

                    if (this.offerVariables.removedProductItem && this.offerVariables.removedProductItem.length > 0) {
                        this.offerVariables.removeSelectedReason = this.removeResponse[0];
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "stack-amend-product.component.ts", "getResponseForRemoveResponse", JSON.stringify(error));
                    this.logger.log("error", "stack-amend-product.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.offerVariables.apiResponseError = JSON.parse(error);
                        if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                            this.offerVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "stack-amend-product.component.ts", "Offers Page", this.offerVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "stack-amend-product.component.ts", "Offers Page", lAPIErrorLists);
                    }
                    this.offerVariables.retrieveOffersLoading = false;
                });

    }
    /*
        public removeExistingProduct(removed: any) {
            this.offerVariables.undoFlag = true;
            this.offerVariables.removeSelectedReason = removed.removeReason;
            if (removed.type === 'removeInternetNotLast') {
                //iterate over cartObject
                this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
                    if (item.offerCategory === GenericValues.sData ||
                        item.offerCategory === GenericValues.iData) {
                        for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                            if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory) {
                                this.offerVariables.existingServices[i].action = 'REMOVE';
                                this.offerVariables.existingServices[i].catalogId = this.offerVariables.hsiCatalogId;
                                this.existingDeleteexSub(i);
                            }
                        }
                        item.action = 'REMOVE';
                        this.offerVariables.isInternetRemoved = true;
    
                        this.offerVariables.internetCheck = false;
                        this.offerVariables.newInternetCheck = false;
    
                        this.offerHelperService.retrieveOffers(this.offerVariables,false);
                    }
                });
            }
            if (removed.type === 'optOut') {
                this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
                    if (item.offerCategory === GenericValues.cDTV) {
                        for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                            if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory) {
                                this.offerVariables.existingServices[i].action = 'REMOVE';
                                this.offerVariables.existingServices[i].catalogId = this.offerVariables.dtvCatalogId;
                                this.existingDeleteexSub(i);
                            }
                        }
                        item.action = 'REMOVE';
                        this.offerVariables.isOptedOut = true;
    
                        this.offerVariables.videoOffer = false;
                        this.offerVariables.videoSelected = 'NoTV';
                        this.offerVariables.newVideoSelected = 'NoTV';
    
                        this.optedOutCheck = true;
    
                        this.offerHelperService.retrieveOffers(this.offerVariables,false);
                    }
                });
            }
            if (removed.type === 'removePrism') {
                //iterate over cartObject
                this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
                    if (item.offerCategory === 'VIDEO-PRISM') {
                        item.action = 'REMOVE';
                        this.offerVariables.removedProductItem.push(item);
                        this.offerVariables.isRemoved = true;
    
                        this.offerVariables.videoOffer = false;
                        this.offerVariables.videoSelected = 'NoTV';
                        this.offerVariables.newVideoSelected = 'NoTV';
    
                        if (this.dataLink === undefined && this.preserveHSI !== undefined) {
                            this.dataLink = this.preserveHSI;
                        }
                        this.offerHelperService.retrieveOffers(this.offerVariables,false);
                    }
                });
            }
            if (removed.type === 'removeDhp' || removed.type === 'removeHp') {
                //iterate over cartObject
                this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
                    if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
                        for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                            if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory) {
                                this.offerVariables.existingServices[i].action = 'REMOVE';
                                this.offerVariables.existingServices[i].catalogId = this.offerVariables.phoneCatalogId;
                                this.existingDeleteexSub(i);
                            }
                        }
                        item.action = 'REMOVE';
                        let is911 = false;
                        removed.type === 'removeDhp' ? this.offerVariables.isDHPRemoved = true : this.offerVariables.isHPRemoved = true;
                        if (this.offerVariables.phoneSelected === 'DHP' && !this.offerVariables.dhpExisting) {
                            this.e911Validation.open();
                            is911 = true;
                        } else if ((this.offerVariables.phoneSelected === 'HMP' && removed.type === 'removeHp') ||
                            (this.offerVariables.phoneSelected === 'DHP' && removed.type === 'removeDhp')) {
                            this.offerVariables.phoneOffer = false;
                            this.offerVariables.phoneSelected = GenericValues.noPhone;
                            this.offerVariables.newPhoneSelected = GenericValues.noPhone;
                        }
    
                        !is911 ? this.offerHelperService.retrieveOffers(this.offerVariables,false) : '';
                    }
                });
            }
            if (removed.type === 'removeInternet' || (removed.type === 'removeLastInternet' && removed.subType === 'Remove Internet and Add Home Phone')) {
                //iterate over cartObject
                this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
                    if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                        for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                            if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory && this.offerVariables.existingServices[i].customerOrderSubItems &&
                                this.offerVariables.existingServices[i].customerOrderSubItems.length > 0) {
                                this.offerVariables.existingServices[i].action = 'REMOVE';
                                this.offerVariables.existingServices[i].catalogId = this.offerVariables.existingServices[i].catalogId === null ? this.offerVariables.hsiCatalogId : this.offerVariables.existingServices[i].catalogId;
                                this.existingDeleteexSub(i);
                            }
                        }
                        item.action = 'REMOVE';
                        this.offerVariables.isInternetRemoved = true;
    
                        this.offerVariables.internetCheck = false;
                        this.offerVariables.phoneSelected = 'HMP';
                        this.offerVariables.newInternetCheck = false;
                        this.offerVariables.newPhoneSelected = 'HMP';
    
                        this.offerHelperService.retrieveOffers(this.offerVariables,false);
                    }
                });
            }
            if (removed.type === 'removeLastInternet' && removed.subType === 'Remove Internet and Close') {
                this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
                    if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                        this.offerVariables.removedProductItem.push(item);
                    }
                });
                let services = [{
                    "offerCategory": this.offerVariables.removedProductItem[0].offerCategory,
                    "reasonType": this.offerVariables.removeSelectedReason.rsnType,
                    "reasonText": null,
                    "reasonList": [{
                        "code": this.offerVariables.removeSelectedReason.rsnCode,
                        "description": this.offerVariables.removeSelectedReason.chgDesc,
                        "waiverFlag": "No"
                    }],
                    "etfInfo": {
                        "terminationFee": "0",
                        "currencyCode": "USD",
                        "contractExpiryDate": null
                    }
                }];
                let apiRequest = {
                    orderRefNumber: this.offerVariables.orderRefNumber,
                    processInstanceId: this.offerVariables.processInstanceId,
                    taskId: this.offerVariables.taskId,
                    taskName: 'Select Disconnect Reason',
                    payload: {
                        disconnectInfo: services
                    }
                }
    
                this.offerVariables.loading = true;
                this.logger.log("info", "stack-amend-product.component.ts", "disconnectSubmitInfoServcRequest", JSON.stringify(apiRequest));
                this.logger.startTime();
                this.disconnectServiceCall.submitInformation(apiRequest)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "stack-amend-product.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(error));
                        this.logger.log("error", "stack-amend-product.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.offerVariables.loading = false;
                        return Observable.throw(
                            this.systemErrorService.logAndRouteUnexpectedError(
                                "error", "Not Applicable",
                                "Submit Task", "stack-amend-product.component.ts",
                                "Disconnect call - Offers Page",
                                error));
                    })
                    .subscribe(
                        (data) => {
                            this.logger.endTime();
                            this.logger.log("info", "stack-amend-product.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(data ? data : ''));
                            this.logger.log("info", "stack-amend-product.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.offerVariables.loading = false;
                            this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                            this.router.navigate(['/disconnect-schedule']);
                        },
                        (error) => {
                            this.logger.endTime();
                            this.logger.log("error", "stack-amend-product.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(error));
                            this.logger.log("error", "stack-amend-product.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.offerVariables.loading = false;
                            if (error === undefined || error === null)
                                return;
                            let unexpectedError = false;
                            if (this.ctlHelperService.isJson(error)) {
                                this.offerVariables.apiResponseError = JSON.parse(error);
                                if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                                    this.offerVariables.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", "Pending Summary", "stack-amend-product.component.ts", "Offers Page", this.offerVariables.apiResponseError);
                                } else unexpectedError = true;
                            } else unexpectedError = true;
                            if (unexpectedError) {
                                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                                this.systemErrorService.logAndeRouteToSystemError("error", "Pending Summary", "stack-amend-product.component.ts", "Offers Page", lAPIErrorLists);
                            }
                            window.scroll(0, 0);
                        });
            }
        }
    */
    private existingDeleteexSub(i: number) {
        this.offerVariables.existingServices[i].action = 'REMOVE';
        let exServ = cloneDeep(this.offerVariables.existingServices[i]);
        if (exServ.existingServiceSubItems) {
            exServ.customerOrderSubItems = exServ.existingServiceSubItems;
            delete exServ.existingServiceSubItems;
        }
        this.offerVariables.removedProductItem.push(exServ);
    }

    public undoAll() {
        this.offerVariables.loading = true;
        this.offerVariables.undoSelected = true;
        this.initilizeAll();
        this.ngOnInit();
        this.offerVariables.undoFlag = false;
        this.offerVariables.loading = false;
    }

    public internetClickHandler() {
        if (this.offerVariables.internetAvail && this.offerVariables.internetCheck && !this.offerVariables.videoOffer && !this.offerVariables.phoneOffer && this.hsiExisting) {
            this.offerHelperService.productRemoved('INTERNET', this.offerVariables);
            this.offerHelperService.setMessage('Internet is last product on account. Account will be closed if all products are removed.',
                this.offerVariables.newPhoneSelected === 'HMP' ? 'removeInternet' : 'removeLastInternet', this.offerVariables);
            if (this.offerVariables.newPhoneSelected === 'HMP') { this.offerVariables.newInternetCheck = false; }
            this.offerHelperService.retrieveSecurityDepositHistory(this.offerVariables, this.removeProduct, this.removeProductOpen);
            this.getRemoveResponse();
        }
        else if (this.offerVariables.internetAvail && this.offerVariables.internetCheck && this.hsiExisting && this.offerVariables.phoneOffer && this.offerVariables.phoneSelected === 'HMP') {
            this.offerHelperService.productRemoved('INTERNET', this.offerVariables);
            this.offerHelperService.setMessage('More information is needed', 'removeInternetNotLast', this.offerVariables);
            this.offerHelperService.retrieveSecurityDepositHistory(this.offerVariables, this.removeProduct, this.removeProductOpen);
            this.getRemoveResponse();
        }
        else if (this.offerVariables.internetAvail && this.offerVariables.internetCheck && this.hsiExisting && this.offerVariables.videoOffer && this.offerVariables.videoSelected === 'DTV' && !this.offerVariables.phoneOffer) {
            this.offerHelperService.productRemoved('INTERNET', this.offerVariables);
            this.offerHelperService.setMessage('TV requires Phone or Internet. At least one must be selected.', 'removeInternet', this.offerVariables);
            this.offerHelperService.retrieveSecurityDepositHistory(this.offerVariables, this.removeProduct, this.removeProductOpen);
            this.getRemoveResponse();
        }

    }

    public phoneClickHandler() {
        this.offerHelperService.productRemoved('offerCategory', this.offerVariables);
        this.offerHelperService.setMessage('More information is needed', this.offerVariables.phoneSelected === 'DHP' ? 'removeDhp' : this.offerVariables.phoneSelected === 'HMP' ? 'removeHp' : '', this.offerVariables);
        this.offerHelperService.retrieveSecurityDepositHistory(this.offerVariables, this.removeProduct, this.removeProductOpen);
        this.getRemoveResponse();
    }

    public stopClickPropogation(event: Event, flag: boolean, fromVideo?: boolean) {
        if (flag || (this.offerVariables.isStack && this.offerVariables.newPhoneSelected === 'DHP' && this.isCanRemoveCvoip === 'false' && !fromVideo)) {
            event.stopPropagation();
        }
    }

    public onDtvClick() {
        if (!this.offerVariables.isAmend) {
            this.optOutPopUp.open();
            this.offerHelperService.setMessage('Reason for Opt Out', 'optOut', this.offerVariables);
            this.getRemoveResponse();
            this.offerHelperService.retrieveSecurityDepositHistoryForOptOut(this.offerVariables);
        }
    }

    public findCustomerOrderObject(custObj: CustomerOrderItems[], filterBy, flag?): CustomerOrderItems {
        let val: CustomerOrderItems;
        if (custObj !== undefined) {
            custObj.forEach(obj => {
                if (!flag && obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER') {
                    val = obj;
                } else if (flag && (obj.offerCategory === filterBy || obj.offerCategory === GenericValues.sData) && obj.offerType !== 'SUBOFFER' && obj.offerName.toUpperCase() !== VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                    val = obj;
                }
            })
        }
        return val;
    }

    public handleRemovedProdInCart(customerOrderItems) {
        let orderItems = customerOrderItems;
        let multiplePendingOrders = false;
        this.existingSubscription = this.existingObservable.subscribe(data => {
            multiplePendingOrders = (data.pendingOrders && data.pendingOrders.length > 1);
        });
        if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
        if (!multiplePendingOrders && this.offerVariables.NIPendingStackAmend) {
            orderItems = orderItems.filter(item => {
                return (item.action !== 'REMOVE');
            });
        } else if (multiplePendingOrders && this.offerVariables.NIPendingStackAmend) {
            orderItems = orderItems.filter(item => {
                if (item.action === 'REMOVE') {
                    let existing = this.offerHelperService.getExistingProducts(this.offerVariables.existingServicesForAction, item.offerCategory);
                    return (existing !== undefined);
                }
                return true;
            });
        }
        return orderItems;
    }

    public beforeToContinue(orderDisclosures) {
        this.offerVariables.voiceMailInput = this.voiceMailInput;
        this.offerVariables.secureWifiSelected = this.secureWifiSelected;
        this.offerVariables.easeSelected = this.easeSelected;
        this.offerVariables.wireMaintainanceInput = this.wireMaintainanceInput;
        this.offerVariables.portingInput = this.portingInput;
        this.offerHelperService.toContinue(this.offerVariables, orderDisclosures);
    }
}