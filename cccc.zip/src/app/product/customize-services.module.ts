import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from './../common/service/text-mask.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { CustomizeServicesComponent } from './customize-services.component';
import { SharedModule } from '../shared/shared.module';
import { TooltipModule } from 'ngx-bootstrap';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { OneTimeChargesComponent } from './onetime-charges/onetime-charges.component'
import { PhoneConfigurationComponent } from './phone-configuration/phone-configuration.component';
import { InternetConfigurationComponent } from './internet-configuration/internet-configuration.component';
import { ClosersPromosComponent } from './closers-promos/closers-promos.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: CustomizeServicesComponent
    }
];

@NgModule({
    imports: [FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        TextMaskModule,
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TooltipModule.forRoot()
    ],
    exports: [
        CustomizeServicesComponent
    ],
    declarations: [
        CustomizeServicesComponent,
        OneTimeChargesComponent,
        PhoneConfigurationComponent,
        InternetConfigurationComponent,
        ClosersPromosComponent,
    ],
    providers: [TextMaskService]
})

export class CustomizeServicesModule { }
