import { serverErrorMessages, APIErrorLists } from './../../common/models/common.model';
import { Observable, Subscription } from 'rxjs/Rx';
import { Store } from '@ngrx/store';
import { AppStore } from './../../common/models/appstore.model';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
    Component, OnInit, Input, Output, AfterViewInit,
    // tslint:disable-next-line:no-unused-variable
    EventEmitter, forwardRef, SimpleChanges, ElementRef, ViewChild, ViewEncapsulation
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { find, cloneDeep } from 'lodash';
import { Logger } from '../../common/logging/default-log.service';
import { Validations } from '../../common/validations/validations';
import { ProductService } from '../../common/service/product.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import { User } from '../../common/models/user.model';
import { GenericValues } from '../../common/models/common.model';
import { DatePipe } from '@angular/common';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { AppConstant } from 'app/app.constant';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'phone-configuration',
    templateUrl: './phone-configuration.component.html',
    styleUrls: ['./phone-configuration.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            // tslint:disable-next-line:no-forward-ref
            useExisting: forwardRef(() => PhoneConfigurationComponent),
            multi: true
        }
    ],
    encapsulation: ViewEncapsulation.None
})
// tslint:disable
export class PhoneConfigurationComponent implements OnInit, ControlValueAccessor, AfterViewInit {
    isLQFlow: boolean = false;
    existingListingData: any;
    isOnHold: boolean = false;
    listingValue: any = 'Listed';
    selectedNonPubList: any;
    isVacSus: boolean = false;
    isOpenAccordian: boolean = false;
    listingFormSelected: boolean = false;
    isListingDataChanged: boolean = false;
    nonPupNoChargeRemoved: boolean;
    nonPubNoChargeValue: boolean;
    isProfileLifelineDiscount: boolean;
    disableAllLifelineFields: boolean = false;
    lifelineProfileExists: boolean = false;
    freezeisActive: boolean;
    adjustmentsResponse: boolean = false;
    custData: any;
    lifelinePotsConfigData: any;
    lifelinePots: any;
    lifelineDHP: any;
    isRentrant: boolean = false;
    emptyTNnumber: boolean = false;
    cartSubscription: Subscription;
    cartObservable: Observable<any>;
    mnValue: string;
    manualTnAssigned: boolean = false;
    billingPotsSelected: boolean = false;
    remainCarrierDisable: boolean = true;
    lifelineInternetExpandPots: boolean = false;
    azmediOptionSelected: boolean = false;
    lifelineCollapesed: boolean = false;
    existingLifelineData: boolean = false;
    lifelineDataAdded: boolean = false;
    public removePOTSLifeline: boolean = false;
    exNickname: any;
    stateChecked: boolean = false;
    validLifelineData: boolean = false;
    discValue: number;
    discountsLifelineData: any;
    public lifelineSubmitted: boolean = false;
    public lifelinePotsAdded: boolean = true;
    @Input() public phonePlan: boolean;
    @Output() phonePlanChange = new EventEmitter<boolean>();
    @Output() selectedListingOption = new EventEmitter<any>();
    public callDetailVal: string = ''
    linkupSelected: boolean = false;
    stateSelected: boolean = false;
    tribalSelected: boolean = false;
    fedaralSelected: boolean = false;
    discountsUpdates: any;
    adjustmentsUpdates: any;
    LifeLineDiscounts: any;
    LifeLineAdjustments: any;
    discountsLifelineDate: any;
    saveLifelineUpdates: any;
    currentFlow: any;
    refreshServiceAddress: any;
    existinglistedAddressOption: any;
    existingProductStoreSubscription: Subscription;
    existingProductStore$: Observable<any>;
    @Input() public previousUrl;
    @Input() public inputData;
    @Input() public isHP;
    @Input() public DisableVoiceMail;
    @Input() public lifelineReponseData;
    @Input() public exInputData;
    @Input() public isReEntrant: boolean;
    @Input() public tnObject;
    @Input() public potsPortedCheck;
    @Input() public savedPhoneTN;
    @Input() public lifelineRespData: any;
    @Input() public macd;
    @Output() public onError = new EventEmitter();
    @Output() public potsListingData = new EventEmitter();
    @Output() public dhpListingData = new EventEmitter();
    @Output() public additionalPortingData = new EventEmitter();
    @Output() public additionalPortingDataAccountId = new EventEmitter();
    @Output() public listedAddressSelected = new EventEmitter();
    @Output() public listedAddressFields = new EventEmitter();
    @Output() public selectedProg = new EventEmitter();
    @Output() public changedAddressListing = new EventEmitter();
    @Output() public clickLifelineContinue: EventEmitter<Object> = new EventEmitter<Object>();
    @Output() public removeLifelineContinue: EventEmitter<Object> = new EventEmitter<Object>();
    @Output() public expandPotsLifelineContinue: EventEmitter<Object> = new EventEmitter<Object>();
    @Output() public isPortingOpen = new EventEmitter();
    @Output() public tnPortingSelected = new EventEmitter();
    @Output() public isAccordionOpen = new EventEmitter();
    @Output() public isTnNoChanged = new EventEmitter();
    @Output() public onTnBackSelectedAgain = new EventEmitter();
    @Output() public listingFormChange = new EventEmitter();
    @Input() public accordianHandler = {
        tn: false,
        listing: false,
        ldCarrier: false,
        voice: false
    };
    @Input() public lifeLineShowing: boolean = false;
    @Input() public lifeLineMasterQualProgList: any;
    @Input() public lifeLineMasterRecurringCredits: any;
    @Input() public lifeLineMasterNonRecurringCredits: any;
    @Input() public formRule: any;
    @Input() public potsOfferName: any;
    @Input() public phoneConfigObj: any
    @Output() phoneLifeLine: EventEmitter<any> = new EventEmitter<any>();
    @Output() callDetailPlan: EventEmitter<any> = new EventEmitter<any>();
    portingwire: boolean;
    portingwireless: boolean;
    WirelessNumber: any;
    wirelesspin: any;
    wireless: any;
    wirelesspininput: any;
    ringHoverText: any;
    fromHold = false;
    isDownstreamAvailable = false;
    cFringHoverText: any;
    public vacationObservable: Observable<any>;
    public vacationSubscription: Subscription;
    @Input() public isAmend: boolean;
    @Input() public isStack: boolean;
    @ViewChild('phoneFieldSet', { static: false, }) phoneField: ElementRef;
    public newLegacyProvider: any;
    hideLifeline() {
        this.lifeLineShowing = false;
        this.lifelineDataAdded = false;
        if (this.phoneConfigObj) this.phoneConfigObj.showHide = false;
        this.phoneLifeLine.emit(false);
        this.removePOTSLifeline = true;
        this.removeLifelineContinue.emit(this.removePOTSLifeline);
        this.lifelineForm = this.fb.group({
            firstName: [(this.lifelineReponseData && this.lifelineReponseData.firstName) ? this.lifelineReponseData.firstName : this.userInfo.firstName, [Validators.required, <any>Validations.nameValidator]],
            lastName: [(this.lifelineReponseData && this.lifelineReponseData.lastName) ? this.lifelineReponseData.lastName : this.userInfo.lastName, [Validators.required, <any>Validations.nameValidator]],
            dateOfBirth: [(this.lifelineReponseData && this.lifelineReponseData.dateOfBirth) ? new DatePipe('en-US').transform(this.lifelineReponseData.dateOfBirth, 'shortDate') : this.dateOfBirth, Validators.required],
            ssnLastFour: [(this.lifelineReponseData && this.lifelineReponseData.ssnLastFour) ? this.lifelineReponseData.ssnLastFour : this.ssnNumber, Validators.required],
            qualProg: [(this.lifelineReponseData && this.lifelineReponseData.qualProg) ? this.lifelineReponseData.qualProg : ''],
            effectiveDate: [this.effectiveDate, Validators.required],
            iehCertDate: [this.iehCertDate, Validators.required],
            expirationDate: [this.expirationDate, Validators.required],
            anniversaryDate: [this.anniversaryDate, Validators.required],
            federalInd: [(this.lifelineReponseData && this.lifelineReponseData.federalInd) ? this.lifelineReponseData.federalInd : false],
            tribalInd: [(this.lifelineReponseData && this.lifelineReponseData.tribalInd) ? this.lifelineReponseData.tribalInd : false],
            stateInd: [(this.lifelineReponseData && this.lifelineReponseData.stateInd) ? this.lifelineReponseData.stateInd : false],
            linkUpInd: [(this.lifelineReponseData && this.lifelineReponseData.linkUpInd) ? this.lifelineReponseData.linkUpInd : false],
            linkupSvcDate: [this.linkupSvcDate],
            caseNumber: [(this.lifelineReponseData && this.lifelineReponseData.caseNumber) ? this.lifelineReponseData.caseNumber : ''],
            acpInd: [(this.lifelineReponseData && this.lifelineReponseData.acpInd) ? this.lifelineReponseData.acpInd : false],
            ruralInd: [(this.lifelineReponseData && this.lifelineReponseData.ruralInd) ? this.lifelineReponseData.ruralInd : false],
            nladData: [{
                serviceDate: [(this.lifelineReponseData && this.lifelineReponseData.nladData.serviceDate) ? this.lifelineReponseData.nladData.serviceDate : ''],
                subscriberId: [(this.lifelineReponseData && this.lifelineReponseData.nladData.subscriberId) ? this.lifelineReponseData.nladData.subscriberId : ''],
            }]
        });
    }
    public addOnAttributes = {
        title1: '',
        title2: '',
        designation: '',
        Nickname: '',
        lineage: ''
    }
    public listingFlags = {
        showListingForm: false,
        showProvidedFlag: false,
        showNotProvidedFlag: false
    }
    public userStore;
    public defaultTN: any;
    public phoneMask: any;
    public callFwdPhoneMask: any;
    public carrierInfo: any;
    public selectedPortedTn: string;
    public errorMsg: any;
    public carrierList: any;
    public carrierListURL: string;
    public ssnNumber: any;
    public dateOfBirth: any;
    public lifelineConfigObj: any;
    public lifelineOption: boolean = false;
    public ssn: any;
    public addlOrderAttributesPorting: any;
    public addlOrderAttributesPortingYes: any;
    public telephoneNumberResponse: string;
    public portingUnknown: any;
    public possibleDesiredDueDate: string;
    public saveUpdates: any;
    public isVacRes: boolean = false;
    public phoneConfigForm: FormGroup;
    public loading;
    propagateChange = (_: any) => { };
    public lifelineResponseCust = {};
    public potsAddonsData: any;
    public dhpAddonsData: any;
    public OFFER_CHECK_NAME = '';
    public directoryListingData;
    private selectedListing: any;
    public listedAddressOptions: any;
    public isVacRestore: Observable<any>;
    public addressListing: any;
    public updatedListedAddress: any;
    public selectedListedType: any;
    public exSelectedOption: any;
    public nladData: any;
    public isLifelineShow: boolean = true;
    nladDateResponse: boolean = false;
    expLifelineSelected: boolean;
    discountChanges: boolean = false;
    private lifelineResponse = {
        "lifelineInd": true,
        "llServiceType": "VOICE",
        "productDetails": {
            "ban": 300021686,
            "productType": "T",
            "csrId": 1061338
        },
        "LifeLineConfig": {
            "firstName": "Whitney",
            "lastName": "Johnson",
            "dateOfBirth": "2018-06-13T10:42:47.749Z",
            "ssnLastFour": 5689,
            "federalInd": true,
            "tribalInd": true,
            "stateInd": true,
            "linkUpInd": true,
            "linkupSvcDate": "10/31/2018",
            "qualProg": "BDS: Badger Care",
            "effectiveDate": "11/22/2017",
            "iehCertDate": "11/22/2017",
            "expirationDate": "12/31/9999",
            "anniversaryDate": "11/22/2017",
            "caseNumber": "1234-01",
            "acpInd": true,
            "ruralInd": false,
            "nladData": {
                "subscriberId": "LLID 3252413, NVID 3025266245, NVAP 3023241",
                "serviceDate": "11/22/2017"
            }
        },
        "LifeLineDiscounts": {
            "discounts": [
                {
                    "llarcCreditInd": true,
                    "discountCode": "MEDTAP",
                    "recurringStateCreditDesc": "ARC Recurring Credit (LLARC)",
                    "startDate": "2/20/2018",
                    "endDate": "12/31/9999",
                    "zone1Ind": true,
                    "zone2Ind": true,
                    "WireMaintanaceInd": true,
                    "actionType": "ADD"
                }
            ]
        },
        "LifeLineAdjustments": {
            "adjustments": [
                {
                    "adjustmentReason": "AJLIFE",
                    "nonRecurringStateCreditDesc": "Lifeline Adjustment (AJLIFE)",
                    "adjustmentAmount": 50,
                    "actionType": "ADD"
                }
            ]
        },
        "LifeLineMasterQualProgList": [
            {
                "lifelineQualifyingProgram": "string"
            }
        ],
        "LifeLineMasterRecurringCredits": [
            {
                "lifelineCreditType": "Recurring Credit",
                "lifeLineCreditCodeDesc": "ARC Recurring Credit (LLARC)",
                "lifeLineCreditCode": "string",
                "isSelected": true
            }
        ],
        "LifeLineMasterNonRecurringCredits": [
            {
                "lifelineCreditType": "Recurring Credit",
                "lifeLineCreditCodeDesc": "ARC Recurring Credit (LLARC)",
                "lifeLineCreditCode": "string",
                "isSelected": true
            }
        ]
    };
    public selectedQualProg: any;
    public cachedAssignedTN;
    public preselectedListing;
    public exListedAddress;
    public exFirstName;
    public exLastName;
    public exTitle1;
    public exTitle2;
    public exLineage;
    public exDesignation;
    //listed address
    public exStreetNrFirst;
    public exStreetNamePrefix;
    public exStreetType;
    public exStreetName;
    public exUnit;
    public exCity;
    public exState;
    public exPostCode;
    public otherlistingOptions: any[];
    public apiResponseError: APIErrorLists;
    @Input() public compatibility;
    selectedAssessCharge: any;

    @Input('potsAddOns')
    set potsAddOns(addons: any) {
        this.OFFER_CHECK_NAME = 'Home Phone Directory Listing';
        this.potsAddonsData = addons;
        this.directoryListingData = this.getOptionsForDirectoryListing(this.potsAddonsData);
    }
    @Input('nonpubNoChargeSelected')
    set nonpubNoChargeSelected(one: boolean) {
        this.nonPubNoChargeValue = one;
        this.nonPupNoChargeRemoved = false;
        let custData = <Observable<any>>this.store.select('customize');
        custData.subscribe((data) => {
            this.nonPupNoChargeRemoved = data.nonpubremoved;
        });
        this.directoryListingData = this.getOptionsForDirectoryListing(this.potsAddonsData);
        if (this.nonPupNoChargeRemoved && !this.nonPubNoChargeValue) {
            if (this.directoryListingData.length > 0) {
                for (let i = 0; i < this.directoryListingData.length; i++) {
                    if (this.directoryListingData[i].name === "Non-Pub No Charge") {
                        this.directoryListingData.splice(i, 1);
                    }
                    if ((this.selectedNonPubList !== undefined && this.selectedNonPubList) === (this.selectedListing !== undefined && (this.selectedListing.name || this.selectedListing))) {
                        if (this.directoryListingData[i].name === "Listed") {
                            this.listingValue = this.directoryListingData[i].name;
                        }
                    }
                }
            }
            this.isListingDataChanged = false;
        }
        if (this.nonPubNoChargeValue) {
            this.isOpenAccordian = true;
            if (this.directoryListingData.length > 0) {
                for (let i = 0; i < this.directoryListingData.length; i++) {
                    if (this.directoryListingData[i].name === "Non-Pub No Charge") {
                        this.listingValue = this.directoryListingData[i].name;
                    }
                }
                if (this.isListingDataChanged) {
                    this.isListingDataChanged = false;
                }
            }
        }

        if (this.nonPubNoChargeValue && !this.isListingDataChanged) {
            this.selectedListing = "Non-Pub No Charge";
            this.selectedNonPubList = cloneDeep(this.selectedListing);
            this.potsListingData.emit(this.selectedListing);
        }
    }
    @Input() public assessCharge;

    @Input('dhpAddons')
    set dhpAddons(addons: any) {
        this.OFFER_CHECK_NAME = 'Digital Home Phone Directory Listing';
        this.dhpAddonsData = addons;
        this.directoryListingData = this.getOptionsForDirectoryListing(this.dhpAddonsData);
    }

    @Input() set restrictivePotsSelected(isClicked: boolean) {
        let defaultInterlata = '';
        let defaultIntraLata = '';
        if (this.inputData) {
            this.inputData.ldCarrierData.intraLataArray = this.ldRemoveEmptyValues(this.inputData.ldCarrierData.intraLataArray);
            let temp = find(this.inputData.ldCarrierData.intraLataArray, (o) => o.isDefault == true);
            if (temp) {
                defaultIntraLata = temp.value;
            } else {
                defaultIntraLata = this.legacyProvider !== 'CENTURYLINK' ? "9199-NONE" : "10X1 - No PIC";
                this.inputData.ldCarrierData.intraLataArray = [
                    {
                        value: defaultIntraLata,
                        isDefault: true
                    }];
            }
            this.inputData.ldCarrierData.interLataArray = this.ldRemoveEmptyValues(this.inputData.ldCarrierData.interLataArray);
            temp = find(this.inputData.ldCarrierData.interLataArray, (o) => o.isDefault == true);
            if (temp) {
                defaultInterlata = temp.value;
            } else {
                defaultInterlata = this.legacyProvider !== 'CENTURYLINK' ? "NONE" : "10X1 - No PIC";
                this.inputData.ldCarrierData.interLataArray = [
                    {
                        value: defaultInterlata,
                        isDefault: true
                    }]
            }
        }
        if (this.phoneConfigForm) {
            this.phoneConfigForm.get('ldCarrierForm.selectedInterCarrierOption').setValue(defaultInterlata);
            this.phoneConfigForm.get('ldCarrierForm.selectedIntraCarrierOption').setValue(defaultIntraLata);
        }
    }


    public phoneNumberSelected = false;
    public errors = {
        tnForm: {
            error: false,
            message: '',
            charterCable: false,
            unVerifiedAddress: false,
            unVerifiedNumber: false,
            notPortable: false,
            tnConfirmClicked: false,
            verifiedNumber: false,
            validateOffline: false,
            showRetainOption: true
        },
        listingForm: { error: false, message: '' },
        ldCarrierForm: { error: false, message: '' },
        additionalConfig: { error: false, message: '' },
        callForwarding: { error: false, message: '', onDontAnswer: false, onBusy: false }
    }
    public user: Observable<User>;
    public userSubscription: Subscription;
    public userStoreSubscription: Subscription;
    public userInfo;
    public existingInfo;
    public date = new Date();
    public removeExpDate: string = "<>9999-12-31";
    public expDate: string;
    public linkupSvcDate: string;
    public effectiveDate: string;
    public iehCertDate: string;
    public expirationDate: string;
    public anniversaryDate: string;
    public federalLinkToggle: boolean = false;
    public lifelineForm: any;
    public emptyMask = "";
    public freezeData: any;
    public oldCallForwardingNoAnswer;
    public oldCallForwardingBusy;

    public serviceUnavailable: any;
    public group1: any;
    public group2: any;
    public group3: any;
    public group4: any;
    public group5: any;
    @Input() public switchData;
    public legacyProvider: any;

    private ldRemoveEmptyValues(ld) {
        let finalLDArray = [];
        ld && ld.map(ldArray => {
            if (ldArray && ldArray.value && ldArray.value !== '') finalLDArray.push(ldArray);
        });
        return finalLDArray;
    }

    @Input() set cFNoAnswerSelected(noAnswer: boolean) {
        if (noAnswer) {
            let ringCycle = this.inputData.voiceMailData.ringCycleArray;
            if (ringCycle) {
                this.getSwitchRulesByTN(this.inputData.tnData.selectedTN, ringCycle, noAnswer);
            }
        }
    }
    private getSwitchRulesByTN(tn, noRingCycle?, noAnswer?) {
        let flag = false;
        this.loading = true;
        this.logger.log("info", "customize-services.component.ts - getCompatibilityRules", "fetchRulesRequest", JSON.stringify(tn));
        this.logger.startTime();
        this.productService.getSwitchByTN(tn)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesResponse", error);
                this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "SUBMIT_TASK", "customize-services.component.ts - getCompatibilityRules", "CustomizeService Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "customize-services.component.ts - getCompatibilityRules", "fetchRulesResponse", JSON.stringify(data ? data : ""));
                this.logger.log("info", "customize-services.component.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.switchData = data;
                if (this.switchData) {
                    this.switchData.outputAttribute && this.switchData.outputAttribute.map(attr => {
                        if (noAnswer && attr && attr[3] && attr[3].replace(/\s/g, "") === 'CallForwarding-NoAnswer' && attr[16] && attr[16].toLowerCase() === 'ring cycle' &&
                            attr[6] && (attr[6] === 'NOTAVAILABLE' || attr[6] === 'INCOMPATIBLE') && attr[6] && attr[17]) {
                            if (attr[9].replace(/\s/g, "") === 'VoiceMessaging') {
                                let ringCycle = this.inputData.voiceMailData.ringCycleArray;
                                ringCycle && ringCycle.map(ring => {
                                    if (ring && ring.value.indexOf(attr[17]) !== -1) {
                                        ring.disable = true;
                                        flag = true;
                                        this.ringHoverText = attr[14];
                                    }
                                })
                                this.inputData.voiceMailData.ringCycleArray = ringCycle;
                            } else if (attr[9].replace(/\s/g, "") === 'CallForwarding-NoAnswer') {
                                let ringCycle = this.inputData.callForwarding.ringCycleArray;
                                ringCycle && ringCycle.map(ring => {
                                    if (ring && ring.value.indexOf(attr[17]) !== -1) {
                                        ring.disable = true;
                                        flag = true;
                                        this.cFringHoverText = attr[14];
                                    }
                                })
                                this.inputData.callForwarding.ringCycleArray = ringCycle;
                            }
                        }
                    })
                }
                if (!flag) this.ringHoverText = '';
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesResponse", error);
                this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (error === undefined || error === null)
                    return;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", this.apiResponseError);
                    }
                    else
                        unexpectedError = true;
                }
                else
                    unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.inputData.orderReferenceNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }
    public disablePortingMsg: string = '';
    public disablePortedTN: boolean = false;

    constructor(private logger: Logger,
        private fb: FormBuilder,
        private store: Store<AppStore>,
        private productService: ProductService,
        private textMask: TextMaskService,
        private helperService: HelperService,
        private ctlHelperService: CTLHelperService,
        private systemErrorService: SystemErrorService,
        private appStateService: AppStateService,
        private offerHelperService: OfferHelperService
    ) {
        this.loading = true;
        this.logger.log("info", "phone-configuration.component.ts", "getFreezeDropDownRequest", JSON.stringify(""));
        this.logger.startTime();
        this.productService.getFreezeDropDown()
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "phone-configuration.component.ts", "getFreezeDropDownResponse", error);
                this.logger.log("error", "phone-configuration.component.ts", "getFreezeDropDownSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage('error', error);
                return Observable.throw(error._body);
            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "phone-configuration.component.ts", "getFreezeDropDownResponse", JSON.stringify(data));
                this.logger.log("info", "phone-configuration.component.ts", "getFreezeDropDownSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data && data.outputAttribute) {
                    this.freezeData = data;
                }
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "phone-configuration.component.ts", "getFreezeDropDownResponse", error);
                this.logger.log("error", "phone-configuration.component.ts", "getFreezeDropDownSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.freezeData = {
                    "outArrHeader": [
                        "ruleName",
                        "freezeType",
                        "freezePresent",
                        "LOV",
                        "default"
                    ],
                    "outputAttribute": [
                        [
                            "picFreezeRule",
                            "AccessLine",
                            "FALSE",
                            "Not Added",
                            "yes"
                        ],
                        [
                            "picFreezeRule",
                            "intraLATA",
                            "TRUE",
                            "Remove Freeze",
                            null
                        ],
                        [
                            "picFreezeRule",
                            "intraLATA",
                            "FALSE",
                            "Add Freeze",
                            null
                        ],
                        [
                            "picFreezeRule",
                            "intraLATA",
                            "TRUE",
                            "Freeze is active",
                            "Yes"
                        ],
                        [
                            "picFreezeRule",
                            "intraLATA",
                            "FALSE",
                            "Not Added",
                            "yes"
                        ],
                        [
                            "picFreezeRule",
                            "AccessLine",
                            "FALSE",
                            "Add Freeze",
                            null
                        ],
                        [
                            "picFreezeRule",
                            "AccessLine",
                            "TRUE",
                            "Freeze is active",
                            "Yes"
                        ],
                        [
                            "picFreezeRule",
                            "interLATA",
                            "FALSE",
                            "Not Added",
                            "yes"
                        ],
                        [
                            "picFreezeRule",
                            "interLATA",
                            "FALSE",
                            "Add Freeze",
                            null
                        ],
                        [
                            "picFreezeRule",
                            "interLATA",
                            "TRUE",
                            "Freeze is active",
                            "Yes"
                        ],
                        [
                            "picFreezeRule",
                            "AccessLine",
                            "TRUE",
                            "Remove Freeze",
                            null
                        ],
                        [
                            "picFreezeRule",
                            "interLATA",
                            "TRUE",
                            "Remove Freeze",
                            null
                        ]
                    ]
                }
            })
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.callFwdPhoneMask = this.textMask.getPhoneNumberMaskTN();
        this.nladData = '';
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.userInfo = data;
            this.lifelineResponseCust = this.lifelineResponse.LifeLineConfig;
            if (this.userInfo.previousUrl === "/schedule-appt-ship" && this.userInfo.currentUrl === "/customize-services") {
                this.isRentrant = true;
            } else {
                this.isRentrant = false;
                this.isRentrant = data.reEntrant;
            }
            this.isProfileLifelineDiscount = this.helperService.isAuthorized(ProfileEnums.LIFELINE_DISCOUNT);
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress &&
                data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider === 'CENTURYLINK') {
                this.legacyProvider = 'CENTURYLINK';
            }
            if (data && data.orderInit && data.orderInit.payload
                && data.orderInit.payload.newLocation && data.orderInit.payload.newLocation.serviceAddress
                && data.orderInit.payload.newLocation.serviceAddress.locationAttributes && data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider) {

                this.newLegacyProvider = data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider;
            }
        });
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
        this.cartObservable = <Observable<any>>store.select('customize');
        this.cartSubscription = this.cartObservable.subscribe((data) => {
            if (data && data.payload && data.payload.reservedTN && data.payload.reservedTN !== undefined) {
                data.payload.reservedTN.map((data) => {
                    if (data.productType !== "VOICE-HP" || data.productType !== "VOICE-DHP") {
                        this.emptyTNnumber = true;
                    } else {
                        this.emptyTNnumber = false;
                    }
                    if (data.productType === "VOICE-HP" && data.tnType && (data.tnType.toUpperCase() === "Z" || data.tnType.toUpperCase() === "R") && this.legacyProvider === 'CENTURYLINK') {
                        this.disablePortedTN = true;
                        this.disablePortingMsg = AppConstant.TNPORTING_DISABLE_NON_METRO_AND_EAS;
                    }
                    // If CGS server is not available
                    this.isDownstreamAvailable = data.requestedTelephoneNumber === '9999999999' ? true : false;
                })
            }
        });
        if (this.cartSubscription !== undefined) this.cartSubscription.unsubscribe();
        this.existingProductStore$ = <Observable<any>>store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            if (respData && respData.orderFlow && respData.orderFlow.flow) {
                this.currentFlow = respData.orderFlow.flow;
            }

            if (respData && respData.orderFlow && respData.orderFlow.flow === "billing") {
                this.billingPotsSelected = true;
            }

            if (respData && respData.existingProductsAndServices && respData.existingProductsAndServices[0].serviceAddress) {
                this.refreshServiceAddress = respData.existingProductsAndServices[0].serviceAddress;
            }

            this.existingInfo = respData;
            if (this.currentFlow === 'Change' || this.currentFlow === "Move" || this.currentFlow === "billing" || this.isAmend || this.isStack) {
                this.lifelineOption = true;
                if (respData && respData.existingProductsAndServices && respData.existingProductsAndServices[0] &&
                    respData.existingProductsAndServices[0].accountInfo && respData.existingProductsAndServices[0].accountInfo.personalDetails) {
                    this.ssnNumber = respData.existingProductsAndServices[0].accountInfo.personalDetails.ssn && respData.existingProductsAndServices[0].accountInfo.personalDetails.ssn.slice(5, 9);
                    if (respData.existingProductsAndServices[0].accountInfo.personalDetails.dateOfBirth)
                        this.dateOfBirth = new DatePipe('en-US').transform(respData.existingProductsAndServices[0].accountInfo.personalDetails.dateOfBirth, "MM/dd/yyyy");
                }
            }
            if (respData && respData.existingProductsAndServices && respData.existingProductsAndServices[0] && respData.existingProductsAndServices[0].serviceAddress
                && respData.existingProductsAndServices[0].serviceAddress.locationAttributes) {
                this.legacyProvider = respData.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
            }
            if (this.newLegacyProvider == 'CENTURYLINK' && this.currentFlow && this.currentFlow.toUpperCase() == 'MOVE') {
                this.disablePortedTN = true;
                this.disablePortingMsg = AppConstant.TNPORTING_DISABLE_MOVE_LC;
            }
        });
        this.isLQFlow = this.offerHelperService.legacyValue();
        if (this.existingProductStoreSubscription !== undefined) this.existingProductStoreSubscription.unsubscribe();
        if (this.isAmend)
            this.disablePortingMsg = AppConstant.AMEND_DISABLE_PORTING;
    }

    checkEnable() {
        (<HTMLInputElement>document.getElementById("federal")).checked = true;

    }
    writeValue(value: any) {

    }

    ngOnChanges(changes: SimpleChanges): void {
    }

    public ngAfterViewInit() {
        if (this.assessCharge) {
            this.store.dispatch({ type: 'ASSESS_CHARGE', payload: this.assessCharge });
        }
    }


    ngDoCheck(): void {

        // TODO : improve this logic and code later:
        // in short we are manually checking if the checkbox gets checked.
        if (this.oldCallForwardingNoAnswer !== this.inputData.callForwarding.callForwardingNoAnswer) {
            this.errors.callForwarding.onDontAnswer = this.inputData.callForwarding.callForwardingNoAnswer && this.phoneConfigForm.get('callfwdForm').get('fwdOnDontAnswer').value.length !== 12;
            let val = this.phoneConfigForm.get('callfwdForm').get('fwdOnDontAnswer').value;
            if (this.errors.callForwarding.onDontAnswer && val && val.indexOf("-") === -1 && val.length === 10) {
                this.errors.callForwarding.onDontAnswer = false;
            }
            this.errors.callForwarding.onBusy = this.inputData.callForwarding.callForwardingBusy && this.phoneConfigForm.get('callfwdForm').get('fwdOnBusy').value.length !== 12;
            val = this.phoneConfigForm.get('callfwdForm').get('fwdOnBusy').value;
            if (this.errors.callForwarding.onBusy && val && val.indexOf("-") === -1 && val.length === 10) {
                this.errors.callForwarding.onBusy = false;
            }
            this.oldCallForwardingNoAnswer = this.inputData.callForwarding.callForwardingNoAnswer;
        }

        if (this.oldCallForwardingBusy !== this.inputData.callForwarding.callForwardingBusy) {
            this.errors.callForwarding.onDontAnswer = this.inputData.callForwarding.callForwardingNoAnswer && this.phoneConfigForm.get('callfwdForm').get('fwdOnDontAnswer').value.length !== 12;
            let val = this.phoneConfigForm.get('callfwdForm').get('fwdOnDontAnswer').value;
            if (this.errors.callForwarding.onDontAnswer && val && val.indexOf("-") === -1 && val.length === 10) {
                this.errors.callForwarding.onDontAnswer = false;
            }
            this.errors.callForwarding.onBusy = this.inputData.callForwarding.callForwardingBusy && this.phoneConfigForm.get('callfwdForm').get('fwdOnBusy').value.length !== 12;
            val = this.phoneConfigForm.get('callfwdForm').get('fwdOnBusy').value;
            if (this.errors.callForwarding.onBusy && val && val.indexOf("-") === -1 && val.length === 10) {
                this.errors.callForwarding.onBusy = false;
            }
            this.oldCallForwardingBusy = this.inputData.callForwarding.callForwardingBusy;
        }

        if (this.errors.callForwarding.onBusy || this.errors.callForwarding.onDontAnswer) {
            this.setError("callForwarding", true, "Enter a valid number");
        } else {
            this.setError("callForwarding", false);
        }
    }

    /* public setTitle(input){
        for (var i=0; i < input.length; i++) {
            input[i].setAttribute("title", AppConstant.AMEND_MESSAGE);
        }
    } */

    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    public existinglifelineExpandPots() {
        this.lifelineInternetExpandPots = true;
        this.expandPotsLifelineContinue.emit(this.lifelineInternetExpandPots);
    }
    registerOnTouched() { }

    private directoryListingOTCToCart(data, type) {
        if (data) {
            let productType = type === 'hp' ? 'HP ADDON OFFER' : 'DHP ADDON OFFER';
            let deliveryToCart = {
                productId: '',
                name: data.name,
                productType: productType,
                isRegulated: '',
                prices:
                    [
                        {
                            discountedRc: 0,
                            discountedOtc: data.price,
                            otc: data.price,
                            rc: 0
                        }
                    ]
            };
            this.store.dispatch({ type: 'UPDATE_LISTING_ADDON', payload: deliveryToCart });
        }
        else {
            this.clearListingOTC();
        }
    }

    clearListingOTC() {
        let deliveryToCart = {
            productId: '',
            name: '',
            productType: this.inputData.configType === 'hp' ? 'HP ADDON OFFER' : 'DHP ADDON OFFER',
            isRegulated: '',
            prices:
                [
                    {
                        discountedRc: 0,
                        discountedOtc: 0,
                        otc: 0,
                        rc: 0
                    }
                ]
        };
        this.store.dispatch({ type: 'UPDATE_LISTING_ADDON', payload: deliveryToCart });
    }

    listingDataChanged(event, val?) {
        this.isListingDataChanged = val;
        const value = event;
        let flagOTC = false;
        if (val) {
            this.selectedListingOption.emit(value);
            if (value.indexOf("Non-Pub No Charge") === -1) {
                this.nonPubNoChargeValue = false;
                if (this.directoryListingData.length > 0) {
                    for (let i = 0; i < this.directoryListingData.length; i++) {
                        if (this.directoryListingData[i].name === "Non-Pub No Charge") {
                            this.directoryListingData.splice(i, 1);
                        }
                    }
                }
            }
        }
        if (value && this.directoryListingData) {
            this.directoryListingData.map(v => {
                if (value === v.name) {
                    this.selectedListing = v;
                }
            });

            if (this.exSelectedOption && this.selectedListing && this.exSelectedOption[0].value !== this.selectedListing) {
                let changedToListing = [];

                if (this.exSelectedOption[0].value === 'Listed') {
                    if (this.selectedListing && this.selectedListing.name === 'Non-Listed') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Listed';
                        })
                    }
                    else if (this.selectedListing && this.selectedListing.name === 'Non-Published') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Published';
                        })
                    }
                }
                else if (this.exSelectedOption[0].value === 'Non-Listed') {
                    if (this.selectedListing.name === 'Listed') {
                        this.clearListingOTC();
                    }
                    else if (this.selectedListing && this.selectedListing.name === 'Non-Published') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Published';
                        })
                    }
                }
                else if (this.exSelectedOption[0].value === 'Non-Published') {
                    if (this.selectedListing && this.selectedListing.name === 'Listed') {
                        this.clearListingOTC();
                    }
                    else if (this.selectedListing.name === 'Non-Listed') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Listed';
                        })
                    }
                }

                this.directoryListingOTCToCart(changedToListing[0], this.inputData.configType);
                flagOTC = true;
            }
            else {
                this.clearListingOTC();
            }

            if (this.isHP) {
                this.dhpListingData.emit(this.selectedListing);
            }
            else if (!this.nonPubNoChargeValue) {
                this.potsListingData.emit(this.selectedListing);
            }
            if (this.selectedListing && this.selectedListing.name == "Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = false;
            } else if (this.selectedListing && this.selectedListing.name == "Non-Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = true;
            } else if (this.selectedListing && this.selectedListing.name == "Non-Published") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = true;
                this.listingFlags.showProvidedFlag = false;
            }
        }

    }
    public ListingDetails(item) {
        item && item.configDetails && item.configDetails.map(config => {
            config.formItems && config.formItems.map(form => {
                if (form.attributeName === 'Listing Type') {
                    this.exSelectedOption = form.attributeValue;
                    if (this.exSelectedOption && this.exSelectedOption[0] && this.exSelectedOption[0].value) {
                        this.phoneConfigForm.get('listingForm.selectedOption').setValue(this.exSelectedOption[0].value);
                        this.listingValue = this.exSelectedOption[0].value;
                        this.listingDataChanged(this.exSelectedOption[0].value, false);
                    }
                }
                if (form.attributeName === 'Listed Address Option') {
                    this.exListedAddress = form.attributeValue;
                }
                if (form.attributeName === 'First Name') {
                    this.exFirstName = form.attributeValue;
                }
                if (form.attributeName === 'Last Name') {
                    this.exLastName = form.attributeValue;
                }
                if (form.attributeName === 'Title 1') {
                    this.exTitle1 = form.attributeValue[0].value;
                    this.addOnAttributes.title1 = this.exTitle1;
                }
                if (form.attributeName === 'Title 2') {
                    this.exTitle2 = form.attributeValue[0].value;
                    this.addOnAttributes.title2 = this.exTitle2;
                }
                if (form.attributeName === 'Lineage') {
                    this.exLineage = form.attributeValue[0].value;
                    this.addOnAttributes.lineage = this.exLineage;
                }
                if (form.attributeName === 'Designation') {
                    this.exDesignation = form.attributeValue[0].value;
                    this.addOnAttributes.designation = this.exDesignation;
                }
                if (form.attributeName === 'Nickname') {
                    this.exNickname = form.attributeValue[0].value;
                    this.addOnAttributes.Nickname = this.exNickname;
                }
                if (form.attributeName === 'streetNrFirst') {
                    this.exStreetNrFirst = form.attributeValue[0].value;
                }
                if (form.attributeName === 'streetNamePrefix') {
                    this.exStreetNamePrefix = form.attributeValue[0].value;
                }
                if (form.attributeName === 'streetType') {
                    this.exStreetType = form.attributeValue[0].value;
                }
                if (form.attributeName === 'streetName') {
                    this.exStreetName = form.attributeValue[0].value;
                }
                if (form.attributeName === 'Unit') {
                    this.exUnit = form.attributeValue[0].value;
                }
                if (form.attributeName === 'city') {
                    this.exCity = form.attributeValue[0].value;
                }
                if (form.attributeName === 'state') {
                    this.exState = form.attributeValue[0].value;
                }
                if (form.attributeName === 'postCode') {
                    this.exPostCode = form.attributeValue[0].value;
                }
            })
        });
        this.onSaveUpdate(this.addOnAttributes);
    }
    public ngOnInit() {
        this.logger.metrics('PhoneConfigurationPage');
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacResFlow) this.isVacRes = true;
                else this.isVacRes = false;
                if (data.vacFlowName.isVacSusFlow) this.isVacSus = true;
                else this.isVacSus = false;
            }
        });
        let pendingObservable = <Observable<any>>this.store.select('pending');
        let pendingSubscription = pendingObservable.subscribe(pending => {
            if (pending && pending.orderReference && pending.orderReference.customerOrderStatus && pending.orderReference.customerOrderStatus === "ONHOLD") {
                this.isOnHold = true;
                pending.orderDocument && pending.orderDocument.productConfiguration && pending.orderDocument.productConfiguration.map(data => {
                    if (data.productType === "VOICE-HP") {
                        this.existingListingData = data.configItems;
                    }
                })
            } else {
                this.isOnHold = false;
            }

        });
        let lifelineDetainRetain = <Observable<any>>this.store.select('customize');
        lifelineDetainRetain.subscribe((data) => {
            if (data && data.payload && data.payload !== undefined && data.payload.existingProductConfiguration !== undefined && data.payload.existingProductConfiguration.length > 0) {
                for (let i = 0; i < data.payload.existingProductConfiguration.length; i++) {
                    if (data.payload.existingProductConfiguration[i].productType === "VOICE-HP") {
                        if (data.payload.existingProductConfiguration[i] && data.payload.existingProductConfiguration[i] !== null && data.payload.existingProductConfiguration[i].configItems && data.payload.existingProductConfiguration[i].configItems.length > 0) {
                            for (let j = 0; j < data.payload.existingProductConfiguration[i].configItems.length; j++) {
                                data.payload.existingProductConfiguration[i].configItems[j].configDetails.map(data => {
                                    data && data.formItems && data.formItems !== undefined && data.formItems.map(formData => {
                                        if (formData.attributeValue[0].value == "Freeze is active") {
                                            this.freezeisActive = true;
                                        }
                                    })
                                })
                            }
                        }
                    }
                }
            }
            this.lifelinePots = data.lifelineaddedforpots;
            this.lifelineDHP = data.lifelineaddedfordhp;
            this.lifelinePotsConfigData = data.lifelinePotsConfig;
            if (data && data.selectedAssessCharge) {
                this.selectedAssessCharge = data.selectedAssessCharge;
            }
        });
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            this.lifelineDataAdded = true;
        } else {
            this.lifelineDataAdded = false;
        }
        this.date = new Date();
        this.expDate = "9999-12-31";
        if (!this.isRentrant) {
            this.linkupSvcDate = (this.lifelineReponseData && this.lifelineReponseData.linkupSvcDate) ? this.lifelineReponseData.linkupSvcDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
            this.effectiveDate = (this.lifelineReponseData && this.lifelineReponseData.effectiveDate) ? this.lifelineReponseData.effectiveDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
            this.iehCertDate = (this.lifelineReponseData && this.lifelineReponseData.iehCertDate) ? this.lifelineReponseData.iehCertDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
            this.expirationDate = (this.lifelineReponseData && this.lifelineReponseData.expirationDate) ? this.lifelineReponseData.expirationDate : new DatePipe('en-US').transform(this.expDate, "MM/dd/yyyy");
            this.anniversaryDate = (this.lifelineReponseData && this.lifelineReponseData.anniversaryDate) ? this.lifelineReponseData.anniversaryDate : new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
        } else {
            this.linkupSvcDate = new DatePipe('en-US').transform(this.lifelinePotsConfigData && this.lifelinePotsConfigData !== undefined && this.lifelinePotsConfigData.linkupSvcDate !== undefined && this.lifelinePotsConfigData.linkupSvcDate, "MM/dd/yyyy");
            this.effectiveDate = new DatePipe('en-US').transform(this.lifelinePotsConfigData && this.lifelinePotsConfigData !== undefined && this.lifelinePotsConfigData.effectiveDate !== undefined && this.lifelinePotsConfigData.effectiveDate, "MM/dd/yyyy");
            this.iehCertDate = new DatePipe('en-US').transform(this.lifelinePotsConfigData && this.lifelinePotsConfigData !== undefined && this.lifelinePotsConfigData.iehCertDate !== undefined && this.lifelinePotsConfigData.iehCertDate, "MM/dd/yyyy");
            this.expirationDate = new DatePipe('en-US').transform(this.lifelinePotsConfigData && this.lifelinePotsConfigData !== undefined && this.lifelinePotsConfigData.expirationDate !== undefined && this.lifelinePotsConfigData.expirationDate, "MM/dd/yyyy");
            this.anniversaryDate = new DatePipe('en-US').transform(this.lifelinePotsConfigData && this.lifelinePotsConfigData !== undefined && this.lifelinePotsConfigData.anniversaryDate !== undefined && this.lifelinePotsConfigData.anniversaryDate, "MM/dd/yyyy");
        }
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            this.existingLifelineData = true;
            if (this.lifelineReponseData.federalInd) {
                this.fedaralSelected = true;
            }
            if (this.lifelineReponseData.tribalInd) {
                this.tribalSelected = true;
            }
            if (this.lifelineReponseData.stateInd) {
                this.stateSelected = true;
            }
            if (this.lifelineReponseData.linkUpInd) {
                this.linkupSelected = true;
            }
        }
        if (this.lifelineReponseData && this.lifelineReponseData.federalInd !== undefined && this.lifelineReponseData.federalInd && this.lifelineReponseData.tribalInd !== undefined && this.lifelineReponseData.tribalInd && this.lifelineReponseData.linkUpInd !== undefined && this.lifelineReponseData.linkUpInd) {
            this.federalLinkToggle = true;
        } else {
            this.federalLinkToggle = false;
        }
        if (this.lifelinePotsConfigData && this.lifelinePotsConfigData.federalInd !== undefined && this.lifelinePotsConfigData.federalInd && this.lifelinePotsConfigData.tribalInd !== undefined && this.lifelinePotsConfigData.tribalInd && this.lifelinePotsConfigData.linkUpInd !== undefined && this.lifelinePotsConfigData.linkUpInd) {
            this.federalLinkToggle = true;
        }
        if (!this.isRentrant) {
            this.lifelineForm = this.fb.group({
                firstName: [(this.lifelineReponseData && this.lifelineReponseData.firstName) ? this.lifelineReponseData.firstName : this.userInfo.firstName, [Validators.required, <any>Validations.nameValidator]],
                lastName: [(this.lifelineReponseData && this.lifelineReponseData.lastName) ? this.lifelineReponseData.lastName : this.userInfo.lastName, [Validators.required, <any>Validations.nameValidator]],
                dateOfBirth: [(this.lifelineReponseData && this.lifelineReponseData.dateOfBirth) ? new DatePipe('en-US').transform(this.lifelineReponseData.dateOfBirth, 'shortDate') : this.dateOfBirth, Validators.required],
                ssnLastFour: [(this.lifelineReponseData && this.lifelineReponseData.ssnLastFour) ? this.lifelineReponseData.ssnLastFour : this.ssnNumber, Validators.required],
                qualProg: [(this.lifelineReponseData && this.lifelineReponseData.qualProg) ? this.lifelineReponseData.qualProg : ''],
                effectiveDate: [this.effectiveDate, Validators.required],
                iehCertDate: [this.iehCertDate, Validators.required],
                expirationDate: [this.expirationDate, Validators.required],
                anniversaryDate: [this.anniversaryDate, Validators.required],
                federalInd: [(this.lifelineReponseData && this.lifelineReponseData.federalInd) ? this.lifelineReponseData.federalInd : false],
                tribalInd: [(this.lifelineReponseData && this.lifelineReponseData.tribalInd) ? this.lifelineReponseData.tribalInd : false],
                stateInd: [(this.lifelineReponseData && this.lifelineReponseData.stateInd) ? this.lifelineReponseData.stateInd : false],
                linkUpInd: [(this.lifelineReponseData && this.lifelineReponseData.linkUpInd) ? this.lifelineReponseData.linkUpInd : false],
                linkupSvcDate: [this.linkupSvcDate],
                caseNumber: [(this.lifelineReponseData && this.lifelineReponseData.caseNumber) ? this.lifelineReponseData.caseNumber : ''],
                acpInd: [(this.lifelineReponseData && this.lifelineReponseData.acpInd) ? this.lifelineReponseData.acpInd : false],
                ruralInd: [(this.lifelineReponseData && this.lifelineReponseData.ruralInd) ? this.lifelineReponseData.ruralInd : false],
                nladData: [{
                    serviceDate: [(this.lifelineReponseData && this.lifelineReponseData.nladData.serviceDate) ? this.lifelineReponseData.nladData.serviceDate : ''],
                    subscriberId: [(this.lifelineReponseData && this.lifelineReponseData.nladData.subscriberId) ? this.lifelineReponseData.nladData.subscriberId : ''],
                }]
            });
        } else {
            this.lifelineForm = this.fb.group({
                firstName: this.lifelinePotsConfigData && this.lifelinePotsConfigData.firstName !== undefined && this.lifelinePotsConfigData.firstName,
                lastName: this.lifelinePotsConfigData && this.lifelinePotsConfigData.lastName !== undefined && this.lifelinePotsConfigData.lastName,
                dateOfBirth: this.lifelinePotsConfigData && this.lifelinePotsConfigData.dateOfBirth !== undefined && new DatePipe('en-US').transform(this.lifelinePotsConfigData.dateOfBirth, 'MM/dd/yyyy'),
                ssnLastFour: this.lifelinePotsConfigData && this.lifelinePotsConfigData.ssnLastFour !== undefined && this.lifelinePotsConfigData.ssnLastFour,
                qualProg: this.lifelinePotsConfigData && this.lifelinePotsConfigData.qualProg !== undefined && this.lifelinePotsConfigData.qualProg,
                effectiveDate: [this.effectiveDate, Validators.required],
                iehCertDate: [this.iehCertDate, Validators.required],
                expirationDate: [this.expirationDate, Validators.required],
                anniversaryDate: [this.anniversaryDate, Validators.required],
                federalInd: this.lifelinePotsConfigData && this.lifelinePotsConfigData.federalInd !== undefined && this.lifelinePotsConfigData.federalInd,
                tribalInd: this.lifelinePotsConfigData && this.lifelinePotsConfigData.tribalInd !== undefined && this.lifelinePotsConfigData.tribalInd,
                stateInd: this.lifelinePotsConfigData && this.lifelinePotsConfigData.stateInd !== undefined && this.lifelinePotsConfigData.stateInd,
                linkUpInd: this.lifelinePotsConfigData && this.lifelinePotsConfigData.linkUpInd !== undefined && this.lifelinePotsConfigData.linkUpInd,
                linkupSvcDate: [this.linkupSvcDate],
                caseNumber: this.lifelinePotsConfigData && this.lifelinePotsConfigData.caseNumber !== undefined && this.lifelinePotsConfigData.caseNumber,
                acpInd: this.lifelinePotsConfigData && this.lifelinePotsConfigData.acpInd !== undefined && this.lifelinePotsConfigData.acpInd,
                ruralInd: this.lifelinePotsConfigData && this.lifelinePotsConfigData.ruralInd !== undefined && this.lifelinePotsConfigData.ruralInd,
                nladData: [{
                    serviceDate: this.lifelinePotsConfigData && this.lifelinePotsConfigData.serviceDate !== undefined && this.lifelinePotsConfigData.serviceDate,
                    subscriberId: this.lifelinePotsConfigData && this.lifelinePotsConfigData.subscriberId !== undefined && this.lifelinePotsConfigData.subscriberId,
                }]
            });
        }
        this.store.dispatch({ type: 'PRODUCT_TYPE', payload: this.inputData.configType });
        let defaultInterlata = '';
        let defaultIntraLata = '';
        let defaultMessageIndicator = '';
        let defaultRingCycle = '';
        let defaultLanguage = '';
        let defaultCallForwarding = '';
        let temp = find(this.inputData.ldCarrierData.intraLataArray, (o) => o.isDefault == true);
        if (temp) {
            defaultIntraLata = temp.value;
        }
        temp = find(this.inputData.ldCarrierData.interLataArray, (o) => o.isDefault == true);
        if (temp) {
            defaultInterlata = temp.value;
        }
        temp = find(this.inputData.voiceMailData.mesageIndicatorArray, (o) => o.isDefault == true);
        if (temp) {
            defaultMessageIndicator = temp.value;
        }
        temp = find(this.inputData.voiceMailData.ringCycleArray, (o) => o.isDefault == true);
        if (temp) {
            defaultRingCycle = temp.value;
        }
        temp = find(this.inputData.voiceMailData.ringCycleArray, (o) => o.disable == true);
        if (temp) {
            this.ringHoverText = temp.hoverText;
        }

        temp = find(this.inputData.voiceMailData.langArray, (o) => o.isDefault == true);
        if (temp) {
            defaultLanguage = temp.value;
        }

        temp = find(this.inputData.callForwarding.ringCycleArray, (o) => o.isDefault == true);
        if (temp) {
            defaultCallForwarding = temp.value;
        }
        //EX-CONFIGURATION
        if (this.exInputData) {
            //  temp = find(this.exInputData.ldCarrierData.intraLataArray, (o) => o.value !== null && o.value);
            //  if (temp) {
            //      defaultIntraLata = temp.value;
            //  }
            // temp = find(this.exInputData.ldCarrierData.interLataArray, (o) => o.value !== null && o.value);
            // if (temp) {
            //      defaultInterlata = temp.value;
            //  } Will delete this after monitoring for few days
            temp = find(this.exInputData.voiceMailData.mesageIndicatorArray, (o) => o.value !== null && o.value);
            if (temp) {
                defaultMessageIndicator = temp.value;
            }
            temp = find(this.exInputData.voiceMailData.ringCycleArray, (o) => o.value !== null && o.value);
            if (temp && this.ringHoverText === '') {
                defaultRingCycle = temp.value;
            }
            temp = find(this.exInputData.callForwarding.ringCycleArray, (o) => o.value !== null && o.value);
            if (temp && (this.cFringHoverText === '' || !this.cFringHoverText)) {
                defaultCallForwarding = temp.value;
            }
            temp = this.exInputData.listingData.configItems.filter(x => { return x.productName === 'Call Detail' })
            if (temp) {
                temp.map(y => {
                    y.configDetails[0].formItems.map(z => { this.callDetailVal = z.attributeName === 'printOnBill' ? z.attributeValue[0].value : 'No' })
                });
            }
        }
        if (this.exSelectedOption && this.exSelectedOption[0]) {
            this.listingDataChanged(this.exSelectedOption[0].value, false);
        }
        let existinglistedAddressOptions;
        if (this.exInputData && this.macd && this.exInputData.listingData && this.exInputData.listingData.configItems) {
            existinglistedAddressOptions = this.getOptionsForListedAddress(this.exInputData.listingData.configItems);
        }
        if (this.inputData && this.inputData.listingData && this.inputData.listingData.configItems) {
            this.listedAddressOptions = this.getOptionsForListedAddress(this.inputData.listingData.configItems);
        }

        if (this.exListedAddress && this.exSelectedOption[0]) {
            this.listedChange(this.exListedAddress[0].value);
        }
        if (this.exInputData && this.exInputData.listingData && this.macd) {
            this.selectedListedType = existinglistedAddressOptions && existinglistedAddressOptions[0] &&
                existinglistedAddressOptions[0].value;
            this.existinglistedAddressOption = existinglistedAddressOptions && existinglistedAddressOptions[0] &&
                existinglistedAddressOptions[0].value;
            if (existinglistedAddressOptions && existinglistedAddressOptions[0] && existinglistedAddressOptions[0].value) {
                this.listedAddressSelected.emit(existinglistedAddressOptions[0].value);
            }
        } else {
            let listedAdd: any;
            this.listedAddressOptions && this.listedAddressOptions.map(v => {
                if (v.isDefault) {
                    return listedAdd = v;
                }
            })
            if (listedAdd) this.selectedListedType = listedAdd[0] && listedAdd[0].value;
        }
        if (this.inputData && this.inputData.tnData && this.inputData.tnData.selectedTN) {
            this.cachedAssignedTN = this.inputData.tnData.selectedTN;
        }
        let assignedTn;
        let currentStore = this.appStateService.getState();
        let fromHold = false;
        if (currentStore && currentStore.existingProducts && currentStore.existingProducts.orderFlow
            && currentStore.existingProducts.orderFlow.type === 'fromHold' && !currentStore.existingProducts.orderFlow.customizeCalled) {
            fromHold = true;
            this.fromHold = true;
            if (this.potsPortedCheck) this.tnObject = 'EXTPORTED';
        }
        if (this.disablePortedTN) this.potsPortedCheck = false;
        this.phoneConfigForm = this.fb.group({
            'tnForm': this.fb.group({
                'task': [this.potsPortedCheck || ((this.isReEntrant || fromHold) && this.tnObject && this.tnObject === 'EXTPORTED') ? 'portedTn' : 'assignedTn', [Validators.required]],
                'SelectedManualPhoneNumber': [''],
                'SelectedPhoneNumber': [this.inputData.tnData.selectedTN ? this.inputData.tnData.selectedTN : ''],
                'PortingNumber': [(this.isReEntrant || fromHold) && this.tnObject && this.tnObject === 'EXTPORTED' ? this.inputData.tnData.selectedTN : ''],
                'accessPin': [''],
                'retainOtherNumbers': [''],
                'accountNo': [''],
                'wirelessNo': ['']
            }),
            'listingForm': this.fb.group({
                'selectedOption': [this.getSelectedListingOption(this.exSelectedOption, this.preselectedListing)],
                'firstName': [''],
                'lastName': [''],
                'title1': [this.exTitle1 ? this.exTitle1 : ''],
                'title2': [this.exTitle2 ? this.exTitle2 : ''],
                'lineage': [this.exLineage ? this.exLineage : ''],
                'designation': [this.exDesignation ? this.exDesignation : ''],
                'Nickname': [this.exNickname ? this.exNickname : '']
            }),
            'ldCarrierForm': this.fb.group({
                'selectedInterCarrierOption': [defaultInterlata],
                'selectedIntraCarrierOption': [defaultIntraLata],
                'selectedCallDetailBill': [this.callDetailVal ? this.callDetailVal : 'No']
            }),
            'additionalForm': this.fb.group({
                'selectedMessageIndicatorOption': [defaultMessageIndicator],
                'selectedRingCycleOption': [defaultRingCycle],
                'selectLanguageOption': [defaultLanguage]
            }),
            'callfwdForm': this.fb.group({
                'fwdOnBusy': [this.macd ? this.inputData.callForwarding.callForwardingBusy ? (this.exInputData.callForwarding.fwdOnBusy && this.exInputData.callForwarding.fwdOnBusy.length > 0) ? this.exInputData.callForwarding.fwdOnBusy[0].value : '' : '' : ''],
                'fwdOnDontAnswer': [this.macd ? this.inputData.callForwarding.callForwardingNoAnswer ? (this.exInputData.callForwarding.fwdNoAns && this.exInputData.callForwarding.fwdNoAns.length > 0) ? this.exInputData.callForwarding.fwdNoAns[0].value : '' : '' : ''],
                'selectedRingCycleOption': [defaultCallForwarding]
            })
        });
        this.listingFormSelected = true;
        this.callDetailPlan.emit(this.callDetailVal ? this.callDetailVal : 'No');
        let cartVal = <Observable<any>>this.store.select('cart');
        let cartSubscribe: Subscription = cartVal.subscribe(
            (cartVal => {
                cartVal && cartVal.payload && cartVal.payload.customerAddonOfferItems && cartVal.payload.customerAddonOfferItems.map((val) => {
                    if (val.offerType === "P4L" && this.potsOfferName !== "PFL Internet and Essential Home Phone") {
                        this.phonePlan = true;
                        this.phonePlanChange.emit(this.phonePlan);
                    }
                })
            })
        )
        if (cartSubscribe !== undefined)
            cartSubscribe.unsubscribe();
        if (this.isOnHold && this.existingListingData && this.existingListingData !== undefined) {
            this.existingListingData.map(item => {
                if (item && item.productName && item.productName.indexOf('Listing') !== -1) {
                    this.ListingDetails(item);
                }
            })
        } else if (!this.isReEntrant && !this.isOnHold) {
            this.exInputData && this.exInputData.listingData && this.exInputData.listingData.configItems &&
                this.exInputData.listingData.configItems.map(item => {
                    if (item && item.productName && item.productName.indexOf('Listing') !== -1) {
                        this.ListingDetails(item);
                    }
                });
        } else {
            let retainVal = <Observable<any>>this.store.select('retain');
            let retSubscribe: Subscription = retainVal.subscribe(
                (retVal => {
                    this.retainedFreezeData = retVal.retainedFreezeData;
                    retVal && retVal.prodConfig && retVal.prodConfig.prodConfig && retVal.prodConfig.prodConfig.map((data) => {
                        data && data.configItems && data.configItems.map((item) => {
                            if (item && item.productName && item.productName.indexOf('Listing') !== -1) {
                                this.ListingDetails(item);
                            } else if (item && item.productName && item.productName.indexOf('Call Detail') !== -1) {
                                item.configDetails && item.configDetails[0].formItems && item.configDetails[0].formItems.map(formItem => {
                                    if (formItem.attributeName.toLowerCase().indexOf('printonbill') !== -1) {
                                        this.callDetailVal = (formItem.attributeValue && formItem.attributeValue[0].value) ? formItem.attributeValue[0].value : 'No';
                                        this.callDetailPlan.emit(this.callDetailVal ? this.callDetailVal : 'No');
                                        this.phoneConfigForm.patchValue({ "ldCarrierForm": { "selectedCallDetailBill": this.callDetailVal ? this.callDetailVal : 'No' } });
                                    }
                                })
                            }
                        })
                    })
                })
            )
            if (retSubscribe !== undefined)
                retSubscribe.unsubscribe();
        }
        if (!this.exSelectedOption && this.directoryListingData && this.directoryListingData.length > 0) {
            this.directoryListingData.map(option => {
                if (option.isDefault === 1) {
                    this.preselectedListing = option.name;
                    this.listingDataChanged(this.preselectedListing, false);
                }
            })
        }
        if (((this.isReEntrant || fromHold) && this.tnObject && this.tnObject === 'EXTPORTED') && this.inputData &&
            this.inputData.tnData && this.inputData.tnData.selectedTN) {
            this.phoneNumberSelected = true;
            this.setError('tnForm', false);
            this.isAccordionOpen.emit(false);
        }
        else {
            this.setError('tnForm', true, this.phoneConfigForm.get('tnForm.task').value === 'portedTn' ? 'Porting information not complete' : 'TN selection not complete');

        }
        this.setError('callForwarding', true, 'enter a valid number');
        this.errors.callForwarding.onDontAnswer = false;
        this.errors.callForwarding.onBusy = false;
        setTimeout(() => { this.propagateChange(this.phoneConfigForm.value) }, 10);
        this.userStore = <Observable<any>>this.store.select('user');
        this.userStoreSubscription = this.userStore.subscribe((data) => {

            if (this.exFirstName && this.exFirstName[0] && this.exFirstName[0].value) {
                this.phoneConfigForm.get('listingForm.firstName').setValue(this.exFirstName[0].value);
            }
            else {
                this.phoneConfigForm.get('listingForm.firstName').setValue(data.firstName);
            }

            if (this.exLastName && this.exLastName[0] && this.exLastName[0].value) {
                this.phoneConfigForm.get('listingForm.lastName').setValue(this.exLastName[0].value);
            }
            else {
                this.phoneConfigForm.get('listingForm.lastName').setValue(data.lastName);
            }

            if (this.currentFlow && this.currentFlow === "Move") {
                if (this.exSelectedOption && data && data.orderInit && data.orderInit.payload
                    && data.orderInit.payload.newLocation && data.orderInit.payload.newLocation.serviceAddress) {
                    this.addressListing = data.orderInit.payload.newLocation.serviceAddress;
                    this.changedAddressListing.emit(this.addressListing);
                }
            }
            else if (this.exStreetNrFirst || this.exStreetNamePrefix || this.exStreetType || this.exStreetName || this.exUnit || this.exCity || this.exState || this.exPostCode) {
                this.addressListing = {};
                this.addressListing = {
                    'streetNrFirst': this.exStreetNrFirst ? this.exStreetNrFirst : '',
                    'streetNamePrefix': this.exStreetNamePrefix ? this.exStreetNamePrefix : '',
                    'streetName': this.exStreetName ? this.exStreetName : '',
                    'streetType': this.exStreetType ? this.exStreetType : '',
                    'unit': this.exUnit ? this.exUnit : '',
                    'city': this.exCity ? this.exCity : '',
                    'stateOrProvince': this.exState ? this.exState : '',
                    'postCode': this.exPostCode ? this.exPostCode : ''
                }
                if (this.addressListing) {
                    this.changedAddressListing.emit(this.addressListing);
                }
            }
            else if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress) {
                this.addressListing = data.orderInit.payload.serviceAddress;
            }
            // If addressListing is undefined then take from retrieveProductCall
            else if(!this.addressListing) {
                const state = this.appStateService.getState();
                if(state 
                     && state.existingProducts 
                     && state.existingProducts.existingProductsAndServices
                     && state.existingProducts.existingProductsAndServices.length > 0
                     && state.existingProducts.existingProductsAndServices[0]
                     && state.existingProducts.existingProductsAndServices[0].serviceAddress) {
                     this.addressListing = state.existingProducts.existingProductsAndServices[0].serviceAddress;
                }
             }
        });
        if (this.userStoreSubscription !== undefined) this.userStoreSubscription.unsubscribe();

        this.phoneConfigForm.valueChanges.subscribe((data: any) => {
            this.propagateChange(data);
        });
        this.phoneConfigForm.get('listingForm.selectedOption').valueChanges.subscribe((data: any) => {
            if (data == "Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = false;
            }
            else if (data == "Non-Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = true;
            } else if (data == "Non-Published") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = true;
                this.listingFlags.showProvidedFlag = false;
            }
        });
        this.phoneConfigForm.get("listingForm").valueChanges.debounceTime(750).subscribe((data: any) => {
            this.listingFormChange.emit();
        })
        this.phoneConfigForm.get('tnForm.task').valueChanges.subscribe((data: any) => {
            if (this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value === '') {
                this.phoneNumberSelected = false;
                this.setError('tnForm', true, data === 'portedTn' ? 'Porting information not complete' : 'TN selection not complete');
                this.isAccordionOpen.emit(true);

            }
            if (this.phoneConfigForm.get('tnForm.task').value === 'assignedTn' && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value) {
                this.setError('tnForm', false);
                this.isAccordionOpen.emit(false);

                if (this.cachedAssignedTN) {
                    this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(this.cachedAssignedTN);
                    this.store.dispatch({ type: 'TELEPHONE_NUMBER', payload: this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value });
                    this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' });
                }
            }
            if (this.phoneConfigForm.get('tnForm.task').value === 'portedTn' && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value) {
                this.startOver();
                if (this.selectedAssessCharge) this.store.dispatch({ type: 'TN_CHARGE_NEED_TO_REMOVE', payload: true });
            }
        });
        this.onError.emit(this.errors);
        if (this.inputData && this.inputData.tnData && this.inputData.tnData.selectedTN && this.inputData.tnData.selectedTN.trim() !== '') {
            this.isAccordionOpen.emit(false);
            this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(this.inputData.tnData.selectedTN);
            this.selectPhoneNumber(false);
        }
        //clearing selected phone in case of porting selected yes at pots order
        if (this.potsPortedCheck) {
            this.accordianHandler.tn = true;
            this.isAccordionOpen.emit(true);
            this.setError('tnForm', true, 'Porting information not complete');
        }
        this.phoneConfigForm.get('callfwdForm').get('fwdOnDontAnswer').valueChanges.debounceTime(750).subscribe((values) => {
            if (this.inputData.callForwarding.callForwardingNoAnswer && (!values || !values.length || values.length !== 12)) {

                this.setError('callForwarding', true, 'enter a valid number');
                this.errors.callForwarding.onDontAnswer = true;

            } else if (this.inputData.callForwarding.callForwardingNoAnswer && values && values.length !== undefined && values.length === 12) {
                this.errors.callForwarding.onDontAnswer = false;
                let isBusyFieldDisplayed = this.inputData.callForwarding.callForwardingBusy;
                if (!isBusyFieldDisplayed || (isBusyFieldDisplayed && !this.errors.callForwarding.onBusy)) {
                    this.setError('callForwarding', false);
                }
            }
        });
        this.phoneConfigForm.get('callfwdForm').get('fwdOnBusy').valueChanges.debounceTime(750).subscribe((values) => {
            if (this.inputData.callForwarding.callForwardingBusy && (!values || !values.length || values.length !== 12)) {
                this.setError('callForwarding', true, 'enter a valid number');
                this.errors.callForwarding.onBusy = true;

            } else if (this.inputData.callForwarding.callForwardingBusy && values && values.length !== undefined && values.length === 12) {
                let isForwardingFieldDisplayed = this.inputData.callForwarding.callForwardingNoAnswer;
                this.errors.callForwarding.onBusy = false;
                if (!isForwardingFieldDisplayed || (isForwardingFieldDisplayed && !this.errors.callForwarding.onDontAnswer)) {
                    this.setError('callForwarding', false);
                }
            }
        });
        if (this.potsPortedCheck && fromHold && this.inputData && this.inputData.tnData && this.inputData.tnData.reservedTNs
            && this.inputData.tnData.reservedTNs.length > 0) {
            this.inputData.tnData.reservedTNs.map(tnTypeCheck => {
                if (tnTypeCheck.productType === GenericValues.cHP && tnTypeCheck.tnType !== 'DEFAULTED') {
                    this.phoneConfigForm.get('tnForm.retainOtherNumbers').setValue('Yes');
                    this.confirmTn(true, currentStore);
                }
            })
        }
        if (this.disablePortedTN) this.temp1();
    }
    retainedFreezeData: any;
    private getOptionsForListedAddress(configItems) {
        let options = [];
        configItems && configItems.some(item => {
            if (item.productName.indexOf('Listing') !== -1) {
                item.configDetails && item.configDetails[0].formItems && item.configDetails[0].formItems.map(formItem => {
                    if (formItem.attributeName.toLowerCase().indexOf('listed address') !== -1) {
                        options = formItem.attributeValue;
                    }
                })
            }
        })
        return options;
    }
    public subLifelineData() {
        if (this.lifelineForm.valid) {
            this.submitLifelineData();
        } else {
            this.validLifelineData = true;
            this.lifelineSubmitted = true;
        }
        if (this.stateChecked && this.lifelineForm.get("qualProg").value === "") {
            this.validLifelineData = true;
            this.lifelineSubmitted = true;
        } else if (this.lifelineForm.get("qualProg").value !== "") {
            this.validLifelineData = false;
            this.lifelineSubmitted = false;
        }
        this.clickLifelineContinue.emit(this.validLifelineData);
    }
    public clickDoneButton() {
        this.lifelineCollapesed = true;
        if (this.lifelineForm.get("federalInd").value) {
            this.fedaralSelected = true;
        } else {
            this.fedaralSelected = false;
        }
        if (this.lifelineForm.get("tribalInd").value) {
            this.tribalSelected = true;
        } else {
            this.tribalSelected = false;
        }
        if (this.lifelineForm.get("stateInd").value) {
            this.stateSelected = true;
        } else {
            this.stateSelected = false;
        }
        if (this.lifelineForm.get("linkUpInd").value) {
            this.linkupSelected = true;
        } else {
            this.linkupSelected = false;
        }
        this.subLifelineData();
    }
    private getSelectedListingOption(exItem, preItem) {
        if (exItem && exItem[0].value) {
            this.selectedListing = exItem[0];
            return exItem[0].value;
        }
        else if (preItem) {
            return preItem;
        }
        else if (this.directoryListingData && this.directoryListingData.length > 0) {
            this.directoryListingData.map(option => {
                if (option.isDefault === 1) {
                    this.preselectedListing = option.name;
                    this.listingDataChanged(this.preselectedListing, false);
                }
            })
            return this.preselectedListing;
        }
    }

    public onListedUpdate(updatedAddress) {
        this.updatedListedAddress = updatedAddress;
        this.listedAddressFields.emit(updatedAddress);
    }

    assignedManualTN() {
        if (this.billingPotsSelected) {
            if (this.phoneConfigForm.get('tnForm.SelectedManualPhoneNumber').value.replace(/_|-/g, '').length !== 10) {
                this.manualTnAssigned = true;
                this.isAccordionOpen.emit(true);
            }
            else {
                this.manualTnAssigned = false;
                this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(this.phoneConfigForm.get('tnForm.SelectedManualPhoneNumber').value.replace(/_|-/g, ''));
                this.phoneConfigForm.get('tnForm.SelectedManualPhoneNumber').setValue('');
                this.emptyTNnumber = false;
                this.isAccordionOpen.emit(false);
                this.phoneNumberSelected = true;
                this.setError('tnForm', false, '');
            }
        }
    }
    private listedChange(type) {
        if (this.existinglistedAddressOption && this.existinglistedAddressOption !== type && this.refreshServiceAddress) {
            this.addressListing = {};
            this.addressListing = this.refreshServiceAddress;
            this.changedAddressListing.emit(this.addressListing);
        }

        this.selectedListedType = type;
        this.listedAddressSelected.emit(type);
    }
    public longDistance() {
        let flag = false;
        let val = this.phoneConfigForm.get('ldCarrierForm.selectedIntraCarrierOption');
        let str = this.legacyProvider !== 'CENTURYLINK' ? '9199-NONE, NONE' : '10X1 - No PIC, 10X1 - No PIC';
        if (val && val.value && val.value.toString().trim() !== '') {
            str = val.value.toString();
            flag = true;
        }
        val = this.phoneConfigForm.get('ldCarrierForm.selectedInterCarrierOption');
        if (val && val.value && val.value.toString().trim() !== '') {
            str += flag ? ', ' + val.value.toString() : val.value.toString();
        }
        return str;
    }
    public resolveListedString() {
        let str = '';
        if (this.phoneConfigForm.get('listingForm.selectedOption').value) {
            str = this.phoneConfigForm.get('listingForm.selectedOption').value;
        }
        if (str === "") {
            str = "Listed";
        }
        return str === "Non-Pub No Charge" ? "Non-Published" : str;
    }
    getOptionsForDirectoryListing(data) {
        let optionsData: any = [];
        let otherOptionsData: any = [];
        if (data && data != null && data != undefined) {
            if (data.catalogs && data.catalogs.length > 0) {
                let catalogs = data.catalogs[0];
                if (catalogs.catalogItems && catalogs.catalogItems.length > 0) {
                    catalogs.catalogItems.map((catalogItems) => {
                        if (catalogItems && catalogItems.productOffer && catalogItems.productOffer.offerName.indexOf(this.OFFER_CHECK_NAME) !== -1) {
                            if (catalogItems.productOffer.productComponents && catalogItems.productOffer.productComponents.length > 0) {
                                catalogItems.productOffer.productComponents.map(productComponent => {
                                    if (productComponent && productComponent.product && productComponent.product.productDisplayName === this.OFFER_CHECK_NAME) {
                                        if (productComponent.product && productComponent.product.productAttributes) {
                                            productComponent.product.productAttributes.map((productAttr) => {
                                                if (productAttr.compositeAttribute && productAttr.displayOrder > 0) {
                                                    productAttr.compositeAttribute.map((compositeAttr) => {
                                                        if (compositeAttr.attributeName === 'Listing Type') {
                                                            let priceData = 0;
                                                            if (productAttr.prices && productAttr.prices != null) {
                                                                productAttr.prices.map((price) => {
                                                                    if (price.discountedRc > 0) {
                                                                        priceData = price.discountedRc;
                                                                    }
                                                                    else if (price.rc > 0) {
                                                                        priceData = price.rc;
                                                                    }
                                                                    else if (price.discountedOtc > 0) {
                                                                        priceData = price.discountedOtc;
                                                                    }
                                                                    else if (price.otc > 0) {
                                                                        priceData = price.otc;
                                                                    }
                                                                });
                                                            }
                                                            if (productAttr.isDefault) {

                                                            }

                                                            if (compositeAttr.attributeValue !== "Non-Pub No Charge") {
                                                                optionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault, displayName: compositeAttr.attributeDisplayName });
                                                            } else if (this.nonPubNoChargeValue && compositeAttr.attributeValue === "Non-Pub No Charge") {
                                                                optionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault, displayName: compositeAttr.attributeDisplayName });
                                                            }
                                                        }
                                                    });
                                                }
                                                else if (productAttr.compositeAttribute && productAttr.displayOrder === 0) {
                                                    productAttr.compositeAttribute.map((compositeAttr) => {
                                                        if (compositeAttr.attributeName === 'Listing Change') {
                                                            let priceData = 0;
                                                            if (productAttr.prices && productAttr.prices != null) {
                                                                productAttr.prices.map((price) => {
                                                                    if (price.discountedOtc > 0) {
                                                                        priceData = price.discountedOtc;
                                                                    }
                                                                    else if (price.otc > 0) {
                                                                        priceData = price.otc;
                                                                    }
                                                                });
                                                            }
                                                            if (productAttr.isDefault) {

                                                            }
                                                            optionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault });
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    } else if (productComponent.product && productComponent.product.productAttributes) {
                                        productComponent.product.productAttributes.map((productAttr) => {
                                            productAttr && productAttr.compositeAttribute && productAttr.compositeAttribute.map((compositeAttr) => {
                                                if (compositeAttr.attributeName === 'Listing Change') {
                                                    let priceData = 0;
                                                    if (productAttr.prices && productAttr.prices != null) {
                                                        productAttr.prices.map((price) => {
                                                            if (price.discountedOtc > 0) {
                                                                priceData = price.discountedOtc;
                                                            }
                                                            else if (price.otc > 0) {
                                                                priceData = price.otc;
                                                            }
                                                        });
                                                    }
                                                    if (productAttr.isDefault) {

                                                    }
                                                    otherOptionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault });

                                                }
                                            })
                                        })
                                    }
                                })
                            }
                        }
                    });

                }
            }
        }
        this.otherlistingOptions = otherOptionsData;
        return optionsData;
    }

    public maskTelephone(number: string) {
        if (number && number.indexOf('-') === -1) {
            return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
        }
        else if (number) {
            return number;
        }
    }

    public callDetail(value) {
        this.callDetailVal = value;
        this.callDetailPlan.emit(this.callDetailVal);
    }
    public temp1() {
        this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(this.inputData.tnData.selectedTN);
        this.selectPhoneNumber(false);
        if (this.phoneConfigForm && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value
            && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value !== 'Choose your option...') {
            this.isPortingOpen.emit(true);

        } else {
            this.isPortingOpen.emit(false);
        }
    }
    public submitLifelineData(lifelineRemove?) {
        let lifelineDetainRetain = <Observable<any>>this.store.select('customize');
        let retainCustomizeLifelineData = lifelineDetainRetain.subscribe((data) => {
            this.custData = data;
        });
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            if (!this.nladDateResponse) {
                this.saveLifelineUpdates = this.lifelineReponseData.nladData ? this.lifelineReponseData.nladData : null;
            }
        }
        if (this.isRentrant) {
            if (!this.nladDateResponse) {
                this.saveLifelineUpdates = this.custData.lifelinePotsConfig.nladData;
            }
            if (!this.adjustmentsResponse) {
                this.discountsUpdates = this.custData.lifelinePotsDiscounts.discounts;
                this.adjustmentsUpdates = this.custData.lifelinePotsAdjustment.adjustments;
            }
        }
        this.lifelineConfigObj = {
            firstName: this.lifelineForm.get('firstName').value,
            lastName: this.lifelineForm.get('lastName').value,
            dateOfBirth: new DatePipe('en-US').transform(this.lifelineForm.get('dateOfBirth').value, "yyyy-MM-dd"),
            ssnLastFour: this.lifelineForm.get('ssnLastFour').value,
            federalInd: this.lifelineForm.get("federalInd").value,
            tribalInd: this.lifelineForm.get("tribalInd").value,
            stateInd: this.lifelineForm.get("stateInd").value,
            linkUpInd: this.lifelineForm.get("linkUpInd").value,
            linkupSvcDate: (this.lifelineForm.get("tribalInd").value === true && this.lifelineForm.get("federalInd").value === true && this.lifelineForm.get("linkUpInd").value === true) ? new DatePipe('en-US').transform(this.linkupSvcDate, "yyyy-MM-dd") : undefined,
            qualProg: this.lifelineForm.get("qualProg").value,
            effectiveDate: new DatePipe('en-US').transform(this.effectiveDate, "yyyy-MM-dd"),
            iehCertDate: new DatePipe('en-US').transform(this.iehCertDate, "yyyy-MM-dd"),
            expirationDate: new DatePipe('en-US').transform(this.expirationDate, "yyyy-MM-dd"),
            anniversaryDate: new DatePipe('en-US').transform(this.anniversaryDate, "yyyy-MM-dd"),
            caseNumber: this.lifelineForm.get('caseNumber').value,
            acpInd: this.lifelineForm.get('acpInd').value,
            ruralInd: this.lifelineForm.get('ruralInd').value,
            nladData: this.saveLifelineUpdates ? this.saveLifelineUpdates : null
        };

        if (this.discountChanges && !this.expLifelineSelected || this.lifelineRespData === null || this.lifelineRespData === undefined) {
            this.LifeLineDiscounts = {
                discounts: this.discountsUpdates ? this.discountsUpdates : null
            }
        } else if (!this.discountChanges && !this.expLifelineSelected && this.lifelineRespData && this.lifelineRespData !== null && !this.removePOTSLifeline) {
            this.lifelineRespData.discounts.map((item) => {
                item.actionType = "NOCHANGE";
            })
            this.LifeLineDiscounts = {
                discounts: this.lifelineRespData.discounts
            }
        } else if ((this.expLifelineSelected || this.removePOTSLifeline) && this.lifelineRespData && this.lifelineRespData !== null) {
            this.lifelineRespData.discounts.map((item) => {
                item.actionType = "REMOVE";
                item.llarcCreditInd = false;
                item.endDate = new DatePipe('en-US').transform(this.expirationDate, "yyyy-MM-dd");
            })
            this.LifeLineDiscounts = {
                discounts: this.lifelineRespData.discounts
            }
        }
        this.LifeLineAdjustments = {
            adjustments: this.adjustmentsUpdates ? this.adjustmentsUpdates : null
        }
        if (lifelineRemove) {
            this.lifelineConfigObj.federalInd = false;
            this.lifelineConfigObj.tribalInd = false;
            this.lifelineConfigObj.stateInd = false;
            this.lifelineConfigObj.linkUpInd = false;
            this.lifelineConfigObj.acpInd = false;
            this.lifelineConfigObj.ruralInd = false;
            this.lifelineConfigObj.qualProg = "EXP:Expire Lifeline";
            this.expLifelineSelected = true;
            this.lifelineConfigObj.expirationDate = this.removeExpDate;
            this.LifeLineDiscounts.discounts.map((data) => {
                data.endDate = new DatePipe('en-US').transform(this.lifelineConfigObj.expirationDate, "yyyy-MM-dd");
            })
        }
        this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG', payload: this.lifelineConfigObj });
        this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_DISCOUNTS', payload: this.LifeLineDiscounts });
        this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_ADJUSTMENTS', payload: this.LifeLineAdjustments });
        this.validLifelineData = false;

    }
    public selectPhoneNumber(dispatchIt) {
        if (this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value !== '' && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value !== 'Choose your option...') {
            this.phoneNumberSelected = true;
            this.store.dispatch({ type: 'TELEPHONE_NUMBER', payload: this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value });
            if(dispatchIt) { this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' }); }
            this.setError('tnForm', false);
            this.isAccordionOpen.emit(false);
        }
        if (dispatchIt) {
            if (this.phoneConfigForm && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value && this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value !== 'Choose your option...') {
                this.isPortingOpen.emit(true);
            } else {
                this.isPortingOpen.emit(false);
            }
        }
    }

    public onPhoneNumberSelected(data) {
        this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(data);
        this.phoneNumberSelected = true;
        this.store.dispatch({ type: 'TELEPHONE_NUMBER', payload: this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value });
        this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' });
        this.store.dispatch({ type: 'WORKING_TN', payload: 'NO' });
        this.setError('tnForm', false);
        this.isAccordionOpen.emit(false);
        this.isTnNoChanged.emit(this.phoneNumberSelected);

    }
    onTnBackSelected(event) {
        this.onTnBackSelectedAgain.emit(event);
    }

    public onSaveUpdate(data) {
        this.saveUpdates = data;
        this.phoneConfigForm.get('listingForm.title1').setValue(data.title1);
        this.phoneConfigForm.get('listingForm.title2').setValue(data.title2);
        this.phoneConfigForm.get('listingForm.lineage').setValue(data.lineage);
        this.phoneConfigForm.get('listingForm.designation').setValue(data.designation);
        this.phoneConfigForm.get('listingForm.Nickname').setValue(data.Nickname);
    }
    public onSaveNLADUpdate(event) {
        this.nladDateResponse = true;
        this.saveLifelineUpdates = event;
        if (this.saveLifelineUpdates.serviceDate && this.saveLifelineUpdates.serviceDate !== undefined) {
            this.saveLifelineUpdates.serviceDate = new DatePipe('en-US').transform(this.saveLifelineUpdates.serviceDate, "yyyy-MM-dd")
        }
        this.lifelineForm.get('nladData').setValue(event);
    }
    public onSaveDiscountsUpdate(event) {
        this.adjustmentsResponse = true;
        this.discountsLifelineData = event;
        let disc;
        let discount = {};
        let adjustment = {};
        let discounts = [];
        let adjustments = [];
        let one = Object.keys(this.discountsLifelineData.controls);
        for (let field of one) {
            if (field == 'adjustmentReason' || field == 'nonRecurringStateCreditDesc' || field == 'adjustmentAmount' || field === 'actionType') {
                disc = this.discountsLifelineData.get(field).value;
                adjustment[field] = disc;
            }
        }
        adjustments.push(adjustment);
        this.adjustmentsUpdates = adjustments;
        this.adjustmentsUpdates[0].adjustmentReason = this.adjustmentsUpdates[0].nonRecurringStateCreditDesc.substring(this.adjustmentsUpdates[0].nonRecurringStateCreditDesc.lastIndexOf('('), this.adjustmentsUpdates[0].nonRecurringStateCreditDesc.length).replace(/[\(\)]/g, "");
    }
    public onsaveDiscouts(event) {
        this.discountChanges = true;
        this.discountsUpdates = event;
        this.discountsUpdates.map((data) => {
            if (data.recurringStateCreditDesc === "AZ Medical (AZMEDI)") {
                this.azmediOptionSelected = true;
            } else {
                this.azmediOptionSelected = false;
            }
        })
    }
    public moreTn() {
        this.phoneNumberSelected = false;
        this.defaultTN = this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value;
        this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue('');
        this.setError('tnForm', true, 'TN selection not complete');
        if (this.selectedAssessCharge) this.store.dispatch({ type: 'TN_CHARGE_NEED_TO_REMOVE', payload: true });
    }

    private setError(keyname, value, message = '') {
        this.errors[keyname].error = value;
        this.errors[keyname].message = message;
        this.onError.emit(this.errors);
    }
    public validate(a, b, c, d, e, f, current) {
        if (this.errors.tnForm.error && current !== 0) {
            if (a) a.isOpen = true;
            if (b) b.isOpen = current === 1 ? true : false;
            if (c) c.isOpen = current === 2 ? true : false;
            if (d) d.isOpen = current === 3 ? true : false;
            if (e) e.isOpen = current === 4 ? true : false;
            if (f) f.isOpen = current === 5 ? true : false;
        } else if (this.errors.tnForm.error) {
            if (a) a.isOpen = false;
        }
        this.lifelineCollapesed = true;
        if (this.lifelineForm.get("federalInd").value) {
            this.fedaralSelected = true;
        } else {
            this.fedaralSelected = false;
        }
        if (this.lifelineForm.get("tribalInd").value) {
            this.tribalSelected = true;
        } else {
            this.tribalSelected = false;
        }
        if (this.lifelineForm.get("stateInd").value) {
            this.stateSelected = true;
        } else {
            this.stateSelected = false;
        }
        if (this.lifelineForm.get("linkUpInd").value) {
            this.linkupSelected = true;
        } else {
            this.linkupSelected = false;
        }
    }

    public getCarrierList(url) {
        this.loading = true;
        this.logger.log("info", "phone-configuration.component.ts", "getCarrierInfoRequest", JSON.stringify(url));
        this.logger.startTime();
        this.productService.getCarrierInfo(url)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "phone-configuration.component.ts", "getCarrierInfoResponse", error);
                this.logger.log("error", "phone-configuration.component.ts", "getCarrierInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage('error', error);
                return Observable.throw(error._body);
            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "phone-configuration.component.ts", "getCarrierInfoResponse", JSON.stringify(data));
                this.logger.log("info", "phone-configuration.component.ts", "getCarrierInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data && data[0].resellerResponseList) {
                    this.carrierList = data[0].resellerResponseList;
                }
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "phone-configuration.component.ts", "getCarrierInfoResponse", error);
                this.logger.log("error", "phone-configuration.component.ts", "getCarrierInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                    } else unexpectedError = true;
                } else unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                    this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", lAPIErrorLists);
                }
            })
    }

    public getPortingAccountDetails(detail) {
        if (detail) {
            this.portingUnknown = detail;
            this.errors.tnForm.validateOffline = true;
            this.errors.tnForm.verifiedNumber = true;
            this.errors.tnForm.unVerifiedNumber = false;
            this.errors.tnForm.showRetainOption = false;
            this.setError('tnForm', false, '');
            this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(this.selectedPortedTn);
            this.phoneNumberSelected = true;
            this.store.dispatch({ type: 'TELEPHONE_NUMBER', payload: this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value });
            this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'EXTPORTED' });
            if (this.portingUnknown.accessPin && this.portingUnknown.accessPin !== '') {
                this.phoneConfigForm.get('tnForm.accessPin').setValue(this.portingUnknown.accessPin);
            }
        }
    }
    public getAddlOrderAttributes(additionalData) {
        this.additionalPortingData.emit(additionalData);
    }

    public tnPortibilityCheck(tn, flag?, currentStore?) {
        let tnCheck: string = '';
        this.selectedPortedTn = tn;
        let req: any;
        req = {
            "orderReferenceNumber": this.inputData.orderReferenceNumber,
            "productType": this.inputData.configType && this.inputData.configType === 'dhp' ? 'VOICE-DHP' : this.inputData.configType && this.inputData.configType === 'hp' ? 'VOICE-HP' : '',
            "accessPin": this.phoneConfigForm.get('tnForm.accessPin').value ? this.phoneConfigForm.get('tnForm.accessPin').value : '',
            "retainOtherNumbers": this.phoneConfigForm.get('tnForm.retainOtherNumbers').value ? this.phoneConfigForm.get('tnForm.retainOtherNumbers').value.toUpperCase() : '',
            "portingInfoRetain": "YES",
            "salesChannel": "ESHOP-Customer Care",
            "portCheckRequest": [
                {
                    "telephoneNumber": tn
                }
            ],
            "addressInfo": this.addressListing,
        }
        if (this.newLegacyProvider === 'CENTURYLINK' || this.legacyProvider == 'CENTURYLINK') {

            if (this.currentFlow && this.currentFlow.toUpperCase() == 'NEWINSTALL' || (this.currentFlow && this.currentFlow.toUpperCase() == 'MOVE' && this.newLegacyProvider === 'CENTURYLINK'))
                req.orderType = this.currentFlow && this.currentFlow.toUpperCase()

        }
        this.loading = true;
        this.logger.log("info", "phone-configuration.component.ts", "getTnPortingStatusRequest", JSON.stringify(req));
        this.logger.startTime();
        this.productService.getTnPortingStatus(req)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "phone-configuration.component.ts", "getTnPortingStatusResponse", error);
                this.logger.log("error", "phone-configuration.component.ts", "getTnPortingStatusSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "TN -Number Porting", "phone-configuration.ts",
                    "Customize Page",
                    error);
                return Observable.throwError(null);

            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "phone-configuration.component.ts", "getTnPortingStatusResponse", JSON.stringify(data));
                this.logger.log("info", "phone-configuration.component.ts", "getTnPortingStatusSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.store.dispatch({ type: 'SIMPLE_PORT_CHECK', payload: data });
                this.errorMsg = '';
                if (data && data.portCheckResponse) {
                    this.carrierInfo = data.portCheckResponse[0].carrierInfo;
                    this.telephoneNumberResponse = data.portCheckResponse[0].telephoneNumber;
                    tnCheck = data.portCheckResponse && data.portCheckResponse[0] && data.portCheckResponse[0].portable && data.portCheckResponse[0].portable.toLowerCase();

                    switch (tnCheck) {
                        case 'yes':
                            this.setError('tnForm', true, 'Porting information not complete');
                            this.errors.tnForm.charterCable = true;
                            this.errors.tnForm.unVerifiedAddress = true;
                            this.errors.tnForm.unVerifiedNumber = false;
                            this.errors.tnForm.notPortable = false;
                            this.errors.tnForm.verifiedNumber = false;
                            this.errors.tnForm.validateOffline = false;
                            this.errors.tnForm.showRetainOption = false;
                            if (data && data.addlOrderAttributes) {
                                this.addlOrderAttributesPortingYes = data.addlOrderAttributes;
                                data.addlOrderAttributes.map(val => {
                                    if ((val.orderAttributeGroup[0] && val.orderAttributeGroup[0] !== undefined && val.orderAttributeGroup[0].orderAttributeGroupName && val.orderAttributeGroup[0].orderAttributeGroupName !== undefined && val.orderAttributeGroup[0].orderAttributeGroupName === "wirelessPin") || (val.orderAttributeGroup[0] && val.orderAttributeGroup[0] !== undefined && val.orderAttributeGroup[0].orderAttributeGroupName && val.orderAttributeGroup[0].orderAttributeGroupName !== undefined && val.orderAttributeGroup[0].orderAttributeGroupName === "tnPortinInfo")) {
                                        this.wireless = true;
                                    }
                                });
                            }
                            this.tnPortingSelected.emit(true);
                            break;
                        case 'unknown':
                            this.setError('tnForm', true, 'Porting information not complete');
                            this.errors.tnForm.charterCable = false;
                            this.errors.tnForm.unVerifiedAddress = false;
                            this.errors.tnForm.unVerifiedNumber = true;
                            this.errors.tnForm.notPortable = false;
                            this.errors.tnForm.verifiedNumber = false;
                            this.errors.tnForm.validateOffline = false;
                            this.errors.tnForm.showRetainOption = false;
                            if (data && data.resellerListURL) {
                                this.carrierListURL = data.resellerListURL;
                                this.getCarrierList(this.carrierListURL);
                            }
                            if (data && data.addlOrderAttributes) {
                                this.addlOrderAttributesPorting = data.addlOrderAttributes
                            }
                            break;
                        case 'no':
                            this.setTnFormError();
                            break;
                    }

                    if (tnCheck === null) {
                        this.setTnFormError();
                    }

                    if (data && data.portCheckResponse[0] && data.portCheckResponse[0].possibleDesiredDueDate) {
                        this.possibleDesiredDueDate = data.portCheckResponse[0].possibleDesiredDueDate;
                    }
                    if (this.fromHold && flag && currentStore && currentStore.customize && currentStore.customize.payload
                        && currentStore.customize.payload.addlOrderAttributes && currentStore.customize.payload.addlOrderAttributes.length > 0) {
                        currentStore.customize.payload.addlOrderAttributes.map(orderAttribute => {
                            orderAttribute && orderAttribute.orderAttributeGroup && orderAttribute.orderAttributeGroup.map(group => {
                                if (group && (group.orderAttributeGroupName === 'portinLosingAccountNumber' || group.orderAttributeGroupName === 'wirelessPin')) {
                                    if (group.orderAttributeGroupInfo && group.orderAttributeGroupInfo[0] &&
                                        group.orderAttributeGroupInfo[0].orderAttributes && group.orderAttributeGroupInfo[0].orderAttributes[0] &&
                                        group.orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue) {
                                        group.orderAttributeGroupName === 'portinLosingAccountNumber' ?
                                            this.phoneConfigForm.get('tnForm.accountNo').setValue(group.orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue) :
                                            this.wirelesspininput = group.orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue
                                    }
                                }
                            })
                        })
                        this.verifyAddress();
                    }
                    this.loading = false;
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "phone-configuration.component.ts", "getTnPortingStatusResponse", error);
                    this.logger.log("error", "phone-configuration.component.ts", "getTnPortingStatusSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.setError('tnForm', true, 'Porting information not complete');
                    if (error !== undefined) {
                        let msg = JSON.parse(error);
                        if (msg.errorResponse !== undefined && msg.errorResponse.length > 0) {
                            this.errorMsg = msg.errorResponse[0].message;
                        } else {
                            this.errorMsg = serverErrorMessages.telephoneNotFound;
                        }
                    } else {
                        this.errorMsg = serverErrorMessages.serviceDown;
                    }
                    window.scroll(0, 0);
                    this.loading = false;
                })
    }

    private setTnFormError() {
        this.setError('tnForm', true, 'Porting information not complete');
        this.errors.tnForm.charterCable = false;
        this.errors.tnForm.unVerifiedAddress = false;
        this.errors.tnForm.unVerifiedNumber = false;
        this.errors.tnForm.notPortable = true;
        this.errors.tnForm.verifiedNumber = false;
        this.errors.tnForm.validateOffline = false;
        this.errors.tnForm.showRetainOption = false;
    }

    public confirmTn(flag?, currentStore?) {
        let tn = this.phoneConfigForm.get('tnForm.PortingNumber').value.replace(/-/g, "");
        if (tn) {
            this.isPortingOpen.emit(true);
            this.errors.tnForm.tnConfirmClicked = true;
            this.setError('tnForm', false);
            this.tnPortibilityCheck(tn, flag, currentStore);
        }
    }
    public startOver() {
        this.phoneNumberSelected = false;
        this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue('');
        this.phoneConfigForm.get('tnForm.PortingNumber').setValue('');
        this.phoneConfigForm.get('tnForm.accessPin').setValue('');
        this.errors.tnForm.tnConfirmClicked = false;
        this.setError('tnForm', true, 'Porting information not complete');
        this.errors.tnForm.charterCable = false;
        this.errors.tnForm.unVerifiedAddress = false;
        this.errors.tnForm.unVerifiedNumber = false;
        this.errors.tnForm.notPortable = false;
        this.errors.tnForm.verifiedNumber = false;
        this.errors.tnForm.validateOffline = false;
        this.errors.tnForm.showRetainOption = true;
        this.errorMsg = '';
        this.phoneConfigForm.get('tnForm.accessPin').setValue('');
        this.phoneConfigForm.get('tnForm.retainOtherNumbers').setValue('');
        this.isAccordionOpen.emit(true);
    }
    public verifyAddress() {
        this.errors.tnForm.unVerifiedAddress = false;
        this.errors.tnForm.verifiedNumber = true;
        this.phoneNumberSelected = true;

        this.isAccordionOpen.emit(false);
        this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').setValue(this.selectedPortedTn);
        this.store.dispatch({ type: 'TELEPHONE_NUMBER', payload: this.phoneConfigForm.get('tnForm.SelectedPhoneNumber').value });
        this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'EXTPORTED' });
        if (this.carrierInfo && (this.carrierInfo.accountNumber === '' && this.phoneConfigForm.get('tnForm.accountNo').value)) {
            this.carrierInfo.accountNumber = this.phoneConfigForm.get('tnForm.accountNo').value;
            if (this.addlOrderAttributesPortingYes && this.addlOrderAttributesPortingYes.length > 0) {
                this.addlOrderAttributesPortingYes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue = this.phoneConfigForm.get('tnForm.accountNo').value;
                this.additionalPortingDataAccountId.emit(this.addlOrderAttributesPortingYes);
            }
        }
        this.WirelessNumber = this.wirelesspininput;
        this.cartObservable = <Observable<any>>this.store.select('customize');
        this.cartSubscription = this.cartObservable.subscribe((data) => {
            if (data && data.payload && data.payload.reservedTN && data.payload.reservedTN !== undefined) {
                data.payload.reservedTN.map((data) => {
                    if (data.productType === "VOICE-HP" && this.addlOrderAttributesPortingYes && this.addlOrderAttributesPortingYes.length > 0) {
                        if (this.addlOrderAttributesPortingYes && this.addlOrderAttributesPortingYes[1] !== undefined && this.addlOrderAttributesPortingYes[1].orderAttributeGroup[0] !== undefined && this.addlOrderAttributesPortingYes[1].orderAttributeGroup[0].orderAttributeGroupInfo[0] !== undefined && this.addlOrderAttributesPortingYes[1].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0] !== undefined) {
                            this.addlOrderAttributesPortingYes[1].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue = this.WirelessNumber;
                        }
                        this.additionalPortingDataAccountId.emit(this.addlOrderAttributesPortingYes);
                    }
                    else if (this.addlOrderAttributesPortingYes && this.addlOrderAttributesPortingYes[0]) {
                        this.addlOrderAttributesPortingYes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue = this.WirelessNumber;
                        this.additionalPortingDataAccountId.emit(this.addlOrderAttributesPortingYes);
                    }
                    this.setError('tnForm', false, '');
                    this.errorMsg = '';
                });
            }
        });

    }
    public customerRequestedDueDateUpdated(event) {
        alert(event);
    }


    public tribalChange(event) {
        if (event.target.checked) {
            this.lifelineForm.get("federalInd").setValue(true);
        }
        this.federalLinkUp(event);
    }
    public federalChange(event) {
        if (!event.target.checked) {
            this.lifelineForm.get("tribalInd").setValue(false);
        }
        this.federalLinkUp(event);
    }
    enableAZMEDIoption: boolean = false;
    public enableAZMEDIChange(event) {
        if (this.lifelineForm.get("federalInd").value || this.lifelineForm.get("stateInd").value) {
            this.enableAZMEDIoption = true;
        } else {
            this.enableAZMEDIoption = false;
        }
        if (event.target.checked) {
            this.stateChecked = true;
        } else {
            this.stateChecked = false;
        }
    }
    public federalLinkUp(event) {
        if (this.lifelineForm.get("federalInd").value && this.lifelineForm.get("tribalInd").value && this.lifelineForm.get("linkUpInd").value) {
            this.federalLinkToggle = true;
        } else {
            this.federalLinkToggle = false;
        }
    }
    public effectiveDateUpdated(event) {
        this.effectiveDate = event.substring(0, 23);
        this.iehCertDate = event.substring(0, 23);
        this.anniversaryDate = event.substring(0, 23);
    }
    public IEHCertifiedUpdated(event) {
        this.iehCertDate = event.substring(0, 23);
    }
    public expirationUpdated(event) {
        this.expirationDate = event.substring(0, 23);
    }
    public anniversaryUpdated(event) {
        this.anniversaryDate = event.substring(0, 23);
    }
    public federalLinkDateUpdated(event) {
        this.linkupSvcDate = event.substring(0, 23);
    }

    public onChangeQualProgList(program) {
        this.stateChecked = false;
        if (!this.lifelineReponseData && this.lifelineReponseData === null || this.lifelineReponseData === undefined) {
            if (program === "EXP:Expire Lifeline") {
                this.expLifelineSelected = true;
                if (this.expLifelineSelected) {
                    this.expirationDate = new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
                }
            }
        }
        if (this.lifelineReponseData && this.lifelineReponseData !== null) {
            if (program === "EXP:Expire Lifeline") {
                this.expLifelineSelected = true;
                if (this.expLifelineSelected) {
                    this.lifelineForm.get('federalInd').setValue(false);
                    this.lifelineForm.get('tribalInd').setValue(false);
                    this.lifelineForm.get('stateInd').setValue(false);
                    this.lifelineForm.get('linkUpInd').setValue(false);
                    this.lifelineForm.get('acpInd').setValue(false);
                    this.lifelineForm.get('ruralInd').setValue(false);
                    this.expirationDate = new DatePipe('en-US').transform(this.date.toString(), "MM/dd/yyyy");
                }
            } else if (program !== "EXP:Expire Lifeline") {
                this.expLifelineSelected = false;
                this.stateChecked = false;
                if (!this.expLifelineSelected && this.lifelineReponseData && this.lifelineReponseData !== null) {
                    this.lifelineForm.get('federalInd').setValue(this.lifelineReponseData.federalInd);
                    this.lifelineForm.get('tribalInd').setValue(this.lifelineReponseData.tribalInd);
                    this.lifelineForm.get('stateInd').setValue(this.lifelineReponseData.stateInd);
                    this.lifelineForm.get('linkUpInd').setValue(this.lifelineReponseData.linkUpInd);
                    this.lifelineForm.get('acpInd').setValue(this.lifelineReponseData.acpInd);
                    this.lifelineForm.get('ruralInd').setValue(this.lifelineReponseData.ruralInd);
                    this.expirationDate = new DatePipe('en-US').transform(this.lifelineReponseData.expirationDate, "MM/dd/yyyy");
                }
            }
        }
    }

    public remainCarrier() {
        this.remainCarrierDisable = false;
    }

    public remainCarrierReset() {
        this.remainCarrierDisable = true;
    }

    @Output() emitFreezeData = new EventEmitter<any>();
    public onEmitLDFreeze(data) {
        this.emitFreezeData.emit(data);
    }

    private ngOnDestroy() {
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
        if (this.existingProductStoreSubscription !== undefined) this.existingProductStoreSubscription.unsubscribe();
    }
}
