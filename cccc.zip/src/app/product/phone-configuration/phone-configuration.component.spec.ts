import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhoneConfigurationComponent } from './phone-configuration.component';
import { Store } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { MockAppStateService, 
  MockSystemErrorService,
  MockPropertiesHelperService,
  MockHelperService,
  MockBlueMarbleService,
  MockLogger,
  MockOfferHelperService,
  MockDisconnectService,
  MockPendingOrderService,
  MockDirectvService,
  MockAddressService,
  MockReviewOrderService,
  MockCountryStateService,
  MockAccountService, 
  MOCK_ROUTES} from 'app/common/service/mockServices.test';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Logger } from 'app/common/logging/default-log.service';
import { HelperService } from 'app/common/service/helper.service';
import { Observable } from 'rxjs';
import { TooltipModule, AccordionModule, TabsModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { MockServer } from 'app/MockServer.test';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DirectvService } from 'app/common/service/directv.services';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AccountService } from 'app/common/service/account.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('PhoneConfigurationComponent', () => {
  let component: PhoneConfigurationComponent;
  let fixture: ComponentFixture<PhoneConfigurationComponent>;
  const mockServer = new MockServer();
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    SharedCommonModule,
    TextMaskModule,
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    TooltipModule.forRoot(),
    RouterTestingModule.withRoutes(MOCK_ROUTES),
    BrowserAnimationsModule
  ];

  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }

  class MockProductService {
    getFreezeDropDown() {
      return Observable.of(mockServer.getResponseForRequest('fetchRule131'))
    }
    getSwitchByTN() {return Observable.of(null)}
  }

  const store = { provide: Store, useValue: mockRedux };
  const productService = { provide: ProductService, useClass: MockProductService };
  const logger = { provide: Logger, useClass: MockLogger };
  const offerHelperService = { provide: OfferHelperService, useClass: MockOfferHelperService };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const ctlHelperService = CTLHelperService;
  const textMaskService = TextMaskService;
  const formBuilder = FormBuilder;
  const helperService = { provide: HelperService, useClass: MockHelperService };

  // Dialog component provides
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const directvService = {provide: DirectvService, useClass: MockDirectvService};
  const propertiesHelperService = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const reviewOrderService = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  const accountService = {provide: AccountService, useClass: MockAccountService};

  const providers = [
    store, appStateService, productService, systemErrorService, ctlHelperService,
    helperService, logger, offerHelperService, textMaskService, formBuilder,
    pendingOrderService, addressService, countryStateService, directvService,
    propertiesHelperService, disconnectService, blueMarbleService, reviewOrderService,
    accountService
  ];

  describe('NI Flow', () => {
    const baseConfig = {
      imports: imports,
      declarations: [PhoneConfigurationComponent],
      providers: providers
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(PhoneConfigurationComponent);
      component = fixture.componentInstance;
      const parentComponentData = mockServer.getVariables('dhp_ni_phoneConfigurationParentCompoData');
      component.inputData = parentComponentData.inputData;
      component.accordianHandler = parentComponentData.accordianHandler;
      component.exInputData = parentComponentData.exInputData;
      component.isHP = parentComponentData.isHP;
      component.isReEntrant = parentComponentData.isReEntrant;
      component.lifeLineShowing = parentComponentData.lifeLineShowing;
      component.savedPhoneTN = parentComponentData.savedPhoneTN;
      component.tnObject = parentComponentData.tnObject;
      component.cFNoAnswerSelected = true;
      component.restrictivePotsSelected = true;
      component.nonpubNoChargeSelected = true;
      component.potsAddOns = {};
      fixture.detectChanges();
    });

    it('should create phone configuration component for NI flow', () => {
      expect(component).toBeTruthy();
    });

    it('should call onSaveUpdate method from dialog modal for add on attribute', () => {
      const data = {title1: "Mdarif", title2: "Khan", lineage: "", designation: "Software Engineer", Nickname: ""};
      component.onSaveUpdate(data);
      expect(component.saveUpdates).toEqual(data);
    });

    it('should save update from Listed Address modal', () => {
      const updatedAddress = {
        streetNrFirst: "611",
        streetNamePrefix: "",
        streetName: "FENWICK DR",
        streetType: "",
        unit: "",
        city: "Papillion",
        state: "NE",
        postCode: "68046"
      };
      component.onListedUpdate(updatedAddress);
      expect(component.updatedListedAddress).toEqual(updatedAddress);
    });

    it('should should call validate fn and assign current values', () => {
      const a = {_isOpen : true};
      const b  = {_isOpen : true};
      const c  = undefined;
      const d  = undefined;
      const e  = undefined;
      const f  = undefined;
      const currentValue  = 1;
      component.validate(a,b,c,d,e,f,currentValue);
      expect(component.fedaralSelected).toBe(false);
      expect(component.tribalSelected).toBe(false);
      expect(component.stateSelected).toBe(false);
      expect(component.linkupSelected).toBe(false);
    });

    it('should should call getOptionsForDirectoryListing', () => {
      const data = mockServer.getResponseForRequest('getOptionsForDirectoryListing');
      component.OFFER_CHECK_NAME = 'Home Phone Directory Listing';
      component.getOptionsForDirectoryListing(data);
      expect(component.otherlistingOptions).not.toBe(null);
      expect(typeof component.otherlistingOptions).toBe('object');
      expect(component.otherlistingOptions).toBeDefined();
    });

    it('should call clearListingOTC and subLifelineData assign values', () => {
      component.remainCarrier();
      component.subLifelineData();
      expect(component.remainCarrierDisable).toEqual(false);
      expect(component.validLifelineData).toEqual(false);
    });

    it('should call clickDoneButton and longDistance assign values', () => {
      component.clickDoneButton();
      const data = component.longDistance();
      expect(data).toEqual('9199-NONE, NONE');
      expect(component.lifelineCollapesed).toEqual(true);
    });

    it('should call maskTelephone, moreTn and temp1 assign values', () => {
      const number = component.maskTelephone('123-212-3341');
      component.temp1(); 
      component.moreTn(); 
      expect(component.phoneNumberSelected ).toEqual(false);
      expect(number).toEqual('123-212-3341')
    });

    it('should call verifyAddress assign values', () => {
      component.verifyAddress();
      expect(component.phoneNumberSelected ).toEqual(true);
    });

    it('should call remain carrier', () => {
      component.remainCarrier();
      expect(component.remainCarrierDisable).toEqual(false);
    });
    it('should call remain carrier', () => {
      component.remainCarrier();
      expect(component.remainCarrierDisable).toEqual(false);
    });

    it('should call remainCarrierReset', () => {
      component.remainCarrierReset();
      expect(component.remainCarrierDisable).toEqual(true);
    });

    it('should call remainCarrierReset', () => {
      component.billingPotsSelected = true;
      component.assignedManualTN();
      expect(component.remainCarrierDisable).toEqual(true);
    });

    it('should call remainCarrierReset', () => {
      component.remainCarrierReset();
      expect(component.remainCarrierDisable).toEqual(true);
    });

    it('should hide lifeline on click hideLifeline', () => {
      component.hideLifeline();
      expect(component.lifeLineShowing).toBe(false);
    });

  });

  describe('Move HSI+POTS Flow', () => {
    const mockRedux: any = {
      dispatch() {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
    class MockProductService {
      getTnPortingStatus() {
        return Observable.of(mockServer.getResponseForRequest('portabilityCheck_portableNo'));
      }
      getFreezeDropDown() {
        return Observable.of(mockServer.getResponseForRequest('fetchRule131'))
      }
    }
    const store = { provide: Store, useValue: mockRedux};
    const productService = { provide: ProductService, useClass: MockProductService};
    const _providers = [...providers, store, productService];
    const baseConfig = {
      imports: imports,
      declarations: [PhoneConfigurationComponent],
      providers: _providers
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(PhoneConfigurationComponent);
      component = fixture.componentInstance;
      const parentComponentData = mockServer.getVariables('dhp_ni_phoneConfigurationParentCompoData');
      component.inputData = parentComponentData.inputData;
      component.accordianHandler = parentComponentData.accordianHandler;
      component.exInputData = parentComponentData.exInputData;
      component.isHP = parentComponentData.isHP;
      component.isReEntrant = parentComponentData.isReEntrant;
      component.lifeLineShowing = parentComponentData.lifeLineShowing;
      component.savedPhoneTN = parentComponentData.savedPhoneTN;
      component.tnObject = parentComponentData.tnObject;
      fixture.detectChanges();
    });

    it('should create phone configuration component for HSI + POTS flow', () => {
      expect(component).toBeTruthy();
    });

    it('should get called tnPortibilityCheck once user click on confirm TN and get notPortable response', () => {
      const tnForm =  component.phoneConfigForm.controls['tnForm'];
      tnForm.setValue({
        task: 'portedTn',
        SelectedManualPhoneNumber: '',
        SelectedPhoneNumber: '2121212121',
        PortingNumber: '123456789',
        accessPin: '',
        retainOtherNumbers: '',
        accountNo: '',
        wirelessNo: ''
      })
      component.confirmTn();
      expect(component.errors.tnForm.notPortable).toEqual(true);
    });
    
  });

  describe('tnPortibilityCheck with portable Yes ', () => {
    const mockRedux: any = {
      dispatch() {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
    class MockProductService {
      getTnPortingStatus() {
        return Observable.of(mockServer.getResponseForRequest('portabilityCheck_portableYes'));
      }
      getFreezeDropDown() {
        return Observable.of(mockServer.getResponseForRequest('fetchRule131'))
      }
    }
    const store = { provide: Store, useValue: mockRedux};
    const productService = { provide: ProductService, useClass: MockProductService};
    const _providers = [...providers, store, productService];
    const baseConfig = {
      imports: imports,
      declarations: [PhoneConfigurationComponent],
      providers: _providers
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(PhoneConfigurationComponent);
      component = fixture.componentInstance;
      const parentComponentData = mockServer.getVariables('dhp_ni_phoneConfigurationParentCompoData');
      component.inputData = parentComponentData.inputData;
      component.accordianHandler = parentComponentData.accordianHandler;
      component.exInputData = parentComponentData.exInputData;
      component.isHP = parentComponentData.isHP;
      component.isReEntrant = parentComponentData.isReEntrant;
      component.lifeLineShowing = parentComponentData.lifeLineShowing;
      component.savedPhoneTN = parentComponentData.savedPhoneTN;
      component.tnObject = parentComponentData.tnObject;
      fixture.detectChanges();
    });

    it('should get called tnPortibilityCheck once user click on confirm TN and get portable response', () => {
      const tnForm =  component.phoneConfigForm.controls['tnForm'];
      tnForm.setValue({
        task: 'portedTn',
        SelectedManualPhoneNumber: '',
        SelectedPhoneNumber: '2121212121',
        PortingNumber: '123456789',
        accessPin: '',
        retainOtherNumbers: '',
        accountNo: '',
        wirelessNo: ''
      })
      component.confirmTn();
    });

    it('should call Listing Details and assign values', () => {
      const data = mockServer.getResponseForRequest('listing_details');
      component.ListingDetails(data); 
      expect(component.exFirstName).toBeDefined();
      expect(component.exFirstName).not.toBe(null);
      expect(typeof component.exFirstName).toBe('object');
    });
    
  });

  describe('tnPortibilityCheck with error response', () => {
    class MockProductService {
      getTnPortingStatus() {
        return Observable.throw(mockServer.getResponseForRequest('portabilityCheck_portableNo'));
      }
      getFreezeDropDown() {
        return Observable.throw(mockServer.getResponseForRequest('fetchRule131'))
      }
    }
    const productService = { provide: ProductService, useClass: MockProductService};
    const _providers = [...providers, productService];
    const baseConfig = {
      imports: imports,
      declarations: [PhoneConfigurationComponent],
      providers: _providers
    };

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(PhoneConfigurationComponent);
      component = fixture.componentInstance;
      const parentComponentData = mockServer.getVariables('dhp_ni_phoneConfigurationParentCompoData');
      component.inputData = parentComponentData.inputData;
      component.accordianHandler = parentComponentData.accordianHandler;
      component.exInputData = parentComponentData.exInputData;
      component.isHP = parentComponentData.isHP;
      component.isReEntrant = parentComponentData.isReEntrant;
      component.lifeLineShowing = parentComponentData.lifeLineShowing;
      component.savedPhoneTN = parentComponentData.savedPhoneTN;
      component.tnObject = parentComponentData.tnObject;
      fixture.detectChanges();
    });

    it('should check tnPortibilityCheck once user click on confirm TN and get error response', () => {
      const tnForm =  component.phoneConfigForm.controls['tnForm'];
      tnForm.setValue({
        task: 'portedTn',
        SelectedManualPhoneNumber: '',
        SelectedPhoneNumber: '2121212121',
        PortingNumber: '123456789',
        accessPin: '',
        retainOtherNumbers: '',
        accountNo: '',
        wirelessNo: ''
      })
      expect(component.loading).toEqual(false);
    });

  });

});
