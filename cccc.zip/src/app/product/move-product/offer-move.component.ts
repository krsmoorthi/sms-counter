import { Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStore } from 'app/common/models/appstore.model';
import { ContactInfo, CustomerOrderItems, CustomerOrderSubItem, Payload, ShoppingCart } from 'app/common/models/cart.model';
import { GenericValues } from 'app/common/models/common.model';
import { OfferVariables } from 'app/common/models/offers.model';
// tslint:disable-next-line:no-unused-variable
import { AttributesCombination, OfferProductComponents, PayloadProduct, Prices, ProductOfferings, Products } from 'app/common/models/product.model';
import { User } from 'app/common/models/user.model';
import { AddressService } from 'app/common/service/address.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { HelperService } from "app/common/service/helper.service";
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { DialogComponent } from 'app/common/popup/dialog.component';
import * as _ from 'lodash';
import { RE_ENTRANT_OFFERVARIABLE } from 'app/app.constant';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
    selector: 'move-product',
    styleUrls: ['./../offer.component.scss'],
    templateUrl: './offer-move.component.html'
})

export class OfferMoveComponent implements OnInit, OnDestroy, AfterViewInit {
    public offerVariables: OfferVariables;
    public movetabSelected: boolean = false;
    public enableMovetab: boolean = false;
    public removal: any = {};
    public user: Observable<User>;
    public userSubscription: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public existingOffersCalled: boolean = false;
    public existingInternet: boolean = false;
    public isp4L: boolean = false;
    public changedModemType: string = '';
    public newLocation = [];
    public e911Retained: any;
    public cartOrd: CustomerOrderItems;
    public pendingObservable: Observable<any>;
    public pendingSubscription: Subscription;
    public orderObservable: Observable<any>;
    public orderSubscription: Subscription;
    public prodConfig: any;
    public exprodConfig: any;
    @ViewChild("removeProduct", { static: false, }) public removeProduct: any;
    @ViewChild("e911Validation", { static: false, }) public e911Validation: any;
    @ViewChild('voiceMailInput', { static: false, }) public voiceMailInput: ElementRef;
    @ViewChild('wireMaintainanceInput', { static: false, }) public wireMaintainanceInput: ElementRef;
    @ViewChild('portingInput', { static: false, }) public portingInput: ElementRef;
    @ViewChild('easeSelected', { static: false, }) public easeSelected: ElementRef;
    @ViewChild('secureWifiSelected', { static: false, }) public secureWifiSelected: ElementRef;
    @ViewChild('jackSelected', { static: false, }) public jackSelected: ElementRef;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;

    constructor(
        private logger: Logger,
        public store: Store<AppStore>,
        private router: Router,
        private productService: ProductService,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private disconnectServiceCall: DisconnectService,
        private bMService: BlueMarbleService,
        private addressService: AddressService,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
        public offerHelperService: OfferHelperService
    ) {
        this.appStateService.setLocationURLs();
        let addons: CustomerOrderItems[];
        this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);
        if (this.offerVariables) {
            let cart = <Observable<ShoppingCart>>this.store.select('cart');
            let cartSubscription = cart.subscribe((data) => {
                if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
                    addons = data.payload.cart.customerOrderItems;
                    addons[0].customerOrderSubItems.forEach(data => {
                        if (data.componentType === "PRIMARY")
                            this.offerVariables.selectedValues = data.productName;
                    })
                }
                if (data && data.payload && data.payload.discountItems) {
                    this.offerVariables.discountsAdded = data.payload.discountItems;
                    this.offerVariables.copyOfDiscountsAdded = this.offerVariables.discountsAdded;
                }
            })
            if (cartSubscription !== undefined)
                cartSubscription.unsubscribe();
        }
        this.offerVariables.currentComponentName = "offer-move.component.ts";
        this.initializeAll('false');
    }

    public ngAfterViewInit() {
        this.offerVariables.currentFlow = "MOVE";
        this.offerVariables.secureWifiSelected = this.secureWifiSelected;
        this.offerVariables.easeSelected = this.easeSelected;
        this.offerVariables.voiceMailInput = this.voiceMailInput;
        this.offerVariables.wireMaintainanceInput = this.wireMaintainanceInput;
        this.offerVariables.portingInput = this.portingInput;
    }

    public initializeAll(flagUndo: string) {
        this.offerVariables.existingModem = undefined;
        this.offerVariables.isProfileBypassLoopQual = this.helperService.isAuthorized(ProfileEnums.BYPASS_LOOP_QUAL);
        this.offerVariables.isProfileBypassHSISpeeds = this.helperService.isAuthorized(ProfileEnums.BYPASS_HSI_SPEEDS);
        this.offerVariables.isProfileBypassModemCheck = this.helperService.isAuthorized(ProfileEnums.BYPASS_MODEM_CHECK);
        this.user = <Observable<User>>this.store.select('user');
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.pendingObservable = <Observable<any>>this.store.select('pending');
        this.orderObservable = <Observable<any>>this.store.select('order');
        this.offerVariables.discountedPriceList = [];
        this.offerVariables.internetCheck = false;
        this.offerVariables.internetOffer = true;
        this.offerVariables.videoOffer = false;
        this.offerVariables.phoneOffer = false;
        this.offerVariables.internetAvail = false;
        this.offerVariables.videoAvail = false;
        this.offerVariables.phoneAvail = false;
        this.offerVariables.videoSelected = 'NoTV';
        this.offerVariables.phoneSelected = GenericValues.noPhone;
        this.offerVariables.offersGenerated = true;
        this.offerVariables.serviceUnavailable = 'Service not available for your Address';
        let prod: Products = {
            productId: '608',
            productName: 'Intrastate Service Fee',
            productType: 'Service',
            isRegulated: false
        };
        let state: boolean = false;
        this.offerVariables.intraStateFee = prod;
        this.offerVariables.holdCalled = false;
        if (flagUndo) this.existingOffersCalled = false;
        this.userSubscription = this.user.subscribe(
            (data) => {
                this.offerVariables.isDtvOpus = data.isDtvOpus;
                if (data.selfinstallselected) this.offerVariables.selfinstallSelected = true;
                if (data && data.existsServices && data.existsServices.indexOf('INTERNET') > -1) {
                    this.offerVariables.isHSIExistingProduct = true;
                }
                if(data && data.orderInit && data.orderInit.payload && data.orderInit.payload.newLocation && data.orderInit.payload.newLocation.serviceAddress
                     && data.orderInit.payload.newLocation.serviceAddress.locationAttributes && data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider){
                        this.offerVariables.legacyProvider = data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider;
                }
            }
        );
        let exist = this.appStateService.getState().existingProducts;
        this.offerVariables.existingObjects = exist;
        if (exist.orderFlow.type === 'fromHold') {
            this.offerVariables.fromHold = true;
        }
        if (exist) {
            if (exist.existingDiscounts) {
                this.offerVariables.existingDiscounts = exist.existingDiscounts;
            }
            if (exist.existingProductsAndServices && exist.existingProductsAndServices[0].accountInfo
                && exist.existingProductsAndServices[0].accountInfo.billingType) {
                this.offerVariables.offerBillingType = exist.existingProductsAndServices[0].accountInfo.billingType === "PREPAID" ? exist.existingProductsAndServices[0].accountInfo.billingType : "POSTPAID";
            }
        }
        if (exist && exist.orderFlow && exist.orderFlow.flow) this.offerVariables.flow = exist.orderFlow.flow.toUpperCase();
        if (exist && exist.orderFlow && exist.orderFlow.flow === 'Move' && this.offerVariables.fromHold && !exist.orderFlow.selectProductCalled && !this.offerVariables.holdCalled) {
            this.pendingSubscription = this.pendingObservable.subscribe(pending => {
                let inputAddress: any;
                let callerInfo: ContactInfo = {
                    firstName: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.accountName &&
                        pending.orderDocument.accountInfo.accountName.firstName ? pending.orderDocument.accountInfo.accountName.firstName : 'First Name',
                    lastName: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.accountName &&
                        pending.orderDocument.accountInfo.accountName.lastName ? pending.orderDocument.accountInfo.accountName.lastName : 'Last Name',
                    phoneNumber: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.contact &&
                        pending.orderDocument.accountInfo.contact.contactNumber ? pending.orderDocument.accountInfo.contact.contactNumber : '2424242424',
                };
                inputAddress = {
                    addressLine: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetAddress,
                    unitNumber: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.subAddress
                        && pending.orderDocument.serviceAddress.subAddress.combinedDesignator,
                    stateOrProvince: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.stateOrProvince,
                    city: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.city,
                    postCode: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.postCode,
                    singleLine: true,
                    orderReferenceNumber: pending && pending.orderReference && pending.orderReference.orderReferenceNumber,
                    streetNrFirst: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrFirst,
                    streetNrFirstSuffix: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrFirstSuffix,
                    streetNrLast: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrLast,
                    streetNrLastSuffix: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrLastSuffix,
                    streetName: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetName,
                };
                this.offerVariables.holdedObjects = pending;
                this.offerVariables.loading = true;
                this.logger.log("info", "offer-move.component.ts", "moveAddressRequest", JSON.stringify(inputAddress));
                this.logger.startTime();
                this.addressService.moveAddress(inputAddress, true, pending.orderDocument, true)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "offer-move.component.ts", "moveAddressResponse", JSON.stringify(error));
                        this.logger.log("error", "offer-move.component.ts", "moveAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.ctlHelperService.setLocalStorage('error', error);
                        this.offerVariables.loading = false;
                        return Observable.throw(error._body);
                    })
                    .subscribe(
                        (data) => {
                            this.logger.endTime();
                            this.logger.log("info", "offer-move.component.ts", "moveAddressResponse", JSON.stringify(data ? data : ''));
                            this.logger.log("info", "offer-move.component.ts", "moveAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.offerVariables.loading = false;
                            let response = data;
                            if (response && response.taskName === 'Select Product') {
                                callerInfo = {
                                    firstName: data.payload.existingLocation.accountInfo.accountName.firstName,
                                    lastName: data.payload.existingLocation.accountInfo.accountName.lastName,
                                    phoneNumber: data.payload.existingLocation.accountInfo.contact.contactNumber,
                                };
                                this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
                                let internetCheck = false;
                                let videoAvail;
                                let phoneAvail: boolean = false;
                                let phoneType = [];
                                let videoType = [];
                                if (response.payload && response.payload.newLocation && this.addressService.checkCategoryId('DATA',
                                    response.payload.newLocation.serviceCategory) !== undefined) {
                                    internetCheck = true;
                                }
                                if (response.payload && response.payload.newLocation && this.addressService.checkCategoryId('DATA/VIDEO',
                                    response.payload.newLocation.serviceCategory) !== undefined) {
                                    videoAvail = true;
                                    videoType.push({
                                        name: 'DATA/VIDEO',
                                        displayName: 'PRISM TV',
                                        code: 'PTV',
                                        tabName: 'PRISM'
                                    });
                                }
                                if (response.payload && response.payload.newLocation && this.addressService.checkCategoryId('VIDEO-DTV',
                                    response.payload.newLocation.serviceCategory) !== undefined) {
                                    videoAvail = true;
                                    videoType.push({
                                        name: 'VIDEO-DTV',
                                        displayName: 'DIRECTV',
                                        code: 'DTV',
                                        tabName: 'DIRECTV'
                                    });
                                }
                                if (response.payload && response.payload.newLocation && this.addressService.checkCategoryId('VOICE-DHP',
                                    response.payload.newLocation.serviceCategory) !== undefined) {
                                    phoneAvail = true;
                                    phoneType.push({
                                        name: 'VOICE-DHP',
                                        displayName: 'Digital(DHP)',
                                        code: 'DHP',
                                        tabName: 'DHP'
                                    });
                                }
                                if (response.payload && response.payload.newLocation && this.addressService.checkCategoryId('VOICE-HP',
                                    response.payload.newLocation.serviceCategory) !== undefined) {
                                    phoneAvail = true;
                                    phoneType.push({
                                        name: 'VOICE-HP',
                                        displayName: 'Home Phone',
                                        code: 'HMP',
                                        tabName: 'Home Phone'
                                    });
                                }
                                let user: User = {
                                    id: 1,
                                    internetCheck,
                                    videoCheck: videoAvail,
                                    phoneCheck: phoneAvail,
                                    phoneType: phoneType,
                                    videoType: videoType,
                                    enabledServiceList: response.payload && response.payload.newLocation && response.payload.newLocation.serviceCategory,
                                    ban: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.ban
                                };
                                this.store.dispatch({ type: 'UPDATE_USER', payload: user });
                                this.store.dispatch({ type: 'FINAL_ADDRESS', payload: inputAddress });
                                this.orderSubscription = this.orderObservable.subscribe(ord => {
                                    if (ord.orderRefNumber) {
                                        data.orderRefNumber = ord.orderRefNumber;
                                        data.processInstanceId = ord.processInstanceId;
                                        data.taskId = ord.taskId;
                                    }
                                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                    this.offerVariables.isCustomize = ord.taskName === 'Checkout & Scheduling' ? true : false;
                                    this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                                    if (!this.offerVariables.holdCalled) {
                                        this.offerVariables.holdCalled = true;
                                        this.offerVariables.isPortingCheckNoSelected = false;
                                        this.offerVariables.isPortingCheckNoSelected = true;
                                        if (this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument
                                            && this.offerVariables.holdedObjects.orderDocument.reservedTN
                                            && this.offerVariables.holdedObjects.orderDocument.reservedTN.length > 0) {
                                            this.offerVariables.holdedObjects.orderDocument.reservedTN.map(tn => {
                                                if (tn && tn.productType === GenericValues.cHP && tn.tnType === 'EXTPORTED') {
                                                    this.offerVariables.portingCheck = true;
                                                    this.offerVariables.isPortingCheckYesSelected = true;
                                                    this.offerVariables.isPortingCheckNoSelected = false;
                                                    this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: this.offerVariables.portingCheck });
                                                }
                                            })
                                        }
                                        state = this.selectProductAPI(this.store, state);
                                        this.prodConfig = pending && pending.orderDocument && pending.orderDocument.productConfiguration;
                                        if (this.prodConfig) this.offerHelperService.existingProductConfigCheck(this.offerVariables, this.prodConfig);
                                    }
                                })
                            }
                        },
                        (error) => {
                            this.logger.endTime();
                            this.logger.log("error", "offer-move.component.ts", "moveAddressResponse", JSON.stringify(error));
                            this.logger.log("error", "offer-move.component.ts", "moveAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.offerVariables.loading = false;
                            let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                                this.offerVariables.apiResponseError = JSON.parse(error);
                                if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                                    this.offerVariables.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Move Page", this.offerVariables.apiResponseError);
                                } else unexpectedError = true;
                            } else unexpectedError = true;
                            if (unexpectedError) {
                                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                                this.systemErrorService.logAndeRouteToSystemError("error", "offer-move.component.ts", this.offerVariables.taskName, "Offer Move Page", lAPIErrorLists);
                            }
                        })
            })
        } else {
            state = this.selectProductAPI(this.store, state, flagUndo);
        }
        if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
    }
    public existingmoveProductsSelected() {
        this.enableMovetab = true;
        this.store.dispatch({ type: 'MOVE_EXISTING_TAB', payload: this.enableMovetab });
        this.store.dispatch({ type: 'CHANGE_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'BILLING_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'DISCONNECT_EXISTING_TAB', payload: false });
    }
    private selectProductAPI(store: Store<AppStore>, state: boolean, flag?: string) {
        let data = this.appStateService.getState().user;
        if (!state) {
            let usr: any;
            usr = data;
            if (usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.existingLocation && usr.orderInit.payload.existingLocation.existingServices && usr.orderInit.payload.existingLocation.existingServices.existingServiceItems) {
                this.offerVariables.existingServices = usr.orderInit.payload.existingLocation.existingServices.existingServiceItems;
            }
            if (this.offerVariables.existingServices) {
                this.offerVariables.existingServices.map((item) => {
                    if (!item.customerOrderSubItems) item.customerOrderSubItems = item.existingServiceSubItems;
                    if (item.offerCategory === GenericValues.cDTV) {
                        this.offerVariables.dtvExisting = true;
                    }
                    if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER') {
                        this.offerVariables.dhpExisting = true;
                    } else if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER') {
                        this.offerVariables.hpExisting = true;
                        this.isp4L = item.offerType === 'P4L' ? true : false;;
                    }
                });
            }
            this.offerVariables.orderRefNumber = data.orderInit.orderRefNumber;
            this.offerVariables.processInstanceId = data.orderInit.processInstanceId;
            if (flag === 'false') {
                this.offerVariables.taskId = data.orderInit.taskId;
            }
            if (data.autoLogin) {
                if (data.autoLogin.oamData) {
                    this.offerVariables.agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    this.offerVariables.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    this.offerVariables.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    this.offerVariables.ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                }
            }
            this.newLocation = usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.newLocation && usr.orderInit.payload.newLocation.serviceCategory;
            let disconnectReq = {
                'ban': usr.ban,
                'salesChannel': 'ESHOP-Customer Care',
                'customerOrderType': 'DISCONNECT',
                'serviceAddress': usr.finalAddress.addressLine ? usr.finalAddress : (usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.newLocation && usr.orderInit.payload.newLocation.serviceAddress),
                party: {
                    id: this.offerVariables.agentCuid,
                    firstName: this.offerVariables.firstName,
                    lastName: this.offerVariables.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.offerVariables.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.offerVariables.ensembleId
                        }
                    ]
                }
            };
            this.offerVariables.disconnectReq = JSON.stringify(disconnectReq);
            this.offerVariables.taskName = data.orderInit.taskName;
            if(data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceCategory) {
                this.offerVariables.serviceSpec = data.orderInit.payload.serviceCategory;
            }
            this.offerVariables.internetAvail = data.internetCheck;
            this.offerVariables.videoAvail = data.videoCheck;
            this.offerVariables.phoneAvail = data.phoneCheck;
            this.offerVariables.phoneArray = data.phoneType;
            this.offerVariables.videoArray = data.videoType;
            this.offerVariables.ban = data.ban;
            this.offerVariables.enabledServiceList = data.enabledServiceList;
            this.appStateService.setLocationURLs();
            let cart = <Observable<ShoppingCart>>this.store.select('cart');
            let cartSubscription = cart.subscribe((data) => {
                if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
                    this.cartOrd = this.offerHelperService.findCustomerOrderProduct(data.payload.cart.customerOrderItems, GenericValues.iData, true);
                }
                this.existingObservable = <Observable<any>>this.store.select('existingProducts');
                this.existingSubscription = this.existingObservable.subscribe(
                    (exist) => {
                        if (exist.enablemovetab === true) {
                            this.movetabSelected = true;
                        } else {
                            this.movetabSelected = false;
                        }
                    });
                if (this.movetabSelected) {
                    this.offerVariables.taskId = data.taskId;
                }
            });
            if (cartSubscription !== undefined) {
                cartSubscription.unsubscribe();
            }
            let retSubscribe: Subscription;
            let retainVal = <Observable<any>>this.store.select('retain');
            retSubscribe = retainVal.subscribe((retVal => {
                this.offerVariables.removeResponse = retVal.disconnectReason;
            }));
            if (data.previousUrl !== '/' && (data.previousUrl !== '/home' || this.offerVariables.fromHold) && data.previousUrl !== '/multipleMatchAddress' && (data.previousUrl !== '/existing-products' || (data.previousUrl === '/existing-products' && this.offerVariables.fromHold)) && data.autoLogin !== undefined) {
                this.offerVariables.isReEntrant = true;
                this.offerVariables.reEntrant = true;
                this.offerVariables.reentrantUI = true;
                retSubscribe = retainVal.subscribe((retVal => {
                    if (!state) {
                        this.offerVariables.taskId = data.taskId;
                        this.offerVariables.taskName = retVal.selectProduct.taskName;
                        this.offerVariables.retainedPotsBooleans = retVal.potsBooleans;
                        this.offerVariables.wireMaintainance = this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.wireMaintainance;
                        this.offerVariables.voiceMail = this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.voiceMail;
                        if (this.offerVariables.voiceMail) this.offerVariables.voiceMailValue = 'Yes';
                        if (!this.offerVariables.holdCalled) this.offerVariables.portingCheck = this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.portingCheck;
                        this.offerVariables.selectedMaintainance = this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.selectedMaintainance;
                        this.offerVariables.selectedMaintainance ? this.offerVariables.wireMaintainanceValue = 'Yes' : this.offerVariables.wireMaintainanceValue = 'No';
                        this.offerVariables.isInternational = this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.isInternational;
                        this.offerVariables.dhpIntlSelected = this.offerVariables.isInternational ? 'Yes' : 'No';
                        this.offerVariables.cartObject = retVal.addOns;
                        this.offerVariables.cartCopyObject = cloneDeep(retVal.addOns);
                        this.e911Retained = retVal.e911ValidatedAddress;
                        this.offerVariables.e911ValidatedAddress = retVal.e911ValidatedAddress;
                        let custOrderItem: CustomerOrderItems[] = this.offerVariables.holdCalled ? this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
                            this.offerVariables.holdedObjects.orderDocument.customerOrderItems : retVal.addOns.payload.cart.customerOrderItems;
                        if (this.offerVariables.cartObject && this.offerVariables.cartObject.payload) {
                            this.offerVariables.cartObject.payload = {
                                cart: {
                                    customerOrderItems: custOrderItem
                                },
                                productConfiguration: !this.offerVariables.holdCalled ? retVal && retVal.addOns && retVal.addOns.payload && retVal.addOns.payload.productConfiguration :
                                    this.offerVariables.existingObjects && this.offerVariables.existingObjects.existingProductsAndServices && this.offerVariables.existingObjects.existingProductsAndServices[0]
                                    && this.offerVariables.existingObjects.existingProductsAndServices[0].productConfiguration
                            }
                        } else {
                            this.offerVariables.cartObject = {
                                payload: {
                                    cart: {
                                        customerOrderItems: custOrderItem
                                    },
                                    productConfiguration: !this.offerVariables.holdCalled ? retVal && retVal.addOns && retVal.addOns.payload && retVal.addOns.payload.productConfiguration :
                                        this.offerVariables.existingObjects && this.offerVariables.existingObjects.existingProductsAndServices && this.offerVariables.existingObjects.existingProductsAndServices[0]
                                        && this.offerVariables.existingObjects.existingProductsAndServices[0].productConfiguration
                                }
                            }
                        }
                        this.offerVariables.cartCopyObject = cloneDeep(this.offerVariables.cartObject);
                        this.installationDevices();
                        if (this.offerVariables.cartObject && this.offerVariables.internetAvail) {
                            this.offerVariables.internetCheck = this.offerHelperService.isExists(this.offerVariables.cartObject.payload.cart.customerOrderItems, GenericValues.iData, true);
                            if(!this.offerVariables.internetCheck && this.offerHelperService.isExists(this.offerVariables.cartObject.payload.cart.customerOrderItems, GenericValues.cHP))  { this.offerVariables.phoneSelected = 'HMP'; }
                            this.existingInternet = this.offerVariables.internetCheck;
                            this.offerVariables.newInternetCheck = this.offerVariables.internetCheck;
                            if (this.offerVariables.internetCheck && !this.offerVariables.holdCalled) {
                                this.offerVariables.cartCopyObject.payload.productConfiguration = !this.offerVariables.holdCalled ? retVal && retVal.addOns && retVal.addOns.payload && this.offerVariables.cartCopyObject.payload.productConfiguration :
                                    this.offerVariables.existingObjects && this.offerVariables.existingObjects.existingProductsAndServices && this.offerVariables.existingObjects.existingProductsAndServices[0]
                                    && this.offerVariables.existingObjects.existingProductsAndServices[0].productConfiguration
                            }
                            if (this.offerHelperService.isExists(this.offerVariables.cartObject.payload.cart.customerOrderItems, GenericValues.cDHP)) {
                                let dhp = this.offerHelperService.getExistingProducts(this.offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.cDHP);
                                if (dhp && dhp.customerOrderSubItems !== null && dhp.customerOrderSubItems
                                    && dhp.customerOrderSubItems.length !== 0) {
                                    dhp.customerOrderSubItems.map(subItems => {
                                        if (subItems && subItems.productName === 'Digital Home Phone Intl Call') {
                                            subItems.productAttributes.map(subAttr => {
                                                if ((subAttr && subAttr.compositeAttribute !== null && subAttr.compositeAttribute.length !== 0
                                                    && subAttr.compositeAttribute[0].attributeName === 'Service Status')) {
                                                    subAttr.compositeAttribute[0].attributeValue === 'Enabled'
                                                        || subAttr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes' ? this.offerVariables.dhpIntlSelected = 'Yes' :
                                                        this.offerVariables.dhpIntlSelected = 'No';
                                                    this.offerVariables.dhpIntlSelected === 'Yes' ? this.offerVariables.isInternational = true : this.offerVariables.isInternational = false;
                                                }
                                            })
                                        }
                                    })
                                }
                                if (this.offerVariables.fromHold && this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
                                    this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo && this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address) {
                                    this.offerVariables.e911ValidatedAddress = this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address;
                                    this.offerVariables.e911ValidatedAddress.acceptedData = this.offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.dhpDisclaimerAcceptDateTime;
                                }
                            }
                        }
                        if (this.offerVariables.isReEntrant && this.offerVariables.cartCopyObject && this.offerVariables.cartCopyObject.payload && this.offerVariables.cartCopyObject.payload.cart.customerOrderItems) {
                            this.getPhoneData(this.offerVariables.cartCopyObject.payload.cart.customerOrderItems);
                        }
                        state = true;
                        this.offerVariables.calledFromConstructor = true;
                        this.offerVariables.internetAvail && this.offerVariables.internetCheck ? this.offerHelperService.retrieveOffers(this.offerVariables, true) : this.offerHelperService.retrieveOffers(this.offerVariables, true, true);
                        this.offerHelperService.fetchExistingProducts(this.offerVariables, this.offerVariables.existingServices, false);
                    }
                }));
            }
            else {
                if (!state) {
                    if (this.offerVariables.existingServices && this.offerVariables.internetAvail) {
                        this.offerVariables.internetCheck = this.offerHelperService.isExists(this.offerVariables.existingServices, GenericValues.iData, true);
                        if(!this.offerVariables.internetCheck && this.offerHelperService.isExists(this.offerVariables.existingServices, GenericValues.cHP)) { this.offerVariables.newPhoneSelected = 'HMP'; }
                        if(!this.offerVariables.internetCheck && this.offerHelperService.isExists(this.offerVariables.existingServices, GenericValues.cDTV)) { this.offerVariables.newVideoSelected = 'DTV'; }
                        this.existingInternet = this.offerVariables.internetCheck;
                        this.offerVariables.newInternetCheck = this.offerVariables.internetCheck;
                        if (this.offerVariables.internetCheck) {
                            this.offerVariables.cartCopyObject = {
                                payload: {
                                    productConfiguration: this.offerVariables.existingObjects && this.offerVariables.existingObjects.existingProductsAndServices && this.offerVariables.existingObjects.existingProductsAndServices[0]
                                        && this.offerVariables.existingObjects.existingProductsAndServices[0].productConfiguration
                                }
                            }
                        }
                    } else if (this.offerVariables.existingServices) {
                        if(!this.offerVariables.internetCheck && this.offerHelperService.isExists(this.offerVariables.existingServices, GenericValues.cHP)) { this.offerVariables.newPhoneSelected = 'HMP'; }
                        if(!this.offerVariables.internetCheck && this.offerHelperService.isExists(this.offerVariables.existingServices, GenericValues.cDTV)) { this.offerVariables.newVideoSelected = 'DTV'; }
                    }
                    if (this.offerVariables.existingServices !== undefined) {
                        this.getPhoneData(this.offerVariables.holdCalled ? this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument
                            && this.offerVariables.holdedObjects.orderDocument.customerOrderItems : this.offerVariables.existingServices);
                    }
                    state = true;
                    this.offerVariables.calledFromConstructor = true;
                    if (this.offerVariables.dhpExisting) this.offerHelperService.e911Response(undefined, this.offerVariables, true);
                    if(!this.offerVariables.dhpExisting)
                    this.offerVariables.internetCheck ? this.offerHelperService.retrieveOffers(this.offerVariables, true) : this.offerHelperService.retrieveOffers(this.offerVariables, true, true);
                    this.offerHelperService.fetchExistingProducts(this.offerVariables, this.offerVariables.existingServices, true)
                }
            }
            this.offerVariables.existingServices && this.offerVariables.existingServices.map(exServ => {
                if (exServ && exServ.offerCategory === GenericValues.cHP && exServ.offerType !== 'SUBOFFER') {
                    if (!this.offerVariables.isReEntrant) {
                        this.offerVariables.wireMaintainanceValue = 'No';
                        this.offerVariables.voiceMailValue = 'No';
                    }
                    exServ.existingServiceSubItems && exServ.existingServiceSubItems.map(exSub => {
                        if (exSub.productName === "Voice Messaging") {
                            if (!this.offerVariables.isReEntrant) {
                                this.offerVariables.voiceMail = true;
                                this.offerVariables.voiceMailValue = 'Yes';
                            }
                            this.offerVariables.voiceMailCondi = true;
                        }
                        else if (exSub.productName.indexOf('Wire Maintenance Plan') !== -1) {
                            if (!this.offerVariables.isReEntrant) {
                                this.offerVariables.wireMaintainance = true;
                                this.offerVariables.wireMaintainanceValue = 'Yes';
                            }
                            this.offerVariables.wireMaintainCondi = true;
                            this.offerVariables.isWireMaintainanceYesSelected = true;
                            this.offerVariables.isWireMaintainanceNoSelected = false;
                        } else if (exSub.productName.indexOf('Jack and Wire') !== -1) {
                            this.offerVariables.retainValueForPotsJack = exSub.productAttributes[0].compositeAttribute[0].attributeValue
                        } else if (exSub.productName.indexOf('Extended Area Calling') !== -1) {
                            this.offerVariables.isExtendedAreaCallingExits = true;
                        }
                    });
                }
            });
               this.offerVariables.retainedPotsBooleans = {
                wireMaintainance: this.offerVariables.wireMaintainance,
                voiceMail: this.offerVariables.voiceMail,
                retainValueForPotsJack: this.offerVariables.retainValueForPotsJack,
                portingCheck: this.offerVariables.portingCheck
            }
        }
        this.getRemoveResponse();
        this.offerHelperService.notAvailProd(this.offerVariables);
        if (this.offerVariables.existingObjects && this.offerVariables.existingObjects.existingTN) {
            this.offerVariables.existingTN = this.offerHelperService.maskTelephone(this.offerVariables.existingObjects.existingTN);
        }
        return state;
    }

    private installationDevices() {
        if (!this.offerVariables.deviceSelected && this.offerVariables.cartCopyObject && this.offerVariables.cartCopyObject.payload && this.offerVariables.cartCopyObject.payload.productConfiguration) {
            let selectConfigList = this.offerVariables.cartCopyObject.payload.productConfiguration;
            if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
                for (let i = 0; i < selectConfigList.length; i++) {
                    selectConfigList[i].configItems && selectConfigList[i].configItems.map(selectedConf => {
                        this.offerVariables.selectedQuantity = selectedConf.configDetails[0].formItems[0].attributeValue[0].value;
                        this.offerVariables.deviceSelected = true;
                    });
                }
            }
        }
    }

    public ngOnInit() {
        this.logger.metrics('OfferMovePage');
        window.scroll(0, 0);
        this.offerVariables.loading = true;
        this.offerVariables.retrieveOffersLoading = true;
        this.offerHelperService.getReentrantFlags(this.offerVariables);
        this.offerHelperService.getTechnologyTypes(this.offerVariables);
        this.offerHelperService.compatibilityAPIcall(this.offerVariables);
        this.offerHelperService.checkCSCompatibitlity(this.offerVariables);
        this.offerHelperService.setDiscountsFromExistingDiscounts(this.offerVariables, this.offerVariables.existingDiscounts);
        this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: { type: '', selected: '' } } });
    }

    public removeProductDialog() {
        if (this.offerVariables.hsiExisting && !this.offerVariables.isInternetRemoved) {
            this.removeProduct.open();
        }
    }

    private retrievePhoneOffer(item: any, payload: PayloadProduct) {
        if (this.offerVariables.phoneOfferData && this.offerVariables.phoneOfferData.length === 0) {
            this.offerVariables.loading = true;
            this.logger.log("info", "offer-move.component.ts", "selectedProductSrvcRequest", JSON.stringify(item));
            this.logger.startTime();
            this.productService.getOffers(item, 'move')
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "selectedProductSrvcResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-move.component.ts", "selectedProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.offerVariables.retrieveOffersLoading = false;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Get POTS Offers - Offers Page", error);
                    return Observable.throwError(null);
                })
                .subscribe((data) => {
                    this.logger.endTime();
                    this.logger.log("info", "offer-move.component.ts", "selectedProductSrvcResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "offer-move.component.ts", "selectedProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.offerVariables.offerResponse = data;
                    if (this.offerVariables.offerResponse && this.offerVariables.offerResponse.payload && this.offerVariables.offerResponse.payload !== undefined &&
                        this.offerVariables.offerResponse.payload.retrievalTypes !== undefined && this.offerVariables.offerResponse.payload.retrievalTypes[0] !== undefined) {
                        this.offerVariables.offerResponse.payload.offers = this.offerVariables.offerResponse.payload.retrievalTypes[0].offers;
                    }
                    this.offerVariables.initialOfferResponse = data;
                    if (this.offerVariables.initialOfferResponse && this.offerVariables.initialOfferResponse.payload && this.offerVariables.initialOfferResponse.payload !== undefined &&
                        this.offerVariables.initialOfferResponse.payload.retrievalTypes !== undefined && this.offerVariables.initialOfferResponse.payload.retrievalTypes[0] !== undefined) {
                        this.offerVariables.initialOfferResponse.payload.offers = this.offerVariables.initialOfferResponse.payload.retrievalTypes[0].offers;
                    }
                    if (this.offerVariables.initialOfferResponse && this.offerVariables.initialOfferResponse.payload && this.offerVariables.initialOfferResponse.payload.productConfiguration !== null
                        && this.offerVariables.initialOfferResponse.payload.productConfiguration && this.offerVariables.initialOfferResponse.payload.productConfiguration.length > 0) {
                        this.offerVariables.productConfiguration = this.offerVariables.initialOfferResponse.payload.productConfiguration;
                    }
                    if (this.offerVariables.offerResponse && this.offerVariables.offerResponse.payload && this.offerVariables.offerResponse.payload !== undefined && this.offerVariables.offerResponse.payload.giftCardOffers && (this.offerVariables.offerResponse.payload.giftCardOffers !== undefined && this.offerVariables.offerResponse.payload.giftCardOffers !== null)) {
                        this.store.dispatch({ type: 'INCLUDING_GIFTCARDS', payload: this.offerVariables.offerResponse.payload.giftCardOffers });
                    }
                    this.offerVariables.dataLink = this.offerHelperService.getOfferLink(GenericValues.sData, this.offerVariables.initialOfferResponse.payload.offers);
                    this.offerVariables.videoLink = this.offerHelperService.getOfferLink(this.offerVariables.videoSelected, this.offerVariables.initialOfferResponse.payload.offers);
                    this.offerVariables.catalogSpecId = this.offerVariables.offerResponse.payload.cart.catalogSpecId;
                    this.onlyPOTSOffers(payload);
                }, (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "selectedProductSrvcResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-move.component.ts", "selectedProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.offerVariables.retrieveOffersLoading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.offerVariables.apiResponseError = JSON.parse(error);
                        if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                            this.offerVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", this.offerVariables.taskName, "offer.component.ts", "Offers Page", this.offerVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", this.offerVariables.taskName, "offer.component.ts", "Offers Page", lAPIErrorLists);
                    }
                });
        } else {
            this.onlyPOTSOffers(payload);
        }
    }

    private retrieveVideoOffer(payload: PayloadProduct) {
        this.offerVariables.videoLink = this.offerHelperService.getOfferLink(this.offerVariables.videoSelected, this.offerVariables.initialOfferResponse.payload.offers);
        this.offerVariables.loading = true;
        this.logger.log("info", "offer-move.component.ts", "selectProductFromVideoLinkRequest", JSON.stringify(this.offerVariables.videoLink));
        this.logger.startTime();
        let errorResolved = false;
        this.productService.getOffersFromLink(this.offerVariables.videoLink.offerDataLinkURL)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer-move.component.ts", "selectProductFromVideoLinkResponse", JSON.stringify(error));
                this.logger.log("error", "offer-move.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "Submit task - Offer ", "offer.component.ts", "Get Offers - Offer Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "offer-move.component.ts", "selectProductFromVideoLinkResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "offer-move.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                payload = {
                    offers: data.retrievalTypes[0].offers
                };
                this.offerVariables.offerResponse = Object.assign({}, this.offerVariables.offerResponse, {
                    payload: payload
                });
                data.offers = this.offerHelperService.sortSpeeds(data.retrievalTypes[0].offers);
                this.offerVariables.videorOffer = this.offerHelperService.getOfferByCategory(this.offerVariables.videoSelected, data, this.offerVariables.internetCheck, this.offerVariables.phoneSelected).categorys;
                if (this.offerVariables.internetCheck && this.offerVariables.internerOffer.length === 0) {
                    this.offerVariables.errorMsg = 'Catalogs are coming as empty';
                }
                else if (this.offerVariables.videorOffer.length === 0) {
                    this.offerVariables.errorMsg = 'Catalogs are coming as empty';
                }
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
                if (this.offerVariables.videoSelected !== 'NoTV') {
                    this.offerHelperService.createSlot(this.offerVariables);
                }
            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "selectProductFromVideoLinkResponse", error);
                    this.logger.log("error", "offer-move.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
                if (error === undefined || error === null)
                    return;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.offerVariables.apiResponseError = JSON.parse(error);
                    if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                        this.offerVariables.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Page", this.offerVariables.apiResponseError);
                    } else unexpectedError = true;
                } else unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Page", lAPIErrorLists);
                }
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
            });
        return payload;
    }

    private onlyPOTSOffers(payload) {
        this.offerVariables.phoneLink = this.offerHelperService.getOfferLink(this.offerVariables.phoneSelected, this.offerVariables.initialOfferResponse.payload.offers);
        this.offerVariables.loading = true;
        this.logger.log("info", "offer-move.component.ts", "selectProductFromDHPLinkRequest", JSON.stringify(this.offerVariables.phoneLink));
        this.logger.startTime();
        this.productService.getOffersFromLink(this.offerVariables.phoneLink.offerDataLinkURL)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer-move.component.ts", "selectProductOffersLinkResponse", JSON.stringify(error));
                this.logger.log("error", "offer-move.component.ts", "selectProductOffersLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Get Only POTS Offers - Offers Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "offer-move.component.ts", "selectProductFromDHPLinkResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "offer-move.component.ts", "selectProductFromDHPLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    if (this.offerVariables.phoneSelected === 'HMP') {
                        if (!data || !data.retrievalTypes || !data.retrievalTypes[0] || !data.retrievalTypes[0].offers
                            || !data.retrievalTypes[0].offers[0] || !data.retrievalTypes[0].offers[0].catalogs[0]
                            || data.retrievalTypes[0].offers[0].catalogs[0].catalogItems === null
                            || data.retrievalTypes[0].offers[0].catalogs[0].catalogItems === undefined
                            || data.retrievalTypes[0].offers[0].catalogs[0].catalogItems.length === 0) {
                            this.offerVariables.errorMsg = 'POTS Catalog coming as null';
                        }
                    }
                    this.offerVariables.phoneCatalogId = data.retrievalTypes[0].offers[0].catalogs[0].catalogId;
                    this.offerVariables.hsiCatalogId = this.offerVariables.phoneCatalogId;
                    payload = {
                        offers: data.retrievalTypes[0].offers
                    };
                    data.offers = this.offerHelperService.sortSpeeds(data.retrievalTypes[0].offers);
                    this.offerVariables.phoneOfferData = this.offerHelperService.getOfferByCategory(this.offerVariables.phoneSelected, data, this.offerVariables.internetCheck, this.offerVariables.phoneSelected).categorys;
                    if (this.offerVariables.phoneOfferData.length === 0) {
                        this.offerVariables.loading = false;
                        this.offerVariables.retrieveOffersLoading = false;
                    }
                    if (this.offerVariables.videoOffer) this.retrieveVideoOffer(payload);
                    if (!this.offerVariables.videoOffer) this.offerHelperService.createSlot(this.offerVariables);
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "selectProductOffersLinkResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-move.component.ts", "selectProductOffersLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.offerVariables.retrieveOffersLoading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.offerVariables.apiResponseError = JSON.parse(error);
                        if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                            this.offerVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Page", this.offerVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Page", lAPIErrorLists);
                    }
                });
    }

    public getDATAoffers(payload: PayloadProduct) {
        this.offerVariables.loading = true;
        this.logger.log("info", "offer-move.component.ts", "selectProductFromDataLinkRequest", JSON.stringify(this.offerVariables.dataLink));
        this.logger.startTime();
        this.productService.getOffersFromLink(this.offerVariables.dataLink.offerDataLinkURL)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer-move.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(error));
                this.logger.log("error", "offer-move.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Get Data Offers - Offers Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "offer-move.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "offer-move.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    payload = {
                        offers: data.retrievalTypes[0].offers
                    };
                    data.offers = this.offerHelperService.sortSpeeds(data.retrievalTypes[0].offers);
                    data.offers && data.offers.map((offer) => {
                        offer && offer.catalogs && offer.catalogs.map((catalog) => {
                            if (catalog && catalog.catalogName) {
                                this.store.dispatch({ type: 'MOVE_FLOW_DATA_CATALOG_NAME', payload: catalog.catalogName })
                            }
                        });
                    });
                    this.offerVariables.offerResponse = Object.assign({}, this.offerVariables.offerResponse, { payload: payload });
                    this.offerVariables.internerOffer = this.offerHelperService.filterCategory(data.retrievalTypes[0].offers, GenericValues.sData).catalogs[0].catalogItems;
                    let primaryProdduct = this.offerHelperService.searchforPrimary(this.offerVariables.internerOffer[0].productOffer.productComponents, GenericValues.cPrimary)
                    this.store.dispatch({ type: 'CART_MAX_SPEED', payload: primaryProdduct });
                    if (this.offerVariables.videoSelected === 'NoTV' && this.offerVariables.phoneSelected === GenericValues.noPhone) {
                        this.offerHelperService.createSlot(this.offerVariables);
                    }
                    if (this.offerVariables.phoneOffer) this.onlyPOTSOffers(payload);
                    else if (this.offerVariables.videoSelected !== 'NoTV') this.retrieveVideoOffer(payload);
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-move.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.offerVariables.retrieveOffersLoading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.offerVariables.apiResponseError = JSON.parse(error);
                        if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                            this.offerVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Page", this.offerVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", this.offerVariables.taskName, "Offer Page", lAPIErrorLists);
                    }
                });
    }

    public retainData() {
        if ((this.offerVariables.isReEntrant || this.offerVariables.reentrantUI) && !this.retainLoaded) {
            this.offerVariables.selectedInstallation = undefined;
            this.offerVariables.selectedModem = undefined;
            this.offerVariables.selectedEase = undefined;
            this.offerVariables.selectedSecureWifi = undefined;
            this.offerVariables.installError = false;
            this.offerVariables.modemError = false;
            this.offerVariables.easeError = false;
            this.offerVariables.secureWifiError = false;
            this.offerVariables.jackError = false;
            let custObj = this.offerHelperService.findCustomerOrderObject(this.offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
            if (custObj && custObj.customerOrderSubItems) {
                let custSubObj: CustomerOrderSubItem = this.offerHelperService.findCustomerSubOrderObjectForRetain(custObj, 'TECH INSTALL');
                if (custSubObj !== undefined) {
                    this.offerVariables.selectedInstallation = custSubObj;
                }
                if (this.offerVariables.installationValues && this.offerVariables.installationValues.isMandatory && !this.offerVariables.selectedInstallation && !custSubObj) {
                    this.offerVariables.installError = true;
                }
                custSubObj = this.offerHelperService.findCustomerSubOrderObjectForRetain(custObj, 'MODEM');
                if (custSubObj !== undefined) {
                    this.offerVariables.selectedModem = custSubObj;
                }
                if (this.offerVariables.modemValues && this.offerVariables.modemValues.isMandatory && !this.offerVariables.selectedModem) {
                    this.offerVariables.modemError = true;
                }
                custSubObj = this.offerHelperService.findCustomerSubOrderObjectForRetain(custObj, 'CENTURYLINK @ EASE');
                if (custSubObj !== undefined) {
                    this.offerVariables.selectedEase = custSubObj;
                }
                if (this.offerVariables.easeValues && this.offerVariables.easeValues.isMandatory && !this.offerVariables.selectedEase) {
                    this.offerVariables.easeError = true;
                }
                this.offerVariables.canDisplayCS = this.offerHelperService.displayCS(this.offerVariables, this.offerVariables.selectedModem);
                this.offerHelperService.modemDisplayNameForCart(this.offerVariables.selectedModem, this.offerVariables.modemValues);
                if (this.offerVariables.canDisplayCS) {
                    custSubObj = this.offerHelperService.findCustomerSubOrderObjectForRetain(custObj, GenericValues.secureWifiComponent);
                    if (custSubObj !== undefined) {
                        this.offerVariables.selectedSecureWifi = custSubObj;
                    }
                    if (this.offerVariables.secureWifiValues && !this.offerVariables.selectedSecureWifi) {
                        if (this.offerVariables.selectedModem && this.offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() === 'purchase') {
                            this.offerHelperService.selectNotNeeded(this.offerVariables, this.offerVariables.secureWifiValues);
                        }
                    }
                }
                if (this.offerVariables.secureWifiValues && this.offerVariables.secureWifiValues.isMandatory && !this.offerVariables.selectedSecureWifi) {
                    if (this.offerVariables.selectedModem && this.offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() === 'purchase') {
                        this.offerVariables.secureWifiError = true;
                    }
                }
                if (!this.offerVariables.phoneOffer || (this.offerVariables.phoneOffer && this.offerVariables.phoneSelected !== 'HMP')) {
                    custSubObj = this.offerHelperService.findCustomerSubOrderObjectForRetain(custObj, 'Jack and Wire');
                    if (custSubObj !== undefined) {
                        this.offerVariables.selectedJack = custSubObj;
                    }
                    if (this.offerVariables.isReEntrant && this.offerVariables.selectedJack === undefined) {
                        this.offerVariables.JacksWireDefault = 'No work is needed';
                    }
                    if (this.offerVariables.jackValues && this.offerVariables.jackValues.isMandatory && !this.offerVariables.selectedJack) {
                        this.offerVariables.jackError = true;
                    }
                }
            }
            let reEntrantOfferVariable: OfferVariables = this.ctlHelperService.getLocalStorage(RE_ENTRANT_OFFERVARIABLE);
            if (reEntrantOfferVariable && reEntrantOfferVariable !== undefined) {
                this.offerVariables.isExtendedAreaCallingPresent = reEntrantOfferVariable.isExtendedAreaCallingPresent;
                this.offerVariables.isOffer1PtyResLineSelected = reEntrantOfferVariable.isOffer1PtyResLineSelected;
                this.offerVariables.isExtendedAreaCallingYESSelected = reEntrantOfferVariable.isExtendedAreaCallingYESSelected;
                this.offerVariables.isExtendedAreaCallingNASelected = reEntrantOfferVariable.isExtendedAreaCallingNASelected;
                this.offerVariables.selectedExtendedAreaCalling = reEntrantOfferVariable.selectedExtendedAreaCalling;
                this.offerVariables.extendedAreaCallingPrice = reEntrantOfferVariable.extendedAreaCallingPrice;
            }
            this.retainLoaded = true;
        }
    }
    private retainLoaded = false;

    public findCustomerSubOrderObject(custObj: CustomerOrderItems, filterBy): Products {
        let val: Products;
        let prod: Products[] = [];
        if (custObj !== undefined && custObj.existingServiceSubItems !== undefined) {
            prod = custObj.existingServiceSubItems;
        } else if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
            prod = custObj.customerOrderSubItems;
        }
        prod && prod.map(obj => {
            if (obj && obj.productName === filterBy) {
                let values: AttributesCombination[] = [];
                let flag: boolean = false;
                obj.productAttributes && obj.productAttributes.map(attr => {
                    if (!flag) {
                        flag = true;
                        values.push(attr);
                    }
                })
                obj = Object.assign({}, obj, { productAttributes: values });
                val = obj;
            }
        });
        return val;
    }

    public getPhoneData(data) {
        let flag: boolean = false;
        let isRemoved = false;
        data.map((item) => {
            if (item !== undefined && item.offerCategory !== undefined) {
                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                    this.offerVariables.hsiExisting = true;
                }
                if (item.action !== 'REMOVE' && item.offerCategory === GenericValues.cDHP && item.offerType !== 'SUBOFFER') {
                    flag = true;
                    this.offerVariables.e911ValidatedAddress = this.e911Retained;
                    this.offerVariables.isE911Called = true;
                    this.offerVariables.newPhoneSelected = 'DHP';
                    this.offerVariables.newPhoneUpdated = true;
                } else if (item.action !== 'REMOVE' && item.offerCategory === GenericValues.cHP && item.offerType !== 'SUBOFFER'
                    && item.offerType !== 'VAS_INTERCEPT') {
                    flag = true;
                    this.offerVariables.newPhoneSelected = 'HMP';
                    this.offerVariables.newPhoneUpdated = true;
                    this.offerVariables.selectedHP = item.productOfferingId;
                    this.offerVariables.selectedPhoneOfferdId = item.productOfferingId;
                    this.offerVariables.hpOfferType = item.offerType;
                    if (this.offerVariables.voiceMailValue !== 'Yes') this.offerVariables.voiceMailValue = 'No';
                    if (this.offerVariables.wireMaintainanceValue !== 'Yes') this.offerVariables.wireMaintainanceValue = 'No';
                }
                if (item.action === 'REMOVE') {
                    flag = true;
                    isRemoved = true;
                    this.offerVariables.removedProductItem.push(item);
                    this.setRemovedStatus(item.offerCategory);
                }
                if (item.offerCategory === GenericValues.cDTV) {
                    flag = true;
                    this.offerVariables.dtvExisting = true;
                    this.offerVariables.newVideoSelected = 'DTV';
                    this.offerVariables.videoSelected = 'DTV';
                }
            }
        });
        if (isRemoved) {
            this.offerVariables.removeResponse && this.offerVariables.removeResponse.map(rsn => {
                if (rsn.rsnCode === 'MRNA') {
                    this.offerVariables.removeSelectedReason = rsn;
                }
            });
        }
    }

    public setRemovedStatus(category) {
        if (category === GenericValues.cHP) {
            this.offerVariables.isHPRemoved = true;
        } else if (category === GenericValues.cDHP) {
            this.offerVariables.isDHPRemoved = true;
            this.offerVariables.onlyDHPRemoved = true;
            this.offerVariables.e911ValidatedAddress = this.e911Retained;
        } else if (category === GenericValues.cDTV) {
            this.offerVariables.isOptedOut = true;
            this.offerVariables.videoOffer = false;
            this.offerVariables.videoSelected = 'NoTV';
            this.offerVariables.optedOutCheck = true;
        } else if (category === GenericValues.iData) {
            this.offerVariables.isInternetRemoved = true;
            this.offerVariables.internetCheck = false;
        }
    }

    /**
     * Populate default component value in dropdowns
     * @param defaultVal
     * @param addons
     */
    public potsPortingMandatory: boolean = false;
    public e911MethodCalled(payload: Payload, orderItemstoSend: CustomerOrderItems[]) {
        let e911 = {
            "streetDirectionPrefix": this.offerVariables.e911ValidatedAddress.streetDirectionPrefix,
            "streetAddress": this.offerVariables.e911ValidatedAddress.streetAddress,
            "location": this.offerVariables.e911ValidatedAddress.location,
            "streetNrFirst": this.offerVariables.e911ValidatedAddress.streetNrFirst,
            "city": this.offerVariables.e911ValidatedAddress.city,
            "stateOrProvince": this.offerVariables.e911ValidatedAddress.stateOrProvince,
            "postCode": this.offerVariables.e911ValidatedAddress.postCode,
            "postCodeSuffix": this.offerVariables.e911ValidatedAddress.postCodeSuffix
        };
        payload = {
            dhpAdditionalInfo: {
                e911Address: e911,
                dhpDisclaimerAcceptDateTime: this.offerVariables.e911ValidatedAddress.acceptedData
            },
            cart: {
                catalogSpecId: this.offerVariables.catalogSpecId,
                customerOrderItems: orderItemstoSend
            },
            productConfiguration: this.offerVariables.configSelected
        };
        this.offerVariables.cartObject = {
            success: this.offerVariables.offerResponse.success,
            orderRefNumber: this.offerVariables.offerResponse.orderRefNumber,
            processInstanceId: this.offerVariables.offerResponse.processInstanceId,
            taskId: this.offerVariables.offerResponse.taskId,
            taskName: this.offerVariables.offerResponse.taskName,
            payload: payload
        };
        return payload;
    }

    public serviceTerminate() {
        for (let i = 0; i < this.offerVariables.removedProductItem.length; i++) {
            if (this.offerVariables.removedProductItem[i] && this.offerVariables.removedProductItem[i].existingServiceSubItems && this.offerVariables.removedProductItem[i].existingServiceSubItems &&
                this.offerVariables.removedProductItem[i].existingServiceSubItems.length > 0) {
                let addRemoveToAllSubItems = this.offerVariables.removedProductItem[i].existingServiceSubItems.map(item => {
                    item.action = 'REMOVE';
                    return item;
                });
                this.offerVariables.removedProductItem[i].existingServiceSubItems = addRemoveToAllSubItems;
                this.offerVariables.removedProductItem[i].customerOrderSubItems = this.offerVariables.removedProductItem[i].existingServiceSubItems;
                delete this.offerVariables.removedProductItem[i].existingServiceSubItems;
            }
            else if (this.offerVariables.removedProductItem[i] && this.offerVariables.removedProductItem[i].customerOrderSubItems && this.offerVariables.removedProductItem[i].customerOrderSubItems.length > 0) {
                let addRemoveToAllSubItems = this.offerVariables.removedProductItem[i].customerOrderSubItems.map(item => {
                    item.action = 'REMOVE';
                    return item;
                });
                this.offerVariables.removedProductItem[i].customerOrderSubItems = addRemoveToAllSubItems;
            }
        }
        if (this.offerVariables.removedProductItem && this.offerVariables.removedProductItem.length > 0) {
            this.offerVariables.serviceTerminationInfo = [{
                "offerCategory": this.offerVariables.removedProductItem[0].offerCategory,
                "etfInfo": {
                    "terminationFee": "0",
                    "currencyCode": "USD",
                    "contractExpiryDate": null
                },
                "reasonType": this.offerVariables.removeSelectedReason.rsnType,
                "reasonText": null,
                "reasonList": [{
                    "code": this.offerVariables.removeSelectedReason.rsnCode,
                    "description": this.offerVariables.removeSelectedReason.chgDesc,
                    "waiverFlag": "No"
                }]
            }]
        }
    }

    public checkPrimary(product: Products) {
        let action = 'CHANGE';
        for (let n = 0; n < this.offerVariables.existingServices.length; n++) {
            let cust = this.offerVariables.existingServices[n];
            if (cust && cust.existingServiceSubItems && cust.offerCategory === GenericValues.cHP &&
                cust.offerType !== 'SUBOFFER') {
                for (let k = 0; k < cust.existingServiceSubItems.length; k++) {
                    let subs = cust.existingServiceSubItems[k];
                    if (subs.componentType === GenericValues.cPrimary && subs.productId === product.productId) {
                        action = 'NOCHANGE';
                    }
                }
            }
        }
        return action
    }
/*
  public onChangeSecureWifi(attrVal: string, isMandatory: boolean) {
        this.offerVariables.secureWifiDefault = false;
        let price = attrVal === 'na' ? this.offerVariables.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(this.offerVariables.secureWifiValues, attrVal, '');
        this.offerVariables.selectedSecureWifi = this.offerHelperService.searchForDefault(this.offerVariables,false, this.offerVariables.secureWifiValues, price);
        if (attrVal === 'na') {
            isMandatory ? this.offerVariables.secureWifiError = true : this.offerVariables.secureWifiError = false;
            this.offerVariables.selectedSecureWifi = undefined;
        } else {
            this.offerVariables.undoFlag = true;
            this.offerVariables.secureWifiError = false;
        }
        this.offerHelperService.shoppingCartRequest(this.offerVariables);
    }*/

    public onChangeJack(attrVal: string, isMandatory: boolean) {
        this.offerVariables.JacksWireDefault = false;
        let price = attrVal === 'na' ? this.offerVariables.noPrice : this.offerHelperService.getPriceDetailsByAttrVal(this.offerVariables.jackValues, attrVal, '');
        this.offerVariables.selectedJack = this.offerHelperService.searchForDefault(this.offerVariables,false, this.offerVariables.jackValues, price);
        if (attrVal === 'na') {
            this.offerVariables.jackError = false;
            this.offerVariables.selectedJack = undefined;
        } else {
            this.offerVariables.undoFlag = true;
            this.offerVariables.jackError = false;
        }
        this.offerHelperService.shoppingCartRequest(this.offerVariables);
    }

    public showWithHSI(items: ProductOfferings): boolean {
        let flag: boolean = false;
        if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
            items.productOffer.offerAttributes.forEach(attr => {
                if (this.offerVariables.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'yes') {
                    items.productOffer.offerAttributes.forEach(checkAttr => {
                        if (this.offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
                            flag = true;
                        }
                    })
                } else if (!this.offerVariables.internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'no') {
                    items.productOffer.offerAttributes.forEach(checkAttr => {
                        if (this.offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
                            flag = true;
                        }
                    })
                }
            })
        }
        return flag;
    }

    public getRemoveResponse() {
        this.offerVariables.loading = true;
        this.logger.log("info", "offer-move.component.ts", "getRemoveResponseDataRequest", JSON.stringify(""));
        this.logger.startTime();
        this.offerHelperService.getRemoveResponseData()
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer-move.component.ts", "getRemoveResponseDataResponse", JSON.stringify(error));
                this.logger.log("error", "offer-move.component.ts", "getRemoveResponseDataSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.offerVariables.loading = false;
                this.offerVariables.retrieveOffersLoading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Disconnect Remove Response - Offers Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "offer-move.component.ts", "getRemoveResponseDataResponse", JSON.stringify(respData));
                    this.logger.log("info", "offer-move.component.ts", "getRemoveResponseDataSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    if(respData && respData.bmReasonCodes) this.offerVariables.removeResponse = respData.bmReasonCodes;
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "getRemoveResponseDataResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-move.component.ts", "getRemoveResponseDataSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    this.offerVariables.retrieveOffersLoading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.offerVariables.apiResponseError = JSON.parse(error);
                        if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                            this.offerVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.component.ts", "Offers Page", this.offerVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.component.ts", "Offers Page", lAPIErrorLists);
                    }
                });
    }
/*
    public removeExistingProduct(removed: any) {
        this.offerVariables.undoFlag = true;
        this.offerVariables.removeSelectedReason = removed.removeReason;
        if (removed.type === 'removeInternetNotLast') {
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.sData ||
                    item.offerCategory === GenericValues.iData) {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory && this.offerVariables.existingServices[i].existingServiceSubItems &&
                            this.offerVariables.existingServices[i].existingServiceSubItems.length > 0) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.existingServices[i].catalogId === null ? this.offerVariables.hsiCatalogId : this.offerVariables.existingServices[i].catalogId
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    this.offerVariables.isInternetRemoved = true;
                    this.offerVariables.internetCheck = false;
                    this.offerHelperService.retrieveOffers(this.offerVariables, false);
                }
            });
        }
        if (removed.type === 'optOut') {
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.cDTV) {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory && this.offerVariables.existingServices[i].existingServiceSubItems &&
                            this.offerVariables.existingServices[i].existingServiceSubItems.length > 0) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.existingServices[i].catalogId === null ? this.offerVariables.hsiCatalogId : this.offerVariables.existingServices[i].catalogId
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    this.offerVariables.isOptedOut = true;
                    this.offerVariables.videoOffer = false;
                    this.offerVariables.videoSelected = 'NoTV';
                    this.offerVariables.newVideoSelected = 'NoTV';
                    this.offerVariables.optedOutCheck = true;
                    this.offerHelperService.retrieveOffers(this.offerVariables, false);
                }
            });
        }
        if (removed.type === 'removePrism') {
            //iterate over cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === 'VIDEO-PRISM') {
                    item.action = 'REMOVE';
                    this.offerVariables.removedProductItem.push(item);
                    this.offerVariables.isRemoved = true;
                    this.offerVariables.videoOffer = false;
                    this.offerVariables.videoSelected = 'NoTV';
                    this.offerVariables.newVideoSelected = 'NoTV';
                    if (this.offerVariables.dataLink === undefined && this.offerVariables.preserveHSI !== undefined) {
                        this.offerVariables.dataLink = this.offerVariables.preserveHSI;
                    }
                    this.offerHelperService.retrieveOffers(this.offerVariables, false);
                }
            });
        }
        if (removed.type === 'removeDhp' || removed.type === 'removeHp') {
            //iterate over cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory && this.offerVariables.existingServices[i].existingServiceSubItems &&
                            this.offerVariables.existingServices[i].existingServiceSubItems.length > 0) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.existingServices[i].catalogId === null ? this.offerVariables.hsiCatalogId : this.offerVariables.existingServices[i].catalogId;
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    let is911 = false;
                    removed.type === 'removeDhp' ? this.offerVariables.isDHPRemoved = true : this.offerVariables.isHPRemoved = true;
                    if (this.offerVariables.newPhoneSelected === 'DHP' && !this.offerVariables.dhpExisting) {
                        this.e911Validation.open();
                        is911 = true;
                    } else if ((this.offerVariables.newPhoneSelected === 'HMP' && removed.type === 'removeHp') ||
                        (this.offerVariables.newPhoneSelected === 'DHP' && removed.type === 'removeDhp')) {
                        this.offerVariables.phoneOffer = false;
                        this.offerVariables.newPhoneSelected = GenericValues.noPhone;
                    }
                    !is911 ? this.offerHelperService.retrieveOffers(this.offerVariables, false) : '';
                    if (item.offerCategory === 'VOICE-DHP') {
                        this.offerVariables.onlyDHPRemoved = true;
                    }
                }
            });
        }
        if (removed.type === 'removeInternet' || (removed.type === 'removeLastInternet' && removed.subType === 'Remove Internet and Add Home Phone')) {
            //iterate over cartObject
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                    for (let i = 0; i < this.offerVariables.existingServices.length; i++) {
                        if (this.offerVariables.existingServices[i].offerCategory === item.offerCategory && this.offerVariables.existingServices[i].existingServiceSubItems &&
                            this.offerVariables.existingServices[i].existingServiceSubItems.length > 0) {
                            this.offerVariables.existingServices[i].action = 'REMOVE';
                            this.offerVariables.existingServices[i].catalogId = this.offerVariables.existingServices[i].catalogId === null ? this.offerVariables.hsiCatalogId : this.offerVariables.existingServices[i].catalogId;
                            this.offerVariables.removedProductItem.push(this.offerVariables.existingServices[i]);
                        }
                    }
                    item.action = 'REMOVE';
                    this.offerVariables.isInternetRemoved = true;
                    this.offerVariables.newInternetCheck = false;
                    this.offerVariables.newPhoneSelected = 'HMP';
                    this.offerHelperService.retrieveOffers(this.offerVariables, false);
                }
            });
        }
        if (removed.type === 'removeLastInternet' && removed.subType === 'Remove Internet and Close') {
            this.offerVariables.cartObject.payload.cart.customerOrderItems.map(item => {
                if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
                    this.offerVariables.removedProductItem.push(item);
                }
            });
            let services = [{
                "offerCategory": this.offerVariables.removedProductItem[0].offerCategory,
                "reasonType": this.offerVariables.removeSelectedReason.rsnType,
                "reasonText": null,
                "reasonList": [{
                    "code": this.offerVariables.removeSelectedReason.rsnCode,
                    "description": this.offerVariables.removeSelectedReason.chgDesc,
                    "waiverFlag": "No"
                }],
                "etfInfo": {
                    "terminationFee": "0",
                    "currencyCode": "USD",
                    "contractExpiryDate": null
                }
            }];
            let apiRequest = {
                orderRefNumber: this.offerVariables.orderRefNumber,
                processInstanceId: this.offerVariables.processInstanceId,
                taskId: this.offerVariables.taskId,
                taskName: 'Select Disconnect Reason',
                payload: {
                    disconnectInfo: services
                }
            }
            this.offerVariables.loading = true;
            this.logger.log("info", "offer-move.component.ts", "disconnectSubmitInfoServcRequest", JSON.stringify(apiRequest));
            this.logger.startTime();
            this.disconnectServiceCall.submitInformation(apiRequest)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer-move.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(error));
                    this.logger.log("error", "offer-move.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.offerVariables.loading = false;
                    return Observable.throw(this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Disconnect call - Offers Page", error));
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "offer-move.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(data));
                        this.logger.log("info", "offer-move.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.offerVariables.loading = false;
                        this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                        this.router.navigate(['/disconnect-schedule']);
                    },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "offer-move.component.ts", "disconnectSubmitInfoServcResponse", JSON.stringify(error));
                        this.logger.log("error", "offer-move.component.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.offerVariables.loading = false;
                        if (error === undefined || error === null)
                            return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.offerVariables.apiResponseError = JSON.parse(error);
                            if (this.offerVariables.apiResponseError !== undefined && this.offerVariables.apiResponseError !== null && this.offerVariables.apiResponseError.errorResponse &&
                                this.offerVariables.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Pending Summary", "offer.component.ts", "Offers Page", this.offerVariables.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.offerVariables.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Pending Summary", "offer.component.ts", "Offers Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    });
        }
    }
*/
    public undoAll() {
        this.offerVariables.loading = true;
        let cart = <Observable<any>>this.store.select('cart');
        let cartSubscription = cart.subscribe((data) => {
            if (data && data.taskId) {
                this.offerVariables.taskId = data.taskId;
            }
        })
        if (cartSubscription !== undefined) {
            cartSubscription.unsubscribe();
        }
        this.initializeAll('true');
        this.ngOnInit();
        this.offerVariables.undoFlag = false;
        this.offerVariables.loading = false;
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
        if (this.pendingSubscription !== undefined) this.pendingSubscription.unsubscribe();
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
    }
}