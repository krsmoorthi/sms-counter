import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferMoveComponent } from './offer-move.component';
import { MockServer } from 'app/MockServer.test';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TooltipModule } from 'ngx-bootstrap';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs';
import { Logger } from 'app/common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { ProductService } from 'app/common/service/product.service';
import { MockLogger, MockProductService, MockAppStateService, MockSystemErrorService, MockDisconnectService, MockBlueMarbleService, MockAddressService, MockHelperService, MockOfferHelperService, MockPendingOrderService, MockCountryStateService, MockDirectvService, MockPropertiesHelperService, MockReviewOrderService, MockAccountService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { AddressService } from 'app/common/service/address.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import "rxjs/add/observable/of";
import { AccountService } from 'app/common/service/account.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DirectvService } from 'app/common/service/directv.services';
import { CountryStateService } from 'app/common/service/country-state.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';

describe('OfferMoveComponent', () => {
  let component: OfferMoveComponent;
  let fixture: ComponentFixture<OfferMoveComponent>;
  const mockServer = new MockServer();
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    SharedCommonModule,
    TooltipModule.forRoot(),
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }

  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const productService = { provide: ProductService, useClass: MockProductService };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const ctlHelperService = CTLHelperService;
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const offerHelperService = { provide: OfferHelperService, useClass: MockOfferHelperService };

  //Dialog component provides
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const directvService = {provide: DirectvService, useClass: MockDirectvService};
  const propertiesHelperService = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  const reviewOrderService = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  const accountService = {provide: AccountService, useClass: MockAccountService};

  const providers = [
    logger, store, productService, appStateService, 
    systemErrorService, disconnectService, blueMarbleService,
    addressService, ctlHelperService, helperService, offerHelperService,
    pendingOrderService, countryStateService, directvService, propertiesHelperService, 
    reviewOrderService, accountService
  ]

  describe('HSI Standalone', () => {
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ OfferMoveComponent ],
        providers: providers
      })
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(OfferMoveComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('POTS Standalone', () => {
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_POTS_TILL_REVIEW_ORDER")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
    const store = { provide: Store, useValue: mockRedux };
    const _providers = [...providers, store]

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ OfferMoveComponent ],
        providers: _providers
      })
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(OfferMoveComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('HSI and POTS', () => {
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
    const store = { provide: Store, useValue: mockRedux };
    const _providers = [...providers, store]

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ OfferMoveComponent ],
        providers: _providers
      })
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(OfferMoveComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });
});
