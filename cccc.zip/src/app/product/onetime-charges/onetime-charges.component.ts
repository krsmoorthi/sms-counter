import { AppStore } from './../../common/models/appstore.model';
import { Store } from '@ngrx/store';
import { Products } from './../../common/models/product.model';
import { CustomerOrderItems } from './../../common/models/cart.model';
// tslint:disable-next-line:no-unused-variable
import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { AppStateService } from './../../common/service/app-state.service';
import { GenericValues } from '../../common/models/common.model';
import { Subscription } from 'rxjs';
import { AppConstant } from 'app/app.constant';
import { Logger } from '../../common/logging/default-log.service';

@Component({
    selector: 'one-time-charges',
    templateUrl: './onetime-charges.component.html',
    styleUrls: ['./onetime-charges.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class OneTimeChargesComponent implements OnInit, OnChanges {
    public isVacSus: boolean = false;
    public nonPubNoChargeSelected: boolean = false;
    public nonPubNoChargeRemoved: boolean = false;
    public selectedListingValue: any;
    public customizeSubscription: Subscription;
    @Input() public firstIsOpen: boolean = true;
    @Input() public addOnOfferData;
    @Input() public DisableVoiceMail;
    @Input() public priceKeyName: string = 'discountedOtc';
    @Output() public onDataChange = new EventEmitter();
    @Input() public isMACD;
    @Input() public hpExisting;
    @Input() public undoQty;
    @Input() public compatibility;
    @Input() public potsOfferType;
    @Input() public internetActive;
    @Input() public selectedObjectsList = [];
    public refObj = [];
    @Output() public prodRequired = new EventEmitter();
    @Output() public hideCalldetail = new EventEmitter();
    public phonePlan: boolean;
    public isReEntrant: boolean = false;
    public addonObj: CustomerOrderItems[] = [];
    public pType: string[] = [];
    private repeat: boolean = false;
    public selectedProducs: string[] = [];
    public indexId = 0;
    public indxCounter = 0;
    public selectedProductName: string;
    private vacationObservable;
    public isVacRestore : Observable<any>;
    public nonpubSelectedVal: any;
    public isVacRes : boolean = false;
    public productExist: boolean = false;
    public prodGroup = new Map<string, string[]>();
    public prodArr: string[] = [];
    public groupMap = new Map<string, string[]>();
    public productArray: string[] = [];
    public prodMap = new Map<string, string[]>();
    public incompatibleRollOverDescription: string;
    @Input() public isAmend : boolean;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    @Input() private isChange: boolean;
    @Input() private existingCart: CustomerOrderItems[];
    @Input() public newHSI;
    @Input() public newPOTS;
    public selectedIndexArray: any = [];
    public techdevselectedVal: any;
    public isPrepaid: boolean = false;

    @Input() set cartData(cart: CustomerOrderItems[]) {
        this.addonObj = cart;
        let userStore = <Observable<any>>this.store.select('user');
        let usrSubscription = userStore.subscribe((data) => {
            this.isReEntrant = data.reEntrant;
            if (data.previousUrl !== '/product-offer' && data.previousUrl !== '/move-product' && data.previousUrl !== '/offer-change'
                && data.previousUrl !== '/billing-product' && data.previousUrl !== '/stack-amend-product') {
                this.isReEntrant = true;
            }
            this.isPrepaid = (data.prepaidFlag === 'PREPAID');
        });

        if (usrSubscription !== undefined) usrSubscription.unsubscribe();
        if (!this.repeat) {
            if(this.addOnOfferData) this.pType.push(this.addOnOfferData.catalogCategory);
            this.repeat = true;
            this.updateList();
        }
    }

    @Input("selectedListingOptionValue")
    set selectedListingOptionValue(listingoption: any){
        this.selectedListingValue = listingoption;  
        let customizeData = <Observable<any>>this.store.select('customize');
        customizeData.subscribe((data) => {
            this.nonpubSelectedVal = data.nonpubnochargeselectedvalue;            
        });             
        if(this.selectedListingValue && this.selectedListingValue.indexOf('Non-Pub No Charge') === -1) {
            this.updateList(true);
        } 
    }

    @Input() set hpAutoSelect(isClicked: boolean) {
        if (!isClicked) {
            this.updateList();
        }
    }

    @Input() set undo(isUndo: boolean) {
        if (isUndo) {
            this.addonObj = [];
            this.checkSelection(undefined, undefined, undefined, undefined);
        }
    }
    public ngOnChanges(changes: SimpleChanges) {
        if (changes['undoQty']) {
            if (this.undoQty !== undefined && this.undoQty) {
                for (let i = 0; i < this.refObj.length; i++) {
                    if (this.refObj && this.refObj[i] && this.refObj[i].selectedItems) {
                        for (let prodname of Object.keys(this.refObj[i].selectedItems)) {
                            delete this.refObj[i].selectedItems[prodname];
                        }
                    }
                    this.updateList();
                }
            }
        }
    }

    public updateList(flagFromListing?) {
        let voiceMessagingExist = false;
        let selectedProducts = [];
        let isNonPubExist = false;
        let isHoldNonPubExist = false;
        let curStore = this.appStateService.getState();
        if(curStore && curStore.existingProducts && curStore.existingProducts.orderFlow && curStore.existingProducts.orderFlow.flow === "Newinstall" && curStore.existingProducts.orderFlow.type === "fromHold") {
            curStore && curStore.existingProducts && curStore.existingProducts.pendingOrders && curStore.existingProducts.pendingOrders[0].orderDocument &&
            curStore.existingProducts.pendingOrders[0].orderDocument.productConfiguration.map(exConf => {
                if(exConf.productType === GenericValues.cHP && exConf.configItems) {
                    exConf.configItems.map(confItems => {
                        if (confItems.productName === 'Home Phone Directory Listing' && confItems.configDetails) {
                            confItems.configDetails.map(confDet => {
                                confDet.formItems && confDet.formItems.map(formItem => {
                                    if (formItem.attributeName === 'Listing Type' && formItem.attributeValue[0].value === 'Non-Pub No Charge') {
                                        isHoldNonPubExist = true;
                                    }
                                })
                            })
                        }
                    })
                }
            })
        }
        else if(curStore && curStore.customize && curStore.customize.payload && curStore.customize.payload.existingProductConfiguration) {
            curStore.customize.payload.existingProductConfiguration.map(exConf => {
                if(exConf.productType === GenericValues.cHP && exConf.configItems) {
                    exConf.configItems.map(confItems => {
                        if (confItems.productName === 'Home Phone Directory Listing' && confItems.configDetails) {
                            confItems.configDetails.map(confDet => {
                                confDet.formItems && confDet.formItems.map(formItem => {
                                    if (formItem.attributeName === 'Listing Type' && formItem.attributeValue[0].value === 'Non-Pub No Charge') {
                                        isNonPubExist = true;
                                    }
                                })
                            })
                        }
                    })
                }
            })
        }
        if (this.addonObj !== undefined) {
            this.addonObj.forEach(addOn => {
                if (this.addOnOfferData && (this.addOnOfferData.catalogCategory === addOn.productType)) {
                    addOn.customerOrderSubItems.forEach(subOrder => {
                        for (let k = 0; k < this.addOnOfferData.length; k++) {
                            let mainObj = this.addOnOfferData[k].productOffer;
                            let item = mainObj.productComponents;
                            this.indxCounter++;
                            let calledAddon = false;
                            if(item) {
                                for (let i = 0; i < item.length; i++) {
                                    if (item[i].product.productName === subOrder.productName || (item[i].product.productName === 'Voice Messaging')) {
                                        if (item[i].product.productName === 'Voice Messaging') {
                                            voiceMessagingExist = true;
                                        }
    
                                        if (!item[i].hasQuantity) {
                                            if ((!flagFromListing && selectedProducts.length === 0) || (flagFromListing && item[i].product.productName === 'Non-Pub No Charge')) {
                                                this.checkBoxHandlerDp(item[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                                                selectedProducts.push(item[i].product.productName);
                                                if (this.compatibility && this.compatibility.outputAttribute && this.compatibility.outputAttribute.length > 0) {
                                                    for (let j = 0; j < this.compatibility.outputAttribute.length; j++) {
                                                        let compArr = [] = this.compatibility.outputAttribute[j];
                                                        if (compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requires
                                                            && compArr[4] && compArr[10] && compArr[4].trim() === item[i].product.productName && this.addOnOfferData && this.addOnOfferData.catalogCategory === 'HP ADDON OFFER') {
                                                            selectedProducts.push(compArr[10].trim());
                                                        }
                                                    }
                                                }
                                            }
                                            if (selectedProducts && selectedProducts.length > 0 && selectedProducts[i] !== item[i].product.productName
                                                && !flagFromListing) {
                                                for (let k = 0; k < selectedProducts.length; k++) {
                                                    if (selectedProducts[k] === item[i].product.productName) {
                                                        calledAddon = true;
                                                    }
                                                }
                                                if (!calledAddon) {
                                                    this.checkBoxHandlerDp(item[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                                                    if (this.compatibility && this.compatibility.outputAttribute && this.compatibility.outputAttribute.length > 0) {
                                                        for (let j = 0; j < this.compatibility.outputAttribute.length; j++) {
                                                            let compArr = [] = this.compatibility.outputAttribute[j];
                                                            if (compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requires
                                                                && compArr[4] && compArr[10] && compArr[4].trim() === item[i].product.productName && this.addOnOfferData && this.addOnOfferData.catalogCategory === 'HP ADDON OFFER') {
                                                                selectedProducts.push(compArr[10].trim());
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else if (!flagFromListing) {
                                            this.checkBoxHandlerDp(item[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                                            this.checkboxHandlerDpQty(item[i], subOrder.quantity, mainObj.customProdName, k, this.addOnOfferData[k], true);
                                        }
                                    }
                                }
                            }
                        }
                    });
                }

            });
        }
        if ((!voiceMessagingExist || isNonPubExist) && this.addOnOfferData && !flagFromListing) {
            for (let k = 0; k < this.addOnOfferData.length; k++) {
                let mainObj = this.addOnOfferData[k].productOffer;
                let item = mainObj.productComponents;
                this.indxCounter++
                if(item) {
                    for (let i = 0; i < item.length; i++) {
                        if ((!voiceMessagingExist && item[i].product.productName === 'Voice Messaging') || (!this.isReEntrant && isNonPubExist && item[i].product.productName === 'Non-Pub No Charge')|| (isHoldNonPubExist && this.isReEntrant && item[i].product.productName === 'Non-Pub No Charge')) {
                            this.checkBoxHandlerDp(item[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                        }
                        if(!voiceMessagingExist && item[i].product.productName === "Easy Access" && this.isAmend){  
                            if(this.selectedIndexArray && this.selectedIndexArray.indexOf(k) > -1) {   // this condition is for Amend flow Easy Access is selected and  voiceMessaging is not selected 
                                this.checkBoxHandlerDp(item[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                            }
                            
                        }
                    }
                }
            }
        }
        if(!flagFromListing) {
            let retVal = curStore.retain;
            let potsBooleans = retVal.potsBooleans;

            if (potsBooleans && potsBooleans.retainValueForHSIJack === ''){
                if(this.addOnOfferData && this.addOnOfferData.catalogCategory === "DATA ADDON OFFER") {
                    for (let k = 0; k < this.addOnOfferData.length; k++) {
                        let mainObj = this.addOnOfferData[k].productOffer;
                        let item = mainObj.productComponents;
                        if(item) {
                            for (let i = 0; i < item.length; i++) {
                                if (item[i].product.productName === 'Additional Jack and Wire' && this.selectedProducs.indexOf('Additional Jack and Wire')!==-1) {
                                    this.checkBoxHandlerDp(item[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if ((!this.isReEntrant || (potsBooleans && potsBooleans.isPOTSChanged)) && !flagFromListing) {
                let data = curStore.customize;
                if (data.includingfeature) {
                    let type = "COMPONENT";
                    data.includingfeature.map((item) => {
                        let includedFlag = false;
                        if ((item && item.displayOrder !== 0 && item.componentType === type && item.isDefault !== 0 && item.additionalUiAttrProduct &&
                            item.additionalUiAttrProduct.includedFlag && item.additionalUiAttrProduct.includedFlag.toLowerCase() === 'yes')) {
                            if(this.addOnOfferData) {
                                for (let k = 0; k < this.addOnOfferData.length; k++) {
                                    let mainObj = this.addOnOfferData[k].productOffer;
                                    let mainItem = mainObj.productComponents;
                                    this.indxCounter++;
                                    for (let i = 0; i < mainItem.length; i++) {
                                        if (mainItem[i].product.productName === item.product.productDisplayName) {
                                            this.checkBoxHandlerDp(mainItem[i], mainObj.customProdName, k, this.addOnOfferData[k], true);
                                            includedFlag = true;
                                            break;
                                        }
                                    }
                                    if (includedFlag) break;
                                }
                            }
                        }
                    })
                }
                if (this.customizeSubscription !== undefined) this.customizeSubscription.unsubscribe();
            }
        }
    }

    public checkSelection(component: any, customProdName, k, catalogueItem): boolean {
        let currentStore = this.appStateService.getState();
        this.addonObj = currentStore.cart.payload.customerAddonOfferItems;
        let flag: boolean = false;
        if (this.addonObj !== undefined) {
            this.addonObj.forEach(addOn => {
                if (this.addOnOfferData && (this.addOnOfferData.catalogCategory === addOn.productType && component !== undefined
                    && component.product !== undefined && addOn)) {
                    addOn.customerOrderSubItems.forEach(subOrder => {
                        if (component.product.productName === subOrder.productName) {
                            flag = true;
                        }
                    })
                }
            })
        }
        return flag;
    }


    constructor(private logger: Logger, private store: Store<AppStore>, public appStateService: AppStateService) { }

    public ngOnInit() {
        this.logger.metrics('OneTimeChargesPage');
        this.vacationObservable = <Observable<any>>this.store.select('vacation'); 
        this.vacationObservable.subscribe((data) => {
             if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacResFlow) this.isVacRes= true;
                else this.isVacRes= false;
                if(data.vacFlowName.isVacSusFlow) this.isVacSus = true;
                else this.isVacSus = false;
            } 
        })
        let customize = <Observable<any>>this.store.select('customize');
        this.customizeSubscription = customize.subscribe((data) => {
            this.techdevselectedVal = data.techdevselected;
        });
        this.compatibility && this.compatibility.outputAttribute && this.compatibility.outputAttribute.map((a) => {
            if (a[7] !== null && a[7] === GenericValues.requiresSelectGrp) {
                if (a[11] !== null && this.prodGroup.has(a[11])) {
                    this.prodGroup.get(a[11]).push(a[10])
                } else if (a[11] !== null) {
                    this.prodArr.push(a[10]);
                    this.prodGroup.set(a[11], this.prodArr);
                }
            }
        })
    }

    public calculateTotal(refObj, isVisible) {
        let items = [];
        if (refObj && refObj.selectedItems) {
            items = refObj.selectedItems;
        }
        let total = 0;
        for (let key in items) {
            total = total + items[key];
        }
        if (refObj) {
            refObj.total = total;
            total > 0 ? refObj.visible = true : refObj.visible = false;
        }
    }

    public getPrice(attr: any, flag: boolean, qty: number): string {
        let val: string = '$0.00';
        if (attr !== null && attr !== undefined && attr.length > 0) {
            attr.map(item => {
                if (item.isPriceable) {
                    item.prices.map(price => {
                        if (price.discountedRc !== 0) {
                            val = flag ? '$' + (qty * price.discountedRc.toFixed(2)) : '$' + price.discountedRc.toFixed(2) + '/mo'
                        } else if (price.rc !== 0) {
                            val = flag ? '$' + (qty * price.rc.toFixed(2)) : '$' + price.rc.toFixed(2) + '/mo'
                        } else if (price.discountedOtc !== 0) {
                            val = flag ? '$' + (qty * price.discountedOtc).toFixed(2) : '$' + price.discountedOtc.toFixed(2)
                        } else if (price.otc !== 0) {
                            val = flag ? '$' + (qty * price.otc).toFixed(2) : '$' + price.otc.toFixed(2)
                        }
                    })
                }
            })
        }
        return val;
    }
    public resolveSelectedCount(inx) {

        let selectedItems = {};
        let flag = false;
        if (this.refObj[inx] && this.refObj[inx].selectedItems) {
            if(this.refObj[inx].selectedItems["Trip Charge Regular"]) flag = true;
            selectedItems = this.refObj[inx].selectedItems;
        }
        let count = flag ? Object.keys(selectedItems).length - 1 : Object.keys(selectedItems).length;
        let text = '';
        if (count > 0) {
            text = count + ' selected';
        }
        return text;
    }
    public toEnableProdList: string[] = [];
    public getCompatibilityRules(item , productOffer?: any): boolean {
         if(this.isAmend){
            let Sup3Disable = this.SupDisableConfig(productOffer);
            if(Sup3Disable){
                this.incompatibleRollOverDescription = AppConstant.AMEND_MESSAGE;
                return true;
            }
            
        }

        if(this.selectedProducs && this.selectedProducs.length > 0 && this.selectedProducs.indexOf(this.potsOfferType) === -1) {
            this.selectedProducs.push(this.potsOfferType);
        }
        if(this.DisableVoiceMail) {
            this.selectedProducs.push('Voice Messaging');
        }
        if(this.compatibility && this.compatibility.outputAttribute && this.compatibility.outputAttribute.length > 0) {
            let enableCategory = false;
            let enable: boolean = false;
            for(let i=this.compatibility.outputAttribute.length-1;i>=0;i--) {
                let compArr = [] = this.compatibility && this.compatibility.outputAttribute[i];
                if((this.newHSI || this.newPOTS) && (compArr[2] === 'WIRINGWORKS' || compArr[8] === 'WIRINGWORKS')) {
                    continue
                }
                if(((compArr[2] === 'ALL_VALUES' && compArr[8] === 'WIRINGWORKS') || (compArr[8] === 'ALL_VALUES' && compArr[2] === 'WIRINGWORKS'))
                && compArr[7] === GenericValues.isEnable && compArr[10] && compArr[10].trim() === item.product.productName && this.isChange
                && this.selectedProducs.indexOf(compArr[4].trim()) === -1) {
                    this.incompatibleRollOverDescription =  compArr[15];
                    return true;
                }
                if((compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY') && 
                    compArr[6] === 'NOTAVAILABLE' && compArr[3] && compArr[3].trim() === item.product.productName && compArr[17] === null) {
                    this.incompatibleRollOverDescription = compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY' ? compArr[14] : compArr[15];
                    return true;
                }
                if((((compArr[2] === 'ALL_VALUES' && compArr[8] === 'WIRINGWORKS') || (compArr[8] === 'ALL_VALUES' && compArr[2] === 'WIRINGWORKS'))
                && compArr[7] === GenericValues.incompatible && compArr[4] && compArr[4].trim() === item.product.productName) ||
                (compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.incompatible
                    && compArr[4] && compArr[4].trim() === item.product.productName) ||
                ((compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY') && compArr[17] === null && compArr[6] === GenericValues.incompatible
                && compArr[3] && compArr[3].trim() === item.product.productName)) {
                    if(this.selectedProducs && this.selectedProducs.length > 0 && (compArr[10] && this.selectedProducs.indexOf(compArr[10].trim()) !== -1 ||
                    (compArr[9] && this.selectedProducs.indexOf(compArr[9].trim()) !== -1))) {
                        this.incompatibleRollOverDescription = compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY' ? compArr[14] : compArr[15];
                        return true;
                    }
                } else if((compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.incompatible
                    && compArr[10] && compArr[10].trim() === item.product.productName) ||
                    (((compArr[2] === 'ALL_VALUES' && compArr[8] === 'WIRINGWORKS') || (compArr[8] === 'ALL_VALUES' && compArr[2] === 'WIRINGWORKS'))
                    && compArr[7] === GenericValues.incompatible && compArr[4] && compArr[4].trim() === item.product.productName) ||
                    ((compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY') && compArr[6] === GenericValues.incompatible
                    && compArr[17] === null && compArr[9] && compArr[9].trim() === item.product.productName)) {
                        if((this.selectedProducs && this.selectedProducs.length > 0 &&
                            (this.selectedProducs.indexOf(compArr[4]) !== -1 || (compArr[3] && this.selectedProducs.indexOf(compArr[3].trim()) !== -1)))
                            || (compArr[4] && compArr[4].trim() === this.potsOfferType || (this.DisableVoiceMail && compArr[4] && compArr[4].trim() === 'Voice Messaging'))) {
                                this.incompatibleRollOverDescription = compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY' ? compArr[14] : compArr[15];
                            return true;
                        }
                    }
                    else if((compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requires
                        && compArr[10] && compArr[10].trim() === item.product.productName && this.selectedProducs.indexOf(compArr[4]) !== -1)||
                        (((compArr[2] === 'ALL_VALUES' && compArr[8] === 'WIRINGWORKS') || (compArr[8] === 'ALL_VALUES' && compArr[2] === 'WIRINGWORKS'))
                        && compArr[7] === GenericValues.incompatible && compArr[4] && compArr[4].trim() === item.product.productName) ||
                        ((compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY') && compArr[6] === GenericValues.requires && compArr[17] === null
                            && compArr[9] && compArr[9].trim() === item.product.productName && this.selectedProducs.indexOf(compArr[3]) !== -1)){
                            this.incompatibleRollOverDescription = compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY' ? compArr[14] : compArr[15];
                            return true;
                    }
                    else if(compArr[2] === GenericValues.cHP && (compArr[7] === GenericValues.isEnable && compArr[10] && item.product.productName === compArr[10].trim()) ||
                    ((compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY') && compArr[17] === null &&
                    compArr[6] === GenericValues.isEnable && compArr[9] && item.product.productName === compArr[9].trim())){
                            enableCategory = true;
                                if(this.selectedProducs && this.selectedProducs.length > 0 && compArr[4] && this.selectedProducs.indexOf(compArr[4].trim()) !== -1) {
                                    if(this.toEnableProdList && (this.toEnableProdList.length === 0)){
                                        this.toEnableProdList.push(compArr[4] && compArr[4].trim());
                                    }
                                } else {
                                    if(this.toEnableProdList && this.toEnableProdList.length > 0 && this.toEnableProdList.indexOf(compArr[4] && compArr[4].trim()) !== -1) {
                                        this.toEnableProdList.splice(0,1);
                                    }
                                }
                                if(this.selectedProducs && this.selectedProducs.length > 0 && this.toEnableProdList && this.toEnableProdList.length > 0) {
                                    enable = true;
                                }
                                this.incompatibleRollOverDescription = compArr[0] === 'SWITCH_PRODUCT_ATTR_COMPATIBILITY' || compArr[0] === 'SWITCH_PRODUCT_COMPATIBILITY' ? compArr[14] : compArr[15];
                    }    
            }
            if(enableCategory && !enable){
                return true;
            }
        }
        return false;
    }
    public includeCheck(compArr: any, item: any): boolean {
        let flg = false;
        let currentStore = this.appStateService.getState();
        let customerOrderItems = currentStore.cart.payload.cart.customerOrderItems;
        for (let j = 0; j < customerOrderItems.length; j++) {
            if (customerOrderItems && customerOrderItems[j] && customerOrderItems[j].productType === GenericValues.cHP && customerOrderItems[j].offerSubType !== 'SUBOFFER') {
                customerOrderItems[j].customerOrderSubItems && customerOrderItems[j].customerOrderSubItems.map(sub => {
                    if (sub && compArr[4] && sub.productName === compArr[4].trim() && compArr[2] === GenericValues.cHP &&
                        compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.incompatible
                        && compArr[10] && compArr[10].trim() === item.product.productName) {
                        flg = true;
                    }
                });
            }
        }
        return flg;
    }
    public addRequiredfromRule(prodName, flag, indx, isSelected) {
        let exist = flag === 'add' ? false : true;
        if (this.selectedProducs && this.selectedProducs.length > 0) {
            for (let i = 0; i < this.selectedProducs.length; i++) {
                if (flag === 'add' && this.selectedProducs[i] === prodName) {
                    exist = true;
                }
                if (flag === 'remove' && this.selectedProducs[i] === prodName) {
                    exist = false;
                }
            }
        }
        if (!exist) {
            this.addOnOfferData.map(addOn => {
                if (addOn && addOn.productOffer && addOn.productOffer.productComponents &&
                    addOn.productOffer.productComponents.length > 0) {
                    let val = 0;
                    addOn.productOffer.productComponents.map(component => {
                        if (component && component.product && component.product.productName === prodName) {
                            this.checkBoxHandlerDp(component, addOn.productOffer.customProdName, indx, addOn, undefined, flag);
                        }
                        val++;
                    })
                }
            })
        }
    }

    public checkBoxHandlerDp(item, prodType, indx, catalog, isSelected?, fromRule?, fromUpdate?) {
        if(this.selectedIndexArray && !(this.selectedIndexArray.indexOf(indx) > -1)) {
            this.selectedIndexArray.push(indx);
        }
        if (fromUpdate) {
            indx = indx - 1;
        }
        let product = item.product;
        this.selectedProductName = item.product.productName;
        if (this.selectedProducs && this.selectedProducs.length > 0 && this.selectedProducs.indexOf(product.productName) !== -1 && (fromRule === 'remove' || !fromRule)) {
            this.addNremoveproducts(indx, product, fromRule, item, catalog, isSelected, prodType);
            if (this.selectedProducs && this.selectedProducs.length > 0) {
                for (let i = 0; i < this.selectedProducs.length; i++) {
                    if (this.selectedProducs[i] === product.productName) {
                        this.selectedProducs.splice(i, 1);
                        if (product.productName.replace(/\s/gi, "") === 'CenturyLinkUnlimited') {
                            this.phonePlan = false;
                            this.hideCalldetail.emit(this.phonePlan)
                        }
                    }
                }
            }
            if (this.compatibility && this.compatibility.outputAttribute && this.compatibility.outputAttribute.length > 0) {
                for (let j = 0; j < this.compatibility.outputAttribute.length; j++) {
                    let compArr = [] = this.compatibility.outputAttribute[j];
                    if (compArr[7] === GenericValues.requiresSelectGrp && compArr[10] === this.selectedProductName && this.groupMap.has(compArr[11])
                        && this.groupMap.get(compArr[11]).indexOf(this.selectedProductName) !== -1 && this.selectedProducs.indexOf(compArr[4]) !== -1) {
                        let ind = this.groupMap.get(compArr[11]).indexOf(compArr[10]);
                        this.groupMap.get(compArr[11]).splice(ind, 1);
                        if (this.groupMap.get(compArr[11]).length === 0) {
                            this.prodRequired.emit(compArr[4] + " requires " + compArr[15]);
                        }
                    } else if (compArr[7] === GenericValues.requires && this.selectedProducs.indexOf(compArr[4]) !== -1 &&
                        this.selectedProductName === compArr[10]) {
                        this.prodRequired.emit(compArr[15]);
                    }
                    if ((compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requires
                        && compArr[4] && compArr[4].trim() === product.productName) ||
                        ((compArr[2] === 'ALL_VALUES' && compArr[8] === 'WIRINGWORKS') || (compArr[8] === 'ALL_VALUES' && compArr[2] === 'WIRINGWORKS') && compArr[7] === GenericValues.requires
                        && compArr[4] && compArr[4].trim() === product.productName)) {
                        if (compArr[10] && this.prodMap.has(compArr[10].trim()) && this.prodMap.get(compArr[10].trim()) !== undefined && compArr[4] &&
                        this.prodMap.get(compArr[10].trim()).indexOf(compArr[4].trim()) !== -1) {
                            let index = this.prodMap.get(compArr[10].trim()).indexOf(compArr[4].trim());
                            this.prodMap.get(compArr[10].trim()).splice(index, 1);
                            if ((this.prodMap.get(compArr[10].trim()).length)! < 1) {
                                this.addRequiredfromRule(compArr[10].trim(), 'remove', indx, isSelected);
                            }
                        }
                    } else if ((compArr[2] === GenericValues.cHP && compArr[7] === GenericValues.isEnable && compArr[4] && compArr[10] &&
                        compArr[4].trim() === product.productName && this.selectedProducs.indexOf(compArr[10].trim()) !== -1) ||
                        ((compArr[2] === 'ALL_VALUES' && compArr[8] === 'WIRINGWORKS') || (compArr[8] === 'ALL_VALUES' && compArr[2] === 'WIRINGWORKS') &&
                        compArr[7] === GenericValues.isEnable && compArr[4] && compArr[10] &&
                            compArr[4].trim() === product.productName && this.selectedProducs.indexOf(compArr[10].trim()) !== -1)) {
                        this.addRequiredfromRule(compArr[10].trim(), 'remove', indx, isSelected);
                    } else if (compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requiresSelectGrp
                        && compArr[4] === product.productName && this.addOnOfferData && this.addOnOfferData.catalogCategory === 'HP ADDON OFFER') {
                        if (this.groupMap.has(compArr[11]) && this.groupMap.get(compArr[11]) !== undefined && (this.groupMap.get(compArr[11]).indexOf(this.selectedProductName) !== -1 ||
                            this.groupMap.get(compArr[11]).indexOf(compArr[10]) !== -1)) {
                            let ind = this.groupMap.get(compArr[11]).indexOf(compArr[10]);
                            this.groupMap.get(compArr[11]).splice(ind, 1);
                            this.addRequiredfromRule(compArr[10], 'remove', indx, isSelected);
                        }
                        this.productExist = false;
                        this.prodRequired.emit(null);

                    }
                }
            }
        } else {
            if ((this.selectedProducs && this.selectedProducs.length === 0) || (this.selectedProducs && this.selectedProducs.length > 0 && this.selectedProducs.indexOf(product.productName) === -1 && (!fromRule || fromRule === 'add'))) {
                this.addNremoveproducts(indx, product, fromRule, item, catalog, isSelected, prodType);

                this.selectedProducs.push(product.productName);
                if (this.compatibility && this.compatibility.outputAttribute && this.compatibility.outputAttribute.length > 0) {
                    for (let j = 0; j < this.compatibility.outputAttribute.length; j++) {
                        let compArr = [] = this.compatibility.outputAttribute[j];
                        if (compArr[7] === GenericValues.requiresSelectGrp && compArr[4] === this.selectedProductName) {
                            this.prodGroup.forEach((value: string[], key: string) => {
                                value.forEach((w) => {
                                    if (this.selectedProducs.indexOf(w) !== -1 && this.groupMap.size === 0) {
                                        this.productExist = true;
                                        this.groupMap.set(key, [w]);
                                    }
                                });
                            });
                        }
                        if (compArr[7] === GenericValues.requiresSelectGrp && compArr[10] === product.productName && this.groupMap.has(compArr[11])
                            && this.groupMap.get(compArr[11]).indexOf(compArr[10]) === -1) {
                            this.productArray.push(compArr[10])
                            this.groupMap.set(compArr[11], this.productArray);
                            this.prodRequired.emit(null)
                        } else if (compArr[7] === GenericValues.requires && this.selectedProducs.indexOf(compArr[4]) && this.selectedProductName === compArr[10]) {
                            this.prodRequired.emit(null)
                        }
                        if (compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requires
                            && compArr[4] && compArr[4].trim() === product.productName && compArr[10]) {
                            if (this.prodMap.has(compArr[10].trim()) && this.prodMap.get(compArr[10].trim()) !== undefined) {
                                this.prodMap.get(compArr[10].trim()).push(compArr[4].trim());
                            } else {
                                this.prodMap.set(compArr[10].trim(), [compArr[4].trim()]);
                            }
                            this.addRequiredfromRule(compArr[10].trim(), 'add', indx, isSelected);
                        }
                        if (compArr[2] === GenericValues.cHP && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.requiresSelectGrp
                            && compArr[4] && compArr[4].trim() === product.productName && this.addOnOfferData && this.addOnOfferData.catalogCategory === 'HP ADDON OFFER') {
                            if (this.groupMap.has(compArr[11]) && this.groupMap.get(compArr[11]) !== undefined && this.groupMap.get(compArr[11]).length < Number(compArr[14])
                                && this.groupMap.get(compArr[11]).length >= Number(compArr[13])) {
                                this.groupMap.get(compArr[11]).push(compArr[10]);
                                this.addRequiredfromRule(compArr[10], 'add', indx, isSelected);
                            } else if (Number(compArr[12]) === 1 && !this.productExist) {
                                this.productArray.push(compArr[10]);
                                this.groupMap.set(compArr[11], this.productArray);
                                this.addRequiredfromRule(compArr[10], 'add', indx, isSelected);
                                this.productExist = false;
                            }
                            this.prodRequired.emit(null);
                        }
                    }
                }
            }
        }
    }

    public addNremoveproducts(indx, product, fromRule, item, catalog, isSelected, prodType) {
        let index;
        if(this.addOnOfferData) index = this.checkInsertProduct(prodType, this.addOnOfferData.catalogCategory, catalog, product, isSelected, item);
        if (item.hasQuantity) {
            product.quantity.minQuantity = (product.quantity.minQuantity === null || product.quantity.minQuantity === 0) ? 1 : product.quantity.minQuantity;
            product.quantity.maxQuantity = (product.quantity.maxQuantity === null || product.quantity.maxQuantity === 0) ? 8 : product.quantity.maxQuantity;
            product.quantity.defaultQuantity = (product.quantity.defaultQuantity === null || product.quantity.defaultQuantity === 0) ? product.quantity.minQuantity : product.quantity.defaultQuantity;
            if(product.productName === "Tech-Install without Modem"){
                product.quantity.defaultQuantity = null;              
            }
        }
        for (let i = 0; i < this.refObj.length; i++) {
            if (this.refObj[i] && this.refObj[i].selectedItems && this.refObj[i].selectedItems.hasOwnProperty(product.productName)) {
                indx = i;
                break;
            }
        }
        if (this.refObj[indx] && this.refObj[indx].selectedItems && this.refObj[indx].selectedItems.hasOwnProperty(product.productName)) {
            if(product.productName === "Non-Pub No Charge"){
                this.nonPubNoChargeRemoved = true;
            }
            this.store.dispatch({ type: 'NON-PUB-REMOVED', payload:  this.nonPubNoChargeRemoved });
            delete this.refObj[indx].selectedItems[product.productName];
            this.selectedObjectsList[index].customerOrderSubItems.splice(
                this.findElem(this.selectedObjectsList[index].customerOrderSubItems, product.productName), 1);
        } else {
            if (!this.refObj[indx]) {
                this.refObj[indx] = {
                    selectedItems: {},
                    total: 0,
                    visible: false
                }
            }
            let price = 0;
            if(product && product.productAttributes && product.productAttributes !== undefined){
            for (let i = 0; i < product.productAttributes.length; i++) {
                if (product.productAttributes[i].isPriceable) {
                    let priceObj = product.productAttributes[i].prices;
                    priceObj.map(pric => {
                        if (pric.discountedRc !== 0) {
                            price = pric.discountedRc
                        } else if (pric.rc !== 0) {
                            price = pric.rc
                        } else if (pric.discountedOtc !== 0) {
                            price = pric.discountedOtc
                        } else if (pric.otc !== 0) {
                            price = pric.otc
                        }
                    })
                }
            }
        }
            this.refObj[indx].selectedItems[product.productName] = price;
            product.componentType = item.componentType;
            if (product.productName === 'Voice Messaging') product.dontShow = true;
            if(product.productName === "Non-Pub No Charge"){
                this.nonPubNoChargeSelected = true;
            }
            let producttemp = cloneDeep(product);            
            producttemp.action = this.isMACD ? this.addOnOfferData.catalogCategory !== 'DATA ADDON OFFER' && isSelected ? 'NOCHANGE' : this.getAction(product, this.addonObj, this.addOnOfferData.catalogCategory) : null;
            if(this.addOnOfferData && this.addOnOfferData.catalogCategory === 'DATA ADDON OFFER' && producttemp.action === 'NOCHANGE') producttemp.dontShow = true;
            producttemp.productOfferingId = item.productOfferingId;
            producttemp.quantity = item.hasQuantity ? product.quantity.defaultQuantity : null;
            if (this.isMACD && producttemp.action === 'ADD') {
                this.selectedObjectsList[index].action = this.selectedObjectsList[index].action === 'NOCHANGE' ? 'CHANGE' : 'NOCHANGE';
            }
            this.selectedObjectsList[index].customerOrderSubItems.push(producttemp);
        }        
        let defQuantity = product.quantity && product.quantity.defaultQuantity;
        if(product.productName === "Tech-Install without Modem"){
            defQuantity = 1;
        }
            product.totalPriceWithQty = this.getPrice(product.productAttributes, item.hasQuantity, defQuantity);                                               
        this.insertTotal();
        this.onChecked();
    }

    public checkboxHandlerDpQty(item, qty: number, prodType, indx, catalog, isSelected?) {
        let product = item.product;
        let index
        if(this.addOnOfferData) index = this.checkInsertProduct(prodType, this.addOnOfferData.catalogCategory, catalog, product, isSelected, item);

        for (let i = 0; i < this.refObj.length; i++) {
            if (this.refObj[i] && this.refObj[i].selectedItems && this.refObj[i].selectedItems.hasOwnProperty(product.productName)) {
                indx = i;
                break;
            }
        }
        delete this.refObj[indx].selectedItems[product.productName];
        this.selectedObjectsList[index].customerOrderSubItems.splice(
        this.findElem(this.selectedObjectsList[index].customerOrderSubItems, product.productName), 1);
        if(product.productAttributes && product.productAttributes !== undefined){
            product.productAttributes.map(prodAttr =>{
                if(prodAttr && prodAttr.prices && prodAttr.prices !== null){
                    let qtyPrice = (prodAttr.prices[0].otc - prodAttr.prices[0].discountedRc) * qty;                
                    let producttemp = cloneDeep(product);
                    producttemp.productOfferingId = item.productOfferingId;
                    producttemp.componentType = item.componentType;
                    producttemp.quantity = qty;
                    producttemp.dontShow = false;
                    producttemp.action = this.isMACD ? this.addOnOfferData.catalogCategory !== 'DATA ADDON OFFER' && isSelected ? 'NOCHANGE' : this.getAction(product, this.addonObj, this.addOnOfferData.catalogCategory, undefined, qty) : null;
                    if(this.addOnOfferData && this.addOnOfferData.catalogCategory === 'DATA ADDON OFFER' && producttemp.action === 'NOCHANGE') producttemp.dontShow = true;
                    this.selectedObjectsList[index].customerOrderSubItems.push(producttemp);
                    this.refObj[indx].selectedItems[product.productName] = qtyPrice;  
                }             
            })                      
        }
        if(product.productName === "Tech-Install without Modem"){
            this.store.dispatch({ type: 'TECHDEV_SELECTED', payload: qty});                
            product.totalPriceWithQty = this.getPrice(product.productAttributes, true, 1);
        } else {
            product.totalPriceWithQty = this.getPrice(product.productAttributes, true, qty);
        }
        this.insertTotal();
        this.onChecked();
    }

    public checkInsertProduct(prodName, prodType, catalog, product?, isSelected?, item?) {
        let prodObj: any;
        let subOffer = false;
        if (catalog.productOffer.offerCategory === 'VOICE-HP' && catalog.productOffer.offerType !== 'SUBOFFER') {
            prodObj = this.selectedObjectsList.find((obj) => {
                return obj.offerType === catalog.productOffer.offerType;
            });
        } else if (catalog.productOffer.offerCategory === 'VOICE-HP' && catalog.productOffer.offerType === 'SUBOFFER') {
            subOffer = true;
            prodObj = this.selectedObjectsList.find((obj) => {
                return obj.productOfferingId === item.productOfferingId;
            });
        } else {
            prodObj = this.selectedObjectsList.find((obj) => {
                return obj.name === prodName && obj.offerCategory === catalog.productOffer.offerCategory;
            });
        }
        if (!prodObj) {
            this.selectedObjectsList.push(
                {
                    "catalogId": catalog.catalogId,
                    "contractTerm": catalog.productOffer.contract.contractTerm,
                    "productOfferingId": subOffer ? item.productOfferingId : catalog.productOfferingId,
                    "offerType": catalog.productOffer.offerType,
                    "offerSubType": catalog.productOffer.offerSubType,
                    "offerCategory": catalog.productOffer.offerCategory,
                    "quantity": null,
                    "rc": catalog.defaultOfferPrice !== null ? catalog.defaultOfferPrice.rc : 0,
                    "otc": catalog.defaultOfferPrice !== null ? catalog.defaultOfferPrice.otc : 0,
                    "discountedRc": catalog.defaultOfferPrice !== null ? catalog.defaultOfferPrice.discountedRc : 0,
                    "discountedOtc": catalog.defaultOfferPrice !== null ? catalog.defaultOfferPrice.discountedOtc : 0,
                    productType: prodType,
                    name: prodName,
                    action: this.isMACD ? this.addOnOfferData && this.addOnOfferData.catalogCategory !== 'DATA ADDON OFFER' && isSelected ? 'NOCHANGE' : this.getAction(product, this.addonObj, this.addOnOfferData.catalogCategory, true) : null,
                    customerOrderSubItems: [],
                    offerName: catalog.productOffer && catalog.productOffer.offerName
                });
            return this.selectedObjectsList.length - 1;
        } else {
            return this.selectedObjectsList.indexOf(prodObj);
        }
    }

    public findElem(array, name): number {
        let obj = array.find((item) => {
            return item.productName === name;
        });
        return array.indexOf(obj);
    }

    public showQuantity(product: Products, indx): boolean {
        let flag: boolean = false;
        for (let i = 0; i < this.refObj.length; i++) {
            if (this.refObj[i] && this.refObj[i].selectedItems.hasOwnProperty(product.productName)) {
                flag = true;
                break;
            } else if (this.refObj[i]) {
                for (let j = 0; j < product.productAttributes.length; j++) {
                    if (product.productAttributes[i].isPriceable) {
                        let qtyPrice = (product.productAttributes[i].prices[0].otc - product.productAttributes[i].prices[0].discountedRc) * 1;
                        product.productAttributes[i].prices[0].discountedOtc = qtyPrice;
                        this.refObj[i].selectedItems[product.productName] = qtyPrice;
                        delete this.refObj[i].selectedItems[product.productName];
                        flag = false;
                    }
                }
            } else {
                flag = false;
            }
        }
        return flag;
    }

    public quantity(component): number {
        let currentStore = this.appStateService.getState();
        this.addonObj = currentStore && currentStore.cart && currentStore.cart.payload && currentStore.cart.payload.customerAddonOfferItems;
        let val = component && component.product && component.product.quantity;
        let qty = val && val.defaultQuantity === null || val && val.defaultQuantity === 0 ?
            val && val.minQuantity === null || val && val.minQuantity === 0 ? 1 : val && val.minQuantity : val && val.defaultQuantity;
        if (this.addonObj !== undefined) {
            this.addonObj.forEach(addOn => {
                if (this.addOnOfferData.catalogCategory === addOn.productType && component !== undefined
                    && component.product !== undefined) {
                    addOn.customerOrderSubItems.forEach(subOrder => {
                        if (component.product.productName === subOrder.productName) {
                            for (let i = 0; i < this.refObj.length; i++) {
                                if (this.refObj[i] && this.refObj[i].selectedItems.hasOwnProperty(component.product.productName)) {
                                    qty = subOrder.quantity;
                                }
                            }
                        }
                    });
                }
            });
        }
        if(component.product.productName === "Tech-Install without Modem" && (val.defaultQuantity === null || (this.techdevselectedVal === null || this.techdevselectedVal === 'na'))){
            qty = 'na';
        }
        return qty;
    }

    public insertTotal() {
        this.store.dispatch({ type: 'UPDATE_ADDON', payload: this.selectedObjectsList });
    }

    public onChecked() {
        this.onDataChange.emit(this.selectedObjectsList);
    }

    public noOfQtyCountDp(quantity) {
        return Array.apply(null, { length: quantity.maxQuantity + 1 - quantity.minQuantity }).map(function (_, idx) {
            return idx + quantity.minQuantity;
        });
    }

    public getAction(product, addonObj: CustomerOrderItems[], category: string, isParent?: boolean, qty?) {
        let action = 'CHANGE';
        if (addonObj) {
            for (let i = 0; i < addonObj.length; i++) {
                if (addonObj[i] && addonObj[i].productType !== 'DATA ADDON OFFER' && (addonObj[i].offerCategory === 'INTERNET' ||
                    addonObj[i].offerCategory === product.productType)) {
                    if (addonObj[i].customerOrderSubItems !== null && addonObj[i].customerOrderSubItems && addonObj[i].customerOrderSubItems.length !== 0) {
                        for (let j = 0; j < addonObj[i].customerOrderSubItems.length; j++) {
                            if (product.productName === addonObj[i].customerOrderSubItems[j].productName) {
                                action = 'NOCHANGE';
                                break;
                            } else {
                                action = 'ADD';
                                break;
                            }
                        }
                    }
                    break;
                } else if (addonObj[i] && (addonObj[i].productType === 'DATA ADDON OFFER')) {
                    action = 'ADD';
                    for (let k = 0; k < this.addOnOfferData.length; k++) {
                        let mainObj = this.addOnOfferData[k].productOffer;
                        if(mainObj.offerCategory === product.productType) {
                            let item = mainObj.productComponents;
                            for (let i = 0; i < item.length; i++) {
                                if (item[i].product.productName === product.productName) {
                                    this.existingCart && this.existingCart.map(exCart => {
                                        exCart.customerOrderSubItems && exCart.customerOrderSubItems.map(sub => {
                                            if(item[i].hasQuantity && sub.productName === product.productName && sub.quantity === qty) {
                                                action = 'NOCHANGE';
                                            }
                                        })
                                    })
                                }
                            }
                        }
                    }
                } else {
                    action = 'ADD';
                }
            }
        } else if (category === 'HP ADDON OFFER' && isParent) {
            action = this.hpExisting ? 'NOCHANGE' : 'ADD';
        } else {
            action = 'ADD';
        }
        return action;
    }

    public SupDisableConfig(productOffer){
        if(productOffer && productOffer.accordianTitle && productOffer.accordianTitle === "Equipment") {
            return true;
        }
        return false;
    }
    
    public groupOpenStatus(isClosed, index) {
        setTimeout(() => {
            if(isClosed && this.selectedIndexArray && (this.selectedIndexArray.length > 0)) {
                this.selectedIndexArray = this.selectedIndexArray.filter((i) => i !== index);
            }
            if(!isClosed && this.selectedIndexArray && !(this.selectedIndexArray.indexOf(index) > 0)) {
                this.selectedIndexArray.push(index);
            }
        }, 300);
    }

}