import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OneTimeChargesComponent } from './onetime-charges.component';
import { MockServer } from 'app/MockServer.test';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { MockAppStateService, MockLogger } from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TabsModule, AccordionModule, TooltipModule } from 'ngx-bootstrap';
import "rxjs/add/observable/of";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('OnetimeChargesComponent', () => {
  let component: OneTimeChargesComponent;
  let fixture: ComponentFixture<OneTimeChargesComponent>;
  const mockServer = new MockServer();
  const imports = [
      FormsModule,
      ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
      SharedModule,
      SharedCommonModule,
      TextMaskModule,
      TabsModule.forRoot(),
      AccordionModule.forRoot(),
      TooltipModule.forRoot(),
      BrowserAnimationsModule
  ]

  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }
  class MockAppStateService{
    setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE');
    }
  }

  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const logger = { provide: Logger, useClass: MockLogger };

  let indx, product, fromRule, item, catalog, isSelected, prodType;

  const providers = [
    store, appStateService, logger
  ]

  describe('NI Flow', () => {
  
    const baseConfig = {
      imports: imports,
      declarations: [OneTimeChargesComponent],
      providers: providers
    };
    
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(OneTimeChargesComponent);
      component = fixture.componentInstance;
      const data = mockServer.getVariables('oneTimeChargeVarFor-addNremoveproducts');
      indx = data.indx; 
      product = data.product;
      fromRule = data.fromRule;
      item = data.item;
      catalog = data.catalog;
      isSelected= data.isSelected;
      prodType=data.prodType;
      component.addOnOfferData = data.addOnOfferData;
      component.cartData = [];
      component.selectedListingOptionValue = '';
      component.hpAutoSelect = false;
      component.undo = true;
      component.undoQty  = 1;
      component.firstIsOpen = data.inputDataFromParent.firstIsOpen;
      component.DisableVoiceMail = data.inputDataFromParent.DisableVoiceMail;
      component.priceKeyName = data.inputDataFromParent.priceKeyName;
      component.isMACD = data.inputDataFromParent.isMACD;
      component.hpExisting = data.inputDataFromParent.hpExisting;
      component.compatibility = data.inputDataFromParent.compatibility;
      component.potsOfferType = data.inputDataFromParent.potsOfferType;
      component.internetActive = data.inputDataFromParent.internetActive;
      component.selectedObjectsList = data.inputDataFromParent.selectedObjectsList;
      component.isAmend = data.inputDataFromParent.isAmend;
      component.newHSI = data.inputDataFromParent.newHSI;
      component.newPOTS = data.inputDataFromParent.newPOTS;
      (component as any).isChange = data.inputDataFromParent.isChange;
      component.refObj = data.refObj;
      fixture.detectChanges();
    });
  
    it('should create onetime charges component', () => {
      expect(component).toBeTruthy();
    });
  
    it('should assign vacation suspend flag', () => {
      expect(component.isVacSus).toBeFalsy();
      expect(component.isVacRes).toBeFalsy();
    });
  
    it('should dispatch addons using insertTotal fn', () => {
      let mockRedux = TestBed.get(Store);
      spyOn(mockRedux, 'dispatch');
      component.insertTotal();
      expect(mockRedux.dispatch).toHaveBeenCalled();
    });
  
    it('should call updateList fn', () => {
      let MockAppStateService = TestBed.get(AppStateService);
      spyOn(MockAppStateService, 'getState').and.returnValue(mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE'));
      component.updateList();
      expect(component.customizeSubscription).toBeDefined();
    }); 
  
    it('should call checkSelection fn', () => {
      let MockAppStateService = TestBed.get(AppStateService);
      spyOn(MockAppStateService, 'getState').and.returnValue(mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE'));
      component.checkSelection(undefined, undefined, undefined, undefined);
      expect(component.addonObj).toBe(mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE').cart.payload.customerAddonOfferItems);
    }); 
  
    xit('should call getCompatibilityRules fn', () => {
      let value = component.getCompatibilityRules(undefined, undefined);
      expect(value).toBe(false);
    }); 

    it('should call addNremoveproducts fn', () => {
      let value = component.addNremoveproducts(indx, product, fromRule, item, catalog, isSelected, prodType);
      expect(value).toBe(undefined);
      expect(component.nonPubNoChargeRemoved).toBe(false);
    });

    it('should call checkBoxHandlerDp fn', () => {
      let value = component.checkBoxHandlerDp(item, prodType, indx, catalog, isSelected, fromRule);
      expect(value).toBe(undefined);
    });

    it('should call checkboxHandlerDpQty fn', () => {
      let value = component.checkboxHandlerDpQty(item, 1, prodType, 0, catalog, isSelected);
      expect(value).toBe(undefined);
    }); 

    it('should call groupOpenStatus fn', () => {
      let value = component.groupOpenStatus(true, 1);
      expect(value).toBe(undefined);
    }); 

    it('should call calculateTotal fn', () => {
      let refObj = component.refObj;
      let value = component.calculateTotal(refObj, true);
      expect(value).toBe(undefined);
    }); 

  });

  describe('MOVE Flow - HSI', () => {
    class MockAppStateService{
      setLocationURLs() {
          return null;
      }
      getState () {
          return mockServer.getMockStore('MOVE_HSI_TILL_REVIEW_ORDER');
      }
    }
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
  
    const store = { provide: Store, useValue: mockRedux };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };
    const _providers = [...providers, store, appStateService]
  
    let baseConfig = {
      imports: imports,
      declarations: [OneTimeChargesComponent],
      providers: _providers
    };
    
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(OneTimeChargesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create onetime charges component', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('MOVE Flow - POTS', () => {
    class MockAppStateService{
      setLocationURLs() {
          return null;
      }
      getState () {
          return mockServer.getMockStore('MOVE_POTS_TILL_REVIEW_ORDER');
      }
    }
    const mockRedux: any = {
      dispatch() {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_POTS_TILL_REVIEW_ORDER")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
  
    const store = { provide: Store, useValue: mockRedux };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };
    const _providers = [...providers, store, appStateService];
  
    const baseConfig = {
      imports: imports,
      declarations: [OneTimeChargesComponent],
      providers: _providers
    };
    
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(OneTimeChargesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create onetime charges component', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('HSI+POTS', () => {
    const mockRedux: any = {
      dispatch() {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }
  
    const store = { provide: Store, useValue: mockRedux };
    const _providers = [...providers, store];
  
    const baseConfig = {
      imports: imports,
      declarations: [OneTimeChargesComponent],
      providers: _providers
    };
    
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(OneTimeChargesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create onetime charges component', () => {
      expect(component).toBeTruthy();
    });
  });

});
