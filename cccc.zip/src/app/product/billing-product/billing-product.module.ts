import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TooltipModule } from 'ngx-bootstrap';
import { SharedModule } from '../../shared/shared.module';
import { TextMaskService } from './../../common/service/text-mask.service';
import { OfferBillingComponent } from './offer-billing.component';

const routes: Routes = [
    {
        path: '', component: OfferBillingComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        SharedModule,
        SharedCommonModule,
        TooltipModule.forRoot()
    ],
    exports: [
        OfferBillingComponent,
    ],
    declarations: [
        OfferBillingComponent,
    ],
    providers: [
        TextMaskService
    ]
})

export class BillingProductModule { }
