import { Component, OnDestroy, OnInit, ViewChild, AfterViewInit } from "@angular/core";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { CTLHelperService } from "app/common/service/ctlHelperService";
import { cloneDeep } from "lodash";
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { OfferVariables } from 'app/common/models/offers.model';
import { HelperService } from "app/common/service/helper.service";
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { Logger } from "app/common/logging/default-log.service";
import { AppStore } from "app/common/models/appstore.model";
import { ContactInfo, CustomerOrderItems, CustomerOrderSubItem, ShoppingCart } from "app/common/models/cart.model";
import { APIErrorLists, ErrorResponse, GenericValues, serverErrorMessages } from "app/common/models/common.model";
import { AttributesCombination, CompositeAttribute, filterObjModel, OfferProductComponents, ProductOfferings, Products, ServiceCategoryBasedOffers, ServiceCategoryId } from "app/common/models/product.model";
import { User } from "app/common/models/user.model";
import { AppStateService } from "app/common/service/app-state.service";
import { DisconnectService } from "app/common/service/disconnect.service";
import { ProductService } from "app/common/service/product.service";
import { SystemErrorService } from "app/common/service/system-error.service";
import { DialogComponent } from "app/common/popup/dialog.component";
import * as _ from 'lodash';
import { RE_ENTRANT_OFFERVARIABLE } from "app/app.constant";
import { ElementRef } from '@angular/core';
import "rxjs/add/operator/catch";
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums';

@Component({
	selector: "billing-product",
	styleUrls: ["./../offer.component.scss"],
	templateUrl: "./offer-billing.component.html"
})
export class OfferBillingComponent implements OnInit, OnDestroy, AfterViewInit {
	public user: Observable<User>;
	public userObservable: Observable<any>;
	public userSubscription: Subscription;
	public existingObservable: Observable<any>;
	public existingSubscription: Subscription;
	public orderObservable: Observable<any>;
	public orderSubscription: Subscription;
	public pendingSubscription: Subscription;
	public pendingObservable: Observable<any>;
	public existingProductStore$: Observable<any>;
	public existingProductStoreSubscription: Subscription;
	@ViewChild("removeProduct", { static: false, }) public removeProduct: any;
	@ViewChild("e911Validation", { static: false, }) public e911Validation: any;
	@ViewChild('wireMaintainanceInput', { static: false, }) public wireMaintainanceInput: ElementRef;
	@ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
	public serviceSpec: ServiceCategoryId[] = [];
	public offerVariables: OfferVariables;
	public selectedModemType: string = '';	
	public changedModemType: string = '';	
	public selectedValues: string;
	public isExpiredOffer: boolean = false;
	constructor(
		private logger: Logger,
		public store: Store<AppStore>,
		private router: Router,
		private productService: ProductService,
		private appStateService: AppStateService,
		private systemErrorService: SystemErrorService,
		private disconnectServiceCall: DisconnectService,
		private ctlHelperService: CTLHelperService,
		private helperService: HelperService,
		private propertiesHelperService: PropertiesHelperService,
		public offerHelperService: OfferHelperService,
	) {
		this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);
		let addons: CustomerOrderItems[];
		let cart = <Observable<ShoppingCart>>this.store.select('cart');
		let cartSubscription = cart.subscribe((data) => {
			if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
				addons = data.payload.cart.customerOrderItems;
				addons[0].customerOrderSubItems.forEach(data => {
					if (data.componentType === "PRIMARY") { this.selectedValues = data.productName; }
				});
			}
			if (data && data.payload && data.payload.discountItems) {
				this.offerVariables.discountsAdded = data.payload.discountItems;
				this.offerVariables.copyOfDiscountsAdded = this.offerVariables.discountsAdded;
			}
		})
		if (cartSubscription !== undefined) cartSubscription.unsubscribe();
		this.initilizeAll();
		this.isExpiredOffer = this.helperService.isAuthorized(ProfileEnums.ALLOW_SALE_EXPIRED_OFFERS);
	}
	public ngAfterViewInit() {
		this.offerVariables.currentFlow = "BILLING";
        this.offerVariables.secureWifiSelected = '';
        this.offerVariables.easeSelected= '';
        this.offerVariables.voiceMailInput= '';
        this.offerVariables.wireMaintainanceInput= '';
        this.offerVariables.portingInput= '';
    } 
	public initilizeAll() {
		this.offerHelperService.checkCSCompatibitlity(this.offerVariables);
		this.offerVariables.isProfileBypassLoopQual = this.helperService.isAuthorized(ProfileEnums.BYPASS_LOOP_QUAL);
		this.offerVariables.isProfileBypassHSISpeeds = this.helperService.isAuthorized(ProfileEnums.BYPASS_HSI_SPEEDS);
		this.offerVariables.isProfileBypassModemCheck = this.helperService.isAuthorized(ProfileEnums.BYPASS_MODEM_CHECK);
		this.appStateService.setLocationURLs();
		this.offerHelperService.getTechnologyTypes(this.offerVariables);
		this.existingObservable = <Observable<any>>(this.store.select("existingProducts"));
		this.userObservable = <Observable<any>>this.store.select("user");
		let ensembleId;
		let userSub = this.userObservable.subscribe((data) => {
			if (data.selfinstallselected) this.offerVariables.selfinstallSelected = true;
			if(data && data.existsServices && data.existsServices.indexOf('INTERNET') > -1) {
				this.offerVariables.isHSIExistingProduct = true;
			}
			if (data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.ensembleId) {
				ensembleId = data.autoLogin.oamData.ensembleId;
			}
	});
		if (userSub) userSub.unsubscribe();
		this.offerVariables.isAllowBypassLoopQualForLQ = this.propertiesHelperService.isPropertyInList(PropertyEnums.ALLOW_BYPASS_LOOPQUAL_FOR_LQ, ensembleId);
		this.orderObservable = <Observable<any>>this.store.select('order');
		this.pendingObservable = <Observable<any>>this.store.select('pending');
		this.offerVariables.discountedPriceList = [];
		this.offerVariables.internetCheck = false;
		this.offerVariables.isOptedOut = false;
		this.offerVariables.internetOffer = true;
		this.offerVariables.videoOffer = false;
		this.offerVariables.phoneOffer = false;
		this.offerVariables.internetAvail = false;
		this.offerVariables.videoAvail = false;
		this.offerVariables.phoneAvail = false;
		this.offerVariables.videoSelected = "NoTV";
		this.offerVariables.phoneSelected = GenericValues.noPhone;
		this.offerVariables.currentStore = this.appStateService.getState();
		this.offerVariables.offersGenerated = true;
		this.offerVariables.isSalesExpiredOfferSelected = false;
		this.offerVariables.addOfferExpired = false;
		this.offerVariables.serviceUnavailable = "Service not available for your Address";
		let prod: Products = {
			productId: "608",
			productName: "Intrastate Service Fee",
			productType: "Service",
			isRegulated: false
		};
		let state: boolean = false;
		this.orderSubscription = this.orderObservable.subscribe(ord => {
			this.offerVariables.isCustomize = ord.taskName === 'Checkout & Scheduling' ? true : false;
			this.offerVariables.selectedSalesExpiredOfferId = ord.offerId;
		})
		if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
		this.offerVariables.intraStateFee = prod;
		let data = this.appStateService.getState().existingProducts;
		if (!state) {
			this.offerVariables.existingObject = data;
			if (data.orderFlow.type === 'fromHold') {
				this.offerVariables.fromHold = true;
			}
			let pendingSubscription = this.pendingObservable.subscribe(pending => {
				if(pending.BillingAndRecordsPending)
				{this.offerVariables.holdedObjects = pending.BillingAndRecordsPending;
				}else{
					this.offerVariables.holdedObjects = pending;
				}
			})
			pendingSubscription.unsubscribe();


			if (data) {
				if (data.existingDiscounts) {
					this.offerVariables.existingDiscounts = data.existingDiscounts;
				}
				if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo
					&& data.existingProductsAndServices[0].accountInfo.billingType) {
						this.offerVariables.offerBillingType = data.existingProductsAndServices[0].accountInfo.billingType === "PREPAID" ? data.existingProductsAndServices[0].accountInfo.billingType : "POSTPAID";
				}
			}

			this.getRemoveResponse();
			if(data && data.orderFlow && data.orderFlow.flow )
			this.offerVariables.flow = data.orderFlow.flow.toUpperCase() ;
			if (data && data.orderFlow && data.orderFlow.flow === 'Billandrec' && this.offerVariables.fromHold && !data.orderFlow.selectProductCalled && !this.offerVariables.holdCalled) {
				this.offerVariables.holdCalled = true;
				this.pendingSubscription = this.pendingObservable.subscribe(pending => {
					let inputAddress: any;
					let callerInfo: ContactInfo = {
						firstName: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.accountName &&
							pending.orderDocument.accountInfo.accountName.firstName ? pending.orderDocument.accountInfo.accountName.firstName : 'First Name',
						lastName: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.accountName &&
							pending.orderDocument.accountInfo.accountName.lastName ? pending.orderDocument.accountInfo.accountName.lastName : 'Last Name',
						phoneNumber: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.contact &&
							pending.orderDocument.accountInfo.contact.contactNumber ? pending.orderDocument.accountInfo.contact.contactNumber : '2424242424',
					};
					inputAddress = {
						addressLine: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetAddress,
						unitNumber: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.subAddress
							&& pending.orderDocument.serviceAddress.subAddress.combinedDesignator,
						stateOrProvince: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.stateOrProvince,
						city: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.city,
						postCode: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.zipCode,
						singleLine: true,
					};
					this.offerVariables.holdedObjects = pending;
					this.offerVariables.loading = true;
					this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
					this.store.dispatch({ type: 'FINAL_ADDRESS', payload: inputAddress });
					state = this.callApiForChange(this.store, state, data);
				})
				if (this.pendingSubscription !== undefined) this.pendingSubscription.unsubscribe();
			} else {
				state = this.callApiForChange(this.store, state, data);
			}
		}
		this.getRemoveResponse();
		if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
	}

	public callApiForChange(store: Store<AppStore>, state: boolean, data1: any) {
		let data: any = this.appStateService.getState().user;
		this.offerVariables.isDtvOpus = data.isDtvOpus;
		this.offerVariables.orderRefNumber = data.orderInit.orderRefNumber;
		if (data.orderInit && data.orderInit.payload && data.orderInit.payload.productConfiguration) {
			this.offerVariables.productConfiguration = data.orderInit.payload.productConfiguration;
		}
		this.offerVariables.processInstanceId = data.orderInit.processInstanceId;
		if (!this.offerVariables.taskId) this.offerVariables.taskId = data.orderInit.taskId;
		this.offerVariables.taskName = data.orderInit.taskName;
		this.serviceSpec = data.orderInit.payload.serviceCategory;
		this.offerVariables.videoAvail = data.videoCheck;
		this.offerVariables.phoneAvail = data.phoneCheck;
		this.offerVariables.phoneArray = data.phoneType;
        this.offerVariables.internetAvail = data.internetCheck;
		this.offerVariables.videoArray = data.videoType;
		this.offerVariables.enabledServiceList = data.enabledServiceList;
		this.offerVariables.ban = data.ban;
		this.user = <Observable<User>>this.store.select('user');
		let retSubscribe: Subscription;

		if (((data.previousUrl !== '/existing-products') || (data.previousUrl === '/existing-products' && this.offerVariables.existingObject.orderFlow.type === 'fromHold'))
			&& data.previousUrl !== '/pending-order') {
			this.offerVariables.isReEntrant = true;
			this.offerVariables.reEntrant = true;
			this.offerVariables.reentrantUI = true;
		}
		
		if (data.previousUrl === '/existing-products' && data.currentUrl === "/billing-product") {
			this.offerVariables.flow = 'BILLING';
			let orderFlow = {
				flow: 'billing',			
			}
			this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });			
		}

		if (data.previousUrl === '/pending-order') {
			this.offerVariables.flow = 'BILLING';
			let orderFlow = {
				flow: 'billing',
				type: 'pending'
			}
			this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
			this.offerVariables.isPendingFlow = true;
		}
		if (this.offerVariables.isPendingFlow && this.offerVariables.holdedObjects &&
			this.offerVariables.holdedObjects.orderDocument) {
			this.offerHelperService.existingProductConfigCheck(this.offerVariables, this.offerVariables.holdedObjects.orderDocument);
		}
		this.existingObservable.subscribe((data) => {
			this.offerVariables.existingObject.orderFlow = data.orderFlow;
			if (data && data.existingDiscounts) {

				this.offerVariables.existingDiscounts = data.existingDiscounts;

			}
			if (data && data.existingProductsAndServices) {
				this.offerHelperService.existingProductConfigCheck(this.offerVariables, data.existingProductsAndServices);
			}

			if (data && data.orderFlow && data.orderFlow.type === 'pending') {
				this.offerVariables.isPendingFlow = true;
            }
            if(data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].serviceAddress
                && data.existingProductsAndServices[0].serviceAddress.locationAttributes){
                    this.offerVariables.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
                }
		})

		if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.retrievalTypes) {
			this.offerVariables.offersByFilters = this.offerHelperService.retrieveOffersByFilter(data.orderInit.payload.retrievalTypes);
			this.offerVariables.qualifiedFilter = this.offerVariables.offersByFilters.qualifiedFilter;
			this.offerVariables.unQualifiedOffers = this.offerVariables.offersByFilters.unQualifiedOffers;
			this.offerVariables.qualifiedUnfilter = this.offerVariables.offersByFilters.qualifiedUnfilter;
		}

		if (!this.offerVariables.fromHold && this.offerVariables.existingObject && this.offerVariables.existingObject.existingProductsAndServices && this.offerVariables.existingObject.existingProductsAndServices[0] &&
			this.offerVariables.existingObject.existingProductsAndServices[0].existingServices &&
			this.offerVariables.existingObject.existingProductsAndServices[0].existingServices.existingServiceItems) {
			this.offerVariables.existingServices = this.offerVariables.existingObject.existingProductsAndServices[0].existingServices.existingServiceItems;
		} else {
			this.offerVariables.existingServices = !this.offerVariables.isPendingFlow ? this.offerVariables.holdedObjects.orderDocument.existingServices : this.offerVariables.holdedObjects.orderDocument.customerOrderItems;
		}
		this.availableExistingProds();
		this.offerVariables.retainedPotsBooleans = {
			wireMaintainance: this.offerVariables.wireMaintainance,
			voiceMail: this.offerVariables.voiceMail,
			retainValueForPotsJack: this.offerVariables.retainValueForPotsJack
		}
		if (
			(
			(data.previousUrl !== '/existing-products') 
			|| (data.previousUrl === '/existing-products' && this.offerVariables.existingObject.orderFlow.type === 'fromHold')
			)
			&& data.previousUrl !== '/pending-order') {
			this.offerVariables.isReEntrant = true;
			this.offerVariables.reEntrant = true;
			this.offerVariables.reentrantUI = true;
			let retainVal = <Observable<any>>this.store.select('retain');
			retSubscribe = retainVal.subscribe(
				(retVal => {
					this.offerVariables.isConverted = retVal.isConverted;
					this.offerVariables.taskId = data.taskId;
					if (!state) {
						this.offerVariables.holdCalled && this.offerVariables.existingObject && this.offerVariables.existingObject.existingProductsAndServices &&
							this.offerVariables.existingObject.existingProductsAndServices.map((item) => {
								let existingItems: any;
								if (this.offerVariables.existingObject.orderFlow.type === 'fromHold') {
									existingItems = this.offerVariables.holdedObjects.orderDocument.customerOrderItems;
								} else {
									existingItems = item.existingServices.existingServiceItems;
								}
								this.offerVariables.retainedPotsBooleans = {
									retainValueForPotsJack: this.offerVariables.retainValueForPotsJack
								}
								this.dropDownPopulationforHP(existingItems, false);
								item && item.productConfiguration && item.productConfiguration.map((data) => {

									if (!this.offerVariables.isDtvOpus) {
										if (data && data.productType === GenericValues.cDTV) {
											data.configItems && data.configItems.map((config) => {
												config && config.configDetails && config.configDetails.map((details) => {
													if (details && details.formName === 'DTV AccountID') {
														details.formItems && details.formItems.map((items) => {
															if (items && items.attributeName === 'DIRECTV Account ID') {
																if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
																	this.offerVariables.directvAccountId = items.attributeValue[0].value;
																}
															}
														})
													}
												})
											})
										}
									}

									if (data && data.productType === GenericValues.iData) {
										data.configItems && data.configItems.map((config) => {
											config && config.configDetails && config.configDetails.map((details) => {
												if (details && details.formName === 'Devices') {
													details.formItems && details.formItems.map((items) => {
														if (items && items.attributeName === 'Quantity') {
															if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
																this.offerVariables.selectedQuantity = items.attributeValue[0].value;
																this.offerVariables.deviceSelected = true;
															}
														}
													})
												}
											})
										})
									}

								})
							})
						this.offerVariables.retainedPotsBooleans = {
							wireMaintainance: this.offerVariables.wireMaintainance,
							voiceMail: this.offerVariables.voiceMail,
							retainValueForPotsJack: this.offerVariables.retainValueForPotsJack
						}
						if (retVal.potsBooleans) this.offerVariables.retainedPotsBooleans = retVal.potsBooleans;
						if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.wireMaintainance !== undefined) {
							this.offerVariables.wireMaintainance = this.offerVariables.retainedPotsBooleans.wireMaintainance;
						}
						if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.voiceMail !== undefined) {
							this.offerVariables.voiceMail = this.offerVariables.retainedPotsBooleans.voiceMail;
						}
						if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.portingCheck !== undefined) {
							this.offerVariables.portingCheck = this.offerVariables.retainedPotsBooleans.portingCheck;
						}
						if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.selectedMaintainance !== undefined) {
							this.offerVariables.selectedMaintainance = this.offerVariables.retainedPotsBooleans.selectedMaintainance;
						}
						if (this.offerVariables.retainedPotsBooleans && this.offerVariables.retainedPotsBooleans.isInternational !== undefined) {
							this.offerVariables.isInternational = this.offerVariables.retainedPotsBooleans.isInternational;
						}
						this.offerVariables.cartObject = retVal.addOns;
						this.offerVariables.cartCopyObject = retVal.addOns;
						this.offerVariables.e911ValidatedAddress = retVal.e911ValidatedAddress;

						if (!this.offerVariables.cartObject) {
							this.offerVariables.cartObject = {
								payload: {
									cart: {
										customerOrderItems: this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
											this.offerVariables.holdedObjects.orderDocument.customerOrderItems
									},
									productConfiguration: this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
										this.offerVariables.holdedObjects.orderDocument.productConfiguration
								}
							}
						}
						//to retain jack values
						this.offerVariables.cartObject.payload && this.offerVariables.cartObject.payload.cart && this.offerVariables.cartObject.payload.cart.customerOrderItems.map(cust => {
							if (cust && cust.offerCategory === GenericValues.cHP && cust.offerType !== 'SUBOFFER') {
								cust.customerOrderSubItems && cust.customerOrderSubItems.map(exSub => {
									if (exSub.productName.indexOf('Jack and Wire') !== -1) {
										this.offerVariables.retainValueForPotsJack = exSub.productAttributes[0].compositeAttribute[0].attributeValue
									}
								});
							}
						})
						if (this.offerVariables.retainValueForPotsJack !== undefined && this.offerVariables.retainValueForPotsJack) {
							this.offerVariables.retainedPotsBooleans.retainValueForPotsJack = this.offerVariables.retainValueForPotsJack;
						}

						this.offerVariables.cartCopyObject = cloneDeep(this.offerVariables.cartObject);
						if (this.offerVariables.cartCopyObject && this.offerVariables.cartCopyObject.payload && this.offerVariables.cartCopyObject.payload.productConfiguration) {
							let selectConfigList = this.offerVariables.cartCopyObject.payload.productConfiguration;
							if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
								for (let i = 0; i < selectConfigList.length; i++) {
									selectConfigList[i].configItems && selectConfigList[i].configItems.map(selectedConf => {
										this.offerVariables.selectedQuantity = selectedConf.configDetails[0].formItems[0].attributeValue[0].value;
										this.offerVariables.deviceSelected = true;
									})
								}
							}
						}

						let custOrderItem: CustomerOrderItems[] = this.offerVariables.holdCalled ? this.offerVariables.holdedObjects && this.offerVariables.holdedObjects.orderDocument &&
							this.offerVariables.holdedObjects.orderDocument.customerOrderItems : retVal.addOns.payload.cart.customerOrderItems;
						this.offerVariables.cartObject.payload = {
							cart: {
								customerOrderItems: custOrderItem
							}
						}
						this.offerVariables.cartCopyObject = cloneDeep(this.offerVariables.cartObject);
						if (this.offerVariables.cartObject) {
							if (this.offerVariables.cartObject.payload.cart.customerOrderItems !== undefined && this.offerVariables.cartObject.payload.cart.customerOrderItems.length > 0) {
								this.offerVariables.cartObject.payload.cart.customerOrderItems.forEach((item) => {
									if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
										if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.hsiExisting = true; }
									} else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
										this.offerVariables.removedProductItem.push(item);
									}
									if (item.offerCategory === 'VIDEO-PRISM' && item.action !== 'REMOVE') {
										this.offerVariables.videoOffer = true;
										this.offerVariables.videoSelected = 'PTV';
										state = false;
									}
									if (item.offerCategory === 'VIDEO-DTV' && item.action !== 'REMOVE') {
										if(item.action !== 'ADD') { this.offerVariables.dtvExisting = true; }
										this.offerVariables.videoOffer = true;
										this.offerVariables.videoSelected = 'DTV';
										state = false;
									} else if (item.offerCategory === 'VIDEO-DTV' && item.action === 'REMOVE') {
										this.offerVariables.removeSelectedReason = retVal.removeReason;
										this.offerVariables.removedProductItem.push(item);
										this.offerVariables.dtvExisting = true;
										state = false;
									}
									if (item.offerCategory === 'VOICE-DHP' && item.action !== 'REMOVE') {
										if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.dhpExisting = true; }
										this.offerVariables.phoneOffer = true;
										this.offerVariables.phoneSelected = 'DHP';
										state = false;
									} else if (item.offerCategory === 'VOICE-DHP' && item.action === 'REMOVE') {
										this.offerVariables.removeSelectedReason = retVal.removeReason;
										this.offerVariables.removedProductItem.push(item);
										this.offerVariables.dhpExisting = true;
										this.offerVariables.isDHPRemoved = true;
										state = false;
									}
									if (item.offerCategory === 'VOICE-HP' && item.action !== 'REMOVE') {
										if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.hpExisting = true; }
										if(item.action === 'ADD' && item.offerType !== 'SUBOFFER') { this.offerVariables.hpExisting = false; }
										this.offerVariables.phoneOffer = true;
										this.offerVariables.phoneSelected = 'HMP';
										if (item.offerType !== 'SUBOFFER') {
											this.offerVariables.selectedPhoneOfferdId  = item.productOfferingId;
											this.offerVariables.selectedHP = item.productOfferingId;
										}
										state = false;
									} else if (item.offerCategory === 'VOICE-HP' && item.action === 'REMOVE') {
										this.offerVariables.removeSelectedReason = retVal.removeReason;
										this.offerVariables.removedProductItem.push(item);
										this.offerVariables.hpExisting = true;
										this.offerVariables.hpOfferType = item.offerType;
										this.offerVariables.isHPRemoved = true;
										state = false;
									}
									if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
										if (item.offerType === 'SUBOFFER') {
											this.offerVariables.existingAddonsHSI = item;
										}
										this.offerVariables.internetCheck = true;
									} else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
										if (item.offerType === 'SUBOFFER') {
											this.offerVariables.removeSelectedReason = retVal.removeReason;
											this.offerVariables.removedProductItem.push(item);
											this.offerVariables.existingAddonsHSI = item;
										}
									}
								});
							}
						}
						state = true;
						this.offerVariables.calledFromConstructor = true;
						this.offerHelperService.fetchExistingProducts(this.offerVariables, this.offerVariables.existingServices);
						if (this.offerVariables.internetCheck) {
							this.offerVariables.internerOffer = this.offerVariables.qualifiedFilter;
							let filterSpeed = false;
							if (this.offerVariables.fromHold && this.offerVariables.internerOffer && this.offerVariables.internerOffer.length > 0) {
								this.offerVariables.cartCopyObject.payload.cart.customerOrderItems.forEach(orderItem => {
									if (orderItem.offerCategory === GenericValues.iData) {
										filterSpeed = this.filterCheck(orderItem, filterSpeed);
										if (!filterSpeed) {
											filterSpeed = this.filterCheck(orderItem, filterSpeed);
											if (!filterSpeed) {
												filterSpeed = this.filterCheck(orderItem, filterSpeed);
											}
										}
									}
								})
							}
						}
						this.offerVariables.internetCheck ? this.offerHelperService.retrieveOffers(this.offerVariables, true, "fromSlot") : this.offerHelperService.retrieveOffers(this.offerVariables, true);
					}
				})
			)
			if (retSubscribe !== undefined)
				retSubscribe.unsubscribe();
		} else {
			if (!this.offerVariables.taskId) this.offerVariables.taskId = data.orderInit.taskId;
			if (!state) {

				let moreServices;
				if (this.offerVariables.existingObject && this.offerVariables.existingObject.existingProductsAndServices && this.offerVariables.existingObject.existingProductsAndServices[0] &&
					this.offerVariables.existingObject.existingProductsAndServices[0].existingServices &&
					this.offerVariables.existingObject.existingProductsAndServices[0].existingServices.existingServiceItems) {
					if ((this.offerVariables.existingObject.pendingOrders && this.offerVariables.existingObject.pendingOrders.length === 0) || !this.offerVariables.existingObject.pendingOrders || this.offerVariables.existingObject.pendingOrders === null) {
						moreServices = this.offerVariables.existingServices;
					} else if (this.offerVariables.existingObject.pendingOrders && this.offerVariables.existingObject.pendingOrders.length > 0) {
						moreServices = this.offerVariables.existingObject.pendingOrders[0] && this.offerVariables.existingObject.pendingOrders[0].orderDocument &&
							this.offerVariables.existingObject.pendingOrders[0].orderDocument.customerOrderItems;
						this.offerVariables.existingServices = moreServices;
					}
				}
				this.dropDownPopulationforHP(this.offerVariables.existingServices, false);
				this.offerVariables.retainedPotsBooleans = {
					wireMaintainance: this.offerVariables.wireMaintainance,
					voiceMail: this.offerVariables.voiceMail,
					retainValueForPotsJack: this.offerVariables.retainValueForPotsJack
				}
				if (this.offerVariables.isPendingFlow && !moreServices) moreServices = this.offerVariables.holdedObjects.orderDocument.customerOrderItems
				if (moreServices !== undefined && moreServices.length > 0) {
					moreServices.map((item) => {
						if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
							this.offerVariables.hsiExisting = true;
							if (item.offerType === 'SUBOFFER') {
								this.offerVariables.existingAddonsHSI = item;
							}
							this.offerVariables.internetCheck = true;
							this.offerVariables.newInternetCheck = true;
						}
					});
				}

				if (moreServices !== undefined && moreServices.length > 1) {
					moreServices.map((item) => {
						if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
							this.offerVariables.hsiExisting = true;
						}
						if (item.offerCategory === 'VIDEO-PRISM' && item.action !== 'REMOVE') {
							this.offerVariables.videoOffer = true;
							this.offerVariables.videoSelected = 'PTV';
							state = false;
						}
						if (item.offerCategory === 'VIDEO-DTV' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
							this.offerVariables.dtvExisting = true;
							this.offerVariables.videoOffer = true;
							this.offerVariables.videoSelected = 'DTV';
							state = false;
						}
						if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
							this.offerVariables.dhpExisting = true;
							this.offerVariables.phoneOffer = true;
							this.offerVariables.phoneSelected = 'DHP';
							state = false;
						}
						if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
							this.offerVariables.selectedHP = item.productOfferingId;
							this.offerVariables.selectedPhoneOfferdId  = item.productOfferingId;
							this.offerVariables.hpExisting = true;
							this.offerVariables.hpOfferType = item.offerType;
							this.offerVariables.phoneOffer = true;
							this.offerVariables.phoneSelected = 'HMP';
							state = false;
						}
						if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
							if (item.offerType === 'SUBOFFER' && item.action !== 'REMOVE') {
								this.offerVariables.existingAddonsHSI = item;
							}
							this.offerVariables.internetCheck = true;
						}
					});
				}
				if (!this.offerVariables.internetCheck && moreServices !== undefined && moreServices.length >= 1) {
					moreServices.map((item) => {
						if (item.offerCategory === 'VOICE-HP' && item.action !== 'REMOVE') {
							this.offerVariables.hpExisting = true;
							this.offerVariables.phoneOffer = true;
							this.offerVariables.phoneSelected = 'HMP';
							state = false;
						}
					});
				}

				if (this.offerVariables.hsiCatalogId === undefined && moreServices) {
					moreServices.map((item) => {
						if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
							this.offerVariables.hsiCatalogId = item.catalogId;
							this.offerVariables.cartContractTerm = item.contractTerm;
						}
						if (item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') {
							this.offerVariables.phoneCatalogId = item.catalogId;
							this.offerVariables.cartContractTermDHP = item.contractTerm;
						}
						if (item.offerCategory === 'VIDEO-DTV') {
							this.offerVariables.dtvCatalogId = item.catalogId;
							this.offerVariables.cartContractTermDTV = item.contractTerm;
						}
					});
				}

				state = true;
				this.offerVariables.calledFromConstructor = true;
				this.offerHelperService.retrieveOffers(this.offerVariables, true, 'fromSlot');
			}
			this.offerHelperService.fetchExistingProducts(this.offerVariables, this.offerVariables.existingServices);
		}
		this.getRemoveResponse();
		return state;
	}

	private availableExistingProds() {
		this.offerVariables.existingServices && this.offerVariables.existingServices.map((data) => {
			if (!data.customerOrderSubItems && data.existingServiceSubItems) {
				data.customerOrderSubItems = data.existingServiceSubItems;
			}
			if (data.offerCategory === GenericValues.cHP && data.offerType !== 'SUBOFFER') {
				let subOrder = data.customerOrderSubItems ? data.customerOrderSubItems : data.existingServiceSubItems;
				subOrder && subOrder.map((voiceData) => {
					if (voiceData.productName === "Voice Messaging") {
						this.offerVariables.voiceMailCondi = true;
					}
					else if (voiceData.productName.indexOf('Wire Maintenance Plan') !== -1) {
						this.offerVariables.wireMaintainCondi = true;
					}
					else if (voiceData.productName.indexOf('Jack and Wire') !== -1) {
						this.offerVariables.retainValueForPotsJack = voiceData.productAttributes[0].compositeAttribute[0].attributeValue;
					}
					else if (voiceData.productName.indexOf('Extended Area Calling') !== -1) {
						this.offerVariables.isExtendedAreaCallingExits = voiceData.productAttributes[0].compositeAttribute[0].attributeValue;
					}
				});
			}
		});
	}
	
	private dropDownPopulationforHP(existingItems: any, flag) {
		this.offerVariables.voiceMail = false;
		this.offerVariables.wireMaintainance = false;
		existingItems && existingItems.map((data) => {
			if (data.offerCategory === GenericValues.cHP && data.offerType !== 'SUBOFFER') {
				data.customerOrderSubItems && data.customerOrderSubItems.map((voiceData) => {
					if (voiceData.productName === "Voice Messaging") {
						this.offerVariables.voiceMail = true;
					}
					else if (voiceData.productName.indexOf('Wire Maintenance Plan') !== -1) {
						this.offerVariables.wireMaintainance = true;
					} else if (voiceData.productName.indexOf('Jack and Wire') !== -1) {
						this.offerVariables.retainValueForPotsJack = voiceData.productAttributes[0].compositeAttribute[0].attributeValue;
						if (this.offerVariables.retainValueForPotsJack !== undefined && this.offerVariables.retainValueForPotsJack && this.offerVariables.retainedPotsBooleans !== undefined) {
							this.offerVariables.retainedPotsBooleans.retainValueForPotsJack = this.offerVariables.retainValueForPotsJack;
						}
					}
				});
			}
		});
	}

	public ngOnInit() {
		window.scroll(0, 0);
		this.offerHelperService.getReentrantFlags(this.offerVariables);
		this.offerHelperService.compatibilityAPIcall(this.offerVariables);
		this.existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
			this.offerVariables.exisitngData = respData
		});
		this.offerHelperService.setDiscountsFromExistingDiscounts(this.offerVariables, this.offerVariables.existingDiscounts);
		this.store.dispatch({
			type: "UPDATE_USER",
			payload: { currentSelected: { type: "", selected: "" } }
		});
		this.logger.metrics("OfferBillingPage");
	}

  private filterCheck(orderItem: CustomerOrderItems, filterSpeed: boolean) {
		this.offerVariables.internerOffer.forEach(offer => {
			if (offer.productOffer.productOfferingId === orderItem.productOfferingId) {
				filterSpeed = true;
			}
		});
		return filterSpeed;
	}

	public filterObj: filterObjModel = {
		name: "All Speed options",
		isExist: true
	};

	public makeUndefined(type: string) {
		switch (type) {
			case "install":
				this.offerVariables.selectedInstallation = undefined;
				break;
			case "modem":
				this.offerVariables.selectedModem = undefined;
				break;
			case "ease":
				this.offerVariables.selectedEase = undefined;
				break;
			case 'secureWifi': 
				this.offerVariables.selectedSecureWifi = undefined; 
				break;	
			case "jack":
				this.offerVariables.selectedJack = undefined;
				break;
		}
	}

	public ngOnDestroy() {
		if (this.userSubscription !== undefined) {
			this.userSubscription.unsubscribe();
		}
		if (this.existingSubscription !== undefined) {
			this.existingSubscription.unsubscribe();
		}
		if (this.orderSubscription !== undefined) {
			this.orderSubscription.unsubscribe();
		}
		if (this.pendingSubscription !== undefined) {
			this.pendingSubscription.unsubscribe();
		}
	}

	public getRemoveResponse() {
		let request: any = {
			rsnType: "DISCONNECT"
		};
		this.offerVariables.loading = false;
		this.logger.log("info", "offer-billing.component.ts", "getResponseForRemoveRequest", JSON.stringify(request));
		this.logger.startTime();
		this.productService
			.getResponseForRemove(request)
			.catch((error: any) => {
                this.logger.endTime();
				this.logger.log("error", "offer-billing.component.ts", "getResponseForRemoveResponse", JSON.stringify(error));
				this.logger.log("error", "offer-billing.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
				this.offerVariables.loading = false;
				this.systemErrorService.logAndRouteUnexpectedError("error",	"Not Applicable", "Submit Task", "offer-billing.component.ts", "Remove Response - Offer Page", error);
				return Observable.throwError(null);
			})
			.subscribe(
				respData => {
					this.logger.endTime();
					this.logger.log("info", "offer-billing.component.ts", "getResponseForRemoveResponse", JSON.stringify(respData));
					this.logger.log("info", "offer-billing.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					this.offerVariables.loading = false;
					if(respData && respData.bmReasonCodes) this.offerVariables.removeResponse = respData.bmReasonCodes;
				},
				error => {
					this.logger.endTime();
					this.logger.log("error", "offer-billing.component.ts", "getResponseForRemoveResponse", JSON.stringify(error));
					this.logger.log("error", "offer-billing.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					this.offerVariables.loading = false;
					if (error === undefined || error === null) return;
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						this.offerVariables.apiResponseError = JSON.parse(error);
						if (
							this.offerVariables.apiResponseError !== undefined &&
							this.offerVariables.apiResponseError !== null &&
							this.offerVariables.apiResponseError.errorResponse &&
							this.offerVariables.apiResponseError.errorResponse.length > 0
						) {
							this.systemErrorService.logAndeRouteToSystemError(
								"error",
								"selectProductError ",
								"offer-billing.component.ts",
								"Offers Page",
								this.offerVariables.apiResponseError
							);
						} else unexpectedError = true;
					} else unexpectedError = true;
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
							this.offerVariables.orderRefNumber
						);
						this.systemErrorService.logAndeRouteToSystemError(
							"error",
							"selectProductError ",
							"offer-billing.component.ts",
							"Offers Page",
							lAPIErrorLists
						);
					}
					this.offerVariables.retrieveOffersLoading = false;
				}
			);
	}

	public undoAll() {
		this.offerVariables.loading = true;
		this.initilizeAll();
		this.ngOnInit();
		this.offerVariables.undoFlag = false;
		this.offerVariables.loading = false;
	}

}