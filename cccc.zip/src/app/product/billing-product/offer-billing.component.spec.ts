import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OfferBillingComponent } from './offer-billing.component';
import { Routes, Router, RouterModule } from '@angular/router';
import { MockServer } from 'app/MockServer.test';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger, MockRouter, MockProductService, MockDisconnectService, MockHelperService, MockOfferHelperService, MockAppStateService, MockSystemErrorService, MockPendingOrderService, MockCountryStateService, MockReviewOrderService, MockAccountService, MockAddressService, MockBlueMarbleService, MockDirectvService, MockPropertiesHelperService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { Store } from '@ngrx/store';
import { Observable, throwError } from 'rxjs';
import { ProductService } from 'app/common/service/product.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { TooltipModule } from 'ngx-bootstrap';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import 'rxjs/add/observable/of';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpResponse } from '@angular/common/http';

const routes: Routes = [
  {
      path: '', component: OfferBillingComponent
  }
];

describe('OfferBillingComponent', () => {
  let component: OfferBillingComponent;
  let fixture: ComponentFixture<OfferBillingComponent>;
  let mockServer = new MockServer();
  const mockRedux: any = {
    dispatch() { },
    configureStore() { },
    select(reducer) {
        return Observable.of(mockServer.getBillingMockStore("BILLING_HSI_TILL_ORDER_COFIRMATION")[reducer]);
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
}

  // billing component provides list
  let p1 = { provide: Logger, useClass: MockLogger };
  let p2 = { provide: Store, useValue: mockRedux };
  let p3 = { provide: Router, useClass: MockRouter };
  let p4 = { provide: ProductService, useClass: MockProductService };
  let p5 = { provide: AppStateService, useClass: MockAppStateService };
  let p6 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  let p7 = { provide: DisconnectService, useClass: MockDisconnectService };
  let p8 = CTLHelperService;
  let p9 = { provide: HelperService, useClass: MockHelperService };
  let p10 = { provide: OfferHelperService, useClass: MockOfferHelperService };

  // dialog component providers list
  let dp1 = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  let dp2 = {provide: PendingOrderService, useClass: MockPendingOrderService};
  let dp3 = {provide: AccountService, useClass: MockAccountService};
  let dp4 = {provide: AddressService, useClass: MockAddressService};
  let dp5 = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  let dp6 = {provide: CountryStateService, useClass: MockCountryStateService};
  let dp7 = {provide: DirectvService, useClass: MockDirectvService};
  let dp8 = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};

  const base_providers = [p1,p2,p4,p5,p6,p7,p8,p9,p10,dp1,dp2,dp3,dp4,dp5,dp6,dp7,dp8]
  const base_imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    RouterModule.forChild(routes),
    SharedModule,
    SharedCommonModule,
    TooltipModule.forRoot(),
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ]

  let baseConfig = {
    imports: base_imports,
    declarations: [OfferBillingComponent],
    providers: base_providers
  };
  describe('BR loading checking',()=>{
    
  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferBillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create offer billing component', () => {
    expect(component).toBeTruthy();
  });

  it('should have ORN, process instance id and task id defined', () => {
    expect(component.offerVariables.orderRefNumber).toEqual('ORN-1166982822457779');
    expect(component.offerVariables.processInstanceId).toEqual('d7059d00-5ecc-11ea-a066-cef400a61cea');
    expect(component.offerVariables.taskId).toEqual('d7cda81a-5ecc-11ea-a066-cef400a61cea');
  });

  it('should assign enabledServiceList from the store', () => {
    expect(component.offerVariables.enabledServiceList).toEqual(mockServer.getMockStore("onload-BRPage")['user'].enabledServiceList);
  });

  xit('should create offer billing component', () => {    
    component.offerVariables = mockServer.getOfferHelperDetails('offer-variable')
    component.offerVariables.isReEntrant = true
    component.offerVariables.reentrantUI = true
    component.offerVariables.reEntrantLoaded = false
    expect(component).toBeTruthy();
  });
  it('Excute undo all Method',()=>{
    component.undoAll()
    expect(component.offerVariables.loading).toBeFalsy();
  })

  it('Excute makeUndefined Method',()=>{
    component.makeUndefined("install")
    expect(component.offerVariables.selectedInstallation).toBe(undefined);
  })
  it('Excute makeUndefined Method',()=>{
    component.makeUndefined("modem")
    expect(component.offerVariables.selectedModem).toBe(undefined);
  })
  it('Excute makeUndefined Method',()=>{
    component.makeUndefined("ease")
    expect(component.offerVariables.selectedEase).toBe(undefined);
  })
  it('Excute makeUndefined Method',()=>{
    component.makeUndefined("jack")  
    expect(component.offerVariables.selectedJack).toBe(undefined);
  })
  it('Excute makeUndefined Method',()=>{
    component.makeUndefined("secureWifi")
    expect(component.offerVariables.selectedSecureWifi).toBe(undefined);
  })

  it('Excute callApiForChange Method',()=>{
    let arg1 = mockServer.getBillingMockStore("onload-billing-scheduling")['user']
    let data = mockServer.getBillingMockStore("BILLING_HSI_TILL_ORDER_COFIRMATION")['existingProducts']
    component.callApiForChange(arg1, false,data)
    expect(component.offerVariables.selectedSecureWifi).toBe(undefined);
  })


  })
  describe('Throw error in getRemoveResponse() - Failed Response', () => {
    class MockProductService {
      getResponseForRemove() {
        const data: any = {errorResponse: []};
        return throwError(new HttpResponse(data));
      }
    }
    class MockAppStateService{
      getState(){
        return mockServer.getBillingMockStore("onload-billing-scheduling")
      }
      
    }
    const blueMarbleService = {provide: ProductService, useClass: MockProductService};

    const _providers = [ ...base_providers, blueMarbleService];
    

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: base_imports,
        declarations: [ OfferBillingComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(OfferBillingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
    it('should create offer billing component', () => {
      expect(component).toBeTruthy();
    });
  
    it('getRemoveResponse, should get error response and it should execute catch block', () => {
      component.getRemoveResponse();
      expect(component.offerVariables.loading).toBeFalsy();
    });
  });

});  