import { ChangeDetectorRef, Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { User } from 'app/common/models/user.model';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { InternetConfigurationComponent } from 'app/product/internet-configuration/internet-configuration.component';
import { PhoneConfigurationComponent } from 'app/product/phone-configuration/phone-configuration.component';
import { cloneDeep, filter, find } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../common/logging/default-log.service';
import { AppStore } from '../common/models/appstore.model';
import { CustomerOrderItems, ShoppingCart } from '../common/models/cart.model';
import { APIErrorLists, ErrorResponse, GenericValues, serverErrorMessages } from '../common/models/common.model';
import { ConfigDetails, ConfigItems, CustomizeServices, FormItems, ProductConfiguration } from '../common/models/customize-services.model';
import { Products, AttributesCombination } from '../common/models/product.model';
import { AppStateService } from '../common/service/app-state.service';
import { ProductService } from '../common/service/product.service';
import { SystemErrorService } from '../common/service/system-error.service';
import { ProfileEnums } from '../common/enums/profileEnums';
import { HelperService } from '../common/service/helper.service';
import { OfferHelperService } from '../common/service/offerHelper.service';
import { AppConstant, RE_ENTRANT_OFFERVARIABLE } from 'app/app.constant';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisclosuresRes } from 'app/common/models/disclosures.model';
import * as _ from 'lodash';
import "rxjs/add/operator/catch";
import { VacationEnums } from '../common/enums/vacationEnums';


@Component({
    selector: 'product-customize-services',
    templateUrl: './customize-services.component.html',
    styleUrls: ['./customize-services.component.scss']
})

export class CustomizeServicesComponent implements OnInit, OnDestroy, AfterViewInit {
    public retainDiscountData: any;
    public isNewInstall: boolean;
    public isDisclosureAddedDiscAllowed: boolean;
    public isSelectedGiftCardDiscounts: boolean;
    public isSelectedDiscounts: boolean;
    public vacationflow: any;
    public vacationFlow: any;
    public vacationCartData: any;
    public nonPubSelecetd: boolean = false;
    public NIPendingStackAmend: boolean = false;
    public cartObjectChanged: boolean = true;
    public discloserPopUpSelected: boolean = false;
    public listingNameData: any = [];
    public selectedListingOptionValue: any;
    public nonpubNoChargeSelected: boolean = false;
    public isProfileLifelineDiscount: boolean = false;
    public hideLifelineOption: boolean = false;
    public addedDiscounts: any = [];
    public existingDiscArray: any = [];
    public selectedDiscounts: any = [];
    public selectedGiftCardData: any;
    public portingTnResponse: boolean = false;
    public simplePortTN: any;
    public switchType: any;
    public lifelineDHP: boolean = false;
    public lifelinePots: boolean = false;
    public lifelineInternet: boolean = false;
    public agentCuid: any;
    public disableCloserandPromos: boolean = true;
    public simpleportCustData: any;
    public lifelineHsiRemove: boolean = false;
    public addedLifelineInternet: boolean = false;
    public lifelineexisting: boolean = false;
    public lifelineResProducts: any;
    public lifelineResConfig: any;
    public lifelineResDiscounts: any;
    public lifelinePOtsRemove: boolean = false;
    public lifelineCheckoutReq: boolean = true;
    public lifelinepotsValidation: boolean;
    public lifelineValidation: boolean;
    public enableCloserPromoNIFlow: boolean = false;
    public showHide: any;
    public phoneConfigObj: any;
    public productDHPDet: any;
    public productInternetDet: any;
    public selectedLifelineType: string;
    public productPotsDet: any;
    public observable;
    public custSubscription: Subscription;
    public custdata;
    public lifelineTotalResponseData: any;
    public disableLifelineOption: boolean = false;
    public lifelineResAdjustments: any;
    public refObj: any = {
        isUndo: false,
        disableInternet: true,
        disablePrism: true,
        disablePhone: true,
        disableClosure: true,
        disableDtv: true,
        disableHp: true
    };
    public selectedObjectsList = [];
    public isUndoAll: boolean = false;
    public cartSubscription: Subscription;
    public cartObj;
    public internetActive: boolean = true;
    public prismActive: boolean = false;
    public phoneActive: boolean = false;
    public dtvActive: boolean = false;
    public hpActive: boolean = false;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public catalogSpecId: any;
    public isFirstOpen: boolean = true;
    public potsAddonOffers: any;
    public dhpAddonOffers: any;
    public videoCData = [];
    public hsiCData = [];
    public dhpCData = [];
    public hpCData = [];
    public reservedTNs = [];
    public reservedTN: string;
    public macd: boolean = false;
    public toNext: boolean = false;
    public productRequires: boolean = false;
    public productMsg: string;
    public phoneConfigInputData: any = {
        tnData: {
            haveData: true,
            reservedTNs: [],
            selectedTN: ''
        },
        listingData: {
            haveData: true,
            optionsArray: [],
            configItems: []
        },
        ldCarrierData: {
            haveData: true,
            interLataArray: [],
            intraLataArray: []
        },
        voiceMailData: {
            haveData: true,
            mesageIndicatorArray: [],
            ringCycleArray: []
        },
        callForwarding: {
            haveData: true,
            selected: false,
            callForwardingNoAnswer: false,
            callForwardingBusy: false,
            ringCycleArray: [],
            fwdOnBusy: []
        },
        configType: 'dhp',
        orderReferenceNumber: ''
    };
    public collections: any = [];
    public accNoErrorMsg: boolean = false;
    public isDisablePOTSVoiceMail: boolean = false;
    public exPhoneConfigInputData: any;
    public phoneConfigForm: FormGroup;
    public phoneConfigError: any = {};
    public selectedProduct: any;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public customizeSubscription: Subscription;
    public existingData: any;
    public isReEntrant: boolean = false;
    public taskId: string = '';
    public cartObject: CustomerOrderItems[] = [];
    public isMove: boolean = false;
    public isChange: boolean = false;
    public isBilling: boolean = false;
    public userStore: Observable<User>;
    public potsComponent: any;
    public primaryPOTS: any;
    public accordianHandling = {
        tn: false,
        listing: false,
        ldCarrier: false,
        voice: false,
        callforwarding: false
    }
    public dhpExisting: boolean = false;
    public hpExisting: boolean = false;
    public hsiExisting: boolean = false;
    public prismExisting: boolean = false;
    public dtvExisting: boolean = false;
    public existingServices: any;
    public isHPTabClicked: boolean = false;
    public existingConfiguration: any;
    public existingConfigurationDHP: any;
    public isChangeAction: boolean = false;
    public portedType: string;
    public addlPortingData: any;
    public addlPortingDataAccountId: any;
    public potsPortedCheck: string;
    public savedPhoneTN: any;
    public workingTN: string;
    public compatibilityArray: any;
    public existingDTVAccountId;
    public listingToCart;
    public mandatorySubOffers: any[] = [];
    public lifeLineMasterQualProgList: any;
    public lifelineReponseData: any;
    public lifelineRespData: any;
    public lifeLineMasterRecurringCredits: any;
    public lifeLineMasterNonRecurringCredits: any;
    public lifeLineMasterQualProgListInternet: any;
    public lifelineReponseDataInternet: any;
    public lifelineRespDataInternet: any;
    public lifeLineMasterRecurringCreditsInternet: any;
    public lifeLineMasterNonRecurringCreditsInternet: any;
    public lifeLineMasterQualProgListPots: any;
    public lifelineReponseDataPots: any;
    public lifelineRespDataPots: any;
    public lifeLineMasterRecurringCreditsPots: any;
    public lifeLineMasterNonRecurringCreditsPots: any;
    public lifeLineMasterQualProgListDhp: any;
    public lifelineReponseDataDhp: any;
    public lifelineRespDataDhp: any;
    public lifeLineMasterRecurringCreditsDhp: any;
    public lifeLineMasterNonRecurringCreditsDhp: any;
    public selectedProg: any;
    @ViewChild('phoneConfiguration', { static: false, }) public phoneConfiguration: PhoneConfigurationComponent;
    @ViewChild('lifeLineAccordion', { static: false, }) public internetConfigurationComponent: InternetConfigurationComponent;
    public previousUrl: string = '';
    public selectedListedAddressOption: any;
    public updatedListedAddressFields: any;
    public formRule: string = '';
    public potsOfferName: string = '';
    public potsOfferType: string = '';
    public lataList: any;
    public restrictivePotsSelected = false;
    public exSelectedListing;
    public existingListingDirectory;
    public exSelectedListingDHP;
    public existingListingDirectoryDHP;
    public addressListing;
    public changedListedAddress;
    public isPOTSRemoved = false;
    public portingNotComplete = false;
    public newChangeTn = false;
    public portedreq: boolean;
    public orderRefNumber: string;
    public phonePlan: boolean = false;
    public productName: string;
    public callDetailPlan: string;
    public applicableGiftcard: any[];
    public selectedGiftcard: any = [];
    public isDtvOpus: boolean;
    public dtvConfigForm: FormGroup;
    public switchData: any;
    public newReserveTNObject: any;
    public actionAccess: string = '';
    private tnType = '';
    public isVacSusFlow: boolean = false;

    // vacation restore variable
    private vacRequest: any;
    private vacOrderRefNumber: any;
    private vacTaskId: any;
    private vacProcessInstanceId: any
    private vacResCart: any;
    public isVacResFlow: boolean = false;
    private vacationObservable: any;
    private vacationSubscription: any;
    public isProfileReadOnly: boolean;
    public isAmend: boolean;
    public isAmendOrStack: boolean;
    public isStack: boolean;
    public reentrantvacTaskId: any;
    public amendMessage = AppConstant.AMEND_MESSAGE;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    public userSubscription: Subscription;
    public fromHold: boolean = false;
    public reqDeposit: boolean = false;
    public pendingObservable: Observable<any>;
    public pendingSubscription: Subscription;
    public flushCart: boolean = false;
    public newHSI: boolean = false;
    public newPOTS: boolean = false;
    public stackLifeLine: boolean;
    public loadingNext = false;
    public cartObjCalled = false;
    public deviceSelected: any;
    public techInstallAdded: boolean = false;
    public isDeviceSelected: boolean = true;
    public deviceValues: any;
    public isSubmitted: boolean = false;
    public loadedInitialize: boolean = false;
    public isLatestPendingOrderNI: boolean;
    public isBypassed: boolean = false;
    public isPrepaid: boolean = false;
    public wireCenter: any;
    public state: any;
    public city: any;
    public legacyProvider: any;
    public undoChangesSub: any;
    public ban: any;
    public potsExistingOnCompleted: boolean = false;
    public hsiExistingOnCompleted: boolean = false;
    public isModemConverted: boolean = false;
    public isPOTSChanged: boolean = false;
    public wliLocationAvail: any;

    constructor(
        private logger: Logger,
        private router: Router,
        private store: Store<AppStore>,
        private appStateService: AppStateService,
        private productService: ProductService,
        private changeDetector: ChangeDetectorRef,
        private fb: FormBuilder,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private bMService: BlueMarbleService,
        private offerHelperService: OfferHelperService,
        private helperService: HelperService,
        private disclosuresService: DisclosuresService
    ) {
        this.loading = true;
        this.isProfileReadOnly = helperService.isAuthorized(ProfileEnums.READ_ONLY);
        this.exPhoneConfigInputData = cloneDeep(this.phoneConfigInputData);
        this.observable = <Observable<CustomizeServices>>store.select('customize');
        let cartObservable = <Observable<ShoppingCart>>store.select('cart');
        this.appStateService.setLocationURLs();
        this.existingObservable = <Observable<any>>store.select('existingProducts');
        this.userStore = this.store.select('user');
        this.userSubscription = this.userStore.subscribe((userData) => {
            if (userData && userData.locationAvailable) {
                this.wliLocationAvail = userData.locationAvailable;
            }
        });
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            if (data && data.orderFlow && data.orderFlow.flow && data.orderFlow.flow.toUpperCase() === "NEWINSTALL") {
                this.isNewInstall = true;
            }
            if (data && data.NIPendingStackAmend) {
                this.NIPendingStackAmend = data.NIPendingStackAmend;
            }
            if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].serviceAddress
                && data.existingProductsAndServices[0].serviceAddress.locationAttributes) {
                this.wireCenter = data.existingProductsAndServices[0].serviceAddress.locationAttributes.wirecenter;
                this.city = data.existingProductsAndServices[0].serviceAddress.city;
                this.state = data.existingProductsAndServices[0].serviceAddress.stateOrProvince;
                this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
            }
        });
        this.vacationObservable = <Observable<any>>store.select('vacation');
        this.custSubscription = this.observable.subscribe((data) => {
            if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
                data.payload.cart.customerOrderItems.map(cust => {
                    if (cust && cust.customerOrderSubItems && (cust.offerCategory === GenericValues.cHP && !this.isReEntrant
                        && cust.offerType !== 'P4L')) {
                        this.flushCart = true;
                    } else if (cust && cust.customerOrderSubItems && cust.offerCategory === GenericValues.iData &&
                        cust.action === 'ADD') {
                        this.newHSI = true;
                    }
                    if (cust && cust.customerOrderSubItems && (cust.offerCategory === GenericValues.cHP
                        && cust.action === 'ADD')) {
                        this.newPOTS = true;
                    }
                })
            }
            if (data.isLifelineActive) {
                this.hideLifelineOption = true;
            }
        });
        this.isProfileLifelineDiscount = this.helperService.isAuthorized(ProfileEnums.LIFELINE_DISCOUNT);
        if (this.custSubscription !== undefined) this.custSubscription.unsubscribe();
        let curStore = this.appStateService.getState();
        let data: any = curStore.user;
        if (data && data.autoLogin && data.autoLogin !== undefined && data.autoLogin.oamData && data.autoLogin.oamData.agentCuid !== undefined) {
            this.agentCuid = data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
        }
        this.selectedProduct = data && data.currentSelected;
        let obj = null;
        this.cartObj = curStore && curStore.cart && curStore.cart.payload && curStore.cart.payload.cart;
        for (let k = 0; k < this.selectedProduct.length; k++) {
            obj = this.productService.findObjByName(this.cartObj.customerOrderItems, 'productType', this.selectedProduct[k].selected);
            switch (this.selectedProduct[k].selected) {
                case GenericValues.sData: this.refObj.disableInternet = false; break;
                case GenericValues.iData: this.refObj.disableInternet = false; break;
                case GenericValues.cVideo: this.refObj.disablePrism = false; break;
                case GenericValues.cDHP: this.refObj.disablePhone = false; break;
                case GenericValues.cHP:
                    this.refObj.disableHp = false;
                    this.phoneConfigInputData.configType = 'hp';

                    break;
                case GenericValues.cDTV: this.refObj.disableDtv = false; break;
                default:
                    break;
            }
        }
        this.isReEntrant = data && data.reEntrant;
        this.taskId = data && data.taskId;
        this.previousUrl = data && data.previousUrl;
        if (data && data.previousUrl !== '/move-product' && data.previousUrl !== '/product-offer' && data.previousUrl !== '/offer-change' && data.previousUrl !== '/billing-product' && data.previousUrl !== '/vacation-product-offer' && data.previousUrl !== '/stack-amend-product' && data.previousUrl !== '/vacation-option') {
            this.isReEntrant = true;
        }
        if (data.previousUrl === '/move-product') {
            this.existingServices = data && data.orderInit && data.orderInit.payload && data.orderInit.payload.existingLocation && data.orderInit.payload.existingLocation.existingServices &&
                data.orderInit.payload.existingLocation.existingServices.existingServiceItems;
            this.macdFlow(data, this.existingServices, true);
            this.isMove = true;
        }
        if (data.previousUrl === '/billing-product') {
            this.existingServices = data && data.orderInit && data.orderInit.payload && data.orderInit.payload.cart && data.orderInit.payload.cart.customerOrderItems;
            if (!this.existingServices) {
                let curStore = this.appStateService.getState().existingProducts;
                if (curStore && curStore.existingProductsAndServices && curStore.existingProductsAndServices[0] && curStore.existingProductsAndServices[0].existingServices &&
                    curStore.existingProductsAndServices[0].existingServices.existingServiceItems) {
                    curStore.existingProductsAndServices[0].existingServices.existingServiceItems.map(exSub => {
                        if (!exSub.customerOrderSubItems) exSub.customerOrderSubItems = exSub.existingServiceSubItems;
                    })
                    this.existingServices = curStore.existingProductsAndServices[0].existingServices.existingServiceItems;
                }
            }
            this.macdFlow(data, this.existingServices, false)
            this.isBilling = true;
        }
        if (!this.isReEntrant && curStore && curStore.retain && curStore.retain.potsBooleans && curStore.retain.potsBooleans.isPOTSChanged) {
            this.isPOTSChanged = curStore.retain.potsBooleans.isPOTSChanged;
        }
        if (data.previousUrl === '/offer-change') {
            this.isChange = true;
        }
        if (this.isChange || this.isMove || this.isBilling) {
            this.macd = true;
        }
        if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress) {
            this.addressListing = data.orderInit.payload.serviceAddress;
        }
        if (data && data.orderRefNumber) {
            this.orderRefNumber = data.orderRefNumber;
        }
        let pendingObj: any;
        this.pendingObservable = this.store.select('pending');
        this.pendingSubscription = this.pendingObservable.subscribe(pending => {
            pendingObj = pending;
            if (pending && pending.orderReference && pending.orderReference.customerOrderType === 'NEWINSTALL') {
                this.isLatestPendingOrderNI = true;
            }
            pending && pending.orderDocument && pending.orderDocument.creditReview && pending.orderDocument.creditReview.depositInfo &&
                pending.orderDocument.creditReview.depositInfo.depositRequired ? this.reqDeposit = true : this.reqDeposit = false;
        });
        if (!this.cartObjCalled) this.existingServiceObservable(data, pendingObj);

        if (data) {
            this.isDtvOpus = data.isDtvOpus;
        }

        if (data && data.dtvOpus && this.isDtvOpus) {
            this.existingDTVAccountId = data.dtvOpus.accNo;
        }
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            this.vacationFlow = data.vacationflow;
            if (data && data !== undefined && data.vacationrestorescheduleresponse && data.vacationrestorescheduleresponse !== undefined && data.vacationrestorescheduleresponse.taskId && data.vacationrestorescheduleresponse.taskId !== undefined) {
                this.reentrantvacTaskId = data.vacationrestorescheduleresponse.taskId;
            }
            if (data && data.vacResCart && data.vacResCart.payload && data.vacResCart.payload.cart) {
                this.vacResCart = data.vacResCart.payload.cart;
            }
            if (data.responseData && data.responseData.orderRefNumber) {
                this.vacOrderRefNumber = data.responseData.orderRefNumber;
            }
            if (data.responseData && data.responseData.taskId) {
                this.vacTaskId = data.responseData.taskId;
            }
            if (data.responseData && data.responseData.processInstanceId) {
                this.vacProcessInstanceId = data.responseData.processInstanceId;
            }
            if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacResFlow) this.isVacResFlow = true;
                else this.isVacResFlow = false;
                if (data.vacFlowName.isVacSusFlow) this.isVacSusFlow = true;
                else this.isVacSusFlow = false;
            }
        });

        this.userStore = <Observable<any>>store.select('user');
        this.userSubscription = this.userStore.subscribe((data) => {
            data && data.prepaidFlag && data.prepaidFlag === 'PREPAID' ? this.isPrepaid = true : this.isPrepaid = false;
            if (this.isMove && data && data.orderInit && data.orderInit.payload && data.orderInit.payload.newLocation && data.orderInit.payload.newLocation.serviceAddress
                && data.orderInit.payload.newLocation.serviceAddress.locationAttributes) {
                this.wireCenter = data.orderInit.payload.newLocation.serviceAddress.locationAttributes.wirecenter;
                this.city = data.orderInit.payload.newLocation.serviceAddress.city;
                this.state = data.orderInit.payload.newLocation.serviceAddress.stateOrProvince;
                this.legacyProvider = data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider;

            } else if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes) {
                this.wireCenter = data.orderInit.payload.serviceAddress.locationAttributes.wirecenter;
                this.city = data.orderInit.payload.serviceAddress.city;
                this.state = data.orderInit.payload.serviceAddress.stateOrProvince;
                this.legacyProvider = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
        })
        //calling compatibility API to fetch rules
        this.compatibilityAPIcall();
        let isCustomizeCalled = false, type = '';
        this.existingObservable = <Observable<any>>store.select('existingProducts');
        data = curStore.existingProducts;
        if (data && data.existingDiscounts && data.existingDiscounts.orderDiscounts && data.existingDiscounts.orderDiscounts !== undefined && data.existingDiscounts.orderDiscounts.length > 0) {
            data.existingDiscounts.orderDiscounts[0].productDiscounts.map(data => {
                data.discountDetails.map(discData => {
                    this.existingDiscArray.push(discData.discountId);
                })
            })
        }

        if (data && data.stackamend && data.stackamend.stackAmendFlag) {
            if (data.stackamend.stackAmendFlag === "amendOrder") {
                this.isAmend = true;
            } else if (data.stackamend.stackAmendFlag === "stackOrder") {
                this.isStack = true;
            }
            this.isAmendOrStack = this.isAmend || this.isStack;
            if (this.isAmendOrStack) {
                this.macd = true;
            }
        }
        if (data && data.orderFlow && data.orderFlow.type === 'fromHold' && !data.orderFlow.customizeCalled) {
            this.fromHold = true;
            this.pendingObservable = this.store.select('pending');
            this.pendingSubscription = this.pendingObservable.subscribe(pending => {
                pending && pending.orderDocument && pending.orderDocument.creditReview && pending.orderDocument.creditReview.depositInfo &&
                    pending.orderDocument.creditReview.depositInfo.depositRequired ? this.reqDeposit = true : this.reqDeposit = false;
            });
            type = data.orderFlow.type;
            isCustomizeCalled = data.orderFlow.customizeCalled;
            let cartObjCalled = false;
            this.cartObject = [];
            this.cartSubscription = cartObservable.subscribe((data) => {
                if (data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems) {
                    data.payload.cart.customerOrderItems.forEach(cust => {
                        if (!cartObjCalled && cust && cust.customerOrderSubItems && (cust.offerCategory === GenericValues.cHP || cust.offerType === 'SUBOFFER')) {
                            let orderedItems: CustomerOrderItems = {
                                productType: this.getExistingProdType(cust),
                                customerOrderSubItems: cust.existingServiceSubItems ? cust.existingServiceSubItems : cust.customerOrderSubItems
                            }
                            this.cartObject.push(orderedItems);
                        }
                    });
                }
            });
            if (this.cartSubscription !== undefined) this.cartSubscription.unsubscribe();
            cartObjCalled = true;
        }
        if (data && data.orderFlow && (data.orderFlow.flow === 'Change' || data.orderFlow.flow === 'Move' || data.orderFlow.flow === 'billing' || this.isAmendOrStack)) {
            if (data.orderFlow.flow === 'Change') { this.isChange = true; }
            if (data.orderFlow.flow === 'Move') { this.isMove = true; }
            if (data.orderFlow.flow === 'billing') { this.isBilling = true; }
            this.productInternetDet = {
                ban: data && data.existingProductsAndServices && data.existingProductsAndServices[0] &&
                    data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.ban,
                productType: 'INTERNET',
                csrId: this.agentCuid
            }
            this.productPotsDet = {
                ban: data && data.existingProductsAndServices && data.existingProductsAndServices[0] &&
                    data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.ban,
                productType: 'VOICE-HP',
                csrId: this.agentCuid
            }
            this.productDHPDet = {
                ban: data && data.existingProductsAndServices && data.existingProductsAndServices[0] &&
                    data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.ban,
                productType: 'VOICE-DHP',
                csrId: this.agentCuid
            }
        }
        if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
        data = curStore.cart;
        if ((type !== 'fromHold' && data && data.payload && data.payload.customerAddonOfferItems) || (type === 'fromHold' && isCustomizeCalled)) {
            this.cartObject = data.payload.customerAddonOfferItems;
        }
        this.cartObj = data && data.payload && data.payload.cart;
        let custOrderItems: any[] = [];
        if (this.isVacResFlow) {
            data && data.payload && data.payload.cart && data && data.payload && data.payload.cart.customerOrderItems && data && data.payload && data.payload.cart.customerOrderItems.map((custOrderItem) => {
                custOrderItem && custOrderItem.customerOrderSubItems && custOrderItem.customerOrderSubItems.map((custOrderSubItem) => {
                    if (custOrderSubItem && custOrderSubItem.productType && (custOrderSubItem.productType === 'INTERNET' || custOrderSubItem.productType === 'DATA')) {
                        custOrderItem.productType = 'DATA';
                    }
                    if (custOrderSubItem && custOrderSubItem.productType && custOrderSubItem.productType === 'VOICE-HP') {
                        custOrderItem.productType = 'VOICE-HP';
                    }
                    if (custOrderSubItem && custOrderSubItem.productType && custOrderSubItem.productType === 'VOICE-DHP') {
                        custOrderItem.productType = 'VOICE-DHP';
                    }
                    if (custOrderSubItem && custOrderSubItem.productType && custOrderSubItem.productType === 'VIDEO-DTV') {
                        custOrderItem.productType = 'VIDEO-DTV';
                    }
                });
                custOrderItems.push(custOrderItem);
            });
            this.cartObj = { customerOrderItems: custOrderItems };
        }
        if (this.isVacSusFlow) {
            data && data.payload && data.payload.cart && data && data.payload && data.payload.cart.customerOrderItems && data && data.payload && data.payload.cart.customerOrderItems.map((custOrderItem) => {
                custOrderItem && custOrderItem.customerOrderSubItems && custOrderItem.customerOrderSubItems.map((custOrderSubItem) => {
                    if (custOrderSubItem && custOrderSubItem.productType && (custOrderSubItem.productType === 'INTERNET' || custOrderSubItem.productType === 'DATA')) {
                        custOrderItem.productType = 'DATA';
                    }
                    if (custOrderSubItem && custOrderSubItem.productType && custOrderSubItem.productType === 'VOICE-HP') {
                        custOrderItem.productType = 'VOICE-HP';
                    }
                    if (custOrderSubItem && custOrderSubItem.productType && custOrderSubItem.productType === 'VOICE-DHP') {
                        custOrderItem.productType = 'VOICE-DHP';
                    }
                    if (custOrderSubItem && custOrderSubItem.productType && custOrderSubItem.productType === 'VIDEO-DTV') {
                        custOrderItem.productType = 'VIDEO-DTV';
                    }
                });
                custOrderItems.push(custOrderItem);
            });
            this.cartObj = { customerOrderItems: custOrderItems };
        }
        this.catalogSpecId = data && data.payload && data.payload.cart && data.payload.cart.catalogSpecId ? data.payload.cart.catalogSpecId : 39;

        this.cpTab();
        if ((this.refObj.disableInternet && !this.refObj.disableHp) || (!this.refObj.disableInternet && !this.refObj.disableHp)) {
            this.internetActive = false;
            this.hpActive = true;
        } else if (!this.refObj.disableInternet && !this.refObj.disablePhone) {
            this.internetActive = false;
            this.phoneActive = true;
        } else if (!this.refObj.disableInternet && !this.refObj.disablePrism) {
            this.internetActive = false;
            this.prismActive = true;
        } else if (!this.refObj.disableInternet && !this.refObj.disableDtv) {
            if (this.isDtvOpus) {
                this.internetActive = true;
                this.dtvActive = false;
            }
            else {
                if (this.dtvExisting) {
                    this.internetActive = true;
                    this.dtvActive = false;
                } else {
                    this.internetActive = false;
                    this.dtvActive = true;
                }

            }


        }

        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }
        this.custSubscription = this.observable.subscribe((data) => {
            this.lifelineInternet = data.lifelineaddedforinternet;
            this.lifelinePots = data.lifelineaddedforpots;
            this.lifelineDHP = data.lifelineaddedfordhp;
            this.selectedGiftCardData = data.selectedGiftCard;
            this.custdata = data;
            if (!this.refObj.disablePhone || !this.refObj.disableHp) {
                let filteredDHPTN = filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'VOICE-DHP' || obj.productType === 'VOICE-HP' })
                if (filteredDHPTN && filteredDHPTN !== undefined && filteredDHPTN[0] && filteredDHPTN[0] !== undefined) {
                    this.phoneConfigInputData.tnData.selectedTN = filteredDHPTN[0].requestedTelephoneNumber;
                }
                if (((!filteredDHPTN) || (filteredDHPTN && filteredDHPTN.length === 0)) && this.isBilling) {
                    filteredDHPTN = filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'INTERNET' });
                    this.phoneConfigInputData.tnData.selectedTN = filteredDHPTN[0].requestedTelephoneNumber;
                }
                this.savedPhoneTN = filteredDHPTN && filteredDHPTN[0];
                if (this.savedPhoneTN && this.savedPhoneTN.productType === 'INTERNET') {
                    this.savedPhoneTN.productType = !this.refObj.disablePhone ? 'VOICE-HP' : 'VOICE-DHP';
                }
                if (!data.telephoneNumberType) {
                    if (this.savedPhoneTN && this.savedPhoneTN !== undefined && this.savedPhoneTN.tnType && this.savedPhoneTN.tnType !== undefined) {
                        this.tnType = this.savedPhoneTN.tnType;
                    }
                }
                if (this.isMove || this.isChange || this.isBilling || this.isAmendOrStack) {
                    if (data && data.payload && data.payload.existingProductConfiguration !== null && data.payload.existingProductConfiguration
                        && data.payload.existingProductConfiguration.length !== 0) {
                        data.payload.existingProductConfiguration.map(exConf => {
                            if (exConf.productType === GenericValues.cDHP) {
                                this.existingConfigurationDHP = exConf;
                                this.exPhoneConfigInputData.listingData.configItems = this.existingConfigurationDHP.configItems;
                            }
                            else if (exConf.productType === GenericValues.cHP) {
                                this.existingConfiguration = exConf;
                                this.exPhoneConfigInputData.listingData.configItems = this.existingConfiguration.configItems;
                            }
                        })
                    }
                }
                if (!this.isLatestPendingOrderNI && this.isAmend && curStore && curStore.retain && curStore.retain.potsBooleans) {
                    let potsBooleans = curStore.retain.potsBooleans;
                    potsBooleans['isPOTSChanged'] = false;
                    this.store.dispatch({ type: 'ADD-ONS_POTS', payload: potsBooleans });
                }

                if (this.isBilling && this.phoneConfigInputData && this.phoneConfigInputData !== undefined &&
                    this.phoneConfigInputData.listingData && this.phoneConfigInputData.listingData !== undefined &&
                    this.phoneConfigInputData.listingData.configItems && this.phoneConfigInputData.listingData.configItems !== undefined &&
                    this.custdata && this.custdata !== undefined && this.custdata.payload && this.custdata.payload !== undefined &&
                    this.custdata.payload.existingProductConfiguration && this.custdata.payload.existingProductConfiguration[0] &&
                    this.custdata.payload.existingProductConfiguration[0].configItems && (!this.custdata.payload.productConfiguration ||
                        this.custdata.payload.productConfiguration[0] || !this.custdata.payload.existingProductConfiguration[0].configItems)) {
                    this.phoneConfigInputData.listingData.configItems = this.custdata.payload.existingProductConfiguration[0].configItems;
                }
                if (this.custdata && this.custdata.payload && this.custdata.payload.productConfiguration && this.custdata.payload.productConfiguration[0] && this.custdata.payload.productConfiguration[0].configItems) {
                    this.phoneConfigInputData.listingData.configItems = this.custdata.payload.productConfiguration[0].configItems;
                }

            }
            if (data && data.telephoneNumberType) {
                this.portedType = data.telephoneNumberType;
            }
            if (data && data.potsPortingCheck) {
                this.potsPortedCheck = data.potsPortingCheck;
                if (data.potsPortingCheck) {
                    this.accordianHandling.tn = true;
                    this.portingNotComplete = true;
                }
            }
            if (data && data.workingTN) {
                this.workingTN = data.workingTN;
            }
            this.phoneConfigInputData.orderReferenceNumber = this.custdata.orderRefNumber;
            if (data.payload.lifeLineConfiguration === null || data.payload.lifeLineConfiguration === "" || data.payload.lifeLineConfiguration === undefined) {
                this.disableLifelineOption = true;
            }
            if (data.payload.lifeLineConfiguration && data.payload.lifeLineConfiguration !== undefined) {
                data.payload.lifeLineConfiguration.lifeLineProducts.map(item => {
                    if ((item && item.productDetails) && (item.productDetails.productType === GenericValues.iData || item.productDetails.productType === GenericValues.sData)) {
                        this.lifelineTotalResponseData = item;
                        this.lifelineReponseDataInternet = item.lifeLineConfig;
                        this.lifelineRespDataInternet = item.lifeLineDiscounts;
                    }
                    else if ((item && item.productDetails) && item.productDetails.productType === GenericValues.cDHP) {
                        this.lifelineTotalResponseData = item;
                        this.lifelineReponseDataDhp = item.lifeLineConfig;
                        this.lifelineRespDataDhp = item.lifeLineDiscounts;
                    }
                    else if ((item && item.productDetails) && item.productDetails.productType === GenericValues.cHP) {
                        this.lifelineTotalResponseData = item;
                        this.lifelineReponseDataPots = item.lifeLineConfig;
                        this.lifelineRespDataPots = item.lifeLineDiscounts;
                    }
                })
                this.lifeLineMasterQualProgList = data.payload.lifeLineConfiguration.lifeLineProducts[0].lifeLineMasterQualProgList;
                this.lifeLineMasterRecurringCredits = data.payload.lifeLineConfiguration.lifeLineProducts[0].lifeLineMasterRecurringCredits;
                this.lifeLineMasterNonRecurringCredits = data.payload.lifeLineConfiguration.lifeLineProducts[0].lifeLineMasterNonRecurringCredits;
            }
            if (!this.loadedInitialize) this.initializeData();
        });
        this.store.dispatch({ type: 'TN_CHANGED', payload: false });
    }
    public potsListingValue: string = '';
    public dhpListingValue: string = '';
    public potsListingSelectedData(event) {
        if (event && event.name) {
            this.potsListingValue = event.name;
            this.errorMsg = '';
            this.directoryListingToCart(event, true);
        } else if (event === "Non-Pub No Charge") {
            this.potsListingValue = event;
            this.errorMsg = '';
            this.directoryListingToCart(event, true);
        }
    }
    public dhpListingSelectedData(event) {
        if (event && event.name) {
            this.dhpListingValue = event.name;
            this.errorMsg = '';
            this.directoryListingToCart(event, false);
        }
    }
    private directoryListingToCart(data, isHp) {
        let productType = isHp ? 'HP ADDON OFFER' : 'DHP ADDON OFFER';
        let deliveryToCart = {
            productId: '',
            name: data.name,
            productType: productType,
            isRegulated: '',
            prices:
                [
                    {
                        discountedRc: data.price,
                        discountedOtc: 0,
                        otc: 0,
                        rc: data.price
                    }
                ]
        };
        this.store.dispatch({ type: 'UPDATE_SHIPPING_ADDON', payload: deliveryToCart });
    }
    public clearDirectoryListingToCart(data, isHp) {
        let productType = isHp ? 'HP ADDON OFFER' : 'DHP ADDON OFFER';
        let deliveryToCart = {
            productId: '',
            name: '',
            productType: productType,
            isRegulated: '',
            prices:
                [
                    {
                        discountedRc: 0,
                        discountedOtc: 0,
                        otc: 0,
                        rc: 0
                    }
                ]
        };
        this.store.dispatch({ type: 'UPDATE_SHIPPING_ADDON', payload: deliveryToCart });
    }

    public existingServiceObservable(user, pending?) {
        this.cartObjCalled = true;
        let data = this.appStateService.getState().existingProducts;
        this.existingData = data;
        if (!this.isLatestPendingOrderNI && data.existingProductsAndServices && data.existingProductsAndServices[0] &&
            data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems) {
            let exData = data.existingProductsAndServices[0].existingServices.existingServiceItems;
            if (exData && exData.length > 0) {
                exData.forEach(item => {
                    item.offerCategory === GenericValues.cHP ? this.potsExistingOnCompleted = true : this.hsiExistingOnCompleted = true;
                })
            }
        }

        if (data && data.orderFlow && (data.orderFlow.flow === 'billing' || data.orderFlow.flow === 'Billandrec')) {
            this.existingServices = user && user.orderInit && user.orderInit.payload && user.orderInit.payload.cart && user.orderInit.payload.cart.customerOrderItems;
            if (data.orderFlow.type === 'fromHold' && data.existingProductsAndServices && data.existingProductsAndServices[0] &&
                data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems) {
                this.existingServices = data.existingProductsAndServices[0].existingServices.existingServiceItems;
            }
            if (!this.existingServices && data.orderFlow.type !== 'pending') {
                if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices &&
                    data.existingProductsAndServices[0].existingServices.existingServiceItems) {
                    data.existingProductsAndServices[0].existingServices.existingServiceItems.map(exSub => {
                        if (!exSub.customerOrderSubItems) exSub.customerOrderSubItems = exSub.existingServiceSubItems;
                    })
                    this.existingServices = data.existingProductsAndServices[0].existingServices.existingServiceItems;
                }
            } else if (!this.existingServices && data.orderFlow.type === 'pending') {
                if (data.pendingOrders && data.pendingOrders[0] && data.pendingOrders[0].orderDocument && data.pendingOrders[0].orderDocument.customerOrderItems) {
                    this.existingServices = data.pendingOrders[0].orderDocument.customerOrderItems;
                }
            }
            this.macdFlow(user, this.existingServices, false)
            this.isBilling = true;
        }
        if (data && data.orderFlow && (data.orderFlow.flow === 'Change' || this.isMove || data.orderFlow.flow === 'Move' || this.isAmendOrStack)) {
            if (data.orderFlow.flow === 'Move' && user && user.orderInit && user.orderInit.payload && user.orderInit.payload.existingLocation &&
                user.orderInit.payload.existingLocation.existingServices && user.orderInit.payload.existingLocation.existingServices.existingServiceItems) {
                this.existingServices = user.orderInit.payload.existingLocation.existingServices.existingServiceItems;
                this.macdFlow(data, this.existingServices, true);
                this.isMove = true;
            }
            if (data.orderFlow.flow === 'Change') { this.isChange = true; }
            let moreServices = data.existingProductsAndServices && data.existingProductsAndServices[0] &&
                data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems;
            if (data.pendingOrders && data.pendingOrders.length > 0 && data.pendingOrders[0] && data.pendingOrders[0].orderReference &&
                data.pendingOrders[0].orderReference.customerOrderStatus === 'PENDING') {
                moreServices = data.pendingOrders[0].orderDocument.customerOrderItems;
            }
            if ((!moreServices || moreServices === null) && pending && pending.orderDocument && pending.orderDocument.customerOrderItems) {
                moreServices = pending.orderDocument.customerOrderItems;
            }
            if (moreServices !== undefined && moreServices.length !== 0) {
                this.macdFlow(user, moreServices, false);
                moreServices.map((item) => {
                    if (item.offerCategory === 'VOICE-DHP') {
                        this.dhpExisting = true;
                    } else if (item.offerCategory === 'VOICE-HP') {
                        this.hpExisting = true;
                    } else if (item.offerCategory === 'VIDEO-DTV') {
                        this.dtvExisting = true;
                    }
                });
            }
        }
        if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();
    }

    public existingCart: CustomerOrderItems[] = [];
    public macdFlow(data, existingServices, isMove) {
        this.existingServices = existingServices;
        if (!data.oTCustomize && !this.NIPendingStackAmend) {
            this.cartObject = [];
            if (this.existingServices) {
                this.existingServices.map(exItems => {
                    exItems.action = 'NOCHANGE';
                    if (exItems.existingServiceSubItems) {
                        exItems.existingServiceSubItems.map(exServ => {
                            exServ.action = 'NOCHANGE';
                        })
                    } else if (exItems.customerOrderSubItems) {
                        exItems.customerOrderSubItems.map(exServ => {
                            exServ.action = 'NOCHANGE';
                        })
                    }
                    if (this.flushCart && exItems.offerCategory === GenericValues.cHP && exItems.offerType !== 'SUBOFFER' && exItems.offerType !== 'P4L') this.flushCart = false;
                    if (exItems.offerType === 'SUBOFFER' || (exItems.offerCategory === GenericValues.cHP &&
                        ((!this.isReEntrant && !this.flushCart) || (this.isReEntrant)))) {
                        let orderedItems: CustomerOrderItems = {
                            productType: this.getExistingProdType(exItems),
                            customerOrderSubItems: exItems.existingServiceSubItems ? exItems.existingServiceSubItems : exItems.customerOrderSubItems
                        }
                        if (exItems.offerCategory !== 'INTERNET' && exItems.offerCategory !== 'WIRINGWORKS') {
                            if (exItems.offerCategory === 'VOICE-HP' && orderedItems.customerOrderSubItems && orderedItems.customerOrderSubItems.length > 0) {
                                for (let a = 0; a < orderedItems.customerOrderSubItems.length; a++) {
                                    let prod = orderedItems.customerOrderSubItems[a];
                                    if (prod.productType === 'WIRINGWORKS') orderedItems.customerOrderSubItems.splice(a, 1)
                                }
                            }
                            this.cartObject.push(orderedItems);
                        }
                        if (exItems.offerCategory === 'VOICE-DHP') {
                            this.dhpExisting = true;
                        } else if (exItems.offerCategory === 'VOICE-HP') {
                            this.hpExisting = true;
                        }
                    }
                    if (exItems.offerCategory === GenericValues.cDTV) this.dtvExisting = true;
                })
                this.existingCart = cloneDeep(this.cartObject);
            }
            if (this.isPOTSChanged) this.cartObject = [];
        } else {
            if (this.existingServices) {
                this.existingServices.map(exItems => {
                    if (exItems.offerType === 'SUBOFFER' || (exItems.offerCategory === GenericValues.cHP &&
                        ((!this.isReEntrant && !this.flushCart) || (this.isReEntrant)))) {
                        let orderedItems: CustomerOrderItems = {
                            productType: this.getExistingProdType(exItems),
                            customerOrderSubItems: exItems.existingServiceSubItems ? exItems.existingServiceSubItems : exItems.customerOrderSubItems
                        }
                        this.cartObject.push(orderedItems);
                    }
                })
                this.existingCart = cloneDeep(this.cartObject);
            }
        }
    }
    public getExistingProdType(exItems): string {
        switch (exItems.offerCategory) {
            case GenericValues.sData: {
                return 'DATA ADDON OFFER';
            }
            case GenericValues.iData: {
                return 'DATA ADDON OFFER';
            }
            case GenericValues.cDHP: {
                return 'DHP ADDON OFFER';
            }
            case GenericValues.cHP: {
                return 'HP ADDON OFFER';
            }
            case GenericValues.cVideo: {
                return 'VIDEO ADDON OFFER';
            }
            case "WIRINGWORKS": {
                return !this.refObj.disableHp ? 'HP ADDON OFFER' : 'DATA ADDON OFFER';
            }
        }
    }
    public undoChanges() {
        this.refObj.isUndo = true;
        this.ctlHelperService.setUndoChanges(false);
    }

    public compatibilityAPIcall() {
        this.loading = true;
        this.logger.log("info", "customize-services.component.ts - getCompatibilityRules", "fetchRulesRequest", JSON.stringify(""));
        this.logger.startTime();
        this.productService.getCompatibilityRules()
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesResponse", error);
                this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "FETCH_RULES", "customize-services.component.ts - getCompatibilityRules",
                    "CustomizeService Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "customize-services.component.ts - getCompatibilityRules", "fetchRulesResponse", JSON.stringify(data ? data : ""));
                this.logger.log("info", "customize-services.component.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.compatibilityArray = data;
                let reservedTNs = this.custdata && this.custdata.payload && this.custdata.payload.reservedTN && filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'VOICE-HP' });
                if (reservedTNs && reservedTNs[0] && reservedTNs[0].requestedTelephoneNumber && reservedTNs[0].requestedTelephoneNumber !== null
                    && reservedTNs[0].requestedTelephoneNumber.toString().trim().length !== 0) {
                    let tn = reservedTNs[0].requestedTelephoneNumber.toString().trim();
                    this.getSwitchRulesByTN(tn, true);
                } else if (!this.vacationFlow) {
                    this.addJacksCompatibility(true);
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesResponse", error);
                    this.logger.log("error", "customize-services.component.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    private getSwitchRulesByTN(tn, flag) {
        this.loading = true;
        this.logger.log("info", "customize-services.component.ts", "getSwitchByTNRequest", JSON.stringify(tn));
        this.logger.startTime();
        this.productService.getSwitchByTN(tn)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts", "getSwitchByTNResponse", error);
                this.logger.log("error", "customize-services.component.ts", "getSwitchByTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "FETCH_RULES", "customize-services.component.ts - getCompatibilityRules", "CustomizeService Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "customize-services.component.ts", "getSwitchByTNResponse", JSON.stringify(data ? data : ""));
                this.logger.log("info", "customize-services.component.ts", "getSwitchByTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (this.switchData && this.switchData.outputAttribute) {
                    this.compatibilityArray.outputAttribute.splice(this.compatibilityArray.outputAttribute.length - this.switchData.outputAttribute.length, this.switchData.outputAttribute.length);
                }
                this.switchData = data;
                if (!this.vacationFlow) {
                    this.addJacksCompatibility(flag);

                }
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts", "getSwitchByTNResponse", error);
                this.logger.log("error", "customize-services.component.ts", "getSwitchByTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (error === undefined || error === null)
                    return;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", this.apiResponseError);
                    }
                    else
                        unexpectedError = true;
                }
                else
                    unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    private addJacksCompatibility(flag?) {
        let potsBooleans: any;
        let currentStore = this.appStateService.getState();
        let retVal = currentStore.retain;
        this.previousLoaded = retVal.potsOffer;
        potsBooleans = retVal.potsBooleans;
        this.voiceMailAdded = potsBooleans && potsBooleans.voiceMail;
        this.voiceMailAdded = potsBooleans && potsBooleans.voiceMail;
        if (flag) {
            if ((this.isChange && !this.isAmendOrStack) || this.isBilling || this.isAmendOrStack) {
                if (!this.newPOTS && !this.newHSI) {
                    this.compatibilityArray.outputAttribute.unshift([
                        "ESHOP-Customer Care",
                        "PRODUCT_COMPATIBILITY",
                        "VOICE-HP",
                        null,
                        "Jack and Wire",
                        null,
                        null,
                        "INCOMPATIBLE",
                        "VOICE-HP",
                        null,
                        "In Wire or Jack 1st 1/2 HR T/M",
                        "DMS100",
                        null,
                        null,
                        null,
                        "Product Initial Jack INCOMPATIBLE Initial Technician Time"
                    ],
                        [
                            "ESHOP-Customer Care",
                            "PRODUCT_COMPATIBILITY",
                            "VOICE-HP",
                            null,
                            "Jack and Wire",
                            null,
                            null,
                            "ENABLE",
                            "VOICE-HP",
                            null,
                            "Additional Jack and Wire",
                            "DMS100",
                            null,
                            null,
                            null,
                            "Product Initial Jack ENABLE Additional Jack and Wire"
                        ], [
                        "ESHOP-Customer Care",
                        "PRODUCT_COMPATIBILITY",
                        "VOICE-HP",
                        null,
                        "In Wire or Jack 1st 1/2 HR T/M",
                        null,
                        null,
                        "REQUIRES",
                        "VOICE-HP",
                        null,
                        "Trip Charge Regular",
                        null,
                        null,
                        null,
                        null,
                        "Initial Technician Time REQUIRES Trip Charge Regular",
                        "DMS100",
                        null,
                        null,
                        null
                    ]
                    );
                }
                else {
                    if (potsBooleans && ((this.newPOTS && potsBooleans.retainValueForPotsJack !== '' && potsBooleans.retainValueForPotsJack !== 'No work is needed') ||
                        (this.newHSI && potsBooleans && (potsBooleans.retainValueForHSIJack !== '' && potsBooleans.retainValueForHSIJack !== 'No work is needed')))) {
                        this.compatibilityArray.outputAttribute.unshift([
                            "SWITCH_PRODUCT_ATTR_COMPATIBILITY",
                            null,
                            null,
                            "In Wire or Jack 1st 1/2 HR T/M",
                            null,
                            null,
                            "NOTAVAILABLE",
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            "Initial Technician Time NOTAVAILABLE if jacks selected",
                            "DMS100",
                            null,
                            null,
                            null
                        ]);
                    } else {
                        this.compatibilityArray.outputAttribute.unshift([
                            "SWITCH_PRODUCT_ATTR_COMPATIBILITY",
                            null,
                            null,
                            "Additional Jack and Wire",
                            null,
                            null,
                            "NOTAVAILABLE",
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            "Product Additional Jack and Wire NOTAVAILABLE if no jacks selected",
                            "DMS100",
                            null,
                            null,
                            null
                        ],
                            [
                                "ESHOP-Customer Care",
                                "PRODUCT_COMPATIBILITY",
                                "VOICE-HP",
                                null,
                                "In Wire or Jack 1st 1/2 HR T/M",
                                null,
                                null,
                                "REQUIRES",
                                "VOICE-HP",
                                null,
                                "Trip Charge Regular",
                                null,
                                null,
                                null,
                                null,
                                "Initial Technician Time REQUIRES Trip Charge Regular",
                                "DMS100",
                                null,
                                null,
                                null
                            ]);
                    }
                }
            }
            if (potsBooleans && (potsBooleans.retainValueForPotsJack !== '' && potsBooleans.retainValueForPotsJack !== 'No work is needed' && !(this.isChange && !this.isAmendOrStack) && !this.isBilling && !this.isAmendOrStack) ||
                (potsBooleans.retainValueForHSIJack !== '' && potsBooleans.retainValueForHSIJack !== 'No work is needed' && this.newHSI && ((this.isChange && !this.isAmendOrStack) || this.isBilling || this.isAmendOrStack))) {
                this.compatibilityArray.outputAttribute.unshift([
                    "SWITCH_PRODUCT_ATTR_COMPATIBILITY",
                    null,
                    null,
                    "In Wire or Jack 1st 1/2 HR T/M",
                    null,
                    null,
                    "NOTAVAILABLE",
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    "Initial Technician Time NOTAVAILABLE if jacks selected",
                    "DMS100",
                    null,
                    null,
                    null
                ]);
            }
            else if (((this.newHSI && ((this.isChange && !this.isAmendOrStack) || this.isBilling || this.isAmendOrStack)) || (!(this.isChange && !this.isAmendOrStack) && !this.isBilling && !this.isAmendOrStack)) && ((potsBooleans.retainValueForHSIJack === '' || potsBooleans.retainValueForHSIJack === 'No work is needed') && (potsBooleans.retainValueForPotsJack === '' || potsBooleans.retainValueForPotsJack === 'No work is needed'))) {
                this.compatibilityArray.outputAttribute.unshift([
                    "SWITCH_PRODUCT_ATTR_COMPATIBILITY",
                    null,
                    null,
                    "Additional Jack and Wire",
                    null,
                    null,
                    "NOTAVAILABLE",
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    "Product Additional Jack and Wire NOTAVAILABLE if no jacks selected",
                    "DMS100",
                    null,
                    null,
                    null
                ],
                    [
                        "ESHOP-Customer Care",
                        "PRODUCT_COMPATIBILITY",
                        "VOICE-HP",
                        null,
                        "In Wire or Jack 1st 1/2 HR T/M",
                        null,
                        null,
                        "REQUIRES",
                        "VOICE-HP",
                        null,
                        "Trip Charge Regular",
                        null,
                        null,
                        null,
                        null,
                        "Initial Technician Time REQUIRES Trip Charge Regular",
                        "DMS100",
                        null,
                        null,
                        null
                    ]);
            }
            else if ((this.newHSI && ((this.isChange && !this.isAmendOrStack) || this.isBilling || !this.isAmend)) || (!this.isChange && !this.isBilling && !this.isAmend)) {
                this.compatibilityArray.outputAttribute.unshift([
                    "SWITCH_PRODUCT_ATTR_COMPATIBILITY",
                    null,
                    null,
                    "Additional Jack and Wire",
                    null,
                    null,
                    "NOTAVAILABLE",
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    "Product Additional Jack and Wire NOTAVAILABLE if no jacks selected",
                    "DMS100",
                    null,
                    null,
                    null
                ],
                    [
                        "ESHOP-Customer Care",
                        "PRODUCT_COMPATIBILITY",
                        "VOICE-HP",
                        null,
                        "In Wire or Jack 1st 1/2 HR T/M",
                        null,
                        null,
                        "REQUIRES",
                        "VOICE-HP",
                        null,
                        "Trip Charge Regular",
                        null,
                        null,
                        null,
                        null,
                        "Initial Technician Time REQUIRES Trip Charge Regular",
                        "DMS100",
                        null,
                        null,
                        null
                    ]);
            }
        }
        if (this.switchData) {
            this.compatibilityArray.outArrHeader = this.switchData.outArrHeader;
            this.switchData.outputAttribute && this.switchData.outputAttribute.map(attr => {
                if (attr)
                    this.compatibilityArray.outputAttribute.push(attr);
            });
        }
        if (!this.loadedInitialize) this.initializeData();
    }

    public ngOnInit() {
        this.logger.metrics('CustomizeServicesPage');
        let retainVal = <Observable<any>>this.store.select('retain');
        retainVal.subscribe(data => {
            this.retainDiscountData = data.retainDisc;
            this.isModemConverted = data.isConverted;
        });
        let customize = <Observable<any>>this.store.select('customize');
        this.customizeSubscription = customize.subscribe((data) => {
            if (data && data.potsPortingCheck) {
                this.portedreq = true;
            }
            else {
                this.portedreq = false;
            }
            let isData = data.payload.cart.customerOrderItems.filter(x => {
                return x.offerCategory === 'INTERNET'
            })
            this.applicableGiftcard = isData.length && data && data.eligibleCards ? data.eligibleCards : '';
        });
        if (this.customizeSubscription !== undefined) this.customizeSubscription.unsubscribe();

        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            this.vacationObservable = <Observable<any>>this.store.select('vacation');
            this.vacationSubscription = this.vacationObservable.subscribe((data) => {
                this.vacationflow = data.vacationflow;
            });
            if (data && data.orderFlow && data.orderFlow !== undefined && (data.orderFlow.flow === "NEWINSTALL" || data.orderFlow.flow === "Newinstall" || data.orderFlow.flow === "Change" || data.orderFlow.flow === "billing" || data.orderFlow.flow === "Move" || this.vacationflow)) {
                this.disableCloserandPromos = false;
            } else {
                this.disableCloserandPromos = true;
            }
        });
        if (this.lifelineTotalResponseData && this.lifelineTotalResponseData !== null) {
            this.addedLifelineInternet = true;
        }
        if (this.lifelineReponseDataInternet && this.lifelineReponseDataInternet !== null) {
            this.lifelineexisting = true;
        } else {
            this.lifelineexisting = false;
        }
        let user = <Observable<User>>this.store.select('user');
        let userSubscription = user.subscribe(
            (usr) => {
                if (usr.currentSelected) {
                    if (usr.currentSelected.length > 1) {
                        this.selectedLifelineType = "BNDVCBB";
                    }
                    else if (usr.currentSelected.length === 1) {
                        if (usr.currentSelected[0].selected === "DATA") {
                            this.selectedLifelineType = "BRBAND";
                        } else if (usr.currentSelected[0].selected === "VOICE-HP") {
                            this.selectedLifelineType = "VOICE";
                        }
                    }
                }
            });
        if (userSubscription !== undefined) userSubscription.unsubscribe();
        window.scroll(0, 0);
        this.phoneConfigForm = this.fb.group({
            'phoneConfigData': [{}]
        });

        if (!this.isDtvOpus) {
            this.dtvConfigForm = this.fb.group({
                'taskName': ['yes'],
                'accNo': ['']
            });
        }


        //once the closer&Promo implmented for both NI and MACD we can remove this check. As of now only implmented for NI
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            if (data && data.orderFlow && data.orderFlow === "NEWINSTALL") {
                this.enableCloserPromoNIFlow = true;
            }
        });
        this.undoChangesSub = this.ctlHelperService.undoChanges.subscribe(next => {
            if (next) {
                this.undoChanges();
            }
        });
    }

    // Fix: ExpressionChangedAfterItHasBeenCheckedError
    ngAfterViewInit(): void {
        this.changeDetector.detectChanges();
    }

    public lifelineClickContinue(event) {
        this.lifelineValidation = event;
        if (this.lifelineValidation) {
            this.lifelineCheckoutReq = false;
        } else {
            this.lifelineCheckoutReq = true;
        }
    }
    public lifelinemulproContinue(event) {
        this.lifelinepotsValidation = event;
        if (this.lifelinepotsValidation) {
            this.lifelineCheckoutReq = false;
        } else {
            this.lifelineCheckoutReq = true;
        }
    }
    public removeLifelineContinue(event) {
        this.lifelinePOtsRemove = event;
    }
    public removeLifelineInternet(event) {
        this.lifelineHsiRemove = event;
    }
    public expandLifelineContinue(event) {
        this.lifeLineShowInternet = event;
    }
    public expandPotsLifelineContinue(event) {
        this.lifeLineShow = event;
    }
    public expandDhpLifelineContinue(event) {
        this.showDHPLifeline = event;
        this.lifelineShowDHP = event;
    }
    public phonePlanChange(event: boolean) {
        this.phonePlan = event;
    }
    public mandateOfferSelected: string[] = [];
    private fetchListingCatalog(addonOffers, product) {
        addonOffers.catalogs[0].catalogItems.map(item => {
            if (item.productOffer && item.productOffer.offerName.indexOf('Listing') !== -1 && (product === 'pots' || product === 'dhp')) {
                let qtty;
                let customerOrderSubItems: any[] = [];
                if (item && item.productOffer && item.productOffer.productComponents && item.productOffer.productComponents.length > 0) {
                    let listingComp = cloneDeep(item);
                    listingComp.productOffer.productComponents.map(comp => {
                        delete comp.product.productDisplayName;
                        delete comp.product.isRegulated;
                        if (comp && comp.product && comp.product.quantity) {
                            qtty = comp.product.quantity.defaultQuantity ? comp.product.quantity.defaultQuantity : comp.product.quantity.minQuantity;
                            comp.product.quantity = qtty;
                        }
                        if (product === 'pots' && comp && comp.product && comp.product.productName && comp.product.productName === 'Home Phone Directory Listing') {
                            item.productOffer.productComponents = [];
                            item.productOffer.productComponents[0] = comp;
                            customerOrderSubItems.push(comp.product);
                        }
                        if (product === 'dhp') {
                            customerOrderSubItems.push(comp.product);
                        }
                    })
                    listingComp.productOffer.productComponents.map(comp => {
                        if (product === 'pots' && comp && comp.product && comp.product.productName && comp.product.productName !== 'Home Phone Directory Listing') {
                            if (comp.product.productName.toUpperCase() === 'Home Phone Directory Listing Change'.toUpperCase() && (this.isChange || this.isAmendOrStack || this.isBilling || this.isMove)) {
                                delete comp.product.productDisplayName;
                                delete comp.product.isRegulated;
                                comp.product.componentType = comp.componentType;
                                item.productOffer.productComponents.push(comp);
                                customerOrderSubItems.push(comp.product);
                            }
                        }
                    })
                    if (item.productOffer.productComponents[0] && item.productOffer.productComponents[0].product &&
                        item.productOffer.productComponents[0].product.quantity) {
                        qtty = item.productOffer.productComponents[0].product.quantity.defaultQuantity ? item.productOffer.productComponents[0].product.quantity.defaultQuantity : item.productOffer.productComponents[0].product.quantity.minQuantity;
                        item.productOffer.productComponents[0].product.quantity = qtty;
                    }
                }
                item.productOffer.productComponents[0].product.action = 'NOCHANGE';
                item.productOffer.productComponents[0].product.componentType = 'COMPONENT';
                delete item.productOffer.productComponents[0].product.productDisplayName;
                delete item.productOffer.productComponents[0].product.isRegulated;
                this.listingToCart = {
                    "catalogId": addonOffers.catalogs[0].catalogId,
                    "contractTerm": item.productOffer.contract.contractTerm,
                    "productOfferingId": item.productOfferingId,
                    "offerType": item.productOffer.offerType,
                    "offerSubType": item.productOffer.offerSubType,
                    "offerCategory": item.productOffer.offerCategory,
                    "quantity": qtty ? qtty : null,
                    "rc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.rc : 0,
                    "otc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.otc : 0,
                    "discountedRc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedRc : 0,
                    "discountedOtc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedOtc : 0,
                    "customerOrderSubItems": customerOrderSubItems,
                    action: 'NOCHANGE',
                    offerName: item.productOffer.offerName
                }
            }
            else if (item && item.productOffer && item.productOffer.productComponents) {
                item.productOffer.productComponents.map(prodComp => {
                    if (prodComp.displayOrder === 0 && (prodComp.isMandatory || (!prodComp.isMandatory && prodComp.product.productName === 'Access Line Freeze')) &&
                        ((this.mandateOfferSelected && this.mandateOfferSelected.length === 0) ||
                            (this.mandateOfferSelected && this.mandateOfferSelected.length > 0 && this.mandateOfferSelected.indexOf(prodComp.product.productName) === -1))) {
                        let qtty = prodComp.product.quantity && prodComp.product.quantity.defaultQuantity ? prodComp.product.quantity.defaultQuantity :
                            prodComp.product.quantity && prodComp.product.quantity.minQuantity && prodComp.product.quantity.minQuantity;
                        prodComp.product.quantity = qtty;
                        /* if (this.isAmend && !this.isLatestPendingOrderNI) {
                            prodComp.product.action = (!this.isLatestPendingOrderNI && ((item.productOffer.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted) || (item.productOffer.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted))) ?
                                'ADD' : 'NOCHANGE'
                        } */
                        prodComp.product.action = ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((item.productOffer.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                            || (item.productOffer.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : 'NOCHANGE';
                        prodComp.product.componentType = 'COMPONENT';
                        delete prodComp.product.productDisplayName;
                        delete prodComp.product.isRegulated;
                        this.mandateOfferSelected.push(prodComp.product.productName);
                        this.mandatorySubOffers.push({
                            "catalogId": addonOffers.catalogs[0].catalogId,
                            "contractTerm": item.productOffer.contract.contractTerm,
                            "productOfferingId": item.productOfferingId,
                            "offerType": item.productOffer.offerType,
                            "offerSubType": item.productOffer.offerSubType,
                            "offerCategory": item.productOffer.offerCategory,
                            "quantity": qtty,
                            "rc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.rc : 0,
                            "otc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.otc : 0,
                            "discountedRc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedRc : 0,
                            "discountedOtc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedOtc : 0,
                            "customerOrderSubItems": [prodComp.product],
                            action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((item.productOffer.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                || (item.productOffer.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : 'NOCHANGE',
                            offerName: item.productOffer.offerName
                        })
                    }
                })
            }
        })
    }

    public previousLoaded: any;
    private getProductConfig(configList) {
        let values = 0;
        configList.map(config => {
            if (config && config.configItems !== null && config.configItems && config.configItems.length > 0) {
                config.configItems.map(item => {
                    if (item.productName === 'TECH INSTALL') {
                        if (item.configDetails !== null && item.configDetails && item.configDetails.length > 0) {
                            item.configDetails.map(det => {
                                if (det.formName === GenericValues.cDevices) {
                                    det.formItems && det.formItems.map(form => {
                                        values = form.attributeValue.length;
                                        this.deviceValues = form.attributeValue;
                                    })
                                }
                            })
                        }
                        if (!this.deviceSelected)
                            this.deviceSelected = {
                                "configItems": [
                                    {
                                        "productId": "",
                                        "productName": config.configItems[0].productName,
                                        "configDetails": [
                                            {
                                                "isConfigRequired": config.configItems[0].configDetails[0].isConfigRequired,
                                                "formName": config.configItems[0].configDetails[0].formName,
                                                "formItems": [
                                                    {
                                                        "attributeName": config.configItems[0].configDetails[0].formItems[0].attributeName,
                                                        "attributeType": config.configItems[0].configDetails[0].formItems[0].attributeType,
                                                        "isMandatory": config.configItems[0].configDetails[0].formItems[0].isMandatory,
                                                        "attributeValue": [{
                                                            value: 1
                                                        }]
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "productType": config.productType
                            }
                    }
                })
            }
        })
        return values;
    }

    public selectedListingOption(data) {
        this.selectedListingOptionValue = data;
    }
    /** initialize Data for the screen */
    public initializeData() {
        let addOnOffers;
        if (this.custdata && this.custdata.payload && this.custdata.payload.retrievalTypes && (this.custdata.payload.retrievalTypes.length > 0) && this.custdata.payload.retrievalTypes[0].addOnOffers) {
            addOnOffers = cloneDeep(this.custdata.payload.retrievalTypes[0].addOnOffers);
        }
        addOnOffers && addOnOffers !== undefined && addOnOffers.map(data => {
            if (data.serviceCategory === "VOICE-HP") {
                if (data.catalogs[0] && data.catalogs[0].catalogItems && data.catalogs[0].catalogItems.length > 0) {
                    data.catalogs[0].catalogItems.map(catelogData => {
                        if (catelogData.productOffer.offerName === "Home Phone Directory Listing") {
                            catelogData.productOffer.productComponents.map(dat => {
                                if (dat.product.productName === "Home Phone Directory Listing") {
                                    dat.product.productAttributes.map(da => {
                                        this.listingNameData.push(da.compositeAttribute[0].attributeValue);
                                    })
                                }
                            })
                        }
                    })
                }
            }
        })
        let deviceQuantity;
        if (this.custdata && this.custdata.payload && this.custdata.payload.productConfiguration) {
            deviceQuantity = this.getProductConfig(this.custdata.payload.productConfiguration);
        }
        let potsClone: any;
        if (Array.isArray(addOnOffers)) {
            let hsiObj = cloneDeep(this.productService.findObjByName(addOnOffers, 'serviceCategory', GenericValues.sData));
            let dataClone: any;
            let dataObj: any;
            if (hsiObj) {
                dataObj = cloneDeep(hsiObj);
                dataClone = cloneDeep(hsiObj);
                hsiObj.catalogs[0].catalogItems = []
            }


            this.potsAddonOffers = this.productService.findObjByName(addOnOffers, 'serviceCategory', GenericValues.cHP); potsClone = cloneDeep(this.potsAddonOffers);
            this.dhpAddonOffers = this.productService.findObjByName(addOnOffers, 'serviceCategory', GenericValues.cDHP); let dhpClone = cloneDeep(this.dhpAddonOffers);

            if (this.potsAddonOffers) {
                this.fetchAssessCharge(this.potsAddonOffers);
            }

            if (!this.refObj.disableHp && this.potsAddonOffers && this.potsAddonOffers.catalogs && this.potsAddonOffers.catalogs[0].catalogItems) {
                this.fetchListingCatalog(potsClone, 'pots');
            }
            else if (!this.refObj.disablePhone && this.dhpAddonOffers && this.dhpAddonOffers.catalogs && this.dhpAddonOffers.catalogs[0].catalogItems) {
                this.fetchListingCatalog(dhpClone, 'dhp');
            }
            else if (hsiObj && hsiObj.catalogs && hsiObj.catalogs[0].catalogItems) {
                this.fetchListingCatalog(dataClone, 'hsi');
            }

            if (dataObj && !this.loadedInitialize) {
                dataObj.catalogs[0].catalogItems.catalogCategory = "DATA ADDON OFFER";
                for (let i = 0; i < dataObj.catalogs[0].catalogItems.length; i++) {
                    for (let a = 0; a < dataObj.catalogs[0].catalogItems[i].productOffer.productComponents.length; a++) {
                        if ((dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].displayOrder > 0) ||
                            (dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].displayOrder === 0 &&
                                dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productType === 'WIRINGWORKS' &&
                                dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular')) {
                            if ((!this.refObj.disableHp && !this.newHSI) && dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productType === 'WIRINGWORKS') {
                                continue;
                            }
                            if (i === 0 || hsiObj.catalogs[0].catalogItems.length === 0) {
                                hsiObj.catalogs[0].catalogItems = [];
                                hsiObj.catalogs[0].catalogItems.catalogCategory = "DATA ADDON OFFER";
                                hsiObj.catalogs[0].catalogItems[0] = cloneDeep(dataObj.catalogs[0].catalogItems[i]);
                                let prodComp = cloneDeep(dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a]);
                                if (prodComp.product.productName === 'In Wire or Jack 1st 1/2 HR T/M' && dataObj.catalogs[0].catalogItems[i]
                                    && dataObj.catalogs[0].catalogItems[i].defaultOfferPrice) {
                                    let price = dataObj.catalogs[0].catalogItems[i].defaultOfferPrice;
                                    price.discountedOtc === 0 ? price = price.otc : price = price.discountedOtc
                                    prodComp.product.price = price;
                                }
                                hsiObj.catalogs[0].catalogItems[0].productOffer.productComponents = [];
                                if (prodComp.product.productName === 'Tech-Install without Modem') {
                                    prodComp.product.quantity = {
                                        minQuantity: 1,
                                        maxQuantity: deviceQuantity,
                                        defaultQuantity: 1
                                    };
                                }
                                hsiObj.catalogs[0].catalogItems[0].productOffer.productComponents.push(prodComp);
                                hsiObj.catalogs[0].catalogItems[0].productOffer.productComponents[0].productOfferingId = hsiObj.catalogs[0].catalogItems[0].productOffer.productOfferingId;
                                hsiObj.catalogs[0].catalogItems[0].productOffer.productComponents[0].hasQuantity = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' ||
                                    dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'In Wire or Jack 1st 1/2 HR T/M' ||
                                    dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Jack and Wire' ? false : true;
                                hsiObj.catalogs[0].catalogItems[0].productOffer.customProdName = prodComp.product.productCategory;
                                hsiObj.catalogs[0].catalogItems[0].productOffer.hasQuantity = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' ||
                                    dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'In Wire or Jack 1st 1/2 HR T/M' ||
                                    dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Jack and Wire' ? false : true;
                                hsiObj.catalogs[0].catalogItems[0].productOffer.accordianTitle = prodComp.product.productCategoryDisplayName;
                                hsiObj.catalogs[0].catalogItems[0].catalogId = dataObj.catalogs[0].catalogId;
                                hsiObj.catalogs[0].catalogItems[0].action = dataObj.catalogs[0].catalogItems[0].action;

                                hsiObj.catalogs[0].catalogItems[0].displayOrder = prodComp.displayOrder;

                                continue;
                            }
                            let prdCtry = false;
                            for (let j = 0; j < hsiObj.catalogs[0].catalogItems.length; j++) {
                                for (let c = 0; c < hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents.length; c++) {
                                    if (dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productCategoryDisplayName ===
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.accordianTitle) {
                                        prdCtry = true;
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.customProdName = hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents[c].product.productCategory;
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.hasQuantity = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' ||
                                            dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'In Wire or Jack 1st 1/2 HR T/M' ||
                                            dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Jack and Wire' ? false : true;
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.accordianTitle = hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents[c].product.productCategoryDisplayName;
                                        let prodComp = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a]
                                        if (prodComp.product.productName === 'In Wire or Jack 1st 1/2 HR T/M' && dataObj.catalogs[0].catalogItems[i]
                                            && dataObj.catalogs[0].catalogItems[i].defaultOfferPrice) {
                                            let price = dataObj.catalogs[0].catalogItems[i].defaultOfferPrice;
                                            price.discountedOtc === 0 ? price = price.otc : price = price.discountedOtc
                                            prodComp.product.price = price;
                                        }
                                        if (prodComp.product.productName === 'Tech-Install without Modem') {
                                            prodComp.product.quantity = {
                                                minQuantity: 1,
                                                maxQuantity: deviceQuantity,
                                                defaultQuantity: 1
                                            };
                                        }
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents.push(prodComp);
                                        let lengthObj = cloneDeep(hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents);
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents[lengthObj.length - 1].productOfferingId = dataObj.catalogs[0].catalogItems[i].productOffer.productOfferingId;
                                        hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents[lengthObj.length - 1].hasQuantity = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' ||
                                            dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'In Wire or Jack 1st 1/2 HR T/M' ||
                                            dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Jack and Wire' ? false : true;
                                        hsiObj.catalogs[0].catalogItems[j].catalogId = dataObj.catalogs[0].catalogId;
                                        hsiObj.catalogs[0].catalogItems[j].displayOrder = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].displayOrder;
                                        break;
                                    }
                                }
                            }
                            if (!prdCtry) {
                                let j = hsiObj.catalogs[0].catalogItems.length;
                                hsiObj.catalogs[0].catalogItems[j] = cloneDeep(dataObj.catalogs[0].catalogItems[i]);
                                let prodComp = cloneDeep(dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a]);
                                hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents = [];
                                if (prodComp.product.productName === 'In Wire or Jack 1st 1/2 HR T/M' && dataObj.catalogs[0].catalogItems[i]
                                    && dataObj.catalogs[0].catalogItems[i].defaultOfferPrice) {
                                    let price = dataObj.catalogs[0].catalogItems[i].defaultOfferPrice;
                                    price.discountedOtc === 0 ? price = price.otc : price = price.discountedOtc
                                    prodComp.product.price = price;
                                }
                                if (prodComp.product.productName === 'Tech-Install without Modem') {
                                    prodComp.product.quantity = {
                                        minQuantity: 1,
                                        maxQuantity: deviceQuantity,
                                        defaultQuantity: 1
                                    };
                                }
                                hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents.push(prodComp);
                                hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].productOfferingId = hsiObj.catalogs[0].catalogItems[j].productOffer.productOfferingId;
                                hsiObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].hasQuantity = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' ||
                                    dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'In Wire or Jack 1st 1/2 HR T/M' ? false : true;
                                hsiObj.catalogs[0].catalogItems[j].productOffer.customProdName = prodComp.product.productCategory;
                                hsiObj.catalogs[0].catalogItems[j].productOffer.hasQuantity = dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' ||
                                    dataObj.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'In Wire or Jack 1st 1/2 HR T/M' ? false : true;
                                hsiObj.catalogs[0].catalogItems[j].productOffer.accordianTitle = prodComp.product.productCategoryDisplayName;
                                hsiObj.catalogs[0].catalogItems[j].catalogId = dataObj.catalogs[0].catalogId;
                                hsiObj.catalogs[0].catalogItems[j].displayOrder = prodComp.displayOrder;
                            }
                        }
                    }
                }
                this.hsiCData = hsiObj.catalogs[0].catalogItems;
            }

            let videObj = this.productService.findObjByName(addOnOffers, 'serviceCategory', 'VIDEO-PRISM');
            if (videObj && !this.refObj.disablePrism && !this.loadedInitialize) {
                videObj.catalogs[0].catalogItems.catalogCategory = "VIDEO ADDON OFFER";
                for (let i = 0; i < videObj.catalogs[0].catalogItems.length; i++) {
                    if (videObj.catalogs[0].catalogItems[i].productOffer.offerName === "Prism Premium Channel") {
                        videObj.catalogs[0].catalogItems[i].productOffer.customProdName = "Premium Channel Package"
                        videObj.catalogs[0].catalogItems[i].productOffer.hasQuantity = false;
                        videObj.catalogs[0].catalogItems[i].productOffer.accordianTitle = "Premium Channels";
                    } else if (videObj.catalogs[0].catalogItems[i].productOffer.offerName === "Prism International Channel") {
                        videObj.catalogs[0].catalogItems[i].productOffer.customProdName = "International Channel Package"
                        videObj.catalogs[0].catalogItems[i].productOffer.hasQuantity = false;
                        videObj.catalogs[0].catalogItems[i].productOffer.accordianTitle = "International Channels";
                    }
                }
                this.videoCData = videObj.catalogs[0].catalogItems;
            }

            let dhpObj = cloneDeep(this.productService.findObjByName(addOnOffers, 'serviceCategory', 'VOICE-DHP'));
            let dhpObjClone = cloneDeep(dhpObj);
            if (dhpObj && !this.loadedInitialize) {
                dhpObj.catalogs[0].catalogItems = [];
            }

            if (dhpObjClone) {
                dhpObjClone.catalogs[0].catalogItems.catalogCategory = "DHP ADDON OFFER";
                for (let i = 0; i < dhpObjClone.catalogs[0].catalogItems.length; i++) {

                    if (dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].displayOrder > 0) {
                        if (i === 0 || dhpObj.catalogs[0].catalogItems.length === 0) {
                            dhpObj.catalogs[0].catalogItems = [];
                            dhpObj.catalogs[0].catalogItems.catalogCategory = "DHP ADDON OFFER";
                            dhpObj.catalogs[0].catalogItems[0] = dhpObjClone.catalogs[0].catalogItems[i];
                            dhpObj.catalogs[0].catalogItems[0].productOffer.productComponents[0].productOfferingId = dhpObjClone.catalogs[0].catalogItems[0].productOffer.productOfferingId;
                            dhpObj.catalogs[0].catalogItems[0].productOffer.productComponents[0].hasQuantity = true;
                            dhpObj.catalogs[0].catalogItems[0].productOffer.customProdName = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].product.productCategory;
                            dhpObj.catalogs[0].catalogItems[0].productOffer.hasQuantity = true;
                            dhpObj.catalogs[0].catalogItems[0].productOffer.accordianTitle = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].product.productCategoryDisplayName;
                            dhpObj.catalogs[0].catalogItems[0].catalogId = dhpObjClone.catalogs[0].catalogId;
                            dhpObj.catalogs[0].catalogItems[0].action = dhpObjClone.catalogs[0].catalogItems[i].action;
                            dhpObj.catalogs[0].catalogItems[0].displayOrder = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].displayOrder;
                            continue;
                        }
                        let prdCtry = false;
                        for (let j = 0; j < dhpObj.catalogs[0].catalogItems.length; j++) {
                            if (dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].product.productCategory ===
                                dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategory) {
                                prdCtry = true;
                                dhpObj.catalogs[0].catalogItems[j].productOffer.customProdName = dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategory;
                                dhpObj.catalogs[0].catalogItems[j].productOffer.hasQuantity = true;
                                dhpObj.catalogs[0].catalogItems[j].productOffer.accordianTitle = dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategoryDisplayName;
                                dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents.push(dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0]);
                                let lengthObj = cloneDeep(dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents);
                                dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[lengthObj.length - 1].productOfferingId = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productOfferingId;
                                dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[lengthObj.length - 1].hasQuantity = true;
                                dhpObj.catalogs[0].catalogItems[j].catalogId = dhpObjClone.catalogs[0].catalogId;
                                dhpObj.catalogs[0].catalogItems[j].displayOrder = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].displayOrder;
                            }
                        }
                        if (!prdCtry) {
                            let j = dhpObj.catalogs[0].catalogItems.length;
                            dhpObj.catalogs[0].catalogItems[j] = dhpObjClone.catalogs[0].catalogItems[i];
                            dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].productOfferingId = dhpObj.catalogs[0].catalogItems[j].productOffer.productOfferingId;
                            dhpObj.catalogs[0].catalogItems[j].productOffer.productComponents[0].hasQuantity = true;
                            dhpObj.catalogs[0].catalogItems[j].productOffer.customProdName = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].product.productCategory;
                            dhpObj.catalogs[0].catalogItems[j].productOffer.hasQuantity = true;
                            dhpObj.catalogs[0].catalogItems[j].productOffer.accordianTitle = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].product.productCategoryDisplayName;
                            dhpObj.catalogs[0].catalogItems[j].catalogId = dhpObjClone.catalogs[0].catalogId;
                            dhpObj.catalogs[0].catalogItems[j].displayOrder = dhpObjClone.catalogs[0].catalogItems[i].productOffer.productComponents[0].displayOrder;
                        }
                    }
                }
                this.dhpCData = dhpObj.catalogs[0].catalogItems;
            }
            this.phoneConfigInputData.configType = 'dhp';
            let listing = find(this.dhpCData, (obj) => {
                return obj.productOffer.offerName.toString().toLowerCase().indexOf("listing") !== -1;
            });
            let listingArray = [];
            if (listing) {
                listingArray = filter(listing.productOffer.productComponents[0].product.productAttributes, (obj) => {
                    return obj.compositeAttribute.length > 0 && obj.compositeAttribute[0].attributeName === "Listing Type";
                });
            }
            this.phoneConfigInputData.listingData.optionsArray = listingArray;
            this.phoneConfigInputData.tnData.reservedTNs = this.custdata && this.custdata.payload && this.custdata.payload.reservedTN && filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'VOICE-DHP' });

            //EX-CONFIGURATION
            let exTemp = this.existingConfigurationDHP;
            if (exTemp) {
                this.macd = true;
                let listing = find(exTemp.configItems, (o) => {
                    return o.productName.indexOf('Listing') !== -1;
                });
                if (listing && listing.configDetails !== null && listing.configDetails.length !== 0 && listing.configDetails[0].formItems && listing.configDetails[0].formItems.length > 0) {
                    let listingType = find(listing.configDetails[0].formItems, (o) => o.attributeName === "Listing Type");
                    if (listingType) {
                        this.exSelectedListingDHP = listingType.attributeValue[0].value;
                    }
                    this.existingListingDirectoryDHP = listing.configDetails[0].formItems;
                }
            }
        }

        if (!this.refObj.disableHp) {
            if (this.custdata && this.custdata.payload && this.custdata.payload.reservedTN) {
                this.phoneConfigInputData.tnData.reservedTNs = [this.productService.findObjByName(this.custdata.payload.reservedTN, 'productType', 'VOICE-HP')];
            }
            this.phoneConfigInputData.configType = 'hp';
            this.phoneConfigInputData.tnData.reservedTNs = this.custdata && this.custdata.payload && this.custdata.payload.reservedTN && filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'VOICE-HP' });
            let temp = this.custdata && this.custdata.payload && this.custdata.payload.productConfiguration && find(this.custdata.payload.productConfiguration, (o) => {
                return o.productType === GenericValues.cHP;
            });
            if (temp && temp.configItems) {
                for (let i = 0; i < temp.configItems.length; i++) {
                    if (temp.configItems[i].configDetails && temp.configItems[i].configDetails[0].formName === 'Listing') {
                        if (temp.configItems[i].configDetails[0].formItems && temp.configItems[i].configDetails[0].formItems.length > 0) {
                            temp.configItems[i].configDetails[0].formItems.map(formItems => {
                                if (formItems.attributeName === 'Listing Type') {
                                    this.phoneConfigInputData.listingData.optionsArray = formItems.attributeValue;
                                }
                            })
                        }
                        break;
                    }
                }
            }
            let intralatalist = temp && temp.configItems && find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "") === 'LongDistance-IntraLata';
            });
            if (!intralatalist && temp && temp.configItems) {
                for (let i = 0; i < temp.configItems.length; i++) {
                    if (temp.configItems[i].configDetails && temp.configItems[i].configDetails[0] && temp.configItems[i].configDetails[0].formName.replace(/\s/g, "").toLowerCase() === 'ldcarrierintralata') {
                        intralatalist = temp.configItems[i];
                        break;
                    }
                }
            }
            if (intralatalist && intralatalist.configDetails && intralatalist.configDetails.length > 0 && intralatalist.configDetails[0].formItems && intralatalist.configDetails[0].formItems.length > 0 && intralatalist.configDetails[0].formItems[0].attributeValue && intralatalist.configDetails[0].formItems[0].attributeValue.length > 0) {
                this.phoneConfigInputData.ldCarrierData.intraLataArray = intralatalist.configDetails[0].formItems[0].attributeValue;
                if (intralatalist.configDetails[1]) {
                    this.phoneConfigInputData.ldCarrierData.intraLataArray.push(intralatalist.configDetails[1]);
                }
                this.formRule = intralatalist.configDetails[0].formItems[0].attributeType;
                let res = this.formRule.indexOf('Rule-');
                this.formRule = this.formRule.substring(res + 5, this.formRule.length);
                if (this.formRule !== '') this.restrictivePotsSelected = true;
            }
            let interlatalist = temp && temp.configItems && find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "") === 'LongDistance-InterLata';
            });
            if (!interlatalist && temp && temp.configItems) {
                for (let i = 0; i < temp.configItems.length; i++) {
                    if (temp.configItems[i].configDetails && temp.configItems[i].configDetails[0] && temp.configItems[i].configDetails[0].formName.replace(/\s/g, "").toLowerCase() === 'ldcarrierinterlata') {
                        interlatalist = temp.configItems[i];
                        break;
                    }
                }
            }
            if (interlatalist && interlatalist.configDetails && interlatalist.configDetails.length > 0 && interlatalist.configDetails[0].formItems && interlatalist.configDetails[0].formItems.length > 0 && interlatalist.configDetails[0].formItems[0].attributeValue && interlatalist.configDetails[0].formItems[0].attributeValue.length > 0) {
                this.phoneConfigInputData.ldCarrierData.interLataArray = interlatalist.configDetails[0].formItems[0].attributeValue;
                if (interlatalist.configDetails[1]) {
                    this.phoneConfigInputData.ldCarrierData.interLataArray.push(interlatalist.configDetails[1]);
                }
            }

            let voicemail = temp && temp.configItems && find(temp.configItems, (o) => {
                return o.productName === 'Voice Mail' || o.productName === 'Voice Messaging'
            });
            if (voicemail && voicemail.configDetails && voicemail.configDetails.length > 0 && voicemail.configDetails[0].formItems
                && voicemail.configDetails[0].formItems.length > 0) {
                let msgindicator = find(voicemail.configDetails[0].formItems, (o) => o.attributeName === "Message Indicator");
                if (msgindicator) {
                    this.phoneConfigInputData.voiceMailData.mesageIndicatorArray = msgindicator.attributeValue;
                }
                let ringCycle = find(voicemail.configDetails[0].formItems, (o) => o.attributeName === "Ring cycle");
                if (ringCycle) {
                    this.phoneConfigInputData.voiceMailData.ringCycleArray = ringCycle.attributeValue;
                }
                let languageVersion = find(voicemail.configDetails[0].formItems, (o) => o.attributeName === "Language Version");
                if (languageVersion) {
                    this.phoneConfigInputData.voiceMailData.langArray = languageVersion.attributeValue;
                }
            }

            let callFwdBusy = temp && temp.configItems && find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "") === 'CallForwarding-Busy'
            });
            if (callFwdBusy) {
                this.phoneConfigInputData.callForwarding.fwdOnBusy = callFwdBusy.attributeValue;
            }
            let callFwdNoAnswer = temp && temp.configItems && find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer'
            });
            if (callFwdNoAnswer && callFwdNoAnswer.configDetails && callFwdNoAnswer.configDetails.length > 0 && callFwdNoAnswer.configDetails[0].formItems
                && callFwdNoAnswer.configDetails[0].formItems.length > 0) {
                let ringCycle = find(callFwdNoAnswer.configDetails[0].formItems, (o) => o.attributeName === "Ring cycle");
                if (ringCycle) {
                    ringCycle.attributeValue && ringCycle.attributeValue.map(ring => {
                        if (this.switchData) {
                            this.switchData.outputAttribute && this.switchData.outputAttribute.map(attr => {
                                if (attr && attr[3] && attr[3].replace(/\s/g, "") === 'CallForwarding-NoAnswer' && attr[5] && attr[5] === 'Ring Cycle' &&
                                    attr[7] && attr[6] === 'NOTAVAILABLE' && attr[6] && ring && ring.value.indexOf(attr[6]) !== -1) {
                                    ring.disable = true;
                                    ring.hoverText = attr[15]
                                }
                            })
                        }
                    })
                    this.phoneConfigInputData.callForwarding.ringCycleArray = ringCycle.attributeValue;
                }
            }

            //EX-CONFIGURATION
            let exTemp = this.existingConfiguration;
            if (exTemp) {
                this.macd = true;
                intralatalist = find(exTemp.configItems, (o) => {
                    return o.productName.replace(/\s/g, "") === 'LongDistance-IntraLata'
                });
                if (!intralatalist && exTemp && exTemp.configItems) {
                    for (let i = 0; i < exTemp.configItems.length; i++) {
                        if (exTemp.configItems[i].configDetails && exTemp.configItems[i].configDetails[0] && exTemp.configItems[i].configDetails[0].formName.replace(/\s/g, "").toLowerCase() === 'ldcarrierintralata') {
                            intralatalist = exTemp.configItems[i];
                            break;
                        }
                    }
                }
                if (intralatalist && intralatalist.configDetails && intralatalist.configDetails.length > 0 && intralatalist.configDetails[0].formItems && intralatalist.configDetails[0].formItems.length > 0 && intralatalist.configDetails[0].formItems[0].attributeValue && intralatalist.configDetails[0].formItems[0].attributeValue.length > 0) {
                    this.exPhoneConfigInputData.ldCarrierData.intraLataArray = intralatalist.configDetails[0].formItems[0].attributeValue;
                }
                interlatalist = find(exTemp.configItems, (o) => {
                    return o.productName.replace(/\s/g, "") === 'LongDistance-InterLata'
                });
                if (!interlatalist && exTemp && exTemp.configItems) {
                    for (let i = 0; i < exTemp.configItems.length; i++) {
                        if (exTemp.configItems[i].configDetails && exTemp.configItems[i].configDetails[0] && exTemp.configItems[i].configDetails[0].formName.replace(/\s/g, "").toLowerCase() === 'ldcarrierinterlata') {
                            interlatalist = exTemp.configItems[i];
                            break;
                        }
                    }
                }
                if (interlatalist && interlatalist.configDetails && interlatalist.configDetails.length > 0 && interlatalist.configDetails[0].formItems && interlatalist.configDetails[0].formItems.length > 0 && interlatalist.configDetails[0].formItems[0].attributeValue && interlatalist.configDetails[0].formItems[0].attributeValue.length > 0) {
                    this.exPhoneConfigInputData.ldCarrierData.interLataArray = interlatalist.configDetails[0].formItems[0].attributeValue;
                }
                voicemail = find(exTemp.configItems, (o) => {
                    return o.productName === 'Voice Mail' || o.productName === 'Voice Messaging'
                });
                if (voicemail && voicemail.configDetails && voicemail.configDetails.length > 0 && voicemail.configDetails[0].formItems
                    && voicemail.configDetails[0].formItems.length > 0) {
                    let msgindicator = find(voicemail.configDetails[0].formItems, (o) => o.attributeName === "Message Indicator");
                    if (msgindicator) {
                        this.exPhoneConfigInputData.voiceMailData.mesageIndicatorArray = msgindicator.attributeValue;
                    }
                    let ringCycle = find(voicemail.configDetails[0].formItems, (o) => o.attributeName === "Ring cycle");
                    if (ringCycle) {
                        ringCycle.attributeValue && ringCycle.attributeValue.map(ring => {
                            if (this.switchData) {
                                this.switchData.outputAttribute && this.switchData.outputAttribute.map(attr => {
                                    if (attr && attr[4] && attr[4] === 'Voice Messaging' && attr[5] && attr[5] === 'Ring Cycle' &&
                                        attr[7] && attr[7] === 'NOTAVAILABLE' && attr[6] && ring && ring.value.indexOf(attr[6]) !== -1) {
                                        ring.disable = true;
                                        ring.hoverText = attr[15]
                                    }
                                })
                            }
                        })
                        this.exPhoneConfigInputData.voiceMailData.ringCycleArray = ringCycle.attributeValue;
                    }
                }

                let callFwdBusy = find(exTemp.configItems, (o) => {
                    return o.productName.replace(/\s/g, "") === 'CallForwarding-Busy'
                });
                if (callFwdBusy && callFwdBusy.configDetails && callFwdBusy.configDetails[0] && callFwdBusy.configDetails[0].formName === 'Call Forwarding'
                    && callFwdBusy.configDetails[0].formItems && callFwdBusy.configDetails[0].formItems[0] && callFwdBusy.configDetails[0].formItems[0].attributeName === 'Forward on Busy'
                    && callFwdBusy.configDetails[0].formItems[0].attributeValue) {
                    this.exPhoneConfigInputData.callForwarding.fwdOnBusy = callFwdBusy.configDetails[0].formItems[0].attributeValue;
                }
                let callFwdNoAnswer = find(exTemp.configItems, (o) => {
                    return o.productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer'
                });
                if (callFwdNoAnswer && callFwdNoAnswer.configDetails && callFwdNoAnswer.configDetails.length > 0 && callFwdNoAnswer.configDetails[0].formItems
                    && callFwdNoAnswer.configDetails[0].formItems.length > 0) {
                    let ringCycle = find(callFwdNoAnswer.configDetails[0].formItems, (o) => o.attributeName === "Ring cycle");
                    if (ringCycle) {
                        this.exPhoneConfigInputData.callForwarding.ringCycleArray = ringCycle.attributeValue;
                    }
                    ringCycle = find(callFwdNoAnswer.configDetails[0].formItems, (o) => o.attributeName.replace(/\s/g, "") === "ForwardonDon'tAnswer");
                    if (ringCycle) {
                        this.exPhoneConfigInputData.callForwarding.fwdNoAns = ringCycle.attributeValue;
                    }
                }
                let listing = find(exTemp.configItems, (o) => {
                    return o.productName.indexOf('Listing') !== -1;
                });
                if (listing && listing.configDetails !== null && listing.configDetails.length !== 0 && listing.configDetails[0].formItems && listing.configDetails[0].formItems.length > 0) {
                    let listingType = find(listing.configDetails[0].formItems, (o) => o.attributeName === "Listing Type");
                    if (listingType) {
                        this.exSelectedListing = listingType.attributeValue[0].value;
                    }
                    this.existingListingDirectory = listing.configDetails[0].formItems;
                }

            }
            let hpObj = this.custdata && this.custdata.payload && this.productService.findObjByName(this.custdata.payload.cart.customerOrderItems, 'offerCategory', 'VOICE-HP');
            if (hpObj) {
                this.potsOfferName = hpObj.offerName;
                this.potsOfferType = hpObj.offerType;
                if (this.phoneConfigInputData.ldCarrierData.intraLataArray && this.phoneConfigInputData.ldCarrierData.intraLataArray[0] && this.phoneConfigInputData.ldCarrierData.intraLataArray[0].value === '' && this.formRule !== '' && !this.toNext) {
                    if (this.lataList) {
                        this.lataCall(false);
                    } else {
                        this.logger.log("info", "customize-services.component.ts", "getLATARequest", JSON.stringify(""));
                        this.logger.startTime();
                        this.productService.getLATA(this.potsOfferName, this.formRule, this.wireCenter, this.city, this.state)
                            .catch((error: any) => {
                                this.logger.endTime();
                                this.logger.log("error", "customize-services.component.ts", "getLATAResponse", error);
                                this.logger.log("error", "customize-services.component.ts", "getLATASrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                this.ctlHelperService.setLocalStorage('error', error);
                                return Observable.throw(error._body);
                            })
                            .subscribe(data => {
                                this.logger.endTime();
                                this.logger.log("info", "customize-services.component.ts", "getLATAResponse", JSON.stringify(data ? data : ""));
                                this.logger.log("info", "customize-services.component.ts", "getLATASrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                if (data && data.outputAttribute) {
                                    this.lataList = data.outputAttribute;
                                    this.lataCall(false);
                                }
                            }, (error) => {
                                this.logger.endTime();
                                this.logger.log("error", "customize-services.component.ts", "getLATAResponse", error);
                                this.logger.log("error", "customize-services.component.ts", "getLATASrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                if (error === undefined || error === null) return;
                                let unexpectedError = false;
                                if (this.ctlHelperService.isJson(error)) {
                                    this.apiResponseError = JSON.parse(error);
                                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                                        this.apiResponseError.errorResponse.length > 0) {
                                        this.systemErrorService.logAndeRouteToSystemError("error", "productService - getLATA", "customize-services.component.ts", "Customized Services Page", this.apiResponseError);
                                    } else unexpectedError = true;
                                } else unexpectedError = true;
                                if (unexpectedError) {
                                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                                    this.systemErrorService.logAndeRouteToSystemError("error", "productService - getLATA", "customize-services.component.ts", "Customized Services Page", lAPIErrorLists);
                                }
                            })
                    }
                } else {
                    this.loading = false;
                }
                if (!this.loadedInitialize) {
                    this.loadedInitialize = true;
                    let potsBooleans: any;
                    let retainVal = <Observable<any>>this.store.select('retain');
                    let retSubscribe: Subscription = retainVal.subscribe(
                        (retVal => {
                            this.previousLoaded = retVal.potsOffer;
                            if (this.switchData) {
                                this.compatibilityArray.outArrHeader = this.switchData.outArrHeader;
                                this.switchData.outputAttribute && this.switchData.outputAttribute.map(attr => {
                                    if (attr) this.compatibilityArray.outputAttribute.push(attr);
                                })
                            }
                            potsBooleans = retVal.potsBooleans;
                            this.voiceMailAdded = potsBooleans && potsBooleans.voiceMail;
                            this.isReEntrant && retVal.prodConfig && retVal.prodConfig.prodConfig && retVal.prodConfig.prodConfig[0] && retVal.prodConfig.prodConfig[0].configItems && retVal.prodConfig.prodConfig[0].configItems.map((a) => {
                                if (a && a.configDetails && a.configDetails[0] && a.configDetails[0].formName.replace(/\s+/g, '').toLowerCase() === 'easytalk2' || a.configDetails[0].formName.replace(/\s+/g, '').toLowerCase() === 'centurylinkunlimited' ||
                                    a.configDetails[0].formName.replace(/\s+/g, '').replace("-", "").toLowerCase() === 'longdistanceinterlata') {
                                    this.productName = a.productName;
                                }

                            })
                        })
                    )
                    let p = [];
                    p.push({
                        defaultOfferPrice: hpObj.defaultOfferPrice = { rc: hpObj.rc, discountedRc: hpObj.discountedRc, otc: hpObj.otc, discountedOtc: hpObj.discountedOtc },
                        displayOrder: 0,
                        isDefault: false,
                        productOfferingId: hpObj.productOfferingId,
                        sequence: 1,
                        catalogId: hpObj.catalogId,
                        productOffer: {
                            associatedOffers: [],
                            contract: hpObj.contractTerm !== null ? hpObj.contractTerm : 0,
                            offerAttributes: [],
                            offerCategory: hpObj.offerCategory,
                            offerDisplayName: 'Package & Features',
                            offerName: this.potsOfferName,
                            offerSubType: hpObj.offerSubType,
                            offerType: hpObj.offerType,
                            productOfferingId: hpObj.productOfferingId,
                            productComponents: (this.previousLoaded && this.previousLoaded !== undefined && this.previousLoaded.customerOrderSubItems !== undefined) ? this.previousLoaded.customerOrderSubItems : "",
                            customProdName: 'Package and Features',
                            accordianTitle: 'Package and Features',
                            accordionDisplayName: '',
                            hasQuantity: false,
                            action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((hpObj.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)))) && this.isAmend ? 'ADD' : hpObj.action
                        }
                    });

                    p.catalogCategory = 'HP ADDON OFFER';
                    let hpObject = cloneDeep(p);
                    for (let i = 0; i < hpObj.customerOrderSubItems.length; i++) {
                        if (hpObj.customerOrderSubItems[i].componentType === GenericValues.cPrimary) {
                            this.primaryPOTS = hpObj.customerOrderSubItems[i] && hpObj.customerOrderSubItems[i].productName;
                        }
                    };
                    let insideAddon = false;
                    if (this.previousLoaded && this.previousLoaded !== undefined && this.previousLoaded.customerOrderSubItems.length > 0) {
                        for (let i = 0; i < this.previousLoaded.customerOrderSubItems.length; i++) {
                            let breakFor = false;
                            if (potsBooleans && potsBooleans.voiceMail) {
                                this.isDisablePOTSVoiceMail = true;
                            }
                            if (this.previousLoaded && this.previousLoaded.customerOrderSubItems && this.previousLoaded.customerOrderSubItems[i] &&
                                this.previousLoaded.customerOrderSubItems[i].product && this.previousLoaded.customerOrderSubItems[i].product.productName &&
                                (this.previousLoaded.customerOrderSubItems[i].product.productName.indexOf('Wire Maintenance Plan') !== -1 ||
                                    this.previousLoaded.customerOrderSubItems[i].product.productName.indexOf('Jack and Wire') !== -1 || breakFor ||
                                    this.previousLoaded.customerOrderSubItems[i].product.productName === 'Voice Messaging' ||
                                    this.previousLoaded.customerOrderSubItems[i].displayOrder === 0 ||
                                    (this.previousLoaded.customerOrderSubItems[i].isDefault === 0 && this.previousLoaded.customerOrderSubItems[i].isMandatory) ||
                                    (potsBooleans && potsBooleans.voiceMail && (this.previousLoaded.customerOrderSubItems[i].product.productName === 'Easy Access' ||
                                        this.previousLoaded.customerOrderSubItems[i].product.productName === 'Voice Mail  - Indicator' || this.previousLoaded.customerOrderSubItems[i].product.productName === 'Voice Mail  - Visual')))) {
                                continue;
                            }
                            if (i === 0 || !insideAddon) {
                                insideAddon = true;
                                hpObject[0].productOffer.productComponents = [];
                                hpObject.catalogCategory = 'HP ADDON OFFER';
                                hpObject[0].productOffer.productComponents.push(this.previousLoaded.customerOrderSubItems[i]);
                                hpObject[0].productOffer.accordionDisplayName = this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName;
                                if (this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct !== null && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct) {
                                    hpObject[0].sequence = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.selectionGroup;
                                    hpObject[0].productOffer.customProdName = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct !== null && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.selectionGroup;
                                    hpObject[0].productOffer.accordianTitle = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory;
                                    hpObject[0].productOffer.accordionDisplayName = this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName ?
                                        this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName :
                                        this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.subGroup ?
                                            this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.subGroup : this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory;
                                }
                                hpObject[0].productOffer.hasQuantity = false;
                                hpObject[0].catalogId = this.previousLoaded.catalogId;
                                hpObject[0].action = this.previousLoaded.action;
                                hpObject[0].catalogCategory = 'HP ADDON OFFER';
                                continue;
                            }
                            let prdCtry = false;
                            for (let j = 0; j < hpObject.length; j++) {
                                if (this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory ===
                                    hpObject[j].productOffer.customProdName) {
                                    prdCtry = true;
                                    hpObject[j].productOffer.accordionDisplayName = this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName;
                                    if (this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct !== null && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct) {
                                        hpObject[j].productOffer.customProdName = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.selectionGroup;
                                        hpObject[j].sequence = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.selectionGroup;
                                        hpObject[j].productOffer.accordianTitle = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory;
                                        hpObject[j].productOffer.accordionDisplayName = this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName ?
                                            this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName : this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.subGroup ?
                                                this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.subGroup : this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory;
                                    }
                                    hpObject[j].productOffer.hasQuantity = false;
                                    hpObject[j].productOffer.productComponents.push(this.previousLoaded.customerOrderSubItems[i]);
                                    hpObject[j].catalogCategory = 'HP ADDON OFFER';
                                }
                            }
                            if (!prdCtry) {
                                let j = hpObject.length;
                                hpObject[j] = cloneDeep(p[0]);
                                hpObject[j].productOffer.productComponents = [];
                                if (hpObject[j].productOffer.accordionDisplayName === '' || hpObject[j].productOffer.accordionDisplayName === null)
                                    hpObject[j].productOffer.accordionDisplayName = this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName;
                                if (this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct !== null && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct) {
                                    hpObject[j].productOffer.customProdName = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.selectionGroup;
                                    hpObject[j].sequence = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.selectionGroup;
                                    hpObject[j].productOffer.accordianTitle = this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory;
                                    if (hpObject[j].productOffer.accordionDisplayName === '' || hpObject[j].productOffer.accordionDisplayName === null)
                                        hpObject[j].productOffer.accordionDisplayName = this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName ?
                                            this.previousLoaded.customerOrderSubItems[i].product.productCategoryDisplayName : this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct && this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.subGroup ?
                                                this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.subGroup : this.previousLoaded.customerOrderSubItems[i].additionalUiAttrProduct.productSubCategory;
                                }
                                hpObject[j].productOffer.hasQuantity = false;
                                hpObject[j].productOffer.productComponents.push(this.previousLoaded.customerOrderSubItems[i]);
                                hpObject[j].catalogCategory = 'HP ADDON OFFER';
                            }
                        }
                    }
                    if (potsClone) {
                        potsClone.catalogs[0].catalogItems.catalogCategory = 'HP ADDON OFFER';
                        for (let i = 0; i < potsClone.catalogs[0].catalogItems.length; i++) {
                            for (let a = 0; a < potsClone.catalogs[0].catalogItems[i].productOffer.productComponents.length; a++) {
                                if ((potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].displayOrder > 0 &&
                                    ((potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productType !== 'WIRINGWORKS') ||
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productType === 'WIRINGWORKS' && (!this.newHSI || this.isNewInstall))) ||
                                    (potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].displayOrder === 0 &&
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productType === 'WIRINGWORKS' &&
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Trip Charge Regular' &&
                                        !this.newHSI)) {
                                    let prdCtry = false;
                                    let hpClone = cloneDeep(potsClone);
                                    prdCtry = true;
                                    let j = hpObject.length;
                                    hpClone.catalogs[0].catalogItems[i].productOffer.productComponents = [];
                                    hpObject[j] = cloneDeep(hpClone.catalogs[0].catalogItems[i]);
                                    hpObject[j].catalogCategory = 'HP ADDON OFFER';
                                    hpObject[j].productOffer.accordionDisplayName = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productCategoryDisplayName;
                                    if (potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct &&
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct !== null) {
                                        hpObject[j].productOffer.customProdName = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct.selectionGroup;
                                        hpObject[j].sequence = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct.selectionGroup;
                                        hpObject[j].productOffer.accordianTitle = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct.productSubCategory;
                                        hpObject[j].productOffer.accordionDisplayName = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productCategoryDisplayName ?
                                            potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productCategoryDisplayName :
                                            potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct.subGroup ?
                                                potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct.subGroup : potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].additionalUiAttrProduct.productSubCategory;
                                    }
                                    hpObject[j].productOffer.hasQuantity = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Additional Jack and Wire' ? true : false;
                                    if (potsClone && potsClone.catalogs[0] && potsClone.catalogs[0].catalogItems[i] && potsClone.catalogs[0].catalogItems[i].productOffer &&
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents && potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a]) {
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].productOfferingId = potsClone.catalogs[0].catalogItems[i].productOffer.productOfferingId;
                                        potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].hasQuantity = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Additional Jack and Wire' ? true : false;
                                        let prodComp = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a];
                                        if (prodComp.product.productName === 'In Wire or Jack 1st 1/2 HR T/M' && potsClone.catalogs[0].catalogItems[i]
                                            && potsClone.catalogs[0].catalogItems[i].defaultOfferPrice) {
                                            let price = potsClone.catalogs[0].catalogItems[i].defaultOfferPrice;
                                            price.discountedOtc === 0 ? price = price.otc : price = price.discountedOtc
                                            prodComp.product.price = price;
                                        }
                                        hpObject[j].productOffer.productComponents.push(prodComp);
                                    }
                                    hpObject[j].catalogId = potsClone.catalogs[0].catalogId;
                                    hpObject[j].displayOrder = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].displayOrder;
                                    if (!prdCtry) {
                                        let j = hpClone.catalogs[0].catalogItems.length;
                                        hpClone.catalogs[0].catalogItems[j] = cloneDeep(potsClone.catalogs[0].catalogItems[i]);
                                        hpClone.catalogs[0].catalogItems[j].productOffer.productComponents = [];
                                        if (potsClone && potsClone.catalogs[0] && potsClone.catalogs[0].catalogItems[i] && potsClone.catalogs[0].catalogItems[i].productOffer &&
                                            potsClone.catalogs[0].catalogItems[i].productOffer.productComponents) {
                                            potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].productOfferingId = potsClone.catalogs[0].catalogItems[i].productOffer.productOfferingId;
                                            potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].hasQuantity = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a].product.productName === 'Additional Jack and Wire' ? true : false;
                                            let prodComp = potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a];
                                            if (prodComp.product.productName === 'In Wire or Jack 1st 1/2 HR T/M' && potsClone.catalogs[0].catalogItems[i]
                                                && potsClone.catalogs[0].catalogItems[i].defaultOfferPrice) {
                                                let price = potsClone.catalogs[0].catalogItems[i].defaultOfferPrice;
                                                price.discountedOtc === 0 ? price = price.otc : price = price.discountedOtc
                                                prodComp.product.price = price;
                                            }
                                            hpObject[j].productOffer.productComponents.push(prodComp);
                                            hpClone.catalogs[0].catalogItems[j].productOffer.productComponents.push(potsClone.catalogs[0].catalogItems[i].productOffer.productComponents[a]);
                                        }
                                        hpClone.catalogs[0].catalogItems[j].productOffer.customProdName = hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategory;
                                        hpClone.catalogs[0].catalogItems[j].productOffer.accordianTitle = hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategory;
                                        if (hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct) {
                                            hpClone.catalogs[0].catalogItems[j].productOffer.customProdName = hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.selectionGroup ?
                                                hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.selectionGroup : hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategory;
                                            hpClone.catalogs[0].catalogItems[j].sequence = hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.selectionGroup;
                                            hpClone.catalogs[0].catalogItems[j].productOffer.accordianTitle = hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct && hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.productSubCategory ?
                                                hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.productSubCategory : hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategory;
                                        }
                                        hpClone.catalogs[0].catalogItems[j].productOffer.hasQuantity = false;
                                        hpClone.catalogs[0].catalogItems[j].catalogId = hpClone.catalogs[0].catalogId;
                                        hpClone.catalogs[0].catalogItems[j].displayOrder = hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].displayOrder;
                                        let k = hpObject.length;
                                        hpObject[k] = (hpClone.catalogs[0].catalogItems[j]);
                                        hpObject[k].catalogCategory = 'HP ADDON OFFER';
                                        if (hpObject[k].productOffer.accordionDisplayName === '' || hpObject[k].productOffer.accordionDisplayName === null)
                                            hpObject[k].productOffer.accordionDisplayName = potsClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategoryDisplayName ?
                                                potsClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].product.productCategoryDisplayName :
                                                hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct &&
                                                    hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.subGroup ?
                                                    hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct &&
                                                    hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.subGroup : hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct &&
                                                    hpClone.catalogs[0].catalogItems[j].productOffer.productComponents[0].additionalUiAttrProduct.productSubCategory;
                                    }
                                }
                            }
                        }
                    }
                    if (retSubscribe !== undefined)
                        retSubscribe.unsubscribe();
                    this.potsComponent = hpObject[0];
                    let nonPubListing = [];
                    this.listingNameData.map(listingname => {
                        if (listingname === "Non-Pub No Charge") {
                            nonPubListing.push({
                                defaultOfferPrice: hpObj.defaultOfferPrice = { rc: hpObj.rc, discountedRc: hpObj.discountedRc, otc: hpObj.otc, discountedOtc: hpObj.discountedOtc },
                                displayOrder: 1,
                                isDefault: false,
                                productOfferingId: hpObj.productOfferingId,
                                sequence: 2.5,
                                productOffer: {
                                    associatedOffers: [],
                                    contract: hpObj.contractTerm !== null ? hpObj.contractTerm : 0,
                                    offerAttributes: [],
                                    offerCategory: hpObj.offerCategory,
                                    offerDisplayName: 'Listings',
                                    offerName: this.potsOfferName,
                                    offerSubType: hpObj.offerSubType,
                                    offerType: hpObj.offerType,
                                    productOfferingId: hpObj.productOfferingId,
                                    productComponents: [{
                                        displayOrder: 1,
                                        hasQuantity: false,
                                        product: {
                                            productDisplayName: 'Non-Pub No Charge',
                                            productName: 'Non-Pub No Charge'
                                        }
                                    }],
                                    customProdName: 'Listings',
                                    accordianTitle: 'Listings',
                                    accordionDisplayName: '',
                                    hasQuantity: false,
                                    action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((hpObj.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)))) && this.isAmend ? 'ADD' : hpObj.action
                                }
                            });
                        }
                    });
                    /*             if(this.additionalValuesAval){
                        nonPubListing[0].productOffer.productComponents.push({
                            displayOrder: 1,
                            hasQuantity: true,
                            product: {
                            quantity : {
                                minQuantity: 1,
                                maxQuantity: this.listingQuantity,
                                defaultQuantity: 1
                                },
                            productDisplayName: 'Additional Listing',                        
                            productName: 'Additional Listing'
                            }
                            })                  
                    } */
                    if (nonPubListing.length > 0) {
                        hpObject.push(nonPubListing[0]);
                    }
                    this.hpCData = hpObject;
                    this.hpCData.catalogCategory = 'HP ADDON OFFER';
                    this.hpCData = hpObject.reduce((acc, item) => {
                        const parent = acc.filter(obj => obj.productOffer.accordianTitle ? obj.productOffer.accordianTitle === item.productOffer.accordianTitle && item.productOffer.offerType === obj.productOffer.offerType :
                            obj.productOffer.offerDisplayName === item.productOffer.offerDisplayName && item.productOffer.offerType === obj.productOffer.offerType);
                        parent.length ? (parent[0].productOffer.productComponents = parent[0].productOffer.productComponents.concat(item.productOffer.productComponents)) : acc.push(item);
                        return acc;
                    }, []);
                    this.hpCData.catalogCategory = 'HP ADDON OFFER';
                    this.hpCData = this.hpCData.sort(this.offerHelperService.dynamicSort("sequence"))
                }
            }
            this.phoneConfigInputData.tnData.reservedTNs = this.custdata && this.custdata.payload && this.custdata.payload.reservedTN && filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'VOICE-DHP' || obj.productType === 'VOICE-HP' });

            if (!this.refObj.disablePhone || !this.refObj.disableHp) {
                let filteredDHPTN = this.custdata && this.custdata.payload && this.custdata.payload.reservedTN && filter(this.custdata.payload.reservedTN, (obj) => { return obj.productType === 'VOICE-DHP' || obj.productType === 'VOICE-HP' })
                this.phoneConfigInputData.tnData.selectedTN = filteredDHPTN && filteredDHPTN[0] ? filteredDHPTN[0].requestedTelephoneNumber : '';
                if (this.phoneConfigInputData.tnData.selectedTN === '') {
                    this.phoneConfigInputData.tnData.haveData = false;
                }
            }
        }
        if (this.refObj.disableHp) this.loading = false;
    }

    public assessCharge: any[] = [];
    private fetchAssessCharge(addonOffers) {
        this.assessCharge = [];
        addonOffers && addonOffers.catalogs && addonOffers.catalogs.map((catalog) => {
            catalog && catalog.catalogItems && catalog.catalogItems.map((catalogItem) => {
                if (catalogItem && catalogItem.productOffer) {
                    if (catalogItem.productOffer.offerName.indexOf('Personalize Nbr Chrg') > -1) {
                        let price = this.getPriceofProduct(catalogItem)
                        this.assessCharge.push({ offerName: 'Custom Number', otc: price });
                        this.ctlHelperService.setLocalStorage('custom_number', catalogItem);
                    } else if (catalogItem.productOffer.offerName.indexOf('Same Number Charge') > -1) {
                        let price = this.getPriceofProduct(catalogItem)
                        this.assessCharge.push({ offerName: 'Same Number', otc: price });
                        this.ctlHelperService.setLocalStorage('same_number', catalogItem);
                    }
                }
            });
        });
    }

    public getPriceofProduct = (catalogItem) => {
        let finalprices;
        catalogItem && catalogItem.productOffer && catalogItem.productOffer.productComponents && catalogItem.productOffer.productComponents.map(product => {
            product && product.product && product.product.productAttributes && product.product.productAttributes.map(attr => {
                if (attr.isPriceable === true) {
                    finalprices = attr.prices[0].discountedOtc;
                }
            })
        });
        if (finalprices) { return finalprices; }
        else {
            return 0;
        }
    }

    public tnChargeMergeToReq(req) {
        let customize = <Observable<any>>this.store.select('customize');
        let selectedAssessCharge, isTnReserved;
        this.customizeSubscription = customize.subscribe((data) => {
            if (data && data.selectedAssessCharge) {
                selectedAssessCharge = data.selectedAssessCharge;
            }
            if (data && data.isTnReserved) {
                isTnReserved = data.isTnReserved;
            }
        });
        if (this.customizeSubscription !== undefined) this.customizeSubscription.unsubscribe();
        if (this.isModemConverted) {
            let additionalAttr = [
                {
                    "orderAttributeGroup": [
                        {
                            "orderAttributeGroupName": "convertToPurchaseModem",
                            "orderAttributeGroupInfo": [
                                {
                                    "orderAttributes": [
                                        {
                                            "orderAttributeName": "convertToPurchase",
                                            "orderAttributeValue": "YES"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ];
            if (req.payload && req.payload.addlOrderAttributes && req.payload.addlOrderAttributes.length > 0) {
                req.payload.addlOrderAttributes.push(additionalAttr[0])
            } else {
                req.payload.addlOrderAttributes = additionalAttr;
            }
        }
        let catalog;
        if (selectedAssessCharge === 'Custom Number') catalog = this.ctlHelperService.getLocalStorage('custom_number');
        else catalog = this.ctlHelperService.getLocalStorage('same_number');
        if (catalog) {
            let tnProduct = this.ctlHelperService.catalogItemToCustSubItem(catalog, 'ADD');
            if (isTnReserved && selectedAssessCharge) {
                req && req.payload && req.payload.cart && req.payload.cart.customerOrderItems && req.payload.cart.customerOrderItems.map((custItem) => {
                    if (custItem && custItem.offerCategory === 'VOICE-HP' && custItem.offerType === 'SUBOFFER') {
                        if (custItem && custItem.customerOrderSubItems) {
                            custItem.customerOrderSubItems.push(tnProduct);
                        }
                    }
                });
            }
        }
        return req;
    }

    private removeDeleteActionOrderSubItems = (req) => {
        req && req.payload && req.payload.cart && req.payload.cart.customerOrderItems && req.payload.cart.customerOrderItems.map((custItem) => {
            if (custItem && custItem.offerCategory === 'VOICE-HP' && custItem.offerType === 'P4L' && custItem.action !== 'REMOVE') {
                if (custItem && custItem.customerOrderSubItems) {
                    custItem.customerOrderSubItems = custItem.customerOrderSubItems.filter(item => { return (item.action !== "REMOVE"); });
                }
            }
        });
        return req;
    };

    public telephoneError(errorOn: string) {
        if (this.previousUrl !== '/billing-product') {
            let errorResponseArray: ErrorResponse[] = [];
            let localErrorResponse: ErrorResponse = {
                orderRefNumber: this.custdata.orderRefNumber,
                statusCode: serverErrorMessages.statusCode,
                reasonCode: serverErrorMessages.statusCode,
                message: serverErrorMessages.serverDownAddons,
                messageDetail: errorOn === 'tn' ? serverErrorMessages.telephoneNumberEmpty : serverErrorMessages.productConfigEmpty
            }
            errorResponseArray.unshift(localErrorResponse);
            let lAPIErrorLists: APIErrorLists = {
                errorResponse: errorResponseArray
            };
            this.systemErrorService.logAndeRouteToSystemError("error", this.custdata.taskName, "customize-services.component.ts", "Add-Ons Page", lAPIErrorLists);
        }
    }

    /** Generic: active tab selection handler */
    public tabSelected(tab, selected) {
        if (tab === 'INTERNET') {
            this.internetActive = true;
            this.prismActive = false;
            this.phoneActive = false;
            this.dtvActive = false;
            this.hpActive = false;
        } else if (tab === 'prism') {
            this.prismActive = true;
            this.internetActive = false;
            this.phoneActive = false;
            this.dtvActive = false;
            this.hpActive = false;
        } else if (tab === "PHONE") {
            this.prismActive = false;
            this.internetActive = false;
            this.phoneActive = true;
            this.dtvActive = false;
            this.hpActive = false;
        } else if (tab === 'Dtv') {
            this.prismActive = false;
            this.internetActive = false;
            this.phoneActive = false;
            this.dtvActive = true;
            this.hpActive = false;
        } else if (tab === 'hp') {
            this.prismActive = false;
            this.internetActive = false;
            this.phoneActive = false;
            this.dtvActive = false;
            this.hpActive = true;
        }
    }

    /** Undo updates click handler */
    public undoAll() {
        this.refObj.isUndo = false;
        for (let selectedbox of this.selectedObjectsList) {
            selectedbox.customerOrderSubItems = [];
        }
        this.isUndoAll = true;
        this.store.dispatch({ type: 'UPDATE_ADDON', payload: [] });
        this.changeDetector.detectChanges();
        this.initializeData();
    }

    private listingDhpValidate() {
        let check = true;
        let phoneconfigData = this.phoneConfigForm.get("phoneConfigData").value;
        if (phoneconfigData && phoneconfigData !== undefined && phoneconfigData.callfwdForm && phoneconfigData.callfwdForm !== undefined && phoneconfigData.callfwdForm.fwdOnDontAnswer && phoneconfigData.callfwdForm.fwdOnDontAnswer !== undefined) {
            phoneconfigData.callfwdForm.fwdOnDontAnswer = phoneconfigData.callfwdForm.fwdOnDontAnswer.replace(/\D+/g, '');
        }
        if (phoneconfigData && phoneconfigData !== undefined && phoneconfigData.callfwdForm && phoneconfigData.callfwdForm !== undefined && phoneconfigData.callfwdForm.fwdOnBusy && phoneconfigData.callfwdForm.fwdOnBusy !== undefined) {
            phoneconfigData.callfwdForm.fwdOnBusy = phoneconfigData.callfwdForm.fwdOnBusy.replace(/\D+/g, '');
        }
        if ((this.dhpCData.length !== 0 && !this.refObj.disablePhone) || (this.hpCData.length !== 0 && !this.refObj.disableHp)) {

            if (phoneconfigData.listingForm.selectedOption && phoneconfigData.listingForm.selectedOption.toString().toLowerCase() === 'listed') {
                if (phoneconfigData.listingForm.firstName === '' || phoneconfigData.listingForm.lastName === '') {
                    check = false;
                }
            }
        }
        return check;
    }

    public getAdditionalPortingData(portingAddlData) {
        this.addlPortingData = portingAddlData;
        this.portingNotComplete = false;
    }

    public updateAddlAttributes(x: any) {
        if (this.isReEntrant) {
            this.observable.subscribe((data) => {
                this.selectedGiftcard = data.selectedGiftCard ? data.selectedGiftCard : [];
            })
        }
        if (this.selectedGiftcard.indexOf(x) < 0) {
            this.selectedGiftcard.push(x);
        } else {
            this.selectedGiftcard.splice(this.selectedGiftcard.indexOf(x), 1);
        }
        this.store.dispatch({ type: 'SELCTED_GIFTCARDS', payload: this.selectedGiftcard });
    }

    public updateIsBypassedOption(event: any) {
        this.isBypassed = event;
    }

    public getAdditionalPortingDataAccountId(portingAddlData) {
        this.addlPortingDataAccountId = portingAddlData;
    }

    public getSelectedProg(program) {
        this.selectedProg = program;
    }
    public getListedAddressOption(option) {
        this.selectedListedAddressOption = option;
        this.checkForDirectoryListingChange();
    }

    public getListedAddressFields(updatedAddress) {
        this.updatedListedAddressFields = updatedAddress;
        this.checkForDirectoryListingChange();
    }

    public getChangedAddressListing(address) {
        this.changedListedAddress = address;
        this.checkForDirectoryListingChange();
    }

    public frameAdditionalAttributesRequest() {
        if (this.portedType && this.portedType === 'EXTPORTED' && this.addlPortingData) {
            return this.addlPortingData;
        }
        else if (this.addlPortingDataAccountId) {
            return this.addlPortingDataAccountId;
        }
        if (this.wliLocationAvail && (this.isNewInstall || this.isMove)) {
            let addlOrderAttributes
            return addlOrderAttributes = [
                {
                    "orderAttributeGroup": [
                        {
                            "orderAttributeGroupName": "workingServiceInfo",
                            "orderAttributeGroupInfo": [
                                {
                                    "orderAttributes": [
                                        {
                                            "orderAttributeName": "isExistingAccountValid",
                                            "orderAttributeValue": this.wliLocationAvail
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    }

    private listingSelection(listingValue) {
        let tempArray = [];
        this.listingToCart.customerOrderSubItems[0].productAttributes.map((v, i) => {
            if (v.compositeAttribute && v.compositeAttribute.length > 0) {
                return v.compositeAttribute.map((comp, index) => {
                    if (comp.attributeName !== 'Listing Type' || (comp.attributeName === 'Listing Type' && comp.attributeValue === listingValue)) {
                        tempArray.push(v);
                    }
                })
            }
        });
        return tempArray;
    }

    private listingSelectionChange(listingValue) {
        let tempArray = [];
        this.listingToCart.customerOrderSubItems[1].productAttributes.map((v, i) => {
            if (v.compositeAttribute && v.compositeAttribute.length > 0) {
                return v.compositeAttribute.map((comp, index) => {
                    if (comp.attributeName !== 'Listing Change' || (comp.attributeName === 'Listing Change' && comp.attributeValue === listingValue)) {
                        tempArray.push(v);
                    }
                })
            }
        });
        return tempArray;
    }
    public onTnBackSelectedAgain(event) {
        if (event) {
            this.newReserveTNObject = event;
        }
    }


    public isPortingOpen(value) {
        if (value) {
            this.portedreq = false;
        } else {
            this.portedreq = true;
        }
    }
    public tnPortingSelected(portinvalue) {
        this.portingTnResponse = portinvalue;
    }

    public getAccordionStatus(bool) {
        if (bool && this.custSubscription !== undefined) {
            this.custSubscription.unsubscribe();
        }
        this.accordianHandling.tn = bool;
        let phoneconfigData = this.phoneConfigForm.get("phoneConfigData").value;

        if (phoneconfigData.tnForm && phoneconfigData.tnForm.task !== undefined && phoneconfigData.tnForm.task === 'portedTn' && (phoneconfigData.tnForm.PortingNumber === '' || phoneconfigData.tnForm.PortingNumber === null || phoneconfigData.tnForm.PortingNumber === undefined)) {
            this.portingNotComplete = true;
        }
        else if (phoneconfigData.tnForm && phoneconfigData.tnForm.task !== undefined && phoneconfigData.tnForm.task === 'assignedTn' && (phoneconfigData.tnForm.SelectedPhoneNumber === '' || phoneconfigData.tnForm.SelectedPhoneNumber === null || phoneconfigData.tnForm.SelectedPhoneNumber === undefined)) {
            this.portingNotComplete = true;
        }
        else {
            this.portingNotComplete = false;
        }
    }

    public getTnChangeValue(event) {
        if (event) {
            this.newChangeTn = event;
            this.store.dispatch({ type: 'TN_CHANGED', payload: this.newChangeTn });
            this.portedreq = false;
            let phoneconfigData = this.phoneConfigForm.get("phoneConfigData").value;
            let tn = '';
            if (phoneconfigData.tnForm && phoneconfigData.tnForm.PortingNumber && phoneconfigData.tnForm.task === 'portedTn') {
                tn = phoneconfigData.tnForm.PortingNumber;
            } else if (phoneconfigData.tnForm && phoneconfigData.tnForm.SelectedPhoneNumber && phoneconfigData.tnForm.task === 'assignedTn') {
                tn = phoneconfigData.tnForm.SelectedPhoneNumber;
            }
            if (tn !== '' && tn !== null && tn) {
                this.getSwitchRulesByTN(tn, false);
            }
        }
    }

    public viewRccsDisclosure() {
        let cart1 = <Observable<ShoppingCart>>this.store.select('cart');
        let cartDetails;
        this.cartSubscription = cart1.subscribe((data) => {
            if (data && data.payload && data.payload.cart) {
                cartDetails = data.payload.cart;
            }
        });
        this.loading = true;
        let request = {
            orderRefNumber: this.orderRefNumber,
            rccGroupId: "CUSTOMIZED_SERVICES",
            salesChannel: "ESHOP - Customer Care",
            versionNumber: "",
            cart: this.custdata.cartData ? this.custdata.cartData.cart : this.custdata.payload.cart
        }
        request = this.addGiftcard(request, true);
        let errorResolved = false;
        this.logger.log("info", "customize-services.component.ts", "retrieveRccDisclosuresRequest", JSON.stringify(request));
        this.logger.startTime();
        this.disclosuresService.viewRccsDisclosure(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts", "retrieveRccDisclosuresResponse", error);
                this.logger.log("error", "customize-services.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                return Observable.throw(this.toNextStage());
            })
            .subscribe(
                (data: DisclosuresRes) => {
                    this.logger.endTime();
                    this.logger.log("info", "customize-services.component.ts", "retrieveRccDisclosuresResponse", JSON.stringify(data));
                    this.logger.log("info", "customize-services.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data && data.rccGroup) {
                        if (data && data.rccGroup && data.rccGroup.length > 0) {
                            this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: data });
                            this.discloserPopUpSelected = true;
                            this.orderDisclosures.open();
                        } else {
                            this.toNextStage();
                        }
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "customize-services.component.ts", "retrieveRccDisclosuresResponse", error);
                    this.logger.log("error", "customize-services.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    if (!errorResolved) {
                        this.toNextStage();
                        this.loading = false;
                    }
                })
    }

    public isDisclosureAllowed: boolean = true;
    public toContinue() {
        if (!this.isDeviceSelected) {
            this.isSubmitted = true;
            return true;
        }
        this.isSelectedGiftCardDiscounts = false;
        this.isSelectedDiscounts = false;
        this.isDisclosureAddedDiscAllowed = false;
        this.store.dispatch({ type: 'TN_CHARGE_NEED_TO_REMOVE', payload: false });
        let cart = <Observable<ShoppingCart>>this.store.select('cart');
        this.cartSubscription = cart.subscribe(
            (data) => {
                if (data && data.payload && data.payload.discountItems) {
                    this.selectedDiscounts = [];
                    data.payload.discountItems.map(dat => {
                        if (dat.autoAttachInd === "N") {
                            this.selectedDiscounts.push(dat);
                        }
                    })
                }
            });
        let customize = <Observable<any>>this.store.select('customize');
        customize.subscribe((data) => {
            if (this.discloserPopUpSelected || (this.isReEntrant && ((data && data.selectedreentrantDisc && data.selectedreentrantDisc !== undefined && data.selectedreentrantDisc.length > 0) || (data && data.selectedreentrantGiftDisc && data.selectedreentrantGiftDisc !== undefined && data.selectedreentrantGiftDisc.length > 0)))) {
                this.isDisclosureAllowed = false;
                if (this.selectedDiscounts && this.selectedDiscounts.length > 0 && data && data.selectedreentrantDisc && data.selectedreentrantDisc !== undefined) {
                    if (((data && data.selectedreentrantDisc && data.selectedreentrantDisc.length) === (this.selectedDiscounts && this.selectedDiscounts.length)) && _.isEqual(JSON.stringify(this.selectedDiscounts), JSON.stringify(data.selectedreentrantDisc))) {
                        this.isSelectedDiscounts = true;
                    }
                }
                if (this.selectedGiftCardData && this.selectedGiftCardData.length > 0 && data && data.selectedreentrantGiftDisc && data.selectedreentrantGiftDisc !== undefined) {
                    if (((data && data.selectedreentrantGiftDisc && data.selectedreentrantGiftDisc.length) === (this.selectedGiftCardData && this.selectedGiftCardData.length)) && _.isEqual(JSON.stringify(this.selectedGiftCardData), JSON.stringify(data.selectedreentrantGiftDisc))) {
                        this.isSelectedGiftCardDiscounts = true;
                    }
                }
            }
        });
        if ((this.isSelectedDiscounts && !this.isSelectedGiftCardDiscounts) || (!this.isSelectedDiscounts && this.isSelectedGiftCardDiscounts) || (!this.isSelectedDiscounts && !this.isSelectedGiftCardDiscounts)) {
            this.isDisclosureAddedDiscAllowed = true;
        }

        if ((this.isDisclosureAllowed || this.isDisclosureAddedDiscAllowed) && ((this.selectedDiscounts && this.selectedDiscounts !== undefined && this.selectedDiscounts.length > 0 && !this.isSelectedDiscounts) || (this.selectedGiftCardData && this.selectedGiftCardData !== undefined && this.selectedGiftCardData.length > 0 && !this.isSelectedGiftCardDiscounts))) {
            this.viewRccsDisclosure();
        } else {
            this.toNextStage();
        }
        this.store.dispatch({ type: 'SELECTED_REENTRANT_DISCOUNTS', payload: this.selectedDiscounts });
        this.store.dispatch({ type: 'SELECTED_REENTRANT_GIFT_DISCOUNTS', payload: this.selectedGiftCardData });
    }

    /** Continue button to scheduling page */
    public toNextStage() {
        this.toNext = true;
        if (this.isProfileReadOnly) {
            return false;
        }

        if (!this.isDtvOpus) {
            if (this.dtvConfigForm.get('taskName').value === 'no' && this.dtvConfigForm.get('accNo').value === '') {
                this.accNoErrorMsg = true;
                return false;
            }
        }
        if (this.internetConfigurationComponent && (this.lifeLineShowInternet || this.addedLifelineInternet || (this.isReEntrant || this.lifelineInternet)) && (!this.lifelineHsiRemove)) {
            this.internetConfigurationComponent.subLifelineData();
        }
        if (this.phoneConfiguration && (this.showPotsLifeline || this.showDHPLifeLine || this.addedLifelineInternet || (this.isReEntrant || (this.lifelinePots || this.lifelineDHP)) && !this.lifelinePOtsRemove)) {
            this.phoneConfiguration.subLifelineData();
        }
        this.loading = true;
        this.loadingNext = true;
        let addonHP: ShoppingCart;
        let discountItems: any = [];
        let lifeLineProducts = [];
        let custDataPayload: any = this.custdata.payload;
        let custDataLifeLineConfig = this.custdata.payload.lifeLineConfiguration;
        let custDataLifeLine: any = {
            lifelineInd: true,
            llServiceType: this.selectedLifelineType,
            lifeLineProducts
        }

        let internetDetails = {
            productDetails: '',
            lifeLineConfig: '',
            lifeLineDiscounts: '',
            lifeLineAdjustments: '',
        }
        let potsDetails = {
            productDetails: '',
            lifeLineConfig: '',
            lifeLineDiscounts: '',
            lifeLineAdjustments: '',
        }
        let dhpDetails = {
            productDetails: '',
            lifeLineConfig: '',
            lifeLineDiscounts: '',
            lifeLineAdjustments: '',
        }

        internetDetails.productDetails = this.productInternetDet;
        internetDetails.lifeLineConfig = this.custdata.lifelineConfig;
        internetDetails.lifeLineDiscounts = this.custdata.lifelineDiscounts;
        internetDetails.lifeLineAdjustments = this.custdata.lifelineAdjustment;

        potsDetails.productDetails = this.productPotsDet;
        potsDetails.lifeLineConfig = this.custdata.lifelinePotsConfig;
        potsDetails.lifeLineDiscounts = this.custdata.lifelinePotsDiscounts;
        potsDetails.lifeLineAdjustments = this.custdata.lifelinePotsAdjustment;

        dhpDetails.productDetails = this.productDHPDet;
        dhpDetails.lifeLineConfig = this.custdata.lifelinePotsConfig;
        dhpDetails.lifeLineDiscounts = this.custdata.lifelinePotsDiscounts;
        dhpDetails.lifeLineAdjustments = this.custdata.lifelinePotsAdjustment;
        if (this.custdata && this.custdata.lifelineConfig && this.custdata.lifelineConfig.qualProg !== undefined && this.custdata.lifelineConfig.qualProg !== "" && this.custdata.lifelineConfig.qualProg === "EXP:Expire Lifeline") {
            custDataLifeLine.lifelineInd = false;
        }
        if (this.custdata && this.custdata.lifelinePotsConfig && this.custdata.lifelinePotsConfig.qualProg !== "" && this.custdata.lifelinePotsConfig.qualProg !== undefined && this.custdata.lifelinePotsConfig.qualProg === "EXP:Expire Lifeline") {
            custDataLifeLine.lifelineInd = false;
        }

        if (((this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null) || (this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null)) && this.lifelineReponseDataInternet && this.lifelineReponseDataInternet !== null) {
            if (!this.lifeLineShowInternet && ((this.showDHPLifeline || this.lifelineShowDHP) || this.lifeLineShow)) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "INTERNET") {
                        let internetDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(internetDetails);
                    }
                })
            }
        }
        if (this.lifelineInternet) {
            this.lifeLineShowInternet = true;
        } else {
            this.lifeLineShowInternet = false;
        }
        if (this.lifelinePots) {
            this.lifeLineShow = true;
        } else {
            this.lifeLineShow = false
        }
        if (this.lifelineDHP) {
            this.lifelineShowDHP = true;
            this.showDHPLifeline = true;
        } else {
            this.lifelineShowDHP = false;
            this.showDHPLifeline = false;
        }
        if ((this.lifeLineShowInternet) && custDataLifeLine && custDataLifeLine.llServiceType === "BRBAND") {
            lifeLineProducts.push(internetDetails);
        } else if (this.lifeLineShow && custDataLifeLine && custDataLifeLine.llServiceType === "VOICE") {
            lifeLineProducts.push(potsDetails);
        } else if ((!this.lifeLineShowInternet || this.lifelineHsiRemove) && this.lifeLineShow && !this.lifelineShowDHP && custDataLifeLine && custDataLifeLine.llServiceType === "BNDVCBB") {
            custDataLifeLine.llServiceType = 'BNDVC';
            lifeLineProducts.push(potsDetails);
        } else if ((!this.lifeLineShowInternet || this.lifelineHsiRemove) && this.lifelineShowDHP && custDataLifeLine && custDataLifeLine.llServiceType === "BNDVCBB") {
            custDataLifeLine.llServiceType = 'BNDVC';
            lifeLineProducts.push(dhpDetails);
        } else if (this.lifeLineShowInternet && custDataLifeLine && custDataLifeLine.llServiceType === "BNDVCBB" && !this.showDHPLifeline && ((!this.showPotsLifeline && !this.lifeLineShow) || this.lifelinePOtsRemove)) {
            custDataLifeLine.llServiceType = 'BNDVCBB';
            lifeLineProducts.push(internetDetails);
        } else if (this.lifeLineShowInternet && this.lifeLineShow && !this.showDHPLifeline && !this.lifelineShowDHP && custDataLifeLine && custDataLifeLine.llServiceType === "BNDVCBB" && (!this.lifelineHsiRemove && !this.lifelinePOtsRemove)) {
            lifeLineProducts.push(internetDetails);
            lifeLineProducts.push(potsDetails);
        } else if (this.lifeLineShowInternet && (this.showDHPLifeline || this.lifelineShowDHP) && custDataLifeLine && custDataLifeLine.llServiceType === "BNDVCBB" && (!this.lifelineHsiRemove && !this.lifelinePOtsRemove)) {
            lifeLineProducts.push(internetDetails);
            lifeLineProducts.push(dhpDetails);
        }
        if (((this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null) || (this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null)) && !this.lifelineReponseDataInternet) {
            if ((!this.showDHPLifeline || !this.lifelineShowDHP) && this.lifeLineShowInternet && !this.lifelineexisting) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "VOICE-DHP") {
                        let dhpDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(dhpDetails);
                    }
                })
            }
            if (!this.lifeLineShow && this.lifeLineShowInternet && !this.lifelineexisting) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "VOICE-HP") {
                        let potsDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(potsDetails);
                    }
                })
            }
        }
        if (((this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null) || (this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null && this.lifelineReponseDataDhp !== undefined)) && (this.lifelineReponseDataInternet && this.lifelineReponseDataInternet !== null && this.lifelineReponseDataInternet !== undefined)) {
            custDataLifeLine.llServiceType = 'BNDVCBB';
        } else if (((this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null) || (this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null)) && !this.lifelineReponseDataInternet && this.lifeLineShowInternet) {
            custDataLifeLine.llServiceType = 'BNDVCBB';
        }
        if (((this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null) || (this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null)) && this.lifelineReponseDataInternet && this.lifelineReponseDataInternet !== null) {
            if (!this.lifeLineShow && this.lifeLineShowInternet) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "VOICE-HP") {
                        let potsDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(potsDetails);
                    }
                })
            }
            if ((!this.showDHPLifeline || !this.lifelineShowDHP) && this.lifeLineShowInternet) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "VOICE-DHP") {
                        let dhpDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(dhpDetails);
                    }
                })
            }
        }

        //Addons to be added in Cart on Click Continue
        let item: CustomerOrderItems[] = [];
        item = this.populateCart(this.custdata, true, false);
        let cart = <Observable<ShoppingCart>>this.store.select('cart');
        this.cartSubscription = cart.subscribe(
            (data) => {
                addonHP = data;
                discountItems = data.payload.discountItems;
                let items = this.populateCart(data, false, false, this.custdata);
                items && items.map(sub => {
                    if (sub && sub.customerOrderSubItems && sub.customerOrderSubItems.length > 0) { item.push(sub); }
                });
            }
        );
        if (this.isBypassed) {
            let discountFlag: boolean = false;
            item.forEach((orderItem) => {
                if (orderItem.offerCategory === 'INTERNET') {
                    orderItem.customerOrderSubItems.forEach((subItem) => {
                        discountItems && discountItems.forEach((discount) => {
                            if (discount.productId === subItem.productId) {
                                subItem.productAttributes.forEach((prod) => {
                                    if (prod.isPriceable) {
                                        if (prod.discounts.length > 0) {
                                            prod.discounts.forEach((dt) => {
                                                if (dt.discountId === discount.discountId) {
                                                    discountFlag = true;
                                                }
                                            });
                                            if (!discountFlag)
                                                prod.discounts.push(discount);
                                            discountFlag = false;
                                        } else {
                                            prod.discounts.push(discount);
                                        }
                                    }
                                });
                            }
                        });
                    });
                }
            })
        }
        let callDetailAdded = false;
        if (!this.refObj.disableHp) {
            if (!addonHP || !addonHP.payload || addonHP.payload.customerAddonOfferItems === undefined ||
                addonHP.payload.customerAddonOfferItems.length === 0) {
                let items = this.populateCart(this.custdata, true, true, undefined, true);
                items && items.map(sub => {
                    if (sub && sub.customerOrderSubItems && sub.customerOrderSubItems.length > 0) item.push(sub);
                })
            }
            let isPotsAddons = false;
            if (addonHP && addonHP.payload && addonHP.payload.customerAddonOfferItems &&
                addonHP.payload.customerAddonOfferItems.length !== 0) {
                addonHP.payload.customerAddonOfferItems.forEach(data => {
                    if (data.customerOrderSubItems && data.customerOrderSubItems.length !== 0 &&
                        data.offerCategory === GenericValues.cHP && data.offerType !== 'SUBOFFER') {
                        isPotsAddons = true;
                    }
                })

                if (!isPotsAddons) {
                    let items = this.populateCart(this.custdata, true, true, undefined, true);
                    item && items.map(sub => {
                        if (sub && sub.customerOrderSubItems && sub.customerOrderSubItems.length > 0) item.push(sub);
                    })
                }
            }
            if (addonHP && addonHP.payload && addonHP.payload.customerAddonOfferItems &&
                addonHP.payload.customerAddonOfferItems.length !== 0) {
                let isExist = false;
                let exOrder: CustomerOrderItems;
                addonHP.payload.customerAddonOfferItems.forEach(data => {
                    isExist = false;
                    if ((data.offerCategory === GenericValues.cHP || data.offerCategory === 'WIRINGWORKS') && data.offerType === 'SUBOFFER' && !isExist) {
                        this.existingServices && this.existingServices.forEach(exServ => {
                            if (data.productOfferingId === exServ.productOfferingId) {
                                if (exServ.offerCategory === data.offerCategory && exServ.offerType === data.offerType) {
                                    isExist = true;
                                    exOrder = exServ;
                                }
                            }
                        })
                        if (isExist) {
                            let action = 'NOCHANGE';
                            let isSubExist = false;
                            let subItems: Products[] = [];
                            data.customerOrderSubItems && data.customerOrderSubItems.forEach(sub => {
                                isSubExist = false;
                                exOrder.customerOrderSubItems = exOrder.customerOrderSubItems ? exOrder.customerOrderSubItems : exOrder.existingServiceSubItems;
                                exOrder && exOrder.customerOrderSubItems && exOrder.customerOrderSubItems.map(exSub => {
                                    if (sub.productName === exSub.productName) {
                                        isSubExist = true;
                                    }
                                })
                                subItems.push({
                                    productId: sub.productId,
                                    productName: sub.productName,
                                    productType: sub.productType,
                                    componentType: sub.componentType,
                                    productAttributes: sub.productAttributes,
                                    productAssociations: sub.productAssociations,
                                    productCategory: sub.productCategory,
                                    quantity: sub.quantity,
                                    action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((exOrder.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                        || (exOrder.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' :
                                        this.macd ? this.refObj.disableHp ? 'REMOVE' : isSubExist ? 'NOCHANGE' : 'ADD' : sub.action
                                })
                                if (subItems.length > 0 && subItems[subItems.length - 1].action !== 'NOCHANGE') action = 'CHANGE';
                            })
                            exOrder.customerOrderSubItems = exOrder.customerOrderSubItems ? exOrder.customerOrderSubItems : exOrder.existingServiceSubItems;
                            exOrder && exOrder.customerOrderSubItems && exOrder.customerOrderSubItems.map(exSub => {
                                isSubExist = false;
                                data.customerOrderSubItems && data.customerOrderSubItems.map(sub => {
                                    if (sub.productName === exSub.productName) {
                                        isSubExist = true;
                                    }
                                })
                                if (!isSubExist) {
                                    subItems.push({
                                        productId: exSub.productId,
                                        productName: exSub.productName,
                                        productType: exSub.productType,
                                        componentType: exSub.componentType,
                                        productAttributes: exSub.productAttributes,
                                        productAssociations: exSub.productAssociations,
                                        productCategory: exSub.productCategory,
                                        quantity: exSub.quantity,
                                        action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((exOrder.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                            || (exOrder.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.macd ? 'REMOVE' : exSub.action
                                    })
                                    if (subItems.length > 0 && subItems[subItems.length - 1].action !== 'NOCHANGE') action = 'CHANGE';
                                }
                            })
                            let orderItem: CustomerOrderItems = {
                                catalogId: data.catalogId,
                                productOfferingId: data.productOfferingId,
                                offerType: data.offerType,
                                offerSubType: data.offerSubType,
                                offerCategory: data.offerCategory,
                                quantity: 1,
                                rc: data.rc,
                                discountedRc: data.discountedRc,
                                otc: data.otc,
                                discountedOtc: data.discountedOtc,
                                contractTerm: 0,
                                customerOrderSubItems: subItems,
                                action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((data.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                    || (data.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : action
                            }
                            if (orderItem && orderItem.customerOrderSubItems && orderItem.customerOrderSubItems.length > 0) item.push(orderItem);
                        } else {
                            let subItems: Products[] = [];
                            data.customerOrderSubItems && data.customerOrderSubItems.map(sub => {
                                subItems.push({
                                    productId: sub.productId,
                                    productName: sub.productName,
                                    productType: sub.productType,
                                    componentType: sub.componentType,
                                    productAttributes: sub.productAttributes,
                                    productAssociations: sub.productAssociations,
                                    productCategory: sub.productCategory,
                                    quantity: sub.quantity,
                                    action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((data.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                        || (data.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.macd ? this.refObj.disableHp ? 'REMOVE' : 'ADD' : sub.action
                                })
                            })
                            let orderItem: CustomerOrderItems = {
                                catalogId: data.catalogId,
                                productOfferingId: data.productOfferingId,
                                offerType: data.offerType,
                                offerSubType: data.offerSubType,
                                offerCategory: data.offerCategory,
                                quantity: 1,
                                rc: data.rc,
                                discountedRc: data.discountedRc,
                                otc: data.otc,
                                discountedOtc: data.discountedOtc,
                                contractTerm: 0,
                                customerOrderSubItems: subItems,
                                action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((data.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                    || (data.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.macd ? this.refObj.disableHp ? 'REMOVE' : 'ADD' : data.action
                            }
                            if (orderItem && orderItem.customerOrderSubItems && orderItem.customerOrderSubItems.length > 0) item.push(orderItem);
                        }
                    }
                })
                if (this.mandatorySubOffers.length > 0) {
                    this.mandatorySubOffers && this.mandatorySubOffers.map(subOffer => {
                        let sameCallDetail = false;
                        this.existingServices && this.existingServices.map(exServ => {
                            exServ.customerOrderSubItems = exServ.customerOrderSubItems ? exServ.customerOrderSubItems : exServ.existingServiceSubItems;
                            if (subOffer.productOfferingId === exServ.productOfferingId) {
                                if (exServ.offerCategory === subOffer.offerCategory && exServ.offerType === subOffer.offerType) {
                                    exServ && exServ.customerOrderSubItems && exServ.customerOrderSubItems.map(sub => {
                                        exServ.customerOrderSubItems.map((a) => {
                                            if (a.productName === 'Call Detail') {
                                                for (let i = 0; i < a.productAttributes.length; i++) {
                                                    if ((a.productAttributes[i].compositeAttribute.length > 0) && a.productAttributes[i].compositeAttribute[0].attributeName === 'printOnBill' &&
                                                        a.productAttributes[i].compositeAttribute[0].attributeValue === this.callDetailPlan) {
                                                        sameCallDetail = true;
                                                    }
                                                }
                                            }
                                        })
                                    })
                                    subOffer && subOffer.customerOrderSubItems && subOffer.customerOrderSubItems.map(sub => {
                                        if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                                        if (subOffer.offerCategory === GenericValues.cHP) {
                                            subOffer.customerOrderSubItems.map((a) => {
                                                if (a.productName === 'Call Detail') {
                                                    if (a.totalPriceWithQty) delete a.totalPriceWithQty;
                                                    for (let i = 0; i < a.productAttributes.length; i++) {
                                                        if ((a.productAttributes[i].compositeAttribute.length > 0) && a.productAttributes[i].compositeAttribute[0].attributeName === 'printOnBill' &&
                                                            a.productAttributes[i].compositeAttribute[0].attributeValue !== this.callDetailPlan) {
                                                            a.productAttributes.splice(i, 1);
                                                            a.action = sameCallDetail ? 'NOCHANGE' : 'CHANGE';
                                                        }
                                                    }
                                                    subOffer.action = sameCallDetail ? 'NOCHANGE' : 'CHANGE';
                                                    if (subOffer && subOffer.customerOrderSubItems && subOffer.customerOrderSubItems.length > 0) item.push(subOffer);
                                                    callDetailAdded = true;
                                                }
                                            })
                                        }
                                    })
                                }
                            }
                        })
                    })
                }
                this.existingServices && this.existingServices.map(exServ => {
                    isExist = false;
                    exServ.customerOrderSubItems = exServ.customerOrderSubItems ? exServ.customerOrderSubItems : exServ.existingServiceSubItems;
                    exOrder = exServ;
                    if (exServ.offerCategory === GenericValues.cHP && exServ.offerType === 'SUBOFFER'
                        && exOrder.customerOrderSubItems && exOrder.customerOrderSubItems.length > 0
                        && exOrder.customerOrderSubItems[0].productName !== 'Home Phone Directory Listing') {
                        addonHP && addonHP.payload && addonHP.payload.customerAddonOfferItems && addonHP.payload.customerAddonOfferItems.map(data => {
                            if (data.productOfferingId === exServ.productOfferingId) {
                                if (exServ.offerCategory === data.offerCategory && exServ.offerType === data.offerType) {
                                    isExist = true;
                                }
                            }
                        })
                        if (this.mandatorySubOffers.length > 0) {
                            this.mandatorySubOffers && this.mandatorySubOffers.map(subOffer => {
                                if (subOffer.productOfferingId === exServ.productOfferingId) {
                                    if (exServ.offerCategory === subOffer.offerCategory && exServ.offerType === subOffer.offerType) {
                                        isExist = true;
                                    }
                                }
                            })
                        }
                        if (!isExist) {
                            let subItems: Products[] = [];
                            exServ.customerOrderSubItems && exServ.customerOrderSubItems.map(sub => {
                                subItems.push({
                                    productId: sub.productId,
                                    productName: sub.productName,
                                    productType: sub.productType,
                                    componentType: sub.componentType,
                                    productAttributes: sub.productAttributes,
                                    productAssociations: sub.productAssociations,
                                    productCategory: sub.productCategory,
                                    quantity: sub.quantity,
                                    action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((exServ.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                        || (exServ.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.macd ? 'REMOVE' : sub.action
                                })
                            })
                            let orderItem: CustomerOrderItems = {
                                catalogId: exOrder.catalogId,
                                productOfferingId: exOrder.productOfferingId,
                                offerType: exOrder.offerType,
                                offerSubType: exOrder.offerSubType,
                                offerCategory: exOrder.offerCategory,
                                quantity: 1,
                                rc: exOrder.rc,
                                discountedRc: exOrder.discountedRc,
                                otc: exOrder.otc,
                                discountedOtc: exOrder.discountedOtc,
                                contractTerm: 0,
                                customerOrderSubItems: subItems,
                                action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((exServ.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                    || (exServ.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.macd ? 'REMOVE' : exOrder.action
                            }
                            if (orderItem && orderItem.customerOrderSubItems && orderItem.customerOrderSubItems.length > 0) item.push(orderItem);
                        }
                    }
                })
            }
        }
        if (this.isPOTSRemoved) {
            this.store.dispatch({ type: 'POTS_REMOVED', payload: true });
            if (this.custdata && this.custdata.payload && this.custdata.payload.cart &&
                this.custdata.payload.cart.customerOrderItems && this.custdata.payload.cart.customerOrderItems.length > 0) {
                this.custdata.payload.cart.customerOrderItems.map(orderItem => {
                    if (orderItem.offerCategory === GenericValues.cHP && orderItem.offerType === 'SUBOFFER') {
                        if (orderItem && orderItem.customerOrderSubItems && orderItem.customerOrderSubItems.length > 0) item.push(orderItem);
                    }
                })
            }
        }
        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }

        let selectedTN = [];
        custDataPayload && custDataPayload.reservedTN && custDataPayload.reservedTN.map(item => {
            if (item.productType === 'INTERNET') {
                selectedTN.push(item);

            }
        });


        let phoneconfigData = this.phoneConfigForm.get("phoneConfigData").value;
        if (phoneconfigData && phoneconfigData !== undefined && phoneconfigData.callfwdForm && phoneconfigData.callfwdForm !== undefined && phoneconfigData.callfwdForm.fwdOnDontAnswer && phoneconfigData.callfwdForm.fwdOnDontAnswer !== undefined) {
            phoneconfigData.callfwdForm.fwdOnDontAnswer = phoneconfigData.callfwdForm.fwdOnDontAnswer.replace(/\D+/g, '');
        }
        if (phoneconfigData && phoneconfigData !== undefined && phoneconfigData.callfwdForm && phoneconfigData.callfwdForm !== undefined && phoneconfigData.callfwdForm.fwdOnBusy && phoneconfigData.callfwdForm.fwdOnBusy !== undefined) {
            phoneconfigData.callfwdForm.fwdOnBusy = phoneconfigData.callfwdForm.fwdOnBusy.replace(/\D+/g, '');
        }
        if (phoneconfigData.tnForm && phoneconfigData.tnForm.SelectedPhoneNumber !== undefined && phoneconfigData.tnForm.SelectedPhoneNumber !== 'Choose your option...') {
            this.portingNotComplete = false;
            let customize = <Observable<any>>this.store.select('customize');
            this.customizeSubscription = customize.subscribe((data) => {
                if (data && data.telephoneNumberType) {
                    this.portedType = data.telephoneNumberType;
                }
                if (data.simpleportcheck && data.simpleportcheck !== undefined && data.simpleportcheck.orderTN && data.simpleportcheck.orderTN[0].workingTN !== undefined && data.simpleportcheck.orderTN[0].workingTN !== null) {
                    this.simplePortTN = data.simpleportcheck && data.simpleportcheck !== undefined && data.simpleportcheck.orderTN[0].workingTN;
                }
                this.simpleportCustData = data;
            })
            if (this.customizeSubscription !== undefined) this.customizeSubscription.unsubscribe();
            if (this.previousUrl === '/billing-product') {
                let tnList = custDataPayload.reservedTN;
                tnList.some(item => {
                    let isDhp = false;
                    let isPots = false;
                    let isInternet = false;
                    custDataPayload.retrievalTypes[0].addOnOffers.map(addOn => {
                        if (addOn.serviceCategory === 'DATA') {
                            isInternet = true;
                        }
                        else if (addOn.serviceCategory === 'VOICE-DHP') {
                            isDhp = true;
                        }
                        else if (addOn.serviceCategory === 'VOICE-HP') {
                            isPots = true;
                        }
                    });
                    if (isDhp) {
                        let item1 = cloneDeep(item);
                        item1.requestedTelephoneNumber = phoneconfigData.tnForm.SelectedPhoneNumber;
                        item1.productType = 'VOICE-DHP';
                        selectedTN.push(item1);

                    }
                    else if (isPots) {
                        if (item.requestedTelephoneNumber !== phoneconfigData.tnForm.SelectedPhoneNumber) {
                            item.workingTN = "NO";
                        }
                        item.requestedTelephoneNumber = phoneconfigData.tnForm.SelectedPhoneNumber;
                        item.productType = 'VOICE-HP';
                        selectedTN.push(item);
                    }
                    return true;
                });
            }
            else {
                let tnList = custDataPayload.reservedTN;
                tnList && tnList.map(item => {
                    if (item.productType === 'VOICE-DHP' || item.productType === 'VOICE-HP') {
                        item.requestedTelephoneNumber = phoneconfigData.tnForm.SelectedPhoneNumber;
                        if (phoneconfigData.tnForm.task === 'portedTn' && this.portedType) {
                            item.tnType = this.portedType;
                        }
                        else if (phoneconfigData.tnForm.task === 'assignedTn') {
                            if (item.tnType === '' || item.tnType === null || item.tnType === undefined) {
                                item.tnType = this.simpleportCustData.telephoneNumberType ? this.simpleportCustData.telephoneNumberType : this.tnType;
                            }
                            this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: item.tnType });
                        }
                        if (this.workingTN) {
                            item.workingTN = this.workingTN;
                        }
                        let obj = selectedTN && selectedTN.find((object) =>
                            object.requestedTelephoneNumber !== item.requestedTelephoneNumber
                        );
                        if (obj || (selectedTN && selectedTN.length === 0)) selectedTN.push(item);
                    }
                });
            }
        }

        if ((this.dhpCData.length !== 0 && !this.refObj.disablePhone)) {
            if (phoneconfigData.tnForm.SelectedPhoneNumber === '' || phoneconfigData.tnForm.SelectedPhoneNumber === null || phoneconfigData.tnForm.SelectedPhoneNumber === undefined) {

                this.loading = false;
                this.loadingNext = false;
                this.accordianHandling.tn = false;
                this.accordianHandling.tn = true;
                this.portingNotComplete = true;
                this.tabSelected("PHONE", true);
                return;

            }
        }
        if (this.hpCData.length !== 0) {
            if (phoneconfigData.tnForm.SelectedPhoneNumber === '' || phoneconfigData.tnForm.SelectedPhoneNumber === null || phoneconfigData.tnForm.SelectedPhoneNumber === undefined) {

                this.loading = false;
                this.loadingNext = false;
                this.accordianHandling.tn = false;
                this.accordianHandling.tn = true;
                this.portingNotComplete = true;
                this.tabSelected("hp", true);
                return;

            }
        }
        if (this.hpCData.length !== 0) {

            if (this.phoneConfigInputData.callForwarding.selected && phoneconfigData && phoneconfigData.callfwdForm) {
                if (this.phoneConfigInputData.callForwarding.callForwardingBusy && phoneconfigData.callfwdForm.fwdOnBusy !== undefined && phoneconfigData.callfwdForm.fwdOnBusy !== "" && phoneconfigData.callfwdForm.fwdOnBusy.toString().trim().length !== 10) {
                    this.loading = false;
                    this.loadingNext = false;
                    this.tabSelected("hp", true);
                    return;
                }
                if (this.phoneConfigInputData.callForwarding.callForwardingNoAnswer && phoneconfigData.callfwdForm.fwdOnDontAnswer !== undefined && phoneconfigData.callfwdForm.fwdOnDontAnswer !== "" && phoneconfigData.callfwdForm.fwdOnDontAnswer.toString().trim().length !== 10) {
                    this.loading = false;
                    this.loadingNext = false;
                    this.tabSelected("hp", true);
                    return;
                }

            }
        }
        if (this.isDtvOpus) {
            if (!this.refObj.disableDtv) {
                this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvOpus: { taskName: 'yes', accNo: this.existingDTVAccountId } } });
            }
            else {
                this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvOpus: { taskName: 'no', accNo: '' } } });
            }

        }
        else {
            if (!this.refObj.disableDtv) {
                if (this.dtvConfigForm.get('taskName').value === 'yes') {
                    this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'yes', accNo: '' } } });
                } else if (this.dtvConfigForm.get('taskName').value === 'no') {
                    let dtvAccountNo = this.dtvConfigForm.get('accNo').value;
                    this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'no', accNo: dtvAccountNo } } });
                }
            } else {
                this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'no', accNo: '' } } });
            }

        }

        let phoneCategory = !this.refObj.disableHp ? GenericValues.cHP : GenericValues.cDHP;
        let listing: any;
        let indexNo = 0;
        let productConfig = [];
        let prodStruc: ProductConfiguration[] = [];
        let prodConf: ProductConfiguration[] = [];
        let prodConfData: ProductConfiguration[] = [];

        // fetching existing Prod conf 
        if (!this.isDtvOpus) {
            if (custDataPayload && custDataPayload.existingProductConfiguration &&
                custDataPayload.existingProductConfiguration.length > 0) {
                custDataPayload.existingProductConfiguration.map(struct => {
                    if (struct.productType === GenericValues.cDTV) {
                        struct && struct.configItems && struct.configItems.map(confItem => {
                            confItem && confItem.configDetails && confItem.configDetails.map(confDet => {
                                confDet && confDet.formItems && confDet.formItems.map(formItem => {
                                    if (formItem.attributeName === 'DIRECTV Account ID') {
                                        this.existingDTVAccountId = formItem.attributeValue[0].value;
                                    }
                                })
                            });
                        });
                    }
                });
            }

        }
        if (this.isDtvOpus) {
            if (this.dtvExisting) {
                this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvOpus: { taskName: 'no', accNo: this.existingDTVAccountId } } });
            }
        }
        else {
            if (this.dtvExisting) {
                this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'no', accNo: this.existingDTVAccountId } } });
            }
        }


        prodStruc = cloneDeep(custDataPayload.productConfiguration);
        prodStruc && prodStruc.map(struct => {
            let confItemList: ConfigItems[] = [];
            struct && struct.configItems && struct.configItems.map(confItem => {
                let confDetList: ConfigDetails[] = [];
                confItem && confItem.configDetails && confItem.configDetails.map(confDet => {
                    let formItemList: FormItems[] = [];
                    confDet && confDet.formItems && confDet.formItems.map(formItem => {
                        formItemList.push({
                            attributeName: formItem.attributeName,
                            attributeType: formItem.attributeType,
                            attributeValue: formItem.attributeValue,
                            isMandatory: formItem.isMandatory
                        })
                    })
                    confDetList.push({
                        formItems: formItemList,
                        formName: confDet.formName,
                        isConfigRequired: confDet.isConfigRequired
                    })
                })
                confItemList.push({
                    configDetails: confDetList,
                    productId: confItem.productId,
                    productName: confItem.productName
                })
            })
            prodConfData.push({
                productType: struct.productType,
                configItems: confItemList
            })
        })
        if (!this.refObj.disableInternet) {
            let internetConf = find(prodConfData, (o) => {
                return o.productType === 'INTERNET';
            });
            if (internetConf && this.techInstallAdded) {
                let confItemList: ConfigItems[] = [];
                internetConf && internetConf.configItems && internetConf.configItems.map(confItem => {
                    let confDetList: ConfigDetails[] = [];
                    confItem && confItem.configDetails && confItem.configDetails.map(confDet => {
                        let formItemList: FormItems[] = [];
                        confDet && confDet.formItems && confDet.formItems.map(formItem => {
                            if (confItem.productName === 'TECH INSTALL') {
                                formItemList.push(this.deviceSelected.configItems[0].configDetails[0].formItems[0]);
                            } else if (confItem.productName !== 'TECH INSTALL') {
                                formItemList.push({
                                    attributeName: formItem.attributeName,
                                    attributeType: formItem.attributeType,
                                    attributeValue: formItem.attributeValue,
                                    isMandatory: formItem.isMandatory
                                })
                            }
                        })
                        confDetList.push({
                            formItems: formItemList,
                            formName: confDet.formName,
                            isConfigRequired: confDet.isConfigRequired
                        })
                    })
                    confItemList.push({
                        configDetails: confDetList,
                        productId: confItem.productId,
                        productName: confItem.productName
                    })
                })
                prodConf.push({
                    productType: internetConf.productType,
                    configItems: confItemList
                })
                let one = {
                    productType: internetConf.productType,
                    configItems: confItemList
                }
                productConfig[indexNo] = one;
                indexNo = 1;
            }
        }
        productConfig[indexNo] = cloneDeep(find(prodConfData, (o) => {
            return o.productType === phoneCategory;
        }));
        if (!productConfig[indexNo] || productConfig[indexNo] === null) productConfig = [];
        if (productConfig && productConfig.length !== 0 && productConfig[indexNo]) {
            productConfig[indexNo].configItems = [];
        }
        if (!this.listingDhpValidate()) {
            this.loading = false;
            this.loadingNext = false;
            return;
        } else {
            if ((this.dhpCData.length !== 0 && !this.refObj.disablePhone) || (this.hpCData.length !== 0 && !this.refObj.disableHp)) {
                let temp = find(prodConfData, (o) => {
                    return o.productType === phoneCategory;
                });
                if (temp && temp.configItems !== null && temp.configItems.length > 0) {
                    let form: any;
                    if (!this.refObj.disablePhone) {
                        form = find(temp.configItems, (o) => {
                            return o.productName === 'Digital Home Phn Dir Listing';
                        });
                    } else if (!this.refObj.disableHp) {
                        form = find(temp.configItems, (o) => {
                            return o.productName === 'Home Phone Directory Listing';
                        });
                    }
                    let dhpForm: any;
                    if (form && form.configDetails) {
                        dhpForm = find(form.configDetails, (o) => {
                            return o.formName === 'Listing';
                        });
                    }
                    if (dhpForm && dhpForm.formItems && dhpForm.formItems.length > 0) {

                        if (this.selectedListedAddressOption && this.selectedListedAddressOption === 'List Community Only') {
                            dhpForm.formItems = dhpForm.formItems.filter((v, i) => {
                                if (v.attributeName !== 'streetNrFirst' && v.attributeName !== "streetNamePrefix" && v.attributeName !== "streetType" && v.attributeName !== "streetName" && v.attributeName !== "Unit") {
                                    return dhpForm.formItems[i];
                                }
                            });
                        }

                        for (let i = 0; i < dhpForm.formItems.length; i++) {
                            if (dhpForm.formItems[i].attributeName === "First Name") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.firstName;
                            } else if (dhpForm.formItems[i].attributeName === "Last Name") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.lastName;
                            }
                            else if (dhpForm.formItems[i].attributeName === "Listing Type") {
                                let value = dhpForm.formItems[i].attributeValue[0];
                                dhpForm.formItems[i].attributeValue = [];
                                dhpForm.formItems[i].attributeValue[0] = value;
                                if (form.productName === 'Home Phone Directory Listing') {
                                    dhpForm.formItems[i].attributeValue[0].value = this.potsListingValue;
                                }
                                else {
                                    dhpForm.formItems[i].attributeValue[0].value = this.dhpListingValue;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName.toLowerCase().indexOf("listed address") !== -1) {
                                if (this.selectedListedAddressOption) {
                                    dhpForm.formItems[i].attributeValue = dhpForm.formItems[i].attributeValue.filter(v => {
                                        if (v.value === this.selectedListedAddressOption) {
                                            return v;
                                        }
                                    });
                                }
                                else {
                                    dhpForm.formItems[i].attributeValue = dhpForm.formItems[i].attributeValue.filter(v => {
                                        if (v.isDefault) {
                                            return v;
                                        }
                                    });
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "streetNrFirst") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNrFirst !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetNrFirst;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.streetNrFirst) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetNrFirst;
                                }
                                else if (this.addressListing) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.addressListing.streetNrFirst;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "streetNamePrefix") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNamePrefix !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetNamePrefix;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.streetNamePrefix) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetNamePrefix;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "streetType") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetType !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetType;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.streetType) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetType;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "streetName") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetName !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetName;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.streetName) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetName;
                                }
                                else if (this.addressListing) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.addressListing.streetName;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "Unit") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.unit !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.unit;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.unit) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.unit;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "city") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.city !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.city;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.city) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.city;
                                }
                                else if (this.addressListing) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.addressListing.city;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "state") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.state !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.state;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.stateOrProvince) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.stateOrProvince;
                                }
                                else if (this.addressListing) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.addressListing.stateOrProvince;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "postCode") {
                                if (this.updatedListedAddressFields && this.updatedListedAddressFields.postCode !== undefined) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.postCode;
                                }
                                else if (this.changedListedAddress && this.changedListedAddress.postCode) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.postCode;
                                }
                                else if (this.addressListing) {
                                    dhpForm.formItems[i].attributeValue[0].value = this.addressListing.postCode;
                                }
                            }
                            else if (dhpForm.formItems[i].attributeName === "Title 1") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.title1;
                            }
                            else if (dhpForm.formItems[i].attributeName === "Title 2") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.title2;
                            }
                            else if (dhpForm.formItems[i].attributeName === "Lineage") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.lineage;
                            }
                            else if (dhpForm.formItems[i].attributeName === "Designation") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.designation;
                            }
                            else if (dhpForm.formItems[i].attributeName === "Nickname") {
                                dhpForm.formItems[i].attributeValue[0].value = phoneconfigData.listingForm.Nickname;
                            }
                        }
                        form.configDetails = [];
                        form.configDetails[0] = dhpForm;
                        listing = form;
                    }
                }
            }
        }
        if (!this.refObj.disablePhone) {
            if (listing) { productConfig[indexNo].configItems.push(listing); }

        }
        if (this.hpCData.length !== 0 && !this.refObj.disableHp) {
            if (listing) { productConfig[indexNo].configItems.push(listing); }
            let value;
            let temp = find(prodConfData, (o) => {
                return o.productType === phoneCategory;
            });
            let form = find(temp.configItems, (o) => {
                return o.productName === 'Directory Listing';
            });
            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                && form.configDetails[0].formItems !== null
                && form.configDetails[0].formItems.length !== 0) {
                for (let i = 0; i < form.configDetails[0].formItems.length; i++) {
                    if (form.configDetails[0].formItems[i].attributeName === 'Title 1') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.listingForm.title1;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Title 2') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.listingForm.title2;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Lineage') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.listingForm.lineage;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Designation') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.listingForm.designation;
                    }
                    else if (form.configDetails[0].formItems[i].attributeName === 'Nickname') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.listingForm.Nickname;
                    }
                }
            }
            if (form) { productConfig[indexNo].configItems.push(form); }
            if (this.isLATAExist) {
                if (this.isMainOfferLATA) {
                    form = find(temp.configItems, (o) => {
                        return o.productName.replace(/\s/g, "") === 'LongDistance-InterLata';
                    });
                } else {
                    this.collections = temp.configItems.filter((o) => {
                        return o.productName === this.selectedLATAName
                    });
                }
                for (let k = 0; k < this.collections.length; k++) {
                    if (this.collections[k].configDetails[0].formName.replace(/\s+/g, '').toLowerCase() === 'ldcarrierinterlata') {
                        form = this.collections[k];
                        break;
                    }
                }
                if (!form && temp && temp.configItems) {
                    for (let i = 0; i < temp.configItems.length; i++) {
                        if (temp.configItems[i].configDetails && temp.configItems[i].configDetails[0] && temp.configItems[i].configDetails[0].formName &&
                            temp.configItems[i].configDetails[0].formName.replace(/\s+/g, '').toLowerCase() === 'ldcarrierinterlata') {
                            form = temp.configItems[i];
                            break;
                        }
                    }
                }

                if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                    && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0] && form.configDetails[0].formItems[0].attributeValue !== null
                    && form.configDetails[0].formItems[0].attributeValue.length !== 0) {
                    value = form.configDetails[0].formItems[0].attributeValue[0];
                    form.configDetails[0].formItems[0].attributeValue = [];
                    form.configDetails[0].formItems[0].attributeValue[0] = value;
                    form.configDetails[0].formItems[0].attributeValue[0].value = phoneconfigData.ldCarrierForm.selectedInterCarrierOption;
                    //INTERLATA Freeze Configuration
                    if (this.selectedFreeze) {
                        this.selectedFreeze && this.selectedFreeze.map(freeze => {
                            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[1]
                                && form.configDetails[1].formName === freeze.formName && form.configDetails[1].formItems !== null && form.configDetails[1].formItems[0] && form.configDetails[1].formItems[0].attributeValue !== null
                                && form.configDetails[1].formItems[0].attributeValue.length !== 0) {
                                value = form.configDetails[1].formItems[0].attributeValue[0];
                                form.configDetails[1].formItems[0].attributeValue = [];
                                form.configDetails[1].formItems[0].attributeValue[0] = value;
                                form.configDetails[1].formItems[0].attributeValue[0].value = form.configDetails[1].formItems[0].attributeName === 'TPV Needed' ?
                                    this.selectedFreeze[0] && this.selectedFreeze[0].tpvSelection : freeze.value;
                                if (form.configDetails[1].formItems && form.configDetails[1].formItems[1] && form.configDetails[1].formItems[1].attributeValue
                                    && form.configDetails[1].formItems[1].attributeValue[0] && freeze.changedOn !== '') {
                                    value = form.configDetails[1].formItems[1].attributeValue[0];
                                    form.configDetails[1].formItems[1].attributeValue = [];
                                    form.configDetails[1].formItems[1].attributeValue[0] = value;
                                    form.configDetails[1].formItems[1].attributeValue[0].value = freeze.changedOn
                                } else {
                                    form.configDetails.splice(form.configDetails.length - 1);
                                }
                            }
                        })
                    } else if (form && form.configDetails && form.configDetails[1] && form.configDetails[1].formItems && form.configDetails[1].formItems[1]
                        && form.configDetails[1].formItems[1].attributeValue && form.configDetails[1].formItems[1].attributeValue[0]
                        && form.configDetails[1].formItems[1].attributeValue[0].value === '') {
                        form.configDetails.splice(form.configDetails.length - 1);
                    }
                }
                if (form) { productConfig[indexNo].configItems.push(form); }
                if (this.isMainOfferLATA) {
                    form = find(temp.configItems, (o) => {
                        return o.productName.replace(/\s/g, "") === 'LongDistance-Intralata';
                    });
                } else {
                    form = find(temp.configItems, (o) => {
                        return o.productName === this.selectedLATAName;
                    });
                }
                for (let k = 0; k < this.collections.length; k++) {
                    if (this.collections[k].configDetails[0].formName.replace(/\s+/g, '').toLowerCase() === 'ldcarrierintralata') {
                        form = this.collections[k];
                        break;
                    }
                }
                if (!form && temp && temp.configItems) {
                    for (let i = 0; i < temp.configItems.length; i++) {
                        if (temp.configItems[i].configDetails && temp.configItems[i].configDetails[0] && temp.configItems[i].configDetails[0].formName &&
                            temp.configItems[i].configDetails[0].formName.replace(/\s+/g, '').toLowerCase() === 'ldcarrierintralata') {
                            form = temp.configItems[i];
                            break;
                        }
                    }
                }

                if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                    && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0] && form.configDetails[0].formItems[0].attributeValue !== null
                    && form.configDetails[0].formItems[0].attributeValue.length !== 0) {
                    value = form.configDetails[0].formItems[0].attributeValue[0];
                    form.configDetails[0].formItems[0].attributeValue = [];
                    form.configDetails[0].formItems[0].attributeValue[0] = value;
                    form.configDetails[0].formItems[0].attributeValue[0].value = phoneconfigData.ldCarrierForm.selectedInterCarrierOption;
                    //INTRALATA Freeze Configuration
                    if (this.selectedFreeze) {
                        this.selectedFreeze && this.selectedFreeze.map(freeze => {
                            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[1]
                                && form.configDetails[1].formName === freeze.formName && form.configDetails[1].formItems !== null && form.configDetails[1].formItems[0] && form.configDetails[1].formItems[0].attributeValue !== null
                                && form.configDetails[1].formItems[0].attributeValue.length !== 0) {
                                value = form.configDetails[1].formItems[0].attributeValue[0];
                                form.configDetails[1].formItems[0].attributeValue = [];
                                form.configDetails[1].formItems[0].attributeValue[0] = value;
                                form.configDetails[1].formItems[0].attributeValue[0].value = form.configDetails[1].formItems[0].attributeName === 'TPV Needed' ?
                                    this.selectedFreeze[0] && this.selectedFreeze[0].tpvSelection : freeze.value;
                                if (form.configDetails[1].formItems && form.configDetails[1].formItems[1] && form.configDetails[1].formItems[1].attributeValue
                                    && form.configDetails[1].formItems[1].attributeValue[0] && freeze.changedOn !== '') {
                                    value = form.configDetails[1].formItems[1].attributeValue[0];
                                    form.configDetails[1].formItems[1].attributeValue = [];
                                    form.configDetails[1].formItems[1].attributeValue[0] = value;
                                    form.configDetails[1].formItems[1].attributeValue[0].value = freeze.changedOn
                                } else {
                                    form.configDetails.splice(form.configDetails.length - 1);
                                }
                            }
                        })
                    } else if (form && form.configDetails && form.configDetails[1] && form.configDetails[1].formItems && form.configDetails[1].formItems[1]
                        && form.configDetails[1].formItems[1].attributeValue && form.configDetails[1].formItems[1].attributeValue[0]
                        && form.configDetails[1].formItems[1].attributeValue[0].value === '') {
                        form.configDetails.splice(form.configDetails.length - 1);
                    }
                }
                if (form) { productConfig[indexNo].configItems.push(form); }
            }

            form = find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "") === 'CallDetail'
            });
            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0] && form.configDetails[0].formItems[0].attributeValue !== null
                && form.configDetails[0].formItems[0].attributeValue.length !== 0) {
                value = form.configDetails[0].formItems[0].attributeValue[0];
                form.configDetails[0].formItems[0].attributeValue = [];
                form.configDetails[0].formItems[0].attributeValue[0] = value;
                form.configDetails[0].formItems[0].attributeValue[0].value = phoneconfigData.ldCarrierForm.selectedCallDetailBill ? phoneconfigData.ldCarrierForm.selectedCallDetailBill : 'No';
            }
            if (form && this.phonePlan) { productConfig[indexNo].configItems.push(form) }
            //Access Line Freeze Configuration
            if (this.selectedFreeze && this.selectedFreeze.length > 0) {
                this.selectedFreeze && this.selectedFreeze.map(freeze => {
                    form = find(temp.configItems, (o) => {
                        return o.configDetails[0].formName === (freeze.formName || 'Freeze TPV')
                    });
                    if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                        && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0] && form.configDetails[0].formItems[0].attributeValue !== null
                        && form.configDetails[0].formItems[0].attributeValue.length !== 0) {
                        value = form.configDetails[0].formItems[0].attributeValue[0];
                        form.configDetails[0].formItems[0].attributeValue = [];
                        form.configDetails[0].formItems[0].attributeValue[0] = value;
                        if (value && value.value === '' && freeze && freeze.changedOn === '' && freeze.value === 'Not Added') {
                            freeze.value = '';
                        }
                        form.configDetails[0].formItems[0].attributeValue[0].value = form.configDetails[0].formItems[0].attributeName === 'TPV Needed' ?
                            this.selectedFreeze[0] && this.selectedFreeze[0].tpvSelection : freeze.value;
                        if (freeze && freeze.value === 'Add Freeze') this.actionAccess = 'ADD';
                        if (freeze && freeze.value === 'Freeze is active') this.actionAccess = 'NOCHANGE';
                        if (freeze && freeze.value === 'Remove Freeze') this.actionAccess = 'REMOVE';
                        if (form.configDetails[0].formItems && form.configDetails[0].formItems[1] && form.configDetails[0].formItems[1].attributeValue
                            && form.configDetails[0].formItems[1].attributeValue[0]) {
                            value = form.configDetails[0].formItems[1].attributeValue[0];
                            form.configDetails[0].formItems[1].attributeValue = [];
                            form.configDetails[0].formItems[1].attributeValue[0] = value;
                            form.configDetails[0].formItems[1].attributeValue[0].value = freeze.changedOn;
                            if (freeze && freeze.changedOn === '') this.actionAccess = 'DONTADD';
                        }
                    }
                    if (form && freeze && freeze.value !== '' && freeze.changedOn !== '') { productConfig[indexNo].configItems.push(form) }
                })
            } else {
                this.actionAccess = 'DONTADD';
            }
            form = find(temp.configItems, (o) => {
                return o.productName === 'Voice Mail' || o.productName === 'Voice Messaging';
            });
            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0]
                && form.configDetails[0].formItems.length !== 0) {
                for (let i = 0; i < form.configDetails[0].formItems.length; i++) {
                    if (form.configDetails[0].formItems[i].attributeName === 'Message Indicator') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.additionalForm.selectedMessageIndicatorOption;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Ring cycle') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        if (value && (value.disable || !value.disable)) delete value.disable;
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.additionalForm.selectedRingCycleOption;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Language Version') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.additionalForm.selectLanguageOption;
                    }
                }
            }
            if (form) { productConfig[indexNo].configItems.push(form); }

            form = find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "").toLowerCase() === 'callforwarding-busy';
            });
            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0] && form.configDetails[0].formItems[0].attributeValue !== null
                && form.configDetails[0].formItems[0].attributeValue.length !== 0) {
                value = form.configDetails[0].formItems[0].attributeValue[0];
                form.configDetails[0].formItems[0].attributeValue = [];
                form.configDetails[0].formItems[0].attributeValue[0] = value;
                form.configDetails[0].formItems[0].attributeValue[0].value = phoneconfigData.callfwdForm.fwdOnBusy;

            }
            if (this.phoneConfigInputData.callForwarding.callForwardingBusy && form) productConfig[indexNo].configItems.push(form);
            form = find(temp.configItems, (o) => {
                return o.productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer';
            });
            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                && form.configDetails[0].formItems !== null && form.configDetails[0].formItems[0] && form.configDetails[0].formItems[0].attributeValue !== null
                && form.configDetails[0].formItems[0].attributeValue.length !== 0) {
                for (let i = 0; i < form.configDetails[0].formItems.length; i++) {
                    if (form.configDetails[0].formItems[i].attributeName === "Forward on Don't Answer") {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.callfwdForm.fwdOnDontAnswer;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Ring cycle') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        if (value && (value.disable || !value.disable)) delete value.disable;
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = phoneconfigData.callfwdForm.selectedRingCycleOption;
                    }
                }
            }
            if (this.phoneConfigInputData.callForwarding.callForwardingNoAnswer && form) productConfig[indexNo].configItems.push(form);
        }

        if (!this.isDtvOpus) {
            if (prodConf) {
                let dtvAccountNo = this.dtvConfigForm.get('accNo').value;
                let temp = find(prodConf, (o) => {
                    return o.productType === GenericValues.cDTV;
                });
                if (temp && temp.configItems && temp.configItems[0]) {
                    let dtvForm = find(temp.configItems[0].configDetails, (o) => {
                        return o.formName === 'DTV AccountID';
                    });
                    if (dtvForm && dtvForm.formItems[0] && dtvForm.formItems[0].attributeValue[0] && dtvAccountNo) {
                        dtvForm.formItems[0].attributeValue[0].value = dtvAccountNo;
                    }
                    else if (this.existingDTVAccountId) {
                        dtvForm.formItems[0].attributeValue[0].value = this.existingDTVAccountId;
                    }
                    let yesNoObj = find(temp.configItems[0].configDetails, (o) => {
                        return o.formName === 'Account Information';
                    });
                    if (yesNoObj && yesNoObj.formItems[0] && yesNoObj.formItems[0].attributeValue) {
                        let yesNoSelected = this.dtvConfigForm.value.taskName;
                        let reqDtvObj = yesNoObj.formItems[0].attributeValue;
                        if (yesNoSelected === 'yes') {
                            reqDtvObj[0].value === 'Yes' ? reqDtvObj.splice(1, 1) : reqDtvObj.splice(0, 1);
                        } else {
                            reqDtvObj[0].value === 'Yes' ? reqDtvObj.splice(0, 1) : reqDtvObj.splice(1, 1);
                        }
                    }
                }
            }

        }

        item && item.map((custOdrs) => {
            custOdrs && custOdrs.customerOrderSubItems && custOdrs.customerOrderSubItems.map((custOdrSubItms) => {
                if (custOdrSubItms.componentType === 'PRIMARY' || custOdrSubItms.componentType === 'COMPONENT') {
                    custOdrSubItms && custOdrSubItms.productAttributes && custOdrSubItms.productAttributes.map((attr) => {
                        if (attr.isPriceable) {
                            if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                                for (let i = 0; i < attr.discounts.length; i++) {
                                    let discs = [];
                                    discs.push(attr.discounts[i]);
                                    if (!this.isReEntrant && discs) {
                                        let discountDetails = {
                                            productname: custOdrSubItms.productName,
                                            discounts: discs
                                        }
                                        let retainDiscount = []
                                        retainDiscount.push(discountDetails);
                                        this.store.dispatch({ type: 'RETAIN_DISC', payload: retainDiscount });
                                    }
                                    let d = attr.discounts[i];
                                    let chkFlag: boolean = false;
                                    if (discountItems && discountItems !== undefined) {
                                        !chkFlag && discountItems.map(cD => {
                                            if (d.autoAttachInd === 'N' && d.discountId === cD.discountId && !chkFlag) {
                                                attr.discounts[i] = d;
                                                this.addedDiscounts.push(d);
                                                chkFlag = true;
                                            }

                                        })
                                    }
                                    if (!chkFlag && d.autoAttachInd === 'N') {
                                        attr.discounts.splice(i, 1);
                                        i = i - 1;
                                    }
                                }
                            }
                        }
                    })
                } else {
                    custOdrSubItms && custOdrSubItms.productAttributes && custOdrSubItms.productAttributes.map((attr) => {
                        if (attr.isPriceable) {
                            if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                                for (let i = 0; i < attr.discounts.length; i++) {
                                    let d = attr.discounts[i];
                                    if (d.autoAttachInd === 'Y') {
                                        attr.discounts[i] = d;
                                    } else {
                                        attr.discounts.splice(i, 1);
                                        i = i - 1;
                                    }
                                }
                            }
                        }
                    })
                }
            })
        });

        if (this.potsListingValue) {
            let action = '';
            if (this.exSelectedListing && this.exSelectedListing === this.potsListingValue) {

                if (this.existingListingDirectory) {
                    let isChanged = this.isDirecoryChanged(phoneconfigData);
                    if (this.isMove) {
                        isChanged = this.isDirecoryChanged(phoneconfigData) && this.isProductChanged(item)
                    }
                    if (isChanged) {
                        action = 'CHANGE'
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                    }
                    else {
                        action = 'NOCHANGE';
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems.splice(1, 1);
                        }
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                    }
                }
            }
            else if (this.exSelectedListing && this.exSelectedListing !== this.potsListingValue) {
                action = 'CHANGE';

                if (this.exSelectedListing === 'Listed') {
                    if (this.potsListingValue === 'Non-Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Listed");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Published' || this.potsListingValue === 'Non-Pub No Charge') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                }
                else if (this.exSelectedListing === 'Non-Listed') {
                    if (this.potsListingValue === 'Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Published' || this.potsListingValue === 'Non-Pub No Charge') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                }
                else if (this.exSelectedListing === 'Non-Published') {
                    if (this.potsListingValue === 'Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Listed");
                        }
                    } else if (this.potsListingValue === 'Non-Pub No Charge') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                } else if (this.exSelectedListing === 'Non-Pub No Charge') {
                    if (this.potsListingValue === 'Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Published' || this.potsListingValue === 'Non-Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                }
            }
            else {
                action = 'ADD';
                if (this.listingToCart.customerOrderSubItems[1]) {
                    this.listingToCart.customerOrderSubItems.splice(1, 1);
                }
                this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
            }
            this.listingToCart.action = action;
            if (this.listingToCart.customerOrderSubItems[1]) {
                this.listingToCart.customerOrderSubItems[1].action = 'ADD';
            }
            if (this.potsListingValue === 'Non-Pub No Charge') {
                let isChanged = this.isDirecoryChanged(phoneconfigData);
                if (!isChanged && this.listingToCart.customerOrderSubItems[1]) this.listingToCart.customerOrderSubItems.splice(1, 1);
            }
            this.listingToCart.customerOrderSubItems[0].action = action;
            if (this.listingToCart && this.listingToCart.customerOrderSubItems && this.listingToCart.customerOrderSubItems.length > 0) {
                this.listingToCart.customerOrderSubItems.map(sub => {
                    if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                })
            }
            item.push(this.listingToCart);
            this.errorMsg = '';
        }
        else if (this.dhpListingValue) {
            let action = '';
            if (this.exSelectedListingDHP && this.exSelectedListingDHP === this.dhpListingValue) {
                if (this.existingListingDirectoryDHP) {
                    let isChanged = this.existingListingDirectoryDHP.some(item => {
                        if (item.attributeName === 'First Name' && item.attributeValue[0].value !== phoneconfigData.listingForm.firstName) {
                            return true;
                        }
                        else if (item.attributeName === 'Last Name' && item.attributeValue[0].value !== phoneconfigData.listingForm.lastName) {
                            return true;
                        }
                    });
                    if (isChanged) {
                        action = 'CHANGE'
                    }
                    else {
                        action = 'NOCHANGE';
                    }
                }
            }
            else if (this.exSelectedListingDHP && this.exSelectedListingDHP !== this.dhpListingValue) {
                action = 'CHANGE';
            }
            else {
                action = 'ADD';
            }

            this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.dhpListingValue);
            this.errorMsg = '';
            this.listingToCart.action = action;
            this.listingToCart.customerOrderSubItems[0].action = action;
            if (this.listingToCart && this.listingToCart.customerOrderSubItems && this.listingToCart.customerOrderSubItems.length > 0) {
                this.listingToCart.customerOrderSubItems.map(sub => {
                    if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                })
            }
            item.push(this.listingToCart);
        }

        if (this.mandatorySubOffers.length > 0) {
            this.mandatorySubOffers && this.mandatorySubOffers.map(subOffer => {
                if (subOffer && subOffer.offerCategory === GenericValues.cHP && subOffer.customerOrderSubItems && subOffer.customerOrderSubItems !== null
                    && subOffer.customerOrderSubItems.length > 0 && subOffer.customerOrderSubItems[0].productName === 'Access Line Freeze') {
                    let sub = subOffer.customerOrderSubItems[0];
                    if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                    if (this.actionAccess !== 'DONTADD') {
                        subOffer.action = this.actionAccess;
                        sub.action = this.actionAccess;
                        item.push(subOffer);
                    }
                } else {
                    item && item.map(data => {
                        if (data.productOfferingId === subOffer.productOfferingId) {
                            subOffer && subOffer.customerOrderSubItems && subOffer.customerOrderSubItems.map(sub => {
                                if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                                if (subOffer.offerCategory === GenericValues.cHP) {
                                    subOffer.customerOrderSubItems.map((a) => {
                                        if (a.productName === 'Call Detail') {
                                            if (a.totalPriceWithQty) delete a.totalPriceWithQty;
                                            for (let i = 0; i < a.productAttributes.length; i++) {
                                                if ((a.productAttributes[i].compositeAttribute.length > 0) && a.productAttributes[i].compositeAttribute[0].attributeName === 'printOnBill' &&
                                                    a.productAttributes[i].compositeAttribute[0].attributeValue !== this.callDetailPlan) {
                                                    a.productAttributes.splice(i, 1);
                                                }
                                            }
                                            if (!callDetailAdded) {
                                                let custItems = data.customerOrderSubItems
                                                for (let i = 0; i < custItems.length; i++) {
                                                    if (custItems[i].productName === 'Call Detail') {
                                                        custItems.splice(i, 1);
                                                    }
                                                }
                                                data.customerOrderSubItems.push(a);
                                                callDetailAdded = true;
                                            }
                                        } else if (a.productName === 'Access Line Freeze') {
                                            item.push(subOffer);
                                        }
                                    })
                                }
                            })
                        }
                    })
                }
            })
        }

        if (item && item[1] && item[1].customerOrderSubItems !== undefined && item[1].customerOrderSubItems) {
            item.forEach((arr) => {
                if (arr.offerCategory === "VOICE-HP") {
                    arr && arr.customerOrderSubItems && arr.customerOrderSubItems.forEach((a) => {
                        if (a.productName === 'Call Detail') {
                            for (let i = 0; i < a.productAttributes.length; i++) {
                                if ((a.productAttributes[i].compositeAttribute.length > 0) && a.productAttributes[i].compositeAttribute[0].attributeName === 'printOnBill' &&
                                    a.productAttributes[i].compositeAttribute[0].attributeValue !== this.callDetailPlan) {
                                    a.productAttributes.splice(i, 1);
                                }
                            }
                        }
                    })
                }
            })

        }
        if (item && item[1] && item[1].customerOrderSubItems !== undefined && item[1].customerOrderSubItems) {
            item.forEach((arr) => {
                if (arr.offerCategory === "VOICE-HP") {
                    arr && arr.customerOrderSubItems && arr.customerOrderSubItems.forEach((a) => {
                        for (let j = 0; j < arr.customerOrderSubItems.length; j++) {
                            if (arr.customerOrderSubItems[j].productName === "Non-Pub No Charge") {
                                arr.customerOrderSubItems.splice(j, 1);
                            }
                        }
                    })
                }
            })

        }
        if ((this.isChange || this.isBilling) && item && item[1] && item[1].customerOrderSubItems !== undefined && item[1].customerOrderSubItems) {
            item.forEach((arr) => {
                if (arr.offerCategory === "WIRINGWORKS") {
                    for (let j = 0; j < arr.customerOrderSubItems.length; j++) {
                        if (arr.customerOrderSubItems[j].productName === "Jack and Wire") {
                            for (let k = 0; k < arr.customerOrderSubItems[j].productAttributes.length; k++) {
                                if (arr && arr.customerOrderSubItems && arr.customerOrderSubItems[j].productAttributes && arr.customerOrderSubItems[j].productAttributes[k].compositeAttribute && arr.customerOrderSubItems[j].productAttributes[k].compositeAttribute[0].attributeValue && arr.customerOrderSubItems[j].productAttributes[k].compositeAttribute[0].attributeValue === "No work is needed") {
                                    arr && arr.customerOrderSubItems && arr.customerOrderSubItems[j].productAttributes && arr.customerOrderSubItems[j].productAttributes.splice(k, 1);
                                }
                            }
                        }
                    }
                }
            })

        }
        if (item && item.length > 0) {
            item.forEach(data => {
                if (data.offerCategory === "INTERNET" && data.offerName === "Tech Installation") {
                    if (data.customerOrderSubItems[0].productName === "Tech-Install without Modem") { data.customerOrderSubItems[0].quantity = 1; }
                }
            })
        }
        if (!(this.refObj.disableHp && this.refObj.disablePhone)) {
            if (this.newReserveTNObject) {
                for (let i of item) {
                    if (i.offerCategory === "VOICE-HP" && i.offerType === "P4L") {
                        if (i.customerOrderSubItems.length > 0) {
                            for (let k of i.customerOrderSubItems) {
                                if (
                                    k.productName === "First Phone (P4L)" &&
                                    k.componentType === "PRIMARY" &&
                                    k.productType === "VOICE-HP"
                                ) {
                                    if (k.productAttributes.length > 0) {
                                        for (let j of k.productAttributes) {
                                            if (j.compositeAttribute && (j.compositeAttribute.length > 0) && j.compositeAttribute[0] && j.compositeAttribute[0].attributeName === "pooledTNIndicator") {
                                                j.compositeAttribute[0].attributeValue = this.newReserveTNObject.pooledTNIndicator;
                                            }
                                            if (j.compositeAttribute && (j.compositeAttribute.length > 0) && j.compositeAttribute[0].attributeName === "exchangeKey") {
                                                j.compositeAttribute[0].attributeValue = this.newReserveTNObject.exchangeKey;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                this.existingServices && this.existingServices.map(exServ => {
                    if (this.isMove) exServ.customerOrderSubItems = exServ.customerOrderSubItems ? exServ.customerOrderSubItems : exServ.existingServiceSubItems;
                    if (exServ.offerCategory === GenericValues.cHP && exServ.offerType === 'P4L') {
                        if (this.isBilling && exServ && !exServ.customerOrderSubItems) exServ.customerOrderSubItems = exServ.existingServiceSubItems
                        exServ && exServ.customerOrderSubItems && exServ.customerOrderSubItems.map(exSub => {
                            for (let i of item) {
                                if (i.offerCategory === "VOICE-HP" && i.offerType === "P4L") {
                                    if (i.customerOrderSubItems.length > 0) {
                                        for (let k of i.customerOrderSubItems) {
                                            if (
                                                k.productName === "First Phone (P4L)" && exSub.productName === k.productName &&
                                                k.componentType === "PRIMARY" &&
                                                k.productType === "VOICE-HP"
                                            ) {
                                                if (k.productAttributes.length > 0) {
                                                    for (let j of k.productAttributes) {
                                                        for (let a of exSub.productAttributes) {
                                                            if (j.compositeAttribute && (j.compositeAttribute.length > 0) && (a.compositeAttribute.length > 0) && j.compositeAttribute[0] && j.compositeAttribute[0].attributeName === "pooledTNIndicator" &&
                                                                j.compositeAttribute[0].attributeName === a.compositeAttribute[0].attributeName) {
                                                                j.compositeAttribute[0].attributeValue = a.compositeAttribute[0].attributeValue;
                                                            }
                                                            if (j.compositeAttribute && (j.compositeAttribute.length > 0) && (a.compositeAttribute.length > 0) && j.compositeAttribute[0] && j.compositeAttribute[0].attributeName === "exchangeKey" &&
                                                                j.compositeAttribute[0].attributeName === a.compositeAttribute[0].attributeName) {
                                                                j.compositeAttribute[0].attributeValue = a.compositeAttribute[0].attributeValue;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        })
                    }
                })
            }
        }
        this.existingServices && this.existingServices.map(exServ => {
            if (this.isMove) exServ.customerOrderSubItems = exServ.customerOrderSubItems ? exServ.customerOrderSubItems : exServ.existingServiceSubItems;
            exServ.customerOrderSubItems = exServ.customerOrderSubItems ? exServ.customerOrderSubItems : exServ.existingServiceSubItems;
            if (exServ.offerCategory === 'INTERNET' && exServ.offerType !== 'SUBOFFER') {
                if (this.isBilling && exServ && !exServ.customerOrderSubItems) exServ.customerOrderSubItems = exServ.existingServiceSubItems
                exServ && exServ.customerOrderSubItems && exServ.customerOrderSubItems.map(exSub => {
                    let exchangeKeyHSI: AttributesCombination[] = [], indexPrim = 0;
                    for (let i of item) {
                        if (i.offerCategory === "INTERNET" && i.offerType !== "SUBOFFER") {
                            if (i.customerOrderSubItems.length > 0) {
                                for (let k of i.customerOrderSubItems) {
                                    if (k.componentType === "PRIMARY") {
                                        for (let a of exSub.productAttributes) {
                                            if ((a.compositeAttribute.length > 0) && a.compositeAttribute[0] && a.compositeAttribute[0].attributeName === "pooledTNIndicator") {
                                                exchangeKeyHSI.push(a);
                                            }
                                            if ((a.compositeAttribute.length > 0) && a.compositeAttribute[0] && a.compositeAttribute[0].attributeName === "exchangeKey") {
                                                exchangeKeyHSI.push(a);
                                            }
                                        }
                                        break;
                                    }
                                    indexPrim++;
                                }
                            }
                            if (exchangeKeyHSI.length > 0) {
                                exchangeKeyHSI.forEach(exchangeKey => {
                                    i.customerOrderSubItems[indexPrim].productAttributes.push(exchangeKey);
                                })
                            }
                        }
                    }
                })
            }
        })
        if (this.simplePortTN !== null && this.simplePortTN !== undefined && this.portingTnResponse) {
            selectedTN[0].workingTN = this.simplePortTN;
            custDataPayload.reservedTN[0].workingTN = this.simplePortTN;

        }
        if (indexNo === 0) prodConf = productConfig;
        let apiRequest: CustomizeServices = {
            orderRefNumber: this.custdata && this.custdata.orderRefNumber,
            processInstanceId: this.custdata && this.custdata.processInstanceId,
            taskId: this.isReEntrant ? this.taskId : this.custdata && this.custdata.taskId,
            taskName: this.custdata && this.custdata.taskName,
            payload: {
                cart: {
                    catalogSpecId: custDataPayload.cart.catalogSpecId ? custDataPayload.cart.catalogSpecId : '39',
                    customerOrderItems: item
                },
                reservedTN: this.refObj.disableHp && this.refObj.disablePhone ? custDataPayload.reservedTN : selectedTN,
                portCheckSimplePortFlag: (this.simpleportCustData && this.simpleportCustData.telephoneNumberType !== 'DEFAULTED' && this.simpleportCustData.simpleportcheck) ? this.simpleportCustData.simpleportcheck.portCheckResponse[0].simplePortEligibilityFlag : undefined,
                productConfiguration: this.refObj.disableInternet || !this.refObj.disableHp ? productConfig : prodConf,
                addlOrderAttributes: this.frameAdditionalAttributesRequest(),
            }

        };
        let cart1 = <Observable<any>>this.store.select('cart');
        this.cartSubscription = cart1.subscribe((data) => {
            if (data && data.vacationCart && data.vacationCart !== undefined) {
                this.vacationCartData = data.vacationCart;
            }
        });
        this.vacationCartData && this.vacationCartData.map((custOdrs) => {
            custOdrs && custOdrs.customerOrderSubItems && custOdrs.customerOrderSubItems.map((custOdrSubItms) => {
                if (custOdrSubItms.componentType === 'PRIMARY' || custOdrSubItms.componentType === 'COMPONENT') {
                    custOdrSubItms && custOdrSubItms.productAttributes && custOdrSubItms.productAttributes.map((attr) => {
                        if (attr.isPriceable) {
                            if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                                for (let i = 0; i < attr.discounts.length; i++) {
                                    let d = attr.discounts[i];
                                    let chkFlag: boolean = false;
                                    if (discountItems && discountItems !== undefined) {
                                        !chkFlag && discountItems.map(cD => {
                                            if (d.autoAttachInd === 'N' && d.discountId === cD.discountId && !chkFlag) {
                                                attr.discounts[i] = d;
                                                this.addedDiscounts.push(d);
                                                chkFlag = true;
                                            }
                                        })
                                    }
                                    if (!chkFlag && d.autoAttachInd === 'N') {
                                        attr.discounts.splice(i, 1);
                                        i = i - 1;
                                    }
                                }
                            }
                        }
                    })
                } else {
                    custOdrSubItms && custOdrSubItms.productAttributes && custOdrSubItms.productAttributes.map((attr) => {
                        if (attr.isPriceable) {
                            if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                                for (let i = 0; i < attr.discounts.length; i++) {
                                    let d = attr.discounts[i];
                                    if (d.autoAttachInd === 'Y') {
                                        attr.discounts[i] = d;
                                    } else {
                                        attr.discounts.splice(i, 1);
                                        i = i - 1;
                                    }
                                }
                            }
                        }
                    })
                }
            })
        });
        if (this.vacationFlow && this.isReEntrant) {
            let curStore = this.appStateService.getState();
            let data: any = curStore.user;
            if (data && data.previousUrl === '/existing-products') {
                this.isReEntrant = false;
            }
        }
        let apiVacationRequest: any = {
            orderRefNumber: this.custdata.orderRefNumber,
            processInstanceId: this.custdata.processInstanceId,
            taskId: this.isReEntrant ? this.taskId : this.custdata && this.custdata.taskId,
            taskName: this.custdata.taskName,
            payload: {
                cart: {
                    customerOrderItems: this.vacationCartData
                },
            }

        };
        if (this.isChange && this.isAmendOrStack) {
            this.stackLifeLine = true;
        }
        if (((this.isChange && !this.isAmendOrStack) || !this.stackLifeLine || this.isBilling || this.isMove || this.isAmendOrStack) && ((this.lifeLineShow || this.lifelinePots) || (this.lifeLineShowInternet || this.lifelineInternet) || (this.showDHPLifeline || this.lifelineDHP)) && (lifeLineProducts.length)) {
            apiRequest.payload.lifeLineConfiguration = custDataLifeLine;
            this.store.dispatch({ type: 'LIFELINE_REQUEST', payload: apiRequest.payload.lifeLineConfiguration });
        } else if ((this.isChange || this.isBilling || this.isMove || this.isAmendOrStack) && (this.lifelineReponseDataInternet && this.lifelineReponseDataInternet !== null && !this.lifeLineShowInternet && !this.lifelineReponseDataPots)) {
            custDataLifeLineConfig.lifeLineProducts.map((data) => {
                this.lifelineResAdjustments = data.lifeLineAdjustments;
                this.lifelineResDiscounts = data.lifeLineDiscounts;
                this.lifelineResConfig = data.lifeLineConfig;
                this.lifelineResProducts = data.productDetails;
            })
            let internetDetails = {
                productDetails: this.lifelineResProducts,
                lifeLineConfig: this.lifelineResConfig,
                lifeLineDiscounts: this.lifelineResDiscounts,
                lifeLineAdjustments: this.lifelineResAdjustments,
            }
            lifeLineProducts.push(internetDetails);
            apiRequest.payload.lifeLineConfiguration = {
                lifelineInd: custDataLifeLineConfig.lifeLineInd,
                llServiceType: custDataLifeLineConfig.llServiceType,
                lifeLineProducts
            };
        } else if ((this.isChange || this.isBilling || this.isMove || this.isAmendOrStack) && (this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null && !this.lifeLineShow && !this.lifelineReponseDataInternet)) {
            custDataLifeLineConfig.lifeLineProducts.map((data) => {
                this.lifelineResAdjustments = data.lifeLineAdjustments;
                this.lifelineResDiscounts = data.lifeLineDiscounts;
                this.lifelineResConfig = data.lifeLineConfig;
                this.lifelineResProducts = data.productDetails;
            })
            let potsDetails = {
                productDetails: this.lifelineResProducts,
                lifeLineConfig: this.custdata.lifelinePotsConfig ? this.custdata.lifelinePotsConfig : this.lifelineResConfig,
                lifeLineDiscounts: this.lifelineResDiscounts,
                lifeLineAdjustments: this.lifelineResAdjustments,
            }
            lifeLineProducts.push(potsDetails);
            apiRequest.payload.lifeLineConfiguration = {
                lifelineInd: custDataLifeLineConfig.lifeLineInd,
                llServiceType: custDataLifeLineConfig.llServiceType,
                lifeLineProducts
            };
        } else if ((this.isChange || this.isBilling || this.isMove || this.isAmendOrStack) && (this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null && (!this.showDHPLifeline || !this.lifelineShowDHP) && !this.lifelineReponseDataInternet)) {
            custDataLifeLineConfig.lifeLineProducts.map((data) => {
                this.lifelineResAdjustments = data.lifeLineAdjustments;
                this.lifelineResDiscounts = data.lifeLineDiscounts;
                this.lifelineResConfig = data.lifeLineConfig;
                this.lifelineResProducts = data.productDetails;
            })
            let dhpDetails = {
                productDetails: this.lifelineResProducts,
                lifeLineConfig: this.lifelineResConfig,
                lifeLineDiscounts: this.lifelineResDiscounts,
                lifeLineAdjustments: this.lifelineResAdjustments,
            }
            lifeLineProducts.push(dhpDetails);
            apiRequest.payload.lifeLineConfiguration = {
                lifelineInd: custDataLifeLineConfig.lifeLineInd,
                llServiceType: custDataLifeLineConfig.llServiceType,
                lifeLineProducts
            };
        } else if ((this.isChange || this.isBilling || this.isMove || this.isAmendOrStack) && ((this.lifelineReponseDataPots && this.lifelineReponseDataPots !== null || this.lifelineReponseDataDhp && this.lifelineReponseDataDhp !== null) && this.lifelineReponseDataInternet && this.lifelineReponseDataInternet !== null)) {
            if (!this.lifeLineShowInternet) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "INTERNET") {
                        let internetDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(internetDetails);
                    }
                })
            } else if (this.lifeLineShowInternet) {
                let internetDetails = {
                    productDetails: this.productInternetDet,
                    lifeLineConfig: this.custdata.lifelineConfig,
                    lifeLineDiscounts: this.custdata.lifelineDiscounts,
                    lifeLineAdjustments: this.custdata.lifelineAdjustment,
                }
                lifeLineProducts.push(internetDetails);
            }
            if (!this.lifeLineShow) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "VOICE-HP") {
                        let potsDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(potsDetails);
                    }
                })
            } else if (this.lifeLineShow) {
                let potsDetails = {
                    productDetails: this.productPotsDet,
                    lifeLineConfig: this.custdata.lifelinePotsConfig,
                    lifeLineDiscounts: this.custdata.lifelinePotsDiscounts,
                    lifeLineAdjustments: this.custdata.lifelinePotsAdjustment,
                }
                lifeLineProducts.push(potsDetails);
            }
            if (!this.showDHPLifeline || !this.lifelineShowDHP) {
                custDataLifeLineConfig.lifeLineProducts.map((data) => {
                    this.lifelineResAdjustments = data.lifeLineAdjustments;
                    this.lifelineResDiscounts = data.lifeLineDiscounts;
                    this.lifelineResConfig = data.lifeLineConfig;
                    this.lifelineResProducts = data.productDetails;
                    if (this.lifelineResProducts.productType === "VOICE-DHP") {
                        let dhpDetails = {
                            productDetails: this.lifelineResProducts,
                            lifeLineConfig: this.lifelineResConfig,
                            lifeLineDiscounts: this.lifelineResDiscounts,
                            lifeLineAdjustments: this.lifelineResAdjustments,
                        }
                        lifeLineProducts.push(dhpDetails);
                    }
                })
            } else if (this.showDHPLifeline || this.lifelineShowDHP) {
                let dhpDetails = {
                    productDetails: this.productPotsDet,
                    lifeLineConfig: this.custdata.lifelinePotsConfig,
                    lifeLineDiscounts: this.custdata.lifelinePotsDiscounts,
                    lifeLineAdjustments: this.custdata.lifelinePotsAdjustment,
                }
                lifeLineProducts.push(dhpDetails);
            }
            apiRequest.payload.lifeLineConfiguration = {
                lifelineInd: custDataLifeLineConfig.lifeLineInd,
                llServiceType: custDataLifeLineConfig.llServiceType,
                lifeLineProducts
            };
        }
        this.store.dispatch({ type: 'PRODUCT_CONFIG', payload: { prodConfig: apiRequest.payload.productConfiguration } });

        let isChangeFlow: string = '';
        if (this.existingData && this.existingData.orderFlow && this.existingData.orderFlow.flow !== undefined && this.existingData.orderFlow.flow === 'Change') {
            isChangeFlow = 'change';
        }
        if (this.isMove) {
            isChangeFlow = 'move';
        }
        if (this.isBilling) {
            isChangeFlow = 'billing';
        }
        if (this.isAmendOrStack) {
            isChangeFlow = "change";
        }
        if (!this.macd || this.macd || ((this.isChange && this.lifelineCheckoutReq) || (this.isAmendOrStack && this.lifelineCheckoutReq) || (this.isBilling && this.lifelineCheckoutReq) || (this.isMove && (!this.lifelineTotalResponseData || (this.lifelineCheckoutReq && this.lifelineTotalResponseData))))) {
            this.store.dispatch({ type: 'SCHEDULE_REQUEST', payload: { scheduleReq: apiRequest } });
            apiRequest = this.addGiftcard(apiRequest);
            if (this.selectedFreeze && this.selectedFreeze[0] && this.selectedFreeze[0].tpvSelection === 'Proceed with TPV as normal') {
                let additionalAttr = [
                    {
                        "orderAttributeGroup": [
                            {
                                "orderAttributeGroupName": "FreezeTPVInfo",
                                "orderAttributeGroupInfo": [
                                    {
                                        "orderAttributes": [
                                            {
                                                "orderAttributeName": "FreezeTPVRequired",
                                                "orderAttributeValue": "true"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ];
                if (apiRequest.payload && apiRequest.payload.addlOrderAttributes && apiRequest.payload.addlOrderAttributes.length > 0) {
                    apiRequest.payload.addlOrderAttributes.push(additionalAttr[0])
                } else {
                    apiRequest.payload.addlOrderAttributes = additionalAttr;
                }
            }
            apiRequest = this.tnChargeMergeToReq(apiRequest);
            if (this.isAmend) {
                apiRequest = this.removeDeleteActionOrderSubItems(apiRequest);
            }
            if (this.isNewInstall) {
                let offerVariables = this.ctlHelperService.getLocalStorage(RE_ENTRANT_OFFERVARIABLE);
                apiRequest = this.offerHelperService.removePotsFromRequest(apiRequest, offerVariables);
            }
            this.store.dispatch({ type: 'BYPASS_DISCOUNT_CHECK', payload: this.isBypassed });
            this.loading = true;
            this.logger.log("info", "customize-services.component.ts", "getResponseForCheckOutRequest", JSON.stringify(apiRequest));
            this.logger.startTime();
            if (this.isStack) {
                apiRequest = this.removeVSandVRItems(apiRequest);
            }
            if ((this.isNewInstall || this.isChange || this.isMove || this.isBilling || this.isAmend) && !this.isPrepaid && !this.isStack) {
                apiRequest.payload.allowOTCAdjustment = this.helperService.isAuthorized(ProfileEnums.WAIVE_ADJUSTABLE_OTCS) ? "YES" : "NO";
            }
            if (!this.vacationFlow) {
                this.productService.getResponseForCheckOut(apiRequest, isChangeFlow)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutResponse", error);
                        this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        this.loadingNext = false;
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error", "Not Applicable",
                            "SUBMIT_TASK", "customize-services.component.ts",
                            "CustomizeService Page",
                            error);
                        return Observable.throwError(null);
                    })
                    .subscribe(
                        (data) => {
                            this.logger.endTime();
                            this.logger.log("info", "customize-services.component.ts", "getResponseForCheckOutResponse", JSON.stringify(data ? data : ""));
                            this.logger.log("info", "customize-services.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            if (data) this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            let response = data;
                            if (response) {
                                let orderFlow = {
                                    flow: this.existingData.orderFlow.flow,
                                    type: this.existingData.orderFlow.type,
                                    selectProductCalled: true,
                                    customizeCalled: true,
                                    schedulingCalled: false
                                };
                                this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
                                if (isChangeFlow === 'move') {
                                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: response });
                                    this.router.navigate(['/move-schedule-appt-ship']);
                                }
                                else if (isChangeFlow === 'billing') {
                                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: response });
                                    this.router.navigate(['/billing-schedule-appt-ship']);
                                }
                                else if (isChangeFlow === 'vacation') {
                                    this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: response });
                                    this.ctlHelperService.storeRequestProcessData(data, 'vacation-schedule-appt-ship', 'submit', 'vacation');
                                    this.router.navigate(['/vacation-schedule-appt-ship']);
                                }
                                else {
                                    if (response.taskName === 'Confirm Scheduling') {
                                        this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: response });
                                        this.router.navigate(['/schedule-appt-ship']);
                                    } else if (response.taskName === 'Shipping Information') {
                                        this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: response });
                                        this.router.navigate(['/schedule-non-appt']);
                                    }
                                }
                                this.store.dispatch({ type: 'UPDATE_USER', payload: { oTCustomize: true } });
                            }
                        },
                        (error) => {
                            this.logger.endTime();
                            this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutResponse", error);
                            this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.loading = false;
                            this.loadingNext = false;
                            if (error === undefined || error === null) return;
                            let unexpectedError = false;
                            if (this.ctlHelperService.isJson(error)) {
                                this.apiResponseError = JSON.parse(error);
                                if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                                    this.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", this.custdata.taskName, "customize-services.component.ts", "Add-Ons Page", this.apiResponseError);
                                } else unexpectedError = true;
                            } else unexpectedError = true;
                            if (unexpectedError) {
                                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                                this.systemErrorService.logAndeRouteToSystemError("error", this.custdata.taskName, "customize-services.component.ts", "Add-Ons Page", lAPIErrorLists);
                            }
                            window.scroll(0, 0);
                        });
            }
            else {
                this.bMService.scheduleVacationCall(apiVacationRequest)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "vacation-dialog.component.ts", "checkoutAndSchedulingSubmitResponse", error);
                        this.logger.log("error", "vacation-dialog.component.ts", "checkoutAndSchedulingSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        this.systemErrorService.logAndRouteUnexpectedError("error", " ", "checkoutAndSchedulingSubmit", "vacation-dialog.component.ts", "Vacation Modal", error);
                        return Observable.throwError(null);
                    })
                    .subscribe(
                        (data) => {
                            this.logger.endTime();
                            this.logger.log("info", "vacation-dialog.component.ts", "checkoutAndSchedulingSubmitResponse", JSON.stringify(data));
                            this.logger.log("info", "vacation-dialog.component.ts", "checkoutAndSchedulingSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            if (data) this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                            this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                            this.ctlHelperService.removeLocalStorage('vacation-reconnect');
                            this.ctlHelperService.storeRequestProcessData(data, 'vacation-schedule-appt-ship', 'submit', 'vacation');
                            this.router.navigate(['/vacation-schedule-appt-ship']);
                        },
                        (error) => {
                            this.logger.endTime();
                            this.logger.log("error", "vacation-dialog.component.ts", "checkoutAndSchedulingSubmitResponse", error);
                            this.logger.log("error", "vacation-dialog.component.ts", "checkoutAndSchedulingSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.loading = false;
                            this.systemErrorService.getAPIResponseError(error, 'INIT', 'vacation-dialog.component.ts', 'Existing Product Page');
                        }
                    )
            }

        } else {
            this.loading = false;
            this.loadingNext = false;
        }
        this.store.dispatch({ type: 'UPDATE_CUSTOMIZE_CART_ITEMS', payload: apiRequest.payload.cart.customerOrderItems });
    }
    private isDirecoryChanged(phoneconfigData: any) {
        return this.existingListingDirectory && this.existingListingDirectory !== undefined && this.existingListingDirectory.some(item => {
            if (item.attributeName === 'First Name' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.firstName.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Last Name' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.lastName.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Listed Address Option' && (item.attributeValue[0].value.toUpperCase()) !== (this.selectedListedAddressOption.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Title 1' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.title1.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Title 2' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.title2.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Lineage' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.lineage.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Designation' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.designation.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Nickname' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.Nickname.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'streetNrFirst') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNrFirst && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetNrFirst.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetNrFirst && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetNrFirst.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'streetNamePrefix') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNamePrefix && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetNamePrefix.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetNamePrefix && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetNamePrefix.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'streetType') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetType && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetType.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetType && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetType.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'streetName') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetName && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetName.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetName && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetName.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'Unit') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.unit && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.unit.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.unit && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.unit.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'city') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.city && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.city.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.city && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.city.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'state') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.state && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.state.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.stateOrProvince && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.stateOrProvince.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'postCode') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.postCode && (item.attributeValue[0].value.trim()) !== (this.updatedListedAddressFields.postCode.trim())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.postCode && (item.attributeValue[0].value.trim()) !== (this.changedListedAddress.postCode.trim())) {
                    return true;
                }
            }
        });
    }

    public onchangeCallDetail(event) {
        if (event !== null && event !== undefined) {
            this.callDetailPlan = event;
        }
    }
    public populateCart(data: ShoppingCart, flag: boolean, onlyPOTS: boolean, potsAddons?: ShoppingCart, noDTV?: boolean) {
        let homePhone = false;
        let orderItem: CustomerOrderItems;
        let orderItemstoSend: CustomerOrderItems[] = [];
        if ((!flag && data && data.payload && data.payload.customerAddonOfferItems !== undefined &&
            data.payload.customerAddonOfferItems.length > 0)
            || (flag && data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems)) {
            let addOns = flag ? ((this.isReEntrant && data.cartData !== undefined) ? data.cartData.cart.customerOrderItems : data.payload.cart.customerOrderItems) : data.payload.customerAddonOfferItems;
            if (addOns.length > 0) {
                addOns && addOns.map((item) => {
                    if (!onlyPOTS && !flag && item.offerCategory !== GenericValues.cHP) {
                        homePhone = true;
                        for (let j = 0; j < this.custdata.payload.retrievalTypes[0].addOnOffers.length; j++) {
                            if (this.custdata.payload.retrievalTypes[0].addOnOffers[j].serviceCategory === (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData
                                || item.offerCategory === 'WIRINGWORKS' ? GenericValues.sData : item.offerCategory)) {

                                let mainSubOffers = this.custdata.payload.retrievalTypes[0].addOnOffers[j];
                                for (let k = 0; k < mainSubOffers.catalogs[0].catalogItems.length; k++) {
                                    item.customerOrderSubItems && item.customerOrderSubItems.map(subOffer => {
                                        let sameIdAdded = false;
                                        if (subOffer.productOfferingId === mainSubOffers.catalogs[0].catalogItems[k].productOfferingId) {
                                            if (orderItemstoSend && orderItemstoSend.length > 0) {
                                                orderItemstoSend.forEach(exItem => {
                                                    if (exItem.productOfferingId === subOffer.productOfferingId) {
                                                        sameIdAdded = true;
                                                        let subItems = this.subOrderItem([subOffer], '', potsAddons);
                                                        if (subItems && subItems.length > 0) {
                                                            subItems.forEach(sub => {
                                                                exItem.customerOrderSubItems.push(sub);
                                                            });
                                                        }
                                                    }
                                                });
                                            }
                                            if (!sameIdAdded) {
                                                orderItem = {
                                                    catalogId: item.catalogId,
                                                    productOfferingId: mainSubOffers.catalogs[0].catalogItems[k].productOfferingId,
                                                    offerType: mainSubOffers.catalogs[0].catalogItems[k].productOffer.offerType,
                                                    offerSubType: mainSubOffers.catalogs[0].catalogItems[k].productOffer.offerSubType,
                                                    offerCategory: mainSubOffers.catalogs[0].catalogItems[k].productOffer.offerCategory,
                                                    quantity: 1,
                                                    rc: item.rc,
                                                    discountedRc: item.discountedRc,
                                                    otc: item.otc,
                                                    discountedOtc: item.discountedOtc,
                                                    contractTerm: 0,
                                                    customerOrderSubItems: this.subOrderItem([subOffer], '', potsAddons),
                                                    action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((mainSubOffers.catalogs[0].catalogItems[k].productOffer.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                                        || (mainSubOffers.catalogs[0].catalogItems[k].productOffer.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.isMove || this.isChange || this.isBilling || this.isAmendOrStack ? subOffer.action : item.action,
                                                    offerName: item && item.offerName
                                                };
                                                orderItemstoSend.push(orderItem);
                                            }
                                        }
                                    })
                                }
                                break;
                            }
                        }
                    } else if (item.customerOrderSubItems.length > 0) {
                        let offerList = item.customerOrderSubItems;
                        for (let i = 0; i < offerList.length; i++) {
                            homePhone = false;
                            if ((offerList[i] === null || offerList[i] === undefined) || (flag && item.offerCategory === GenericValues.cHP && !onlyPOTS && !this.refObj.disableHp)
                                || (flag && onlyPOTS && (item.offerCategory === GenericValues.sData
                                    || item.offerCategory === GenericValues.iData)) || (noDTV && item.offerCategory === GenericValues.cDTV) || item.offerCategory === GenericValues.cHP && item.offerType === 'SUBOFFER') {
                                homePhone = true;
                                continue;
                            }
                            let actionVal = '';
                            if ((this.refObj.disableHp && item.offerCategory === GenericValues.cHP) || (this.refObj.disablePhone && item.offerCategory === GenericValues.cDHP)) {
                                actionVal = 'REMOVE';
                                if (this.refObj.disableHp && item.offerCategory === GenericValues.cHP) { this.isPOTSRemoved = true; }
                            }
                            let bundlePOTS = onlyPOTS && flag && item.offerCategory === GenericValues.cHP ? 'POTS' : '';
                            if (bundlePOTS === '') {
                                bundlePOTS = !onlyPOTS && !flag && item.offerCategory === GenericValues.cHP ? 'POTSWITHPRIMARY' : ''
                            }
                            if ((this.isMove || this.isChange || this.isBilling || this.isAmendOrStack) && item.offerCategory === GenericValues.cHP &&
                                this.potsComponent && this.potsComponent.productOffer && this.potsComponent.productOffer.action !== 'ADD'
                                && orderItem && orderItem.action) {
                                item.action = 'NOCHANGE';
                            }
                            let prod: Products[] = this.subOrderItem(item.customerOrderSubItems, bundlePOTS, potsAddons);
                            this.existingServices && this.existingServices.map(exItems => {
                                if (exItems.offerCategory === item.offerCategory && exItems.offerType !== 'SUBOFFER') {
                                    if (exItems.productOfferingId !== item.productOfferingId) {
                                        item.action = 'CHANGE';
                                    }
                                    let exSubItems = exItems.existingServiceSubItems ? exItems.existingServiceSubItems : exItems.customerOrderSubItems
                                    exSubItems && exSubItems.map(exSub => {
                                        if (exSub.productName !== 'ISP' && (exSub.componentType !== GenericValues.cPrimary && exSub.productType === GenericValues.cHP)) {
                                            let flagSub = false;
                                            !flagSub && prod && prod.length > 0 && prod.map(custSub => {
                                                if (!flagSub && custSub.productName === exSub.productName) {
                                                    flagSub = true;
                                                }
                                            })
                                            if (!flagSub) {
                                                if (item.action !== 'REMOVE') { item.action = 'CHANGE'; }
                                                exSub.action = 'REMOVE';
                                                prod.push(exSub);
                                            }
                                        }
                                    })
                                }
                            })
                            orderItem = {
                                catalogId: item.catalogId,
                                productOfferingId: item.productOfferingId,
                                offerType: item.offerType,
                                offerSubType: item.offerSubType,
                                offerCategory: item.offerCategory,
                                quantity: 1,
                                rc: item.rc,
                                discountedRc: item.discountedRc,
                                otc: item.otc,
                                discountedOtc: item.discountedOtc,
                                contractTerm: 0,
                                customerOrderSubItems: item.offerCategory === GenericValues.cHP ? prod : this.subOrderItem(item.customerOrderSubItems, bundlePOTS, potsAddons),
                                action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((item.offerCategory === GenericValues.cHP && !this.potsExistingOnCompleted)
                                    || (item.offerCategory === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.isMove || this.isChange || this.isBilling || this.isAmendOrStack ? actionVal === 'REMOVE' ? actionVal : item.action ? item.action : 'ADD' : item.action,
                                offerName: item.offerName
                            };
                        }
                        if ((this.isMove || this.isChange || this.isBilling || this.isAmendOrStack) && this.isChangeAction && orderItem && orderItem.action === 'NOCHANGE') { orderItem.action = 'CHANGE'; }
                        if ((this.isMove || this.isChange || this.isBilling || this.isAmendOrStack) && item.offerCategory === GenericValues.cHP && item.action && item.action !== 'REMOVE') {
                            if (this.potsComponent && this.potsComponent.productOffer && this.potsComponent.productOffer.action === 'ADD'
                                && orderItem && orderItem.action) {
                                orderItem.action = 'ADD';
                            }
                        }
                        if (!homePhone) orderItemstoSend.push(cloneDeep(orderItem));
                    }
                });

            }
        }
        return orderItemstoSend;
    }

    public addGiftcard(apiRequest: any, Disclosureflag?) {
        let isHSI;
        if (Disclosureflag) {
            isHSI = apiRequest.cart.customerOrderItems.filter(x => {
                return x.offerCategory === 'INTERNET'
            })
        } else {
            isHSI = apiRequest.payload.cart.customerOrderItems.filter(x => {
                return x.offerCategory === 'INTERNET'
            })

            if (!isHSI.length) { return apiRequest }
        }
        let selectedGiftCards: any = [{
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "giftCard",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                            ]
                        }
                    ]
                }
            ]
        }];


        if (this.selectedGiftcard && this.selectedGiftcard.length && this.selectedGiftcard.length > 0) {
            let Attributs = [];
            if (Disclosureflag) {
                this.selectedGiftcard && this.selectedGiftcard.map(itrm => {
                    Attributs.push({
                        "orderAttributeName": "ProdcutId",
                        "orderAttributeValue": apiRequest.cart.customerOrderItems.filter(x => {
                            return x.offerCategory === 'INTERNET'
                        })[0].customerOrderSubItems.filter(y => {
                            return y.componentType === 'PRIMARY'
                        })[0].productId
                    },
                        {
                            "orderAttributeName": "giftCardOfferName",
                            "orderAttributeValue": itrm.toString()
                        });
                })
            } else {
                this.selectedGiftcard && this.selectedGiftcard.map(itrm => {
                    Attributs.push({
                        "orderAttributeName": "ProdcutId",
                        "orderAttributeValue": apiRequest.payload.cart.customerOrderItems.filter(x => {
                            return x.offerCategory === 'INTERNET'
                        })[0].customerOrderSubItems.filter(y => {
                            return y.componentType === 'PRIMARY'
                        })[0].productId
                    },
                        {
                            "orderAttributeName": "giftCardOfferName",
                            "orderAttributeValue": itrm.toString()
                        });
                })
            }
            selectedGiftCards[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes = Attributs;
        }

        if (Disclosureflag) {
            if (apiRequest && apiRequest.addlOrderAttributes && apiRequest.addlOrderAttributes.length > 0) {
                apiRequest.addlOrderAttributes.push(selectedGiftCards[0])
            } else {
                apiRequest.addlOrderAttributes = selectedGiftCards;
            }
            return apiRequest;
        } else {
            if (this.selectedGiftcard.length === 0) {
                return apiRequest;
            } else {
                if (apiRequest.payload && apiRequest.payload.addlOrderAttributes && apiRequest.payload.addlOrderAttributes.length > 0) {
                    apiRequest.payload.addlOrderAttributes.push(selectedGiftCards[0])
                } else {
                    apiRequest.payload.addlOrderAttributes = selectedGiftCards;
                }
                return apiRequest;
            }
        }

    }

    public subOrderItem(customerOrderSubItems: Products[], flag: string, potsAddons?: ShoppingCart) {
        let product: Products;
        let products: Products[] = [];
        let isPOTSPrimaryExists = false;
        let isChanged: boolean = false;
        this.isChangeAction = false;
        if (flag === '' || flag === 'POTSWITHPRIMARY') {
            customerOrderSubItems && customerOrderSubItems.map(component => {
                if (component.productName !== "Non-Pub No Charge") {
                    let subExisting = 'ADD';
                    this.existingServices && this.existingServices.map(exItems => {
                        if (exItems.offerCategory === GenericValues.cHP) {
                            if (this.isMove) {
                                if (exItems && exItems.existingServiceSubItems) {
                                    exItems.existingServiceSubItems && exItems.existingServiceSubItems.map(exSub => {
                                        if (exSub.productName === component.productName) {
                                            component.action === 'REMOVE' ? subExisting = component.action : subExisting = 'NOCHANGE';
                                        }
                                    })
                                } else if (exItems && exItems.customerOrderSubItems) {
                                    exItems.customerOrderSubItems && exItems.customerOrderSubItems.map(exSub => {
                                        if (exSub.productName === component.productName) {
                                            component.action === 'REMOVE' ? subExisting = component.action : subExisting = 'NOCHANGE';
                                        }
                                    })
                                }
                            } else if (this.isChange || this.isBilling || this.isAmendOrStack) {
                                let exTems = exItems.existingServiceSubItems ? exItems.existingServiceSubItems : exItems.customerOrderSubItems;
                                exTems && exTems.map(exSub => {
                                    if (exSub.productName === component.productName) {
                                        component.action === 'REMOVE' ? subExisting = component.action : subExisting = 'NOCHANGE';
                                    }
                                })
                            }
                        }
                    })
                    product = {
                        productId: component.productId,
                        productName: component.productName,
                        productType: component.productType,
                        componentType: component.componentType,
                        productAttributes: component.productAttributes,
                        productAssociations: component.productAssociations,
                        productCategory: component.productCategory,
                        quantity: component.quantity,
                        action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((component.productType === GenericValues.cHP && !this.potsExistingOnCompleted)
                            || (component.productType === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.isMove || this.isChange || this.isBilling || this.isAmendOrStack ?
                                component.productType === GenericValues.cHP ? subExisting :
                                    component.action ? component.action : 'ADD' : component.action
                    }
                    if (!isChanged && product.action === 'ADD') {
                        isChanged = true;
                        this.isChangeAction = true;
                    }
                    products.push(product);
                    if (product.componentType === GenericValues.cPrimary && product.productType === GenericValues.cHP) {
                        isPOTSPrimaryExists = true;
                    }
                }
            })
        }
        if ((flag === 'POTS' || flag === 'POTSWITHPRIMARY') && !isPOTSPrimaryExists) {
            customerOrderSubItems && customerOrderSubItems.map(component => {
                if (component.productName !== "Non-Pub No Charge") {
                    if (component.componentType === GenericValues.cPrimary || component.productName.indexOf('Wire Maintenance Plan') !== -1 ||
                        component.productName.indexOf('Jack and Wire') !== -1 || ((component.productName.indexOf('Voice Messaging') !== -1
                            || component.productName.indexOf('Easy Access') !== -1) && this.voiceMailAdded)) {
                        product = {
                            productId: component.productId,
                            productName: component.productName,
                            productType: component.productType,
                            componentType: component.componentType,
                            productAttributes: component.productAttributes,
                            productAssociations: component.productAssociations,
                            productCategory: component.productCategory,
                            quantity: component.quantity,
                            action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((component.productType === GenericValues.cHP && !this.potsExistingOnCompleted)
                                || (component.productType === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.isMove || this.isChange || this.isBilling || this.isAmendOrStack ? this.hpExisting ? component.action : 'ADD' : undefined
                        }
                        if (!isChanged && product.action === 'ADD') {
                            isChanged = true;
                            this.isChangeAction = true;
                        }
                        products.push(product);
                        isPOTSPrimaryExists = true;
                    }
                }
            })
            if (potsAddons && potsAddons.payload && potsAddons.payload.cart && potsAddons.payload.cart.customerOrderItems) {
                potsAddons.payload.cart.customerOrderItems.forEach(data => {
                    if (data.offerCategory === GenericValues.cHP) {
                        let dat = data.existingServiceSubItems ? data.existingServiceSubItems : data.customerOrderSubItems;
                        dat && dat.forEach(component => {
                            if (component.componentType === GenericValues.cPrimary || component.productName.indexOf('Wire Maintenance Plan') !== -1 ||
                                component.productName.indexOf('Jack and Wire') !== -1 || ((component.productName.indexOf('Voice Messaging') !== -1
                                    || component.productName.indexOf('Easy Access') !== -1) && this.voiceMailAdded)) {
                                product = {
                                    productId: component.productId,
                                    productName: component.productName,
                                    productType: component.productType,
                                    componentType: component.componentType,
                                    productAttributes: component.productAttributes,
                                    productAssociations: component.productAssociations,
                                    productCategory: component.productCategory,
                                    quantity: component.quantity,
                                    action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((component.productType === GenericValues.cHP && !this.potsExistingOnCompleted)
                                        || (component.productType === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.isMove || this.isChange || this.isBilling || this.isAmendOrStack ? this.hpExisting ? component.action : 'ADD' : undefined
                                }
                                if (!isChanged && product.action === 'ADD') {
                                    isChanged = true;
                                    this.isChangeAction = true;
                                }
                                products.push(product);
                            }
                        });
                    }
                })
            }
            if (this.previousLoaded && this.previousLoaded.customerOrderSubItems && !this.isPOTSRemoved) {
                for (let i = 0; i < this.previousLoaded.customerOrderSubItems.length; i++) {
                    if ((this.previousLoaded.customerOrderSubItems[i].product && this.previousLoaded.customerOrderSubItems[i].product.productName &&
                        (this.previousLoaded.customerOrderSubItems[i].product.productName.indexOf('Wire Maintenance Plan') === -1 &&
                            this.previousLoaded.customerOrderSubItems[i].product.productName.indexOf('Jack and Wire') === -1) &&
                        (this.previousLoaded.customerOrderSubItems[i].isDefault === 0 && this.previousLoaded.customerOrderSubItems[i].isMandatory)
                        && this.previousLoaded.customerOrderSubItems[i].product.componentType !== GenericValues.cPrimary)) {
                        let component = this.previousLoaded.customerOrderSubItems[i].product;
                        product = {
                            productId: component.productId,
                            productName: component.productName,
                            productType: component.productType,
                            componentType: component.componentType,
                            productAttributes: component.productAttributes,
                            productAssociations: component.productAssociations,
                            productCategory: component.productCategory,
                            quantity: component && component.quantity && component.quantity.defaultQuantity,
                            action: ((this.isLatestPendingOrderNI) || (!this.isLatestPendingOrderNI && ((component.productType === GenericValues.cHP && !this.potsExistingOnCompleted)
                                || (component.productType === GenericValues.iData && !this.hsiExistingOnCompleted)))) && this.isAmend ? 'ADD' : this.isMove || this.isChange || this.isBilling || this.isAmendOrStack ? this.hpExisting ? 'NOCHANGE' : 'ADD' : undefined
                        }
                        let flagSub = false;
                        this.existingServices && this.existingServices.map(exItems => {
                            if (exItems.offerCategory === GenericValues.cHP && exItems.offerType !== 'SUBOFFER') {
                                let exSubItems = exItems.existingServiceSubItems ? exItems.existingServiceSubItems : exItems.customerOrderSubItems;
                                exSubItems && exSubItems.map(exSub => {
                                    if (exSub.productName !== 'ISP' && (exSub.componentType !== GenericValues.cPrimary && exSub.productType === GenericValues.cHP)) {
                                        if (!flagSub && product.productName === exSub.productName) {
                                            flagSub = true;
                                        }
                                    }
                                })
                            }
                        })
                        if (!flagSub) {
                            product.action = 'ADD';
                        }
                        if (!isChanged && product.action === 'ADD') {
                            isChanged = true;
                            this.isChangeAction = true;
                        }
                        products.push(product);
                    }
                }
            }
        }
        return products;
    }

    private voiceMailAdded = false;

    /** Cancel button click handler */
    public cancelOrder() {
        this.router.navigate(['/home']);
    }

    public isLATAExist = false;
    public selectedLATAName: string = '';
    public isMainOfferLATA = false;

    public lataCall(flag) {
        this.isMainOfferLATA = false;
        let prod: string;
        let prodAvailable: boolean = false;
        if (this.productName === undefined || this.productName === null) {
            prod = this.potsOfferName;
        } else {
            prod = this.productName;
        }
        prod && this.lataList && this.lataList.map((lateProd) => {
            if (lateProd[0] === prod) {
                prodAvailable = true;
            }

        });
        if (prodAvailable && this.potsOfferName === prod) this.isMainOfferLATA = true;
        this.isLATAExist = prodAvailable;
        this.selectedLATAName = this.productName;
        if (this.lataList !== null && prodAvailable) {
            this.lataList && this.lataList.map(lata => {
                if (lata[0] === prod) {
                    if (lata[3] !== null) {
                        this.phoneConfigInputData.ldCarrierData.intraLataArray[0].value = lata[3];
                        this.phoneConfigInputData.ldCarrierData.intraLataArray[0].isDefault = lata[3] === lata[5];
                        if (lata[4] !== null) {
                            this.phoneConfigInputData.ldCarrierData.intraLataArray[1].value = lata[4];
                            this.phoneConfigInputData.ldCarrierData.intraLataArray[1].isDefault = lata[4] === lata[5];
                        }
                    } else if (lata[4] !== null) {
                        this.phoneConfigInputData.ldCarrierData.intraLataArray[0].value = lata[4];
                        this.phoneConfigInputData.ldCarrierData.intraLataArray[0].isDefault = lata[4] === lata[5];
                    }
                    if (lata[1] !== null) {
                        this.phoneConfigInputData.ldCarrierData.interLataArray[0].value = lata[1];
                        this.phoneConfigInputData.ldCarrierData.interLataArray[0].isDefault = lata[1] === lata[6];
                        if (lata[2] !== null) {
                            this.phoneConfigInputData.ldCarrierData.interLataArray[1].value = lata[2];
                            this.phoneConfigInputData.ldCarrierData.interLataArray[1].isDefault = lata[2] === lata[6];
                        }
                    } else if (lata[2] !== null) {
                        this.phoneConfigInputData.ldCarrierData.interLataArray[0].value = lata[2];
                        this.phoneConfigInputData.ldCarrierData.interLataArray[0].isDefault = lata[2] === lata[6];
                    }
                }
            })
        } else {
            this.phoneConfigInputData.ldCarrierData.interLataArray = [];
            this.phoneConfigInputData.ldCarrierData.intraLataArray = [];
            if (this.legacyProvider !== 'CENTURYLINK') {
                this.phoneConfigInputData.ldCarrierData.interLataArray = [
                    {
                        value: "NONE",
                        isDefault: true
                    }]

                this.phoneConfigInputData.ldCarrierData.intraLataArray = [
                    {
                        value: "9199-NONE",
                        isDefault: true
                    }]
            } else {
                this.phoneConfigInputData.ldCarrierData.interLataArray = [
                    {
                        value: "10X1 - No PIC",
                        isDefault: true
                    }]

                this.phoneConfigInputData.ldCarrierData.intraLataArray = [
                    {
                        value: "10X1 - No PIC",
                        isDefault: true
                    }]
            }
        }
        this.restrictivePotsSelected = flag;
        this.loading = false;
    }

    public productRequired(event) {
        if (event !== null) {
            this.productRequires = true;
            this.productMsg = event;
        } else {
            this.productRequires = false;
        }
    }

    public cFNoAnswerSelected = false;

    public onAddonSelected(selectedData) {
        let restrictive = false;
        this.isUndoAll = false;
        this.selectedObjectsList = selectedData;
        this.phoneConfigInputData.callForwarding.selected = false;
        this.nonpubNoChargeSelected = false;
        this.techInstallAdded = false;
        this.phoneConfigInputData.callForwarding.callForwardingBusy = false;
        this.phoneConfigInputData.callForwarding.callForwardingNoAnswer = false;
        this.cFNoAnswerSelected = false;
        this.phonePlan = this.potsOfferName && this.potsOfferName !== "PFL Internet and Essential Home Phone" ? this.phonePlan : false;
        this.productName = null;
        if (selectedData && selectedData.length) {
            for (let j = 0; j < selectedData.length; j++) {
                if (selectedData[j] && selectedData[j].offerCategory === GenericValues.cHP && selectedData[j].customerOrderSubItems.length > 0) {
                    for (let i = 0; i < selectedData[j].customerOrderSubItems.length; i++) {
                        let productName = selectedData[j].customerOrderSubItems[i].productName
                        if (productName.replace(/\s/gi, "") === 'CallForwarding-NoAnswer') {
                            this.phoneConfigInputData.callForwarding.selected = true;
                            this.cFNoAnswerSelected = true;
                            switch (productName.replace(/\s/gi, "")) {
                                case 'CallForwarding-NoAnswer': this.phoneConfigInputData.callForwarding.callForwardingNoAnswer = true; break;
                            }
                        }
                        if (productName.replace(/\s/gi, "").toLowerCase() === 'callforwarding-busy') {
                            this.phoneConfigInputData.callForwarding.selected = true;
                            this.phoneConfigInputData.callForwarding.callForwardingBusy = true;
                        }
                        if (productName === 'Non-Pub No Charge') {
                            this.nonpubNoChargeSelected = true;
                        }
                        if (this.formRule !== '' && productName.replace(/\s/gi, "") === 'TollRestrictNoDeposit') {
                            restrictive = true;
                        }
                        if (this.formRule !== '' && (productName.replace(/\s/gi, "") === 'EasyTalk2' || productName.replace(/\s/gi, "") === 'EasyTalkMRC' || productName.replace(/\s/gi, "") === 'CenturyLinkUnlimited')) {
                            restrictive = true;
                            this.phonePlan = false;
                            this.productName = productName;
                            if (productName.replace(/\s/gi, "") === 'CenturyLinkUnlimited') {
                                this.phonePlan = true;
                            }
                        }
                    }
                } else if (selectedData[j] && (selectedData[j].offerCategory === "WIRINGWORKS" || selectedData[j].offerCategory === GenericValues.iData) && selectedData[j].customerOrderSubItems.length > 0) {
                    this.techInstallAdded = false;
                    for (let i = 0; i < selectedData[j].customerOrderSubItems.length; i++) {
                        let product = selectedData[j].customerOrderSubItems[i]
                        if (product.productName === "Tech-Install without Modem") {
                            this.deviceSelected.configItems.map(config => {
                                config.configDetails.map(detail => {
                                    detail.formItems.map(form => {
                                        form.attributeValue.map(attr => {
                                            this.isDeviceSelected = true;
                                            attr.value = product.quantity + ' ' + detail.formName;
                                            if (product.quantity === null || product.quantity === 'na') {
                                                this.isDeviceSelected = false;
                                            } else {
                                                this.deviceValues.map(val => {
                                                    if (val.value.indexOf(product.quantity) !== -1) {
                                                        attr.value = val.value;
                                                    }
                                                })
                                            }
                                        })
                                    })
                                })
                            })
                            this.techInstallAdded = true;
                        }
                    }
                }
            }
            if (restrictive !== this.restrictivePotsSelected && this.lataList) {
                this.lataCall(restrictive);
            }
        }
        this.refObj.isUndo = true;
        if (this.hpActive) {
            this.isHPTabClicked = true;
        }
    }

    public ngOnDestroy() {
        this.store.dispatch({ type: 'RETAIN_FREEZE', payload: this.selectedFreeze });
        if (this.custSubscription !== undefined) {
            this.custSubscription.unsubscribe();
        }
        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }
        if (this.existingSubscription !== undefined) {
            this.existingSubscription.unsubscribe();
        }
        if (this.vacationSubscription !== undefined) {
            this.vacationSubscription.unsubscribe();
        }
        if (this.userSubscription) this.userSubscription.unsubscribe();
        if (this.pendingSubscription !== undefined) {
            this.pendingSubscription.unsubscribe();
        }
        if (this.undoChangesSub !== undefined) {
            this.undoChangesSub.unsubscribe();
        }
    }

    public onPhoneConfigError(data) {
        this.phoneConfigError = data;
    }

    public lifeLineShow: boolean = false;
    public lifeLineShowInternet: boolean = false;
    public showPotsLifeline: boolean = false;
    public showDHPLifeline: boolean = false;
    public lifeLineHideInternet: boolean = false;
    public lifelineShowDHP: boolean = false;
    public showLifeLine() {
        this.lifelinePOtsRemove = false;
        this.showHide = true;
        this.phoneConfigObj = {
            showHide: this.showHide
        }
        this.lifeLineShow = true;
        this.showPotsLifeline = true;
        this.store.dispatch({ type: 'LIFELINE_POTS_ADDED', payload: this.showPotsLifeline });
    }
    public hidePots() {
        this.showHide = false;
        this.phoneConfigObj.showHide = this.showHide;
    }
    public showDHPLifeLine() {
        this.lifelinePOtsRemove = false;
        this.showDHPLifeline = true;
        this.lifelineShowDHP = true;
        this.showHide = true;
        this.phoneConfigObj = {
            showHide: this.showHide
        }
        this.store.dispatch({ type: 'LIFELINE_DHP_ADDED', payload: this.showDHPLifeline });
    }
    public lifeLineShowHide() {
        this.lifeLineHideInternet = false;
    }
    public showLifeLineInternet() {
        this.lifelineHsiRemove = false;
        this.lifeLineShowInternet = true;
        this.lifeLineHideInternet = true;
        this.addedLifelineInternet = true;
        this.store.dispatch({ type: 'LIFELINE_INTERNET_ADDED', payload: this.lifeLineShowInternet });
    }

    /** Closers Promos Tab Enable/Disable Function */
    public cpTab() {
        let cptabFlag = true;
        this.cartObj.customerOrderItems && this.cartObj.customerOrderItems.map((cpItem) => {
            cpItem.customerOrderSubItems.map((itm) => {
                itm.productAttributes && itm.productAttributes.map((attr) => {
                    if (attr.isPriceable) {
                        if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
                            attr.discounts.map((d) => {
                                if (d.autoAttachInd === 'N' && cptabFlag) {
                                    this.refObj.disableClosure = cptabFlag = false;
                                }
                            })
                        }
                    }
                })
            })
        })
    }
    public GetCloserPromoTab(cpTabEnability: any) {
        this.disableCloserandPromos = cpTabEnability;
    }

    private selectedFreeze: any;
    public emitFreeze(data) {
        this.selectedFreeze = data;
    }

    public onContinueFromCustomizeForRestoreFlow() {
        this.loading = true;
        this.vacRequest = {
            orderRefNumber: this.vacOrderRefNumber,
            taskId: this.isReEntrant ? this.reentrantvacTaskId : this.vacTaskId,
            processInstanceId: this.vacProcessInstanceId,
            taskName: "Checkout & Scheduling",
            payload: {
                cart: {
                    catalogSpecId: '',
                    customerOrderItems: []
                }
            }
        }
        this.vacRequest.payload.cart.customerOrderItems = this.vacResCart.customerOrderItems
            .map(item => {
                delete item.productType;
                return item;
            });
        this.logger.log("info", "customize-services.component.ts", "scheduleVacationCallRequest", JSON.stringify(this.vacRequest));
        this.logger.startTime();
        let errorResolved = false;
        this.bMService.scheduleVacationCall(this.vacRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts", "scheduleVacationCallResponse", error);
                this.logger.log("error", "customize-services.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError("error", " ", "checkoutAndSchedulingSubmit", "vacation-dialog.component.ts", "Vacation Modal", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "customize-services.component.ts", "scheduleVacationCallResponse", JSON.stringify(data));
                    this.logger.log("info", "customize-services.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                    this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                    this.store.dispatch({ type: 'VACATIONRESTORE_SCHEDULE_RESPONSE', payload: data });
                    this.ctlHelperService.storeRequestProcessData(data, 'vacation-schedule-appt-ship', 'submit', 'vacation');
                    this.router.navigate(['/vacation-schedule-appt-ship']);
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.ctlHelperService.isJson(error) && this.logger.log("info", "customize-services.component.ts", "scheduleVacationCallResponse", error);
                        this.logger.log("info", "customize-services.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    this.systemErrorService.getAPIResponseError(error, 'INIT', 'customize-services.component.ts', 'Customize Service Page');
                }
            )
    }

    private removeVSandVRItems(apiReq: CustomizeServices) {
        if (apiReq && apiReq.payload && apiReq.payload.cart && apiReq.payload.cart.customerOrderItems) {
            apiReq.payload.cart.customerOrderItems = apiReq.payload.cart.customerOrderItems.filter((custItem) => !((custItem.offerName === VacationEnums.POTS_VAC_RES_OFFER_NAME) || (custItem.offerName === VacationEnums.POTS_VAC_SUS_OFFER_NAME)))
        }
        return apiReq;
    }


    private isProductChanged(customerOrderItems) {
        return customerOrderItems.some((item) => {
            return (item.offerCategory == "VOICE-HP" && item.action === "CHANGE" || item.action === "ADD")
        });
    }

    public updateListingAddOn(clear?: boolean) {
        let data = {
            price: '',
            name: ''
        }
        if (!clear) {
            let productAttributes = this.listingSelectionChange("ListingDataChange");
            productAttributes.forEach((pa) => {
                if (pa.isPriceable && pa.prices.length > 0 && pa.compositeAttribute.length > 0 && pa.compositeAttribute[0].attributeName == "Listing Change") {
                    data.price = pa.prices[0].discountedOtc ? pa.prices[0].discountedOtc : pa.prices[0].otc;
                    data.name = pa.compositeAttribute[0].attributeDisplayName;
                }
            });
        }

        if ((data.price && data.name) || clear) {

            let deliveryToCart = {
                productId: '',
                name: data.name,
                productType: GenericValues.hpAddOn,
                isRegulated: '',
                prices:
                    [
                        {
                            discountedRc: 0,
                            discountedOtc: data.price,
                            otc: data.price,
                            rc: 0
                        }
                    ]
            };
            this.store.dispatch({ type: 'UPDATE_LISTING_ADDON', payload: deliveryToCart });
        }

    }

    public checkForDirectoryListingChange() {
        let phoneconfigData = this.phoneConfigForm.get("phoneConfigData").value;
        let cart1 = <Observable<ShoppingCart>>this.store.select('cart');
        let listingDetails;
        this.cartSubscription = cart1.subscribe((data) => {
            if (data && data.payload && data.payload.cart) {
                listingDetails = data.payload.listing;
            }
        });
        if (!this.cartSubscription) this.cartSubscription.unsubscribe();
        let item = this.custdata.payload.cart.customerOrderItems;

        if (this.potsListingValue) {
            if (this.exSelectedListing && this.exSelectedListing === this.potsListingValue) {
                if (this.existingListingDirectory && phoneconfigData.listingForm) {
                    let isChanged = this.isDirecoryChanged(phoneconfigData);
                    if (isChanged) {
                        if (!listingDetails || listingDetails.name !== "ListingDataChange") {
                            this.updateListingAddOn();
                        }
                    } else {
                        if (listingDetails && listingDetails.name === "ListingDataChange") {
                            this.updateListingAddOn(true);
                        }
                    }
                }
            } else if (this.exSelectedListing && this.exSelectedListing !== this.potsListingValue) {
                if ((this.exSelectedListing === 'Non-Pub No Charge' && this.potsListingValue === 'Listed') ||
                    (this.exSelectedListing === 'Non-Listed' && this.potsListingValue === 'Listed') ||
                    (this.exSelectedListing === 'Non-Published' && this.potsListingValue === 'Listed')) {
                    if (!listingDetails || listingDetails.name !== "ListingDataChange") {
                        this.updateListingAddOn();
                    }
                }
            }
        }
    }
}