import { Component, OnDestroy, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Logger } from '../../common/logging/default-log.service';

@Component({
    selector: 'tv-product-offer',
    templateUrl: './tv-product-offer.component.html',
    styleUrls: ['./tv-product-offer.component.scss', '../offer.component.scss']
})
export class TvProductOfferComponent implements OnInit, OnDestroy {

    @Input() public newFlowFlag;
    @Input() public directvAccountId;
    @Input() public dtvExisting;
    @Input() public isOptedOut;
    @Input() public optedOutCheck;
    @Input() public productToRemove;
    @Input() public videoOffer;
    @Input() public videoSelected;
    @Input() public removeResponse;
    @Input() public removeSelectedReason: EventEmitter<object> = new EventEmitter<object>();
    @Output() public removeTV: EventEmitter<object> = new EventEmitter<object>();
    @Output() public getRemoveResponse: EventEmitter<object> = new EventEmitter<object>();
    @Output() public removeExistingProduct: EventEmitter<object> = new EventEmitter<object>();
    @Output() public retrieveSecurityDepositHistoryForOptOut: EventEmitter<object> = new EventEmitter<object>();
    @Output() public setOptOutMessage: EventEmitter<object> = new EventEmitter<object>();

    constructor(private logger: Logger) {
    }

    public ngOnInit() {
        this.logger.metrics('PhoneConfigurationPage');
    }

    public removeDTV() {
        this.removeTV.emit();
    }

    public getRemoveDTVResponses() {
        this.getRemoveResponse.emit();
    }

    public removeExistingDTVProduct(reason) {
        this.removeExistingProduct.emit(reason);
    }

    public retrieveSecDepositHistoryForOptOut() {
        this.retrieveSecurityDepositHistoryForOptOut.emit();
    }

    public setMessageData(msg: string, removeProduct: string) {
        let array = [];
        array.push(msg);
        array.push(removeProduct);
        this.setOptOutMessage.emit(array);
    }

    public ngOnDestroy() {
    }

}
