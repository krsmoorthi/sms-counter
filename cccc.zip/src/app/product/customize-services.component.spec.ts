import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomizeServicesComponent } from './customize-services.component';
import { MockServer } from 'app/MockServer.test';
import { Observable, of, throwError } from 'rxjs';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger,
  MockSystemErrorService,
  MockBlueMarbleService,
  MockHelperService,
  MockDisclosuresService,
  MockReviewOrderService,
  MockPendingOrderService,
  MockAccountService,
  MockAddressService,
  MockCountryStateService,
  MockDirectvService,
  MockPropertiesHelperService,
  MockDisconnectService
 } from 'app/common/service/mockServices.test';
import { RouterTestingModule } from '@angular/router/testing';
import { AppStateService } from 'app/common/service/app-state.service';
import { ProductService } from 'app/common/service/product.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { FormBuilder, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { HelperService } from 'app/common/service/helper.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { TooltipModule, AccordionModule, TabsModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { OneTimeChargesComponent } from './onetime-charges/onetime-charges.component';
import { ClosersPromosComponent } from './closers-promos/closers-promos.component';
import { PhoneConfigurationComponent } from './phone-configuration/phone-configuration.component';
import { InternetConfigurationComponent } from './internet-configuration/internet-configuration.component';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import "rxjs/add/observable/of";
import { ScheduleShippingAppointmentComponent } from 'app/scheduling/schedule-shipping-appointment.component';


describe('CustomizeServicesComponent', () => {
  let component: CustomizeServicesComponent;
  let fixture: ComponentFixture<CustomizeServicesComponent>;
  const mockServer = new MockServer();
  
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    SharedCommonModule,
    TextMaskModule,
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    TooltipModule.forRoot(),
    RouterTestingModule.withRoutes([
      {path: 'schedule-appt-ship', component: ScheduleShippingAppointmentComponent}
    ]),
    BrowserAnimationsModule
  ];

  const declaration = [
    CustomizeServicesComponent,
    OneTimeChargesComponent,
    ClosersPromosComponent,
    PhoneConfigurationComponent,
    InternetConfigurationComponent
  ];

  class MockProductService {
    productService = new ProductService(null,null,null);
    getOfferDisplayName() { 
        return of(null);
    }
    getResponseForRemove() {
          return of(null);
    }
    getCompatibilityRules() {
        return of(mockServer.getResponseForReducerAndApi('getCompRules'));
    }
    public findObjByName(list, fieldName, fieldVal, fieldName1 = undefined,
        fieldVal1 = undefined, prefix = undefined) {
        return this.productService.findObjByName(list,fieldName,fieldVal,fieldName1,fieldVal1,prefix);
    }
    getFreezeDropDown() {
      return of(null);
    }
    getCompatibilityRulesforClosers() {
      return of(null);
    }
    getLATA() {
      return of(mockServer.getResponseForReducerAndApi('getLATA'));
    }
    getResponseForCheckOut() {
      return of(mockServer.getResponseForReducerAndApi('checkoutAndSchedulingRes_HSI_POTS_NI'));
    }
  }

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }
  class MockAppStateService{
    setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE');
    }
  }

  //component provider list
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const logger = { provide: Logger, useClass: MockLogger };
  const productService = { provide: ProductService, useClass: MockProductService };
  const formBuilder = FormBuilder;
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const cTLHelperService = CTLHelperService;
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const offerHelperService = OfferHelperService;
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };

  // dialog component providers list
  const reviewOrderService = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService};
  const accountService = {provide: AccountService, useClass: MockAccountService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const directvService = {provide: DirectvService, useClass: MockDirectvService};
  const propertiesHelperService = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};

  const providers = [
    store, appStateService, logger, productService, formBuilder, systemErrorService, cTLHelperService,
    blueMarbleService, offerHelperService, helperService, disclosuresService, reviewOrderService, pendingOrderService,
    accountService, addressService, countryStateService, directvService, propertiesHelperService, disconnectService
  ];

  const baseConfig = {
    imports: imports,
    declarations: declaration,
    providers: providers
  };

  describe('NI Flow', () => {

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(CustomizeServicesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create customize service component', () => {
      expect(component).toBeTruthy();
    });

    it('should have defined and assigned selectedProduct from store', () => {
      expect(component.selectedProduct).toBeDefined();
      expect(component.selectedProduct).toEqual(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user'].currentSelected)
    });

    it('should have defined and assigned city and state from store', () => {
      expect(component.city).toBeDefined();
      expect(component.state).toBeDefined();
      expect(component.city).toEqual(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user'].orderInit.payload.serviceAddress.city)
      expect(component.state).toEqual(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user'].orderInit.payload.serviceAddress.stateOrProvince)
    });

    it('should be loding false as our component created successfully', () => {
      expect(component.loading).toBeDefined();
      expect(component.state).toBeTruthy();
    });

    it('should have defined and assigned orderRefNumber', () => {
      expect(component.orderRefNumber).toBeDefined();
      expect(component.orderRefNumber).toEqual(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user'].orderRefNumber);
    });

    it('should have defined and assigned addressListing', () => {
      expect(component.addressListing).toBeDefined();
      expect(component.addressListing).toEqual(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user'].orderInit.payload.serviceAddress);
    });

    it('should have defined and assigned catalogSpecId from store', () => {
      expect(component.catalogSpecId).toBeDefined();
      expect(component.catalogSpecId).toEqual(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['cart'].payload.cart.catalogSpecId);
    });

    it('should call ngOnInit', () => {
      component.ngOnInit();
      expect(component.customizeSubscription).toBeDefined();
      expect(component.existingObservable).toBeDefined();
      expect(component.existingSubscription).toBeDefined();
    });

    it('should call ngOnDestroy', () => {
        component.ngOnDestroy();
        expect(component.custSubscription).toBeDefined();
    });

    it('should call tabelected() internet', () => {
      component.tabSelected('INTERNET', true);
      expect(component.internetActive).toBe(true);
      expect(component.prismActive).toBe(false);
    });

    it('should call tabelected() prism', () => {
      component.tabSelected('prism', true);
      expect(component.internetActive).toBe(false);
      expect(component.prismActive).toBe(true);
    });

    xit('should call undoAll() prism', () => {
      component.undoAll();
      expect(component.refObj.isUndo).toBe(false);
      expect(component.isUndoAll).toBe(false);
    });

    it('should call cancelOrder()', () => {
      let mockRouter = TestBed.get(Router);
      spyOn(mockRouter, 'navigate');
      component.cancelOrder();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/home']);
    });

    it('calling toNextStage()', () => {
        // expect(component.dtvConfigForm).toBeDefined();
        // let taskName = component.dtvConfigForm.get('taskName');
        // let accNo = component.dtvConfigForm.get('accNo');
        // taskName.setValue('no');
        // accNo.setValue('');
        component.toNextStage();
        expect(component.loading).toBe(true);
        // expect(spy).toBeDefined();
        // expect(component.custdata.payload.cart.customerOrderItems).toBeDefined();
    });

    xit('should call toNextStage() with Error', () => {
        let data = { _body: { error: { errorMessage: "Unexpected error occured" } } };

        let productService = TestBed.get(ProductService)
        spyOn(productService, 'getResponseForCheckOut').and.returnValue(Observable.of(data));
        // let spy = spyOn(service, 'getResponseForCheckOut').and.returnValue(Observable.throw(data));
        component.toNextStage();
        expect(component.errorMsg).toBe(data._body.error.errorMessage);
    });


    xit('calling toNextStage() with Shipping...', () => {
        let req = {
            taskName: 'Shipping'
        };
        let data = mockServer.getResponseForRequest('submitTask', req);
        // let spy = spyOn(service, 'getResponseForCheckOut').and.callFake(() => {
        //     return Observable.of(data);
        // });
        component.toNextStage();
        // expect(mockRouter.navigate).toHaveBeenCalledWith(['/schedule-non-appt']);
    });

    it('should call showLifeLine function and check conditions', () => {
        component.showLifeLine();
        expect(component.lifelinePOtsRemove).toBe(false);
        expect(component.showHide).toBe(true);
        expect(component.phoneConfigObj.showHide).toBe(component.showHide);
        expect(component.lifeLineShow).toBe(true);
        expect(component.showPotsLifeline).toBe(true);
    });

    it('should call showDHPLifeLine function and check conditions', () => {
        component.showDHPLifeLine();
        expect(component.lifelinePOtsRemove).toBe(false);
        expect(component.showDHPLifeline).toBe(true);
        expect(component.lifelineShowDHP).toBe(true);
        expect(component.showHide).toBe(true);
        expect(component.phoneConfigObj.showHide).toBe(component.showHide);
    });

    it('should call lifeLineShowHide function and check conditions', () => {
        component.lifeLineShowHide();
        expect(component.lifeLineHideInternet).toBe(false);
    });


    it('should call showLifeLineInternet function and check conditions', () => {
      component.showLifeLineInternet();
      expect(component.lifelineHsiRemove).toBe(false);
      expect(component.lifeLineShowInternet).toBe(true);
      expect(component.lifeLineHideInternet).toBe(true);
    });

    it('should call dhpListingSelectedData function from child component', () => {
      let event = { name: 'Listed' };
      component.dhpListingSelectedData(event);
      expect(component.dhpListingValue).toBe(event.name);
      expect(component.errorMsg).toBe('');
    });

    it('should call potsListingSelectedData function from child component', () => {
      let event = { name: 'Non-Listed' };
      component.potsListingSelectedData(event);
      expect(component.potsListingValue).toBe(event.name);
      expect(component.errorMsg).toBe('');
    });

    it('should call functions from child component', () => {
      let validLifelineData = true;
      component.lifelineClickContinue(validLifelineData);
      expect(component.lifelineValidation).toBe(validLifelineData);

      let removePOTSLifeline = true;
      component.removeLifelineContinue(removePOTSLifeline);
      expect(component.lifelinePOtsRemove).toBe(removePOTSLifeline);

      let removeInternetLifeline = true;
      component.removeLifelineInternet(removeInternetLifeline);
      expect(component.lifelineHsiRemove).toBe(removeInternetLifeline);

      let lifelineInternetExpand = false;
      component.expandLifelineContinue(lifelineInternetExpand);
      expect(component.lifeLineShowInternet).toBe(lifelineInternetExpand);

      let lifelineDhpExpandPots = false;
      component.expandDhpLifelineContinue(lifelineDhpExpandPots);
      expect(component.showDHPLifeline).toBe(lifelineDhpExpandPots);

      component.lifelinemulproContinue(validLifelineData);
      expect(component.lifelinepotsValidation).toBe(validLifelineData);
    });

    xit('should be able to successfully run reducer data in billing-flow', () => {
        let user = mockServer.getResponseForReducerAndApi('billing-flow-user-reducer');
        let existingProducts = mockServer.getResponseForReducerAndApi('billing-flow-existingProducts-reducer');
        let customize = mockServer.getResponseForReducerAndApi('billing-flow-customize-reducer');
        let cart = mockServer.getResponseForReducerAndApi('billing-flow-cart-reducer');
        let retain = mockServer.getResponseForReducerAndApi('billing-flow-retain-reducer');
        const mockRedux: any = {
            dispatch(action) { },
            select(reducer) {
                switch (reducer) {
                    case 'user': return Observable.of(user);
                    case 'existingProducts': return Observable.of(existingProducts);
                    case 'customize': return Observable.of(customize);
                    case 'cart': return Observable.of(cart);
                    case 'retain': return Observable.of(retain);
                }
            }
        };
        // component = new CustomizeServicesComponent(logger, mockRouter, mockRedux, appstserv, service, ref, fb, systemErrorService, ctlHelperService, bm, helperService, offerHelperService, disclosuresService);
        component.ngOnInit();
        let phoneconfigData = component.phoneConfigForm.get('phoneConfigData');
        phoneconfigData.setValue({ listingForm: { selectedOption: 'Listed' }, tnForm: { task: 'portedTn', PortingNumber: '' } });
        component.toNextStage();
        expect(component.isBilling).toBe(true);
        expect(component.dtvConfigForm).toBeDefined();
    });
  });

  describe('HSI MOVE flow - changing address only', () => {
    class MockAppStateService{
      setLocationURLs() {
          return null;
      }
      getState () {
          return mockServer.getMockStore('MOVE_HSI_TILL_REVIEW_ORDER');
      }
    }
    
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return of(
              mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return of(null);
      }
    }

    const store = { provide: Store, useValue: mockRedux };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };

    const _providers = [...providers, store, appStateService];

    const _baseConfig = {...baseConfig, providers: _providers};

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(_baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(CustomizeServicesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create customize service component', () => {
      expect(component).toBeTruthy();
    });

    xit('should be able to successfully run reducer data in move-flow', () => {
      const mockRedux: any = {
          dispatch(action) { },
          select(reducer) {
              
          }
      };
      // component = new CustomizeServicesComponent(logger, mockRouter, mockRedux, appstserv, service, ref, fb, systemErrorService, ctlHelperService, bm, helperService, offerHelperService, disclosuresService);
      component.ngOnInit();
      let phoneconfigData = component.phoneConfigForm.get('phoneConfigData');
      phoneconfigData.setValue({ listingForm: { selectedOption: 'Listed' }, tnForm: { task: 'portedTn', PortingNumber: '' } });
      component.toNextStage();
      expect(component.dtvConfigForm).toBeDefined();
      expect(component.isMove).toBe(true);
    });
  });

  describe('POTS MOVE flow - changing address only', () => {
    class MockAppStateService{
      setLocationURLs() {
          return null;
      }
      getState () {
          return mockServer.getMockStore('MOVE_POTS_TILL_REVIEW_ORDER');
      }
    }
    
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("MOVE_POTS_TILL_REVIEW_ORDER")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }

    const store = { provide: Store, useValue: mockRedux };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };
    const _providers = [...providers, store, appStateService]

    const _baseConfig = {...baseConfig, providers: _providers};

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(_baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(CustomizeServicesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create customize service component', () => {
      expect(component).toBeTruthy();
    });

    xit('should hide pots products', () => {
      component.hidePots();
      expect(component.showHide).toBeFalsy();
    });
    
  });

  describe('HSI Change flow', () => {
    class MockAppStateService{
      setLocationURLs() {
          return null;
      }
      getState () {
          return mockServer.getMockStore('CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE');
      }
    }
    
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return Observable.of(
              mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
      }
    }

    class MockDisclosuresService {
      viewRccsDisclosure() {
        return of(null);
      }
    }

    const store = { provide: Store, useValue: mockRedux };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };
    const disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
    const _providers = [...providers, store, appStateService, disclosuresService];

    const _baseConfig = {...baseConfig, providers: _providers};

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(_baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(CustomizeServicesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create customize service component', () => {
      expect(component).toBeTruthy();
    });

    it('should display Rcc disclosure', () => {
      component.viewRccsDisclosure();
    });

    it('should display Rcc disclosure', () => {
      component.toContinue();
    });

  });

  describe('Error Responses from API', () => {
    class MockProductService {
      productService = new ProductService(null,null,null);
      public findObjByName(list, fieldName, fieldVal, fieldName1 = undefined,
          fieldVal1 = undefined, prefix = undefined) {
          return this.productService.findObjByName(list,fieldName,fieldVal,fieldName1,fieldVal1,prefix);
      }
      getCompatibilityRules() {
        return throwError({});
      }
      getResponseForCheckOut() {
        return throwError({});
      }
      getFreezeDropDown() {
      return throwError({}); 
      }
      getLATA() {
        return throwError({});
      }
      getCompatibilityRulesforClosers() {
        return throwError({});
      }
    }

    class MockDisclosuresService {
      viewRccsDisclosure() {
        return throwError({});
      }
    }

    const store = { provide: Store, useValue: mockRedux };
    const productService = { provide: ProductService, useClass: MockProductService };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };
    const disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
    const _providers = [...providers, store, appStateService, disclosuresService, productService];

    const _baseConfig = {...baseConfig, providers: _providers};

    beforeEach(async(() => {
      TestBed.configureTestingModule(_baseConfig)
      .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(CustomizeServicesComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create customize service component', () => {
      expect(component).toBeTruthy();
    });

    it('should not display Rcc disclosure when API returns error responses', () => {
      component.viewRccsDisclosure();
    });

    it('calling toNextStage()', () => {
      component.toNextStage();
      expect(component.loading).toBe(false);
  });

  });


});
