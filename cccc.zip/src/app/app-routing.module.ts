import { NgModule } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { Routes, RouterModule } from '@angular/router';
import { NoContentComponent } from './no-content';
import { APP_BASE_HREF } from '@angular/common';
import { PaymentGuard } from './payment.guard';
import { SecurityErrorComponent } from './common/security-error/security-error.component';

export const ROUTES: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./address/address.module').then(m => m.AddressModule)
  },
  {
    path: 'home',
    loadChildren: () =>
      import('./address/address.module').then(m => m.AddressModule)
  },
  {
    path: 'auto-login/:token',
    loadChildren: () =>
      import('./common/auto-login/auto-login.module').then(
        m => m.AutoLoginModule
      ),
    pathMatch: 'full'
  },
  {
    path: 'auto-login',
    loadChildren: () =>
      import('./common/auto-login/auto-login.module').then(
        m => m.AutoLoginModule
      )
  },
  // NI FLow
  {
    path: 'address',
    loadChildren: () =>
      import('./address/address.module').then(m => m.AddressModule)
  },
  {
    path: 'workingService',
    loadChildren: () =>
      import('./address/workingservice.module').then(m => m.WorkingServiceModule),
    canActivate: [PaymentGuard]
  },
  {
    path: 'multipleMatchAddress',
    loadChildren: () =>
      import('./address/multimatch.module').then(m => m.MultimatchModule),
    canActivate: [PaymentGuard]
  },
  {
    path: 'product-offer',
    loadChildren: () =>
      import('./product/product.module').then(m => m.ProductModule),
    canActivate: [PaymentGuard]
  },
  {
    path: 'customize-services',
    loadChildren: () =>
      import('./product/customize-services.module').then(
        m => m.CustomizeServicesModule
      ),
    canActivate: [PaymentGuard]
  },
  {
    path: 'schedule-appt',
    loadChildren: () =>
      import(
        './scheduling/schedule-appointment-component/schedule-appointment.module'
      ).then(m => m.ScheduleAppointmentModule)
  },
  {
    path: 'schedule-appt-ship',
    loadChildren: () =>
      import('./scheduling/scheduling.module').then(m => m.SchedulingModule)
  },
  {
    path: 'account',
    loadChildren: () =>
      import('./account/account.module').then(m => m.AccountModule)
  },
  {
    path: 'review-order',
    loadChildren: () =>
      import('./review-order/review-order.module').then(
        m => m.ReviewOrderModule
      )
  },
  {
    path: 'order-confirmation',
    loadChildren: () =>
      import('./review-order/review-order.module').then(
        m => m.ReviewOrderModule
      )
  },
  {
    path: 'reuse-ban-account',
    loadChildren: () =>
      import('./account/reuse-ban-account/reuse-ban-account.module').then(
        m => m.ReuseBanAccountModule
      )
  },
  // Change Flow
  {
    path: 'existing-products',
    loadChildren: () =>
      import('./existing-products/existing-products.module').then(
        m => m.ExistingProductsModule
      )
  },
  {
    path: 'offer-change',
    loadChildren: () =>
      import('./product/change-product/change-product.module').then(
        m => m.ChangeProductModule
      )
  },
  {
    path: 'change-account',
    loadChildren: () =>
      import('./account/change-account/change-account.module').then(
        m => m.ChangeAccountModule
      )
  },
  {
    path: 'co-review-order',
    loadChildren: () =>
      import('./review-order/change-order/co-review-order.module').then(
        m => m.ChangeReviewOrderModule
      )
  },
  {
    path: 'co-order-confirmation',
    loadChildren: () =>
      import('./review-order/change-order/co-review-order.module').then(
        m => m.ChangeReviewOrderModule
      )
  },
  // Move Flow
  {
    path: 'move-product',
    loadChildren: () =>
      import('./product/move-product/move-product.module').then(
        m => m.MoveProductModule
      )
  },
  {
    path: 'move-schedule-appt-ship',
    loadChildren: () =>
      import('./scheduling/move-schedule/move-scheduling.module').then(
        m => m.MoveSchedulingModule
      )
  },
  {
    path: 'move-account',
    loadChildren: () =>
      import('./account/move-account/move-account.module').then(
        m => m.MoveAccountModule
      )
  },
  {
    path: 'mo-review-order',
    loadChildren: () =>
      import('./review-order/move-order/mo-review-order.module').then(
        m => m.MoveReviewOrderModule
      )
  },
  {
    path: 'mo-order-confirmation',
    loadChildren: () =>
      import('./review-order/move-order/mo-review-order.module').then(
        m => m.MoveReviewOrderModule
      )
  },
  // PO
  {
    path: 'pending-order',
    loadChildren: () =>
      import('./pending-order/pending.module').then(m => m.PendingModule)
  },
  {
    path: 'pending-schedule-appt',
    loadChildren: () =>
      import('./scheduling/pending-order/po-scheduling.module').then(
        m => m.POSchedulingModule
      )
  },
  {
    path: 'po-review-order',
    loadChildren: () =>
      import('./review-order/pending-order/po-review-order.module').then(
        m => m.POReviewOrderModule
      )
  },
  {
    path: 'po-order-confirmation',
    loadChildren: () =>
      import('./review-order/pending-order/po-review-order.module').then(
        m => m.POReviewOrderModule
      )
  },
  // Disconnect
  {
    path: 'disconnect-schedule',
    loadChildren: () =>
      import(
        './scheduling/disconnect-schedule-component/disconnect-scheduling.module'
      ).then(m => m.DisconnectSchedulingModule)
  },
  {
    path: 'disconnect-account',
    loadChildren: () =>
      import('./account/disconnect-account/disconnect-account.module').then(
        m => m.DisconnectAccountModule
      )
  },
  {
    path: 'disconnect-review-order',
    loadChildren: () =>
      import('./review-order/disconnect-review-order.module').then(
        m => m.DisconnectReviewOrderModule
      )
  },
  {
    path: 'disconnect-confirmation',
    loadChildren: () =>
      import(
        './review-order/disconnect-confirm/disconnect-confirm.module'
      ).then(m => m.DisconnectConfirmOrderModule)
  },
  // BR
  {
    path: 'billing-product',
    loadChildren: () =>
      import('./product/billing-product/billing-product.module').then(
        m => m.BillingProductModule
      )
  },
  {
    path: 'billing-schedule-appt-ship',
    loadChildren: () =>
      import('./scheduling/billing-schedule/billing-schedule.module').then(
        m => m.BillingSchedulingModule
      )
  },
  {
    path: 'billing-review-order',
    loadChildren: () =>
      import('./review-order/billing-order/billing-review-order.module').then(
        m => m.BillingReviewOrderModule
      )
  },
  {
    path: 'br-order-confirmation',
    loadChildren: () =>
      import('./review-order/billing-order/billing-review-order.module').then(
        m => m.BillingReviewOrderModule
      )
  },

  {
    path: 'order-unhold',
    loadChildren: () =>
      import('./pending-order/order-onhold/unhold.module').then(
        m => m.OrderUnholdModule
      )
  },
  {
    path: 'order-cancelled',
    loadChildren: () =>
      import('./review-order/review-order-component/order-cancel.module').then(
        m => m.OrderCancelModule
      )
  },
  {
    path: 'cancelled-order',
    loadChildren: () =>
      import('./review-order/pending-order/cancelled-order.module').then(
        m => m.CancelledOrderModule
      )
  },
  {
    path: 'directv-account',
    loadChildren: () =>
      import('./account/directv-account/directv-account.module').then(
        m => m.DirectvAccountModule
      )
  },
  // NonPay Suspend
  {
    path: 'nonpay-suspend',
    loadChildren: () =>
      import('./non-pay-suspend/non-pay-suspend.module').then(
        m => m.NonPaySuspendModule
      )
  },
  {
    path: 'nonpay-suspend-confirmation',
    loadChildren: () =>
      import('./nonpay-confirmation/nonpay-confirmation.module').then(
        m => m.NonPaySuspendConfirmModule
      )
  },
  // Vacation  suspend
  {
    path: 'vacation-option',
    loadChildren: () =>
      import('./vacation-option/vacation-option.module').then(
        m => m.VacationOptionModule
      )
  },
  {
    path: 'vacation-schedule-appt-ship',
    loadChildren: () =>
      import('./scheduling/vacation-schedule/vacation-schedule.module').then(
        m => m.VacationScheduleModule
      )
  },
  {
    path: 'vacation-account',
    loadChildren: () =>
      import('./account/vacation-account/vacation-account.module').then(
        m => m.VacationAccountModule
      )
  },
  {
    path: 'vacation-review-order',
    loadChildren: () =>
      import('./review-order/vacation-order/vacation-review-order.module').then(
        m => m.VacationReviewOrderModule
      )
  },
  {
    path: 'vacation-order-confirmation',
    loadChildren: () =>
      import('./review-order/vacation-order/vacation-review-order.module').then(
        m => m.VacationReviewOrderModule
      )
  },
  // Vacation Restore
  {
    path: 'vacation-product-offer',
    loadChildren: () =>
      import('./product/vacation-offer/vacation-offer.module').then(
        m => m.VacationOfferModule
      )
  },
  // Stack and Amend Flow
  {
    path: 'stack-amend-product',
    loadChildren: () =>
      import('./product/stack-amend-product/stack-amend-product.module').then(
        m => m.StackAmendProductModule
      )
  },
  {
    path: 'amend-account',
    loadChildren: () =>
      import('./account/prepaidAmend-account/ppamend-account.module').then(
        m => m.AmendAccountModule
      )
  },
  // Change Responsibility
  {
    path: 'change-responsibility',
    loadChildren: () =>
      import('./change-responsibility/change-responsibility.module').then(
        m => m.ChangeResponsibilityModule
      )
  },

  { path: 'security-error', component: SecurityErrorComponent },
  { path: '**', component: NoContentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(ROUTES, { useHash: false })],
  exports: [RouterModule],
  providers: [{ provide: APP_BASE_HREF, useValue: '/eshop/customerCare/dist/' }]
})
export class AppRoutingModule { }
