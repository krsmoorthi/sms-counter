import { Component, OnInit, ViewChild } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
// import { DomSanitizer } from '@angular/platform-browser';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { ProductService } from 'app/common/service/product.service';
import { find, cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../common/logging/default-log.service';
import { AppStore } from '../common/models/appstore.model';
import { CustomerOrderItems, ShoppingCart } from '../common/models/cart.model';
import { APIErrorLists, GenericValues } from '../common/models/common.model';
import { ExistingProducts } from '../common/models/existing-products.model';
import { User } from '../common/models/user.model';
import { AppStateService } from '../common/service/app-state.service';
// import { BlueMarbleService } from '../common/service/bm.service';
import { SystemErrorService } from '../common/service/system-error.service';
// import { HelperService } from '../common/service/helper.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisclosuresRes } from 'app/common/models/disclosures.model';
import { ConfigDetails, ConfigItems, FormItems, ProductConfiguration } from '../common/models/customize-services.model';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { ServiceCategoryBasedOffers } from '../common/models/product.model';
import "rxjs/add/operator/catch";

@Component({
    selector: 'change-responsibility',
    styleUrls: ['./change-responsibility.component.scss'],
    templateUrl: './change-responsibility.component.html'
})

export class ChangeResponsibilityComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public userData: any;
    public existingProductsObservable: Observable<ExistingProducts>;
    public existingProductsSubscription: Subscription;
    public existingProducts: ExistingProducts;
    public COResp: any; // Change Of Responsibility
    public enableCORtab: boolean = false;
    public directoryListingData: any;
    public nonPupNoChargeRemoved: boolean;
    public nonPubNoChargeValue: boolean;
    public addressListing: any;
    public preselectedListing;
    public exListedAddress;
    public exFirstName;
    public exLastName;
    public exTitle1;
    public exTitle2;
    public exLineage;
    public exDesignation;
    public exStreetNrFirst;
    public exStreetNamePrefix;
    public exStreetType;
    public exStreetName;
    public exUnit;
    public exCity;
    public exState;
    public exPostCode;
    public exNickname: any;
    public otherlistingOptions: any[];
    public apiResponseError: APIErrorLists;
    public exInputData: any;
    public listedAddressSelected;
    public listedAddressOptions: any;
    public existinglistedAddressOption: any;
    public propagateChange = (_: any) => { };
    public changeRespForm: FormGroup;
    public addOnAttributes = {
        title1: '',
        title2: '',
        designation: '',
        Nickname: '',
        lineage: ''
    }
    public listingFlags = {
        showListingForm: false,
        showProvidedFlag: false,
        showNotProvidedFlag: false
    }
    public selectedListing: any;
    public exSelectedOption: any;
    public isListingDataChanged: boolean = false;
    public isDHP: boolean = false;
    public isHP: boolean = false;
    public selectedListingOption: any;
    public potsListingData: any;
    public dhpListingData: any;
    public updatedListedAddress: any;
    public selectedListedType: any;
    public refreshServiceAddress: any;
    public custSubscription: Subscription;
    public isReEntrant: boolean = false;
    public isDisclosureAllowed: boolean = true;
    public cartSubscription: Subscription;
    public loading: boolean = false;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    public selectedListedAddressOption: any;
    public potsListingValue: string = '';
    public dhpListingValue: string = '';
    public errorMsg: any;
    public exSelectedListing;
    public existingListingDirectory;
    public exSelectedListingDHP;
    public existingListingDirectoryDHP;
    public updatedListedAddressFields: any;
    public changedListedAddress;
    public listingToCart;
    public taskId: any;
    public selectedListingOptionValue: any;
    public nonpubNoChargeSelected: boolean = false;
    public mandatorySubOffers: any = [];
    public saveUpdates: any;
    public existingMRCtoCart: any = [];
    public potsIncludedCustomerOrderSubItems: any[] = [];
    public offerDisplayName: any;

    constructor(private logger: Logger,
        private router: Router,
        private fb: FormBuilder,
        private appStateService: AppStateService,
        public store: Store<AppStore>,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private productService: ProductService,
        public disclosuresService: DisclosuresService,
        public offerHelperService: OfferHelperService) {
        this.appStateService.setLocationURLs();
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.userData = data;
            if (data && data.previousUrl !== '/existing-products') {
                this.isReEntrant = true;
                this.taskId = data.taskId;
            }
            if (data && data.offerDisplayName && data.offerDisplayName !== undefined && data.offerDisplayName.outputAttribute && data.offerDisplayName.outputAttribute !== undefined) {
                if (data.offerDisplayName.outputAttribute.length === 1) {
                    if (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" || data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                        this.offerDisplayName = data.offerDisplayName.outputAttribute[0][2];
                    }
                } else if (data.offerDisplayName.outputAttribute.length > 1) {
                    if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "INTERNET")) {
                        if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "INTERNET")) {
                            this.offerDisplayName = data.offerDisplayName.outputAttribute[0][2];
                        } else if (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                            this.offerDisplayName = data.offerDisplayName.outputAttribute[1][2];
                        }
                    } else if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" || (data.offerDisplayName.outputAttribute[0][3] === "VOICE-DHP" || data.offerDisplayName.outputAttribute[0][3] === "VIDEO-DTV")) && (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" || (data.offerDisplayName.outputAttribute[1][3] === "VOICE-DHP" || data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV")) && (data.offerDisplayName.outputAttribute[0][2] !== null && data.offerDisplayName.outputAttribute[1][2] !== null)) {
                        this.offerDisplayName = ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV") || (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DHP")) ? data.offerDisplayName.outputAttribute[0][2] + ' ' + data.offerDisplayName.outputAttribute[1][2] : data.offerDisplayName.outputAttribute[1][2] + ' ' + data.offerDisplayName.outputAttribute[0][2];
                    }
                }
            }
        });
        this.existingProductsObservable = <Observable<ExistingProducts>>store.select('existingProducts');
        this.existingProductsSubscription = this.existingProductsObservable.subscribe((data) => {
            if (data !== null && data !== undefined) {
                this.existingProducts = data;
                this.COResp = data.changeRespInit;
                this.directoryListingData = this.getOptionsForDirectoryListing(this.COResp.payload.offers);
                if (this.existingProducts && this.existingProducts.existingProductsAndServices[0] && this.existingProducts.existingProductsAndServices[0].serviceAddress) {
                    this.addressListing = this.existingProducts.existingProductsAndServices[0].serviceAddress;
                }
                this.checkProductType(this.COResp.payload.offers);
                this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.existingProducts.existingProductsAndServices[0].serviceAddress });
            }
        });
        this.existingProductsSubscription.unsubscribe();
    }

    public checkProductType(data) {
        data.map((data) => {
            if (data.serviceCategory === 'VOICE-HP') {
                this.isHP = true;
            } else if (data.serviceCategory === 'VOICE-DHP') {
                this.isDHP = true;
            }
        });
    }

    public ListingDetails(item) {
        item.configDetails.map(config => {
            config.formItems.map(form => {
                if (form.attributeName === 'Listing Type') {
                    this.exSelectedOption = form.attributeValue;
                    if (this.exSelectedOption && this.exSelectedOption[0] && this.exSelectedOption[0].value) {
                        this.changeRespForm.get('listingForm.selectedOption').setValue(this.exSelectedOption[0].value);
                        this.listingDataChanged(this.exSelectedOption[0].value, false);
                    }
                }
                if (form.attributeName === 'Listed Address Option') {
                    this.exListedAddress = form.attributeValue;
                }
                if (form.attributeName === 'First Name') {
                    this.exFirstName = form.attributeValue;
                }
                if (form.attributeName === 'Last Name') {
                    this.exLastName = form.attributeValue;
                }
                if (form.attributeName === 'Title 1') {
                    this.exTitle1 = form.attributeValue[0].value;
                    this.addOnAttributes.title1 = this.exTitle1;
                }
                if (form.attributeName === 'Title 2') {
                    this.exTitle2 = form.attributeValue[0].value;
                    this.addOnAttributes.title2 = this.exTitle2;
                }
                if (form.attributeName === 'Lineage') {
                    this.exLineage = form.attributeValue[0].value;
                    this.addOnAttributes.lineage = this.exLineage;
                }
                if (form.attributeName === 'Designation') {
                    this.exDesignation = form.attributeValue[0].value;
                    this.addOnAttributes.designation = this.exDesignation;
                }
                if (form.attributeName === 'Nickname') {
                    this.exNickname = form.attributeValue[0].value;
                    this.addOnAttributes.Nickname = this.exNickname;
                }
                if (form.attributeName === 'streetNrFirst') {
                    this.exStreetNrFirst = form.attributeValue[0].value;
                }
                if (form.attributeName === 'streetNamePrefix') {
                    this.exStreetNamePrefix = form.attributeValue[0].value;
                }
                if (form.attributeName === 'streetType') {
                    this.exStreetType = form.attributeValue[0].value;
                }
                if (form.attributeName === 'streetName') {
                    this.exStreetName = form.attributeValue[0].value;
                }
                if (form.attributeName === 'Unit') {
                    this.exUnit = form.attributeValue[0].value;
                }
                if (form.attributeName === 'city') {
                    this.exCity = form.attributeValue[0].value;
                }
                if (form.attributeName === 'state') {
                    this.exState = form.attributeValue[0].value;
                }
                if (form.attributeName === 'postCode') {
                    this.exPostCode = form.attributeValue[0].value;
                }
            })
        });
        this.onSaveUpdate(this.addOnAttributes);
    }

    public ngOnInit() {
        this.logger.metrics('ChangeResponsibilityPage');
        this.changeRespForm = this.fb.group({
            'listingForm': this.fb.group({
                'selectedOption': [this.getSelectedListingOption(this.exSelectedOption, this.preselectedListing)],
                'firstName': [''],
                'lastName': [''],
                'title1': [this.exTitle1 ? this.exTitle1 : ''],
                'title2': [this.exTitle2 ? this.exTitle2 : ''],
                'lineage': [this.exLineage ? this.exLineage : ''],
                'designation': [this.exDesignation ? this.exDesignation : ''],
                'Nickname': [this.exNickname ? this.exNickname : '']
            })
        });
        this.listedAddressOptions = this.getOptionsForListedAddress(this.COResp.payload.productConfiguration[0].configItems);
        let existinglistedAddressOptions;
        if (this.COResp.payload.productConfiguration[0].configItems) {
            existinglistedAddressOptions = this.getOptionsForListedAddress(this.COResp.payload.productConfiguration[0].configItems);
        }
        this.COResp.payload.existingProductConfiguration && this.COResp.payload.existingProductConfiguration.map(exPrdConfig => {
            if (exPrdConfig.productType === 'VOICE-HP' || exPrdConfig.productType === 'VOICE-DHP') {
                this.exInputData = exPrdConfig.configItems;
            }
        })
        if (this.exInputData && this.exInputData.length > 0) {
            this.selectedListedType = existinglistedAddressOptions && existinglistedAddressOptions[0] &&
                existinglistedAddressOptions[0].value;
            this.existinglistedAddressOption = existinglistedAddressOptions && existinglistedAddressOptions[0] &&
                existinglistedAddressOptions[0].value;
            if (existinglistedAddressOptions && existinglistedAddressOptions[0] && existinglistedAddressOptions[0].value) {
                this.selectedListedAddressOption = this.listedAddressSelected
            }
        } else {
            let listedAdd: any;
            this.listedAddressOptions.map(v => {
                if (v.isDefault) {
                    return listedAdd = v;
                }
            })
            if (listedAdd) this.selectedListedType = listedAdd[0] && listedAdd[0].value;
        }

        //EX-CONFIGURATION
        let exTemp = this.exInputData;
        if (exTemp) {
            let listing = find(exTemp, (o) => {
                return o.productName.indexOf('Listing') !== -1;
            });
            if (listing && listing.configDetails !== null && listing.configDetails.length !== 0 && listing.configDetails[0].formItems && listing.configDetails[0].formItems.length > 0) {
                let listingType = find(listing.configDetails[0].formItems, (o) => o.attributeName === "Listing Type");
                if (listingType) {
                    if (this.isHP) {
                        this.exSelectedListing = listingType.attributeValue[0].value;
                    }
                    if (this.isDHP) {
                        this.exSelectedListingDHP = listingType.attributeValue[0].value;
                    }
                }
                if (this.isHP) {
                    this.existingListingDirectory = listing.configDetails[0].formItems;
                } else {
                    this.existingListingDirectoryDHP = listing.configDetails[0].formItems;
                }
            }
        }
        this.fetchListingCatalog(this.COResp.payload.offers, this.isHP ? "pots" : "dhp");
        this.existingProductMRCtoCart(this.COResp.payload.cart);

        if (!this.isReEntrant) {
            this.exInputData && this.exInputData.map(item => {
                if (item && item.productName && item.productName.indexOf('Listing') !== -1) {
                    this.ListingDetails(item);
                }
            });
        } else {
            let retainVal = <Observable<any>>this.store.select('retain');
            let retSubscribe: Subscription = retainVal.subscribe(
                (retVal => {
                    retVal && retVal.prodConfig && retVal.prodConfig.prodConfig && retVal.prodConfig.prodConfig.map((data) => {
                        data && data.configItems && data.configItems.map((item) => {
                            if (item && item.productName && item.productName.indexOf('Listing') !== -1) {
                                this.ListingDetails(item);
                            }
                        })
                    })
                })
            )
            if (retSubscribe !== undefined)
                retSubscribe.unsubscribe();
        }

        this.user = <Observable<any>>this.store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            if (this.exStreetNrFirst || this.exStreetNamePrefix || this.exStreetType || this.exStreetName || this.exUnit || this.exCity || this.exState || this.exPostCode) {
                this.addressListing = {};
                this.addressListing = {
                    'streetNrFirst': this.exStreetNrFirst ? this.exStreetNrFirst : '',
                    'streetNamePrefix': this.exStreetNamePrefix ? this.exStreetNamePrefix : '',
                    'streetName': this.exStreetName ? this.exStreetName : '',
                    'streetType': this.exStreetType ? this.exStreetType : '',
                    'unit': this.exUnit ? this.exUnit : '',
                    'city': this.exCity ? this.exCity : '',
                    'stateOrProvince': this.exState ? this.exState : '',
                    'postCode': this.exPostCode ? this.exPostCode : ''
                }
                if (this.addressListing) {
                    this.changedListedAddress = this.addressListing;
                }
            } else if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress) {
                this.addressListing = {};
            }
        });
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();

        this.changeRespForm.valueChanges.subscribe((data: any) => {
            this.propagateChange(data);
        });
        this.changeRespForm.get('listingForm.selectedOption').valueChanges.subscribe((data: any) => {
            if (data === "Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = false;
            } else if (data === "Non-Listed") {
                this.listingFlags.showListingForm = false;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = true;
            } else if (data === "Non-Published") {
                this.listingFlags.showListingForm = false;
                this.listingFlags.showNotProvidedFlag = true;
                this.listingFlags.showProvidedFlag = false;
            }
        });
        if (this.exFirstName && this.exFirstName[0] && this.exFirstName[0].value && this.isReEntrant) {
            this.changeRespForm.get('listingForm.firstName').setValue(this.exFirstName[0].value);
        }
        if (this.exLastName && this.exLastName[0] && this.exLastName[0].value && this.isReEntrant) {
            this.changeRespForm.get('listingForm.lastName').setValue(this.exLastName[0].value);
        }
    }

    public existingProductsSelected() {
        this.enableCORtab = true;
        this.store.dispatch({ type: 'COR_EXISTING_TAB', payload: this.enableCORtab });
        this.store.dispatch({ type: 'PENDING_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'DISCONNECT_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'CHANGE_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'MOVE_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'BILLING_EXISTING_TAB', payload: false });
    }
    public listedChange(type) {
        if (this.existinglistedAddressOption && this.existinglistedAddressOption !== type && this.refreshServiceAddress) {
            this.addressListing = {};
            this.addressListing = this.refreshServiceAddress;
            this.changedListedAddress = this.addressListing;
        }
        this.selectedListedType = type;
        this.selectedListedAddressOption = this.listedAddressSelected;
    }

    private getOptionsForDirectoryListing(data) {
        let optionsData: any = [];
        let otherOptionsData: any = [];
        if (data && data !== null && data !== undefined) {
            data.map((offers) => {
                if (offers.serviceCategory === 'VOICE-HP' || offers.serviceCategory === 'VOICE-DHP') {
                    let catalogs = offers.catalogs[0];
                    if (catalogs.catalogItems && catalogs.catalogItems.length > 0) {
                        catalogs.catalogItems.map((catalogItems) => {
                            if (catalogItems && catalogItems.productOffer && (catalogItems.productOffer.offerName === "Home Phone Directory Listing" || catalogItems.productOffer.offerName === "Digital Home Phone Directory Listing")) {
                                if (catalogItems.productOffer.productComponents && catalogItems.productOffer.productComponents.length > 0) {
                                    catalogItems.productOffer.productComponents.map(productComponent => {
                                        if (productComponent && productComponent.product && (productComponent.product.productName === "Home Phone Directory Listing" || productComponent.product.productName === "Digital Home Phone Directory Listing" || productComponent.product.productName === "Digital Home Phn Dir Listing")) {
                                            if (productComponent.product && productComponent.product.productAttributes) {
                                                productComponent.product.productAttributes.map((productAttr) => {
                                                    if (productAttr.compositeAttribute && productAttr.displayOrder > 0) {
                                                        productAttr.compositeAttribute.map((compositeAttr) => {
                                                            if (compositeAttr.attributeName === 'Listing Type') {
                                                                let priceData = 0;
                                                                if (productAttr.prices && productAttr.prices !== null) {
                                                                    productAttr.prices.map((price) => {
                                                                        if (price.discountedRc > 0) {
                                                                            priceData = price.discountedRc;
                                                                        }
                                                                        else if (price.rc > 0) {
                                                                            priceData = price.rc;
                                                                        }
                                                                        else if (price.discountedOtc > 0) {
                                                                            priceData = price.discountedOtc;
                                                                        }
                                                                        else if (price.otc > 0) {
                                                                            priceData = price.otc;
                                                                        }
                                                                    });
                                                                }
                                                                if (compositeAttr.attributeValue !== "Non-Pub No Charge") {
                                                                    optionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault, displayName: compositeAttr.attributeDisplayName });
                                                                } else if (this.nonPubNoChargeValue && compositeAttr.attributeValue === "Non-Pub No Charge") {
                                                                    optionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault, displayName: compositeAttr.attributeDisplayName });
                                                                }
                                                            }
                                                        });
                                                    }
                                                    else if (productAttr.compositeAttribute && productAttr.displayOrder === 0) {
                                                        productAttr.compositeAttribute.map((compositeAttr) => {
                                                            if (compositeAttr.attributeName === 'Listing Change') {
                                                                let priceData = 0;
                                                                if (productAttr.prices && productAttr.prices !== null) {
                                                                    productAttr.prices.map((price) => {
                                                                        if (price.discountedOtc > 0) {
                                                                            priceData = price.discountedOtc;
                                                                        }
                                                                        else if (price.otc > 0) {
                                                                            priceData = price.otc;
                                                                        }
                                                                    });
                                                                }
                                                                if (productAttr.isDefault) {

                                                                }
                                                                optionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault });
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        } else if (productComponent.product && productComponent.product.productAttributes) {
                                            productComponent.product.productAttributes.map((productAttr) => {
                                                productAttr && productAttr.compositeAttribute && productAttr.compositeAttribute.map((compositeAttr) => {
                                                    if (compositeAttr.attributeName === 'Listing Change') {
                                                        let priceData = 0;
                                                        if (productAttr.prices && productAttr.prices !== null) {
                                                            productAttr.prices.map((price) => {
                                                                if (price.discountedOtc > 0) {
                                                                    priceData = price.discountedOtc;
                                                                }
                                                                else if (price.otc > 0) {
                                                                    priceData = price.otc;
                                                                }
                                                            });
                                                        }
                                                        otherOptionsData.push({ name: compositeAttr.attributeValue, price: priceData, isDefault: productAttr.isDefault });
                                                    }
                                                })
                                            })
                                        }
                                    })
                                }
                            }
                        });
                    }
                }
            })
        }
        this.otherlistingOptions = otherOptionsData;
        return optionsData;
    }

    public listingDataChanged(event, val?) {
        this.isListingDataChanged = val;
        const value = event;
        let flagOTC = false;
        if (val) {
            this.selectedListingOptionValue = value;
            if (this.nonpubNoChargeSelected) {
                this.nonpubNoChargeSelected = true;
            }
            if (value.indexOf("Non-Pub No Charge") === -1) {
                this.nonPubNoChargeValue = false;
                if (this.directoryListingData.length > 0) {
                    for (let i = 0; i < this.directoryListingData.length; i++) {
                        if (this.directoryListingData[i].name === "Non-Pub No Charge") {
                            this.directoryListingData.splice(i, 1);
                        }
                    }
                }
            }
        }
        if (value && this.directoryListingData) {
            this.directoryListingData.map(v => {
                if (value.indexOf(v.name) !== -1) {
                    this.selectedListing = v;
                }
            });
            if (this.exSelectedOption && this.selectedListing && this.exSelectedOption[0].value !== this.selectedListing) {
                let changedToListing = [];
                if (this.exSelectedOption[0].value === 'Listed') {
                    if (this.selectedListing && this.selectedListing.name === 'Non-Listed') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Listed';
                        })
                    } else if (this.selectedListing && this.selectedListing.name === 'Non-Published') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Published';
                        })
                    }
                } else if (this.exSelectedOption[0].value === 'Non-Listed') {
                    if (this.selectedListing.name === 'Listed') {
                        this.clearListingOTC();
                    } else if (this.selectedListing && this.selectedListing.name === 'Non-Published') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Published';
                        })
                    }
                } else if (this.exSelectedOption[0].value === 'Non-Published') {
                    if (this.selectedListing && this.selectedListing.name === 'Listed') {
                        this.clearListingOTC();
                    } else if (this.selectedListing.name === 'Non-Listed') {
                        changedToListing = this.otherlistingOptions.filter(val => {
                            return val.name === 'ChangeToNon-Listed';
                        })
                    }
                }
                this.directoryListingOTCToCart(changedToListing[0], this.isHP ? 'HP ADDON OFFER' : 'DHP ADDON OFFER');
                flagOTC = true;
            }
            else {
                this.clearListingOTC();
            }
            if (this.isDHP) {
                this.dhpListingData = this.selectedListing;
                this.dhpListingValue = this.selectedListing.name;
            } else {
                this.potsListingData = this.selectedListing;
                this.potsListingValue = this.selectedListing.name;
            }
            this.directoryListingToCart(this.selectedListing, this.isHP ? true : false);
            if (this.selectedListing && this.selectedListing.name === "Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = false;
            } else if (this.selectedListing && this.selectedListing.name === "Non-Listed") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = false;
                this.listingFlags.showProvidedFlag = true;
            } else if (this.selectedListing && this.selectedListing.name === "Non-Published") {
                this.listingFlags.showListingForm = true;
                this.listingFlags.showNotProvidedFlag = true;
                this.listingFlags.showProvidedFlag = false;
            }
        }
    }

    private directoryListingOTCToCart(data, type) {
        if (data) {
            let productType = type;
            let deliveryToCart = {
                productId: '',
                name: data.name,
                productType: productType,
                isRegulated: '',
                prices:
                    [
                        {
                            discountedRc: 0,
                            discountedOtc: data.price,
                            otc: data.price,
                            rc: 0
                        }
                    ]
            };
            this.store.dispatch({ type: 'UPDATE_LISTING_ADDON', payload: deliveryToCart });
        }
        else {
            this.clearListingOTC();
        }
    }

    public clearListingOTC() {
        let deliveryToCart = {
            productId: '',
            name: '',
            productType: this.isHP ? 'HP ADDON OFFER' : 'DHP ADDON OFFER',
            isRegulated: '',
            prices:
                [
                    {
                        discountedRc: 0,
                        discountedOtc: 0,
                        otc: 0,
                        rc: 0
                    }
                ]
        };
        this.store.dispatch({ type: 'UPDATE_LISTING_ADDON', payload: deliveryToCart });
    }

    public onSaveUpdate(data) {
        this.saveUpdates = data;
        this.changeRespForm.get('listingForm.title1').setValue(data.title1);
        this.changeRespForm.get('listingForm.title2').setValue(data.title2);
        this.changeRespForm.get('listingForm.lineage').setValue(data.lineage);
        this.changeRespForm.get('listingForm.designation').setValue(data.designation);
        this.changeRespForm.get('listingForm.Nickname').setValue(data.Nickname);
    }

    private getSelectedListingOption(exItem, preItem) {
        if (exItem && exItem[0].value) {
            this.selectedListing = exItem[0];
            return exItem[0].value;
        } else if (preItem) {
            return preItem;
        } else if (this.directoryListingData && this.directoryListingData.length > 0) {
            this.directoryListingData.map(option => {
                if (option.isDefault === 1) {
                    this.preselectedListing = option.name;
                    this.listingDataChanged(this.preselectedListing, false);
                }
            })
            return this.preselectedListing;
        }
    }
    public onListedUpdate(updatedAddress) {
        this.updatedListedAddress = updatedAddress;
        this.updatedListedAddressFields = updatedAddress;
    }

    private getOptionsForListedAddress(configItems) {
        let options = [];
        configItems && configItems.some(item => {
            if (item.productName.indexOf('Listing') !== -1) {
                item.configDetails && item.configDetails[0].formItems && item.configDetails[0].formItems.map(formItem => {
                    if (formItem.attributeName.toLowerCase().indexOf('listed address') !== -1) {
                        options = formItem.attributeValue;
                    }
                })
            }
        })
        return options;
    }

    public toContinue() {
        this.isDisclosureAllowed = false;
        if (this.isDisclosureAllowed) {
            this.viewRccsDisclosure();
        } else {
            this.toNextStage();
        }
    }

    /** Continue button to scheduling page */
    public toNextStage() {
        this.loading = true;
        let custDataPayload: any = this.COResp.payload;
        let changeRespData = this.changeRespForm.value;
        let phoneCategory = this.isHP ? GenericValues.cHP : GenericValues.cDHP;
        let listing: any;
        let indexNo = 0;
        let productConfig = [];
        let prodStruc: ProductConfiguration[] = [];
        let prodConfData: ProductConfiguration[] = [];
        //Addons to be added in Cart on Click Continue
        let item: CustomerOrderItems[] = [];
        prodStruc = cloneDeep(custDataPayload.productConfiguration);
        prodStruc && prodStruc.map(struct => {
            let confItemList: ConfigItems[] = [];
            struct && struct.configItems && struct.configItems.map(confItem => {
                let confDetList: ConfigDetails[] = [];
                confItem && confItem.configDetails && confItem.configDetails.map(confDet => {
                    let formItemList: FormItems[] = [];
                    confDet && confDet.formItems && confDet.formItems.map(formItem => {
                        formItemList.push({
                            attributeName: formItem.attributeName,
                            attributeType: formItem.attributeType,
                            attributeValue: formItem.attributeValue,
                            isMandatory: formItem.isMandatory
                        })
                    })
                    confDetList.push({
                        formItems: formItemList,
                        formName: confDet.formName,
                        isConfigRequired: confDet.isConfigRequired
                    })
                })
                confItemList.push({
                    configDetails: confDetList,
                    productId: confItem.productId,
                    productName: confItem.productName
                })
            })
            prodConfData.push({
                productType: struct.productType,
                configItems: confItemList
            })
        })
        productConfig[indexNo] = cloneDeep(find(prodConfData, (o) => {
            return o.productType === phoneCategory;
        }));
        if (!productConfig[indexNo] || productConfig[indexNo] === null) productConfig = [];
        if (productConfig && productConfig.length !== 0 && productConfig[indexNo]) {
            productConfig[indexNo].configItems = [];
        }
        if (this.isDHP || this.isHP) {
            let temp = find(prodConfData, (o) => {
                return o.productType === phoneCategory;
            });
            if (temp && temp.configItems !== null && temp.configItems.length > 0) {
                let form: any;
                if (this.isDHP) {
                    form = find(temp.configItems, (o) => {
                        return o.productName === 'Digital Home Phn Dir Listing';
                    });
                } else if (this.isHP) {
                    form = find(temp.configItems, (o) => {
                        return o.productName === 'Home Phone Directory Listing';
                    });
                }
                let dhpForm: any;
                if (form && form.configDetails) {
                    dhpForm = find(form.configDetails, (o) => {
                        return o.formName === 'Listing';
                    });
                }
                if (dhpForm && dhpForm.formItems && dhpForm.formItems.length > 0) {
                    if (this.selectedListedAddressOption && this.selectedListedAddressOption === 'List Community Only') {
                        dhpForm.formItems = dhpForm.formItems.filter((v, i) => {
                            if (v.attributeName !== 'streetNrFirst' && v.attributeName !== "streetNamePrefix" && v.attributeName !== "streetType" && v.attributeName !== "streetName" && v.attributeName !== "Unit") {
                                return dhpForm.formItems[i];
                            }
                        });
                    }
                    for (let i = 0; i < dhpForm.formItems.length; i++) {
                        if (dhpForm.formItems[i].attributeName === "First Name") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.firstName;
                        } else if (dhpForm.formItems[i].attributeName === "Last Name") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.lastName;
                        }
                        else if (dhpForm.formItems[i].attributeName === "Listing Type") {
                            let value = dhpForm.formItems[i].attributeValue[0];
                            dhpForm.formItems[i].attributeValue = [];
                            dhpForm.formItems[i].attributeValue[0] = value;
                            if (form.productName === 'Home Phone Directory Listing') {
                                dhpForm.formItems[i].attributeValue[0].value = this.potsListingValue;
                            }
                            else {
                                dhpForm.formItems[i].attributeValue[0].value = this.dhpListingValue;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName.toLowerCase().indexOf("listed address") !== -1) {
                            if (this.selectedListedAddressOption) {
                                dhpForm.formItems[i].attributeValue = dhpForm.formItems[i].attributeValue.filter(v => {
                                    if (v.value === this.selectedListedAddressOption) {
                                        return v;
                                    }
                                });
                            }
                            else {
                                dhpForm.formItems[i].attributeValue = dhpForm.formItems[i].attributeValue.filter(v => {
                                    if (v.isDefault) {
                                        return v;
                                    }
                                });
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "streetNrFirst") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNrFirst !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetNrFirst;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.streetNrFirst) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetNrFirst;
                            }
                            else if (this.addressListing) {
                                dhpForm.formItems[i].attributeValue[0].value = this.addressListing.streetNrFirst;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "streetNamePrefix") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNamePrefix !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetNamePrefix;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.streetNamePrefix) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetNamePrefix;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "streetType") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetType !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetType;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.streetType) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetType;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "streetName") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetName !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.streetName;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.streetName) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.streetName;
                            }
                            else if (this.addressListing) {
                                dhpForm.formItems[i].attributeValue[0].value = this.addressListing.streetName;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "Unit") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.unit !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.unit;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.unit) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.unit;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "city") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.city !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.city;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.city) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.city;
                            }
                            else if (this.addressListing) {
                                dhpForm.formItems[i].attributeValue[0].value = this.addressListing.city;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "state") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.state !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.state;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.stateOrProvince) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.stateOrProvince;
                            }
                            else if (this.addressListing) {
                                dhpForm.formItems[i].attributeValue[0].value = this.addressListing.stateOrProvince;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "postCode") {
                            if (this.updatedListedAddressFields && this.updatedListedAddressFields.postCode !== undefined) {
                                dhpForm.formItems[i].attributeValue[0].value = this.updatedListedAddressFields.postCode;
                            }
                            else if (this.changedListedAddress && this.changedListedAddress.postCode) {
                                dhpForm.formItems[i].attributeValue[0].value = this.changedListedAddress.postCode;
                            }
                            else if (this.addressListing) {
                                dhpForm.formItems[i].attributeValue[0].value = this.addressListing.postCode;
                            }
                        }
                        else if (dhpForm.formItems[i].attributeName === "Title 1") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.title1;
                        }
                        else if (dhpForm.formItems[i].attributeName === "Title 2") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.title2;
                        }
                        else if (dhpForm.formItems[i].attributeName === "Lineage") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.lineage;
                        }
                        else if (dhpForm.formItems[i].attributeName === "Designation") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.designation;
                        }
                        else if (dhpForm.formItems[i].attributeName === "Nickname") {
                            dhpForm.formItems[i].attributeValue[0].value = changeRespData.listingForm.Nickname;
                        }
                    }
                    form.configDetails = [];
                    form.configDetails[0] = dhpForm;
                    listing = form;
                }
            }
        }
        if (this.isDHP) {
            if(listing) { productConfig[indexNo].configItems.push(listing); }
        }
        if (this.isHP) {
            if(listing) { productConfig[indexNo].configItems.push(listing); }
            let value;
            let temp = find(prodConfData, (o) => {
                return o.productType === phoneCategory;
            });
            let form = find(temp.configItems, (o) => {
                return o.productName === 'Directory Listing';
            });
            if (form && form.configDetails && form.configDetails !== null && form.configDetails.length !== 0 && form.configDetails[0]
                && form.configDetails[0].formItems !== null && form.configDetails[0].formItems.length !== 0) {
                for (let i = 0; i < form.configDetails[0].formItems.length; i++) {
                    if (form.configDetails[0].formItems[i].attributeName === 'Title 1') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = changeRespData.listingForm.title1;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Title 2') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = changeRespData.listingForm.title2;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Lineage') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = changeRespData.listingForm.lineage;
                    } else if (form.configDetails[0].formItems[i].attributeName === 'Designation') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = changeRespData.listingForm.designation;
                    }
                    else if (form.configDetails[0].formItems[i].attributeName === 'Nickname') {
                        value = form.configDetails[0].formItems[i].attributeValue[0];
                        form.configDetails[0].formItems[i].attributeValue = [];
                        form.configDetails[0].formItems[i].attributeValue[0] = value;
                        form.configDetails[0].formItems[i].attributeValue[0].value = changeRespData.listingForm.Nickname;
                    }
                }
            }
            if(form) { productConfig[indexNo].configItems.push(form); }
        }
        if (this.potsListingValue) {
            let action = '';
            if (this.exSelectedListing && this.exSelectedListing === this.potsListingValue) {
                if (this.existingListingDirectory) {
                    let isChanged = this.isDirecoryChanged(changeRespData);
                    if (isChanged) {
                        action = 'CHANGE'
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                    } else {
                        action = 'NOCHANGE';
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems.splice(1, 1);
                        }
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                    }
                }
            } else if (this.exSelectedListing && this.exSelectedListing !== this.potsListingValue) {
                action = 'CHANGE';
                if (this.exSelectedListing === 'Listed') {
                    if (this.potsListingValue === 'Non-Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Listed");
                        }
                    } else if (this.potsListingValue === 'Non-Published') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    } else if (this.potsListingValue === 'Non-Pub No Charge') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                } else if (this.exSelectedListing === 'Non-Listed') {
                    if (this.potsListingValue === 'Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Published') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    } else if (this.potsListingValue === 'Non-Pub No Charge') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                }
                else if (this.exSelectedListing === 'Non-Published') {
                    if (this.potsListingValue === 'Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Listed");
                        }
                    } else if (this.potsListingValue === 'Non-Pub No Charge') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                } else if (this.exSelectedListing === 'Non-Pub No Charge') {
                    if (this.potsListingValue === 'Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ListingDataChange");
                        }
                    }
                    else if (this.potsListingValue === 'Non-Published') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    } else if (this.potsListingValue === 'Non-Listed') {
                        this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
                        if (this.listingToCart.customerOrderSubItems[1]) {
                            this.listingToCart.customerOrderSubItems[1].productAttributes = this.listingSelectionChange("ChangeToNon-Published");
                        }
                    }
                }
            }
            else {
                action = 'ADD';
                if (this.listingToCart.customerOrderSubItems[1]) {
                    this.listingToCart.customerOrderSubItems.splice(1, 1);
                }
                this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.potsListingValue);
            }
            this.listingToCart.action = action;
            if (this.listingToCart.customerOrderSubItems[1]) {
                this.listingToCart.customerOrderSubItems[1].action = 'ADD';
            }
            if (this.potsListingValue === 'Non-Pub No Charge') {
                let isChanged = this.isDirecoryChanged(changeRespData);
                if (!isChanged && this.listingToCart.customerOrderSubItems[1]) this.listingToCart.customerOrderSubItems.splice(1, 1);
            }
            this.listingToCart.customerOrderSubItems[0].action = action;
            if (this.listingToCart && this.listingToCart.customerOrderSubItems && this.listingToCart.customerOrderSubItems.length > 0) {
                this.listingToCart.customerOrderSubItems.map(sub => {
                    if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                })
            }
            item.push(this.listingToCart);
        }
        else if (this.dhpListingValue) {
            let action = '';
            if (this.exSelectedListingDHP && this.exSelectedListingDHP === this.dhpListingValue) {
                if (this.existingListingDirectoryDHP) {
                    let isChanged = this.existingListingDirectoryDHP.some(item => {
                        if (item.attributeName === 'First Name' && item.attributeValue[0].value !== changeRespData.listingForm.firstName) {
                            return true;
                        } else if (item.attributeName === 'Last Name' && item.attributeValue[0].value !== changeRespData.listingForm.lastName) {
                            return true;
                        }
                    });
                    if (isChanged) {
                        action = 'CHANGE'
                    } else {
                        action = 'NOCHANGE';
                    }
                }
            } else if (this.exSelectedListingDHP && this.exSelectedListingDHP !== this.dhpListingValue) {
                action = 'CHANGE';
            } else {
                action = 'ADD';
            }
            this.listingToCart.customerOrderSubItems[0].productAttributes = this.listingSelection(this.dhpListingValue);
            this.errorMsg = '';
            this.listingToCart.action = action;
            this.listingToCart.customerOrderSubItems[0].action = action;
            if (this.listingToCart && this.listingToCart.customerOrderSubItems && this.listingToCart.customerOrderSubItems.length > 0) {
                this.listingToCart.customerOrderSubItems.map(sub => {
                    if (sub.productCategoryDisplayName || sub.productCategoryDisplayName === null) delete sub.productCategoryDisplayName;
                })
            }
            item.push(this.listingToCart);
        }
        this.COResp.payload.cart.customerOrderItems.map(cusOrdrItems => {
            if (cusOrdrItems && cusOrdrItems.offerName && cusOrdrItems.offerName !== null) {
                if (cusOrdrItems.offerName.indexOf('Listing') === -1) {
                    item.push(cusOrdrItems);
                }
            }
        });
        this.errorMsg = '';
        if (this.mandatorySubOffers && this.mandatorySubOffers.length > 0) {
            item.push(this.mandatorySubOffers[0]);
        }
        let additionalAttr = this.COResp.payload.addlOrderAttributes;
        let apiRequest: any = {
            orderRefNumber: this.COResp.orderRefNumber,
            processInstanceId: this.COResp.processInstanceId,
            taskId: this.isReEntrant ? this.taskId : this.COResp.taskId,
            taskName: this.COResp.taskName,
            payload: {
                cart: {
                    catalogSpecId: custDataPayload.cart.catalogSpecId ? custDataPayload.cart.catalogSpecId : '39',
                    customerOrderItems: item
                },
                productConfiguration: productConfig,
                addlOrderAttributes: additionalAttr
            }
        };
        this.store.dispatch({ type: 'PRODUCT_CONFIG', payload: { prodConfig: apiRequest.payload.productConfiguration } });
        this.logger.startTime();
        this.logger.log("info", "change-responsibility.component.ts", "getResponseForCheckOutRequest", JSON.stringify(apiRequest));
        this.logger.startTime();
        this.productService.getResponseForCheckOut(apiRequest, "COR")
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "change-responsibility.component.ts", "getResponseForCheckOutResponse", error);
                this.logger.log("error", "change-responsibility.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "change-responsibility.component.ts", "Change Responsibility Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "change-responsibility.component.ts", "getResponseForCheckOutResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "change-responsibility.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: data });
                    this.router.navigate(['/schedule-appt-ship']);
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "change-responsibility.component.ts", "getResponseForCheckOutResponse", error);
                    this.logger.log("error", "change-responsibility.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", this.COResp.taskName, "change-responsibility.component.ts", "Add-Ons Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.COResp.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", this.COResp.taskName, "change-responsibility.component.ts", "Add-Ons Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    /** Get Disclosure Request and Response */
    public viewRccsDisclosure() {
        let cart1 = <Observable<ShoppingCart>>this.store.select('cart');
        let cartDetails;
        this.cartSubscription = cart1.subscribe((data) => {
            if (data && data.payload && data.payload.cart) {
                cartDetails = data.payload.cart;
            }
        });
        this.loading = true;
        let request = {
            orderRefNumber: this.COResp.orderRefNumber,
            rccGroupId: "CUSTOMIZED_SERVICES",
            salesChannel: "ESHOP - Customer Care",
            versionNumber: "",
            cart: this.COResp.payload.cart
        }
        // request = this.addGiftcard(request,true);
        let errorResolved = false;
        this.logger.log("info", "change-responsibility.component.ts", "retrieveRccDisclosuresRequest", JSON.stringify(request));
        this.logger.startTime();
        this.disclosuresService.viewRccsDisclosure(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "change-responsibility.component.ts", "retrieveRccDisclosuresResponse", error);
                this.logger.log("error", "change-responsibility.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.toNextStage();
                return Observable.throwError(null);
            })
            .subscribe(
                (data: DisclosuresRes) => {
                    this.logger.endTime();
                    this.logger.log("info", "change-responsibility.component.ts", "retrieveRccDisclosuresResponse", JSON.stringify(data));
                    this.logger.log("info", "change-responsibility.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data && data.rccGroup && data.rccGroup.length > 0) {
                        this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: data });
                        this.orderDisclosures.open();
                    } else {
                        this.toNextStage();
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "change-responsibility.component.ts", "retrieveRccDisclosuresResponse", error);
                    this.logger.log("error", "change-responsibility.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    if(!errorResolved) {
                        this.toNextStage();
                        this.loading = false;
                    }
                })
    }

    public potsListingSelectedData(event) {
        if (event && event.name) {
            this.potsListingValue = event.name;
            this.errorMsg = '';
            this.directoryListingToCart(event, true);
        } else if (event === "Non-Pub No Charge") {
            this.potsListingValue = event;
            this.errorMsg = '';
            this.directoryListingToCart(event, true);
        }
    }
    public dhpListingSelectedData(event) {
        if (event && event.name) {
            this.dhpListingValue = event.name;
            this.errorMsg = '';
            this.directoryListingToCart(event, false);
        }
    }
    private directoryListingToCart(data, isHp) {
        let productType = isHp ? 'HP ADDON OFFER' : 'DHP ADDON OFFER';
        let deliveryToCart = {
            productId: '',
            name: data.name,
            productType: productType,
            isRegulated: '',
            prices:
                [
                    {
                        discountedRc: data.price,
                        discountedOtc: 0,
                        otc: 0,
                        rc: data.price
                    }
                ]
        };
        this.store.dispatch({ type: 'UPDATE_SHIPPING_ADDON', payload: deliveryToCart });
    }

    private listingSelection(listingValue) {
        let tempArray = [];
        this.listingToCart.customerOrderSubItems[0].productAttributes.map((v, i) => {
            if (v.compositeAttribute && v.compositeAttribute.length > 0) {
                return v.compositeAttribute.map((comp, index) => {
                    if (comp.attributeName !== 'Listing Type' || (comp.attributeName === 'Listing Type' && comp.attributeValue === listingValue)) {
                        tempArray.push(v);
                    }
                })
            }
        });
        return tempArray;
    }

    private listingSelectionChange(listingValue) {
        let tempArray = [];
        this.listingToCart.customerOrderSubItems[1].productAttributes.map((v, i) => {
            if (v.compositeAttribute && v.compositeAttribute.length > 0) {
                return v.compositeAttribute.map((comp, index) => {
                    if (comp.attributeName !== 'Listing Change' || (comp.attributeName === 'Listing Change' && comp.attributeValue === listingValue)) {
                        tempArray.push(v);
                    }
                })
            }
        });
        return tempArray;
    }

    private isDirecoryChanged(phoneconfigData: any) {
        return this.existingListingDirectory && this.existingListingDirectory !== undefined && this.existingListingDirectory.some(item => {
            if (item.attributeName === 'First Name' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.firstName.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Last Name' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.lastName.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Listed Address Option' && (item.attributeValue[0].value.toUpperCase()) !== (this.selectedListedAddressOption && this.selectedListedAddressOption.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Title 1' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.title1.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Title 2' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.title2.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Lineage' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.lineage.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Designation' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.designation.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'Nickname' && (item.attributeValue[0].value.toUpperCase()) !== (phoneconfigData.listingForm.Nickname.toUpperCase())) {
                return true;
            }
            else if (item.attributeName === 'streetNrFirst') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNrFirst && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetNrFirst.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetNrFirst && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetNrFirst.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'streetNamePrefix') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetNamePrefix && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetNamePrefix.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetNamePrefix && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetNamePrefix.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'streetType') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetType && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetType.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetType && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetType.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'streetName') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.streetName && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.streetName.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.streetName && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.streetName.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'Unit') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.unit && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.unit.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.unit && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.unit.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'city') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.city && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.city.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.city && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.city.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'state') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.state && (item.attributeValue[0].value.toUpperCase()) !== (this.updatedListedAddressFields.state.toUpperCase())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.stateOrProvince && (item.attributeValue[0].value.toUpperCase()) !== (this.changedListedAddress.stateOrProvince.toUpperCase())) {
                    return true;
                }
            }
            else if (item.attributeName === 'postCode') {
                if (this.updatedListedAddressFields && this.updatedListedAddressFields.postCode && (item.attributeValue[0].value.trim()) !== (this.updatedListedAddressFields.postCode.trim())) {
                    return true;
                }
                else if (this.changedListedAddress && this.changedListedAddress.postCode && (item.attributeValue[0].value.trim()) !== (this.changedListedAddress.postCode.trim())) {
                    return true;
                }
            }
        });
    }

    private fetchListingCatalog(addonOffers: ServiceCategoryBasedOffers[], product) {
        addonOffers.forEach(addonOffers => {
            addonOffers.catalogs[0].catalogItems.forEach(item => {
                if (item.productOffer && item.productOffer.offerName.indexOf('Listing') !== -1 && (product === 'pots' || product === 'dhp')) {
                    let qtty;
                    let customerOrderSubItems: any[] = [];
                    if (item && item.productOffer && item.productOffer.productComponents && item.productOffer.productComponents.length > 0) {
                        let listingComp = cloneDeep(item);
                        listingComp.productOffer.productComponents.forEach(comp => {
                            delete comp.product.productDisplayName;
                            delete comp.product.isRegulated;
                            if (comp && comp.product && comp.product.quantity) {
                                qtty = comp.product.quantity.defaultQuantity ? comp.product.quantity.defaultQuantity : comp.product.quantity.minQuantity;
                                comp.product.quantity = qtty;
                            }
                            if (product === 'pots' && comp && comp.product && comp.product.productName && comp.product.productName === 'Home Phone Directory Listing') {
                                item.productOffer.productComponents = [];
                                item.productOffer.productComponents[0] = comp;
                                customerOrderSubItems.push(comp.product);
                            }
                            if (product === 'dhp') {
                                customerOrderSubItems.push(comp.product);
                            }
                        })
                        listingComp.productOffer.productComponents.forEach(comp => {
                            if (product === 'pots' && comp && comp.product && comp.product.productName && comp.product.productName !== 'Home Phone Directory Listing') {
                                if (comp.product.productName.toUpperCase() === 'Home Phone Directory Listing Change'.toUpperCase()) {
                                    delete comp.product.productDisplayName;
                                    delete comp.product.isRegulated;
                                    item.productOffer.productComponents.push(comp);
                                    customerOrderSubItems.push(comp.product);
                                }
                            }
                        })
                        if (item.productOffer.productComponents[0] && item.productOffer.productComponents[0].product &&
                            item.productOffer.productComponents[0].product.quantity) {
                            qtty = item.productOffer.productComponents[0].product.quantity.defaultQuantity ? item.productOffer.productComponents[0].product.quantity.defaultQuantity : item.productOffer.productComponents[0].product.quantity.minQuantity;
                            item.productOffer.productComponents[0].product.quantity = qtty;
                        }
                    }
                    item.productOffer.productComponents[0].product.action = 'NOCHANGE';
                    item.productOffer.productComponents[0].product.componentType = 'COMPONENT';
                    delete item.productOffer.productComponents[0].product.productDisplayName;
                    delete item.productOffer.productComponents[0].product.isRegulated;
                    this.listingToCart = {
                        "catalogId": addonOffers.catalogs[0].catalogId,
                        "contractTerm": item.productOffer.contract.contractTerm,
                        "productOfferingId": item.productOfferingId,
                        "offerType": item.productOffer.offerType,
                        "offerSubType": item.productOffer.offerSubType,
                        "offerCategory": item.productOffer.offerCategory,
                        "quantity": qtty ? qtty : null,
                        "rc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.rc : 0,
                        "otc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.otc : 0,
                        "discountedRc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedRc : 0,
                        "discountedOtc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedOtc : 0,
                        "customerOrderSubItems": customerOrderSubItems,
                        action: 'NOCHANGE',
                        offerName: item.productOffer.offerName
                    }
                } else if (item && item.productOffer && item.productOffer.productComponents && item.productOffer.offerName.indexOf("Transfer of Responsibility") !== -1) {
                    item.productOffer.productComponents.forEach(prodComp => {
                        let qtty = prodComp.product.quantity && prodComp.product.quantity.defaultQuantity ? prodComp.product.quantity.defaultQuantity :
                            prodComp.product.quantity && prodComp.product.quantity.minQuantity && prodComp.product.quantity.minQuantity;
                        prodComp.product.quantity = qtty;
                        prodComp.product.action = 'ADD';
                        prodComp.product.componentType = 'COMPONENT';
                        delete prodComp.product.productDisplayName;
                        delete prodComp.product.isRegulated;
                        delete prodComp.product.productCategoryDisplayName;
                        this.mandatorySubOffers.push({
                            "catalogId": addonOffers.catalogs[0].catalogId,
                            "contractTerm": item.productOffer.contract.contractTerm,
                            "productOfferingId": item.productOfferingId,
                            "offerType": item.productOffer.offerType,
                            "offerSubType": item.productOffer.offerSubType,
                            "offerCategory": item.productOffer.offerCategory,
                            "quantity": qtty,
                            "rc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.rc : 0,
                            "otc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.otc : 0,
                            "discountedRc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedRc : 0,
                            "discountedOtc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedOtc : 0,
                            "customerOrderSubItems": [prodComp.product],
                            action: 'ADD',
                            offerName: item.productOffer.offerName
                        })
                    })
                } else if (item && item.productOffer && item.productOffer.productComponents &&
                    item.productOffer.offerType === 'P4L' && item.productOffer.offerCategory === 'VOICE-HP') {
                    let subOrderItem;
                    if (item.productOffer.productComponents.length > 0) {
                        let listingComp = cloneDeep(item);
                        listingComp.productOffer.productComponents.forEach(comp => {
                            if (product === 'pots' && comp && comp.isDefault === 0 && comp.isMandatory) {
                                subOrderItem = this.offerHelperService.getDHPComponents(comp);
                                if (subOrderItem.componentType !== 'PRIMARY')
                                    this.potsIncludedCustomerOrderSubItems.push(subOrderItem.productName);
                            }
                        })
                    }
                }
            })
        });
    }

    public existingProductMRCtoCart(cart) {
        let lcart = cloneDeep(cart);
        lcart.customerOrderItems.map(items => {
            if (items.offerType !== "SUBOFFER") {
                if (items.offerCategory === "VOICE-HP" && items.offerType === "P4L") {
                    items.offerDisplayName = this.offerDisplayName;
                    items.customerOrderSubItems.map(custOrdrSubItms => {
                        if (this.potsIncludedCustomerOrderSubItems.indexOf(custOrdrSubItms.productName) !== -1) {
                            custOrdrSubItms.dontShow = true;
                        }
                    })
                } else if (items.offerCategory === "INTERNET" || items.offerCategory === "DATA") {
                    items.offerDisplayName = this.offerDisplayName;
                } else if (items.offerCategory === "VOICE-DHP") {
                    items.offerDisplayName = this.offerDisplayName;
                } else {
                    items.offerDisplayName = this.offerDisplayName;
                }
                this.existingMRCtoCart.push(items);
            }
        });
        if (this.mandatorySubOffers && this.mandatorySubOffers.length > 0) {
            this.existingMRCtoCart.push(this.mandatorySubOffers[0]);
        }
        let CORcartRequest: any = {
            orderRefNumber: this.COResp.orderRefNumber,
            processInstanceId: this.COResp.processInstanceId,
            taskId: this.isReEntrant ? this.taskId : this.COResp.taskId,
            taskName: this.COResp.taskName,
            payload: {
                cart: {
                    customerOrderItems: this.existingMRCtoCart
                }
            }
        }
        this.store.dispatch({ type: 'CREATE_CART', payload: CORcartRequest });
    }
}
