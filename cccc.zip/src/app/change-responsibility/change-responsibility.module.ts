import { NgModule } from '@angular/core';
import { ChangeResponsibilityComponent } from './change-responsibility.component';
// tslint:disable-next-line:no-unused-variable
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
    { path: '', component: ChangeResponsibilityComponent }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        SharedModule,
        SharedCommonModule
    ],
    exports: [
        ChangeResponsibilityComponent
    ],
    declarations: [
        ChangeResponsibilityComponent
    ],
    providers: []
})

export class ChangeResponsibilityModule { }
