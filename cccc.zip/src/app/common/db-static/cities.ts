/**
 * https://raw.githubusercontent.com/David-Haim/CountriesToCitiesJSON/master/countriesToCities.json
 * 
 *  above link is used to get city 
 */

export const CITIES = [
  
];