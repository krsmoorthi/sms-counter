import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'myCustomFilter'
})

export class CustomPipe implements PipeTransform {
    public transform(value: any[], pipeName, category?: string, subCategory?:string) {
        if (!value) {
            return null;
        } else if (pipeName === 'Remark') {
            return value.filter((val) => val.name === category);
        } else if (pipeName === 'BillFilter') {
            return value.filter((val) => val.billAmount > 0);
        } else if (pipeName === 'ChargeType') {
            return value.filter((val) => val.chargeType === category);
        } else if (pipeName === 'blockHeader') {
            return value.filter((val) => val.blockHeader.indexOf(category) !== -1);
            //&& val.blockTitle.indexOf(subCategory) !== -1
        } else if (pipeName === 'keyValue') {
            let keys = [];
            for (let key in value) {
                if (value.hasOwnProperty(key)) {
                    keys.push({key, value: value[key]});
                }
            }
            return keys;
        }
    }
}
