import { TestBed } from '@angular/core/testing';
import { SortByPipe } from './sortby.pipe';
import { AlphabetizePipe } from './alphabetize.pipe';

describe('AlphabetizePipe', () => {
  let alphabetizePipe: AlphabetizePipe;

  beforeEach((() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      declarations: [AlphabetizePipe],
      providers: [
        AlphabetizePipe
      ]
    })
    .compileComponents();
    alphabetizePipe = TestBed.get(AlphabetizePipe);
  }));

  it('create an instance', () => {
    expect(alphabetizePipe).toBeTruthy();
  });

  it('calling transform', () => {
    const returnVal = alphabetizePipe.transform(['B', 'A']);
    expect(returnVal).toEqual(['A', 'B']);
  });

});
