import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'firstCapCustom'
})

export class FirstCustomizePipe implements PipeTransform {
    public transform(value) {
        if(value) {
            let arrayOfString = value.split(" ");
            if ( arrayOfString[0] === 'QWEST') {
                arrayOfString[0] = arrayOfString[0].toLowerCase();
                arrayOfString[0] = arrayOfString[0].charAt(0).toUpperCase()+arrayOfString[0].slice(1);
                return arrayOfString[0];
            }
            for( let i=0;i < arrayOfString.length;i++ ){
                arrayOfString[i] = arrayOfString[i].toLowerCase();
                arrayOfString[i] = arrayOfString[i].charAt(0).toUpperCase()+arrayOfString[i].slice(1);
            }
            return arrayOfString.join(' ');
        } else {
            return '';
        }
    }
}
