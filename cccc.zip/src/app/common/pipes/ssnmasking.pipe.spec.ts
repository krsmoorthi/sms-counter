import { TestBed } from '@angular/core/testing';
import { MaskSsnPipe } from './ssnmasking.pipe';

describe('MaskSsnPipe', () => {
  let maskSsnPipe: MaskSsnPipe;

  beforeEach((() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      declarations: [MaskSsnPipe],
      providers: [
        MaskSsnPipe
      ]
    })
    .compileComponents();
    maskSsnPipe = TestBed.get(MaskSsnPipe);
  }));

  it('create an instance', () => {
    expect(maskSsnPipe).toBeTruthy();
  });

  it('calling transform', () => {
    const returnVal = maskSsnPipe.transform('66665684');
    expect(returnVal).toBe('xxx-xx-5684');
  });

});
