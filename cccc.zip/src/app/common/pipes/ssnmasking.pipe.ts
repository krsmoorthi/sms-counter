import { Pipe, PipeTransform } from '@angular/core';
@Pipe({name: 'maskSsn'})
export class MaskSsnPipe implements PipeTransform {
 public transform(value: string): string {
    if(value && value !== undefined) {
      return  'xxx-xx-'+value.substr(value.length-4);
    }
  }
}
