import { TestBed } from '@angular/core/testing';
import { SortByPipe } from './sortby.pipe';

describe('SortByPipe', () => {
  let sortbyPipe: SortByPipe;

  beforeEach((() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      declarations: [SortByPipe],
      providers: [
        SortByPipe
      ]
    })
    .compileComponents();
    sortbyPipe = TestBed.get(SortByPipe);
  }));

  it('create an instance', () => {
    expect(sortbyPipe).toBeTruthy();
  });

  it('calling transform', () => {
    const returnVal = sortbyPipe.transform([] , 'displayOrder');
    expect(returnVal).toEqual([]);
  });

});
