import { SSNPipe } from './ssn.pipe';
import { TestBed } from '@angular/core/testing';

describe('SSNPipe', () => {
  let ssnPipe: SSNPipe;

  beforeEach((() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      declarations: [SSNPipe],
      providers: [
        SSNPipe
      ]
    })
    .compileComponents();
    ssnPipe = TestBed.get(SSNPipe);
  }));

  it('create an instance', () => {
    expect(ssnPipe).toBeTruthy();
  });

  it('calling transform', () => {
    const returnVal = ssnPipe.transform(66665684);
    expect(returnVal).toBe('666-65-684');
  });

});
