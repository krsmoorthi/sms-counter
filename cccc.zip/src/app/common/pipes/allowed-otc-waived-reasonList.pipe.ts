import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'allowedOtcWaivedReasons'
})

export class allowedOtcWaivedReasonListPipe implements PipeTransform {
    public transform(reasonList : any) {
        const allowedList = ['AJ0402', 'AJ0400', 'AJ0407'];
        return reasonList.filter(function(reason) { return  allowedList.indexOf(reason.code) !== -1});
    }
}