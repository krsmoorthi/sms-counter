import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'myCurrency'
})
export class CurrencyPipe implements PipeTransform {
    public transform(value: any) {
        let val = value && value.toString(); 
        if(val) {
            val = val.replace('(', '-');
            val = val.replace(')','');
            return val === '$NaN' ?  0.00 : val;
        }
    }
}