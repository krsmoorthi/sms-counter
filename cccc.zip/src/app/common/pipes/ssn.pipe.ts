import { Pipe, PipeTransform } from '@angular/core';

@Pipe ({ name: 'ssnFilter' })
export class SSNPipe implements PipeTransform {
    public transform(value: number) {
        if (value){
            let val = value.toString().replace(/\D/g, "")
            let len = val.length
            if (len < 4)
                return val
            else if (len > 3 && len < 6){
                return val.substr(0, 3)+'-'+val.substr(3)
            }
            else if (len > 5)
                return val.substr(0, 3)+'-'+val.substr(3, 2)+'-'+val.substr(5, 4)
        }
    }
}
