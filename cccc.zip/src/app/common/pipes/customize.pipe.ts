import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'myQuantity'
})

export class CustomizePipe implements PipeTransform {
    public transform(value) {
        return (new Array(value)).fill(1);
    }
}
