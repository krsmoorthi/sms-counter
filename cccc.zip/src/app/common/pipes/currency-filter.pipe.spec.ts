import { TestBed } from '@angular/core/testing';
import { CurrencyPipe } from '@angular/common';

describe('allowedOtcWaivedReasonListPipe', () => {
  let currencyPipe: CurrencyPipe;

  beforeEach((() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      declarations: [CurrencyPipe],
      providers: [
        CurrencyPipe
      ]
    })
    .compileComponents();
    currencyPipe = TestBed.get(CurrencyPipe);
  }));

  it('create an instance', () => {
    expect(currencyPipe).toBeTruthy();
  });

  it('calling transform', () => {
    const returnVal = currencyPipe.transform((20.00));
    expect(returnVal).toEqual('$20.00');
  });

});
