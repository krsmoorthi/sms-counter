import { TestBed } from '@angular/core/testing';
import { allowedOtcWaivedReasonListPipe } from './allowed-otc-waived-reasonList.pipe';

describe('allowedOtcWaivedReasonListPipe', () => {
  let allowedOtcWaivedReasonListPi: allowedOtcWaivedReasonListPipe;

  beforeEach((() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      declarations: [allowedOtcWaivedReasonListPipe],
      providers: [
        allowedOtcWaivedReasonListPipe
      ]
    })
    .compileComponents();
    allowedOtcWaivedReasonListPi = TestBed.get(allowedOtcWaivedReasonListPipe);
  }));

  it('create an instance', () => {
    expect(allowedOtcWaivedReasonListPipe).toBeTruthy();
  });

  it('calling transform', () => {
    const returnVal = allowedOtcWaivedReasonListPi.transform([]);
    expect(returnVal).toEqual([]);
  });

});
