import { MockServer } from './../../MockServer.test';
import { Pipe, PipeTransform } from '@angular/core';
import { CustomPipe } from './custom-filter.pipe';

describe('Pipe: customFilter', () => {
    let pipe: CustomPipe;
    let mockServer = new MockServer();
    let order = mockServer.getResponseForRequest('submitTask', {taskName : 'Payments'});
    let billObj = mockServer.getResponseForRequest('submitTask', {taskName : 'billEstimate'});
    let sampleArray = order.payload.orderSummary.notes.remarks;

    let filteredArray = sampleArray.filter((sample) =>
        sample.name === 'Driving Directions');
    let sampleArrayBill = [];
    sampleArrayBill.push(billObj.month[0].charges[0].details[0].primaryService);
    sampleArrayBill.push(billObj.month[0].charges[1].details[0].primaryService);

    let filteredArrayBill = sampleArrayBill.filter((bill) =>
        bill.billAmount > 0);

    let sampleObject: any = billObj.month[0].charges[0].details[0].primaryService[0].taxes;

    let sampleArrayCharge = billObj.month[0].charges;

    let filteredRC = sampleArrayCharge.filter((sample) =>
        sample.chargeType === 'RC');
    let filteredOTC = sampleArrayCharge.filter((sample) =>
        sample.chargeType === 'OTC');

    beforeEach(() => {
        pipe = new CustomPipe();
    });

    it('Fetch remark text only for the matched categoy ', () => {
    expect(pipe.transform(sampleArray, 'Remark', 'Driving Directions')).toEqual(filteredArray);
    });

    it('Fetch Product only if Bill Amount is greater than zero', () => {
    expect(pipe.transform(sampleArrayBill, 'BillFilter')).toEqual(filteredArrayBill);
    });

    it('Fetch RC Charges from bill ', () => {
    expect(pipe.transform(sampleArrayCharge, 'ChargeType', 'RC')).toEqual(filteredRC);
    });

    it('Able to Iterate on key value pair', () => {
    expect(pipe.transform(sampleObject, 'keyValue').length).toBe(3);
    });

    it('Checking Else Case', () => {
        pipe.transform(sampleObject, '');
    });
    it('Do not fail for empty case', () => {
    expect(pipe.transform(null, '')).toBeNull;
    });
});
