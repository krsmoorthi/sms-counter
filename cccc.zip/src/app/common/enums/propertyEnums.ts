export enum PropertyEnums {
    ALLOW_APP_DYNAMICS = "allow-app-dynamics",
    ALLOW_CLICKTALE = "allow-clicktale",
    ALLOW_EXPIRED_OFFERS = "allow-expired-offers",
    ALLOW_STACK_ORDERS = "allow-stack-orders",
    ALLOW_TECH_DROP_MODEMS = "allow-tech-drop-modems",
    ALLOW_TN_RESILIENCY = "allow-tn-resiliency",
    ALLOW_NONPAY_DISCONNECT = "allow-nonpay-disconnect",
    ALLOW_UPDATE_PROFILE = "allow-update-profile",
    ALLOW_WAIVE_OTC = "allow-waive-otc",
    ALLOW_INTERTERITORY_MOVE = "allow-interteritory-move",
    ENABLE_GLOBAL_ERROR_HANDLER = "enable-global-error-handler",
    BILL_QUOTE_MAX_RETRIES = "bill-quote-max-retries",
    BILL_QUOTE_WAIT_TIME = "bill-quote-wait-time",
    ALLOW_BYPASS_LOOPQUAL_FOR_LQ = "allow-bypass-loopqal-for-lq",
    ALLOW_AMEND_ON_HSI = "allow-hsi-amend",
    ALLOW_WLI_LQ = "allow-WLI-LQ"
}

export class PropertyConstants {
    // DO NOT REMOVE
    // This class must be here for ENUMS to work Globally
    // DO NOT REMOVE
}

