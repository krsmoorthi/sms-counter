import { ActionReducer } from '@ngrx/store';
import { User } from '../models/user.model';
import { CustomAction } from 'app/CustomAction';

export function securityErrorReducer(state: any = [], action: CustomAction): ActionReducer<User> {
  switch (action.type) {
    case 'SECURITY_ERROR':
      return Object.assign({}, state, { securityError : action.payload });
    
    default:
      return state;
  }
};