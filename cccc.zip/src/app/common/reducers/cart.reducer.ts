import { ActionReducer } from '@ngrx/store';
import { ShoppingCart } from '../models/cart.model';
import { CustomAction } from 'app/CustomAction';

export function cartReducer(state: any = [], action: CustomAction): ActionReducer<ShoppingCart> {
        switch (action.type) {
            case 'CREATE_CART':
                return Object.assign({}, state, action.payload);
            case 'FLUSH_CART':
                return Object.assign({}, state, { payload: action.payload, terminationFee: [] });
            case 'UPDATE_ADDON':
                return Object.assign({}, state, {
                    payload: Object.assign({}, state.payload, {
                        customerAddonOfferItems: [...action.payload]
                    })
                });
            case 'UPDATE_SHIPPING_ADDON':
                return Object.assign({}, state, {
                    payload: Object.assign({}, state.payload, {
                        shipping: action.payload
                    })
                });
            case 'UPDATE_LISTING_ADDON':
                return Object.assign({}, state, {
                    payload: Object.assign({}, state.payload, {
                        listing: action.payload
                    })
                });

            case 'CLOSERS_PROMOS':
                return Object.assign({}, state, {
                    payload: Object.assign({}, state.payload, {
                        discountItems: [...action.payload]
                    })
                });
            case 'CLOSERS_PROMOS_RECOMMENDATION':
            return Object.assign({}, state, { recommendedDiscounts: action.payload });

            case 'DATE_PICKER_ALLOWED_MONTH':
                return Object.assign({}, state, { Allowed_date: action.payload });
            
            case 'CART_MAX_SPEED':
                return Object.assign({}, state, { maxSpeed : action.payload }); 
            case 'STORE_RETRIVEOFFERS':
                return Object.assign({}, state, action.payload);
            case 'VACATION_CART':
                return Object.assign({}, state, { vacationCart: action.payload });
            case 'LEASED_DISPLAY_NAME':
                return Object.assign({}, state, { leasedModemDisplayName: action.payload });
            case 'WAIVED_OTC_INFO':
                return Object.assign({}, state, { waivedOtcInfo: action.payload })    
            default:
                return state;
        }
    };