import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function orderReducer(state: any = [], action: CustomAction): ActionReducer<any>  {
        switch (action.type) {
            case 'REVIEW_ORDER':
                return Object.assign({}, state, action.payload);
            case 'ACCOUNTPASSWORD_PIN':
                return Object.assign({}, state, { Accountpasswordpin: action.payload });
            case 'CONFIRM_ORDER':
                return Object.assign({}, state, action.payload);
            case 'SUBMITTED_ORDER':
                return Object.assign({}, state, action.payload);
            case 'HOLD_ORDER':
                return Object.assign({}, state, action.payload);
            case 'PAYMENT_DATA':
                return Object.assign({}, state, { paymentdepositdata: action.payload });
            case 'EFFECTIVE_DUE_DATE':
                return Object.assign({}, state, { effectivebilldate: action.payload });
            case 'RCC_DETAILS':
                return Object.assign({}, state, { rccDetails: action.payload });
            case 'PROD_DEALER_ID':
                return Object.assign({}, state, { productSalesIdInfo: action.payload });
            case 'TN_CHARGE_NEED_TO_REMOVE':
                return Object.assign({}, state, { tnChargeNotReq: action.payload });
            case 'Prepaid_LoginDetails':
                return Object.assign({}, state, { loginDetails : action.payload});
            case 'EXPIRED_OFFERID':
                return Object.assign({}, state, { offerId: action.payload }); 
            case 'SELECTED_EXPIRED_OFFER':
                    return Object.assign({}, state, { selectedExpiredOffer: action.payload });                 
            default:
                return state;
        }
    };