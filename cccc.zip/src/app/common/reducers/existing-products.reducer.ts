import { ActionReducer } from "@ngrx/store";
import { CustomAction } from 'app/CustomAction';

export function existingProductsReducer(state: any = [], action: CustomAction): ActionReducer<any> {
        switch (action.type) {
            case 'EXISTING_PRODUCTS':
                return Object.assign({}, state, action.payload);
            case 'CHANGE_ORDER_INIT':
                return Object.assign({}, state, { orderInit: action.payload });
            case 'EXISTING_DISCOUNTS':
                return Object.assign({}, state, { existingDiscounts: action.payload });
            case 'ORDER_FlOW':
                return Object.assign({}, state, { orderFlow: action.payload });
            case 'EXISTING_TN':
                return Object.assign({}, state, { existingTN: action.payload });
            case 'CHANGE_EXISTING_TAB':
                return Object.assign({}, state, { enablechangetab: action.payload });
            case 'MOVE_EXISTING_TAB':
                return Object.assign({}, state, { enablemovetab: action.payload });
            case 'BILLING_EXISTING_TAB':
                return Object.assign({}, state, { enablebillingtab: action.payload });
            case 'DISCONNECT_EXISTING_TAB':
                return Object.assign({}, state, { enabledisctab: action.payload });
            case 'PENDING_EXISTING_TAB':
                return Object.assign({}, state, { enablependingtab: action.payload });
            case 'NONSUSPEND_EXISTING_TAB':
                return Object.assign({}, state, { enableNonSuspendTab: action.payload });
            case 'NEW_REFFERRAL_PRICE':
                return Object.assign({}, state, { newReferralPriceArray: action.payload });
            case 'CHANGE_UPDATE_USER':
                return Object.assign({}, state, action.payload);
            case 'DEPOSIT_INFO':
                return Object.assign({}, state, { depositInfo: action.payload });
            case 'NON-PAY-SUSPEND_INIT_RES':
                return Object.assign({}, state, { nonPayInitRes: action.payload });
            case 'NON-PAY-SUSPEND_SUBMIT_RES':
                return Object.assign({}, state, { nonPaySuspendProductsReq: action.payload });
            case 'NON-PAY-SUSPEND_RES':
                return Object.assign({}, state, { nonPaySuspendProductsSubmitres: action.payload });
            case 'NON-PAY-RESTOREALL':
                return Object.assign({}, state, { restoreallproducts: action.payload });
            case 'LDBLOCK_SELECTED_CARRIERS':
                return Object.assign({}, state, { ldBlockSelectedCArriers: action.payload });
            case 'NON-PAY-SUSPEND_LD_RES':
                return Object.assign({}, state, { nonpaySuspendLdRes: action.payload });
            case 'NON_PAY_LD_REQUEST':
                return Object.assign({}, state, { nonpayLdRequest: action.payload });
            case 'NON_PAY_LD_CARRIER_LIST':
                return Object.assign({}, state, { nonpayLdcarrierlistInitRes: action.payload });
            case 'NON_PAY_RESTORELD_CARRIER_LIST':
                return Object.assign({}, state, { nonpayRestoredCarriers: action.payload });
            case 'NON_PAY_NON_RESTORELD_CARRIER_LIST':
                return Object.assign({}, state, { nonpayNonSelectedRestoredCarriers: action.payload });
            case 'STACK_AMEND':
                return Object.assign({}, state, { stackamend: action.payload });
            case 'UPDATE_AMEND_ALLOWED':
                return Object.assign({}, state, {
                    stackamend: Object.assign({}, state.stackamend, {
                        isAmendAllowed: action.payload
                    })
                });
            case 'PENDING_ADDRESS':
                return Object.assign({}, state, { pendingAddress: action.payload });
            case 'PENDING_ORDERS':
                return Object.assign({}, state, { pendingOrders: action.payload });
            case 'SHOW_STACKED_ORDER':
                return Object.assign({}, state, action.payload);
            case 'POTS_ACTIONTYPE':
                return Object.assign({}, state, { potsActionType: action.payload });
            case 'EXISTING_OFFER_NAME':
                return Object.assign({}, state, { existingOfferName: action.payload });
            case 'CHANGE_RESP_INIT':
                return Object.assign({}, state, { changeRespInit: action.payload });
            case 'COR_EXISTING_TAB':
                return Object.assign({}, state, { enableCORtab: action.payload });
            case 'SUP3_ALLOWED_CON':
                return Object.assign({}, state, { sup3AllowedOnCon: action.payload }); 
            case 'NI_PENDING_STACK_AMEND':
                return Object.assign({}, state, { NIPendingStackAmend: action.payload });
            case 'EXPIRED_OFFERID':
                return Object.assign({}, state, { offerId: action.payload });   
            default:
                return state;
        }
    };
