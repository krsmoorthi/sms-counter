import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function changeReducer(state: any = [], action: CustomAction): ActionReducer<any> {
  switch (action.type) {
    // case 'CANCEL_ORDER':
    //   return Object.assign({}, state, action.payload);
    // case 'DUE_DATE_SCHEDULE':
    //   return Object.assign({}, state, action.payload);
    // case 'CANCELLED_ORDER':
    //   return Object.assign({}, state, action.payload);
    // case 'PENDING_SUMMARY':
    //   return Object.assign({}, state, action.payload);
    // case 'CONFIRM_SCHEDULE':
    //   return Object.assign({}, state, action.payload);
    case 'SUBMITTED_ORDER':
      return Object.assign({}, state, action.payload);
    default:
      return state;
  }
};