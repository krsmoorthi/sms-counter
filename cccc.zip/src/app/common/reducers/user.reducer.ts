import { ActionReducer } from '@ngrx/store';
import { User } from '../models/user.model';
import { CustomAction } from 'app/CustomAction';
const initialState: any = {
    id: 0,
    email: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    companyName: '',
    paymentDone: false,
    freezePage: false
};

export function userReducer(state: any = [], action: CustomAction): ActionReducer<User> {
    switch (action.type) {
        case 'CREATE_USER':
            return Object.assign({}, state, action.payload);
        case 'UPDATE_USER':
            return Object.assign({}, state, action.payload);
        case 'DELETE_USER':
            return initialState;
        case 'INIT_USER':
            return initialState;
        case 'UPDATE_CART_DETAILS':
            return Object.assign({}, state, action.payload);
        case 'ADD_USER_TOKEN':
            return Object.assign({}, state, action.payload);
        case 'ADD_JWT_TOKEN':
            return Object.assign({}, state, action.payload);
        case 'PREVIOUS_URL':
            return Object.assign({}, state, { previousUrl: action.payload });
        case 'CURRENT_URL':
            return Object.assign({}, state, { currentUrl: action.payload });
        case 'ADD_ORDER_INIT':
            return Object.assign({}, state, { orderInit: action.payload });
        case 'ENTERED_ADDRESS':
            return Object.assign({}, state, { enteredAddress: action.payload });
        case 'FINAL_ADDRESS':
            return Object.assign({}, state, { finalAddress: action.payload });
        case 'CALL_REFERRAL':
            return Object.assign({}, state, { isDisconnectLandLineSelected: action.payload });
        case 'ADD_YELLOW':
            return Object.assign({}, state, { yellowAddress: action.payload });
        case 'UPDATE_CHECK_DETAILS':
            return Object.assign({}, state, action.payload);
        case 'ADD_FINGERPRINT':
            return Object.assign({}, state, action.payload);
        case 'TASK_ID':
            return Object.assign({}, state, { taskId: action.payload });
        case 'ISRENTRANT':
            return Object.assign({}, state, { reEntrant: action.payload });
        case 'FREEZEACC':
            return Object.assign({}, state, { paymentDone: action.payload });
        case 'FREEZEPAGE':
            return Object.assign({}, state, { freezePage: action.payload });
        case 'CC_DONE':
            return Object.assign({}, state, { ccDone: action.payload });
        case 'TASK_NAME':
            return Object.assign({}, state, { taskName: action.payload });
        case 'BAN':
            return Object.assign({}, state, { ban: action.payload });
        case 'SELF_INSTALL_SELECTED':
            return Object.assign({}, state, { selfinstallselected: action.payload });
        case 'E911_ADDRESS_REQUEST':
            return Object.assign({}, state, { e911AddressRequest: action.payload });
        case 'FETCH_OFFER_DISNAME':
            return Object.assign({}, state, { offerDisplayName: action.payload });
        case 'ADD_ORDER_REF_NO':
            return Object.assign({}, state, { orderRefNumber: action.payload });
        case 'UPDATE_USER_FROM_ACCOUNT_PAGE':
            return Object.assign({}, state, { ...state, firstName: action.payload.firstName, lastName: action.payload.lastName, phoneNumber: action.payload.phoneNumber, emailAddress: action.payload.emailAddress });
        case 'CALLER_DOB_AND_SSN':
            return Object.assign({}, state, { creditCheckData: action.payload });
        case 'TECH_INSTALL_SELECTED':
            return Object.assign({}, state, { techInstallselected: action.payload });
        case 'PAYMENT_STATUS':
            return Object.assign({}, state, { paymentStatusChk: action.payload });
        case 'CHANGE_ADDRESS_DEPOSIT':
            return Object.assign({}, state, { depositAddress: action.payload });
        case 'ORDER_DISCLOSERS':
            return Object.assign({}, state, { orderDisclosers: action.payload });
        case 'EXISTS_SERVICES':
            return Object.assign({}, state, { existsServices: action.payload });
        case 'PREPAID_FLAG':
            return Object.assign({}, state, { prepaidFlag: action.payload });
        case 'SHOW_REFUND_FLAG':
            return Object.assign({}, state, { showRefundBanner: action.payload });
        case 'PROCESSINSTANCEID':
            return Object.assign({}, state, { processInstanceId: action.payload });
        case 'LOGICAL_SYSTEM_DATE':
            return Object.assign({}, state, { logicalSystemDate: action.payload });
        case 'WORKING_SERVICE_INFO':
            return Object.assign({}, state, { workingServiceInfo: action.payload });
        case 'LOCATION_AVAILABLE':
            return Object.assign({}, state, { locationAvailable: action.payload });
        default:
            return state;
    }
};