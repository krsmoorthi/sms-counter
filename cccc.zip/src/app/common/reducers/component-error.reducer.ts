import { ActionReducer } from "@ngrx/store";
import { CustomAction } from 'app/CustomAction';

export function componentErrorReducer(
  state: any = [],
  action: CustomAction
): ActionReducer<any> {
  switch (action.type) {
    case "COMPONENT_ERROR":
      return Object.assign({}, state, { componentError: action.payload });
    default:
      return state;
  }
}
