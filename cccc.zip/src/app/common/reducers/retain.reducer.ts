import { ActionReducer } from "@ngrx/store";
import { CustomAction } from 'app/CustomAction';

export function retainReducer(state: any = [], action: CustomAction): ActionReducer<any> {
        switch (action.type) {
            case 'SELECT_PRODUCT':
                return Object.assign({}, state, { selectProduct: action.payload });
            case 'ADD-ONS':
                return Object.assign({}, state, { addOns: action.payload });
            case 'ADD-ONS_POTS':
                return Object.assign({}, state, { potsBooleans: action.payload });
            case 'ADD-ONS_E911':
                return Object.assign({}, state, { e911ValidatedAddress: action.payload });
            case 'SCHEDULING':
                return Object.assign({}, state, { scheduling: action.payload });
            case 'VACATION_SCHEDULE_RESPONSE':
                return Object.assign({}, state, { vacationscheduleresponse: action.payload });
            case 'VACATIONSCHEDULING':
                return Object.assign({}, state, { vacationscheduling: action.payload });
            case 'RETAINSCHEDULING':
                return Object.assign({}, state, { retainscheduling: action.payload });
            case 'RETAIN_OFFERS':
                return Object.assign({}, state, { retainoffers: action.payload });
            case 'SCHEDULE_DISCONNECT':
                return Object.assign({}, state, { reentrantscheduling: action.payload });
            case 'RETAIN_EARLIEST_APPT':
                return Object.assign({}, state, action.payload);
            case 'MONTHSELECTED':
                return Object.assign({}, state, { monthSelected: action.payload });
            case 'ACCOUNT':
                return Object.assign({}, state, { account: action.payload });
            case 'REENTRANT':
                return Object.assign({}, state, { reentrant: action.payload });
            case 'ORDERNUM':
                return Object.assign({}, state, { ordernum: action.payload });
            case 'REVIEW':
                return Object.assign({}, state, { review: action.payload });
            case 'SUBMIT':
                return Object.assign({}, state, { submit: action.payload });
            case 'ORDER-SUMMARY':
                return Object.assign({}, state, { orderSummary: action.payload });
            case 'DISPLAY_TEXT':
                return Object.assign({}, state, { displayText: action.payload });
            case 'OTCINFO':
                return Object.assign({}, state, { otcinfo: action });
            case 'VALIDATE_ADDRESS':
                return Object.assign({}, state, action.payload);
            case 'VALIDATED_ADDR':
                return Object.assign({}, state, action.payload);
            case 'VALIDATED_BILLING_ADDR':
                return Object.assign({}, state, { billingValidatedAdddress: action.payload });
            case 'POTS_OFFER':
                return Object.assign({}, state, { potsOffer: action.payload });
            case 'REMOVAL_REASON':
                return Object.assign({}, state, { removeReason: action.payload });
            case 'COMPATIBILITY_RULES':
                return Object.assign({}, state, { compatibility: action.payload });
            case 'POTS_REMOVED':
                return Object.assign({}, state, { potsRemoved: action.payload });
            case 'TN_CHANGED':
                return Object.assign({}, state, { tnChanged: action.payload });
            case 'PRODUCT_CONFIG':
                return Object.assign({}, state, { prodConfig: action.payload });
            case 'DISCON_REASON':
                return Object.assign({}, state, { disconnectReason: action.payload });
            case 'SCHEDULE_REQUEST':
                return Object.assign({}, state, { scheduleReq: action.payload });
            case 'DTV_ACCOUNT_ID':
                return Object.assign({}, state, { dtvaccountid: action.payload });
            case 'IS_REENTRENT':
                return Object.assign({}, state, { isreenterent: action.payload });
            case 'REMOVED_OFFERS':
                return Object.assign({}, state, { removedOffers: action.payload });
            case 'REMOVED_ACCTNAME':
                return Object.assign({}, state, { removedAccNmae: action.payload });
            case 'ACCOUNT_REENTRANT':
                return Object.assign({}, state, { accountreentrant: action.payload });
            case 'ACCOUNT_ISPREPAID':
                return Object.assign({}, state, { isPrepaidAccountPage: action.payload });
            case 'MOVE_ACCOUNT_REENTRANT':
                return Object.assign({}, state, { moveaccountreentrant: action.payload });
            case 'SELECTED_APPOINTMENT':
                return Object.assign({}, state, { selectedappointment: action.payload });
            case 'DTV_INIT':
                return Object.assign({}, state, { dtvLocations: action.payload });
            case 'CAPTURE_DTV_REQUEST':
                return Object.assign({}, state, { dtvSessionInfo: action.payload });
            case 'RETRIEVE_DTV_ORDER':
                return Object.assign({}, state, { dtvOrderInfo: action.payload });
            case 'GIFT_COMPATIBILITY_RULES':
                return Object.assign({}, state, { gcardcompatibility: action.payload });
            case 'UPDATE_APPLICATION_COUNT':
                return Object.assign({}, state, { maxCreditCheckReached: action.payload });
            case 'RETAIN_RESERVED_APPOINTMENT':
                return Object.assign({}, state, { retainReservedAppointment: action.payload });
            case 'ON_HOLD_FLOW_ACCOUNT_INFORMATION_PAYLOAD':
                return Object.assign({}, state, { accInformationPayload: action.payload });
            case 'RETAIN_FREEZE':
                return Object.assign({}, state, { retainedFreezeData: action.payload });
            case 'DTV_REMOVED':
                return Object.assign({}, state, { removedDTV: action.payload });
            case 'DTV_ACCOUNT_INFO':
                return Object.assign({}, state, { dtvAccountInfo: action.payload });
            case 'INSTALL_AVAIL':
                return Object.assign({}, state, { isInstallmentAvail: action.payload });
            case 'BYPASS-VALUE':
                return Object.assign({}, state, { bypassvalue: action.payload });
            case 'BYPASSED-VALUE':
                return Object.assign({}, state, { bypassedvalue: action.payload });
            case 'ACCOUNT_PAGE_REENTRANT':
                return Object.assign({}, state, { accountPageReEntrant: action.payload });
            case 'RETAIN_INSTALL_OPTION':
                return Object.assign({}, state, { retainInstallOption: action.payload });
            case 'RETAIN_VOICE_MAIL':
                return Object.assign({}, state, { retainVoiceMail: action.payload });
            case 'RETAIN_DISC':
                return Object.assign({}, state, { retainDisc: action.payload });
            case 'CHANGE_RESPONSIBILITY_APPROVAL':
                return Object.assign({}, state, { cResponsibility: action.payload });
            case 'BYPASS_DISCOUNT_CHECK':
                return Object.assign({}, state, { isBypassedDiscount: action.payload });
            case 'BYPASSED_INTERNET_DISCOUNTS':
                return Object.assign({}, state, {internetDiscounts: action.payload});
            case 'MOVE_SCHEDULING_REQUEST':
                return Object.assign({}, state, { moveSchedulingReq: action.payload });
            case 'IS_CONVERTED':
                return Object.assign({}, state, { isConverted: action.payload });
            default:
                return state;
        }
    };
