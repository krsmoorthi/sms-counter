import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function appointmentReducer(state: any = [], action: CustomAction): ActionReducer<any> {
  switch (action.type) {
    case 'AVAILABLE_APPOINTMENTS':
      return Object.assign({}, state, action.payload);
       
    case 'VACATION_AVAILABLE_APPOINTMENTS':
       return Object.assign({}, state, action.payload);

    case 'SCHEDULE_SHIPPING':
      return Object.assign({}, state, action.payload);
      
    case 'SCHEDULE':
      return Object.assign({}, state, { schedule: action.payload});

    case 'SHIPPING':
      return Object.assign({}, state, { shipping: action.payload});
    
    case 'RESERVED_APPOINTMENT':
      return Object.assign({}, state, { reservedAppointment: action.payload});

    case 'OVERIDE_APPOINTMENTID':
      return Object.assign({}, state, { overideAppointmentid: action.payload});
    case 'RESERVED_CBR':
      return Object.assign({},state,  {reservedCbr: action.payload});
    case 'EFFECTIVE_BILLDATE_CHANGE':
      return Object.assign({}, state, { effectiveBillDateChange: action.payload});
    case 'BILL_EFFECTIVE_DATE_INFO':
          return Object.assign({}, state, { billeffectiveDateInfo: action.payload});
    case 'APPOINTMENT_DATA':
      return Object.assign({}, state, { appointmentInfoNoValue: action.payload });
    default:
      return state;
  }
};