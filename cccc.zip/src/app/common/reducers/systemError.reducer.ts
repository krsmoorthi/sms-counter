import { ActionReducer } from "@ngrx/store";
import { User } from "../models/user.model";
import { CustomAction } from 'app/CustomAction';

export function systemErrorReducer(
  state: any = [],
  action: CustomAction
): ActionReducer<User> {
  switch (action.type) {
    case "SYSTEM_ERROR":
      return Object.assign({}, state, { systemError: action.payload });

    default:
      return state;
  }
}
