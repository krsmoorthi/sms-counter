import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function moveReducer(state: any = [], action: CustomAction): ActionReducer<any> {
        switch (action.type) {
            // case 'CANCEL_ORDER':
            //   return Object.assign({}, state, action.payload);
            // case 'DUE_DATE_SCHEDULE':
            //   return Object.assign({}, state, action.payload);
            // case 'CANCELLED_ORDER':
            //   return Object.assign({}, state, action.payload);
            // case 'PENDING_SUMMARY':
            //   return Object.assign({}, state, action.payload);
            case 'ADDRESS_TYPE':
                return Object.assign({}, state, action.payload);
            case 'SUBMITTED_ORDER':
                return Object.assign({}, state, action.payload);
            case 'SPLITDUEDATE_CLICKED':
                return Object.assign({}, state, { splitDueDateClicked: action.payload });
            case 'SUP2_SPLITDUEDATE_CLICKED':
                return Object.assign({}, state, { sup2SplitDueDateClicked: action.payload });
            case 'MOVE_FLOW_DATA_CATALOG_NAME':
                return Object.assign({}, state, { catalogName: action.payload });
            default:
                return state;
        }
    };