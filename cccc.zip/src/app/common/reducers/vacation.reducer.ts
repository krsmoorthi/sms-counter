import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function vacationOrderReducer(state: any = [], action: CustomAction): ActionReducer<any> {
  switch (action.type) {
    case 'VACATION_REVIEW_ORDER':
      return Object.assign({}, state, action.payload);
    case 'VACATION_REVIEW_ORDER_SUBMIT':
      return Object.assign({}, state, action.payload);
    default:
      return state;
  }
};
export function vacationReducer(state: any = [], action: CustomAction): ActionReducer<any> {
    switch (action.type) {
        case 'VACATION_SUSPEND_INIT_RESPONSE':
            return Object.assign({}, state, { vacSusInitRes: action.payload });
        case 'VACATION_VOICE_HP_OFFER':
            return Object.assign({}, state, { vacVoiceHpOffer: action.payload });
        case 'VACATION_RESTORE_INIT_RESPONSE':
            return Object.assign({}, state, { vacResInitRes: action.payload });
        case 'VACATION_SCHEDULE_RESPONSE':
            return Object.assign({}, state, {vacationscheduleresponse: action.payload });
        case 'VACATIONRESTORE_SCHEDULE_RESPONSE':
            return Object.assign({}, state, {vacationrestorescheduleresponse: action.payload });
        case 'REENTRANT_OPTION':
            return Object.assign({}, state, {reentrantoption: action.payload });
        case 'VACATION_REVIEWORDER_RESPONSE':
            return Object.assign({}, state, {vacationrevieworderresponse: action.payload });
        case 'VACATION_FLOW':
            return Object.assign({}, state, {vacationflow: action.payload });
        case 'UNHOLD_VACATION_FLOW':
            return Object.assign({}, state, {unholdvacationflow: action.payload });
        case 'HSI_CUSTOMER_ORDER_ITEM_FOR_REQUEST':
            return Object.assign({}, state, {hsiCustomerOrderItem: action.payload });
        case 'CART_FOR_VACATION_OPTION':
            return Object.assign({}, state, {cartForVacOpt: action.payload });
        case 'FINAL_VAC_CART':
            return Object.assign({}, state, {finalVACCart: action.payload });
        case 'VACATION_FLOW_NAME':
            return Object.assign({}, state, {vacFlowName: action.payload });
        case 'VAC_SUS_ACTIVE_PRODUCTS':
            return Object.assign({}, state, {vacSusActiveProducts: action.payload });
        case 'VAC_RES_CART':
            return Object.assign({}, state, {vacResCart: action.payload });
        case 'VACATION_REFERRAL_NUMBER':
            return Object.assign({}, state, {vacReferralNumber: action.payload });
        case 'VACATION_RESERVED_CBR':
            return Object.assign({}, state, {reservedCbr: action.payload });
        case 'EXISTS_PRODUCTS':
            return Object.assign({}, state, {existsProducts: action.payload });
        case 'IS_OFFER_PAGE_CONTINUE_ALLOWED':
            return Object.assign({}, state, {isContinueEnabled: action.payload });
        case 'ON_CONTINUE_FROM_OFFER_PAGE_RESPONSE_DATA':
            return Object.assign({}, state, {responseData: action.payload });
        case 'VACATION_RECONNECT_OFFER':
            return Object.assign({}, state, {vacReconnectOffer: action.payload });
        case 'SELECTED_VACATION_DATA' :
            return Object.assign({}, state, {selectedVacationData: action.payload });
        default:
            return state;
    }
};