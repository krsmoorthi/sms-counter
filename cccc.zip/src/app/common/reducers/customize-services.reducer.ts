import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function customizeServicesReducer(state: any = [], action: CustomAction): ActionReducer<any> {
        switch (action.type) {
            case 'CREATE_CUSTOMIZE_ADDONS':
                return Object.assign({}, state, action.payload);
            case 'PRODUCT_TYPE':
                return Object.assign({}, state, { productType: action.payload });
            case 'TELEPHONE_NUMBER':
                return Object.assign({}, state, { telephoneNumber: action.payload });
            case 'TELEPHONE_NUMBER_TYPE':
                return Object.assign({}, state, { telephoneNumberType: action.payload });
            case 'POTS_PORTING_CHECK':
                return Object.assign({}, state, { potsPortingCheck: action.payload });
            case 'WORKING_TN':
                return Object.assign({}, state, { workingTN: action.payload });
            case 'LIFELINE_CONFIG':
                return Object.assign({}, state, { lifelineConfig: action.payload });
            case 'LIFELINE_CONFIG_DISCOUNTS':
                return Object.assign({}, state, { lifelineDiscounts: action.payload });
            case 'LIFELINE_CONFIG_ADJUSTMENTS':
                return Object.assign({}, state, { lifelineAdjustment: action.payload });
            case 'LIFELINE_POTS_CONFIG':
                return Object.assign({}, state, { lifelinePotsConfig: action.payload });
            case 'LIFELINE_POTS_CONFIG_DISCOUNTS':
                return Object.assign({}, state, { lifelinePotsDiscounts: action.payload });
            case 'LIFELINE_POTS_CONFIG_ADJUSTMENTS':
                return Object.assign({}, state, { lifelinePotsAdjustment: action.payload });
            case 'LIFELINE_REQUEST':
                return Object.assign({}, state, { lifelineRequest: action.payload });
            case 'EMPTY_TN_NUMBER':
                return Object.assign({}, state, { emptytnnumber: action.payload });
            case 'SIMPLE_PORT_CHECK':
                return Object.assign({}, state, { simpleportcheck: action.payload });
            case 'INCLUDING_FEATURE':
                return Object.assign({}, state, { includingfeature: action.payload });
            case 'LIFELINE_INTERNET_ADDED':
                return Object.assign({}, state, { lifelineaddedforinternet: action.payload });
            case 'LIFELINE_POTS_ADDED':
                return Object.assign({}, state, { lifelineaddedforpots: action.payload });
            case 'LIFELINE_DHP_ADDED':
                return Object.assign({}, state, { lifelineaddedfordhp: action.payload });
            case 'LIFELINE_ACTIVE':
                return Object.assign({}, state, { isLifelineActive: action.payload });
            case 'INCLUDING_GIFTCARDS':
                return Object.assign({}, state, { giftcards: action.payload });
            case 'INCLUDING_OFFERS':
                return Object.assign({}, state, { offers: action.payload });
            case 'SELCTED_GIFTCARDS':
                return Object.assign({}, state, { selectedGiftCard: action.payload });
            case 'ELIGIBLE_GIFTCARDS':
                return Object.assign({}, state, { eligibleCards: action.payload });
            case 'CLOSERS_PROMOS_DISCOUNTS':
                return Object.assign({}, state, { closersandpromosDiscounts: action.payload });
            case 'ASSESS_CHARGE':
                return Object.assign({}, state, { assessCharge: action.payload });
            case 'SELECTED_ASSESS_CHARGE':
                return Object.assign({}, state, { selectedAssessCharge: action.payload });
            case 'TN_RESERVED':
                return Object.assign({}, state, { isTnReserved: action.payload });
            case 'UPDATE_CUSTOMIZE_CART_ITEMS':
                return Object.assign({}, state, {
                    payload: Object.assign({}, state.payload, {
                        cart: Object.assign({}, state.payload.cart, {
                            customerOrderItems: action.payload
                        })
                    })
                });
            case 'SELECTED_REENTRANT_DISCOUNTS':
                return Object.assign({}, state, { selectedreentrantDisc: action.payload });
            case 'SELECTED_REENTRANT_GIFT_DISCOUNTS':
                return Object.assign({}, state, { selectedreentrantGiftDisc: action.payload });
            case 'NON-PUB-REMOVED':
                return Object.assign({}, state, { nonpubremoved: action.payload });
            case 'TECHDEV_SELECTED':
                return Object.assign({}, state, { techdevselected: action.payload });
            case 'RECOMMENDATION':
            return Object.assign({}, state, { recommendationFlag: action.payload });  
            case 'NON_PUB_NO_CHARGE_SELECETD':
                return Object.assign({}, state, { nonpubnochargeselectedvalue: action.payload });
            case 'CART_DATA':
                return Object.assign({}, state, { cartData: action.payload }); 
            case 'CART_DATA_DTV':
                return Object.assign({}, state, { dtvCartData: action.payload }); 
            case 'OFFER_CHANGE_DATA':
                return Object.assign({}, state, { offerChangeData: action.payload }); 
            case 'CLOSERS_PROMOS_DISCOUNTS_ONHOLD':
                return Object.assign({}, state, { selectedDiscountsfromHold: action.payload });
            case 'CLOSERS_PROMOS_GIFTCARDS_ONHOLD':
                return Object.assign({}, state, { selectedGiftcardsfromHold: action.payload });
            case 'EXP_DISC_ARRAY':
                return Object.assign({}, state, { expDiscArray: action.payload });
            default:
                return state;
        }
    };