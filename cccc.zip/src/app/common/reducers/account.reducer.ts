import { ActionReducer, Action } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function accountReducer(state: any = [], action: CustomAction): ActionReducer<Account> {
  switch (action.type) {
      case 'ACCOUNT_INFORMATION':
      return Object.assign({}, state, action.payload);
      case 'ADDRESS_TYPES':
      return Object.assign({}, state, action.payload);
      case 'ADD_TYPE':
      return Object.assign({}, state, { addressType: action.payload });
      case 'BILLING_ADDRESS':
      return Object.assign({}, state, action.payload);
      case 'PERSONAL_DETAILS':
      return Object.assign({}, state, { personaldetails: action.payload });
      case 'CONTACT_DETAILS':
      return Object.assign({}, state, { contact: action.payload });  
      case 'ACCT_PASSWORD':
      return Object.assign({}, state, { accountPassword: action.payload }); 
      case 'ACCOUNT_PREFERENCES_DETAILS'   :
      return Object.assign({}, state, { accountReqDetails: action.payload });    
      case 'BILLING_ADDR':
      return Object.assign({}, state, { billingaddr: action.payload });
      case 'AUTHORIZED_PARTIES':
      return Object.assign({}, state, { isAuthorizedParties: action.payload }); 
    default:
      return state;
  }
};