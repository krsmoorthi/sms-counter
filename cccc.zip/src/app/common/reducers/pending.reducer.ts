import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function pendingReducer(state: any = [], action: CustomAction): ActionReducer<any> {
        switch (action.type) {
            case 'CANCEL_ORDER':
                return Object.assign({}, state, action.payload);
            case 'DUE_DATE_SCHEDULE':
                return Object.assign({}, state, action.payload);
            case 'CANCELLED_ORDER':
                return Object.assign({}, state, action.payload);
            case 'PENDING_SUMMARY':
                return Object.assign({}, state, action.payload);
            case 'CONFIRM_SCHEDULE':
                return Object.assign({}, state, action.payload);
            case 'SUBMITTED_ORDER':
                return Object.assign({}, state, action.payload);
            case 'ORDER_UNHOLD':
                return Object.assign({}, state, action.payload);
            case 'SECURITY_DEPOSIT':
                return Object.assign({}, state, action.payload);
            case 'PENDING_RESERVED_CBR':
                return Object.assign({}, state, { reservedCbr: action.payload });
            case 'UNHOLD_REASON_REMARK':
                return Object.assign({}, state, action.payload);
            case 'SUPHOLD_REQUEST':
                return Object.assign({}, state, { suponholdrequest: action.payload });
            case 'STACK_AMEND_ELIGIBILITY':
                return Object.assign({}, state, { stackAmendEligibility: action.payload });
            case 'STACK_AMEND_INIT':
                return Object.assign({}, state, action.payload);
            case 'B_AND_R_PENDING_SUMMARY':
                return Object.assign({}, state,{ BillingAndRecordsPending: action.payload });    
            default:
                return state;
        }
    };