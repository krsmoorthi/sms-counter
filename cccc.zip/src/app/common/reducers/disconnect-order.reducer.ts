import { ActionReducer } from '@ngrx/store';
import { CustomAction } from 'app/CustomAction';

export function disconnectOrderReducer(state: any = [], action: CustomAction): ActionReducer<any> {
  switch (action.type) {
    case 'DISCONNECT_REVIEW_ORDER':
      return Object.assign({}, state, action.payload);
    case 'DISCONNECT_REVIEW_ORDER_SUBMIT':
      return Object.assign({}, state, action.payload);
    default:
      return state;
  }
};