import { ActionReducer } from '@ngrx/store';
import { CreditCheck } from '../models/credit-check.model';
import { CustomAction } from 'app/CustomAction';

export function creditCheckReducer(state: any = [], action: CustomAction): ActionReducer<CreditCheck> {
  switch (action.type) {
    case 'CREDIT_REVIEW':
      return Object.assign({}, state, action.payload);
    case 'UPDATE_CREDIT_REVIEW':
      return Object.assign({}, state, { taskId : action.payload});
   case 'CREDIT_CHECKED':
      return Object.assign({}, state, { creditchecked : action.payload});
    case 'CREDIT_CHECK_ADDLATTR':
      return Object.assign({}, state, { creditcheckedaddlattr : action.payload});
    case 'DEPOSIT_DATA':
      return Object.assign({}, state, { creditreviewdepositdata : action.payload});      
    case 'CREDIT_REVIEW_PAYLOAD':
      return Object.assign({}, state, { billingAddress : action.payload});
    case 'CREDIT_REVIEW_PAYMENT_STATUS':
      return Object.assign({}, state, { paymentStatus : action.payload});
    case 'CREDIT_DATA_RETAIN':
      return Object.assign({}, state, { credit_detail : action.payload});
    case 'CREDIT_DATA_RETAIN_SSN':
      return Object.assign({}, state, { ssn_detail : action.payload});
      case 'PAYMENT_DONE':
      return Object.assign({}, state, { paymentdone : action.payload});   
    default:
      return state;
  }
};