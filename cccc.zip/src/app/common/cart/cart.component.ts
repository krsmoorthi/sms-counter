import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { User } from '../../common/models/user.model';
import { ShoppingCart, CustomerOrderItems, WaivedOtcInfo } from '../../common/models/cart.model';
import { Products, Prices, OfferProductComponents, AttributesCombination, ServiceCharacteristic, CompositeAttribute} from '../../common/models/product.model';
import { AppStateService } from '../../common/service/app-state.service';
import { GenericValues } from '../../common/models/common.model';
import { AccountService } from './../../common/service/account.service';
import { VacationEnums } from '../enums/vacationEnums';
import { isEqual } from 'lodash';
import { Subject } from 'rxjs';

@Component({
    selector: 'cart',
    templateUrl: './cart.component.html',
    styleUrls: ['./cart.component.scss']
})

export class CartSummaryComponent implements OnInit, OnDestroy {
    public isOneTime: boolean = false;
    public closersAndPromosDiscounts: boolean = false;
    public billingBanNum: any;
    public isExistingCartRemoved: boolean = false;
    public prevUrl: string;
    public currUrl: string;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    public existingServiceAddress: any;
    public existingData: any;
    public existingSubscription: Subscription;
    public accountSubscription: Subscription;
    public existingObservable: Observable<any>;
    public user: Observable<User>;
    public cart: Observable<ShoppingCart>;
    public cartSubscription: Subscription;
    public cartObservable: Observable<ShoppingCart>;
    public cartSub: Subscription;
    public internetSummary: CustomerOrderItems;
    public vacSusExistsinternetSummary: CustomerOrderItems;
    public tvSummary: CustomerOrderItems;
    public dhpSummary: CustomerOrderItems;
    public CORSummary: CustomerOrderItems;
    public oneTimeCharge: any[] = [];
    public existingOneTimeCharge: any[] = [];
    public installmentBilling: any[] = [];
    public hsiMonthlyCharge: any[] = [];
    public tvMonthlyCharge: any[] = [];
    public dhpMonthlyCharge: any[] = [];
    public termination: boolean = false;
    private referralPage: boolean = false;
    public referral: boolean = false;
    public otc: boolean = false;
    public totalOTC: number = 0;
    public phonenumber: string;
    public totalHSI: number = 0;
    public totalTV: number = 0;
    public totalDHP: number = 0;
    public monthlyTotal: number = 0;
    public internetAvail: boolean = false;
    public tvAvail: boolean = false;
    public prismSupported: boolean = false;
    public phoneAvail: boolean = false;
    public dhpSupported: boolean = false;
    public internetSelected: boolean = false;
    public tvSelected: boolean = false;
    public dhphoneSelected: boolean = false;
    public hmphoneSelected: boolean = false;
    public selectedValue: string;
    public blink: boolean = false;
    public userObserve;
    public userSubscription: Subscription;
    public currentPath: string;
    public maxSpeed: string;
    public technology: string;
    public noOfHD: string;
    public pendingBillingBan: boolean = false;
    public discountItemDesc = [];
    public discountItemDescExpryDate = [];
    public vacationObservable: Observable<any>;
    public isVacSusFlow: boolean = false;
    public isVacResFlow: boolean = false;
    public reuseBan: boolean = false;
    public discountMonthlyCharge = [];
    public discountPrice: number = 0;
    public orderFlow: string;
    public isResp: boolean = false;
    public leasedModemName = "";
    public isPrepaid: boolean;
    public firstName: string;
    public lastName: string;
    public ban: string;
    public cartData: any;
    public prevTotalOtc: number;
    public diffOtc: number;
    public updateTotalOtcSubject: Subject<number>;
    public updateTotalOtcSubscription: Subscription;
    public waivedOtcInfo: WaivedOtcInfo;
    public payloadNotReady: any;

    @Input() set userEvent(userObs: Observable<User>) {
        this.user = userObs;
        this.existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            if (respData && respData.orderFlow && respData.orderFlow.flow) {
                this.orderFlow = respData.orderFlow.flow;
            }
            if (respData && respData.orderFlow && respData.orderFlow.flow === "billing" && respData.orderFlow.type === "pending") {
                this.pendingBillingBan = true;
            } else if(respData && respData.orderFlow && respData.orderFlow.type === "pending") {
                this.pendingBillingBan = true;
            }
            if(respData && respData.existingProductsAndServices){
                this.billingBanNum = respData && respData.existingProductsAndServices && respData.existingProductsAndServices[0].accountInfo.ban;
            }
            else{
                this.billingBanNum = respData && respData.pendingOrders && respData.pendingOrders[0].orderDocument && respData.pendingOrders[0].orderDocument.accountInfo && respData.pendingOrders[0].orderDocument.accountInfo.ban; 
            }
            if (respData && respData.orderFlow && respData.orderFlow.type === "fromHold") {
                let pendingObservable = <Observable<any>>this.store.select('pending');
                pendingObservable.subscribe(pending => {
                    this.pendingBillingBan = true;
                    this.billingBanNum = pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.ban;
                })
            }
            if (this.orderFlow === "Change") {
                if (respData && respData !== undefined && (respData.internetCheck || respData.videoCheck || respData.phoneCheck)) {
                    this.internetAvail = respData.internetCheck;
                    this.tvAvail = respData.videoCheck;
                    this.phoneAvail = respData.phoneCheck;
                }
                let serviceCategory = [];
                if (respData && respData.orderInit && respData.orderInit.payload && respData.orderInit.payload.serviceCategory !== undefined) {
                    serviceCategory = respData.orderInit.payload.serviceCategory;
                    this.getMaxSpeedTech(serviceCategory);
                }
            }
            if ((this.maxSpeed === '' || this.maxSpeed === undefined || this.maxSpeed === null) && respData.existingProductsAndServices && (respData.existingProductsAndServices.length > 0)) {
                this.getMaxSpeed(respData.existingProductsAndServices[0].serviceCategory);
            }
            if ((this.maxSpeed === '' || this.maxSpeed === undefined || this.maxSpeed === null) && respData.orderInit && respData.orderInit.payload && respData.orderInit.payload.serviceCategory) {
                this.getMaxSpeed(respData.orderInit.payload.serviceCategory);
            }
        });
        this.cartObservable = <Observable<any>>this.store.select('cart');
        this.cartSub = this.cartObservable.subscribe((data) => {
            if(data.leasedModemDisplayName){
                this.leasedModemName = data.leasedModemDisplayName;
            }
            if (data && data.maxSpeed !== undefined) {
                let downspeed: string;
                let downUom: string;
                let upspeed: string;
                let upUom: string;
                let primaryProduct = data.maxSpeed;
                primaryProduct && primaryProduct.productAttributes && primaryProduct.productAttributes.map((prodAttrib) => {
                    prodAttrib.compositeAttribute.map((compAttrib) => {
                        if (compAttrib.attributeName === GenericValues.upspeed && compAttrib.attributeValue !== undefined) {
                            upspeed = compAttrib.attributeValue.slice(4, compAttrib.attributeValue.length);
                            if (compAttrib.uom) { upUom = compAttrib.uom.slice(0, 1); }
                        } else if (compAttrib.attributeName === GenericValues.downspeed && compAttrib.attributeValue !== undefined) {
                            downspeed = compAttrib.attributeValue.slice(4, compAttrib.attributeValue.length);
                            if(compAttrib.uom) { downUom = compAttrib.uom.slice(0, 1) + '/'; }
                        } else if (compAttrib.attributeName === GenericValues.technology) {
                            this.technology = compAttrib.attributeValue;
                        }
                    })

                })
                this.maxSpeed = downspeed + downUom + upspeed + upUom;
            }
            let isStack = this.existingData && this.existingData.stackamend && this.existingData.stackamend.stackAmendFlag === 'stackOrder';
            if(data && data.waivedOtcInfo && data.waivedOtcInfo.otcWaiverList && data.waivedOtcInfo.otcWaiverList.reason && !isStack && data.waivedOtcInfo.totalWaivedOtc > 0) {
                this.waivedOtcInfo = data.waivedOtcInfo;
                this.discountItemDesc.push(data.waivedOtcInfo.totalWaivedOtc);
                this.discountItemDesc.push(data.waivedOtcInfo.otcWaiverList.reason.description);
            }
        })
        this.userSubscription = this.user.subscribe(
            (data) => {
                if(data && data.ban) { this.billingBanNum = data.ban; }
                if (data && data.isDisconnectLandLineSelected) {
                    this.referralPage = data.isDisconnectLandLineSelected;
                }
                if (data.phoneNumber !== null && data.phoneNumber !== undefined && data.phoneNumber) {
                    this.phonenumber = data.phoneNumber.replace(/[^0-9]/g, '');
                }
                if (data.orderInit && data.orderInit.payload !== undefined) {
                    this.internetAvail = data.internetCheck;
                    this.tvAvail = data.videoCheck;
                    this.phoneAvail = data.phoneCheck;
                    let serviceCategory = [];
                    if (data.orderInit.payload.newLocation !== undefined) {
                        serviceCategory = data.orderInit.payload.newLocation.serviceCategory;
                        this.getMaxSpeedTech(serviceCategory);
                    } else {
                        if (data.previousUrl !== '/existing-products' && data.previousUrl !== '/offer-change') {
                            serviceCategory = data.orderInit.payload.serviceCategory;
                            this.getMaxSpeedTech(serviceCategory);
                        }
                    }
                }
                if (data && data.autoLogin && data.autoLogin.sfcData && data.autoLogin.sfcData.type && data.autoLogin.sfcData.type !== undefined) {
                    this.reuseBan = (data.autoLogin.sfcData.type === 'ReopenBAN');
                    this.billingBanNum = data.autoLogin.sfcData.accountBAN;
                }
            });
    }

    constructor(public store: Store<AppStore>, private appStateService: AppStateService, private accountService: AccountService) {
        this.existingObservable = <Observable<any>>store.select('existingProducts');
        this.getExistingStore();
        this.updateTotalOtcSubject =  new Subject<number>();
        this.cart = <Observable<ShoppingCart>>store.select('cart');
        this.cartSubscription = this.cart.subscribe(
            (data) => {
                this.cartData = data;
                this.populateCart(data);

                if(this.payloadNotReady && this.cartData && this.cartData.payload){
                    this.payloadNotReady = false;
                    this.checkWaiveDiscount(this.diffOtc);
                }
            }
        );
        this.accountSubscription = this.accountService.accountData$ && this.accountService.accountData$.subscribe((data) => {
            this.user.subscribe(d => {
                if (data && data !== undefined) {
                    d.firstName = data.firstName ? data.firstName : d.firstName;
                    d.lastName = data.lastName ? data.lastName : d.lastName;
                    d.phoneNumber = data.contactNumber ? data.contactNumber : d.phoneNumber;
                }
            })
        })
        if(this.accountSubscription) this.accountSubscription.unsubscribe();
        let updateTotalOtcObservable$ = this.updateTotalOtcSubject.asObservable();
        this.updateTotalOtcSubscription = updateTotalOtcObservable$ && updateTotalOtcObservable$.subscribe((diffotc)=>{
                this.checkWaiveDiscount(diffotc);
        })
    }

    public ngOnInit() {
        this.getExistingStore();
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.isPrepaid = data.prepaidFlag && data.prepaidFlag === 'PREPAID' ? true : false;
            this.currUrl = data.currentUrl;
            this.prevUrl = data.previousUrl;
            if(data.firstName) this.firstName = data.firstName;
            if(data.lastName) this.lastName = data.lastName;
            if(data.ban) this.billingBanNum = data.ban;
            this.store.select('retain');
            if (this.currUrl === '/existing-products' && !this.referralPage) {
                this.isExistingCartRemoved = true;
            } else {
                this.isExistingCartRemoved = false;
            }
        });
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationObservable.subscribe((data) => {
            if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacSusFlow) this.isVacSusFlow = true;
                else this.isVacSusFlow = false;

                if (data.vacFlowName.isVacResFlow) this.isVacResFlow = true;
                else this.isVacResFlow = false;
            }
        });
    }

    private getExistingStore() {
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            this.existingData = data;
            if (data.orderFlow && data.orderFlow.flow) {
                this.orderFlow = data.orderFlow.flow;
                if ((data.orderFlow.flow === 'EXISTING' || data.orderFlow.flow === 'Change') && data.existingProductsAndServices[0].serviceCategory !== undefined) {
                    this.getMaxSpeedTech(data.existingProductsAndServices[0].serviceCategory);
                }
            }
        });
        if(this.existingSubscription) this.existingSubscription.unsubscribe();
    }

    private getMaxSpeed = (serviceCategory) => {
        let downspeed: string;
        let downUom: string;
        let upspeed: string;
        let upUom: string;
        serviceCategory && serviceCategory.map((category) => {
            if (category.serviceCategory === GenericValues.sData || category.serviceCategory === GenericValues.iData) {
                category.serviceCharacteristic && category.serviceCharacteristic.map((data) => {
                    if (data.name === 'downSpeed' && data.uom) {
                        downspeed = data.value;
                        if(data.uom) { downUom = data.uom.slice(0, 1) + '/'; }
                    }
                    if (data.name === 'upSpeed' && data.uom) {
                        upspeed = data.value;
                        if(data.uom) { upUom = data.uom.slice(0, 1); }
                    }
                    if (data.name === GenericValues.technology) {
                        this.technology = data.value;
                    }
                });
            }
            this.maxSpeed = downspeed + downUom + upspeed + upUom;
        });
    }


    private getMaxSpeedTech(serviceCategory) {
        serviceCategory.map(
            (category) => {
                if (this.internetAvail && (category.serviceCategory === GenericValues.sData ||
                    category.serviceCategory === GenericValues.iData)) {
                    this.prismSupported = (this.fetchValue(category.serviceCharacteristic,
                        'prismSupported') === 'true');
                    this.dhpSupported = (this.fetchValue(category.serviceCharacteristic,
                        'dhpSupported') === 'true');

                }
                if (this.tvAvail && category.serviceCategory === 'DATA/VIDEO') {
                    this.noOfHD = '(' + this.fetchValue(category.serviceCharacteristic,
                        'hdStreaming') + 'HD)';
                    this.prismSupported = (this.fetchValue(category.serviceCharacteristic,
                        'prismSupported') === 'true');
                    this.dhpSupported = (this.fetchValue(category.serviceCharacteristic,
                        'dhpSupported') === 'true');
                }
            }
        );
    }

    public isRetentionDiscount(descName) {
        if (this.discountItemDesc.findIndex(x => x === descName) >= 0) {
            return true;
        } else {
            return false;
        }

    }

    private getIndividualPricesForHP(prices) {
        //  Push individual prices in the monthly charge
        const individualPrices = prices && prices.reduce((allPrices, currentPrice) => {
            allPrices[currentPrice.priceTypeDescription] = currentPrice;
            return allPrices;
        }, {});
        let firstPartyPrice;
        if(individualPrices) firstPartyPrice = individualPrices['MRC/OTC'];
        if (firstPartyPrice && firstPartyPrice.rc && !this.isPrepaid) {
            this.dhpMonthlyCharge.push(this.dhpSummary.offerDisplayName+ ',' + firstPartyPrice.rc);
        }
        prices && prices.map((price => {
            if(price && price.priceType !== GenericValues.pPriceType && price.rc !== 0) {
                this.dhpMonthlyCharge.push(price.priceTypeDescription+ ',' + price.rc);
            }
        }))
    }

    private populateCart(data: ShoppingCart) {
        let currentStore = this.appStateService.getState();
            if(currentStore && currentStore.existingProducts &&  this.isPrepaid && ((currentStore.existingProducts.stackamend &&
                currentStore.existingProducts.stackamend.stackAmendFlag === 'amendOrder') || (currentStore.existingProducts.orderFlow && currentStore.existingProducts.orderFlow.flow === 'NEWINSTALL'))) {
                    this.isOneTime = true;
            }else{
                this.isOneTime= false;
            }
        /* if(!this.oneTimeLoading) {
            let currentStore = this.appStateService.getState();
            if(currentStore && currentStore.existingProducts && currentStore.existingProducts.stackamend &&
                currentStore.existingProducts.stackamend.stackAmendFlag === 'amendOrder' && currentStore.user.prepaidFlag === 'PREPAID') {
                    let existingProds: CustomerOrderItems[] = [];
                    let pending = currentStore.pending;
                    this.existingData = currentStore.existingProducts;
                    if(pending && pending.orderDocument && pending.orderDocument.existingServices
                        && pending.orderDocument.existingServices !== null) {
                            existingProds = pending.orderDocument.existingServices;
                            this.oneTimeLoading = true;
                    } else if(pending && pending.orderDocument && pending.orderDocument.customerOrderItems
                        && pending.orderDocument.customerOrderItems.length > 0) {
                            existingProds = pending.orderDocument.customerOrderItems;
                            this.oneTimeLoading = true;
                    }
                    if(this.oneTimeLoading && existingProds) {
                        existingProds.map(exist => {
                            exist.customerOrderSubItems && exist.customerOrderSubItems.map(sub => {
                                sub.productAttributes && sub.productAttributes.map(attr => {
                                    if(attr.isPriceable) {
                                        attr.prices && attr.prices.map(price => {
                                            price.discountedOtc !== 0 ? 
                                            this.existingOneTimeCharge.push(sub.productName + ',' + price.discountedOtc.toFixed(2)) :
                                            price.otc !== 0 ? this.existingOneTimeCharge.push(sub.productName + ',' + price.otc.toFixed(2)) : ''
                                        })
                                    }
                                })
                            })
                        })
                    }
            }
        } */
        this.internetSelected = false;
        this.tvSelected = false;
        this.dhphoneSelected = false;
        this.hmphoneSelected = false;
        this.oneTimeCharge = [];
        this.installmentBilling = [];
        this.hsiMonthlyCharge = [];
        this.discountMonthlyCharge = [];
        this.tvMonthlyCharge = [];
        this.dhpMonthlyCharge = [];
        this.totalOTC = 0;
        this.totalHSI = 0;
        this.totalTV = 0;
        this.totalDHP = 0;
        this.monthlyTotal = 0;
        this.discountPrice = 0;
        if (data && data.payload && data.payload !== undefined && data.payload.cart && data.payload.cart.customerOrderItems && data.payload.cart.customerOrderItems.length > 0) {
            if (data.selectedService.indexOf('Internet') !== -1) {
                this.internetSelected = true;
            }
            if (data.selectedService.indexOf('TV') !== -1) {
                this.tvSelected = true;
            } else {
                this.selectedValue = 'internet';
            }
            if (data.selectedService.indexOf('DHPhone') !== -1) {
                this.dhphoneSelected = true;
            } else if (data.selectedService.indexOf('HMPhone') !== -1 && this.internetSelected) {
                this.hmphoneSelected = true;
            } else if (data.selectedService.indexOf('HMPhone') !== -1 && !this.internetSelected) {
                this.hmphoneSelected = true;
                this.selectedValue = 'phone';
            } else {
                this.selectedValue = 'internet';
            }
            if (this.isVacSusFlow) {
                this.filterCategorybyType(data.payload.cart.customerOrderItems, GenericValues.iData, true);
                this.filterCategorybyType(data.payload.cart.customerOrderItems, GenericValues.iData, false);
            } else if (this.orderFlow === 'COR') {
                this.internetSummary = this.filterCategorybyType(data.payload.cart.customerOrderItems, GenericValues.iData);
                this.CORSummary = this.filterCategorybyType(data.payload.cart.customerOrderItems, GenericValues.iData, true);
            } else {
                this.internetSummary = this.filterCategorybyType(data.payload.cart.customerOrderItems, GenericValues.sData);
            }
            this.oneTimeCharge = [];
            this.installmentBilling = [];
            this.hsiMonthlyCharge = [];
            this.tvMonthlyCharge = [];
            this.dhpMonthlyCharge = [];
            this.totalOTC = 0;
            this.discountMonthlyCharge = [];
            this.discountPrice = 0;
            this.totalHSI = 0;
            this.totalTV = 0;
            this.totalDHP = 0;
            this.monthlyTotal = 0;
            let offerList: Products[];
            let type: string;
            let name: string;
            let modem: AttributesCombination;
            let modemValue: string;
            if (this.internetSummary !== undefined) {
                offerList = this.internetSummary.customerOrderSubItems;
                for (let i = 0; i < offerList.length; i++) {
                    if (offerList[i] === null || offerList[i] === undefined) {
                        continue;
                    }
                    type = offerList[i].productCategory;
                    name = offerList[i].productName;
                    if (offerList[i].productAttributes.length > 0) {
                        for (let j = 0; j < offerList[i].productAttributes.length; j++) {
                            if (!offerList[i].productAttributes[j].isPriceable) {
                                continue;
                            }
                            modem = offerList[i].productAttributes[j];
                            if (modem !== undefined) {
                                if (modem.compositeAttribute && modem.compositeAttribute.length > 0) {
                                    modemValue = type === 'CORE' ? offerList[i].productName :
                                        modem.compositeAttribute[0].attributeValue;
                                    if (name === GenericValues.modem) {
                                        modem.compositeAttribute.forEach(attr => {
                                            if (attr.attributeName === 'Account Type') {
                                                if(attr.attributeValue === GenericValues.leaseWithCsAttrVAlue) {
                                                    modemValue = GenericValues.lease;
                                                } else {
                                                    modemValue = attr.attributeValue;
                                                }
                                                if(modemValue === GenericValues.lease) {
                                                    if(attr.attributeDisplayName){
                                                        name = attr.attributeDisplayName;
                                                    } else if(this.leasedModemName) {
                                                        name = this.leasedModemName;
                                                    } else { 
                                                        name = attr.attributeValue + " Modem";
                                                    }
                                                } 
                                            }
                                        })
                                    }
                                }
                                for (let k = 0; k < modem.prices.length; k++) {
                                    let priceable = modem.prices[k];
                                    let vacDiscounts = modem.discounts && modem.discounts[k];
                                    if (offerList[i].componentType === GenericValues.cPrimary) {
                                        if (priceable.priceType === GenericValues.pPriceType) {
                                            modemValue = name;
                                            this.populateValues(modem, modemValue, type, name, this.internetSummary, GenericValues.sData);
                                        } else {
                                            modemValue = priceable.priceTypeDescription;
                                            this.populateValues(modem, modemValue, type, name, modem.prices[k], GenericValues.sData);
                                        }
                                    } else {
                                        if (priceable.priceType === GenericValues.pPriceType) {
                                            this.populateValues(modem, modemValue, type, name, modem.prices[k], GenericValues.sData);
                                        }
                                    }
                                 
                                    if (vacDiscounts && this.isVacSusFlow) {
                                        if (vacDiscounts.discountId === '395KQ' && vacDiscounts.autoAttachInd === 'Y' ) { // discountid 395KQ for Vacation Equip. Fee Discount (Ongoing) 
                                            this.discountItemDesc.push(vacDiscounts.discountDescription);
                                            this.hsiMonthly('hsi-vac-discount', vacDiscounts.discountDescription, modemValue, vacDiscounts.discountRate, type)
                                        }
                                        if (vacDiscounts.discountId === '8261KQ' && vacDiscounts.autoAttachInd === 'Y' ) { // discountid 8261KQ for Vacation HSI Discount 6 Mos 
                                            this.discountItemDesc.push(vacDiscounts.discountDescription);
                                            this.hsiMonthly('hsi-vac-discount', vacDiscounts.discountDescription, modemValue, vacDiscounts.discountRate, type)
                                        }
                                        if ((vacDiscounts.discountId !== '395KQ' && vacDiscounts.discountId !== '8261KQ') && vacDiscounts.autoAttachInd === 'Y') {
                                            this.hsiMonthly('DISCOUNT', vacDiscounts.discountDescription, vacDiscounts.autoAttachInd, vacDiscounts.discountRate, '');
                                        }
                                    }
                                }
                                if (!this.isVacSusFlow && !this.isVacResFlow) {
                                    let discounts = modem.discounts;
                                    if(discounts && discounts.length > 0) {
                                        for (let i = 0; i < discounts.length; i++) {
                                            if (discounts[i] && discounts[i].discountRule && (discounts[i].discountRule.toUpperCase() === 'PARENT DISCOUNT' || discounts[i].discountRule.toUpperCase() === 'A' || discounts[i].discountRule.toUpperCase() === 'O' || discounts[i].discountRule.toUpperCase() === 'I') && discounts[i].discountRule && discounts[i].autoAttachInd === 'Y') {
                                                this.hsiMonthly('DISCOUNT', discounts[i].discountDescription, discounts[i].autoAttachInd, discounts[i].discountRate, '');
                                            }
                                            
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if(this.vacSusExistsinternetSummary !== undefined) {
                let productAttributes: any; //modem
                let productCategory: any; //type
                let productName: any; //name
                offerList = this.vacSusExistsinternetSummary.customerOrderSubItems;
                for (let i = 0; i < offerList.length; i++) {
                    if (offerList[i] === null || offerList[i] === undefined) continue;
                    productCategory = offerList[i].productCategory;
                    productName = offerList[i].productName;
                    if (offerList[i].productAttributes.length > 0) {
                        for (let j = 0; j < offerList[i].productAttributes.length; j++) {
                            if (!offerList[i].productAttributes[j].isPriceable) continue;
                            productAttributes = offerList[i].productAttributes[j];
                            if (productAttributes !== undefined) {
                                if (productAttributes.compositeAttribute && productAttributes.compositeAttribute.length > 0) {
                                    modemValue = type === 'CORE' ? offerList[i].productName :
                                    productAttributes.compositeAttribute[0].attributeValue;
                                }
                                for (let k = 0; k < productAttributes.prices.length; k++) {
                                    let priceable = productAttributes.prices[k];
                                    if(productAttributes.discounts && productAttributes.discounts.length>0)
                                    {
                                    let discount = productAttributes.discounts[k];  
                                    if (offerList[i].productName === "Secure WiFi Standalone" && discount && discount.discountRule && (discount.discountRule.toUpperCase() === 'PARENT DISCOUNT' || discount.discountRule.toUpperCase() === 'A' || discount.discountRule.toUpperCase() === 'O' || discount.discountRule.toUpperCase() === 'I') && discount.discountRule && discount.autoAttachInd === 'Y') {
                                        this.hsiMonthly('DISCOUNT', discount.discountDescription, discount.autoAttachInd, discount.discountRate, '');
                                    }      
                                    
                                }
                                        
                                    
                                    if (!(offerList[i].componentType === GenericValues.cPrimary) && offerList[i].action === 'NOCHANGE') {
                                        if (priceable.priceType === GenericValues.pPriceType) {
                                            if(productAttributes.prices[k] && (productAttributes.prices[k].otc > 0 || productAttributes.prices[k].discountedOtc > 0)) continue;
                                            this.populateValues(null, modemValue, productCategory, productName, productAttributes.prices[k], GenericValues.sData);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (this.tvSelected && data.payload.cart.customerOrderItems[1]) {
                this.tvSummary = this.filterCategorybyType(data.payload.cart.customerOrderItems,
                    GenericValues.cVideo);
                if (this.tvSummary) {
                    offerList = this.tvSummary.customerOrderSubItems;
                    for (let i = 0; i < offerList.length; i++) {
                        if (offerList[i] === null || offerList[i] === undefined) {
                            continue;
                        }
                        type = 'VIDEO';
                        let name = offerList[i].productName;
                        if (offerList[i].productAttributes === null || offerList[i].productAttributes.length === 0) {
                            continue;
                        }
                        if (name === GenericValues.cSurcharge) {
                            let modem = offerList[i].productAttributes[0];
                            let modemValue: string;
                            if (modem.compositeAttribute &&
                                modem.compositeAttribute.length > 0) {
                                modemValue = type === 'Internet' ? offerList[i].productName :
                                    modem.compositeAttribute[0].attributeValue;
                            }
                           
                        } else {
                            for (let j = 0; j < offerList[i].productAttributes.length; j++) {
                                if (!offerList[i].productAttributes[j].isPriceable) {
                                    continue;
                                }
                                let modem = offerList[i].productAttributes[j];
                                let modemValue: string;
                                if (modem.compositeAttribute &&
                                    modem.compositeAttribute.length > 0) {
                                    modemValue = type === 'Internet' ? offerList[i].productName :
                                        modem.compositeAttribute[0].attributeValue;
                                }
                                this.populateValues(modem, modemValue, type, name, modem.prices[0], 'VIDEO');
                            }
                        }
                    }
                }
            }
            if (this.dhphoneSelected || this.hmphoneSelected) {
                offerList = [];
                this.dhpSummary = this.filterCategorybyType(data.payload.cart.customerOrderItems, this.hmphoneSelected ? GenericValues.cHP : GenericValues.cDHP);
                if (this.dhpSummary !== undefined) {
                    let pricableAttribute;
                    const primaryComponent = this.dhpSummary.customerOrderSubItems.find((subItem) => {
                        return subItem.componentType === "PRIMARY";
                    });
                    if (primaryComponent && primaryComponent.productAttributes && primaryComponent.productAttributes.length) {
                        pricableAttribute = primaryComponent.productAttributes.filter((productAttribute) => {
                            return productAttribute.isPriceable;
                        })[0];
                    }
                    if ((this.dhpSummary.offerDisplayName === "1 Pty Residence Line" ||
                        (this.dhpSummary.offerType === "NON_BUNDLE" && this.dhpSummary.offerName !== VacationEnums.POTS_VAC_SUS_OFFER_NAME) ||
                        this.dhpSummary.offerName === "Home Phone Unbundled") &&
                        pricableAttribute && pricableAttribute.prices && pricableAttribute.prices.length) {
                        this.getIndividualPricesForHP(pricableAttribute.prices);
                    }
                    offerList = this.dhpSummary.customerOrderSubItems;
                }
                for (let i = 0; i < offerList.length; i++) {
                    if (offerList[i] === null || offerList[i] === undefined || offerList[i].dontShow) {
                        continue;
                    }
                    type = 'DHP';
                    let name = offerList[i].componentType === GenericValues.cPrimary ? this.dhpSummary.productDisplayName === undefined ? this.dhpSummary.offerName : this.dhpSummary.productDisplayName : offerList[i].productName;
                    if (this.isVacSusFlow) {
                        name = offerList[i].componentType === GenericValues.cPrimary ?
                            (this.dhpSummary.productDisplayName ? this.dhpSummary.productDisplayName : offerList[i].productName) : offerList[i].productName;
                    }
                    if (offerList[i].productAttributes === null || offerList[i].productAttributes.length === 0) {
                        continue;
                    }
                    if (offerList[i].productAttributes.length > 0) {
                        for (let j = 0; j < offerList[i].productAttributes.length; j++) {
                            if (!offerList[i].productAttributes[j].isPriceable) {
                                continue;
                            }
                            modem = offerList[i].productAttributes[j];
                        }
                    }
                    if (modem !== undefined) {
                        for (let k = 0; k < modem.prices.length; k++) {
                            let priceable = modem.prices[k];
                            if (priceable.priceType === GenericValues.pPriceType && offerList[i].componentType === GenericValues.cPrimary) {
                                modemValue = name;
                                this.populateValues(modem, modemValue, type, name, this.dhpSummary, 'DHP');
                            } else if (priceable.priceType === GenericValues.pPriceType && offerList[i].componentType !== GenericValues.cPrimary) {
                                if (this.dhpSummary && this.dhpSummary.offerType)
                                    modemValue = this.dhpSummary.offerType.indexOf('BILLING_COR') !== -1 ? undefined : name;
                                this.populateValues(modem, modemValue, type, name, modem.prices[k], 'DHP');
                            } else if (priceable.priceType === 'NRCLINK') {
                                modemValue = priceable.priceTypeDescription;
                                this.populateValues(modem, modemValue, type, name, modem.prices[k], 'DHP');
                            }
                            if (this.isVacSusFlow && priceable.priceType === GenericValues.pPriceType && offerList[i].componentType === GenericValues.cPrimary) {
                                let discounts = modem.discounts;
                                let isInserted = false;
                                if(discounts && discounts.length > 0) {
                                    for (let i = 0; i < discounts.length; i++) {
                                        if (discounts[i] && discounts[i].discountRule && (discounts[i].discountRule.toUpperCase() === 'PARENT DISCOUNT' || discounts[i].discountRule.toUpperCase() === 'A' || discounts[i].discountRule.toUpperCase() === 'O' || discounts[i].discountRule.toUpperCase() === 'I') && discounts[i].discountRule && discounts[i].autoAttachInd === 'Y') {
                                            if(this.discountMonthlyCharge && this.discountMonthlyCharge.length > 0) {
                                                this.discountMonthlyCharge.forEach((monthly) => {
                                                    if(isEqual(monthly, discounts[i].discountDescription + ',' + discounts[i].discountRate)) {
                                                        isInserted = true;
                                                    }
                                                });
                                                if(!isInserted) {
                                                    this.hsiMonthly('DISCOUNT', discounts[i].discountDescription, discounts[i].autoAttachInd, discounts[i].discountRate, '');
                                                }
                                            } else {
                                                this.hsiMonthly('DISCOUNT', discounts[i].discountDescription, discounts[i].autoAttachInd, discounts[i].discountRate, '');
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (!this.dhpSummary || !this.dhpSummary.offerDisplayName) {
                    this.dhpSummary = { offerDisplayName: 'Phone Listing Charge' };
                }
            }
            if (data && data.payload && data.payload.customerAddonOfferItems !== undefined && data.payload.customerAddonOfferItems.length > 0) {
                let addOns = data.payload.customerAddonOfferItems;
                if (addOns.length > 0) {
                    modemValue = '';
                    addOns.forEach((item) => {
                        if (item.customerOrderSubItems) {
                            if (item.customerOrderSubItems.length > 0) {
                                offerList = item.customerOrderSubItems;
                                for (let i = 0; i < offerList.length; i++) {
                                    if (offerList[i] === null || offerList[i] === undefined || offerList[i].dontShow || offerList[i].productName === 'Non-Pub No Charge') {
                                        continue;
                                    }
                                    type = item.productType;
                                    name = offerList[i].productName;
                                    offerList[i].productAttributes && offerList[i].productAttributes.map(attr => {
                                        if (attr.isPriceable) {
                                            if (attr.prices) {
                                                attr.prices.forEach(price => {
                                                    if (price.priceType === 'PRICE') {
                                                        if (price.discountedOtc === 0) {
                                                            if (price.otc === 0) {
                                                                if (price.discountedRc === 0) {
                                                                    if (price.rc !== 0) {
                                                                        this.hsiMonthly(type, name,
                                                                            modemValue, price.rc, type);
                                                                    }
                                                                } else {
                                                                    if (price.discountedRc !== 0) {
                                                                        this.hsiMonthly(type,
                                                                            name, modemValue, price.discountedRc, type);
                                                                    }
                                                                }
                                                            } else {
                                                                if (price.otc !== 0) {
                                                                    this.otcTotal(type, name,
                                                                        modemValue, price.otc, type);
                                                                }
                                                            }
                                                        } else {
                                                            if (price.discountedOtc !== 0) {
                                                                this.otcTotal(type,
                                                                    name, modemValue, price.discountedOtc, type, offerList[i]);
                                                            }
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    });

                }
            }
            if (data.payload.shipping !== undefined) {
                let item: any = data.payload.shipping;
                let modemValue = '';
                let type = item.productType;
                let name = item.name;
                let aapl = item;
                if(aapl.prices[0].discountedOtc === 0) { 
 
                    if (aapl.prices[0].otc === 0) {
                        if (aapl.prices[0].discountedRc === 0) {
                            if (aapl.prices[0].rc !== 0) {
                                this.hsiMonthly(type, name, modemValue, aapl.prices[0].rc, type);
                            }
                        } else {
                            if (aapl.prices[0].discountedRc !== 0) {
                                this.hsiMonthly(type, name,
                                    modemValue, aapl.prices[0].discountedRc, type);
                            }
                        }
                    } else {
                        if (aapl.prices[0].otc !== 0) {
                            this.otcTotal(type, name, modemValue,
                                aapl.prices[0].otc, type);
                        }
                    }

                } else {
                    if (aapl.prices[0].discountedOtc !== 0) {
                        this.otcTotal(type, name,
                            modemValue, aapl.prices[0].discountedOtc, type);
                    }
                }
            }
            if (data.payload.listing !== undefined) {
                let item: any = data.payload.listing;
                let modemValue = '';
                let type = item.productType;
                let name = item.name;
                let aapl = item;
                this.otc = true;
                if (item.name && item.name !== null && item.name !== '' && (aapl.prices[0].discountedOtc < 0 || aapl.prices[0].discountedOtc > 0))
                    if(aapl.prices[0].discountedOtc === 0) { this.otcTotal(type, name, modemValue, aapl.prices[0].discountedOtc, type); }
            }
            if (data.payload.discountItems !== undefined) {
                data.payload.discountItems.map((disc) => {
                    this.discountItemDesc.push(disc.discountDescription);
                    if (disc.discountExpiryDate && disc.discountDuration < 1200) {
                        this.discountItemDescExpryDate[disc.discountDescription] = disc.discountExpiryDate;
                    } else {
                        this.discountItemDescExpryDate[disc.discountDescription] = "";
                    }
                    if (disc.discountDuration > 1) {
                        if (disc.productType === "VOICE-HP") {
                            this.hsiMonthly(disc.productType, disc.discountDescription, modemValue, disc.discountRate, 'Pots AddOn Discount RCD');
                        } else {
                            let parentDiscount = data.payload.discountItems.find((discount) => {
                                return discount.discountRule === "Parent Discount" && discount.autoAttachInd === "N";
                            });
                            if (parentDiscount && disc.discountRule === "Child Discount" && disc.autoAttachInd === "N") {
                                // Do not display this in the cart
                                // This is an issue with Parent Child Discounts
                            }
                            else {
                                this.hsiMonthly(disc.productType, disc.discountDescription, modemValue, disc.discountRate, 'AddOn Discount RCD');
                            }
                        }
                    } else {
                        this.otcTotal(disc.productType, disc.discountDescription, modemValue, disc.discountRate, 'AddOn Discount OTC');
                    }
                })
            }
            if (this.CORSummary !== undefined && this.CORSummary.customerOrderSubItems !== undefined && this.CORSummary.customerOrderSubItems.length > 0) {
                // For Transfer of Responsibility to OTC Cart
                offerList = this.CORSummary.customerOrderSubItems;
                for (let i = 0; i < offerList.length; i++) {
                    if (offerList[i] === null || offerList[i] === undefined) {
                        continue;
                    }
                    type = offerList[i].productCategory;
                    name = offerList[i].productName;
                    if (offerList[i].productAttributes.length > 0) {
                        for (let j = 0; j < offerList[i].productAttributes.length; j++) {
                            if (!offerList[i].productAttributes[j].isPriceable) {
                                continue;
                            }
                            modem = offerList[i].productAttributes[j];
                            if (modem !== undefined) {
                                if (modem.compositeAttribute && modem.compositeAttribute.length > 0) {
                                    modemValue = type === 'CORE' ? offerList[i].productName :
                                        modem.compositeAttribute[0].attributeValue;
                                    if (name === GenericValues.modem) {
                                        modem.compositeAttribute.forEach(attr => {
                                            if (attr.attributeName === 'Account Type') {
                                                modemValue = attr.attributeValue;
                                            }
                                        })
                                    }
                                }
                                for (let k = 0; k < modem.prices.length; k++) {
                                    let priceable = modem.prices[k];
                                    if (priceable.priceType === GenericValues.pPriceType) {
                                        if (this.CORSummary && this.CORSummary.offerType)
                                            modemValue = this.CORSummary.offerType.indexOf('BILLING_COR') !== -1 ? undefined : modemValue;
                                        this.populateValues(modem, modemValue, type, name, modem.prices[k], GenericValues.sData);
                                        this.otc = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            this.monthlyTotal = (this.totalHSI + this.totalTV + this.totalDHP) - this.discountPrice;
        }
        if (data.terminationFee && data.terminationFee.length > 0) {
            this.oneTimeCharge = [];
            this.installmentBilling = [];
            this.hsiMonthlyCharge = [];
            this.discountMonthlyCharge = [];
            this.tvMonthlyCharge = [];
            this.dhpMonthlyCharge = [];
            this.totalOTC = 0;
            this.totalHSI = 0;
            this.totalTV = 0;
            this.totalDHP = 0;
            this.monthlyTotal = 0;
            this.discountPrice = 0;
            for (let item of data.terminationFee) {
                if (item.price !== 0) {
                    this.termination = true;
                    this.otcTotal("termination", item.description,
                        '', item.price, '');
                }
            }
        }
        if (data.Otc && data.Otc.length > 0) {
            this.otc = true;
            for (let item of data.Otc) {
                this.otcTotal("otc", item.name, item.selected, item.price, item.max, item.quantity);
            }
        } else {
            this.otcTotal("otc", '', '', 0, '', '');
        }
        let isStack = this.existingData && this.existingData.stackamend && this.existingData.stackamend.stackAmendFlag === 'stackOrder';
        if(data.waivedOtcInfo && data.waivedOtcInfo.otcWaiverList && data.waivedOtcInfo.otcWaiverList.reason && !isStack) {
            this.otcTotal("waivedOtc", data.waivedOtcInfo.otcWaiverList.reason.description, '', data.waivedOtcInfo.totalWaivedOtc, '', '');
        }
        if (data.selectedReferral && data.selectedReferral !== undefined) {
            if (data.price !== 0) {
                this.referral = true;
                this.otcTotal("referral", data.selectedReferral, '', data.price, '', '');
            }
        } else if (data.selectedReferral === undefined) {
            this.referral = false;
            if (data.price !== 0) {
                this.otcTotal("referral", '', '', 0, '', '');
            }
        }
        this.setCurrPrevOtc(this.totalOTC);
        this.blink = true;
        setTimeout(() => {
            this.blink = false;
        }, 2000
        );
    }

    public populateValues(modem: AttributesCombination, modemValue: string, type: string, name: string, prices: Prices, category: string) {
       if (prices.rc === 0) {
            if (prices.discountedOtc === 0) { if (prices.otc !== 0) { this.otcTotal(type, name, modemValue, prices.otc, category); } } else {
                if (prices.discountedOtc !== 0) { this.otcTotal(type, name, modemValue, prices.discountedOtc, category); }
            }
        } else {
            this.hsiMonthly(type, name, modemValue, prices.rc, category);
        }

    }

    public fetchValue(serviceCharacteristic: ServiceCharacteristic[], filterBy: string): string {
        let val: string;
        serviceCharacteristic && serviceCharacteristic.map(
            (value) => {
                if (value.name === filterBy) {
                    val = value.value;
                }
            }
        );
        return (val === undefined || val === null) ? '0' : val;
    }

    public filterValues(compositeAttribute: CompositeAttribute[], filterBy: string): string {
        let val: string;
        let x: string;
        compositeAttribute && compositeAttribute.forEach((value) => {
            if (value.attributeName === filterBy) {
                if (filterBy === GenericValues.downspeed || filterBy === GenericValues.upspeed) {
                    x = value.attributeDisplayName.slice(4, value.attributeDisplayName.length);
                    val = x;
                } else {
                    val = value.attributeDisplayName
                }
            }
        })
        return (val === undefined || val === null) ? '0' : val;
    }

    public hsiMonthly(type: string, name: string, catalogValue: string, price: number, category: string) {
        if (category === GenericValues.sData || type === 'DATA ADDON OFFER') {
            this.totalHSI += price;
        }
        if (type === 'CORE') {
            return this.hsiMonthlyCharge.push(catalogValue + ',' + price);
        }
        if (type === 'DISCOUNT') {
            this.discountPrice += price;                  
            this.discountItemDesc.push(name);
            return this.discountMonthlyCharge.push(name + ',' + price);
        }
        if (category === 'AddOn Discount RCD') {
            this.closersAndPromosDiscounts = true;
            this.totalHSI -= price;
            return this.hsiMonthlyCharge.push(name + ',' + price);
        } else if (category === 'Pots AddOn Discount RCD') {
            this.closersAndPromosDiscounts = true;
            this.totalDHP -= price;
            return this.dhpMonthlyCharge.push(name + ',' + price);
        } else {
            this.closersAndPromosDiscounts = false;
        }
        if (name === 'Intrastate Service Fee') {
            return this.hsiMonthlyCharge.push(name + ',' + price);
        } else if (type === 'VIDEO' || type === 'VIDEO ADDON OFFER') {
            this.totalTV += price;
            return this.tvMonthlyCharge.push(name + ',' + price);
        } else if ((type === 'DHP' || type === 'DHP ADDON OFFER' || type === 'HP ADDON OFFER') && name && name !== null && name !== '' && price) {
            this.totalDHP += price;
            if ((name === "First Phone" || name.indexOf("1 Pty Residence") !== -1) || (name.indexOf("1 Pty Res. Line") !== -1) && this.dhpSummary &&
                (this.dhpSummary.offerDisplayName.indexOf("1 Pty Residence") !== -1 || this.dhpSummary.offerDisplayName.indexOf("1 Pty Residence Line with Metro Calling") !== -1 ||
                this.dhpSummary.offerType === "NON_BUNDLE" || this.dhpSummary.offerName === "Home Phone Unbundled")) {
                // Do not add 'first phone' in summary as we have added individual summary details for this item
                return;
            }
            if(name === "Price for Life Internet, Voice Package with ULD") { name = 'Price for Life Internet'; }
            return this.dhpMonthlyCharge.push(name + ',' + price);
        } else {
            if (type === 'hsi-vac-discount') {
                this.totalHSI -= price;
                this.discountItemDesc.push(name + ' (' + catalogValue + ')');
                // return this.hsiMonthlyCharge.push(name + ' (' + catalogValue + '),' + price); // TODO /L2OESO-20669
                return this.hsiMonthlyCharge.push(name + ',' + price);
            } else if(name === GenericValues.secureWifiComponent) {
                return this.hsiMonthlyCharge.push(name+',' + price);
            } else {
                return this.hsiMonthlyCharge.push(name + ' (' + catalogValue + '),' + price);
            }
        }
    }

    public otcTotal(type: string, name: string, catalogValue: string, price: number, category: string, subItems?: any) {
        if (type === 'DATA ADDON OFFER' || type === 'DHP ADDON OFFER' || type === 'HP ADDON OFFER') {
            if (name !== '' && price !== null && subItems && subItems !== undefined && subItems.quantity && subItems.quantity !== null) {
                if (name === "Tech-Install without Modem") {
                    this.totalOTC += (1 * price);
                    return this.oneTimeCharge.push(name + ' (' + 1 + '*$' + price.toFixed(2) + ')' + ',' + (1 * price));
                } else {
                    this.totalOTC += (subItems.quantity * price);
                    return this.oneTimeCharge.push(name + ' (' + subItems.quantity + '*$' + price.toFixed(2) + ')' + ',' + (subItems.quantity * price));
                }
            }
            else {
                if (price && price.toFixed(2)) {
                    this.totalOTC += +price.toFixed(2);
                }
                return this.oneTimeCharge.push(name + ',' + price.toFixed(2));
            }
        } else {
            if (category !== 'AddOn Discount OTC') {
                if (type === 'otc') {
                    this.totalOTC += +price.toFixed(2);
                } else if(type === 'waivedOtc') {
                    this.totalOTC -= +price.toFixed(2);
                } else {
                    this.totalOTC += price;
                }
            }
            if (name === 'JACK' || type === 'VIDEO' || type === 'HP ADDON OFFER'
                || type === 'VIDEO ADDON OFFER' || type === 'SHIPPING') {
                return this.oneTimeCharge.push(name + ',' + price);
            }
            else if (type === 'termination') {
                if (name !== '' && price !== null) {
                    return this.oneTimeCharge.push(name + ',' + price);
                }
            }
            else if (type === 'otc') {
                if (name !== '' && price !== null) {
                    this.findAndReplace(name);
                    return this.oneTimeCharge.push(subItems + ' ' + name + '(' + '1' + ' of ' + catalogValue + '),' + price);
                }
            } else if(type=== "waivedOtc") {
                if(name !== '' && price !== null && price > 0) {
                    return this.oneTimeCharge.push(name + ',' + price);
                }
            }else if (type === 'referral' && price !== 0 && name !== '') {
                return this.oneTimeCharge.push(name + ',' + price);
            }
            else if (category === 'AddOn Discount OTC') {
                this.totalOTC -= price;
                return this.oneTimeCharge.push(name + ',' + price)
            }
            else {
                if (name !== '' && price && price !== 0 && catalogValue) {
                    return this.oneTimeCharge.push(name + ' (' + catalogValue + '),' + price);
                } else if (name !== '' && price && price !== 0) {
                    return this.oneTimeCharge.push(name + ',' + price.toFixed(2));
                }
            }
        }
    }

    public findAndReplace(name) {
        this.oneTimeCharge.forEach((x) => {
            if (x.indexOf(name) !== -1) {
                let price = x.substring(x.lastIndexOf(',') + 1, x.length);
                this.totalOTC -= +price;
            }
        })
        this.oneTimeCharge = this.oneTimeCharge.filter((x) => {
            return x.indexOf(name) === -1;
        })
    }

    public value(oneTime: string, i: number, disc?) {
        
        // let value;
        if (oneTime) {
            // value = oneTime.split(',');
            if(i === 0) {
                return oneTime.slice(0,oneTime.lastIndexOf(','));
            } else {
                return oneTime.slice(oneTime.lastIndexOf(',')+1,oneTime.length);
            }
            // return value[i] && value[i] !== 'undefined' ? value[i] : 0;
        }
        return '';
    }

    public filterOffer(data: OfferProductComponents[], type: string) {
        let modem: AttributesCombination;
        data.forEach((item) => {
            if (item.product.productName === type) {
                modem = item.product.productAttributes[0];
            }
        });
        return modem;
    }

    public filterCategorybyType(customerOrderItems: CustomerOrderItems[], filterBy: string, flag?: boolean): CustomerOrderItems {
        let customerOrderItem: CustomerOrderItems;
        customerOrderItems.forEach((items) => {
            if ((items.productType === filterBy) || (filterBy === GenericValues.cHP && items.productType === 'HP ADDON OFFER')) {
                customerOrderItem = items;
            }
            else if (items && items.offerType && items.offerType === "BILLING_CORPOTS" && items.offerCategory === GenericValues.cHP && flag) {
                customerOrderItem = items;
            }
            else if (items && items.offerType && items.offerType === "BILLING_CORINT" && items.offerCategory === "CHANGERES" && flag) {
                if (filterBy === GenericValues.sData || filterBy === GenericValues.iData) {
                    customerOrderItem = items;
                }
            }
            else if (items && items.offerType && items.offerType !== "SUBOFFER" && items.offerType !== "BILLING_CORINT"
                && items.offerType !== "BILLING_CORPOTS" && this.orderFlow === "COR") {
                if (items.offerCategory === GenericValues.iData && filterBy === GenericValues.iData) {
                    customerOrderItem = items;
                }
                else if (items.offerCategory === GenericValues.cDHP && filterBy === GenericValues.cDHP) {
                    customerOrderItem = items;
                }
                else if (items.offerCategory === GenericValues.cHP && filterBy === GenericValues.cHP) {
                    customerOrderItem = items;
                }
            }
            if (this.isVacSusFlow) {
                if (items.offerCategory === filterBy && items.offerType !== 'SUBOFFER') {
                    if (flag && items.offerName && (items.offerName.toUpperCase() === VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase())) {
                        this.internetSummary = items;
                        customerOrderItem = items;
                    } else if(!flag && items.offerName && (items.offerName.toUpperCase() !== VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase())) {
                        this.vacSusExistsinternetSummary = items;
                        customerOrderItem = items;
                    }
                }
                if(items.offerName && (items.offerName.toUpperCase() === VacationEnums.POTS_VAC_SUS_OFFER_NAME.toUpperCase())) {
                    customerOrderItem = items;
                }
                if(items.offerCategory === GenericValues.cDHP) {
                    customerOrderItem = undefined;
                }
            }
        });
        return customerOrderItem;
    }

    public selectedCategory(category: string) {
        this.selectedValue = category;
    }

    public getAddOnsbyCategory(customerOrderItems: CustomerOrderItems[],
        filterBy: string): CustomerOrderItems[] {
        let customerOrderItem: CustomerOrderItems[] = [];
        customerOrderItems && customerOrderItems.forEach((items) => {
            if (items.offerCategory === filterBy) {
                customerOrderItem.push(items);
            }
        });
        return customerOrderItem;
    }

    public ngOnDestroy() {
        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.cartSub !== undefined) {
            this.cartSub.unsubscribe();
        }
        if (this.updateTotalOtcSubscription !== undefined){
            this.updateTotalOtcSubscription.unsubscribe();
        }
    }

    public setCurrPrevOtc(totalOTC) {
        if (this.prevTotalOtc !== totalOTC) {
            if (!isNaN(this.prevTotalOtc) && this.prevTotalOtc > totalOTC) {
                this.diffOtc = this.prevTotalOtc - totalOTC;
                this.updateTotalOtcSubject.next(this.diffOtc);
            }
            this.prevTotalOtc = totalOTC;
        }
    }

    public checkWaiveDiscount(diffotc) {
        let subitems = [];
        if (this.cartData && this.cartData.payload && this.cartData.payload.cart && this.cartData.payload.cart.customerOrderItems) {
            this.cartData.payload.cart.customerOrderItems.map((item) => {
                item.customerOrderSubItems.map((subitem) => {
                    subitems.push(subitem);
                })
            });
        } else if (this.cartData && !this.cartData.payload) {
            this.payloadNotReady = true;
            return;
        }

        if (this.waivedOtcInfo && this.waivedOtcInfo.otcWaiverList && this.waivedOtcInfo.otcWaiverList.waivers &&
            this.waivedOtcInfo.otcWaiverList.waivers.length > 0) {
            let waiver = this.waivedOtcInfo.otcWaiverList.waivers.filter((waiver) => {
                let filterWaiver = false;
                subitems.forEach((si) => {
                    if ((si.productName === GenericValues.modem||si.productName === GenericValues.install) && waiver.productName === si.productName) {
                        if (si.productAttributes && si.productAttributes.length > 0 && si.productAttributes[0].compositeAttribute && si.productAttributes[0].compositeAttribute.length > 0) {
                            si.productAttributes[0].compositeAttribute.forEach((ca) => {
                                if(si.productName === GenericValues.modem){
                                    if (ca.attributeName === GenericValues.accountType && ca.attributeValue === GenericValues.purchasedModem) {
                                        filterWaiver = true;
                                    }
                                } else if(si.productName === GenericValues.install){
                                    if (ca.attributeName === GenericValues.serviceLevel && ca.attributeValue !== GenericValues.selfInstall) {
                                        filterWaiver = true;
                                    }
                                }
                                
                            })
                        }
                    } else if (waiver.productName === si.productName) {
                        filterWaiver = true;
                    }
                });
                return filterWaiver;
            });
            if (waiver.length < this.waivedOtcInfo.otcWaiverList.waivers.length) {
                this.waivedOtcInfo.otcWaiverList.waivers = waiver;
                this.waivedOtcInfo.totalWaivedOtc = this.waivedOtcInfo.totalWaivedOtc - diffotc;
                if (waiver.length === 0) {
                    this.waivedOtcInfo.otcWaiverList.reason = {};
                }
                this.store.dispatch({ type: 'WAIVED_OTC_INFO', payload: this.waivedOtcInfo });
            }

        }
    }
}