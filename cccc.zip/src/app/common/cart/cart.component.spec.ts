import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartSummaryComponent as CartComponent} from './cart.component';
import { MockServer } from 'app/MockServer.test';
import { Observable, of } from 'rxjs';
import { Store } from '@ngrx/store';
import { AppStateService } from '../service/app-state.service';
import { AccountService } from '../service/account.service';
import { MockAccountService } from '../service/mockServices.test';

describe('CartComponent', () => {
  let component: CartComponent;
  let fixture: ComponentFixture<CartComponent>;
  const mockServer = new MockServer();

  const imports = [

  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }
  class MockAppStateService{
    setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE');
    }
  }

  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const accountService = { provide: AccountService, useClass: MockAccountService };

  const providers = [
    store, appStateService, accountService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [ CartComponent ],
    providers: providers
  }

  describe('Ni Flow', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(CartComponent);
      component = fixture.componentInstance;
      component.userEvent = of(mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user']);
      fixture.detectChanges();
    });

    it('should create component for NI HSI and POTS', () => {
      expect(component).toBeTruthy();
    });
  
    it('should `CartSummary` can be created ', () => {
        expect(component.internetSelected).toBe(true);
    });
  
    it('should `CartSummary` set selectedCategory ', () => {
        const selected = 'Internet';
        component.selectedCategory(selected);
        expect(component.selectedValue).toBe(selected);
    });
  
    it('should `CartSummary` call onDestroy ', () => {
        const returnVal = component.ngOnDestroy();
        expect(returnVal).toBeUndefined();
    });

    it('should call getIndividualPricesForHP ', () => {
        const returnVal = (component as any).getIndividualPricesForHP(null);
        expect(returnVal).toBeUndefined();
    });

    it('should call getMaxSpeed', () => {
        const returnVal = (component as any).getMaxSpeed(null);
        expect(returnVal).toBeUndefined();
    });

    it('should call getMaxSpeed', () => {
        const returnVal = component.getAddOnsbyCategory(null, null);
        expect(returnVal).toEqual([]);
    });

    it('should call filterOffer', () => {
        const returnVal = component.filterOffer(null, null);
        expect(returnVal).toBeUndefined();
    });

    it('should call filterValues', () => {
        const returnVal = component.filterValues(null, null);
        expect(returnVal).toBe('0');
    });

    it('should call findAndReplace', () => {
        const returnVal = component.findAndReplace('');
        expect(returnVal).toBeUndefined();
    });

    it('should call checkWaiveDiscount', () => {
        const returnVal = component.checkWaiveDiscount(null);
        expect(returnVal).toBeUndefined();
    });

  });

  describe('Vacation Suspend Flow', () => {
    const mockRedux: any = {
      dispatch(action) {},
      configureStore() {},
      select(reducer) {
          return of(
              mockServer.getMockStore("VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
          return of(null);
      }
    }
    class MockAppStateService{
      setLocationURLs() {
          return null;
      }
      getState () {
          return mockServer.getMockStore('VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE');
      }
    }

    const store = { provide: Store, useValue: mockRedux };
    const appStateService = { provide: AppStateService, useClass: MockAppStateService };

    const _providers = [...providers, store, appStateService];

    const baseConfig = {
      imports: imports,
      declarations: [ CartComponent ],
      providers: _providers
    }

    beforeEach(async(() => {
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(CartComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
    
    it('should create component for VS flow', () => {
      expect(component).toBeTruthy();
    });
  });

});
