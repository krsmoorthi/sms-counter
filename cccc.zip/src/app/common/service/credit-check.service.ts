import { BlueMarbleService } from './bm.service';
import { Injectable } from '@angular/core';

@Injectable()
export class creditService {
    constructor(public bMService: BlueMarbleService) { }
    public paymentRequest(payload: any){
        return this.bMService.changeSubmitTask(payload);
    }
    public paymentRequestMove(payload: any){
        return this.bMService.movePaymentSubmitTask(payload);
    }
}
