import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { ShoppingCart } from '../models/cart.model';
import { AppStateService } from './app-state.service';
import { BlueMarbleService } from './bm.service';
import { Products } from '../models/product.model';
import { GenericValues } from '../models/common.model';
import { env } from '../../../environments/environment';
@Injectable()
export class ProductService {

    constructor(
        public bMService: BlueMarbleService,
        public appStateService: AppStateService,
        public store: Store<AppStore>) {
    }

    /**
     * Bundle offer page Service calls
     */
    public giftCardEligibilityAndRelation(item: any) {
        this.store.dispatch({ type: 'E_GIFTCARDS', payload: item });
        return this.bMService.cardEligibility(item);
    }

    public getOffers(item: any, flow?) {
        let validAddressInput = this.getOfferRequest(item);
        this.store.dispatch({ type: 'SELECT_PRODUCT', payload: validAddressInput });
        return this.bMService.submitTask(validAddressInput, flow);
    }

    public getExpOffers(item: any, flow?) {
        return this.bMService.submitTask(item, flow);
    }
    public getBillingRecOffers(item: any, flag?) {
        let validAddressInput = this.getBillingRecOfferRequest(item);
        this.store.dispatch({ type: 'SELECT_PRODUCT', payload: validAddressInput });
        return this.bMService.billingSubmitTask(validAddressInput, flag);
    }

    public updateCart(item: ShoppingCart, orderFlow?, potsBooleans?, e911ValidatedAddress?) {
        let cartValues = item;
        this.store.dispatch({ type: 'ADD-ONS', payload: cartValues });
        this.store.dispatch({ type: 'ADD-ONS_POTS', payload: potsBooleans });
        this.store.dispatch({ type: 'ADD-ONS_E911', payload: e911ValidatedAddress });
        return this.bMService.submitTask(cartValues, orderFlow);
    }

    public updateChangeCart(item: ShoppingCart, potsBooleans?, e911ValidatedAddress?, isRestoreFlow?) {
        let cartValues = item;
        this.store.dispatch({ type: 'ADD-ONS', payload: cartValues });
        this.store.dispatch({ type: 'ADD-ONS_POTS', payload: potsBooleans });
        this.store.dispatch({ type: 'ADD-ONS_E911', payload: e911ValidatedAddress });
        if(!isRestoreFlow) {
            return this.bMService.changeSubmitTask(cartValues);
        } else {
            return this.bMService.vacationSubmitTask(cartValues);
        }
    }

    public updateBillingCart(item: ShoppingCart, potsBooleans?) {
        let cartValues = item;
        this.store.dispatch({ type: 'ADD-ONS', payload: cartValues });
        this.store.dispatch({ type: 'ADD-ONS_POTS', payload: potsBooleans });
        return this.bMService.billingSubmitTask(cartValues);
    }

    public getResponseForRemove(request: any) {
        return this.bMService.getRemoveChange(request);
    }

    public getCarrierInfo(url: string) {
        let _env = env.production ? `${env.INTRANET}` : `${env.BUILD_NAME}`;
        let res = url.indexOf(_env);
        let strpl = url.substring(res + _env.length, url.length);
        return this.bMService.getCarrierInfo(strpl);
    }

    public getOfferRequest(item: any) {
        let serviceCategory = [];
        if(item && item !== undefined && item.enabledServiceList && item.enabledServiceList !== undefined){
        item.enabledServiceList.forEach((element) => {
            if(this.fetchCategory(element, item))
            serviceCategory.push({
                serviceCategory: element.serviceCategory
            });
        });
    }
        let offerRequest: any = {
            orderRefNumber: item.orderRefNumber,
            taskId: item.taskId,
            processInstanceId: item.processInstanceId,
            taskName: item.taskName,
            payload:
            {
                offerBillingType: item.offerBillingType,
                serviceCategory: serviceCategory,
                filterCriteria : item.filterCriteria
            }
        };
        return offerRequest;
    }

    public fetchCategory(element, item) {
        let flag = false;
        if(element.serviceCategory === GenericValues.cHP && item.phoneSelected === 'HMP') flag = true
        else if(element.serviceCategory === GenericValues.cDHP && item.phoneSelected === 'DHP') flag = true
        else if(element.serviceCategory === GenericValues.cDTV && item.videoSelected === 'DTV') flag = true
        else if(element.serviceCategory === GenericValues.sData && item.internet) flag = true
        return flag;
    }
    public getBillingRecOfferRequest(item: any) {
        let serviceCategory = [];
        item.enabledServiceList.forEach((element) => {
            serviceCategory.push({
                serviceCategory: element.serviceCategory
            });
        });
        let offerRequest: any = {
            orderRefNumber: item.orderRefNumber,
            taskId: item.taskId,
            processInstanceId: item.processInstanceId,
            taskName: item.taskName,
            payload: {
                serviceCategory: serviceCategory
            }
        };
        return offerRequest;
    }

    public getCustomizeAddons(request: any) {
        return this.bMService.submitTask(request);
    }

    public getResponseForCheckOut(request: any, flag?: string) {
        if (flag === 'change') {
            this.store.dispatch({ type: 'SCHEDULING', payload: request });
            return this.bMService.changeSubmitTask(request);
        }
        else if (flag === 'move') {
            this.store.dispatch({ type: 'SCHEDULING', payload: request });
            return this.bMService.submitTask(request, flag);
        }
        else if (flag === 'billing') {
            this.store.dispatch({ type: 'SCHEDULING', payload: request });
            return this.bMService.billingSubmitTask(request, true);
        }
        else {
            this.store.dispatch({ type: 'SCHEDULING', payload: request });
            return this.bMService.submitTask(request);
        }
    }

    public getOffersFromLink(link: string) {
        let res = link.indexOf('baseURL/');
        let strpl = link.substring(res + 8, link.length);
        return this.bMService.getOffersFromLink(strpl);
    }

    public getE911APICall(request: any) {
        return this.bMService.getE911API(request);
    }

    public getAvailableTNs(request: any) {
        return this.bMService.getAvailableTNs(request);
    }

    public getAvailableNumber(request: any) {
        return this.bMService.getAvailableNumber(request);
    }

    public getPotsTnAvailability(request: any) {
        return this.bMService.getPotsTnAvailability(request);
    }

    public getNPANXXList(request: any) {
        return this.bMService.getNPANXXList(request);
    }

    public doReserveTN(request: any) {
        return this.bMService.reserveTNCall(request);
    }

    public doReleaseTN(request: any) {
        return this.bMService.releaseTNCall(request);
    }

    public findObjByName(list, fieldName, fieldVal, fieldName1 = undefined,
        fieldVal1 = undefined, prefix = undefined) {
        let foundObj;
        try {
            if (fieldName1 && fieldVal1 && prefix) {
                foundObj = list.find((obj) => {
                    return obj[prefix][fieldName] === fieldVal &&
                        obj[prefix][fieldName1].indexOf(fieldVal1) !== -1;
                });
            } else {
                foundObj = list.find((obj) => {
                    return obj[fieldName] === fieldVal;
                });
            }
        } catch (exception) {
        }
        return foundObj;
    }

    public getE911Response(): any {
        let currentStore = this.appStateService.getState();
        let userData: any = currentStore.user;
        let request = {
            streetDirectionPrefix: '',
            streetAddress: '',
            location: '',
            streetNrFirst: '',
            city: '',
            stateOrProvince: '',
            postCode: '',
            postCodeSuffix: ''
        };
        let existingData = currentStore.existingProducts;

        if (existingData && existingData.orderFlow && (existingData.orderFlow.flow === 'Change' || existingData.orderFlow.flow === 'billing')) {
            if (existingData && existingData.existingProductsAndServices[0] && existingData.existingProductsAndServices[0].serviceAddress) {
                let address = existingData.existingProductsAndServices[0].serviceAddress;
                request = {
                    streetDirectionPrefix: '',
                    streetAddress: address.streetName,
                    location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
                    streetNrFirst: address.streetNrFirst,
                    city: address.city ? address.city : address.locality,
                    stateOrProvince: address.stateOrProvince,
                    postCode: address.postCode,
                    postCodeSuffix: address.postCodeSuffix
                };

            }
        }

        
        else if (userData && userData.orderInit && userData.orderInit.payload && userData.orderInit.payload.newLocation
            && userData.currentUrl === '/move-product') {
            let address = userData.orderInit.payload.newLocation.serviceAddress;
            request = {
                streetDirectionPrefix: '',
                streetAddress: address.streetName,
                location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
                streetNrFirst: address.streetNrFirst,
                city: address.city ? address.city : address.locality,
                stateOrProvince: address.stateOrProvince,
                postCode: address.postCode,
                postCodeSuffix: address.postCodeSuffix
            };
        }
        else if (userData && userData.orderInit && userData.orderInit.payload.serviceAddress) {
            let address = userData.orderInit.payload.serviceAddress;
            request = {
                streetDirectionPrefix: '',
                streetAddress: address.streetName,
                location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
                streetNrFirst: address.streetNrFirst,
                city: address.city ? address.city : address.locality,
                stateOrProvince: address.stateOrProvince,
                postCode: address.postCode,
                postCodeSuffix: address.postCodeSuffix
            };
        }
        this.store.dispatch({ type: 'E911_ADDRESS_REQUEST', payload: request });
        return this.getE911APICall(request);
    }

    public getPhoneDisplayName(offer): string {
        let val = '';
        if (offer && offer.productOffer && offer.productOffer.productComponents) {
            offer.productOffer.productComponents.map(data => {
                if (data.componentType === 'PRIMARY') {
                    val = data.product.productDisplayName
                }
            })
        }
        return val;
    }
  
    public getTnPortingStatus(request: any) {
        return this.bMService.doTnPortingCheck(request);
    }

    public getCompatibilityRules(toGetHoldDetails?: boolean) {
        return this.bMService.getCompatibilityRules(toGetHoldDetails);
    }

    public getCSCompatibilityRules() {
        return this.bMService.getCSCompatibilityRules();
    }

    public getSwitchByTN(tn) {
        let request = {
            "request": [
                {
                    "productType": "VOICE-HP",
                    "tn": tn
                }
            ]
        }
        return this.bMService.getSwitchByTN(request);
    }

    public getCommunityRules() {
        return this.bMService.getCommunityRules();
    }
    public getCompatibilityRulesforClosers(closerandpromosReq) {
        return this.bMService.getCompatibilityRulesforClosers(closerandpromosReq);
    }
    public getBypassGiftCards(requestPayload)
    {
        return this.bMService.getBypassGiftCards(requestPayload)
    }

    public getBypassInternetDiscounts(requestPayload){
        return this.bMService.getBypassInternetDiscounts(requestPayload);
    }

    public getOfferDisplayName(request) {
        return this.bMService.getOfferDisplayName(request);

    }

    public getLATA(offerName, ruleId, wireCenter, city, state) {
        let request = this.getLATAByRule(offerName, ruleId, wireCenter, city, state);
        return this.bMService.getLATA(request);
    }

    public getLATAByRule(offerName, ruleId, wireCenter, city, state) {
        let request = {
            "inputAttribute": [
                {
                  "attributeName": "RuleType",
                  "attributeValue": [
                    "LDCarrierRule"
                  ]
                },
                {
                    "attributeName": "wireCenter",
                    "attributeValue": [
                      wireCenter
                    ]
                  },
                  {
                    "attributeName": "city",
                    "attributeValue": [
                      city
                    ]
                  },
                  {
                    "attributeName": "state",
                    "attributeValue": [
                      state
                    ]
                  }
              ],
            "outputAttribute": [
                {
                    "attributeName": "mainOfferName"
                },
                {
                    "attributeName": "interLataPIC1"
                },
                {
                    "attributeName": "interLataPIC2"
                },
                {
                    "attributeName": "intraLataPIC1"
                },
                {
                    "attributeName": "intraLataPIC2"
                },
                {
                    "attributeName": "defaultIntraLataPIC"
                },
                {
                    "attributeName": "defaultInterLataPIC"
                }
            ],
            "requestDate": "",
            "ruleId": ruleId
        }
        return request;
    }

    public getHolidaysDate(request) {
        return this.bMService.getHolidaysDate(request);
    }

    public getFreezeDropDown(): any {
        let request = {
            "inputAttribute":
                [
                    {
                        "attributeName": "ruleName",
                        "attributeValue": ["picFreezeRule"]
                    },
                    {
                        "attributeName": "LOV",
                        "attributeValue": ["Not Added", "Remove Freeze", "Add Freeze", "Freeze is active"]
                    }
                ],
            "outputAttribute":
                [
                    {
                        "attributeName": "ruleName"
                    },

                    {
                        "attributeName": "freezeType"
                    },

                    {
                        "attributeName": "freezePresent"
                    },

                    {
                        "attributeName": "LOV"
                    }
                    ,

                    {
                        "attributeName": "default"
                    }
                ],
            "requestDate": "",
            "ruleId": "131"
        }
        return this.bMService.getFreezeDropDown(request);
    }

    public getTechnologyTypes() {
        return this.bMService.getTechnologyTypes();
    }

    public getRccDisclosure(payload: any) {
        return this.bMService.getRccDisclosure(payload);
    }
    public checkDiscountExists(product: Products, subType: any, value?:any, discArray?, discountSelected?,pricekeySelectedValue?, selectedModem?) {
        let flag = false;        
        discArray && discArray.map(disc => {
            if ((disc.productName === subType || (selectedModem && subType === GenericValues.secureWifiComponent)) || value) {
                disc.selected = false;
                flag = false;
                product && product.productAttributes && product.productAttributes.map(attr => {
                    if (attr.isPriceable && attr.discounts !== null && attr.discounts && attr.discounts.length !== 0) {
                        attr.discounts.forEach(discount => {
                            if (disc.discountId === discount.discountId) {
                                disc.selected = true;
                                flag = true;
                            }
                        });
                    }
                });
            }
        });           
        if (!discountSelected && !flag && discArray && discArray.length > 0) { discountSelected = true; }
        return {discountSelected,discArray}        
    }

}
