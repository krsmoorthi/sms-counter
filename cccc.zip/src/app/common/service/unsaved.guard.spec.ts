import { inject, TestBed } from '@angular/core/testing';
import { UnsavedGuard } from './unsaved.guard';
xdescribe('UnsaveGuard', () => {
  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        UnsavedGuard]
    });
  });
  it('Should call canDeactivate true...', inject([UnsavedGuard], (unSavedGuard: UnsavedGuard) => {
    let component: any = {
      hasUnsavedChanges() {
        return true;
      }
    };
    const service = unSavedGuard.canDeactivate(component)
    expect(service).toBeDefined;
  }));
  it('Should call canDeactivate false...', inject([UnsavedGuard], (unSavedGuard: UnsavedGuard) => {
    let component: any = {
      hasUnsavedChanges() {
        return false;
      }
    };
    const service = unSavedGuard.canDeactivate(component)
    expect(service).toBeDefined;
  }));

});