import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/catch";

@Injectable()
export class AppConfig {

    private config: any;

    constructor(private http: HttpClient) {

    }

    /**
     * Use to get the data found in the second file (config file)
     */
    public getConfig() {
        return this.config;
    }



    /**
     * This method:
     *   a) Loads "env.json" to get the current working environment (e.g.: 'production', 'development')
     *   b) Loads "config.[env].json" to get all env's variables (e.g.: 'config.development.json')
     */
    public load() {
        return new Promise((resolve, reject) => {
            this.http.get('config.json').map((res:any) => res).catch((error: any): any => {
                resolve(true);
                return Observable.throw('Server error');
            }).subscribe((envResponse) => {
                this.config = envResponse;
                resolve(true);
            });

        });
    }
}