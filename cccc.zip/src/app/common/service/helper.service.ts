import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from './app-state.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { AppStore } from 'app/common/models/appstore.model';
import { AutoLogin } from 'app/common/models/auto-login.model';
import { User } from 'app/common/models/user.model';
import { AuthService } from 'app/common/service/auth.service';
import { Profile, SecurityElement } from 'app/common/models/profile.model';

@Injectable()

export class HelperService {
    private user: Observable<User>;
    private userSubscription: Subscription;

    constructor(
        public store: Store<AppStore>,
        private router: Router,
        private authService: AuthService,
        private appStateService: AppStateService
    ) {
        this.user = <Observable<User>>store.select('user');
    }

    public addressEditingEnabled() {
        if (this.isAuthorized(ProfileEnums.ESHOP_STD)) {
            return true;
        }
        else {
            return false;
        }
    }

    public startNewOrder() {       
        this.router.navigate(['/home']);
    }

    public startNewOrderWithoutRouting(source: string) {

        // Clean up the autoLogin - OAMData & Profile Data
        var currentUser = {} as User;
        var autoLogin = {} as AutoLogin;
        var maintainFingerprint = false;
        if (this.user) {
            this.userSubscription = this.user.subscribe((data) => {

                // Remove SFC Data if the source type is null
                if (!source && data && data.autoLogin && data.autoLogin.sfcData) {
                    delete data.autoLogin.sfcData;
                }

                // Maintaining AutoLogin and Profile Data
                if (data && data.autoLogin) {
                    autoLogin = cloneDeep(data.autoLogin);
                    currentUser.autoLogin = autoLogin;
                }
                if (data && data.profile) {
                    currentUser.profile = cloneDeep(data.profile);
                }

                if (data && data.properties) {
                    currentUser.properties = cloneDeep(data.properties);
                }

                // Maintaining FingerPrint Data
                if (source && (source === "auto-login")) {
                    currentUser.fingerPrint = cloneDeep(data.fingerPrint);
                    maintainFingerprint = true;
                }
                else if (source && source === "address") {
                    if ((data.autoLogin && data.autoLogin.sfcData) ||
                        !data.orderRefNumber) {
                        currentUser.fingerPrint = cloneDeep(data.fingerPrint);
                        maintainFingerprint = true;
                    }
                }

            });
        }
        this.userSubscription.unsubscribe();

        this.store.dispatch({ type: 'DELETE_USER', payload: '' });
        this.store.dispatch({ type: 'RESET_STORE', payload: '' });
        this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });

        if (!maintainFingerprint) {
            this.authService.getFingerPrint();
        }
    }

    public isAuthorized(lAttributeName: string) {
        let attributeMatchFound = false;
        let returnValue = "false";
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            if (data && data.profile && data.profile.securityElements && data.profile.securityElements.length > 0) {
                for (let entry of data.profile.securityElements) {
                    if (entry.securityElementName === lAttributeName) {
                        attributeMatchFound = true;
                        returnValue = entry.securityElementFlag;
                        break;
                    }
                }
            }
        });

        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }

        if (returnValue === "true") {
            return true;
        }
        else {
            return false;
        }
    }

    public isAuthorizedGiftAndDiscounts(){
        let isAuthorized: boolean = false;
        let authorizedGiftCards: boolean = false;
        let authorizedDiscounts: boolean = false;
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            if (data && data.profile && data.profile.securityElements && data.profile.securityElements.length > 0) {
                for (let entry of data.profile.securityElements) {
                    if (entry.securityElementName === ProfileEnums.OVERRIDE_ORDERTYPE_GIFTCARDS && entry.securityElementFlag === 'true') {
                        authorizedGiftCards = true;
                    } else if(entry.securityElementName === ProfileEnums.OVERRIDE_ORDERTYPE_DISCOUNTS && entry.securityElementFlag === 'true'){
                        authorizedDiscounts = true;
                    }
                }
            }
        });
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if(authorizedGiftCards && authorizedDiscounts){
            isAuthorized = true;
        }
        return isAuthorized;
    }

    public getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    public setCookie(cname, cvalue, domain, exdays) {
        var expires;
        if (exdays === 0) {
            expires="expires=0"
        } 
        else {
            var d = new Date();
            d.setTime(d.getTime() + (exdays*24*60*60*1000));
            expires = "expires="+ d.toUTCString();
        }
        document.cookie = cname + "=" + cvalue + ";" + expires + "; domain=" + domain + ";path=/";
    }
    public appendToCookie(cookieName: string, attributeName: string, attributeValue: string) {
        if (attributeName && attributeValue) {
            let cookieValue = this.getCookie("eshop_oam");
            let updatedCookieValue = cookieValue + "&" + attributeName + "=" + attributeValue;
            let hostName = window.location.hostname.split(".");
            let domain = "." + hostName[hostName.length-2] + "." + hostName[hostName.length-1];

            this.setCookie(cookieName, updatedCookieValue, domain, 0);
        }
    }

    public isLCAddress(): boolean {
        let val = false;
        let store = this.appStateService.getState();
        if(store && store.existingProducts && store.existingProducts.existingProductsAndServices && store.existingProducts.existingProductsAndServices.length > 0) {
            store.existingProducts.existingProductsAndServices.map(data => {
                if(data && data.serviceAddress && data.serviceAddress.source && (data.serviceAddress.source.toUpperCase() === 'MARTENS')) {
                    val = true;
                }
            })
        }
        if(store && store.existingProducts && store.existingProducts.pendingOrders && (store.existingProducts.pendingOrders.length > 0) && store.existingProducts.pendingOrders[0].orderDocument) {
            if(store.existingProducts.pendingOrders[0].orderDocument && store.existingProducts.pendingOrders[0].orderDocument.serviceAddress) {
                if(store.existingProducts.pendingOrders[0].orderDocument.serviceAddress.source.toUpperCase() === 'MARTENS') {
                    val = true;
                }
            }
        }
        return val;
    }

    public processProfileData(profileData: any): Profile {
        let profile = {} as Profile;
        if (profileData.errorResponse) {
            return profile;
        }
        else {
            profile.profileId = profileData.profileId;
            profile.loginType = profileData.loginType;
            let securityElementsArray = new Array() as SecurityElement[];
            for (let entry of profileData.securityElements) {
                let securityElement = {} as SecurityElement;
                securityElement.securityElementName = new String(entry.securityElementName).toUpperCase();
                securityElement.securityElementFlag = entry.securityElementFlag;
                securityElementsArray.push(securityElement);
            }
            profile.securityElements = securityElementsArray;
            return profile;
        }
    }
}
