import { TestBed, async } from "@angular/core/testing";
import { Observable } from 'rxjs/Rx';
import { BlueMarbleService } from './bm.service';
import { Subject } from 'rxjs/Subject';
import { Store } from '@ngrx/store';
import { AccountService } from './account.service';
import { MockBlueMarbleService } from "../../common/service/mockServices.test";
import { MockServer } from '../../MockServer.test';

describe('AccountService', () => {
    let mockServer = new MockServer();
    let accountService: AccountService;
    let mockBMService: MockBlueMarbleService;
    const mockRedux: any = {
        dispatch(action) {},
        configureStore() {},
        select(reducer) {
            return Observable.of(
                mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    }
    let mockStore = {provide: Store, useValue: mockRedux}

    beforeEach(async(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            providers: [
                AccountService,
                { provide: BlueMarbleService, useClass: MockBlueMarbleService },
                mockStore
            ]
        });
    }));

    beforeEach(() => {
        accountService = TestBed.get(AccountService)
        mockBMService = TestBed.get(BlueMarbleService)
    });

    it("should create account.service", () => {
        expect(accountService).toBeDefined();
    });

    it("should emit otcData", () => {
        let mock = new Subject<any>();
        mock.next("TestOtcData");
        accountService.getOtcData(mock);
        expect(accountService.otcData).toEqual(mock);
    });

    it("should emit getAccountData", () => {
        let mock = new Subject<any>();
        mock.next("TestAccountInfo");
        accountService.getAccountData(mock);
        expect(accountService.accountInfo).toEqual(mock);
    });

    it("should call CORSubmitTask", () => {
        spyOn(mockBMService, 'CORSubmitTask');
        accountService.getCreditResponse({}, "COR");
        expect(mockBMService.CORSubmitTask).toHaveBeenCalled();
    });

    it("should call submitTask", () => {
        spyOn(mockBMService, 'submitTask');
        accountService.getCreditResponse({}, "");
        expect(mockBMService.submitTask).toHaveBeenCalled();
    });

    it("should call getPaymentDetails", () => {
        spyOn(mockBMService, 'getPaymentDetails');
        accountService.getPaymentDetails('123');
        expect(mockBMService.getPaymentDetails).toHaveBeenCalled();
    });

    it("should call getInternationalBillingCountryList", () => {
        spyOn(mockBMService, 'getInternationalBillingCountryList');
        accountService.getInternationalBillingCountryList({});
        expect(mockBMService.getInternationalBillingCountryList).toHaveBeenCalled();
    });

    it("should call quickConnectData when getEmailValidated is executed", () => {
        spyOn(mockBMService, 'quickConnectData');
        accountService.getEmailValidated({});
        expect(mockBMService.quickConnectData).toHaveBeenCalled();
    });

    it("should call quickConnectData when saveDtvAccountNo is executed", () => {
        spyOn(mockBMService, 'productConfigCall');
        accountService.saveDtvAccountNo('123','123');
        expect(mockBMService.productConfigCall).toHaveBeenCalled();
    });

    it("should call submittask when getAccInformation is executed", () => {
        spyOn(mockBMService, 'submitTask');
        accountService.getAccInformation({});
        expect(mockBMService.submitTask).toHaveBeenCalled();
    })

});