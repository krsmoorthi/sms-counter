import { Injectable } from '@angular/core';
import { BlueMarbleService } from './bm.service';

@Injectable()
export class DirectvService{
    
  constructor(
      private bMService: BlueMarbleService
    ) { }

    public getLocations(orderReferenceNumber: string) {
      let request = {
        orderReferenceNumber: orderReferenceNumber,
        source: "CRIS"
      };
      return this.bMService.getVendorLocations(request);
    }

    public getDtvSessionInfo(payload: any) {
      return this.bMService.captureDtvRequest(payload);
    }

    public retrieveDtvOrder(payload: any) {
      return this.bMService.retrieveDtvOrder(payload);
    }

  public orderDtvProcess(payload: any) {
    return this.bMService.orderDtvProcess(payload);
  }

  public removeDtvProcess(payload: any, flow?) {
    if (flow.toUpperCase() === 'NEWINSTALL') {
      return this.bMService.submitTask(payload);
    } else if (flow === 'Change') {
      return this.bMService.changeSubmitTask(payload);
    } else if (flow === 'Move') {
      return this.bMService.moveSubmitTask(payload);
    } else if (flow === 'billing') {
      return this.bMService.submitTask(payload, flow);
    } 
    
  }

  public enterDTVManually(payload: any) {
    return this.bMService.enterDTVManually(payload);
  }
}
