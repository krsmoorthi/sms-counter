import { Injectable } from '@angular/core';
import { BlueMarbleService } from './bm.service';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs/Subject';
import { AppStore } from '../models/appstore.model';

@Injectable()
export class PendingOrderService {

    constructor(
        public store: Store<AppStore>,
        public bMService: BlueMarbleService
    ) { }

    public depositData = new Subject<any>();

    public depositRelated$ = this.depositData.asObservable();

    public getDepositAmount(data: any) {
        this.depositData.next(data);
    }

    public getCancelOrderInformation(obj: any) {
        return this.bMService.initSup1(obj);
    }

    public getCancelOrderSubmissionInformation(obj: any) {
        return this.bMService.submitTaskSup1(obj);
    }

    public getOrderSummary(obj: any) {
        this.store.dispatch({ type: 'ORDERNUM', payload: obj });
        return this.bMService.pendingSummary(obj);
    }

    public pendingConfirmReschedule(payload: any) {
        return this.bMService.submitTaskSup2(payload);
    }

    public getOrderProgressStatus(payload: any) {
        return this.bMService.getOrderProgressStatus(payload);
    }

    public getSecurityDepositHistory(ban: any) {
        return this.bMService.getSecurityDepositHistory(ban);
    }

    public getExistingDiscountsByBan(ban: any) {
        return this.bMService.getExistingDiscountsByBan(ban);
    }

    public removeOrderFromHold(obj: any, flow: any) {
        return this.bMService.removeOrderFromHold(obj, flow);
    }

    public supHoldInit(request) {
        return this.bMService.supHoldInit(request);
    }

    public supHoldSubmit(request) {
        return this.bMService.supHoldSubmit(request);
    }    

    public setOrderTypeText(orderType) {
        let customerOrderType = '';
        switch(orderType){
            case "BILLANDREC": {
                customerOrderType = "Billing & Records";
                break;
            }
            case "DISCONNECT": {
                customerOrderType = "Disconnect";
                break;
            }
            case "MOVE": {
                customerOrderType = "Move";
                break;
            }
            case "CHANGE": {
                customerOrderType = "Change";
                break;
            }
            case "VACATIONSUSPEND": {
                customerOrderType = "Vacation Suspend";
                break;
            }
            case "VACATIONRESTORE": {
                customerOrderType = " Vacation Restore";
                break;
            }
            case "NONPAYSUSPEND": {
                customerOrderType = "Non Pay Suspend";
                break;
            }
            case "NONPAYRESTORE": {
                customerOrderType = "Non Pay Restore";
                break;
            }
            case "NEWINSTALL": {
                customerOrderType = "New Install";
                break;
            }
            default: {
                customerOrderType = "";
                break;
            }             
        }
        return customerOrderType;
    }
    public getremarkUpdateInformation(obj: any){
        return this.bMService.supRemarkUpdate(obj);
    }
}
