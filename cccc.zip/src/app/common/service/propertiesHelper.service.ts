import { Injectable } from "@angular/core";
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AppStore } from '../../common/models/appstore.model';
import { User } from '../../common/models/user.model';
import { Logger } from '../../common/logging/default-log.service';


@Injectable()
export class PropertiesHelperService {
    private user: Observable<User>;
    private userSubscription: Subscription;
    private propertiesList;
    
    constructor(
        public store: Store<AppStore>,
        private logger: Logger
    ) {
        this.user = <Observable<User>>store.select('user');
    }

    public getPropertyValueTrueFalse(lAttributeName: string) {
        let attributeMatchFound = false;
        let returnValue = "false";
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            if (data && data.properties && data.properties.properties && data.properties.properties.length > 0) {
                for (let entry of data.properties.properties) {
                    if (entry.name === lAttributeName) {
                        attributeMatchFound = true;
                        returnValue = entry.value[0];
                        break;
                    }
                }
            }
        });

        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if(!attributeMatchFound)
        {
            this.logger.log("error", "propertiesHelper.service.ts", "getPropertyValueTrueFalse", "MongoDB property not found: " +lAttributeName);     
        }

        if (returnValue === "true") {
            return true;
        }
        else {
            return false;
        }
    }

    public getPropertyValueAsNumber(lAttributeName: string, defaultVaule?: any) {
        this.getProperty();
        if (this.propertiesList && this.propertiesList[lAttributeName]) {
            return  parseInt(this.propertiesList[lAttributeName]);
        } else if (defaultVaule) {
            this.logger.log("error", "propertiesHelper.service.ts", "getPropertyValueAsNumber", "MongoDB property not found: " +lAttributeName);   
            return defaultVaule;
        } else {
            this.logger.log("error", "propertiesHelper.service.ts", "getPropertyValueAsNumber", "MongoDB property not found: " +lAttributeName); 
            return null;
        }
    }

    public isPropertyInList(lAttributeName: string, searchValue: string) {
        this.getProperty();
        if (this.propertiesList && this.propertiesList[lAttributeName]) {
            if (this.propertiesList[lAttributeName].indexOf(searchValue) > -1) {
                return true;
            }
            else {
                return false;
            }
        } else {
            this.logger.log("error", "propertiesHelper.service.ts", "isPropertyInList", "MongoDB property not found: " + lAttributeName);   
            return false;
        } 
    }

    private getProperty() {
        if (!this.propertiesList) {
            this.user = <Observable<User>>this.store.select('user');
            this.userSubscription = this.user.subscribe((data) => {
                if (data && data.properties && data.properties.properties && data.properties.properties.length > 0) {
                    this.propertiesList = data.properties.properties.reduce((property, currentProperty) => {
                        property[currentProperty.name] = currentProperty.value[0];
                        return property;
                    })
                }
            });
        }
    }
}