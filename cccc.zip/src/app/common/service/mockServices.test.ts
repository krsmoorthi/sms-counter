import { Observable, of } from 'rxjs';
import { MockServer } from "../../MockServer.test";
import { ProductService } from './product.service';
import { HttpResponse } from '@angular/common/http';
import { nonPaySuspendComponent } from 'app/non-pay-suspend/non-pay-suspend.component';
import { AddressComponent } from 'app/address/address.component';
import { DirectTvComponent } from 'app/account/directv-account/directv-account.component';
import { CoReviewOrderComponent } from 'app/review-order/change-order/co-review-order.component';
import { AutoLoginComponent } from '../auto-login/auto-login.component';
import { MultimatchComponent } from 'app/address/multimatch.component';
import { OfferComponent } from 'app/product/offer.component';
import { CustomizeServicesComponent } from 'app/product/customize-services.component';
import { ScheduleShippingAppointmentComponent } from 'app/scheduling/schedule-shipping-appointment.component';
import { AccountComponent } from 'app/account/account-component/account.component';
import { ReviewOrderComponent } from 'app/review-order/review-order-component/review-order.component';
import { ReuseBanAccountComponent } from 'app/account/reuse-ban-account/reuse-ban-account.component';
import { ExistingProductsComponent } from 'app/existing-products/existing-products.component';
import { OfferChangeComponent } from 'app/product/change-product/offer-change.component';
import { ChangeAccountComponent } from 'app/account/change-account/change-account.component';
import { OfferMoveComponent } from 'app/product/move-product/offer-move.component';
import { MoveScheduleShippingAppointmentComponent } from 'app/scheduling/move-schedule/move-schedule-shipping-appointment.component';
import { MoveAccountComponent } from 'app/account/move-account/move-account.component';
import { MoReviewOrderComponent } from 'app/review-order/move-order/mo-review-order.component';
import { PendingOrderComponent } from 'app/pending-order/pending-order.component';
import { PoScheduleAppointmentComponent } from 'app/scheduling/pending-order/po-schedule-appointment.component';
import { PoReviewOrderComponent } from 'app/review-order/pending-order/po-review-order.component';
import { DisconnectScheduleComponent } from 'app/scheduling/disconnect-schedule-component/disconnect.schedule.component';
import { DisconnectAccountComponent } from 'app/account/disconnect-account/disconnect-account.component';
import { DisconnectReviewOrderComponent } from 'app/review-order/disconnect-review-order-component/disconnect-review-order.component';
import { OfferBillingComponent } from 'app/product/billing-product/offer-billing.component';
import { BillingScheduleShippingAppointmentComponent } from 'app/scheduling/billing-schedule/billing-schedule-shipping-appointment.component';
import { BillingReviewOrderComponent } from 'app/review-order/billing-order/billing-review-order.component';
import { OrderUnHold } from 'app/pending-order/order-onhold/order-unhold.component';
import { OrderCancelComponent } from 'app/review-order/review-order-component/cancelled-order.component';
import { CancelledOrderComponent } from 'app/review-order/pending-order/cancelled-order.component';
import { nonPaySuspendConfirmationComponent } from 'app/nonpay-confirmation/nonpay-confirmation.component';
import { VacationOptionComponent } from 'app/vacation-option/vacation-option.component';
import { VacationScheduleComponent } from 'app/scheduling/vacation-schedule/vacation-schedule.component';
import { VacationAccountComponent } from 'app/account/vacation-account/vacation-account.component';
import { VacationReviewOrderComponent } from 'app/review-order/vacation-order/vacation-review-order.component';
import { VacationOfferComponent } from 'app/product/vacation-offer/vacation-offer.component';
import { StackAmendProductComponent } from 'app/product/stack-amend-product/stack-amend-product.component';
import { AmendAccountComponent } from 'app/account/prepaidAmend-account/ppamend-account.component';
import { ChangeResponsibilityComponent } from 'app/change-responsibility/change-responsibility.component';
import { SecurityErrorComponent } from '../security-error/security-error.component';
import { VacationEnums } from '../enums/vacationEnums';
import { GenericValues } from '../models/common.model';
import { CustomerOrderItems } from '../models/cart.model';
import { Products, AttributesCombination } from '../models/product.model';

export class MockAddressService {
   
    mockServer = new MockServer();
    checkAddress(){
        let data = this.mockServer.getResponseForReducerAndApi(
            "apiValidateAddress-Multimatch"
          );
        return of(new HttpResponse(data));
    }
    getGeoesAddress() {
        return of(new HttpResponse({}));
    }
    getGeoamsrvcl() {
        let data: any = {
            error: "service is down",
            responseCode: 404
        };
        return of(new HttpResponse(data));
    }

    checkCategoryId(data) {
        return of(new HttpResponse(data));
    }
    checkBillingRecAddress(){
        let req ={
            taskName:'initAddressGreen'
        }
        const data = this.mockServer.getResponseForRequest('submitTask',req);
        return of(new HttpResponse(data))
    }
}

export class MockAppStateService{
    mockServer = new MockServer();
    setLocationURLs() {
        return null;
    }
    getState () {
        return this.mockServer.getMockStore('onload-BRPage');
    }
}

export class MockOfferHelperService {
    modemDisplayNameForCart(modem, modemList) {
		let displayName;
		if (modem && modemList && Object.keys(modemList).length > 0) {
			if (modem && modem.productAttributes && modem.productAttributes[0].compositeAttribute.filter(attr => (attr.attributeName === GenericValues.cyberSecurity && attr.attributeValue === 'Enabled')).length > 0) {
				modemList.product.productAttributes.forEach((attr) => {
					if (attr.compositeAttribute.filter(attr => (attr.attributeName === GenericValues.cyberSecurity && attr.attributeValue === 'Enabled')).length > 0) {
						displayName = attr.compositeAttribute[0].attributeDisplayName;
					}
				});
			} else {
				modemList && modemList.product && modemList.product.productAttributes.forEach((attr) => {
					if ((attr && attr.compositeAttribute && attr.compositeAttribute[0].attributeValue.toLowerCase() === (modem.productAttributes && modem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase())) && modem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() === "lease") {
						if (attr.compositeAttribute.filter(a => (a.attributeName === GenericValues.cyberSecurity && a.attributeValue === 'Enabled')).length === 0) {
							displayName = attr.compositeAttribute[0].attributeDisplayName;
						}
					}
				});
			}
		}
	}
    displayCS(offerVariables, modem) {
		return offerVariables.isCSCompatible && modem && modem.productAttributes &&
			modem.productAttributes.length > 0 && modem.productAttributes[0].compositeAttribute &&
			modem.productAttributes[0].compositeAttribute[0].attributeValue === 'Purchase';
	}
    updateModemAttrValue(prodAttrs, value) {
		if (prodAttrs && prodAttrs.compositeAttribute) {
			prodAttrs.compositeAttribute = prodAttrs.compositeAttribute.sort(this.sortModemComposite);
			if (prodAttrs.compositeAttribute.filter(attr => (attr.attributeName === GenericValues.cyberSecurity && attr.attributeValue === 'Enabled')).length > 0) {
				prodAttrs.compositeAttribute[0].attributeValue = value;
			}
			return prodAttrs;
		}
	}
    getCurrentModemType(productAttribute: AttributesCombination[]): string {
		let val: string = '';
		if (productAttribute && productAttribute.length > 0) {
			productAttribute.forEach(attr => {
				attr = this.updateModemAttrValue(attr, GenericValues.leaseWithCsAttrVAlue);
				if (attr.isPriceable) {
					attr.compositeAttribute.forEach(item => {
						if (item.attributeName === 'Account Type') {
							val = item.attributeValue
						}
					});
				}
			});
			return val;
		}
	}
 findCustomerOrderObject(custObj: CustomerOrderItems[], filterBy, flag?): CustomerOrderItems {
		let val: CustomerOrderItems;
		if (custObj !== undefined) {
			custObj.forEach(obj => {
				if (!flag && obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER' && obj.action !== "VACRES-REMOVE" && obj.offerName !== VacationEnums.HSI_VAC_SUS_OFFER_NAME) {
					val = obj;
				} else if (flag && (obj.offerCategory === filterBy || obj.offerCategory === GenericValues.sData) && obj.offerType !== 'SUBOFFER' && obj.offerName !== "HSI Vacation" && obj.action !== VacationEnums.HSI_VAC_SUS_OFFER_NAME) {
					val = obj;
				}
			});
		}
		return val;
    }
    sortModemComposite(a, b) {
		if (a.attributeName === "Account Type") {
			return -1;
		} else {
			return 1;
		}
	}
    findCustomerSubOrderObject(custObj: CustomerOrderItems, filterBy): Products {
		let val: Products;
		let subItems: Products[] = [];
		if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
			subItems = custObj.customerOrderSubItems;
		} else if (custObj !== undefined && custObj.existingServiceSubItems !== undefined) {
			subItems = custObj.existingServiceSubItems;
		}
		subItems && subItems.forEach(obj => {
			if (obj.productName === filterBy && filterBy === 'MODEM') {
				obj.productAttributes && obj.productAttributes.forEach(attr => {
					if (attr.isPriceable) {
						obj = Object.assign({}, obj, {
							productAttributes: [attr]
						});
						obj.productAttributes[0] = Object.assign({}, obj.productAttributes[0], {
							compositeAttribute: attr.compositeAttribute.sort(this.sortModemComposite)
						});
					}
				});
				val = obj;
			}
			else if (obj.productName === filterBy && filterBy !== 'MODEM' && obj.action !== 'REMOVE') {
				val = obj;
			}
		});
		return val;
	}
    getModemCompatibilty(obj){ 
        return true}
    setVariableDefaults() {
        return {};
    }
    checkCSCompatibitlity() {}
    getTechnologyTypes() {}
    retrieveOffers() { }
    fetchExistingProducts() {}
    getReentrantFlags() {}
    compatibilityAPIcall() {}
    setDiscountsFromExistingDiscounts() {}
    existingProductConfigCheck() {}
    findCustomerOrderProduct() {}
    legacyValue() {}
    getRemoveResponseData() {
        return of(new HttpResponse({}))
    }
    notAvailProd() {}
    maskTelephone() {}
    isExists() {}
    initilizeAll() {}
    onInitPage() {}
    retrieveSecurityDepositHistory() {}
    initialize() {}
    getValueofSTB(val:any){ 
        return 'string'}
}
export class MockDisclosuresService {
    
}
export class MockReviewOrderHelperService {
    setReviewOrderVablesDefault() {}
}

export class MockBlueMarbleService {
    scheduleVacationCall() {
        return of(new HttpResponse({}));
    }
    public CORSubmitTask(obj) {
        return of(new HttpResponse(obj));
    }
    public submitTask(obj) {
        return of(new HttpResponse(obj));
    }
    public vacationSubmitTask(obj) {
        return of(new HttpResponse(obj));
    }
    public getBillQuoteDetails(obj) {
        return of(new HttpResponse(obj));
    }
    public submitOrderHold(obj) {
        return of(new HttpResponse(obj));
    }
    public getReasonsForHold(obj) {
        return of(new HttpResponse(obj));
    }
    public removeOrderFromHold(obj) {
        return of(new HttpResponse(obj));
    }
    public retrieveRcc(obj) {
        return of(new HttpResponse(obj));
    }
    public retrieveProductDealerCodeInfo(obj) {
        return of(new HttpResponse(obj));
    }
    public validateDealerCode(obj) {
        return of(new HttpResponse(obj));
    }
    public prepaidCancelOrderCode(obj) {
        return of(new HttpResponse(obj));
    }
    public getPaymentDetails(id) {
        return id;
    }
    public getInternationalBillingCountryList(obj) {
        return obj;
    }
    public quickConnectData(obj) {
        return obj;
    }
    public productConfigCall(obj) {
        return obj;
    }
    public initAddress(obj) {
        return obj;
    }
    public billingSubmitTask(obj) {
        return of(new HttpResponse(obj));
    }
    public geoesServiceCall(obj) {
        return obj;
    }
    public initChangeCall(obj) {
        return obj;
    }
    public changeSubmitTask(obj) {
        return of(new HttpResponse(obj));
    }
    public getE911API(obj) {
        return obj;
    }
    public getNPANXXList(obj) {
        return obj;
    }
    public getAvailableTNs(obj) {
        return obj;
    }
    public reserveTNCall(obj) {
        return obj;
    }
    public getAvailableNumber(obj) {
        return obj;
    }
    public releaseTNCall(obj) {
        return obj;
    }
    public getCompatibilityRules(obj) {
        return obj;
    }
    public getHolidaysDate(obj) {
        return obj;
    }
    public getLATA(obj) {
        return obj;
    }
    public getCompatibilityRulesforClosers(obj) {
        return obj;
    }
    public doTnPortingCheck(obj) {
        return obj;
    }
    public getRemoveChange(obj) {
        return obj;
    }
    public getOffersFromLink(obj) {
        return {};
    }
    public getCommunityRules(obj) {
        return obj;
    }
    public getCarrierInfo(obj) {
        return obj;
    }
    public getTechnologyTypes(obj) {
        return obj;
    }
    public cardEligibility(obj) {
        return obj;
    }
    public getRccDisclosure(obj) {
        return obj;
    }
    getSecurityDepositHistory() {
        return  of(new HttpResponse({}));
    }
    movePaymentSubmitTask() {
        return  of(new HttpResponse({}));
    }
    public billingRecAddress(obj) {
        return obj;
    }
    public geoamServiceCall(obj) {
        return obj;
    }
    public initCORespCall(obj) {
        return obj;
    }
}

export class MockCountryStateService {
    getStates() {
        return null;
    }
    getCountries() {
        return [
            {
                countryId: 1,
                countryName: 'United States of America',
                countryCode: 'USA'
            }
          ];
    }
}

export class MockDisconnectService {
    mockServer = new MockServer();
    submitInformation() {
        return of(new HttpResponse({}));
    } 
}

export class MockHelperService {
    startNewOrderWithoutRouting() {return null;}
    addressEditingEnabled(obj) {}
    isLCAddress(obj) { return true; }
    isAuthorized(obj) { 
        if(obj === "WAIVE ADJUSTABLE OTCS") {
            return true;
        } else {
            return false;
        }
    }
    isAuthorizedGiftAndDiscounts(obj) { return obj }
    appendToCookie(obj) { return obj }
    
    sortModemComposite(a, b) {
		if (a.attributeName === "Account Type") {
			return -1;
		} else {
			return 1;
        }
    }
    findCustomerSubOrderObject(custObj, filterBy){
        let val;
		let subItems = [];
		if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
			subItems = custObj.customerOrderSubItems;
		} else if (custObj !== undefined && custObj.existingServiceSubItems !== undefined) {
			subItems = custObj.existingServiceSubItems;
		}
		subItems && subItems.forEach(obj => {
			if (obj.productName === filterBy && filterBy === 'MODEM') {
				obj.productAttributes && obj.productAttributes.forEach(attr => {
					if (attr.isPriceable) {
						obj = Object.assign({}, obj, {
							productAttributes: [attr]
						});
						obj.productAttributes[0] = Object.assign({}, obj.productAttributes[0], {
							compositeAttribute: attr.compositeAttribute.sort(this.sortModemComposite)
						});
					}
				});
				val = obj;
			}
			else if (obj.productName === filterBy && filterBy !== 'MODEM' && obj.action !== 'REMOVE') {
				val = obj;
			}
		});
		return val;
    }
    findCustomerOrderObject(custObj, filterBy, flag?){
        let val
		if (custObj !== undefined) {
			custObj.forEach(obj => {
				if (!flag && obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER' && obj.action !== "VACRES-REMOVE" && obj.offerName !== VacationEnums.HSI_VAC_SUS_OFFER_NAME) {
					val = obj;
				} else if (flag && (obj.offerCategory === filterBy || obj.offerCategory === GenericValues.sData) && obj.offerType !== 'SUBOFFER' && obj.offerName !== "HSI Vacation" && obj.action !== VacationEnums.HSI_VAC_SUS_OFFER_NAME) {
					val = obj;
				}
			});
		}
		return val;

    }
    getCookie(obj) { return obj }
}

export class MockLogger {
    metrics() { }
    log() { }
    startTime() {}
    startTotalTime() {}
    endTime() {}
    calculateDifference() {}
    getPropertyValueAsNumber() {}
    calculateTotalDifference() {}
}

export class MockPendingOrderService {
    mockServer = new MockServer();
    getOrderSummary() {
        return of(new HttpResponse({}));
    }
    getExistingDiscountsByBan() {
        return of(new HttpResponse({}));
    }
    getOrderProgressStatus() {
        return of(new HttpResponse({}));
    }
}

export class MockProductService {
    mockServer = new MockServer();
    productService = new ProductService(null,null,null);
    getResponseForRemove() {
        return of(new HttpResponse(this.mockServer.getResponseForRequest('getReasonCode')));
    }
    getOffers() {
        return of(new HttpResponse(this.mockServer.getResponseForRequest('changePOTSSelectProduct')))
    }
    checkDiscountExists() {
        return of(new HttpResponse({}))
    }
    getPhoneDisplayName() {
        return of(new HttpResponse({}))
    }
    getOfferDisplayName() { 
        return of(new HttpResponse({}));
    }
    getCompatibilityRules() {
        return of(new HttpResponse(this.mockServer.getResponseForReducerAndApi('getCompRules')));
    }
    public findObjByName(list, fieldName, fieldVal, fieldName1 = undefined,
        fieldVal1 = undefined, prefix = undefined) {
        return this.productService.findObjByName(list,fieldName,fieldVal,fieldName1,fieldVal1,prefix);
    }
    getFreezeDropDown() {
      return of(new HttpResponse({}));
    }
    getCompatibilityRulesforClosers() {
      return of(new HttpResponse({}));
    }
    getLATA() {
      return of(new HttpResponse(this.mockServer.getResponseForReducerAndApi('getLATA')));
    }
    getResponseForCheckOut() {
        return  of(new HttpResponse({}));
    }
    getTechnologyTypes() {
        return  of(new HttpResponse(this.mockServer.getResponseForReducerAndApi('getTechnologyType')))
    }
    getCSCompatibilityRules() {
        return  of(new HttpResponse(this.mockServer.getResponseForReducerAndApi('getCSCompatibilityRules_fetchRules')))
    }
}

export class MockRouter {
    navigate(){
        return '/customize-services'
    }
}

export class MockSystemErrorService {
    lAPIErrorLists() {}
    logAndeRouteToSystemError() {}
    getAPIResponseError() {}
    logAndeRouteToSecurityError() {}
}

export class MockTextMaskService {
    public maskForUsaPhone = ['(', /[2-9]/, /[0-8]/, /\d/, ')', ' ', /[2-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public maskForTN = [/[2-9]/, /[0-8]/, /\d/, '-', /[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public maskForPhoneWithPlusOne = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public maskForUsaZip = [/[1-9]/, /\d/, /\d/, /\d/, /\d/];
    public maskForCanadaZip = [/[1-9]/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/];
    public maskForPhoneExtn = [/[1-9]/, /\d/, /\d/, /\d/];
    public maskForSsn = [/\d|x/, /\d|x/, /\d|x/, '-', /\d|x/, /\d|x/, '-', /\d|x/, /\d|x/, /\d|x/, /\d|x/];

    getPhoneNumberMaskFormat() {
        return this.maskForUsaPhone;
    }

    getPhoneNumberMaskTN() {
        return this.maskForTN;
    }

    getMaskForUsaZip() {
        return this.maskForUsaZip;
    }

    getPhoneNumberExtnMaskFormat() {
        return this.maskForPhoneExtn;
    }

    getSsnMask() {
        return this.maskForSsn;
    }
}

export class MockProfileService {

}

class MockSchedulingHelperService {
    setDefaultsVariables() {return {}}
    initializeAdjustableOtcInfo() {}
    waiveOtcAllowedCheck() {}
    getTechRemarks() {}
    cbrMethod() {}
    handleAppointmentUpdated() {}
}

export class MockReviewOrderService {
    mockServer = new MockServer();
    constructor() {}
    fetchPrimaryProductName() {}
    retrieveProductDealerCodeInfo() {
        return of(new HttpResponse(this.mockServer.getResponseForReducerAndApi('NI-HSI-POTS-retrieveProductDealerCodeInfo')));
    }
    returnOptions() {}
    getBillQuoteDetails() {
        return of(new HttpResponse(this.mockServer.getResponseForReducerAndApi('NI-HSI-POTS-Quote')));
    }
    checkExist() {}
    postSubmitTaskService() {
        return of(new HttpResponse({}));
    }
    putSubmitTaskService(val:any){
        return of(new HttpResponse({}));
    }
}
  
export class MockAccountService {

}
 
  
export class MockDirectvService {

}

export class MockAuthService {

}
  
export class MockPropertiesHelperService {
    getPropertyValueTrueFalse(obj) {
        if(obj === 'allow-waive-otc') {
            return true;
        }
    }
    getPropertyValueAsNumber() {
        return null;
    }
    isPropertyInList() {

    }
}

export class MockCTLHelperService {}

export class MockSchedulingService {}

export class MockhelperService {
    isAuthorized() {
        return true;
    }
}

export class MockVacationService {
    
}

export const MOCK_ROUTES = [
    // {path: '', component: AddressComponent},
    // {path: 'home', component: AddressComponent},
    // {path: 'directv-account', component: DirectTvComponent},
    // {path: 'co-review-order', component: CoReviewOrderComponent},
    // {path: 'auto-login', component: AutoLoginComponent},
    // {path: 'address', component: AddressComponent},
    // {path: 'multipleMatchAddress', component: MultimatchComponent},
    // {path: 'product-offer', component: OfferComponent},
    // {path: 'customize-services', component: CustomizeServicesComponent},
    // {path: 'schedule-appt', component: ScheduleShippingAppointmentComponent},
    // {path: 'schedule-appt-ship', component: ScheduleShippingAppointmentComponent},
    // {path: 'account', component: AccountComponent},
    // {path: 'review-order', component: ReviewOrderComponent},
    // {path: 'order-confirmation', component: ReviewOrderComponent},
    // {path: 'reuse-ban-account', component: ReuseBanAccountComponent},
    // {path: 'existing-products', component: ExistingProductsComponent},
    // {path: 'offer-change', component: OfferChangeComponent},
    // {path: 'change-account', component: ChangeAccountComponent},
    // {path: 'co-review-order', component: CoReviewOrderComponent},
    // {path: 'co-order-confirmation', component: CoReviewOrderComponent},
    // {path: 'move-product', component: OfferMoveComponent},
    // {path: 'move-schedule-appt-ship', component: MoveScheduleShippingAppointmentComponent},
    // {path: 'move-account', component: MoveAccountComponent},
    // {path: 'mo-review-order', component: MoReviewOrderComponent},
    // {path: 'mo-order-confirmation', component: MoReviewOrderComponent},
    // {path: 'pending-order', component: PendingOrderComponent},
    // {path: 'pending-schedule-appt', component: PoScheduleAppointmentComponent},
    // {path: 'po-review-order', component: PoReviewOrderComponent},
    // {path: 'po-order-confirmation', component: PoReviewOrderComponent},
    // {path: 'disconnect-schedule', component: DisconnectScheduleComponent},
    // {path: 'disconnect-account', component: DisconnectAccountComponent},
    // {path: 'disconnect-review-order', component: DisconnectReviewOrderComponent},
    // {path: 'disconnect-confirmation', component: DisconnectReviewOrderComponent},
    // {path: 'billing-product', component: OfferBillingComponent},
    // {path: 'billing-schedule-appt-ship', component: BillingScheduleShippingAppointmentComponent},
    // {path: 'billing-review-order', component: BillingReviewOrderComponent},
    // {path: 'br-order-confirmation', component: BillingReviewOrderComponent},
    // {path: 'order-unhold', component: OrderUnHold},
    // {path: 'order-cancelled', component: OrderCancelComponent},
    // {path: 'cancelled-order', component: CancelledOrderComponent},
    // {path: 'nonpay-suspend', component: nonPaySuspendComponent},
    // {path: 'nonpay-suspend-confirmation', component: nonPaySuspendConfirmationComponent},
    // {path: 'vacation-option', component: VacationOptionComponent},
    // {path: 'vacation-schedule-appt-ship', component: VacationScheduleComponent},
    // {path: 'vacation-account', component: VacationAccountComponent},
    // {path: 'vacation-review-order', component: VacationReviewOrderComponent},
    // {path: 'vacation-order-confirmation', component: VacationReviewOrderComponent},
    // {path: 'vacation-product-offer', component: VacationOfferComponent},
    // {path: 'stack-amend-product', component: StackAmendProductComponent},
    // {path: 'amend-account', component: AmendAccountComponent},
    // {path: 'change-responsibility', component: ChangeResponsibilityComponent},
    // {path: 'security-error', component: SecurityErrorComponent},
];