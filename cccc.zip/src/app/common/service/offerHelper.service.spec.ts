/* tslint:disable */
import { TestBed, async } from '@angular/core/testing';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/retry';
import { MockServer } from '../../MockServer.test';
import { Store } from '@ngrx/store';
import { Logger } from '../logging/default-log.service';
import { SystemErrorService } from './system-error.service';
import { CTLHelperService } from './ctlHelperService';
import { ProductService } from './product.service';
import { AppStateService } from './app-state.service';
import { DisclosuresService } from './disclosures.service';
import { HelperService } from "./helper.service";
import { BlueMarbleService } from './bm.service';
import { GenericValues } from 'app/common/models/common.model';
import { OfferHelperService } from './offerHelper.service';
import { RouterTestingModule } from '@angular/router/testing';
import { MockLogger, 
    MockSystemErrorService, 
    MockDisclosuresService, 
    MockHelperService, 
    MockBlueMarbleService, 
    MockAddressService, 
    MockDisconnectService, 
    MOCK_ROUTES} from './mockServices.test';
import { AddressService } from './address.service';
import { DisconnectService } from './disconnect.service';
import { of, throwError } from 'rxjs';
import { HttpResponse } from '@angular/common/http';

describe('OfferHelperService', () => {
    let offerHelperService: OfferHelperService;
    const mockServer = new MockServer();

    const mockRedux: any = {
        dispatch(action) {},
        configureStore() {},
        select(reducer) {
            return Observable.of(
                mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    }

    class MockAppStateService{
        setLocationURLs() {
            return null;
        }
        getState () {
            return mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE');
        }
    }

    class MockProductService {
        updateCart() {
            return of(mockServer.getOfferHelperDetails('submit-offerPage'))
        }
        getCompatibilityRules() {
            return of(mockServer.getResponseForReducerAndApi('getCompRules'));
        }
        updateChangeCart() {
            return of({});
        }
        updateBillingCart() {
            return of({});
        }
        getResponseForRemove() {
            return of({});
        }
        getPhoneDisplayName() {
            return of({});
        }
        getExpOffers() {
            return of({});
        }
    }

    let logger = { provide: Logger, useClass: MockLogger };
    let store = { provide: Store, useValue: mockRedux };
    let systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
    let cTLHelperService = CTLHelperService;
    let productService = { provide: ProductService, useClass: MockProductService };
    let appStateService = { provide: AppStateService, useClass: MockAppStateService };
    let disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
    let helperService = { provide: HelperService, useClass: MockHelperService };
    let blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
    let addressService = {provide: AddressService, useClass: MockAddressService};
    let disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};

    const providers = [
        logger, store, systemErrorService, cTLHelperService, productService, 
        appStateService, disclosuresService, helperService, blueMarbleService,
        addressService, disconnectService, OfferHelperService
    ];

    describe('When API returns Success response', () => {
        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule({
                imports: [RouterTestingModule.withRoutes(MOCK_ROUTES)],
                providers: providers
            });
        }));
    
        beforeEach(() => {
            offerHelperService = TestBed.get(OfferHelperService)
        });
    
        it("should create offerHelperService", () => {
            expect(offerHelperService).toBeDefined();
        });
    
        it('Should retrieve offer by filter when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.retrieveOffersByFilter(data.payload.retrievalTypes);
            expect(service).toBeDefined();
        });
    
        it('Should dynamically sort when true...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.getDiscountedPrice(data.selectedSpeed,'DATA', data.internetCheck, data.phoneSelected, data.internerOffer, data.phoneOffer, data.videorOffer)
            offerHelperService.getActualPrice(data.selectedTV,'VIDEO', data.internetCheck, data.phoneSelected, data.internerOffer, data.phoneOffer, data.videorOffer)
            offerHelperService.availSpeedChecked(data.selectedSpeed,data);
            const service = offerHelperService.dynamicSort("displayOrder");
            expect(service).toBeDefined();
        });
    
        it('Should extract offer by filter when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.extractOffersByFilter(data.payload.retrievalTypes, 'Qualified-Filtered');
            expect(service).toBeDefined();
        });
    
        it('Should search for primary when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage').payload.retrievalTypes[0].offers[0].catalogs[0].catalogItems[0].productOffer.productComponents;
            const service = offerHelperService.searchforPrimary(data, GenericValues.cPrimary);
            expect(service).toBeDefined();
        });
        
        it('Should search for video slot when true...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.videoSlot(data, data.selectedTVOffer);
            expect(service).toBeUndefined();
        });
        it('Should execute setDefault variables method...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.setVariableDefaults(data);
            expect(data.isPrepaidAccountPage ).toBe(false);
        });
        it('Should execute framingSlot method...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.framingSlot(data.offerResponse.payload.offers, data);
            expect(data.isPrepaidAccountPage ).toBe(false);
        });
        it('Offer filter',()=>{
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.offerFilter(data.internerOffer, data.selectedSpeed, GenericValues.sData, GenericValues.cPrimary, data) 
            expect(data.matchingOffersArray).toBeDefined()
        })
        it('matching offers..',()=>{
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.getMatchingOffers(data.phoneSelected,data.internerOffer, data.selectedSpeed, GenericValues.iData, GenericValues.cPrimary, data);
            offerHelperService.getMatchingOffers('DHP',data.internerOffer, data.selectedSpeed, GenericValues.iData, GenericValues.cPrimary, data);
            offerHelperService.addRecommendedDiscountsInCart(data);
            data.phoneSelected ='DHP'
            offerHelperService.dhpSlot(data,data.phoneOfferData[0]);
        })
        it(' checkCompatibilityEaseAndWireMaintenance method..',()=>{
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.checkCompatibilityEaseAndWireMaintenance(data)
            
        })
        xit(' checkCompatibilityEaseAndWireMaintenance method..',()=>{
            let data = mockServer.getOfferHelperDetails('offer-variable');
            offerHelperService.getSTBPrice(data,'')
            
        })

        it('Should fetch retainPreSelected true...', () => {
            let offerVariables = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.retainPreSelected(offerVariables, offerVariables.selectedInstallation, offerVariables.installationValues, 'install');
            offerHelperService.retainPreSelected(offerVariables, offerVariables.selectedModem, offerVariables.modemValues, 'modem', offerVariables.isModemCompatible);
            offerHelperService.retainPreSelected(offerVariables, offerVariables.selectedSecureWifi, offerVariables.secureWifiValues, 'security');
            offerHelperService.retainPreSelected(offerVariables, offerVariables.selectedSecureWifi, offerVariables.secureWifiValues, 'secureWifi');
            offerHelperService.retainPreSelected(offerVariables, offerVariables.selectedEase, offerVariables.easeValues, 'ease');
			offerHelperService.retainPreSelected(offerVariables, offerVariables.selectedJack, offerVariables.jackValues, 'jack');
            expect(service).toBeDefined();
        });
    
        it('Should fetch is priceable when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage').retrievalTypes[0].offers[0].catalogs[0].catalogItems[0].productOffer.productComponents;
            const service = offerHelperService.fetchIsPriceable(data);
            expect(service).toBeDefined();
        });
        
        it('Should search for primary cart when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.searchforPrimaryCart(data.payload.retrievalTypes[0].offers[0].catalogs[0].catalogItems[0].productOffer.productComponents, GenericValues.cPrimary);
            expect(service).toBeDefined();
        });
        
        it('Should filter bundle catagory when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.filterBundleCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDATVID, GenericValues.sData);
            expect(service).toBeDefined();
        });
        
        it('Should sort speeds when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.sortSpeeds(data.payload.retrievalTypes[0].offers);
            expect(service).toBeDefined();
        });
        
        it('Should search for video slot when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.catalogItemToCustSubItem(data.payload.retrievalTypes[0].offers[0].catalogs[0].catalogItems[0]);
            expect(service).toBeDefined();
        });
        
        it('Should get product name from select when true...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.getProductNameFromSelect(data.videoSelected);
            expect(service).toBeDefined();
        });
        
        it('Should get offer link when true...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.getOfferLink(data.videoSelected, data.initialOfferResponse.payload.retrievalTypes[0].offers);
            expect(service).toBeDefined();
        });
    
        xit('Should get value of STB when true...', () => {
            let data = mockServer.getOfferHelperDetails('submit-offerPage');
            const service = offerHelperService.getValueofSTB(data.payload.retrievalTypes[0].offers[0].catalogs[0].catalogItems[0].productOffer.productComponents[0].product, GenericValues.cTotalSTB);
            expect(service).toBeDefined();
        });
        
        it('Should get value of WSTB when true...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.getValueofWSTB(data.selectedOffer.productOffer.productComponents[0].product.productAttributes[0], GenericValues.cWSTB);
            expect(service).toBeUndefined();
        });
    
        it('Should be able continue when true...', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.isDisclosureAllowed = false;
            const service = offerHelperService.toContinue(data, {});
            expect(service).toBeUndefined();
        });
        
        it('should be able config for NI flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for Move flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'MOVE';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for Change flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'CHANGE';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for Billing flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'BILLING';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for stack and amend flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'STACK_AMEND';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should get remove response data', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.getRemoveResponse(data);
            offerHelperService.fetchPriceforSTB(data);
            expect(service).toBeUndefined();
        });
    
        it('should call shopping cart request from fetchPriceForSTB', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.fetchPriceforSTB(data);
            expect(service).toBeUndefined();
        });
        
        it('should call getRemoveResponseData', () => {
            const service = offerHelperService.getRemoveResponseData();
            expect(service).toBeDefined();
        });
    
        it('should call onChangeSecureWifi', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.onChangeSecureWifi(data, '', false);
            expect(service).toBeUndefined();
        });
    
        it('should call onChangeModem', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.onChangeModem(data, '', false);
            expect(service).toBeUndefined();
        });
    
        it('should call retrieveExpiredOffers', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.retrieveExpiredOffers(data);
            expect(service).toBeUndefined();
        });
        
    });

    describe('When API return error response', () => {
        class MockProductService {
            updateCart() {
                return throwError(new HttpResponse({}))
            }
            getCompatibilityRules() {
                return throwError(new HttpResponse({}));
            }
            updateChangeCart() {
                return throwError(new HttpResponse({}));
            }
            updateBillingCart() {
                return throwError(new HttpResponse({}));
            }
            getResponseForRemove() {
                return throwError(new HttpResponse({}));
            }
            getPhoneDisplayName() {
                return throwError(new HttpResponse({}));
            }
            getExpOffers() {
                return throwError(new HttpResponse({}));
            }
        };

        const productService = { provide: ProductService, useClass: MockProductService };

        const _providers = [...providers, productService];

        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule({
                imports: [RouterTestingModule.withRoutes(MOCK_ROUTES)],
                providers: _providers
            });
        }));
    
        beforeEach(() => {
            offerHelperService = TestBed.get(OfferHelperService)
        });

        it("should create offerHelperService", () => {
            expect(offerHelperService).toBeDefined();
        });

        it('should be able config for NI flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for Move flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'MOVE';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for Change flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'CHANGE';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for Billing flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'BILLING';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should be able config for stack and amend flow', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            data.currentFlow = 'STACK_AMEND';
            const service = offerHelperService.toConfig(data);
            expect(service).toBeUndefined();
        });
    
        it('should get remove response data', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.getRemoveResponse(data);
            offerHelperService.fetchPriceforSTB(data);
            expect(service).toBeUndefined();
        });
    
        it('should call shopping cart request from fetchPriceForSTB', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.fetchPriceforSTB(data);
            expect(service).toBeUndefined();
        });
        
        it('should call getRemoveResponseData', () => {
            const service = offerHelperService.getRemoveResponseData();
            expect(service).toBeDefined();
        });
    
        it('should call onChangeSecureWifi', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.onChangeSecureWifi(data, '', false);
            expect(service).toBeUndefined();
        });
    
        it('should call onChangeModem', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.onChangeModem(data, '', false);
            expect(service).toBeUndefined();
        });
    
        it('should call retrieveExpiredOffers', () => {
            let data = mockServer.getOfferHelperDetails('offer-variable');
            const service = offerHelperService.retrieveExpiredOffers(data);
            expect(service).toBeUndefined();
        });
    });

});