import { GenericValues } from './../models/common.model';
import { AppStore } from './../models/appstore.model';
import { Cart } from './../models/cart.model';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { BlueMarbleService } from './bm.service';

@Injectable()
export class ReviewOrderService {
    private cart: Observable<any>;
    private cartSubscription: Subscription;

    constructor(
        public bMService: BlueMarbleService,
        public store: Store<AppStore>
    ) { }

    public fetchPrimaryProductName() {
       let  productName : string;
       let combinedName: string =""
        this.cart = <Observable<Cart>>this.store.select('cart');
        this.cartSubscription = this.cart.subscribe(cart => {
            if (cart && cart.payload && cart.payload.cart && cart.payload.cart.customerOrderItems) {
                let orderItems = cart.payload.cart.customerOrderItems;

                orderItems.map(orderItem => {
                    if (orderItem && (orderItem.productType === GenericValues.iData) || (orderItem.productType === GenericValues.sData)) {
                        orderItem.customerOrderSubItems.map(subItem => {
                            if (subItem.componentType === GenericValues.cPrimary) {
                                productName = subItem.productName;
                            }
                        })
                    }
                });

                orderItems.map(orderItem => {
                    if (orderItem && (orderItem.productType === GenericValues.iData) || (orderItem.productType === GenericValues.sData)) {
                        combinedName += orderItem.offerDisplayName;
                    }
                    if (orderItem.productType === GenericValues.cDHP) {
                        combinedName += " " + orderItem.offerDisplayName;
                    }
                    if (orderItem.productType === GenericValues.cHP) {
                        combinedName = orderItem.offerDisplayName;
                    }
                    if (orderItem.productType === GenericValues.cVideo) {
                        orderItem.customerOrderSubItems.map(subItem => {
                            if (subItem.componentType === GenericValues.cPrimary) {
                                combinedName += " " + subItem.productName;
                            }
                        })
                        // this.combinedName += " " + orderItem.offerDisplayName;
                    }
                });

            }
        });
        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }
        let obj = {
            speed: productName,
            productName: combinedName
        }
        return obj;
    }


    /**
     * put API call
     * @param request
     */
    public postSubmitTaskService(request, orderFlow?:any) {
        if (orderFlow === "Change") {
            return this.bMService.changeSubmitTask(request);
        } else if(orderFlow === "COR") {
            return this.bMService.CORSubmitTask(request);
        } else {
            return this.bMService.submitTask(request, orderFlow);
        }
    }
    public postVacationSubmitTaskService(request) {
        return this.bMService.vacationSubmitTask(request);
    }

    public putSubmitTaskService(request) {
        return this.bMService.billingSubmitTask(request);
    }

    public getBillQuoteDetails(quoteId: string) {
        return this.bMService.getBillQuoteDetails(quoteId);
    }

    /**
     * To get options as an array
     * @param options
     */
    public returnOptions(options): string[] {
        if (options) {
            let tempArray: string[] = [];
            for (let k in options) {
                if (options[k]) {
                    tempArray.push(k);
                }
            }
            return tempArray;
        }
    }

    /**
     * To check if all values are either true or false
     * @param options
     * @param bool
     */
    public checkExist(options, bool): boolean {
        if (options) {
            let result = Object.keys(options).every((k) => {
                return options[k] === bool;
            });
            return result;
        }
    }

    /**
     * To convert tax strings from API to proper UI
     * @param value
     */
    public camelCaseCapitaliseTax(value): string {
        let taxVar = value.split('TAX');

        let result = taxVar[0].replace(/([A-Z])/g, ' $1').replace(/^./, (str) => {
            return str.toUpperCase();
        });

        return result + ' TAX';
    }

    /**
     * To compute additional service total
     * @param serviceObject
     */
    public computedAdditionalServices(serviceObject: any[]) {
        let result: number = 0;
        for (let key in serviceObject) {
            if (serviceObject[key].billAmount && serviceObject[key].billAmount > 0) {
                result += serviceObject[key].billAmount;
            }
        }
        return result;
    }

    /**
     * To compute taxes total
     * @param taxesObject
     */
    public computedTaxes(taxesObject) {
        let result: number = 0;
        for (let key in taxesObject) {
            if (taxesObject.hasOwnProperty(key)) {
                result += taxesObject[key];
            }
        }
        return result;
    }

    public getMoveReviewOrderInfo(reqObj: any, flow?) {
        // if(flow === 'billing') {
        //     return this.bMService.submitTask(reqObj, flow);
        // } else {
        //     return this.bMService.submitTask(reqObj, true);
        // }
        return this.bMService.submitTask(reqObj, flow);
        
    }

    public getChangeReviewOrderInfo(reqObj: any) {
        return this.bMService.changeSubmitTask(reqObj);
    }

    public getVacationReviewOrderInfo(reqObj: any) {
        return this.bMService.vacationSubmitTask(reqObj);
    }

    /**
    * For calling service to get the reasons for Hold
    */
    public getReasonsForHoldCall(request: any) {
        return this.bMService.getReasonsForHold(request);
    }

    /**
     * For calling service to placing order on Hold
     */
    public getHoldOrderSubmisson(obj: any) {
        return this.bMService.submitOrderHold(obj);
    }

    /**
     * For calling service to unhold
     */
    public removeOrderFromHold(obj: any, flow: any) {
        return this.bMService.removeOrderFromHold(obj, flow);
    }

    public retrieveRcc(payload: any) {
        return this.bMService.retrieveRcc(payload);
    }

    public retrieveProductDealerCodeInfo(request) {
        return this.bMService.retrieveProductDealerCodeInfo(request);
    }

    public validateDealerCode(request) {
        return this.bMService.validateDealerCode(request);
    }
    public prepaidCancelOrderCode(request) {
        return this.bMService.prepaidCancelOrderCode(request);
    }

}
