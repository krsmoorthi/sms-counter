import { TestBed } from '@angular/core/testing';

import { creditService } from './credit-check.service';
import { BlueMarbleService } from './bm.service';
import { MockBlueMarbleService } from './mockServices.test';

describe('CreditCheckService', () => {
  let service: creditService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        creditService,
        {provide: BlueMarbleService, useClass: MockBlueMarbleService}
      ]
    });
    service = TestBed.get(creditService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get payment data on call paymentRequest', () => {
    const response = service.paymentRequest({});
    expect(response).toBeDefined();
  });

  it('should get payment data on call paymentRequestMove', () => {
    const response = service.paymentRequestMove({});
    expect(response).toBeDefined();
  });
});
