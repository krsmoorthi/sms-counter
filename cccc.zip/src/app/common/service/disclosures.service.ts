import { Injectable } from "@angular/core";
import { BlueMarbleService } from "./bm.service";

@Injectable()
export class DisclosuresService {

    constructor(
        private bMService: BlueMarbleService,
    ) { }

    public viewRccsDisclosure(payload) {
        return this.bMService.getRccDisclosure(payload);
    }
}