import { Injectable } from '@angular/core';
import { Observable, Subscription } from 'rxjs/Rx';
import { SecurityError, SystemError, ErrorResponse, APIErrorLists, serverErrorMessages } from '../models/common.model';
import { Logger } from '../logging/default-log.service';
import { AppStore } from '../models/appstore.model';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { CTLHelperService } from './ctlHelperService';
import { User } from '../models/user.model';

@Injectable()
export class SystemErrorService {
    public apiResponseError: APIErrorLists;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public orderRefNumber: any;

    constructor(
        private logger: Logger,
        public store: Store<AppStore>,
        private router: Router,
        private ctlHelperService: CTLHelperService) {
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
        });
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
    }

    public logAndRouteUnexpectedError(messageLevel: string, orderNumber: string, taskName: string, sourcePage: string, className: string, error: any) {
        this.ctlHelperService.setLocalStorage('error', error);
        let errorString = JSON.stringify(error);
        let errorResponseArray: ErrorResponse[] = [];
        let statusCode = error && error.status ? error.status.toString() : '';
        orderNumber = this.orderRefNumber ? this.orderRefNumber : 'Not Applicable';
        if (error.name === 'TimeoutError') {
            let localErrorResponse: ErrorResponse = {
                orderRefNumber: orderNumber,
                statusCode: serverErrorMessages.serverTimeoutErrNumber,
                reasonCode: serverErrorMessages.serverTimeoutErrNumber,
                message: serverErrorMessages.timeoutException,
                messageDetail: serverErrorMessages.serverTimeoutErrMessage
            }
            errorResponseArray.unshift(localErrorResponse);
        } else if (errorString.indexOf('404') > -1) {
            let lerror;
            if (this.ctlHelperService.isJson(error._body)) {
                lerror = error.json();
            }
            let localErrorResponse: ErrorResponse = {};
            if (lerror && lerror.errorResponse && lerror.errorResponse.length > 0) {
                localErrorResponse = {
                    orderRefNumber: orderNumber,
                    statusCode: statusCode,
                    reasonCode: statusCode,
                    message: lerror.errorResponse && lerror.errorResponse.length > 0 ? lerror.errorResponse[0].message : error.statusText,
                    messageDetail: lerror.errorResponse && lerror.errorResponse.length > 0 ? lerror.errorResponse[0].messageDetail : serverErrorMessages.proxyMessageDetail
                }
            } else {
                let result = this.ctlHelperService.getLocalStorage('getOrderByBANOrCOR-Call');
                if (!result) {
                    this.ctlHelperService.removeLocalStorage('getOrderByBANOrCOR-Call');
                    localErrorResponse = {
                        orderRefNumber: orderNumber,
                        statusCode: statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownAddress,
                        messageDetail: serverErrorMessages.serverDownAddressErrMessage,
                        serverDown: serverErrorMessages.serverDown,
                    }
                }
            }
            errorResponseArray.unshift(localErrorResponse);
        } else if (statusCode === '502' || statusCode === '503' || error.statusText === 'Proxy Error') {
            let localErrorResponse: ErrorResponse;
            let lerror;
            if (this.ctlHelperService.isJson(error._body)) {
                lerror = error.json();
            }
            if (lerror && lerror.errorResponse && lerror.errorResponse.length > 0) {
                localErrorResponse = {
                    orderRefNumber: orderNumber,
                    statusCode: statusCode,
                    reasonCode: statusCode,
                    message: lerror.errorResponse && lerror.errorResponse.length > 0 ? lerror.errorResponse[0].message : error.statusText,
                    messageDetail: lerror.errorResponse && lerror.errorResponse.length > 0 ? lerror.errorResponse[0].messageDetail : serverErrorMessages.proxyMessageDetail
                }
            } else {
                localErrorResponse = {
                    orderRefNumber: orderNumber,
                    statusCode: statusCode,
                    reasonCode: serverErrorMessages.statusCode,
                    message: serverErrorMessages.serverDownAddress,
                    messageDetail: serverErrorMessages.serverDownAddressErrMessage,
                    serverDown: serverErrorMessages.serverDown,
                }
            }
            errorResponseArray.unshift(localErrorResponse);
        } else {
            let lerror;
            if (this.ctlHelperService.isJson(error._body)) {
                lerror = error.json();
            }
            let localErrorResponse: ErrorResponse = {};
            if (statusCode === '200') {
                localErrorResponse = {
                    orderRefNumber: orderNumber,
                    statusCode: statusCode,
                    reasonCode: error.reasonCode,
                    message: error.message,
                    messageDetail: error.messageDetail
                };
            } else if (lerror !== undefined && lerror !== null && lerror.errorResponse.length > 0) {
                localErrorResponse = {
                    orderRefNumber: lerror.errorResponse[0].orderRefNumber,
                    statusCode: statusCode,
                    reasonCode: lerror.errorResponse[0].reasonCode,
                    message: lerror.errorResponse[0].message,
                    messageDetail: lerror.errorResponse[0].messageDetail
                }
            } else if(statusCode === '500' && lerror === undefined && error && error.error && error.error.errorResponse && error.error.errorResponse.length >0){
                localErrorResponse = {
                    orderRefNumber: error.error.errorResponse[0].orderRefNumber,
                    statusCode: statusCode,
                    reasonCode: error.error.errorResponse[0].reasonCode,
                    message: error.error.errorResponse[0].message,
                    messageDetail: this.ctlHelperService.toSubstring(error.error.errorResponse[0].messageDetail, 400)
                }
            } else {
                localErrorResponse = {
                    orderRefNumber: orderNumber,
                    statusCode: statusCode,
                    reasonCode: serverErrorMessages.statusCode,
                    message: serverErrorMessages.serverDownAddress,
                    messageDetail: serverErrorMessages.serverDownAddressErrMessage,
                    serverDown: serverErrorMessages.serverDown,
                }
            }
            errorResponseArray.unshift(localErrorResponse);
        }
        let lAPIErrorLists: APIErrorLists = {
            errorResponse: errorResponseArray
        };
        this.logAndeRouteToSystemError(messageLevel, taskName, className, sourcePage, lAPIErrorLists);

    }

    public logAndeRouteToSystemError(messageLevel: string, taskName: string, sourcePage: string, className: string, apiResponseError: APIErrorLists) {
        let errorSystemResponseCustom: SystemError = {
            orderRefNumber: apiResponseError.errorResponse[0].orderRefNumber,
            sourcePage: sourcePage,
            taskName: taskName,
            statusCode: apiResponseError.errorResponse[0].statusCode,
            reasonCode: apiResponseError.errorResponse[0].reasonCode,
            message: apiResponseError.errorResponse[0].message,
            messageDetail: apiResponseError.errorResponse[0].messageDetail
        }
        this.store.dispatch({ type: 'SYSTEM_ERROR', payload: errorSystemResponseCustom });
        this.logger.log(messageLevel, className, taskName, JSON.stringify(errorSystemResponseCustom ? errorSystemResponseCustom : ''));
    }

    public lAPIErrorLists(orderRefNumber?: any) {
        let error = this.ctlHelperService.getLocalStorage('error');
        let errorResponseArray: ErrorResponse[] = [];
        let localErrorResponse: ErrorResponse = {
            orderRefNumber: this.orderRefNumber ? this.orderRefNumber : 'Not Applicable',
            statusCode: error && error.status ? error.status : serverErrorMessages.statusCode,
            reasonCode: error && error.status ? error.status : serverErrorMessages.statusCode,
            message: serverErrorMessages.serverDownSchedule01,
            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
            serverDown: serverErrorMessages.serverDown
        }
        errorResponseArray.unshift(localErrorResponse);
        let lAPIErrorLists: APIErrorLists = {
            errorResponse: errorResponseArray
        };
        return lAPIErrorLists;
    }

    public logAndeRouteToSecurityError(messageLevel: string, taskName: string, sourcePage: string, className: string) {
        let securityErrorCustom: SecurityError = {};
        if (taskName.indexOf("ServiceError") > -1) {
            securityErrorCustom = {
                message: "BM Service Error - getProfileRestrictions",
                messageDetail: "BM Service Error - getProfileRestrictions returned an error."
            }
        }
        else if (taskName.indexOf("SFC") > -1) {
            securityErrorCustom = {
                message: "EShop Authorization Error",
                messageDetail: "User does not have authorization to use EShop from SalesForce."
            }
        }
        else if (taskName.indexOf("STD") > -1) {
            securityErrorCustom = {
                message: "EShop Authorization Error",
                messageDetail: "User does not have authorization to use EShop Standalone."
            }
        }
        else if (taskName.indexOf("EnsembleId") > -1) {
            securityErrorCustom = {
                message: "EShop Authorization Error",
                messageDetail: "User does not have authorization to use EShop - No Ensemble Id."
            }
        }
        else {
            securityErrorCustom = {
                message: "EShop Authorization Error",
                messageDetail: "User does not have authorization to use EShop."
            }
        }

        this.logger.log(messageLevel, className, taskName, JSON.stringify(securityErrorCustom ? securityErrorCustom : ''));
        this.store.dispatch({ type: 'SECURITY_ERROR', payload: securityErrorCustom });
        this.router.navigate(['/security-error']);
    }

    public getAPIResponseError(error?: any, callType?: any, componentName?: any, pageName?: any) {
        if (error === undefined || error === null) return;
        let unexpectedError = false;
        if (this.ctlHelperService.isJson(error)) {
            this.apiResponseError = JSON.parse(error);
            if (this.apiResponseError && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                this.logAndeRouteToSystemError("error", callType, componentName, pageName, this.apiResponseError);
            } else unexpectedError = true;
        } else unexpectedError = true;
        if (unexpectedError) {
            let ORN = this.orderRefNumber ? this.orderRefNumber : 'Not Applicable';
            let lAPIErrorLists = this.lAPIErrorLists(ORN);
            this.logAndeRouteToSystemError("error", callType, componentName, pageName, lAPIErrorLists);
        }
        window.scroll(0, 0);
    }

}
