import { Injectable } from "@angular/core";
import { GenericValues } from "../models/common.model";
import * as moment from 'moment-timezone';
import { CustomerOrderItems } from "../models/cart.model";
import { FinalBillInfo } from "../models/credit-check.model";
import { RE_ENTRANT_OFFERVARIABLE } from "app/app.constant";
import { env } from '../../../environments/environment';
import { BehaviorSubject, Subject } from 'rxjs';
import { AppStore } from "app/common/models/appstore.model";
import { Store } from "@ngrx/store";
@Injectable()
export class CTLHelperService {

    public disclosureModalOpen = new BehaviorSubject(false);
    public undoChanges = new BehaviorSubject(false);
    public errorHandler = new Subject();

    constructor() { }

    public isJson(str) {
        try {
            let object = JSON.parse(str);
            if (typeof object === 'object') {
                return true;
            } else {
                return false;
            }
        } catch (e) {
            return false;
        }
    }

    // sometime BM is not giving status code in errorResponse so putting error object in localstorage to get status code of failed API
    public setLocalStorage(key, value) {
        try {
            const serializedObject = JSON.stringify(value);
            localStorage.setItem(key, serializedObject);
        } catch (e) {
            return;
        }
    }

    public getLocalStorage(key) {
        try {
            const serilizedObject = localStorage.getItem(key);
            if (serilizedObject === null) {
                return undefined;
            }
            return JSON.parse(serilizedObject);
        } catch (e) {
            return undefined;
        }
    }

    public removeLocalStorage(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            return undefined;
        }
    }

    get windowRef() {
        return window;
    }

    get distURL() {
        if (`${env.CURRENT_ENVIRONMENT}`.indexOf('localhost') > -1) return `${env.CURRENT_ENVIRONMENT}` + '/eshop/customerCare/dist/';
        else return `${env.CURRENT_ENVIRONMENT}` + '/customerCare/dist/';
    }

    public closeSession() {
        this.windowRef.open("about:blank", '_self', '');
        this.windowRef.close();
    }

    public maskTelephone(number: string) {
        if (number && (typeof number === 'string') && number.indexOf('-') === -1) {
            return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
        }
        else if (number) {
            return number;
        }
    }

    public getImagePath(productCategory) {
        if (productCategory) {
            switch (productCategory) {
                case 'INTERNET': return './assets/img/internet_sm.png';
                case GenericValues.sData || GenericValues.iData: return './assets/img/internet_sm.png';
                case GenericValues.cVideo: return './assets/img/prism_sm.png';
                case GenericValues.cDATVID: return './assets/img/prism_sm.png';
                case GenericValues.cDHP: return './assets/img/phone_sm.png';
                case GenericValues.cHP: return './assets/img/phone_sm.png';
                case GenericValues.cDTV: return './assets/img/directv-icon-small.png';
            }
        }
    }

    public getCopyOfObject(object) {
        if (typeof object === 'string') {
            return Object.assign({}, JSON.parse(JSON.stringify(object)));
        } else if (typeof object === 'object') {
            return Object.assign({}, object);
        }
    }

    /**
     * @param getDate date convertion as per UTC for time zones
     */
    public convertDateFormat(getDate: any) {
        if (getDate && (getDate !== null || getDate !== undefined)) {
            let UTCDate = moment(getDate).utc().format(moment.HTML5_FMT.DATETIME_LOCAL_MS) + 'Z';
            return (UTCDate);
        }
    }

    /*
    * Determind given JSON path is valid
    * @function isDefined
    * @Param {obj} Parent object
    * @Param {path} dot-notation path to a specific child object
    * @returns {boolean} 
    */
    public isDefined(obj: any, path: string) {
        if (obj === undefined) {
            return false;
        }
        if (obj !== undefined && !path) {
            return true;
        }
        let thisToken;
        let tokens = path.split('.');
        while (tokens.length) {
            thisToken = tokens.shift();
            if (obj[thisToken] === undefined) {
                return false;
            }
            obj = obj[thisToken];
        }
        return true;
    }

    public checkRuralAddress(response) {
        var ruralStatement = false;
        if (response && response.payload && response.payload.addlOrderAttributes && Array.isArray(response.payload.addlOrderAttributes) && response.payload.addlOrderAttributes.length > 0) {
            response.payload.addlOrderAttributes.forEach((item: any) => {
                if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                    item.orderAttributeGroup.forEach((item: any) => {
                        if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                            item.orderAttributeGroupInfo.forEach((item: any) => {
                                if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                    item.orderAttributes.forEach((item: any) => {
                                        if (item.orderAttributeName.toUpperCase() === "SERVICEADDRESSTYPE" && item.orderAttributeValue.toUpperCase() === "R") {
                                            ruralStatement = true;
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
        return ruralStatement;
    }
   
    public getCustomerOrderItem(catalogItem: any, type: string, existsProductIds?: string[]): any {
        let custOrderItem: CustomerOrderItems = {
            customerOrderSubItems: [],
        };
        if (type === 'vacSusExistsCart') {
            custOrderItem.action = 'VACSUS-REMOVE';
            custOrderItem.quantity = 1;
        }
        if (type === 'vacSusOffer') {
            custOrderItem.action = 'VACSUS-ADD';
            custOrderItem.quantity = null;
        }
        if (type === 'vacReconnect') {
            custOrderItem.action = 'VACRES-ADD';
            custOrderItem.quantity = null;             
        }
        custOrderItem.catalogId = catalogItem.catalogId;
        custOrderItem.contractTerm = catalogItem.productOffer.contract.contractTerm;
        custOrderItem.productOfferingId = catalogItem.productOffer.productOfferingId;
        custOrderItem.offerType = catalogItem.productOffer.offerType;
        custOrderItem.offerName = catalogItem.productOffer.offerName;
        custOrderItem.offerDisplayName = catalogItem.productOffer.offerDisplayName;
        custOrderItem.offerSubType = catalogItem.productOffer.offerSubType;
        custOrderItem.offerCategory = catalogItem.productOffer.offerCategory;
        custOrderItem.customerOrderSubItems = [];
        catalogItem.productOffer && catalogItem.productOffer.productComponents.map((productComponentObj) => {
            if (type === 'vacSusExistsCart') {
                productComponentObj.product.action = 'VACSUS-REMOVE';
                productComponentObj.product.quantity = 1;
            }
            if(type === 'vacSusOffer') {
                productComponentObj.product.action = 'VACSUS-ADD';
                productComponentObj.product.quantity = null;
            }
            if (type === 'vacReconnect') {
                productComponentObj.product.action = 'VACRES-ADD';
            }
            productComponentObj.product.componentType = productComponentObj.componentType;
            delete productComponentObj.product.isRegulated;
            delete productComponentObj.product.productCategoryDisplayName;
            delete productComponentObj.product.productDisplayName;
            
            if (existsProductIds && (existsProductIds.indexOf(productComponentObj.product.productId) > -1)) {
                custOrderItem.customerOrderSubItems.push(productComponentObj.product);
            }
            if (!existsProductIds) {
                custOrderItem.customerOrderSubItems.push(productComponentObj.product);
            }
        });
        if (catalogItem.defaultOfferPrice) {
            custOrderItem.discountedRc = catalogItem.defaultOfferPrice.discountedRc;
            custOrderItem.discountedOtc = catalogItem.defaultOfferPrice.discountedOtc;
            custOrderItem.otc = catalogItem.defaultOfferPrice.otc;
            custOrderItem.rc = catalogItem.defaultOfferPrice.rc;
        }
        if (type === 'vacReconnect') {
            this.setLocalStorage('vacation-reconnect', custOrderItem);            
        }
        return custOrderItem;
    }

    public catalogItemToCustSubItem(item, action) {
        let customerOrderSubItem: any = {};
        if (item && item.productOffer && item.productOffer.productComponents) {
            item && item.productOffer && item.productOffer.productComponents.map((productComponentObj) => {
                if (action) productComponentObj.product.action = action;
                else productComponentObj.product.action = null;
                productComponentObj.product.componentType = productComponentObj.componentType;
                delete productComponentObj.product.isRegulated;
                delete productComponentObj.product.productCategoryDisplayName;
                delete productComponentObj.product.productDisplayName;
                customerOrderSubItem = productComponentObj.product;
            });
        }
        return customerOrderSubItem;
    }

    public getSummedOtc(prices: any[]): number {
        let sumPrice: number = 0;
        prices && prices.map(price => {
            if (price.discountedOtc > 0) {
                sumPrice += price.discountedOtc
            } else if (price.otc > 0) {
                sumPrice += price.otc
            }
        })
        return sumPrice;
    }

    public  trackByFn = (index: number, item: any) : number => {
        return index;
    }

    /**
    |--------------------------------------------------
    | calculating and returning total past due amount
    |--------------------------------------------------
    */
    public getTotalPastDueAmount(finalBillInfo: FinalBillInfo[]) {
        let totalPastDueAmount: number = 0;
        if(finalBillInfo && (finalBillInfo.length > 0)) {
            finalBillInfo.forEach(obj => {
                if(obj && obj.finalBillAmt && obj.finalBillAmt.amount) {
                    totalPastDueAmount += obj.finalBillAmt.amount;
                }
            });
        }
        return totalPastDueAmount;
    }

    /**
    |--------------------------------------------------
    | returning array of billing account number
    |--------------------------------------------------
    */
    public getBTNsArray(finalBillInfo: FinalBillInfo[]): string[] {
        let BTNs: string[] = [];
        if(finalBillInfo && (finalBillInfo.length > 0)) {
            finalBillInfo.forEach(obj => {
                if(obj && obj.btn) {
                    BTNs.push(obj.btn);
                }
            });
        }
        return BTNs;
    }

    public storeRequestProcessData(data: any, currentUrl: string, requestType: string, flow: string) {
        let orderRefNumber, processInstanceId, taskId, taskName = '';
        if(data && data.orderRefNumber) orderRefNumber = data.orderRefNumber;
        if(data && data.processInstanceId) processInstanceId = data.processInstanceId;
        if(data && data.taskId) taskId = data.taskId;
        if(data && data.taskName) taskName = data.taskName;
        currentUrl = '/' + currentUrl;
        let storedRequestProcessData: any = this.getLocalStorage('storedRequestProcessData');
        if(storedRequestProcessData) {
            if(data && data.taskName) storedRequestProcessData = storedRequestProcessData.filter(sdata => sdata.taskName !== data.taskName);
            storedRequestProcessData.push({ flow, requestType, currentUrl, orderRefNumber, processInstanceId, taskId, taskName });
            this.setLocalStorage('storedRequestProcessData', storedRequestProcessData);
        } else {
            this.setLocalStorage('storedRequestProcessData', [{ flow, requestType, currentUrl, orderRefNumber, processInstanceId, taskId, taskName }]);
        }
    }

    public removeLocalStorageAtLandingPage() {
        this.removeLocalStorage(RE_ENTRANT_OFFERVARIABLE);
    }

    public setDisclosureModalOpen(flag: boolean) {
        this.disclosureModalOpen.next(flag);
    }

    public setUndoChanges(flag: boolean) {
        this.undoChanges.next(flag);
    }

    public setErrorHandler(message) {
        this.errorHandler.next(message);
    }

    public toSubstring(msg: string, limit: number): string {
        let message: string;
        if(msg && msg.length > limit) {
            message = msg.substring(0, limit) + ' ...';
        } else {
            message = msg
        }
        return message;
    }

}