import { AppStore } from '../../common/models/appstore.model';
import { BlueMarbleService } from './bm.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { User } from '../../common/models/user.model';

@Injectable()
export class ProfileService {
    private user: Observable<User>;

    constructor(
        public store: Store<AppStore>,
        public bMService: BlueMarbleService) {
        this.user = <Observable<User>>store.select('user');

    }

    /**
     * Profile API call from home page
     */
    public getProfile() {
        // Get OAM Cookie Data
        let agentCsrId = "";
        let ensembleId = "";

        if (this.user) {
            this.user.subscribe((data) => {
                if (data.autoLogin) {
                    if (data.autoLogin.oamData) {
                        agentCsrId = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                        ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                    }
                }
            });
        }

        var payload = {
            "salesChannel": "ESHOP-Customer Care",
            "party": {
                "type": "CSR",
                "partyRoles": [
                    {
                        "partyRole": "CSRID",
                        "sourceSystem": "CSR_PROFILE",
                        "id": agentCsrId
                    },
                    {
                        "partyRole": "ENSEMBLEID",
                        "sourceSystem": "ENS_OPERATOR",
                        "id": ensembleId
                    }
                ]
            }
        };

        return this.bMService.getProfile(payload);
    }

    /**
     * Profile API call from home page - override
     */
    public getProfileByEnsembleOverride(ensembleId) {
        // Get OAM Cookie Data
        let agentCsrId = "";

        if (this.user) {
            this.user.subscribe((data) => {
                if (data.autoLogin) {
                    if (data.autoLogin.oamData) {
                        agentCsrId = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    }
                }
            });
        }

        var payload = {
            "salesChannel": "ESHOP-Customer Care",
            "party": {
                "type": "CSR",
                "partyRoles": [
                    {
                        "partyRole": "CSRID",
                        "sourceSystem": "CSR_PROFILE",
                        "id": agentCsrId
                    },
                    {
                        "partyRole": "ENSEMBLEID",
                        "sourceSystem": "ENS_OPERATOR",
                        "id": ensembleId
                    }
                ]
            }
        };

        return this.bMService.getProfile(payload);
    }
}
