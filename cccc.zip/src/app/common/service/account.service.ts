import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { BlueMarbleService } from './bm.service';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import { GenericValues } from './../models/common.model';
import { AppStore } from './../models/appstore.model';
import { Store } from '@ngrx/store';
@Injectable()
export class AccountService {
  
  public custdata: any;
  public observable: any;
  public custSubscription: any;
  public cartObservable: Observable<any>;
  private custData: Observable<any>;
  private custDataSubscription: Subscription;
    public updatedOtc: any;
    
    constructor(
      public bMService: BlueMarbleService,
      public store: Store<AppStore>
    ) { }

    public otcData = new Subject<any>();

    public accountInfo = new Subject<any>();

    public otcRelated$ = this.otcData.asObservable();
    
    public getOtcData(data : any) {
      this.otcData.next(data);
    }

    public accountData$ = this.accountInfo.asObservable();

    public getAccountData(data : any) {
          this.accountInfo.next(data);
    }

    public getAccInformation(obj: any) {
      return this.bMService.submitTask(obj);
    }

    public getCreditResponse(obj: any, orderFlow?: any) {
        if(orderFlow === "COR") {
            return this.bMService.CORSubmitTask(obj);
        } else {
            return this.bMService.submitTask(obj);
        }
    }

    public getPaymentDetails(sessionId: string){
        return this.bMService.getPaymentDetails(sessionId);
    }

    public getInternationalBillingCountryList(countryListReq) {
      /*return {
        "outArrHeader": [
          "countryISOCode",
          "countryName"
        ],
        "outputAttribute": [
          [
            "NMR",
            "Northern Mariana Islands"
          ],
          [
            "PAR",
            "Paraguay"
          ],
          [
            "PHL",
            "Philippines"
          ],
          [
            "OMN",
            "Oman"
          ],
          [
            "PAN",
            "Panama"
          ],
          [
            "USA",
            "United States Of America"
          ]
        ]
      };*/
      
      
      return this.bMService.getInternationalBillingCountryList(countryListReq);
    }
    public saveDtvAccountNo(dtvAccountNo, orderNumber){
      let productName = '';
      this.custData = <Observable<any>>this.store.select('customize');
      //F26699-uncommented to bring back OMS flow
       this.custDataSubscription = this.custData.subscribe(data => {
          if(data && data.payload && data.payload.productConfiguration && data.payload.productConfiguration.length > 0) {
            data.payload.productConfiguration.map(product => {
              if(product.productType === GenericValues.cDTV && product.configItems && product.configItems.length > 0) {
                productName = product.configItems[0].productName;
              }
            })   
          }
      });
      if(this.custDataSubscription !== undefined) {
          this.custDataSubscription.unsubscribe();
      }
      //
        let request = {
            orderReferenceNumber: orderNumber,
            productConfiguration: [
              {
                configItems: [
                  {
                    productId: null,
                    productName: productName,
                    configDetails: [
                      {
                        isConfigRequired: true,
                        formName: 'Account Information',
                        formItems: [
                          {
                            attributeName: 'New DTV Sale',
                            attributeType: 'LOV',
                            isMandatory: true,
                            attributeValue: [
                              {
                                value: 'Yes',
                                isDefault: false
                              }
                            ]
                          }
                        ]
                      },
                      {
                        isConfigRequired: true,
                        formName: 'DTV AccountID',
                        formItems: [
                          {
                            attributeName: 'DIRECTV Account ID',
                            attributeType: 'FreeText',
                            isMandatory: false,
                            attributeValue: [
                              {
                                value: dtvAccountNo,
                                isDefault: false
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  }
                ],
                productType: 'VIDEO-DTV'
              }
            ]
          };
          return this.bMService.productConfigCall(request);
    }
    
    public getEmailValidated(payload: any){
        return this.bMService.quickConnectData(payload);
      }
}
