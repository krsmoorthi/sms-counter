import { Injectable, Inject, OnInit } from '@angular/core';
import { Store, StoreModule } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { Router } from '@angular/router';
import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { AuthService } from './auth.service';
import { Http, BaseRequestOptions, ConnectionBackend } from '@angular/http';
import { AppStateService } from './app-state.service';
import { userReducer } from '../reducers/user.reducer';

// provide our implementations or mocks to the dependency injector
xdescribe('App State Service Tests... ', () => {
  let backend: MockBackend = null;
  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
         {
          provide: AuthService, useClass: class {public AuthService; }
         },
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [ MockBackend, BaseRequestOptions ]
        },
         {
        provide: Router,
        // tslint:disable-next-line:max-classes-per-file
        useClass: class { public navigate = jasmine.createSpy('navigate'); }
        },
      AppStateService, StoreModule.forRoot({user: userReducer}) ]
    });
  });
  it('Should call ngOnInit...', inject([AppStateService], (appStateService: AppStateService) => {
      const service = appStateService.ngOnInit();
      expect(service).toBeDefined;
   }));

  it('Should call getState...', inject([AppStateService], (appStateService: AppStateService) => {
        const service = appStateService.getState();
        expect(service).toBeDefined;
    }));

  it('Should call selocationurls...',
    inject([AppStateService], (appStateService: AppStateService) => {
      const service = appStateService.setLocationURLs();
      expect(service).toBeDefined;
   }));
});
