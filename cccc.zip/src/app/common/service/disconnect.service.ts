import { Injectable } from '@angular/core';
import { BlueMarbleService } from './bm.service';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
@Injectable()
export class DisconnectService {
    public isSchedulingReEntrant;
    public offersData = [];
    public accounInfo = {};

    constructor(private store: Store<AppStore>,
                private bMService: BlueMarbleService) { }

    /**
     * Scheduling API call from home page
     */
    public submitInformation(payload: any) {
        switch(payload.taskName){
            case 'Schedule Disconnect Date':
            this.store.dispatch({ type: 'ACCOUNT', payload: payload });   
            break;   
            case 'Account Information':
            this.store.dispatch({ type: 'REVIEW', payload: payload });   
            break;    
            case 'Submit Order':
            this.store.dispatch({ type: 'SUBMIT', payload: payload });   
            break;        
        }
        return this.bMService.submitTaskDisconnect(payload);
    }
    public submitReviewOrder(payload: any) {
        return this.bMService.submitTaskDisconnect(payload);
    }

    public initDisconnect(payload: any) {
        return this.bMService.initDisconnect(payload);
    }
    public viewRccsDisclosure(payload) {
        return this.bMService.getRccDisclosure(payload);
    }
}
