import { Injectable } from '@angular/core';
import { BlueMarbleService } from './bm.service';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
@Injectable()
export class SchedulingService {

    constructor(
        public bMService: BlueMarbleService,
        public store: Store<AppStore>) { }

    /**
     * Scheduling API call from home page
     */
    public shippingInformation(payload: any, flag: boolean) {
        if (flag) {
            return this.bMService.changeSubmitTask(payload);
        }
        else {
            this.store.dispatch({ type: 'ACCOUNT', payload: payload });
            return this.bMService.submitTask(payload);
        }
    }    
       
    public scheduleAppointment(payload: any, flag: boolean,agentFirstName,agentLastName, flow?: any, appointmentInfoNoValue?,exceptionDaysInfo?,exceptionfromDueDaysInfo?,vacation?) {
        this.store.dispatch({ type: 'ACCOUNT', payload: payload });
        if (flag && flow !== 'billing') {
            return this.bMService.changeSubmitTask(payload);
        } else if (!flag && flow === 'billing') {
            return this.bMService.billingSubmitTask(payload);
        } else if (!flag && flow === "Disconnect") {
            switch(payload.taskName){
                case 'Schedule Disconnect Date':
                this.store.dispatch({ type: 'ACCOUNT', payload: payload });   
                break;   
                case 'Account Information':
                this.store.dispatch({ type: 'REVIEW', payload: payload });   
                break;    
                case 'Submit Order':
                this.store.dispatch({ type: 'SUBMIT', payload: payload });   
                break;        
            }
            return this.bMService.submitTaskDisconnect(payload);
        } else if (!flag && flow === "COR") {
            return this.bMService.CORSubmitTask(payload);
        } else if(vacation){
            return this.bMService.scheduleVacationCall(payload)
        }else if (!flag && flow !== 'billing' && flow !== 'Move') {
            return this.bMService.submitTask(payload);
        } else if(flow === "Move"){
            let reqPayload = payload;
            let appointmentInfo: any;
            if (!appointmentInfoNoValue) {
                appointmentInfo = {
                    availableAppointment: reqPayload.payload.availableAppointment,
                    apptNotes: {
                        animalsPresent: reqPayload.payload.apptNotes.animalsPresent,
                        electricFence: reqPayload.payload.apptNotes.electricFence,
                        lockedGate: reqPayload.payload.apptNotes.lockedGate,
                        notes:
                            [
                                {
                                    name: 'Driving Directions',
                                    value: reqPayload.payload.apptNotes.notes && reqPayload.payload.apptNotes.notes[0] && reqPayload.payload.apptNotes.notes[0].value,
                                    author: agentFirstName + ' ' + agentLastName
                                  
                                },
                                {
                                    name: 'Additional Comments',
                                    value: reqPayload.payload.apptNotes.notes && reqPayload.payload.apptNotes.notes[1] && reqPayload.payload.apptNotes.notes[1].value,
                                    author: agentFirstName + ' ' + agentLastName
                                }
                            ]
                    }
                }
            } else { appointmentInfo = null; }
            let schReEntrantRetain = {
                orderRefNumber: reqPayload.orderRefNumber,
                processInstanceId: reqPayload.processInstanceId,
                taskId: reqPayload.taskId,
                taskName: reqPayload.taskName,
                payload:
                {
                    dueDate: reqPayload.payload.dueDate,
                    appointmentInfo: appointmentInfo,
                    shippingInfo: reqPayload.payload.shippingInfo,
                    cart: reqPayload.payload.cart,
                    exceptionDaysInfo: exceptionDaysInfo,
                    exceptionfromDueDaysInfo: exceptionfromDueDaysInfo,
                    addlOrderAttributes: reqPayload.payload.addlOrderAttributes,
                    productConfiguration: reqPayload.payload.productConfiguration ? reqPayload.payload.productConfiguration : null
                }
            };
            this.store.dispatch({ type: 'ACCOUNT', payload: schReEntrantRetain });
            return this.bMService.submitTask(payload, 'move');
        } 
    }

    public pendingRescheduleAppointment(payload: any) {
        return this.bMService.initSup2(payload);
    }

    public pendingConfirmReschedule(payload: any) {
        this.store.dispatch({ type: 'ACCOUNT', payload: payload });
        return this.bMService.submitTaskSup2(payload);
    }

    /**
     * appointment override function US248579
     */
    public overRideAppointment(request, orderFlow?: any) {
        if (orderFlow === 'SUP2') {
            return this.bMService.submitTaskSup2(request);
        } else if (orderFlow === 'Change') {
            return this.bMService.changeSubmitTask(request);
        } else if (orderFlow === 'Move') {
            return this.bMService.submitTask(request, 'move');
        } else if (orderFlow === 'billing') {
            return this.bMService.billingSubmitTask(request);
        } else if (orderFlow === "COR") {
            return this.bMService.CORSubmitTask(request);
        } else {
            return this.bMService.submitTask(request);
        }
    }
    public retrieveARNcode(request) {
        return this.bMService.RetrieveARNApptCall(request);
    }

}
