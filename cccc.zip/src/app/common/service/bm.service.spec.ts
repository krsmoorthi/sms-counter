import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BlueMarbleService } from './bm.service'
import { EnterpriseAddress } from '../models/cart.model';
import { AuthService } from './auth.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { MockServer } from 'app/MockServer.test';
import { PropertiesHelperService } from './propertiesHelper.service';
import { AppStateService } from './app-state.service';
import { Logger } from '../logging/default-log.service';
import { Router } from '@angular/router';
import 'rxjs/add/observable/of'
import { MockLogger } from './mockServices';
import { HttpHeaders } from '@angular/common/http';
import { env } from 'environments/environment';
const CryptoJS = require("crypto-js");
const base64 = require("crypto-js/enc-base64");

describe('BlueMarble service:', () => {
  let mockServer = new MockServer();
  let bmService: BlueMarbleService;
  const enterpriseAddress: EnterpriseAddress = {
    addressLine: 'ETA 3',
    street: 'Navalur',
    city: 'Chennai',
    stateOrProvince: 'Tamilnadu',
    postCode: '522509',
    country: 'India'
  };

  const mockRedux: any = {
    dispatch(action) { },
    configureStore() { },
    select(reducer) {
      return Observable.of(
        mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  }

  let mockStore = { provide: Store, useValue: mockRedux };
  let logger = { provide: Logger, useClass: MockLogger };

  class MockAppStateService {
    getState() {
      return mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE");
    }
  }

  class MockAuthService {
    getJWTToken(force?: boolean): any {
      let jwtTok = 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhcGljbGllbnRAY3RsLmNvbSIsImlzcyI6IkN0bCIsImlhdCI6MTQ3OTgxNTA5MSwiZXhwIjoxNzkwODU1MDkxfQ.kc-P35bWdS_7qWslOXs7mtcW3CcSZ8fU2jTDtc6uRUiBMhWr1U_3cG3Yoew9nYjgGkvcaRHMl_QHDiEarIrHdA';
      return jwtTok;
    }
    setRequestOptions(authToken:
      string, jwtTok?:
        string) {
      // create authorization header with jwt token
      let authTokenStatic = 'ZXNob3BhcHA6aHlGWDhzRHRZTWtjYnNXWkN1Q1hiMjRT';
      let fingerPrint = "c0067ab08b084c46a30ad1a6cf96561d"
      if (jwtTok) {
        let headers =
          new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
            'Access-Control-Allow-Headers': 'X-Custom-Header',
            'Access-Control-Allow-Origin': '*',
            'X-Requested-With': 'XMLHttpRequest',
            'X-B3-TraceID': fingerPrint
          });

        if (authToken &&
          authToken !== "") {
          headers = new HttpHeaders({
            'Authorization': 'Basic ' + jwtTok,
            'Content-Type': 'application/json',
            'authToken': authToken,
            'X-B3-TraceID': fingerPrint

          });
        } else {
          headers = new HttpHeaders({
            'Authorization': 'Basic ' + authTokenStatic,
            'Content-Type': 'application/json',
            'authToken': jwtTok,
            'X-B3-TraceID': fingerPrint

          });
        }

        var epochTime = new Date().getTime().toString();
        var hmac = CryptoJS.HmacSHA256(epochTime, "AKI1443262019032820211378679142", { asBytes: true });
        var base64String = base64.stringify(hmac);
        var appToken = "APPKEY596132019032820211378667325";
        headers = new HttpHeaders({
          'Content-Type': 'application/json',
          'Accept': '*/*',
          'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
          'Access-Control-Allow-Headers': 'X-Custom-Header',
          'Access-Control-Allow-Origin': '*',
          'X-Requested-With': 'XMLHttpRequest',
          "X-Digest": base64String,
          "X-Digest-Time": epochTime,
          "X-Application-Key": appToken,
          'X-B3-TraceID': fingerPrint
        });

        return { headers }
      } else {
        let headers =
          new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
            'Access-Control-Allow-Headers': 'X-Custom-Header',
            'Access-Control-Allow-Origin': '*',
            'X-Requested-With': 'XMLHttpRequest',
            'X-B3-TraceID': fingerPrint
          });
        return { headers }
      }

    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BlueMarbleService,
        { provide: AuthService, useClass: MockAuthService },
        PropertiesHelperService,
        { provide: AppStateService, useClass: MockAppStateService },
        {
          provide: Router,
          useClass: class { navigate = jasmine.createSpy("navigate"); }
        },
        logger,
        mockStore
      ],
      imports: [
        HttpClientTestingModule
      ]
    });
    bmService = TestBed.get(BlueMarbleService);
  })

  it("should create service", () => {
    expect(bmService).toBeDefined();
  });

  it('check geoamServiceCall service', () => {
    bmService.geoamServiceCall(enterpriseAddress);
    expect(bmService.geoamServiceCall(enterpriseAddress)).toBeDefined();
  });

  it('Should call initAddress...',
    () => {
      const service = bmService.initAddress(enterpriseAddress);
      expect(service).toBeDefined();
    });

  it('Should call submitTask...', () => {
    const service = bmService.submitTask(enterpriseAddress);
    expect(service).toBeDefined();
  });
  it('Should call billing submitTask...', () => {
    const service = bmService.submitTask(enterpriseAddress, 'billing');
    expect(service).toBeDefined();
  });

  it('Should call change submitTask...', () => {
    const service = bmService.changeSubmitTask('enterpriseAddress');
    expect(service).toBeDefined();
  });
  it('Should call getOffersFromLink...', () => {
    const service = bmService.getOffersFromLink('enterpriseAddress');
    expect(service).toBeDefined();
  });
  it('Should call initSup1...', () => {
    const service = bmService.initSup1('enterpriseAddress');
    expect(service).toBeDefined();
  });
  it('Should call supRemarkUpdate...', () => {
    const service = bmService.supRemarkUpdate('enterpriseAddress');
    expect(service).toBeDefined();
  });
  it('Should call initDisconnect...', () => {
    const service = bmService.initDisconnect('enterpriseAddress');
    expect(service).toBeDefined();
  });

  it('Should call billingsubmitTask...', () => {
    const service = bmService.billingSubmitTask(enterpriseAddress);
    expect(service).toBeDefined();
  });
  it('Should call move  submitTask...', () => {
    const service = bmService.moveSubmitTask(enterpriseAddress);
    expect(service).toBeDefined();
  });

  it('check getCSCompatibilityRules service', () => {
    expect(bmService.getCSCompatibilityRules()).toBeDefined()
  });

  it('check getTechnologyTypes service', () => {
    expect(bmService.getTechnologyTypes()).toBeDefined()
  });

  it('check getCommunityRules service', () => {
    expect(bmService.getCommunityRules()).toBeDefined()
  });
  it('check properties service', () => {
    let properties = {
      system: 'ESHOP'
    };
    expect(bmService.properties(properties)).toBeDefined()
  });
  it('check getE911API method', () => {
    let address = mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")['user'].orderInit.payload.serviceAddress
    let request = {
      streetDirectionPrefix: '',
      streetAddress: address.streetName,
      location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
      streetNrFirst: address.streetNrFirst,
      city: address.city ? address.city : address.locality,
      stateOrProvince: address.stateOrProvince,
      postCode: address.postCode,
      postCodeSuffix: address.postCodeSuffix
    };
    expect(bmService.getE911API(request)).toBeDefined()
  })
  it('check NPAXXX method', () => {
    let NPANXXListRequest = {
      orderReferenceNumber: "",
      productType: "VOICE-DHP"
    };
    const returnVal = bmService.getNPANXXList(NPANXXListRequest)
    expect(returnVal).toBeDefined()
  })
  it('check AutoLogin method', () => {
    let token = {};
    const returnVal = bmService.autoLogin(token)
    expect(returnVal).toBeDefined()
  })
  it("Get initNonpaySupspend method", () => {
    let temp = bmService.initNonpaySupspend('active');
    expect(temp).toBeDefined();
  })
  it("Get submitNonpaySupspend method", () => {
    let temp = bmService.submitNonpaySupspend('active');
    expect(temp).toBeDefined();
  })
  it("Get initDisconnect method", () => {
    let temp = bmService.initDisconnect('active');
    expect(temp).toBeDefined();
  })
  it("Get Reasons for Hold method", () => {
    let temp = bmService.getReasonsForHold('active');
    expect(temp).toBeDefined();
  })
  it("Get Reasons for Hold method", () => {
    let offerName = {
      "inputAttribute": [
        {
          "attributeName": "productOfferId",
          "attributeValue": "EO000354"
        }
      ],
      "outputAttribute": [
        {
          "attributeName": "productOfferId"
        },
        {
          "attributeName": "offerName"
        },
        {
          "attributeName": "offerDisplayName"
        },
        {
          "attributeName": "offerCategory"
        },
        {
          "attributeName": "offerType"
        },
        {
          "attributeName": "bundlePromoId"
        }
      ],
      "ruleId": "75"
    }
    let temp = bmService.getReasonsForHold(offerName);
    expect(temp).toBeDefined();
  })
  it("Get removeOrderFromHold method", () => {
    let temp = bmService.removeOrderFromHold('active', 'MOVE');
    expect(temp).toBeDefined();
  })
  it("Get getCompatibilityRules method", () => {
    bmService.getCompatibilityRules();
    let temp = bmService.getCompatibilityRules(true);
    expect(temp).toBeDefined();
  })
  it("Get getSwitchByTN method", () => {
    let temp = bmService.getSwitchByTN('967784590');
    expect(temp).toBeDefined();
  })
  it("Get prepaidCancelOrderCode method", () => {
    let request: any = {
      "accountID": 'PPB11055731',
      "accountStatus": "DISCONNECT",
      "orderReferenceNumber": "ORN-7553782513960618",
      "userDetail": {
        "userId": 'ac31233',
        "userType": "2"
      }
    }
    let temp = bmService.prepaidCancelOrderCode(request);
    expect(temp).toBeDefined();
  })
  it("check getRemoveChange Method", () => {
    let request: any = {
      rsnType: "DISCONNECT"
    };
    let temp = bmService.getRemoveChange(request);
    expect(temp).toBeDefined();
  })
  it("check doTnPortingCheck Method", () => {
    let request: any = {
      "orderReferenceNumber": "ORN-7553782513960618",
      "productType": 'VOICE-HP',
      "accessPin": '7345',
      "retainOtherNumbers": '',
      "portingInfoRetain": "YES",
      "salesChannel": "ESHOP-Customer Care",
      "portCheckRequest": [
        {
          "telephoneNumber": '9845680760'
        }
      ],
      "addressInfo": {},
    }
    let temp = bmService.doTnPortingCheck(request);
    expect(temp).toBeDefined();
  })
  it("getCarrier info method ", () => {
    let url = 'https://eshop-test2.test.intranet/eshop/customerCare/dist/product-offer'
    let _env = '/api-test2.test.intranet';
    let res = url.indexOf(_env);
    let strpl = url.substring(res + _env.length, url.length);
    let temp = bmService.getCarrierInfo(strpl);
    expect(temp).toBeDefined();
  })
  it("Giftcard Eligibility method", () => {
    let eligibilityRequest = {
      "catalogName": "Catalog NE PAPILLION OMAHNE84 ESHOP-Customer Care Individual Regular",
      "city": "",
      "giftCardOfferName": "SAVE $100 Move HSI Visa Offer",
      "state": "",
      "wireCenter": ""
    };
    let temp = bmService.cardEligibility(eligibilityRequest)
    expect(temp).toBeDefined();
  })
  it("COR Method", () => {
    let request = {
      orderRefNumber: 'ORN-7553782513960618',
      processInstanceId: "02277535-727d-11ea-8150-7adb3a02d1cb",
      taskId: "3528dc4a-727d-11ea-8150-7adb3a02d1cb",
      taskName: "Confirm Scheduling",
      payload: {
        "creditReviewAction": "SHOWSUMMARY",
        "accountName": {
          "firstName": "PAMELA",
          "lastName": "DEWITT",
          "middleName": "",
          "businessName": null,
          "title": "Mr",
          "generation": null
        },
        "personalDetails": {
          "dateOfBirth": null,
          "dLExpirationDate": null,
          "dLlicenseNo": null,
          "dLlicenseState": null,
          "ssn": null,
          "taxId": null,
          "creditCheck": true,
          "underAgeAck": null
        },
        "addlOrderAttributes": [
          {
            "orderAttributeGroup": [
              {
                "orderAttributeGroupName": "otcInstallmentInfo",
                "orderAttributeGroupInfo": []
              }
            ]
          }
        ]
      }
    };
    let temp = bmService.CORSubmitTask(request)
    expect(temp).toBeDefined();
  })
  it("initCORespCall Method", () => {
    let request = {
      ban: "683036280",
      salesChannel: "ESHOP-Customer Care",
      customerType: "Individual",
      customerSegment: "Retail",
      customerOrderType: "CHANGERESP",
      party: {
        id: 'ac31233',
        firstName: 'Mohinder',
        lastName: 'Reddy',
        type: "CSR",
        partyRoles: [
          {
            partyRole: env.CSR_NAME,
            sourceSystem: env.CSR_PROFILE,
            id: 'ac31233'
          },
          {
            partyRole: env.ENSEMBLEID,
            sourceSystem: env.ENS_OPERATOR,
            id: 1108402
          }
        ]
      },
    }
    let temp = bmService.initCORespCall(request)
    expect(temp).toBeDefined();
  })
  it("Quick Connect Data", () => {
    let request = 'sample@ctl.com'
    let temp = bmService.initCORespCall(request)
    expect(temp).toBeDefined();
  }) 
  it("getBypassInternetDiscounts method", () => {
    let request = {
      "orderDetail": { "orderRefNumber": "ORN-7553782513960618" },
      "discountRequestedType": "All"
    }
    let temp = bmService.getBypassInternetDiscounts(request)
    expect(temp).toBeDefined();
  })
  it("getBypassGiftCards method", () => {
    let request = {
      "orderRefNumber": "ORN-7553782513960618" ,
      "giftCardRequestedType": "Unqualified",
    }
    let temp = bmService.getBypassGiftCards(request)
    expect(temp).toBeDefined();
  })
  /* need to frame payload request for below test cases*/
  it("validateStackAmend Method", () => {    
    let temp = bmService.validateStackAmend('request')
    expect(temp).toBeDefined();
  })
  it("validateDealerCode Method", () => {    
    let temp = bmService.validateDealerCode('request')
    expect(temp).toBeDefined();
  })
  it("retrieveProductDealerCodeInfo Method", () => {    
    let temp = bmService.retrieveProductDealerCodeInfo('request')
    expect(temp).toBeDefined();
  })
  it("getProfile Method", () => {    
    let temp = bmService.getProfile('request')
    expect(temp).toBeDefined();
  })
  it("getFreezeDropDown Method", () => {    
    let temp = bmService.getFreezeDropDown('request')
    expect(temp).toBeDefined();
  })
  it("getRccDisclosure Method", () => {    
    let temp = bmService.getRccDisclosure('request')
    expect(temp).toBeDefined();
  })
  it("vacationAccountSubmitTask Method", () => {    
    let temp = bmService.vacationAccountSubmitTask('request')
    expect(temp).toBeDefined();
  })
  it("retrieveRcc Method", () => {    
    let temp = bmService.retrieveRcc('request')
    expect(temp).toBeDefined();
  })
  it("vacationSubmitTask Method", () => {    
    let temp = bmService.vacationSubmitTask('request')
    expect(temp).toBeDefined();
  })
  it("vacationSchedulingSubmitTask Method", () => {    
    let temp = bmService.vacationSchedulingSubmitTask('request')
    expect(temp).toBeDefined();
  })
  it("scheduleVacationCall Method", () => {    
    let temp = bmService.scheduleVacationCall('request')
    expect(temp).toBeDefined();
  })
  it("initVacationCall Method", () => {    
    let temp = bmService.initVacationCall('request')
    expect(temp).toBeDefined();
  })
  it("supHoldSubmit Method", () => {    
    let temp = bmService.supHoldSubmit('request')
    expect(temp).toBeDefined();
  })
  it("captureDtvRequest Method", () => {    
    let temp = bmService.captureDtvRequest('request')
    expect(temp).toBeDefined();
  })
  it("orderDtvProcess Method", () => {    
    let temp = bmService.orderDtvProcess('request')
    expect(temp).toBeDefined();
  })  
  it("enterDTVManually Method", () => {    
    let temp = bmService.enterDTVManually('request')
    expect(temp).toBeDefined();
  })
  it("retrieveDtvOrder Method", () => {    
    let temp = bmService.retrieveDtvOrder('request')
    expect(temp).toBeDefined();
  })
  it("supHoldInit Method", () => {    
    let temp = bmService.supHoldInit('request')
    expect(temp).toBeDefined();
  })
  it("submitOrderHold Method", () => {    
    let temp = bmService.submitOrderHold('request')
    expect(temp).toBeDefined();
  })
  it("getCompatibilityRulesforClosers Method", () => {    
    let temp = bmService.getCompatibilityRulesforClosers('request')
    expect(temp).toBeDefined();
  })
  it("getInternationalBillingCountryList Method", () => {    
    let temp = bmService.getInternationalBillingCountryList('request')
    expect(temp).toBeDefined();
  })
  it("overrideApptCall Method", () => {    
    let temp = bmService.overrideApptCall('request')
    expect(temp).toBeDefined();
  })
  it("RetrieveARNApptCall Method", () => {    
    let temp = bmService.RetrieveARNApptCall('request')
    expect(temp).toBeDefined();
  })
  it("getLATA Method", () => {    
    let temp = bmService.getLATA('request')
    expect(temp).toBeDefined();
  })
  it("getReasonsForHold Method", () => {    
    let temp = bmService.getReasonsForHold('34567799')
    expect(temp).toBeDefined();
  })
  it("getVendorLocations Method", () => {    
    let temp = bmService.getVendorLocations('request')
    expect(temp).toBeDefined();
  })
  
  it("getOrderProgressStatus Method", () => {    
    let temp = bmService.getOrderProgressStatus('request')
    expect(temp).toBeDefined();
  })
  it("releaseTNCall Method", () => {    
    let temp = bmService.releaseTNCall('request')
    expect(temp).toBeDefined();
  })
  it("reserveTNCall Method", () => {    
    let temp = bmService.reserveTNCall('request')
    expect(temp).toBeDefined();
  })
  it("getAvailableNumber Method", () => {    
    let temp = bmService.getAvailableNumber('request')
    expect(temp).toBeDefined();
  })
  it("submitTaskSup2 Method", () => {    
    let temp = bmService.submitTaskSup2('request')
    expect(temp).toBeDefined();
  })
  it("initSup2 Method", () => {    
    let temp = bmService.initSup2('request')
    expect(temp).toBeDefined();
  })
  it("submitTaskSup1 Method", () => {    
    let temp = bmService.submitTaskSup1('request')
    expect(temp).toBeDefined();
  })
  it("getPaymentDetails Method", () => {    
    let temp = bmService.getPaymentDetails('request')
    expect(temp).toBeDefined();
  })
  it("pendingSummary Method", () => {    
    let temp = bmService.pendingSummary('request')
    expect(temp).toBeDefined();
  })
  it("geoesServiceCall Method", () => {    
    let temp = bmService.geoesServiceCall('request')
    expect(temp).toBeDefined();
  })
  it("productConfigCall Method", () => {    
    let temp = bmService.productConfigCall('request')
    expect(temp).toBeDefined();
  })
  it("moveAddress Method", () => {    
    let temp = bmService.moveAddress('request')
    expect(temp).toBeDefined();
  })
  it("getAvailableTNs Method", () => {    
    let temp = bmService.getAvailableTNs('request')
    expect(temp).toBeDefined();
  })
  it("getPotsTnAvailability Method", () => {    
    let temp = bmService.getPotsTnAvailability('request')
    expect(temp).toBeDefined();
  })
  it("submitTaskDisconnect Method", () => {    
    let temp = bmService.submitTaskDisconnect('request')
    bmService.sleep(363600)
    expect(temp).toBeDefined();
  }) 
 
})