/* tslint:disable */
import { Injectable } from '@angular/core';

@Injectable()
export class TextMaskService {

    public maskForUsaPhone = ['(', /[2-9]/, /[0-8]/, /\d/, ')', ' ', /[2-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public maskForTN = [/[2-9]/, /[0-8]/, /\d/, '-', /[1-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public maskForPhoneWithPlusOne = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public maskForUsaZip = [/[1-9]/, /\d/, /\d/, /\d/, /\d/];
    public maskForCanadaZip = [/[1-9]/, /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/];
    public maskForPhoneExtn = [/[1-9]/, /\d/, /\d/, /\d/];
    public maskForSsn = [/\d|x/, /\d|x/, /\d|x/, '-', /\d|x/, /\d|x/, '-', /\d|x/, /\d|x/, /\d|x/, /\d|x/];

    getPhoneNumberMaskFormat() {
        return this.maskForUsaPhone;
    }

    getPhoneNumberMaskTN() {
        return this.maskForTN;
    }

    getMaskForUsaZip() {
        return this.maskForUsaZip;
    }

    getPhoneNumberExtnMaskFormat() {
        return this.maskForPhoneExtn;
    }

    getSsnMask() {
        return this.maskForSsn;
    }
}
