import { CTLHelperService } from "./ctlHelperService";
import { Location } from "@angular/common";
import { MockServer } from '../../MockServer.test';
import { Observable } from 'rxjs/Observable';

describe('ctlHelperService Tests', () => {
    let ctlHelperService;

    let jsonObject = { "errorResponse": [{ "statusCode": "404","reasonCode": "ORDERSUMMARY_SERVER_UNAVAILABLE", "message": "The server cannot handle the request for a service due to temporary maintenance.", "messageDetail": "System is undergoing maintainance work. Please resubmit the request after sometime.", "source": "ORDERSUMMARY", "timestamp": "2018-11-07 07:53:02.317", "orderRefNumber": "" }], "payload": null };
    
    let htmlObject = `<html>
    <head><title>504 Gateway Time-out</title></head>
    <body bgcolor="white">
    <center><h1>504 Gateway Time-out</h1></center>
    <hr><center>nginx/1.15.3</center>
    </body>
    </html>
    `;

    let response = {status: 200, payload: { address: 'test'}};
    let mockServer = new MockServer();
    
    let req = {
        taskName: 'init'
      };
    let response1 = { orderInit: mockServer.getResponseForRequest('submitTask', req) };
    const mockRedux: any = { // explicitly saying any here is important
        dispatch(action) { },
        configureStore() { },
        select(action) {
          if (action === 'existingProducts') {
            return Observable.of(mockServer.getResponseForReducerAndApi('existingProductState1'));
          } else if (action === 'retain') {
            return Observable.of(mockServer.getResponseForReducerAndApi('retainState1'));
          } else if (action === 'user') {
            return Observable.of(mockServer.getResponseForReducerAndApi('user-agent1'));
          }
          return Observable.of(response1);
    
        },
        take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
        }
      };
    beforeEach(() => {
        let location: Location;
		ctlHelperService = new CTLHelperService();
    });
    
    it('should return true when object is json', () => {
        expect(ctlHelperService.isJson(JSON.stringify(jsonObject))).toBe(true);
    });

    it('should return false when object is not json', () => {
        expect(ctlHelperService.isJson(htmlObject)).toBe(false);
    });

    it('should return false when object is not json', () => {
        expect(ctlHelperService.isJson(" ")).toBe(false);
    });

    it('should be able to set, get and remove local storage', () => {
        ctlHelperService.setLocalStorage('error', jsonObject);
        let error1 = ctlHelperService.getLocalStorage('error');
        expect(error1).toBeDefined;
        ctlHelperService.removeLocalStorage('error');
    });

});