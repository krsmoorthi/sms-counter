import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Logger } from 'app/common/logging/default-log.service';
import { Subscription } from 'rxjs/Subscription';
import { AppStore } from 'app/common/models/appstore.model';
import { CustomerOrderItems, CustomerOrderSubItem, ShoppingCart, Payload, ContactInfo } from 'app/common/models/cart.model';
import { GenericValues, Switch, serverErrorMessages, ErrorResponse } from 'app/common/models/common.model';
import { OffersByFilters, OfferVariables, ProfileFlags, filterCriteria } from 'app/common/models/offers.model';
import { User } from 'app/common/models/user.model';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { HelperService } from "app/common/service/helper.service";
import {
	AttributesCombination, CompositeAttribute, Catalogs, Discounts, OfferGroup, AssociatedOffers, OfferItems,
	OfferProductComponents, Prices, ProductOfferings, Products, Product, ServiceCategoryBasedOffers, PayloadProduct
} from 'app/common/models/product.model';
import { ProductService } from './product.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { SystemErrorService } from 'app/common/service/system-error.service';

import { APIErrorLists } from 'app/common/models/common.model';
import { RE_ENTRANT_OFFERVARIABLE } from 'app/app.constant';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/operator/catch";
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisclosuresRes } from 'app/common/models/disclosures.model';
import { VacationEnums } from 'app/common/enums/vacationEnums';
import { env } from '../../../environments/environment';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { BlueMarbleService } from 'app/common/service/bm.service';
import * as _ from 'lodash';
import { AddressService } from './address.service';
import { DisconnectService } from 'app/common/service/disconnect.service';

@Injectable()

export class OfferHelperService {

	constructor(
		public store: Store<AppStore>,
		public logger: Logger,
		public systemErrorService: SystemErrorService,
		public ctlHelperService: CTLHelperService,
		private productService: ProductService,
		public appStateService: AppStateService,
		public disclosuresService: DisclosuresService,
		private helperService: HelperService,
		private bMService: BlueMarbleService,
		private router: Router,
		private addressService: AddressService,
		private disconnectServiceCall: DisconnectService) {
	}

	public retrieveOffersByFilter(data: any) {
		var offersByFilters = {} as OffersByFilters;
		var qualifiedFilter: any;
		var qualifiedUnfilter: any;
		var unQualifiedOffers: any;

		qualifiedFilter = this.extractOffersByFilter(data, 'Qualified-Filtered');
		if (qualifiedFilter) {
			offersByFilters.qualifiedFilter = qualifiedFilter.sort(this.dynamicSort("displayOrder"));
		}
		qualifiedUnfilter = this.extractOffersByFilter(data, 'Qualified-Unfiltered');
		if (qualifiedUnfilter) {
			offersByFilters.qualifiedUnfilter = qualifiedUnfilter.sort(this.dynamicSort("displayOrder"));
		}
		unQualifiedOffers = this.extractOffersByFilter(data, 'Unqualified');
		if (unQualifiedOffers) {
			unQualifiedOffers = unQualifiedOffers.sort(this.dynamicSort("displayOrder"));
			if (qualifiedUnfilter) {
				qualifiedUnfilter.forEach(qualUn => {
					unQualifiedOffers.push(qualUn);
				});
			}
			offersByFilters.unQualifiedOffers = unQualifiedOffers.sort(this.dynamicSort("displayOrder"));
		}
		return offersByFilters;
	}

	public dynamicSort(property) {
		var sortOrder = 1;
		if (property[0] === "-") {
			sortOrder = -1;
			property = property.substr(1);
		}
		return function (a, b) {
			var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
			return result * sortOrder;
		};
	}

	public dynamicSortNestedArray(array, property, sortOrder?) {
		property = property.split('.');
		if (sortOrder && sortOrder === "DESC") {
			sortOrder = -1;
		}

		array.sort(function (a, b) {
			a = a[property[0]][0][property[1]];
			b = b[property[0]][0][property[1]];
			var result = (a < b) ? -1 : (a > b) ? 1 : 0;
			return result * sortOrder;
		});
		return array;
	}

	public extractOffersByFilter(retrievalTypes: any, filterBy: string): any {
		let offers = retrievalTypes.find(item => item.retrievalType === filterBy);
		if (offers && offers.offers) {
			let dataOffers = offers.offers.find(currentOffer => currentOffer.serviceCategory === "DATA");
			if (dataOffers && dataOffers.catalogs && dataOffers.catalogs[0] &&
				dataOffers.catalogs[0].catalogItems && dataOffers.catalogs[0].catalogItems.length > 0) {
				return dataOffers.catalogs[0].catalogItems;
			}
		}
	}

	public getOfferPrice(item: ProductOfferings, prod: Products, price: number, filterBySpeed: string, type: string): number {
		let flag: boolean = false;
		prod = this.searchforPrimary(item.productOffer.productComponents,
			GenericValues.cPrimary);
		if (prod.productName === filterBySpeed) {
			if (!flag) {
				if (item.defaultOfferPrice !== null && item.defaultOfferPrice !== undefined) {
					if (type === 'disc') {
						(item.defaultOfferPrice.discountedRc === 0 || item.defaultOfferPrice.discountedRc === 0.00) ?
							price = item.defaultOfferPrice.discountedOtc === item.defaultOfferPrice.otc ? 0 : item.defaultOfferPrice.discountedOtc
							: price = item.defaultOfferPrice.discountedRc === item.defaultOfferPrice.rc ? 0 : item.defaultOfferPrice.rc;
					} else {
						(item.defaultOfferPrice.rc === 0 || item.defaultOfferPrice.rc === 0.00) ?
							price = item.defaultOfferPrice.otc : price = item.defaultOfferPrice.rc;
					}
				}
			}
		}
		return price;
	}

	/**
	 * To get Internet Component from Select Offer
	 * @param componentList
	 * @param type
	 */
	public searchforPrimary(componentList: OfferProductComponents[], type: string) {
		let product: Products = {};
		let flag: boolean = false;
		componentList && componentList.forEach((prod) => {
			if (!flag && prod.componentType === type) {
				flag = true;
				return product = prod.product;
			}
		});
		return product;
	}
	/**
	 * VIDEO SECTION
	 * @param selectedTVOffer
	 */

	public videoSlot(offerVariables, selectedTVOffer: ProductOfferings) {
		offerVariables.selectedTVOffer = selectedTVOffer;
		let price = 0;
		offerVariables.actualTVPrice = price;
		offerVariables.discountedTVPrice = price;
		let prod: Products = this.searchforPrimary(selectedTVOffer.productOffer
			.productComponents, GenericValues.cPrimary);
		offerVariables.selectedTV = prod.productName;
		if (prod.productAttributes !== null && prod.productAttributes.length > 0) {
			offerVariables.actualTVPrice = selectedTVOffer.defaultOfferPrice.rc;
			offerVariables.discountedTVPrice = selectedTVOffer.defaultOfferPrice.discountedRc;
			offerVariables.actualTVOtcPrice = selectedTVOffer.defaultOfferPrice.otc;
			offerVariables.discountedTVOtcPrice = selectedTVOffer.defaultOfferPrice.discountedOtc;
			offerVariables.errorMsg = serverErrorMessages.empty;
			let attr = this.fetchIsPriceable(prod.productAttributes);
			let discounts: Discounts[] = [];
			attr.discounts === null ? discounts = [] : discounts = attr.discounts;
			for (let discount of discounts) {
				if (discount.autoAttachInd === 'Y' && (discount.discountRule === null || discount.discountRule === 'A' || discount.discountRule === 'I' || discount.discountRule === 'O' || (discount.discountRule && discount.discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
					offerVariables.discountedPriceList.push(discount);
				}
			}
			offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
				this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
		} else {
			offerVariables.errorMsg = serverErrorMessages.priceObjectNull;
		}
		offerVariables.hdPrice = price;
		offerVariables.dvrPrice = price;
		let hdvr = this.filterProductByType(offerVariables, selectedTVOffer, GenericValues.cHD);
		if (hdvr !== undefined) {
			offerVariables.hdService = hdvr.product;
			if (offerVariables.hdService.productAttributes[0].prices !== null && offerVariables.hdService.productAttributes[0].prices.length > 0) {
				offerVariables.hdService.productAttributes[0].prices[0].discountedOtc === 0 ? offerVariables.hdService.productAttributes[0].prices[0].otc === 0 ?
					offerVariables.hdService.productAttributes[0].prices[0].discountedRc === 0 ? offerVariables.hdPrice = offerVariables.hdService
						.productAttributes[0].prices[0].rc : offerVariables.hdPrice = offerVariables.hdService.productAttributes[0].prices[0].discountedRc :
					offerVariables.hdPrice = offerVariables.hdService.productAttributes[0].prices[0].otc : offerVariables.hdPrice = offerVariables.hdService
						.productAttributes[0].prices[0].discountedOtc;
				offerVariables.hdService = hdvr.product;
			}
		}
		hdvr = this.filterProductByType(offerVariables, selectedTVOffer, GenericValues.cDVR);
		if (hdvr !== undefined) {
			offerVariables.dvrService = hdvr.product;
			if (offerVariables.dvrService.productAttributes[0].prices !== null && offerVariables.dvrService.productAttributes[0].prices.length > 0) {
				offerVariables.dvrService.productAttributes[0].prices[0].discountedOtc === 0 ? offerVariables.dvrService.productAttributes[0].prices[0].otc === 0 ?
					offerVariables.dvrService.productAttributes[0].prices[0].discountedRc === 0 ? offerVariables.dvrPrice =
						offerVariables.dvrService.productAttributes[0].prices[0].rc : offerVariables.dvrPrice = offerVariables.dvrService.productAttributes[0].prices[0]
							.discountedRc : offerVariables.dvrPrice = offerVariables.dvrService.productAttributes[0].prices[0].otc : offerVariables.dvrPrice
					= offerVariables.dvrService.productAttributes[0].prices[0].discountedOtc;
				offerVariables.dvrService = hdvr.product;
			}
		}
		// to get existing disounts for MACD flows
		if (offerVariables.existingServices) {
			if (prod.productAttributes !== null && prod.productAttributes.length > 0) {
				this.fetchIsPriceable(prod.productAttributes);
				let discounts: Discounts[] = [];
				// find the existing discount availble in the current offer
				for (let existdiscount of offerVariables.existingRetentionDiscounts) {
					let existingDiscountMatchFound = false;
					for (let discount of discounts) {
						if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {

							existingDiscountMatchFound = true;
						}
					}

					if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
						offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
						offerVariables.isShowRemoveRetentionDiscountMsg = true;
					}
					// send only discounts matching in current offer and not the otc discounts.
					if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
						offerVariables.retentionDiscountsToCart.push(existdiscount);

					}
				}
				if (!offerVariables.reEntrant) {
					this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart });
				}
				if (offerVariables.videoSelected === 'NoTV' && !offerVariables.phoneOffer) {
					offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
						this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
				}
			}
		}

		let surcharge: OfferProductComponents = this.filterProductByType(offerVariables, selectedTVOffer, GenericValues.cSurcharge);
		if (surcharge !== undefined) {
			offerVariables.stb = surcharge.product;
			offerVariables.maxTSTB = this.maxValue(offerVariables.stb, GenericValues.cTotalSTB, false);
			offerVariables.selectedTotal = offerVariables.maxTSTB[0];
			this.onChangeTotal(offerVariables, offerVariables.selectedTotal);
		} else {
			this.shoppingCartRequest(offerVariables);
		}
		offerVariables.loading = false;
		offerVariables.reentrantUI = false;
		offerVariables.retrieveOffersLoading = false;
	}

	public onChangeTotal(offerVariables, value: string) {
		offerVariables.selectedTotal = value;
		offerVariables.maxWSTB = this.maxValue(offerVariables.stb, GenericValues.cWSTB, true, value, GenericValues.cTotalSTB);
		offerVariables.selectedWire = offerVariables.maxWSTB[0];
		this.fetchPriceforSTB(offerVariables);
	}
	public fetchPriceforSTB(offerVariables) {
		let flag: boolean = false;
		offerVariables && offerVariables.stb && offerVariables.stb.productAttributes &&
			offerVariables.stb.productAttributes.forEach((attrVal) => {
				if (attrVal.isPriceable) {
					if (!flag && this.getValueofWSTB(attrVal, GenericValues.cWSTB) === offerVariables.selectedWire
						&& this.getValueofWSTB(attrVal, GenericValues.cTotalSTB) === offerVariables.selectedTotal) {
						flag = true;
						offerVariables.selectedSTB = offerVariables.stb;
						offerVariables.selectedSTB = Object.assign({},
							offerVariables.selectedSTB, {
							productAttributes: [attrVal]
						});
						this.getSTBPrice(offerVariables, 'Wired Set Top Box');
						this.getSTBPrice(offerVariables, 'Wireless Set Top Box');
						this.shoppingCartRequest(offerVariables);
					}
				}
			});

		this.shoppingCartRequest(offerVariables);
	}
	// dhp Slot
	public dhpSlot(offerVariables, offer: ProductOfferings) {
		offerVariables.internationalDialing = undefined;
		offerVariables.internationalPrice = 0;
		offerVariables.selectedDHPOffer = offer;
		offerVariables.dhpOfferPriceDiscountedRc = 0;
		offerVariables.dhpOfferPriceDiscountedOtc = 0;
		if (offer.defaultOfferPrice !== null && offer.defaultOfferPrice !== undefined) {
			offerVariables.dhpOfferPriceDiscountedRc = offer.defaultOfferPrice.discountedRc;
			offerVariables.dhpOfferPriceDiscountedOtc = offer.defaultOfferPrice.discountedOtc;
		}
		offer.productOffer.productComponents.forEach(data => {
			if (data.componentType !== GenericValues.cPrimary && data.product.productName === 'Digital Home Phone Intl Call') {
				offerVariables.internationalDialing = data;
				if (data.product.productAttributes !== null && data.product.productAttributes && data.product.productAttributes.length !== 0) {
					data.product.productAttributes.forEach(attr => {
						if (attr.isPriceable && attr.prices !== null && attr.prices && attr.prices.length !== 0) {
							if (!offerVariables.existingServices) {
								if (attr && attr.discounts !== null && attr.discounts.length > 0) {
									for (let i = 0; i < attr.discounts.length; i++) {
										if (attr.discounts[i].autoAttachInd === 'Y' && (attr.discounts[i].discountRule === null || attr.discounts[i].discountRule === 'A' || attr.discounts[i].discountRule === 'I' || attr.discounts[i].discountRule === 'O' || (attr.discounts[i].discountRule && attr.discounts[i].discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
											offerVariables.discountedPriceList.push(attr.discounts[i]);
										}
									}
								}
								offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
									this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
							}
							attr.prices.forEach(price => {
								if (price.discountedRc !== 0) {
									offerVariables.internationalPrice = price.discountedRc;
								} else if (price.rc !== 0) {
									offerVariables.internationalPrice = price.rc;
								} else if (price.discountedOtc !== 0) {
									offerVariables.internationalPrice = price.discountedOtc;
								} else if (price.otc !== 0) {
									offerVariables.internationalPrice = price.otc;
								}
							});
						}
					});
				}
			} else {
				if (data.product.productAttributes !== null && data.product.productAttributes && data.product.productAttributes.length !== 0 && !offerVariables.existingServices) {
					data.product.productAttributes.forEach(attr => {
						if (attr.isPriceable && attr.prices !== null && attr.prices && attr.prices.length !== 0) {

							if (attr && attr.discounts !== null && attr.discounts.length > 0) {
								for (let i = 0; i < attr.discounts.length; i++) {
									if (attr.discounts[i].autoAttachInd === 'Y' && (attr.discounts[i].discountRule === null || attr.discounts[i].discountRule === 'A' || attr.discounts[i].discountRule === 'I' || attr.discounts[i].discountRule === 'O' || (attr.discounts[i].discountRule && attr.discounts[i].discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
										offerVariables.discountedPriceList.push(attr.discounts[i]);
									}
								}
							}
							offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
								this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
						}
					});
				}
			}

		});
		if (!offerVariables.internationalDialing && offerVariables.dhpExisting) {
			offerVariables.dhpIntlExisting = 'NO';
		}
		offerVariables.includedCallingFeatures = this.addincludedCallingFeatures(offerVariables, offer.productOffer.productComponents, 'COMPONENT', false);
		// to get existing discounts for MACD flows
		if (offerVariables.existingServices) {
			let dhpProduct: Products = this.searchforPrimary(offer.productOffer
				.productComponents, GenericValues.cPrimary);
			if (dhpProduct.productAttributes !== null && dhpProduct.productAttributes.length > 0) {
				let attr = this.fetchIsPriceable(dhpProduct.productAttributes);
				let discounts: Discounts[] = [];
				attr.discounts === null ? discounts = [] : discounts = attr.discounts;
				for (let discount of discounts) {
					if (discount.autoAttachInd === 'Y' && (discount.discountRule === null || discount.discountRule === "A" || discount.discountRule === "O" || discount.discountRule === "I" || (discount.discountRule && discount.discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
						offerVariables.discountedPriceList.push(discount);
					}
				}
				offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
					this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
				// find the existing discount availble in the current offer
				for (let existdiscount of offerVariables.existingRetentionDiscounts) {
					let existingDiscountMatchFound = false;
					for (let discount of discounts) {
						if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {

							existingDiscountMatchFound = true;
						}
					}

					if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
						offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
						offerVariables.isShowRemoveRetentionDiscountMsg = true;
					}
					// send only discounts matching in current offer and not the otc discounts.
					if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
						offerVariables.retentionDiscountsToCart.push(existdiscount);

					}
				}
				if (!offerVariables.reEntrant) {
					this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart });
				}
				if (offerVariables.videoSelected === 'NoTV' && !offerVariables.phoneOffer) {
					offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
						this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
				}
			}
		}
		offerVariables.reentrantUI = false;
		this.shoppingCartRequest(offerVariables);
		offerVariables.loading = false;
		offerVariables.retrieveOffersLoading = false;
	}

	public hmpSlot(offerVariables, offer: ProductOfferings) {
		if (!offerVariables.internetCheck) {
			offerVariables.secureWifiError = false;
			offerVariables.easeError = false;
			offerVariables.modemError = false;
			offerVariables.installError = false;
			offerVariables.deviceMandatory = false;
		}
		offerVariables.retrieveOffersLoading = false;
		offerVariables.errorMsg = serverErrorMessages.empty;
		offerVariables.selectedDHPOffer = offer;
		offerVariables.selectedHPOffer = offer;
		offerVariables.dhpOfferPriceDiscountedRc = 0;
		offerVariables.dhpOfferPriceDiscountedOtc = 0;
		offerVariables.selectedInternetOfferPrice = 0;
		offerVariables.selectedHP = offer.productOfferingId;
		offerVariables.selectedPhoneOfferdId = offer.productOfferingId;
		offerVariables.voiceMailPresent = false;
		offerVariables.ismetroTNdisabled = false;
		offerVariables.wireMaintainPresent = false;
		offerVariables.jackValuesForPots = {};
		if (!offerVariables.internetCheck) {
			offerVariables.discountedPriceList = [];
		}
		offer.productOffer.productComponents.forEach(offData => {
			offData.product.productAttributes.forEach(disArray => {
				if (disArray.isPriceable) {
					if (disArray && disArray.discounts !== null && disArray.discounts.length > 0) {
						for (let i = 0; i < disArray.discounts.length; i++) {
							if (disArray.discounts[i].autoAttachInd === 'Y' && (disArray.discounts[i].discountRule === null || disArray.discounts[i].discountRule === 'A' || disArray.discounts[i].discountRule === 'I' || disArray.discounts[i].discountRule === 'O' || (disArray.discounts[i].discountRule && disArray.discounts[i].discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
								offerVariables.discountedPriceList.push(disArray.discounts[i]);
							}
						}
					}
					offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
						this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
				}
			});
		});

		offer.productOffer.productComponents.forEach(offData => {
			if (offData.additionalUiAttrProduct && offData.componentType && offData.componentType.toUpperCase() === 'PRIMARY'
				&& offData.product && offData.product.productName === '1 Pty Residence Ln METRO-CAT') {
				if (offData.additionalUiAttrProduct.iSConfigurableOnAddOn && offData.additionalUiAttrProduct.iSConfigurableOnAddOn.toUpperCase() === 'NO')
					offerVariables.ismetroTNdisabled = true;
				offerVariables.metroText = offData.additionalUiAttrProduct && offData.additionalUiAttrProduct.selectionTextForUi;
			}
		});

		if (offer.defaultOfferPrice !== null && offer.defaultOfferPrice !== undefined) {
			offerVariables.dhpOfferPriceDiscountedRc = offer.defaultOfferPrice.discountedRc;
			offerVariables.dhpOfferPriceDiscountedOtc = offer.defaultOfferPrice.discountedOtc;
			offerVariables.selectedInternetOfferPrice = offer.defaultOfferPrice.rc;
		}
		offerVariables.includedCallingFeatures = this.addincludedCallingFeatures(offerVariables, offer.productOffer.productComponents, 'COMPONENT', true);
		offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.productOffer.productComponents.forEach(products => {
			if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Voice Messaging') !== -1) {
				offerVariables.voiceMailPresent = true;
				offerVariables.selectedVoiceMail = this.getDHPComponents(products, offerVariables);
				offerVariables.voiceMailPrice = this.fetchPrice(offerVariables.selectedVoiceMail);
			}
			if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Wire Maintenance Plan') !== -1) {
				offerVariables.wireMaintainPresent = true;
				offerVariables.selectedMaintainance = this.getDHPComponents(products, offerVariables);
				offerVariables.maintainancePrice = this.fetchPrice(offerVariables.selectedMaintainance);
			}
			if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Jack and Wire') !== -1) {
				let custObj; let custSubObj;
				if (!offerVariables.existingServices) {
					offerVariables.jackValuesForPots = this.filterProductWithPrice(products, offerVariables);
				} else {
					custObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
					custSubObj = this.findCustomerSubOrderObject(custObj, 'Jack and Wire');
					offerVariables.jackValuesForPots = this.filterProductByType(offerVariables, offer, 'Jack and Wire', offerVariables.check, custSubObj);
				}
				offerVariables.jackValuesForPots.product.productAttributes.sort(this.dynamicSort("displayOrder"));
				if (((offerVariables.reentrantUI || offerVariables.fromHold || offerVariables.reEntrant) && !offerVariables.existingServices)
					|| (offerVariables.existingServices && offerVariables.retainedPotsBooleans !== null && offerVariables.retainedPotsBooleans !== undefined)) {
					let attrVal = offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.retainValueForPotsJack;
					offerVariables.retainValueForPotsJack = attrVal;
					let price = attrVal === 'na' ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
						offerVariables.jackValuesForPots, attrVal, '');
					if (!offerVariables.selectedJackForPots) { offerVariables.selectedJackForPots = this.searchForDefault(offerVariables, false, offerVariables.jackValuesForPots, price); }
				} else {
					if (!offerVariables.selectedJackForPots) { offerVariables.selectedJackForPots = this.searchForDefault(offerVariables, true, offerVariables.jackValuesForPots); }
				}
				if (offerVariables.jackValuesForPots.isMandatory && !offerVariables.selectedJackForPots) {
					offerVariables.jackErrorForPots = true;
				} else {
					offerVariables.jackErrorForPots = false;
				}
			}
		});
		/* if (!offerVariables.voiceMailPresent && !offerVariables.existingServices) {
			offerVariables.isVoiceMailYesSelected = false;
			offerVariables.isVoiceMailNoSelected = true;
		} */
		if (!offerVariables.wireMaintainPresent) {
			offerVariables.isWireMaintainanceYesSelected = false;
			offerVariables.isWireMaintainanceNoSelected = true;
		}
		this.retainData(offerVariables);


		// to get existing discounts for MACD flows
		if (offerVariables.existingServices) {
			for (let existdiscount of offerVariables.existingRetentionDiscounts) {
				if (existdiscount.productType !== GenericValues.cHP) { continue; }
				let existingDiscountMatchFound = false;
				if (existdiscount.autoAttachInd === 'N') {
					existingDiscountMatchFound = true;
				}

				if (!existingDiscountMatchFound && existdiscount.discountDuration >= 1) {
					if (offerVariables.hsiRemovedRetentiondiscounts && offerVariables.hsiRemovedRetentiondiscounts.length > 0) {
						offerVariables.hsiRemovedRetentiondiscounts.forEach(addeddisc => {
							if (existdiscount.discountId !== addeddisc.discountId) {
								offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
							}
						});
					} else {
						offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
					}
					offerVariables.isShowRemoveRetentionDiscountMsg = true;
				}
				// send only discounts matching in current offer and not the otc discounts.
				if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
					offerVariables.retentionDiscountsToCart.push(existdiscount);

				}
			}
			if (!offerVariables.reEntrant) { this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart }); }
			offerVariables.loading = false;
			offerVariables.undoSelected = false;
			if (offerVariables.displayOffer && offerVariables.displayOffer.productAttributes && offerVariables.displayOffer.productAttributes !== null && offerVariables.displayOffer.productAttributes.length > 0 && offerVariables.isInternetRemoved) {
				offerVariables.discountedPriceList = [];
				let attr = this.fetchIsPriceable(offerVariables.displayOffer.productAttributes);
				let discounts: Discounts[] = [];
				attr.discounts === null ? discounts = [] : discounts = attr.discounts;
				for (let discount of discounts) {
					if (discount.autoAttachInd === 'Y' && (discount.discountRule === null || discount.discountRule === "A" || discount.discountRule === "O" || discount.discountRule === "I" || (discount.discountRule && discount.discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
						offerVariables.discountedPriceList.push(discount);
					}
				}
				// find the existing discount availble in the current offer
				for (let existdiscount of offerVariables.existingRetentionDiscounts) {
					let existingDiscountMatchFound = false;
					for (let discount of discounts) {
						if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {
							existingDiscountMatchFound = true;
						}
					}
					if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
						if (offerVariables.hsiRemovedRetentiondiscounts && offerVariables.hsiRemovedRetentiondiscounts.length > 0) {
							offerVariables.hsiRemovedRetentiondiscounts.forEach(addeddisc => {
								if (existdiscount.discountId !== addeddisc.discountId) {
									offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
								}
							});
						} else {
							offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
						}
						offerVariables.isShowRemoveRetentionDiscountMsg = true;
					}
					// send only discounts matching in current offer and not the otc discounts.
					if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
						offerVariables.retentionDiscountsToCart.push(existdiscount);
					}
				}
				if (!offerVariables.reEntrant) { this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart }); }
				if (offerVariables.videoSelected === 'NoTV' && !offerVariables.phoneOffer) {
					offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
						this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
				}
			}
		}
		this.shoppingCartRequest(offerVariables);
		if (!offerVariables.reEntrant && offerVariables.existingServices) { this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart }); }
		offerVariables.reentrantUI = false;
		offerVariables.loading = false;
		offerVariables.retrieveOffersLoading = false;
	}

	public searchforPrimaryCart(componentList: OfferProductComponents[], type: string, flagtoCheck?: boolean) {
		let product: Products = {};
		let flag: boolean = false;
		componentList && componentList.forEach((prod) => {
			if (!flag && prod.componentType === type) {
				flag = true;
				prod.product = Object.assign({},
					prod.product, {
					componentType: prod.componentType
				}
				);
				product = prod.product;
				product = {
					productId: product.productId,
					productName: flagtoCheck ? product.productDisplayName : product.productName,
					productType: product.productType,
					componentType: product.componentType,
					productAttributes: product.productAttributes,
					productAssociations: product.productAssociations,
					productCategory: product.productCategory,
					quantity: 1
				};
				return product;
			}
		});
		return product;
	}

	public findPrimaryProductName(internetOffers: ProductOfferings[], productOfferingId, offerVariables) {
		internetOffers && internetOffers.forEach(offers => {
			if (offers.productOfferingId === productOfferingId) {
				offerVariables.expiredProduct = this.searchforPrimaryCart(offers.productOffer.productComponents, GenericValues.cPrimary);
				offerVariables.offerName = offers.productOffer.offerDisplayName;
			}
		});
	}

	public getOfferByCategory(selectedItem, data, internetCheck, phoneSelected) {
		let categorys = [], isPrepaid = false, isPostpaid = false;
		let errorMsg = '';
		if (data && data.length > 0) {
			switch (selectedItem) {
				case 'DHP':
					({ categorys, isPrepaid, isPostpaid } = this.filterBundleCategory(data,
						GenericValues.cDHP, GenericValues.cDHP, internetCheck, phoneSelected));
					errorMsg = 'No Offers with respect to DHP found';
					break;
				case 'HMP':
					({ categorys, isPrepaid, isPostpaid } = this.filterBundleCategory(data,
						GenericValues.cHP, GenericValues.cHP, internetCheck, phoneSelected));
					errorMsg = 'No Offers with respect to Home Phone found';
					break;
				case 'PTV':
					({ categorys, isPrepaid, isPostpaid } = this.filterBundleCategory(data,
						GenericValues.cDATVID, GenericValues.cVideo, internetCheck, phoneSelected));
					errorMsg = 'No Offers with respect to Prism tv found';
					break;
				case 'DTV':
					({ categorys, isPrepaid, isPostpaid } = this.filterBundleCategory(data,
						GenericValues.cDTV, GenericValues.cDTV, internetCheck, phoneSelected));
					errorMsg = 'No Offers with respect to DTV tv found';
					break;
			}
		}
		return { categorys, errorMsg, isPrepaid, isPostpaid };

	}

	/**
	 * To get Category by Type from List
	 * Eg. DATA or VIDEO
	 * @param categoryList
	 * @param categoryId
	 */
	public filterBundleCategory(categoryList: ServiceCategoryBasedOffers[],
		categoryId: string,
		filterBy: string, internetCheck?, phoneSelected?): any {
		let categorys = [], isPrepaid = false, isPostpaid = false;
		if (categoryList !== undefined) {
			categoryList = this.sortSpeeds(categoryList);
			categoryList.forEach((item) => {
				if (item.serviceCategory === categoryId) {
					item && item.catalogs && item.catalogs.forEach((catalog) => {
						catalog && catalog.catalogItems && catalog.catalogItems.forEach(items => {
							if (phoneSelected === 'DHP') {
								items.productOffer.offerBillingType === 'PREPAID' ? isPrepaid = true : isPostpaid = true;
							}
							if (items.productOffer.offerCategory === filterBy) {
								if (filterBy === GenericValues.cHP && items && items.productOffer && items.productOffer.offerAttributes !== null &&
									items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
									items.productOffer.offerAttributes.forEach(attr => {
										if (categoryId === GenericValues.cDTV) {
											categorys.push(items);
										}
										else if ((internetCheck && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'yes') || (!internetCheck && attr.attributeName === 'with-INTERNET' && attr.attributeValue.toLowerCase() === 'no')) {
											items.productOffer.offerAttributes.forEach(checkAttr => {
												if (phoneSelected === 'HMP' && checkAttr && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'yes') {
													categorys.push(items);
												}
											});
										}
									});
								} else {
									categorys.push(items);
								}
							}
						});
					});
				}
			});
		}
		return { categorys, isPrepaid, isPostpaid };
	}

	public sortSpeeds(offerResponse: ServiceCategoryBasedOffers[]) {
		let newOfferResponse = offerResponse;


		if (typeof newOfferResponse !== 'undefined' && newOfferResponse.length > 0) {
			for (var i = 0; i < newOfferResponse.length; i++) {
				if (typeof newOfferResponse[i].catalogs !== 'undefined' && newOfferResponse[i].catalogs.length > 0) {
					if (typeof newOfferResponse[i].catalogs !== 'undefined' && newOfferResponse[i].catalogs.length > 0) {
						let catalogItems = newOfferResponse[i].catalogs[0].catalogItems;
						catalogItems.sort(this.dynamicSort("displayOrder"));
					}
				}
			}
		}
		return newOfferResponse;
	}

	public getRemoveResponseData() {

		let request: any = {
			"rsnType": "DISCONNECT"
		};
		return this.productService.getResponseForRemove(request);

	}

	public getRemoveResponse(offerVariables) {
		this.logger.log("info", "offer.component.ts", "selectProductRemoveRequest", JSON.stringify(""));
		this.logger.startTime();
		offerVariables.loading = true;
		this.getRemoveResponseData()
			.catch((error: any) => {
				offerVariables.loading = false;
				this.logger.endTime();
				this.logger.log("info", "offer.component.ts", "selectProductRemoveResponse", JSON.stringify(error));
				this.logger.log("info", "offer.component.ts", "selectProductRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				this.systemErrorService.logAndRouteUnexpectedError(
					"error", "Not Applicable",
					"Submit Task", "offer.ts",
					"Remove Response - Offer Page",
					error);
				return Observable.throwError(null);
			})
			.subscribe(
				(respData) => {
					offerVariables.loading = false;
					this.logger.endTime();
					this.logger.log("info", "offer.component.ts", "selectProductRemoveResponse", JSON.stringify(respData));
					this.logger.log("info", "offer.component.ts", "selectProductRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.removeResponse = respData.bmReasonCodes;

					if (offerVariables.removedProductItem && offerVariables.removedProductItem.length > 0) {
						offerVariables.removeSelectedReason = offerVariables.removeResponse[0];
					}
				},
				(error) => {
					offerVariables.loading = false;
					this.logger.endTime();
					this.logger.log("error", "offer.component.ts", "selectProductRemoveResponse", JSON.stringify(error));
					this.logger.log("error", "offer.component.ts", "selectProductRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					if (error === undefined || error === null) { return; }
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						let apiResponseError = JSON.parse(error);
						if (apiResponseError !== undefined && apiResponseError !== null && apiResponseError.errorResponse &&
							apiResponseError.errorResponse.length > 0) {
							this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.ts", "Offers Page", apiResponseError);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
						this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.ts", "Offers Page", lAPIErrorLists);
					}
				});
		if (offerVariables.removedProductItem && offerVariables.removedProductItem.length > 0) {
			offerVariables.removeSelectedReason = offerVariables.removeResponse[0];
		}
	}
	public catalogItemToCustSubItem(item) {
		let customerOrderSubItem: any = {};
		item.productOffer && item.productOffer.productComponents.forEach((productComponentObj) => {
			productComponentObj.product.action = null;
			productComponentObj.product.componentType = productComponentObj.componentType;
			delete productComponentObj.product.isRegulated;
			delete productComponentObj.product.productCategoryDisplayName;
			delete productComponentObj.product.productDisplayName;
			customerOrderSubItem = productComponentObj.product;
		});
		return customerOrderSubItem;
	}

	public sortModemComposite(a, b) {
		if (a.attributeName === "Account Type") {
			return -1;
		} else {
			return 1;
		}
	}

	public getProductNameFromSelect(selectedService) {
		let offerLink = null;
		switch (selectedService) {
			case 'DHP': offerLink = GenericValues.cDHP; break;
			case 'HMP': offerLink = GenericValues.cHP; break;
			case 'DTV': offerLink = GenericValues.cDTV; break;
			case 'PTV': offerLink = GenericValues.cVideo; break;
		}
		return offerLink;
	}

	/**
	 * To get Category by Type from List
	 * Eg. DATA or VIDEO
	 * @param categoryList
	 * @param categoryId
	 */
	public filterCategory(categoryList: ServiceCategoryBasedOffers[], categoryId: string):
		ServiceCategoryBasedOffers {
		return categoryList.find((item) => item.serviceCategory === categoryId);
	}

	public getOfferLink(selectedService, serviceList) {
		let offerResponse = this.sortSpeeds(serviceList);
		let offerLink = null;
		switch (selectedService) {
			case 'DHP': offerLink = this.filterCategory(offerResponse, GenericValues.cDHP); break;
			case 'HMP': offerLink = this.filterCategory(offerResponse, GenericValues.cHP); break;
			case 'DTV': offerLink = this.filterCategory(offerResponse, GenericValues.cDTV); break;
			case 'PTV': offerLink = this.filterCategory(offerResponse, GenericValues.cDATVID); break;
		}
		return offerLink;

	}

	public unFilter(offerVariables: OfferVariables) {
		offerVariables.unFilterBool = !offerVariables.unFilterBool;
		this.retrieveOffers(offerVariables, false, undefined, undefined, (data) => {
			if (offerVariables.unFilterBool) {
				offerVariables.internerOffer = offerVariables.qualifiedUnfilter;
			} else {
				if (offerVariables.byPassBool) {
					offerVariables.byPassBool = !offerVariables.byPassBool;
					offerVariables.selectedTech = "na";
				}
				offerVariables.internerOffer = offerVariables.qualifiedFilter;
			}
			this.createSlot(offerVariables);
		})
	}


	public maxValue(wSTB: Products, filterByValue: string, flag: boolean,
		value?: string, tSTB?): string[] {
		let arr: string[] = [];
		if (wSTB.productAttributes[0].prices !== null) {
			wSTB.productAttributes.forEach((val) => {
				if (val.isPriceable) {
					val.compositeAttribute.forEach(attrVal => {
						if (attrVal.attributeName === filterByValue && !flag) {
							if (arr.indexOf(attrVal.attributeValue) === -1) {
								arr.push(attrVal.attributeValue);
							}
						} else if (attrVal.attributeName === tSTB && attrVal.attributeValue === value && flag) {
							let numVal: string = this.getValueofWSTB(val, filterByValue);
							if (arr.indexOf(numVal) === -1) {
								arr.push(numVal);
							}
						}
					});
				}
			});
		}
		return arr;
	}

	public getValueofSTB(prod: Products, type: string): string {
		let value: string;
		prod.productAttributes.forEach(attrVal => {
			if (attrVal.isPriceable) {
				attrVal.compositeAttribute.forEach((val) => {
					if (val.attributeName === type) {
						value = val.attributeValue;
					}
				});
			}
		});
		return value;
	}

	public getValueofWSTB(prod: AttributesCombination, type: string): string {
		let value: string;
		prod.compositeAttribute.forEach(attrVal => {
			if (attrVal.attributeName === type) {
				value = attrVal.attributeValue;
			}
		});
		return value;
	}

	public getPriceDetailsByAttrVal(offerProduct: OfferProductComponents, attrVal: string, type: string, isConverted?) {
		let price: AttributesCombination;
		if (offerProduct && offerProduct.product && offerProduct.product.productAttributes && offerProduct.product.productAttributes.length > 0) {
			offerProduct.product.productAttributes.forEach((item) => {
				if (type !== GenericValues.modem && item.compositeAttribute && (item.compositeAttribute.length > 0) && item.compositeAttribute[0].attributeValue === attrVal) {
					price = item;
				} else {
					item.compositeAttribute && item.compositeAttribute.forEach(attr => {
						if ((!isConverted && attr.attributeValue === attrVal && attr.attributeDisplayName !== 'Convert to Purchased Modem') ||
							(isConverted && attr.attributeDisplayName === 'Convert to Purchased Modem')) {
							// if (attr.attributeValue === attrVal) {
							price = item;
						}
					});
				}
			});
		}
		return price;
	}

	public populateValues(prices: Prices): number {
		let price: number = 0;
		if (prices.discountedRc === 0) {
			if (prices.rc === 0) {
				if (prices.discountedOtc === 0) {
					if (prices.otc !== 0) { price = prices.otc; }
				} else {
					if (prices.discountedOtc !== 0) { price = prices.discountedOtc; }

				}
			} else {
				if (prices.rc !== 0) { price = prices.rc; }
			}
		} else {
			if (prices.discountedRc !== 0) { price = prices.discountedRc; }
		}
 

		return price;
	}

	public getBundledOfferId(group: OfferGroup, filterBy: string, flag?): string {
		let id: string;
		if (group !== undefined && group.offerItems !== undefined) {
			group.offerItems.forEach((offerItem) => {
				if (!flag && offerItem && offerItem.offerCategory === filterBy) {
					id = offerItem.productOfferingId;
				} else if (flag && offerItem && (offerItem.offerCategory === filterBy ||
					offerItem.offerCategory === GenericValues.sData)) {
					id = offerItem.productOfferingId;
				}
			});
		}
		return id;
	}

	public getBundleOfferPrice(group: OfferGroup, filterBy: string, flag?) {
		let listRCPrice: number;
		if (group !== undefined && group.offerItems !== undefined) {
			group.offerItems.forEach((offerItem) => {
				if ((!flag && offerItem && offerItem.offerCategory === filterBy) || (flag && offerItem && (offerItem.offerCategory === filterBy
					|| offerItem.offerCategory === GenericValues.sData))) {
					group.prices.forEach((priceValue) => {
						listRCPrice = priceValue.rc;
					});
				}
			});
		}
		return listRCPrice;
	}

	public getBundledOfferIdandPrice(selectedItem, group) {
		let dataVal = {
			id: null,
			price: null
		};
		switch (selectedItem) {
			case 'DHP':
				dataVal.id = this.getBundledOfferId(group, GenericValues.cDHP);
				dataVal.price = this.getBundleOfferPrice(group, GenericValues.cDHP);
				break;
			case 'HMP':
				dataVal.id = this.getBundledOfferId(group, GenericValues.cHP);
				dataVal.price = this.getBundleOfferPrice(group, GenericValues.cHP);
				break;
			case 'DTV':
				dataVal.id = this.getBundledOfferId(group, GenericValues.cDTV);
				dataVal.price = this.getBundleOfferPrice(group, GenericValues.cDTV);
				break;
			case 'PTV':
				dataVal.id = this.getBundledOfferId(group, GenericValues.cVideo);
				dataVal.price = this.getBundleOfferPrice(group, GenericValues.cVideo);
				break;
		}
		return dataVal;
	}

	public getDHPComponents(products: OfferProductComponents, offerVariables?: OfferVariables) {
		let product: Products = {};
		products.product = Object.assign({},
			products.product, {
			componentType: products.componentType
		}
		);
		product = products.product;
		product = {
			productId: product.productId,
			productName: product.productName,
			productType: product.productType,
			componentType: product.componentType,
			productAttributes: product.productAttributes,
			productAssociations: product.productAssociations,
			productCategory: product.productCategory,
			quantity: 1
		};
		if (offerVariables && offerVariables.flow) {
			let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
			switch (flow) {
				case 'CHANGE':
				case 'BILLING':
					product['action'] = (offerVariables.phoneSelected === 'HMP' && !offerVariables.hpExisting) || (!offerVariables.dhpExisting && offerVariables.phoneSelected === 'DHP') ? 'ADD' : this.checkPOTSAction(product.productName, offerVariables);
					break;
				case 'MOVE':
					product['action'] = (offerVariables.phoneSelected === 'DHP' && offerVariables.dhpExisting) || (offerVariables.phoneSelected === 'HMP' && offerVariables.hpExisting) ? 'NOCHANGE' : 'ADD';
					break;
				case 'STACKAMEND':
					product['action'] = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend && offerVariables.existingData.pendingOrders.length === 1 ? 'ADD' : (offerVariables.phoneSelected === 'HMP' && !offerVariables.hpExisting) || (!offerVariables.dhpExisting && offerVariables.phoneSelected === 'DHP') ? 'ADD' : this.checkPOTSAction(product.productName, offerVariables);
					break;
			}
		}
		return product;
	}

	/**
	 * Populate default component value in dropdowns
	 * @param defaultVal
	 * @param addons
	 */
	public searchForDefault(offerVariables, defaultVal: boolean, cloneAddons: OfferProductComponents,
		priceSelected?: AttributesCombination, type?): Products {
		let flow = offerVariables.flow.toUpperCase();
		let addons = cloneDeep(cloneAddons);
		let component: Products;
		let flag: boolean = false;
		let prodAttr: AttributesCombination;
		let prodAttrs: AttributesCombination[] = [];
		let prodAttrTemp: AttributesCombination;
		if (addons !== undefined && addons.product !== undefined) {
			component = addons.product;
			prodAttrs = [];
			if (defaultVal) {
				if (addons.product.productAttributes !== null && addons.product.productAttributes.length > 0) {
					if (flow === 'NEWINSTALL') {
						addons.product.productAttributes.forEach((item) => {
							if (!flag && (item.isDefault === 1 || (type === 'modem' && item && item.compositeAttribute && item.compositeAttribute[0]
								&& item.compositeAttribute[0].attributeName === 'Account Type' && item.compositeAttribute[0].attributeValue === 'Lease'))) {
								flag = true;
								prodAttr = item;
							}
						});
						// prodAttrs.push(prodAttr);
					} else {
						addons.product.productAttributes.forEach((item) => {
							if (!flag && item.isDefault) {
								flag = true;
								prodAttr = item;
							}
							if (addons.isMandatory && item.isPriceable) {
								prodAttrTemp = item;
							}
						});
						if (!flag) {
							prodAttr = prodAttrTemp;
						}
					}
					!flag ? prodAttrs = [] : prodAttrs.push(prodAttr);
				}
				component = Object.assign({},
					component, {
					productAttributes: prodAttrs,
					componentType: addons.componentType
				}
				);
				component = {
					productId: component.productId,
					productName: component.productName,
					productType: component.productType,
					componentType: component.componentType,
					productAttributes: component.productAttributes,
					productAssociations: component.productAssociations,
					productCategory: component.productCategory,
					quantity: 1
				};
				if (prodAttr === undefined) {
					component = undefined;
				}
			} else {
				if (priceSelected !== undefined) {
					prodAttrs.push(priceSelected);
					component = Object.assign({},
						component, {
						productAttributes: prodAttrs,
						componentType: addons.componentType
					}
					);
					component = {
						productId: component.productId,
						productName: component.productName,
						productType: component.productType,
						componentType: component.componentType,
						productAttributes: component.productAttributes,
						productAssociations: component.productAssociations,
						productCategory: component.productCategory,
						quantity: 1
					};
				} else {
					component = undefined;
				}
			}
		}
		return component;
	}

	public fetchIsPriceable(productAttributes: AttributesCombination[]) {
		let prodAttr: AttributesCombination;
		productAttributes.forEach(attr => {
			if (attr.isPriceable) {
				prodAttr = attr;
			}
		});
		return prodAttr;
	}

	public fetchPriceTypeFromPrimary(productAttributes: AttributesCombination[]): Prices {
		let prices: Prices;
		productAttributes.forEach(attr => {
			if (attr.isPriceable) {
				attr.prices.forEach(price => {
					if (price.priceType === GenericValues.pPriceType) {
						prices = price;
					}
				});
			}
		});
		return prices;
	}

	public getPrice(price: Prices): string {
		let cost: string = '';
		if (price.discountedOtc !== 0) {
			cost = '$' + price.discountedOtc.toFixed(2);
		} else if (price.otc !== 0) {
			cost = '$' + price.otc.toFixed(2);
		} else if (price.discountedRc !== 0) {
			cost = '$' + price.discountedRc.toFixed(2) + '/mo';
		} else if (price.rc !== 0) {
			cost = '$' + price.rc.toFixed(2) + '/mo';
		}
		return cost;
	}

	/**
	 * Calculate the maximum Discount amount of the offers
	 */
	public maxDiscountAmount(data: Discounts[]) {
		let totDiscAmt: number = 0;
		data
			.forEach((item) => {
				totDiscAmt = totDiscAmt + item.discountRate;
			});
		return totDiscAmt;
	}

	public filterSpeed(name: string, isExist: boolean, offerVariables) {
		offerVariables.filterObj = {
			name: name,
			isExist: isExist
		};
		offerVariables.dropName = name;
		if (name === 'Self Install Only') {
			let flg = false;
			for (let i = 0; i < offerVariables.selfInstallOffers.length; i++) {
				if (offerVariables.selfInstallOffers[i] === offerVariables.selectedSpeed) { flg = true; }
			}
			if (!flg) { this.availSpeedChecked(offerVariables.selfInstallOffers[0], offerVariables); }
		}
		else if (name === 'Existing modem') {
			let flg = false;
			for (let i = 0; i < offerVariables.existingModemOffers.length; i++) {
				if (offerVariables.existingModemOffers[i] === offerVariables.selectedSpeed) { flg = true; }
			}
			if (!flg) { this.availSpeedChecked(offerVariables.existingModemOffers[0], offerVariables); }
		}
	}

	public checkSaleExpiry(data) {
		let flag = false;
		if (data.productOffer && data.productOffer.validFor && data.productOffer.validFor && data.productOffer.validFor.saleExpired && data.productOffer.validFor.bundleSaleExpired) {
			if (data.productOffer.validFor.saleExpired === "N" && data.productOffer.validFor.bundleSaleExpired === "N") {
				flag = true;
			}
		}
		return flag;
	}

	public framingSlot(offerResponse: ServiceCategoryBasedOffers[], offerVariables) {
		let notexpiredFlag: boolean = false;
		offerResponse = this.sortSpeeds(offerResponse);
		if (offerVariables.internetCheck) {
			const hsi: ServiceCategoryBasedOffers = this.filterCategory(offerResponse, GenericValues.sData);
			if (hsi && hsi.catalogs !== null && hsi.catalogs[0] !== undefined && hsi.catalogs.length > 0
				&& hsi.catalogs[0].catalogItems !== null && hsi.catalogs[0].catalogItems.length > 0) {
				offerVariables.dataLink = hsi;
				if (offerVariables.byPassBool) {
					offerVariables.internerOffer = offerVariables.unQualifiedOffers;
				}
				else if (offerVariables.unFilterBool) {
					offerVariables.internerOffer = offerVariables.qualifiedUnfilter;
				}
				else {
					offerVariables.internerOffer = hsi.catalogs[0].catalogItems;
				}
				if (offerVariables.internerOffer && offerVariables.internerOffer.length > 1) {

					offerVariables.internerOffer.forEach(data => {
						notexpiredFlag = this.checkSaleExpiry(data);
					});
					if (notexpiredFlag === false) {
						this.catalogEmptyError(offerVariables, notexpiredFlag);
						offerVariables.loading = false;
					}
				}
				const primaryProdduct = this.searchforPrimary(offerVariables.internerOffer[0].productOffer.productComponents, GenericValues.cPrimary);
				this.store.dispatch({ type: 'CART_MAX_SPEED', payload: primaryProdduct });
				offerVariables.hsiCatalogId = hsi.catalogs[0].catalogId;
				offerVariables.catalogSpecId = offerVariables.offerResponse.payload.cart.catalogSpecId;
				if (offerVariables.phoneSelected === GenericValues.noPhone && offerVariables.videoSelected === 'NoTV') { this.createSlot(offerVariables); }
			} else {
				offerVariables.internetCheck = false;
				offerVariables.newInternetCheck = false;
				if (offerVariables.phoneArray && offerVariables.phoneArray.length > 0) {
					offerVariables.phoneArray.forEach((offer) => {
						if (offer.name === GenericValues.cHP) {
							offerVariables.phoneSelected = 'HMP';
							offerVariables.newPhoneSelected = 'HMP';
							offerVariables.phoneOffer = true;
							this.retrieveOffers(offerVariables, false, true);
						}
					});
				}
				offerVariables.internetAvail = false;
				offerVariables.retrieveOffersLoading = false;
				offerVariables.loading = false;
				offerVariables.serviceUnavailable = 'Catalog Empty';
				if (!offerVariables.phoneOffer) {
					this.catalogEmptyError(offerVariables, notexpiredFlag);
				}
				if (offerVariables.phoneOfferData && offerVariables.phoneOfferData.length > 0 && offerVariables.videoSelected === 'NoTV') { this.createSlot(offerVariables); }
			}
		}
		if (offerVariables.phoneOffer) {
			let notexpiredFlag: boolean = false;
			if (offerVariables.phoneSelected === 'HMP') {
				offerVariables.phoneLink = offerResponse;
			} else {
				offerVariables.dhpLink = offerResponse;
			}
			const phoneData = this.getOfferByCategory(offerVariables.phoneSelected, offerResponse, offerVariables.internetCheck, offerVariables.phoneSelected);
			offerVariables.phoneOfferData = phoneData.categorys;
			if (phoneData.categorys && phoneData.categorys.length === 0) {
				this.catalogEmptyError(offerVariables, notexpiredFlag);
				offerVariables.loading = false;
			}
			if (phoneData.categorys && phoneData.categorys.length > 1) {

				phoneData.categorys.forEach(data => {
					notexpiredFlag = this.checkSaleExpiry(data);
				});
				if (notexpiredFlag === false) {
					this.catalogEmptyError(offerVariables, notexpiredFlag);
					offerVariables.loading = false;
				}
			}

			if (offerVariables.phoneSelected === 'DHP') {
				offerVariables.isPrepaid = phoneData.isPrepaid;
				offerVariables.isPostpaid = phoneData.isPostpaid;
			}
			const pots: ServiceCategoryBasedOffers = this.filterCategory(offerResponse, GenericValues.cHP);
			offerVariables.phoneCatalogId = pots && pots.catalogs && pots.catalogs[0] && pots.catalogs[0].catalogId;
			if (offerVariables.videoSelected === 'NoTV') { this.createSlot(offerVariables); }
		}
		if (offerVariables.videoOffer) {
			let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
			switch (flow) {
				case 'NEWINSTALL':
					offerVariables.videorOffer = this.getOfferByCategory(offerVariables.videoSelected, offerResponse, offerVariables.internetCheck, offerVariables.phoneSelected).categorys;
					offerVariables.dtvCatalogId = offerVariables.hsiCatalogId ? offerVariables.hsiCatalogId : offerVariables.phoneCatalogId;
					break;
				default:
					let vid: ServiceCategoryBasedOffers = this.filterCategory(offerResponse, GenericValues.cDTV);
					offerVariables.videorOffer = vid.catalogs[0].catalogItems;
					offerVariables.dtvCatalogId = vid.catalogs[0].catalogId;
					break;
			}
			this.createSlot(offerVariables);
		}
	}

	public checkAndSetExpiredOfferMessage(offer, offerVariables) {
		if (offer && offer.productOffer && offer.productOffer.validFor) {
			if (offer.productOffer.validFor.saleExpired && (offer.productOffer.validFor.saleExpired.toUpperCase() === 'Y')) {
				offerVariables.isSpeedSalesExpired = true;
			} else if (offer.productOffer.validFor.saleExpired && (offer.productOffer.validFor.saleExpired.toUpperCase() === 'N')) {
				offerVariables.isSpeedSalesExpired = false;
			}
			if (offer.productOffer.validFor.bundleSaleExpired && (offer.productOffer.validFor.bundleSaleExpired.toUpperCase() === 'Y')) {
				offerVariables.isBundleSalesExpired = true;
			} else if (offer.productOffer.validFor.bundleSaleExpired && (offer.productOffer.validFor.bundleSaleExpired.toUpperCase() === 'N')) {
				offerVariables.isBundleSalesExpired = false;
			}
		}
	}

	public internetSlot(offer: ProductOfferings, offerVariables) {
		offerVariables.changeAfterReEntrant = false;
		offer && offer.productOffer && offer.productOffer.offerBillingType ? offerVariables.offerBillingType = offer.productOffer.offerBillingType : offerVariables.offerBillingType = 'POSTPAID';
		if (offerVariables.isReEntrant) {
			offerVariables.offerName = offerVariables.offerBillingType === 'PREPAID' ? offer.productOffer.offerDisplayName + ' (' + offer.productOffer.offerBillingType + ')' : offer.productOffer.offerDisplayName;
		}
		offerVariables.offerBillingType === 'PREPAID' ? offerVariables.serviceUnavailable = 'Not Available with Prepaid Offer' : offerVariables.serviceUnavailable = 'Service not available for your Address';
		if (offerVariables.existingBillingType && offerVariables.existingBillingType !== offerVariables.offerBillingType) {
			offerVariables.billingTypeChanged = true;
			offerVariables.changeAfterReEntrant = true;
			if (offerVariables.offerBillingType.toUpperCase() === 'PREPAID') {
				this.store.dispatch({ type: 'WAIVED_OTC_INFO', payload: '' });
			}
		}
		this.store.dispatch({ type: 'PREPAID_FLAG', payload: offerVariables.offerBillingType === 'PREPAID' ? offerVariables.offerBillingType : 'POSTPAID' });
		offerVariables.selfInstall = false;
		offerVariables.deviceMandatory = false;
		offerVariables.selectedOffer = offer;
		offerVariables.speedselected = offerVariables.selectedOffer.productOffer.offerName;
		offerVariables.retentionDiscountsToCart = [];
		offerVariables.hsiRemovedRetentiondiscounts = [];
		offerVariables.selectedInternetOfferdId = offer.productOfferingId;
		let existingObservable: Observable<any> = <Observable<any>>this.store.select('existingProducts');
		let existingSubscription: Subscription;
		let existingProductStoreSubscription: Subscription;
		let existingProductStore$: Observable<any>;
		let internetProduct: Products = this.searchforPrimary(offer.productOffer
			.productComponents, GenericValues.cPrimary);
		this.checkAndSetExpiredOfferMessage(offer, offerVariables);
		offerVariables.selectedSpeed = internetProduct.productName;
		if (offer.defaultOfferPrice !== null && offer.defaultOfferPrice !== undefined) {
			offerVariables.actualPrice = offer.defaultOfferPrice.rc;
			offerVariables.discountedPrice = offer.defaultOfferPrice.discountedRc === offer.defaultOfferPrice.rc ? 0 : offer.defaultOfferPrice.discountedRc;
			offerVariables.actualInternetOtcPrice = offer.defaultOfferPrice.otc;
			offerVariables.discountedInternetOtcPrice = offer.defaultOfferPrice.discountedOtc;
			offerVariables.errorMsg = serverErrorMessages.empty;
		} else {
			offerVariables.errorMsg = serverErrorMessages.priceObjectNull;
		}

		let installation = this.filterProductByType(offerVariables, offer, GenericValues.install);
		if (installation) {
			offerVariables.installationValues = this.filterProductWithPrice(installation, offerVariables);
			offerVariables.recomTechInstall = this.filterProductWithPrice(installation, offerVariables, true);
		}
		offerVariables.installationValues = this.filterProductByType(offerVariables, offer, 'TECH INSTALL');
		offerVariables.recomTechInstall = this.filterProductByType(offerVariables, offer, 'TECH INSTALL', false, undefined, true);
		if (offerVariables.installationValues && offerVariables.installationValues !== undefined && offerVariables.installationValues.product) {
			offerVariables.installationValues.product.productAttributes.sort(this.dynamicSort("displayOrder"));
		}
		let modem = this.filterProductByType(offerVariables, offer, GenericValues.modem, undefined, undefined, true);
		if (offerVariables.flow === 'stackAmend') {
			offerVariables.modemValues = cloneDeep(this.filterProductByType(offerVariables, offer, 'MODEM'));
			if (offerVariables.currentSpeed !== offerVariables.selectedSpeed) {
				offerVariables.isExistingSpeedChanged = true;
			}
			if (offerVariables.isStack && (offerVariables.isHSIExistingProduct || offerVariables.isExistingSpeedChanged)) {
				if (offerVariables.isExistingModemChanged || offerVariables.isExistingSpeedChanged) {
					offerVariables.modemMake = offerVariables.modemModel = '';
					this.retrieveModemModel(offerVariables, offerVariables.modemValues, true);
				} else {
					if (offerVariables.modemMakeModelCheck) {
						existingSubscription = existingObservable && existingObservable.subscribe((data) => {
							if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems && data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems && !offerVariables.NIPendingStackAmend) {
								this.retrieveModemModel(offerVariables, data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems, false);
							}
						});
					} else {
						offerVariables.modemMake = offerVariables.modemModel = '';
						this.retrieveModemModel(offerVariables, offerVariables.modemValues, true);
					}
				}
			} else if (offerVariables.isAmend && offerVariables.isHSIExistingProduct) {
				if (offerVariables.isExistingSpeedChanged) {
					existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
					existingProductStoreSubscription = existingProductStore$.subscribe((respData) => {
						// offerVariables.existingServices = respData && respData.orderInit && respData.orderInit.payload && respData.orderInit.payload.existingServices && respData.orderInit.payload.existingServices.existingServiceItems;
					});
					this.retrieveModemModel(offerVariables, offerVariables.modemValues, offerVariables.isExistingSpeedChanged);
				} else {
					if ((offerVariables.modemMake !== '' && offerVariables.modemMake !== 'null' && offerVariables.modemMake !== 'UNKNOWN') && (offerVariables.modemModel !== '' && offerVariables.modemModel !== 'null' && offerVariables.modemModel !== 'UNKNOWN')) {
						existingSubscription = existingObservable && existingObservable.subscribe((data) => {
							if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems && data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems && !offerVariables.NIPendingStackAmend) {
								this.retrieveModemModel(offerVariables, data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems, false);
							}
							// offerVariables.existingServices = data && data.existingProductsAndServices && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems;
						});
					} else {
						existingSubscription = existingObservable && existingObservable.subscribe((data) => {
							if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems && data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems && !offerVariables.NIPendingStackAmend) {
								this.retrieveModemModel(offerVariables, data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems, true);
							}
							// offerVariables.existingServices = data && data.existingProductsAndServices && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems;
						});
					}
				}
			} else if (offerVariables.isHSIExistingProduct) {
				existingSubscription = existingObservable && existingObservable.subscribe((data) => {
					if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && !offerVariables.NIPendingStackAmend) {
						this.retrieveModemModel(data.existingProductsAndServices[0].existingServices.existingServiceItems[0].existingServiceSubItems, false);
					}
				});
			}
		}
		if (modem) {

			offerVariables.modemValues = this.filterProductWithPrice(modem, offerVariables);
			if (offerVariables.existingServices) {
				offerVariables.modemValues = cloneDeep(this.filterProductByType(offerVariables, offer, 'MODEM'));
				offerVariables.modemCompatValues = this.filterProductByType(offerVariables, offer, 'MODEM', false, undefined, true);
				offerVariables.modemValues.product.productAttributes.forEach((attr) => {
					attr = this.updateModemAttrValue(attr, GenericValues.leaseWithCsAttrVAlue);
				});
			}

		}
		let cs = this.filterProductByType(offerVariables, offer, GenericValues.secureWifiComponent);
		if (cs) {
			if (!offerVariables.existingServices) {
				offerVariables.secureWifiValues = this.filterProductWithPrice(cs, offerVariables, true, GenericValues.serviceLevel, 'No');
			} else {
				offerVariables.secureWifiValues = cs;
			}
			offerVariables.secureWifiValues.product.productAttributes.sort(this.dynamicSort("displayOrder"));
			offerVariables.isSecureWifi = true;
		} else {
			let defaultOfferProd: OfferProductComponents;
			offerVariables.secureWifiValues = defaultOfferProd;
			offerVariables.isSecureWifi = false;
		}
		let ease = this.filterProductByType(offerVariables, offer, GenericValues.ease);
		if (ease) {
			if (!offerVariables.existingServices) {
				offerVariables.easeValues = this.filterProductWithPrice(ease, offerVariables);
			} else {
				offerVariables.easeValues = ease;
			}
			offerVariables.easeValues.product.productAttributes.sort(this.dynamicSort("displayOrder"));
			if (offerVariables.easeValues && offerVariables.easeValues.product.productAttributes.length === 1) {
				offerVariables.disableEase = true;
			}

		} else {
			let defaultOfferProd: OfferProductComponents;
			offerVariables.easeValues = defaultOfferProd;
		}
		let jack = this.filterProductByType(offerVariables, offer, GenericValues.jack);
		if (jack) {
			if (!offerVariables.existingServices) {
				offerVariables.jackValues = this.filterProductWithPrice(jack, offerVariables);
			} else {
				offerVariables.jackValues = jack;
			}
			offerVariables.jackValues.product.productAttributes.sort(this.dynamicSort("displayOrder"));
		}

		offerVariables.recomTechInstall && offerVariables.recomTechInstall.product && offerVariables.recomTechInstall.product.productAttributes &&
			offerVariables.recomTechInstall.product.productAttributes.forEach(attr => {
				attr && attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
					if (comp.attributeName === 'TechInstallRecommended') {
						offerVariables.recommendedTech = attr;
					}
				});
			});
		if (offerVariables.flow === 'CHANGE' && !((!offerVariables.selfInstall && offerVariables.installationValues &&
			offerVariables.installationValues.product && offerVariables.installationValues.product.productName === 'TECH INSTALL' &&
			(offerVariables.recommendedTech && offerVariables.recommendedTech.compositeAttribute && offerVariables.recommendedTech.compositeAttribute[0] && offerVariables.recommendedTech.compositeAttribute[0].attributeValue !== 'Y')) ||
			(offerVariables.recommendedTech && offerVariables.recommendedTech.compositeAttribute && offerVariables.recommendedTech.compositeAttribute[0] && offerVariables.recommendedTech.compositeAttribute[0].attributeValue === 'Y'))) {
			offerVariables.selectedInstallation = undefined;
		}
		let custObj;
		if (offerVariables.existingServices) {

			if (offerVariables.isReEntrant || offerVariables.fromHold) {
				custObj = this.findCustomerOrderObject(offerVariables.cartCopyObject && offerVariables.cartCopyObject.payload && offerVariables.cartCopyObject.payload.cart &&
					offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
			} else {
				custObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
			}
			let exCustObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
			if (exCustObj !== undefined) {
				let existingSpeed: string = this.primaryFromRetain(exCustObj.customerOrderSubItems, GenericValues.cPrimary).productName;
				offerVariables.selectedSpeed === existingSpeed ? offerVariables.check = false : offerVariables.check = true;
				if (offerVariables.isRecommendationSuccess && !offerVariables.reEntrant && !offerVariables.oneTimeLoading) {
					offerVariables.check = false;
				}
			}
		}
		let previousModemSelection = cloneDeep(offerVariables.isModemCompatible);
		let isCompatible = this.getModemCompatibilty(offerVariables);
		let custSubObj: CustomerOrderSubItem = this.findCustomerSubOrderObject(custObj, 'TECH INSTALL');
		offerVariables.installationValues && offerVariables.installationValues.product.productAttributes.sort(this.dynamicSort("displayOrder"));
		offerVariables.modemValues.product.productAttributes.sort(this.dynamicSort("displayOrder"));
		if (!offerVariables.oneTimeLoading || offerVariables.undoSelected) {
			if (!offerVariables.existingServices) {
				// tech Install
				offerVariables.selectedInstallation = this.searchForDefault(offerVariables, true, offerVariables.installationValues);
				// modem
				offerVariables.selectedModem = this.searchForDefault(offerVariables, true, offerVariables.modemValues);
				// j&w
				offerVariables.selectedJack = this.searchForDefault(offerVariables, true, offerVariables.jackValues);
			}
			else {
				if (custSubObj !== undefined && !offerVariables.check) {
					offerVariables.newTechInstall = false;
					offerVariables.techInstallExist = true;
					// if (offerVariables.holdCalled || offerVariables.isAmend) offerVariables.selectedInstallation = custSubObj;
					if (offerVariables.holdCalled || offerVariables.isAmend ||
						((offerVariables && offerVariables.existingObject && offerVariables.existingObject.orderFlow.type === 'pending'
							&& offerVariables.existingObject.orderFlow.flow === 'billing'))) {
						offerVariables.selectedInstallation = custSubObj;
						if (offerVariables && offerVariables.existingObject && offerVariables.existingObject.orderFlow.type === 'pending'
							&& offerVariables.existingObject.orderFlow.flow === 'billing') {
							offerVariables.newTechInstall = true;
						}
						if (offerVariables.installationValues.product.productName === offerVariables.selectedInstallation.productName) {
							let newDiscounts;
							offerVariables.installationValues.product.productAttributes.forEach(newDiscountVal => {
								if (newDiscountVal.isPriceable === true && newDiscountVal.discounts !== null && newDiscountVal.discounts.length > 0) {
									newDiscounts = newDiscountVal.discounts;
								}
							});
							offerVariables.selectedInstallation.productAttributes.forEach(existDiscountVal => {
								if (existDiscountVal.isPriceable === true) {
									existDiscountVal.discounts = newDiscounts;
								}
							});
						}
						
					}
				}
				else if (!custSubObj && offerVariables.check && !offerVariables.isReEntrant) {
					offerVariables.selectedInstallation = this.searchForDefault(offerVariables, true, offerVariables.installationValues);
					offerVariables.newTechInstall = true;
				}
				else if (custSubObj && offerVariables.check) {
					offerVariables.selectedInstallation = custSubObj;
					offerVariables.newTechInstall = true;
				}
				({ custSubObj, custObj } = this.getExistingModem(offerVariables, custSubObj, custObj, isCompatible));
				custSubObj = this.findCustomerSubOrderObject(custObj, 'CENTURYLINK @ EASE');
				if (custSubObj !== undefined) {
					offerVariables.selectedEase = custSubObj;
					offerVariables.easeExist = true;
					this.onChangeEase(offerVariables, offerVariables.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue, false);
				}
				else if (offerVariables.easeValues) {
					offerVariables.selectedEase = this.searchForDefault(offerVariables, true, offerVariables.easeValues);
				}
				if (offerVariables.selectedModem) {
					offerVariables.canDisplayCS = this.displayCS(offerVariables, offerVariables.selectedModem);
					this.modemDisplayNameForCart(offerVariables.selectedModem, offerVariables.modemValues);
				} else {
					offerVariables.canDisplayCS = this.displayCS(offerVariables, offerVariables.existingModem);
					this.modemDisplayNameForCart(offerVariables.existingModem, offerVariables.modemValues);
				}

				custSubObj = this.findCustomerSubOrderObject(custObj, GenericValues.secureWifiComponent);
				if (custSubObj !== undefined) {
					offerVariables.selectedSecureWifi = custSubObj;
					offerVariables.secureWifiExist = true;
					this.onChangeSecureWifi(offerVariables, offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute[0].attributeValue, false);
				}
				else if (offerVariables.secureWifiValues) {
					if (offerVariables.canDisplayCS) {
						this.selectNotNeeded(offerVariables, offerVariables.secureWifiValues)
					}
				}

				custSubObj = this.findCustomerSubOrderObject(custObj, 'Jack and Wire');
				if (custSubObj !== undefined) {
					offerVariables.selectedJack = cloneDeep(custSubObj);
					offerVariables.jackExist = true;
					offerVariables.JacksWireDefault = false;
				}
				else {
					offerVariables.selectedJack = this.searchForDefault(offerVariables, true, offerVariables.jackValues);
				}
				if (!offerVariables.hpExisting) { offerVariables.undoSelected = false; }
			}

		} else {
			if (custSubObj !== undefined && !offerVariables.check) {
				offerVariables.newTechInstall = false;
				offerVariables.techInstallExist = true;
			}
			else if (!custSubObj && offerVariables.check && !offerVariables.isReEntrant) {
				offerVariables.newTechInstall = true;
			}
			else if (custSubObj && offerVariables.check) {
				offerVariables.newTechInstall = true;
			}
			if (!offerVariables.selfInstall) {
				offerVariables.selectedInstallation = this.searchForDefault(offerVariables, true, offerVariables.installationValues);
			} else {
				this.retainPreSelected(offerVariables, offerVariables.selectedInstallation, offerVariables.installationValues, 'install');
			}
			this.retainPreSelected(offerVariables, offerVariables.selectedModem, offerVariables.modemValues, 'modem', previousModemSelection);
			if (!offerVariables.existingServices) {
				this.retainPreSelected(offerVariables, offerVariables.selectedSecureWifi, offerVariables.secureWifiValues, 'security');
			} else {
				this.retainPreSelected(offerVariables, offerVariables.selectedSecureWifi, offerVariables.secureWifiValues, 'secureWifi');
			}
			this.retainPreSelected(offerVariables, offerVariables.selectedEase, offerVariables.easeValues, 'ease');
			this.retainPreSelected(offerVariables, offerVariables.selectedJack, offerVariables.jackValues, 'jack');
		}
		this.retainData(offerVariables);
		// tech Install
		if (offerVariables.installationValues && offerVariables.installationValues.isMandatory && !offerVariables.selectedInstallation) {
			if ((offerVariables.flow && offerVariables.flow !== 'MOVE' && (offerVariables.check && offerVariables.newTechInstall && offerVariables.existingServices))
				|| (offerVariables.flow && offerVariables.flow === 'MOVE') || !offerVariables.existingServices) {
				offerVariables.installError = true;
			}
		} else {
			offerVariables.installError = false;
		}
		// modem
		if (offerVariables.modemValues && offerVariables.modemValues.isMandatory && ((!offerVariables.selectedModem && !offerVariables.existingServices) || (!offerVariables.selectedModem && offerVariables.existingServices && (!offerVariables.isModemCompatible || !offerVariables.hsiExisting)))) {
			offerVariables.modemError = true;
		} else {
			offerVariables.modemError = false;
		}
		// secure Wifi
		if (offerVariables.secureWifiValues && offerVariables.secureWifiValues.isMandatory && !offerVariables.selectedSecureWifi
			&& this.displayCS(offerVariables, offerVariables.selectedModem)) {
			offerVariables.secureWifiError = true;
		} else {
			offerVariables.secureWifiError = false;
		}
		// ease
		if (offerVariables.easeValues && offerVariables.easeValues.isMandatory && !offerVariables.selectedEase) {
			offerVariables.easeError = true;
		} else {
			offerVariables.easeError = false;
		}

		// j&w
		if (offerVariables.jackValues && offerVariables.jackValues.isMandatory && !offerVariables.selectedJack) {
			offerVariables.jackError = true;
		} else {
			offerVariables.jackError = false;
		}

		this.retainData(offerVariables);
		if (!offerVariables.easeValues) {
			offerVariables.selectedEase = undefined;
		}
		if (!offerVariables.check && offerVariables.flow === 'CHANGE') {
			offerVariables.selectedInstallation = undefined;
		}
		if (offerVariables.byPassBool) {
			if (!offerVariables.hasTechnology) {
				offerVariables.selectedModem = undefined;
				offerVariables.selectedInstallation = undefined;
			} else {
				offerVariables.selectedInstallation = this.searchForDefault(offerVariables, true, offerVariables.installationValues);
				offerVariables.selectedModem = this.searchForDefault(offerVariables, true, offerVariables.modemValues);
			}
		}
		if (offerVariables.existingServices) {
			let custPotsObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.cHP);
			let custPotsSubObj: CustomerOrderSubItem = this.findCustomerSubOrderObjectIndexOf(custPotsObj, 'Wire Maintenance Plan');
			if (custPotsSubObj !== undefined) {
				offerVariables.selectedMaintainance = custPotsSubObj;
				offerVariables.wireMaintainanceExist = true;
			}
		}
		if ((!offerVariables.videoOfferTemp && !offerVariables.phoneOfferTemp && !offerVariables.existingServices) ||
			(!offerVariables.videoOffer && !offerVariables.phoneOffer && offerVariables.existingServices)) {
			offerVariables.isReEntrant = false;
			offerVariables.reentrantUI = false;
			offerVariables.retrieveOffersLoading = false;
			offerVariables.loading = false;
			this.shoppingCartRequest(offerVariables);
		}
		offerVariables.loadedConfig = false;
		if (internetProduct.productAttributes !== null && internetProduct.productAttributes.length > 0) {
			let attr = this.fetchIsPriceable(internetProduct.productAttributes);
			let discounts: Discounts[] = [];
			attr.discounts === null ? discounts = [] : discounts = attr.discounts;
			for (let discount of discounts) {
				if (discount.autoAttachInd === 'Y' && (discount.discountRule === null || discount.discountRule === 'A' || discount.discountRule === 'I' || discount.discountRule === 'O' || (discount.discountRule && discount.discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
					offerVariables.discountedPriceList.push(discount)
				}
			}
			// find the existing discount availble in the current offer
			if (offerVariables.existingServices) {
				for (let existdiscount of offerVariables.existingRetentionDiscounts) {
					let existingDiscountMatchFound = false;
					for (let discount of discounts) {
						if (existdiscount.discountId === discount.discountId && discount.autoAttachInd === 'N') {
							existingDiscountMatchFound = true;
						}
					}

					if (!existingDiscountMatchFound && existdiscount.discountDuration > 1 && discounts.length > 0) {
						if (offerVariables.hsiRemovedRetentiondiscounts && offerVariables.hsiRemovedRetentiondiscounts.length > 0) {
							offerVariables.hsiRemovedRetentiondiscounts.forEach(addeddisc => {
								if (existdiscount.discountId !== addeddisc.discountId) {
									offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
								}
							});
						} else {
							offerVariables.hsiRemovedRetentiondiscounts.push(existdiscount);
						}
						offerVariables.isShowRemoveRetentionDiscountMsg = true;
					}
					// send only discounts matching in current offer and not the otc discounts.
					if (existingDiscountMatchFound && existdiscount.discountDuration > 1) {
						offerVariables.retentionDiscountsToCart.push(existdiscount);

					}
				}
				if (!offerVariables.reEntrant) { this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart }); }
			}
			if (offerVariables.videoSelected === 'NoTV' && !offerVariables.phoneOffer) {
				offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
					this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
			}
		}
		offerVariables.oneTimeLoading = true;
	}
	private retrieveModemModel(offerVariables, products: any, isExtSpeedChanged?) {
		if (!isExtSpeedChanged) {
			products && products.forEach((data) => {
				if (data && data.productName === "MODEM") {
					data && data.productAttributes && data.productAttributes.forEach((productAttributes) => {
						productAttributes && productAttributes.compositeAttribute && productAttributes.compositeAttribute.forEach((values) => {
							if (!offerVariables.modemMakeModelCheck) { offerVariables.modemMakeModelCheck = true; }
							if (values && values.attributeName && values.attributeName === "modemMake" && values.attributeValue !== "null" && values.attributeValue !== null) {
								offerVariables.modemMake = values.attributeValue;
							} else if (values && values.attributeName && values.attributeName === "modemModel" && values.attributeValue !== "null" && values.attributeValue !== null) {
								offerVariables.modemModel = values.attributeValue;
							} else if (offerVariables.isHSIExistingProduct && values && values.attributeName && values.attributeName === "Modem Class" && values.attributeValue !== "null" && values.attributeValue !== null) {
								offerVariables.modemClass = values.attributeValue;
							}
						});
					});
				}
			});
		} else {
			products && products.product && products.product.productAttributes && products.product.productAttributes.forEach(data => {
				data.compositeAttribute.forEach(compAttr => {
					if (offerVariables.isHSIExistingProduct && compAttr.attributeName === "Modem Class") {
						offerVariables.modemClass = compAttr.attributeValue;
					}
				});
			});
			products && products.length && (products.length > 0) && products.forEach(data => {
				if (data && data.productName === "MODEM") {
					data && data.productAttributes && data.productAttributes.forEach((productAttributes) => {
						productAttributes && productAttributes.compositeAttribute && productAttributes.compositeAttribute.forEach((values) => {
							if (values && values.attributeName && values.attributeName === "Modem Class" && values.attributeValue !== "null" && values.attributeValue !== null) {
								offerVariables.modemClass = values.attributeValue;
							}
						});
					});
				}
			});
		}
	}
	public getExistingModem(offerVariables, custSubObj: CustomerOrderSubItem, custObj: any, isCompatible: boolean) {
		custSubObj = this.findCustomerSubOrderObject(custObj, 'MODEM');
		if (isCompatible) {
			custObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
			custSubObj = this.findCustomerSubOrderObject(custObj, 'MODEM');
			if (custSubObj) {
				if (!offerVariables.existingModem) {
					offerVariables.existingModem = custSubObj;
				}
				this.productService.checkDiscountExists(offerVariables.existingModem, 'MODEM');
				offerVariables.selectedModemToShow = custSubObj;
				offerVariables.modemExist = true;
				if (offerVariables.isAmend) { offerVariables.selectedModem = custSubObj; }
				if (offerVariables.existingModem && offerVariables.existingModem.productAttributes && offerVariables.existingModem.productAttributes.length > 0) {
					offerVariables.existingModem.productAttributes[0] = this.updateModemAttrValue(offerVariables.existingModem.productAttributes[0], GenericValues.leaseWithCsAttrVAlue);
				}
			}
		}
		return { custSubObj, custObj };
	}
	public retainData(offerVariables) {

		if (offerVariables.isReEntrant || offerVariables.reentrantUI) {
			let secureWifi = false;
			let isCompatible = this.getModemCompatibilty(offerVariables);
			let custObj = this.findCustomerOrderObject(offerVariables.cartCopyObject
				&& offerVariables.cartCopyObject.payload
				&& offerVariables.cartCopyObject.payload.cart
				&& offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
			if (custObj && custObj.customerOrderSubItems) {
				for (let i = 0; i < custObj.customerOrderSubItems.length; i++) {
					let custSubObj: CustomerOrderSubItem = custObj.customerOrderSubItems[i];
					if (custSubObj.componentType !== GenericValues.cPrimary) {
						switch (custSubObj.productName) {
							case GenericValues.install:
								if (offerVariables.reentrantUI && offerVariables.selfInstall) {
									offerVariables.selectedInstallation = custSubObj;
								}
								break;
							case GenericValues.modem:
								custSubObj.productAttributes[0] = this.updateModemAttrValue(custSubObj.productAttributes[0], GenericValues.leaseWithCsAttrVAlue);
								if (isCompatible && custSubObj !== undefined) {
									if (offerVariables.currentStore && offerVariables.currentStore.user
										&& offerVariables.currentStore.user.previousUrl === '/existing-products') {
										offerVariables.existingModem = custSubObj;
									} else if (offerVariables.isPendingFlow && custSubObj.dontShow && custSubObj.action !== 'NOCHANGE' && custSubObj.action !== 'REMOVE') {
										offerVariables.existingModem = custSubObj;
									} else {
										if (custSubObj.action !== 'NOCHANGE' && custSubObj.action !== 'REMOVE') {
											offerVariables.selectedModem = custSubObj;
										}
									}
									offerVariables.selectedModemType = this.getCurrentModemType(custSubObj.productAttributes);
									offerVariables.modemExist = true;
								}
								break;
							case GenericValues.secureWifiComponent:
								offerVariables.selectedSecureWifi = undefined;
								if (custSubObj.action !== 'REMOVE') {
									offerVariables.selectedSecureWifi = custSubObj;
									secureWifi = true;
								}
								break;
							case GenericValues.ease:
								offerVariables.selectedEase = custSubObj;
								let attrval = offerVariables.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue
								if (attrval !== 'na' && attrval !== 'Basic') {
									offerVariables.wireMaintainenceHide = false
								}
								break;
							case GenericValues.jack:
								offerVariables.selectedJack = cloneDeep(custSubObj);
								break;
						}
					}
				}
				if (!secureWifi && offerVariables.selectedModem && offerVariables.selectedModem.productAttributes
					&& offerVariables.selectedModem.productAttributes[0]
					&& offerVariables.selectedModem.productAttributes[0].compositeAttribute[0] && offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue === 'Purchase') {
					this.selectNotNeeded(offerVariables, offerVariables.secureWifiValues);
				}
			}
			if (offerVariables.selectedModem) {
				offerVariables.canDisplayCS = this.displayCS(offerVariables, offerVariables.selectedModem);
			} else {
				offerVariables.canDisplayCS = this.displayCS(offerVariables, offerVariables.existingModem);
			}
			this.modemDisplayNameForCart(offerVariables.selectedModem, offerVariables.modemValues);

			let reEntrantOfferVariable: OfferVariables = this.ctlHelperService.getLocalStorage(RE_ENTRANT_OFFERVARIABLE);
			if (reEntrantOfferVariable) {
				offerVariables.isExtendedAreaCallingPresent = reEntrantOfferVariable.isExtendedAreaCallingPresent;
				offerVariables.isOffer1PtyResLineSelected = reEntrantOfferVariable.isOffer1PtyResLineSelected;
				offerVariables.isExtendedAreaCallingYESSelected = reEntrantOfferVariable.isExtendedAreaCallingYESSelected;
				offerVariables.isExtendedAreaCallingNASelected = reEntrantOfferVariable.isExtendedAreaCallingNASelected;
				offerVariables.selectedExtendedAreaCalling = reEntrantOfferVariable.selectedExtendedAreaCalling;
				offerVariables.extendedAreaCallingPrice = reEntrantOfferVariable.extendedAreaCallingPrice;
			}
		}
	}

	public retainPreSelected(offerVariables, selectedProduct: Products, component: OfferProductComponents, type: string, modemCompatible?: boolean) {
		let prodComp = this.searchForDefault(offerVariables, true, component, undefined, type);
		if (type === 'security' && offerVariables.secureWifiDefault) {
			selectedProduct = undefined;
			offerVariables.selectedSecureWifi = undefined;
		}
		if (type === 'ease' && offerVariables.EaseDefault) {
			selectedProduct = undefined;
			offerVariables.selectedEase = undefined;
		}
		if (type === 'jack' && offerVariables.JacksWireDefault) {
			selectedProduct = undefined;
			offerVariables.selectedJack = undefined;
		}
		if (selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].compositeAttribute) {
			if (prodComp && prodComp.productAttributes && prodComp.productAttributes[0] && prodComp.productAttributes[0].compositeAttribute) {
				let exSelection = this.getModemType(selectedProduct.productAttributes[0].compositeAttribute, true);
				let currentDef = this.getModemType(prodComp.productAttributes[0].compositeAttribute, true);
				if ((exSelection === currentDef) || (type === 'modem' && currentDef && exSelection && (exSelection.indexOf(currentDef) !== -1 ||
					currentDef.substring(0, 5).indexOf(exSelection.substring(0, 5)) !== -1))) {
					let currentPrice, oldPrice;
					prodComp && prodComp.productAttributes && prodComp.productAttributes[0] && prodComp.productAttributes[0].prices && prodComp.productAttributes[0].prices.forEach(price => {
						if (price && price.priceType === GenericValues.pPriceType) {
							currentPrice = this.populateValues(price);
						}
					});
					selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].prices &&
						selectedProduct.productAttributes[0].prices.forEach(price => {
							if (price && price.priceType === GenericValues.pPriceType) {
								oldPrice = this.populateValues(price);
							}
						});
					if ((currentPrice <= oldPrice || (offerVariables.modemBillingType !== offerVariables.offerBillingType && currentDef.indexOf('Lease') !== -1))
						&& component !== null && component !== undefined) {
						this.changeSelection(type, currentDef, component, offerVariables);
					}
					else {
						this.makeUndefined(offerVariables, type);
					}
					if (type === 'modem') {
						offerVariables.modemBillingType = offerVariables.offerBillingType;
					}
				}
				else {
					let exSelection1 = this.getModemType(selectedProduct.productAttributes[0].compositeAttribute, true);
					let currentPrice: number = 0, oldPrice: number = 0;
					selectedProduct && selectedProduct.productAttributes && selectedProduct.productAttributes[0] && selectedProduct.productAttributes[0].prices &&
						selectedProduct.productAttributes[0].prices.forEach(price => {
							if (price && price.priceType === GenericValues.pPriceType) {
								oldPrice = this.populateValues(price);
							}
						});
					let currentDef1 = this.getModemType(selectedProduct.productAttributes[0].compositeAttribute, true);
					let price = currentDef1 === 'na' ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
						component, currentDef1, type.toUpperCase());
					if (price && price.prices && price.prices.length > 0) {
						price.prices.forEach(prize => {
							if (prize && prize.priceType === GenericValues.pPriceType) {
								currentPrice = this.populateValues(prize);
							}
						});
					}
					let isExExist = this.getPriceDetailsByAttrVal(component, exSelection1, '');
					if (isExExist) {
						if (currentPrice <= oldPrice && component !== null && component !== undefined) {
							this.changeSelection(type, exSelection1, component, offerVariables);
						} else {
							this.makeUndefined(offerVariables, type);
						}
					} else {
						if (type === 'install') {
							this.changeSelection(type, currentDef, component, offerVariables);
						}
					}
				}
			}
			else {
				let exSelection = this.getModemType(selectedProduct.productAttributes[0].compositeAttribute, true);
				if (component !== null && component !== undefined) {
					this.changeSelection(type, exSelection, component, offerVariables);
				}
			}
		}
	}
	public makeUndefined(offerVariables, type: string) {
		switch (type) {
			case 'install': offerVariables.selectedInstallation = undefined; break;
			case 'modem': offerVariables.selectedModem = undefined; break;
			case 'securityProduct': offerVariables.selectedSecureWifi = undefined; offerVariables.offerVariables.secureWifiDefault = true; break;
			case 'ease': offerVariables.selectedEase = undefined; offerVariables.EaseDefault = true; break;
			case 'jack': offerVariables.selectedJack = undefined; break;
		}
	}
	public changeSelection(type: string, exSelection: string, component: OfferProductComponents, offerVariables) {
		switch (type) {
			case 'install': this.onChangeInstallation(offerVariables, exSelection, component.isMandatory); break;
			case 'modem': this.onChangeModem(offerVariables, exSelection, component.isMandatory); break;
			case 'securityProduct': this.onChangeSecureWifi(offerVariables, exSelection, component.isMandatory); break;
			case 'ease': this.onChangeEase(offerVariables, exSelection, component.isMandatory); break;
			case 'jack': this.onChangeJack(offerVariables, exSelection, component.isMandatory); break;
		}
	}
	public onChangeInstallationDevices(offerVariables, val, component) {
		if (val === 'na') {
			offerVariables.deviceSelected = false;
			this.getProductConfig(offerVariables, component, false, undefined);
		} else {
			offerVariables.undoFlag = true;
			offerVariables.deviceSelected = true;
			this.getProductConfig(offerVariables, component, false, val);
			if(offerVariables.flow.toUpperCase() === 'CHANGE' || 'STACKAMEND') { offerVariables.newTechInstall = true; }
		}
		offerVariables.selectedQuantity = val;
		this.shoppingCartRequest(offerVariables);
	}
	public onChangeInstallation(offerVariables, attrVal: string, isMandatory: boolean, value?) {
		let flow = offerVariables.flow.toUpperCase();
		offerVariables.deviceMandatory = false;
		offerVariables.deviceSelected = false;
		if(flow === 'NI') {
			offerVariables.installationValues.product.productAttributes[0].compositeAttribute.forEach(val => {
			if (val.attributeDisplayName === attrVal) {
				attrVal = val.attributeValue;
			}
		});
	}
		let price = attrVal === 'na' ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
			offerVariables.installationValues, attrVal, '');

		offerVariables.selectedInstallation = this.searchForDefault(offerVariables, false, offerVariables.installationValues, price);
		this.checkProductConfig(offerVariables, offerVariables.selectedInstallation);
		if (attrVal === 'na') {
			isMandatory ? offerVariables.installError = true : offerVariables.installError = false;
			this.getProductConfig(offerVariables, offerVariables.selectedInstallation, false, undefined);
			offerVariables.selectedInstallation = undefined;
		} else {
			offerVariables.undoFlag = true;
			this.getProductConfig(offerVariables, offerVariables.selectedInstallation, false);
			offerVariables.installError = false;
			if (flow === 'CHANGE') { offerVariables.newTechInstall = true; }
		}
		if (value) {
			offerVariables.displayOffer = "CHANGE";
		}
		if (attrVal === GenericValues.selfInstall) {
			offerVariables.selfinstallSelected = true;
		} else {
			offerVariables.selfinstallSelected = false;
		}
		this.shoppingCartRequest(offerVariables);
		this.store.dispatch({ type: 'SELF_INSTALL_SELECTED', payload: offerVariables.selfinstallSelected })
		if (attrVal === 'Standard' && flow === 'MOVE') {
			this.store.dispatch({ type: 'TECH_INSTALL_SELECTED', payload: true });
		}
	}
	public getModemVal(attrVal) {
		return JSON.stringify(attrVal);
	}
	public onChangeModem(offerVariables, attrVal, isMandatory: boolean, value?, fromDropDown?, isObject?) {
		offerVariables.isConverted = false;
		if (isObject && attrVal !== 'na') {
			attrVal = JSON.parse(attrVal);
			let displayModemVal = this.getModemType(attrVal,false,true);
			if (displayModemVal === 'Convert to Purchased Modem') {
				offerVariables.isConverted = true;
			}
			attrVal = this.getModemType(attrVal,false,false);
		}
		// offerHelperService?.getModemType(modem?.compositeAttribute,false,false)
		let flow = offerVariables.flow.toUpperCase();
		if (fromDropDown && flow === 'MOVE') { offerVariables.modemDropDown = true; }
		let price = attrVal === 'na' ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
			offerVariables.modemValues, attrVal, GenericValues.modem, offerVariables.isConverted);
		offerVariables.selectedModem = this.searchForDefault(offerVariables, false, offerVariables.modemValues, price);
		if (attrVal === 'na') {
			isMandatory ? offerVariables.modemError = true : offerVariables.modemError = false;
			offerVariables.selectedModem = undefined;
		} else {
			offerVariables.undoFlag = true;
			offerVariables.modemError = false;
		}
		if (value) { offerVariables.displayOffer = "CHANGE"; }
		if (flow === 'NEWINSTALL') {
			this.modemDisplayNameForCart(offerVariables.selectedModem, offerVariables.modemValues)
			if (offerVariables.isSecureWifi) {
				this.onChangeSecureWifi(offerVariables, 'na', offerVariables.secureWifiValues.isMandatory);
			}
		}
		this.shoppingCartRequest(offerVariables);

		if (offerVariables.secureWifiValues) {
			if (offerVariables.selectedModem) {
				offerVariables.canDisplayCS = this.displayCS(offerVariables, offerVariables.selectedModem);
				this.modemDisplayNameForCart(offerVariables.selectedModem, offerVariables.modemValues)
			} else if (flow !== 'BILLANDREC') {
				offerVariables.canDisplayCS = this.displayCS(offerVariables, offerVariables.existingModem);
				this.modemDisplayNameForCart(offerVariables.existingModem, offerVariables.modemValues)
			}
			if (!offerVariables.canDisplayCS) {
				offerVariables.selectedSecureWifi = undefined;
				this.onChangeSecureWifi(offerVariables, 'na', false);
			} else if (!offerVariables.selectedSecureWifi) {
				offerVariables.selectedSecureWifi = this.searchForDefault(offerVariables, false, offerVariables.secureWifiValues);
				if (offerVariables.selectedSecureWifi) {
					this.onChangeSecureWifi(offerVariables,
						offerVariables &&
						offerVariables.selectedSecureWifi &&
						offerVariables.selectedSecureWifi.productAttributes &&
						offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute &&
						offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute[0].attributeValue,
						offerVariables.secureWifiValues && offerVariables.secureWifiValues.isMandatory);
				} else {
					this.onChangeSecureWifi(offerVariables,
						'na',
						offerVariables.secureWifiValues && offerVariables.secureWifiValues.isMandatory);
				}
			}
		}
	}
	public onChangeSecureWifi(offerVariables, attrVal: string, isMandatory: boolean) {
		offerVariables.secureWifiDefault = false;
		let price = (attrVal === 'na') ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
			offerVariables.secureWifiValues, attrVal, '');
		offerVariables.selectedSecureWifi = this.searchForDefault(offerVariables, false, offerVariables.secureWifiValues, price);
		let condition = offerVariables.flow.toUpperCase() === 'MOVE' ? (this.displayCS(offerVariables, offerVariables.selectedModem) && attrVal === 'na') : attrVal === 'na'
		if (condition) {
			offerVariables.secureWifiDefault = true;
			isMandatory ? offerVariables.secureWifiError = true : offerVariables.secureWifiError = false;
			offerVariables.selectedSecureWifi = undefined;
		} else {
			offerVariables.undoFlag = true;
			offerVariables.secureWifiDefault = false;
			offerVariables.secureWifiError = false;
		}
		this.shoppingCartRequest(offerVariables);
	}

	public onChangeEase(offerVariables, attrVal: string, isMandatory: boolean) {
		let flow = offerVariables.flow.toUpperCase();
		offerVariables.EaseDefault = false;
		switch (flow) {
			case 'NEWINSTALL':
				if ((attrVal !== 'na' && attrVal !== 'Basic') && offerVariables.phoneOffer) {
					this.checkCompatibilityEaseAndWireMaintenance(offerVariables);
				} else if (offerVariables.phoneOffer) {
					offerVariables.wireMaintainenceHide = true;
				}
				break;
			case 'CHANGE':
			case 'BILLING':
			case 'MOVE':
				if ((attrVal !== 'na' && attrVal !== 'Basic') && offerVariables.phoneOffer) {
					this.checkCompatibilityEaseAndWireMaintenance(offerVariables);
				} else if (offerVariables.phoneOffer) {
					if (offerVariables.wireMaintainanceInput && offerVariables.wireMaintainanceInput.nativeElement && offerVariables.wireMaintainanceInput.nativeElement.value === 'na') {
						offerVariables.wireMaintainenceHide = true;
						if (flow === 'CHANGE') {
							offerVariables.isWireMaintainanceNoSelected = false;
							offerVariables.isWireMaintainanceYesSelected = false;
						}
					}
				}
				break;
			case 'STACKAMEND':
				if ((attrVal !== 'na' && attrVal !== 'Basic') && offerVariables.wireMaintainPresent && offerVariables.phoneOffer) {
					this.checkCompatibilityEaseAndWireMaintenance(offerVariables);
				} else if (offerVariables.wireMaintainPresent && offerVariables.phoneOffer) {
					offerVariables.wireMaintainenceHide = true;
				}
				break;
		}

		let price = attrVal === 'na' ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
			offerVariables.easeValues, attrVal, '');
		offerVariables.selectedEase = this.searchForDefault(offerVariables, false, offerVariables.easeValues, price);
		if (attrVal === 'na') {
			if(flow === 'NEWINSTALL') { offerVariables.EaseDefault = true; }
			isMandatory ? offerVariables.easeError = true : offerVariables.easeError = false;
			offerVariables.selectedEase = undefined;
		} else {
			if (flow === 'NEWINSTALL') { offerVariables.EaseDefault = false; }
			offerVariables.easeError = false;
			if (flow !== 'NEWINSTALL') { offerVariables.undoFlag = true; }
		}
		this.shoppingCartRequest(offerVariables);
	}

	public onChangeJack(offerVariables, attrVal: string, isMandatory: boolean) {
		offerVariables.retainValueForPotsJack = attrVal;
		offerVariables.JacksWireDefault = false;
		let price = attrVal === 'na' ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(
			offerVariables.jackValues, attrVal, '');
		offerVariables.selectedJack = cloneDeep(this.searchForDefault(offerVariables, false, offerVariables.jackValues, price));
		if (attrVal === 'na') {
			isMandatory ? offerVariables.jackError = true : offerVariables.jackError = false;
			offerVariables.selectedJack = undefined;
			offerVariables.JacksWireDefault = true;
			if (offerVariables.flow.toUpperCase() === 'STACKAMEND') { offerVariables.potsJacksMandatory = true; }
		} else {
			offerVariables.jackError = false;
			if (offerVariables.flow.toUpperCase() !== 'NEWINSTALL') { offerVariables.undoFlag = true; }
		}
		this.shoppingCartRequest(offerVariables);
	}
	public filterProductWithPrice(items: OfferProductComponents, offerVariables, nonPricable?, attrName?, attrVal?): OfferProductComponents {
		let item = cloneDeep(items);
		let modem: OfferProductComponents;
		let value: AttributesCombination;
		let values: AttributesCombination[] = [];
		item.product.productAttributes.forEach(val => {
			let price: Prices[] = [];
			if (val.isPriceable) {
				let comp: CompositeAttribute[] = [];
				if (item.product.productName === GenericValues.modem) {
					val = this.updateModemAttrValue(val, GenericValues.leaseWithCsAttrVAlue)
				}
				val.compositeAttribute.forEach(attr => {
					if (attr.attributeValue === 'Self Install') {
						offerVariables.selfInstall = true;
					}
					if (attr.attributeName === 'Account Type') {
						comp.push(attr);
					}
				});
				val.compositeAttribute.forEach(attr => {
					if (attr.attributeName !== 'Account Type') {
						comp.push(attr);
					}
				});
				val = Object.assign({},
					val, {
					compositeAttribute: comp
				}
				)
				value = val;
				val && val.prices && val.prices.forEach(v => {
					if (v.priceType === GenericValues.pPriceType) {
						price.push(v);
					}
				});
				value && value.prices && value.prices.forEach(v => {
					if (v.priceType !== GenericValues.pPriceType) {
						price.push(v);
					}
				});
				value = Object.assign({},
					value, {
					prices: price
				}
				)
				values.push(value);
			} else if (nonPricable) {
				if (attrName && attrVal) {
					val && val.compositeAttribute && val.compositeAttribute.forEach(attr => {
						if (attrName === attr.attributeName && attrVal === attr.attributeValue) {
							values.push(val);
						}
					});
				} else {
					values.push(val);
					val && val.compositeAttribute && val.compositeAttribute.forEach(attr => {
						if (attr.attributeName === 'TechInstallRecommended') {
							offerVariables.recommendedTech = val;
						}
					});
				}

			}
		})
		let cloneItem = cloneDeep(item);
		cloneItem.product = Object.assign({},
			cloneItem.product, {
			productAttributes: values
		}
		)
		let product = {
			productId: cloneItem.product.productId,
			productName: cloneItem.product.productName,
			productDisplayName: cloneItem.product.productDisplayName,
			productType: cloneItem.product.productType,
			componentType: cloneItem.componentType,
			productAttributes: cloneItem.product.productAttributes,
			productAssociations: cloneItem.product.productAssociations,
			productCategory: cloneItem.product.productCategory,
			quantity: cloneItem.product.quantity
		};
		modem = cloneDeep(cloneItem);
		modem = Object.assign({},
			modem, {
			product: product
		}
		)
		return modem;
	}
	public filterLogic(offerVariables: OfferVariables, item: ProductOfferings, speed: Products, flag?): any {
		// filtering for truck and sorting

		offerVariables.selfInstall = false;
		let isCompatible = false;
		this.filterProductByType(offerVariables, item, "TECH INSTALL");
		let technology = 'Technology: Unknown, must select';
		if (!offerVariables.selfInstallAvailable) {
			offerVariables.selfInstallAvailable = offerVariables.selfInstall;
		}
		offerVariables.modemCompatValues = this.filterProductByType(offerVariables, item, "MODEM", false, undefined, true);
		isCompatible = this.getModemCompatibilty(offerVariables, flag);
		if (!offerVariables.modemAvailable) {
			offerVariables.modemAvailable = isCompatible;
		}
		speed && speed.productAttributes && speed.productAttributes.forEach(attr => {
			attr.compositeAttribute && attr.compositeAttribute.forEach(compAttr => {
				if (compAttr.attributeName === 'Technology' && compAttr.attributeValue && compAttr.attributeValue) {
					technology = compAttr.attributeValue;
				}
			});
		});
		let prices = this.fetchPriceTypeFromPrimary(speed.productAttributes);
		let offerBillingType = item.productOffer.offerBillingType ? item.productOffer.offerBillingType : "POSTPAID"

		let name: any = {
			productName: speed.productName,
			productDisplayName: speed.productDisplayName,
			techInstall: offerVariables.selfInstall,
			modem: isCompatible,
			technology: technology,
			tan: offerVariables.isTan,
			prices: prices,
			offerBillingType: offerBillingType,
			productOfferingId: item.productOfferingId
		};
		return name;
	}

	public getProdComponent(offerVariables: OfferVariables, prodName, val) {
		let product: Products;
		let prod = this.filterProductByType(offerVariables, offerVariables.selectedTVOffer, prodName);
		prod.product.productAttributes.forEach(attr => {
			if (attr.isPriceable) {
				attr.compositeAttribute.forEach(compAttr => {
					if (compAttr.attributeName === 'Quantity' && val === compAttr.attributeValue) {
						product = prod.product;
						product = Object.assign({},
							product, {
							productAttributes: [attr]
						});
					}
				});
			}
		});
		return product;
	}

	public getModemCompatibilty(offerVariables: OfferVariables, flag?): boolean {
		let isModemCompatible = true;
		offerVariables
			&& offerVariables.modemCompatValues
			&& offerVariables.modemCompatValues.product
			&& offerVariables.modemCompatValues.product.productAttributes
			&& offerVariables.modemCompatValues.product.productAttributes.forEach(attr => {
				attr && attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
					if (comp && comp.attributeName === 'modemCompatibility' && comp.attributeValue && comp.attributeValue.toLowerCase() === 'false') {
						isModemCompatible = false;
					}
				});
			});
		if (!flag) { offerVariables.isModemCompatible = isModemCompatible; }
		return isModemCompatible;
	}

	public configRequest(offerVariables: OfferVariables, config, values, flag, comp: Products) {
		if (values) {
			let select = false;
			if (flag && values) {
				values.forEach(val => {
					if (!select && val.isDefault) {
						offerVariables.deviceSelected = true;
						values = val;
						select = true;
					}
					else if (!select && val.value === offerVariables.selectedQuantity) {
						offerVariables.deviceSelected = true;
						select = true;
					}
				});
			}
			if (!select && flag) {
				values = values[0];
				offerVariables.deviceSelected = true;
				offerVariables.selectedQuantity = values && values.value;
			}
			if (!flag) {
				offerVariables.deviceSelected = true;
				values = {
					value: values
				}
				offerVariables.selectedQuantity = values && values.value;
			}
			if (offerVariables.deviceMandatory && offerVariables.selectedQuantity !== 'na') {
				offerVariables.deviceSelected = true;
			} else { offerVariables.deviceSelected = false; }
			if (offerVariables.deviceSelected) {
				let productConfiguration = {
					"configItems": [
						{
							"productId": "",
							"productName": config.configItems[0].productName,
							"configDetails": [
								{
									"isConfigRequired": config.configItems[0].configDetails[0].isConfigRequired,
									"formName": config.configItems[0].configDetails[0].formName,
									"formItems": [
										{
											"attributeName": config.configItems[0].configDetails[0].formItems[0].attributeName,
											"attributeType": config.configItems[0].configDetails[0].formItems[0].attributeType,
											"isMandatory": config.configItems[0].configDetails[0].formItems[0].isMandatory,
											"attributeValue": [{
												value: offerVariables.selectedQuantity
											}]
										}
									]
								}
							]
						}
					],
					"productType": config.productType
				}
				let pushed = false;
				if (offerVariables.configSelected.length > 0) {
					for (let i = 0; i < offerVariables.configSelected.length; i++) {
						if (offerVariables.configSelected[i].configItems[0].productName === comp.productName) {
							offerVariables.configSelected[i] = productConfiguration;
							pushed = true;
							break;
						}
					}
					if (!pushed) {
						offerVariables.configSelected.push(productConfiguration);
					}
				} else if (offerVariables.configSelected.length === 0) {
					offerVariables.configSelected.push(productConfiguration);
				}
			}
		} else {
			if (offerVariables.configSelected.length > 0) {
				for (let i = 0; i < offerVariables.configSelected.length; i++) {
					if (comp && offerVariables.configSelected && offerVariables.configSelected[i] && offerVariables.configSelected[i].configItems &&
						offerVariables.configSelected[i].configItems[0] && offerVariables.configSelected[i].configItems[0].productName === comp.productName) {
						offerVariables.configSelected.splice(i, 1);
						break;
					}
				}
			}
		}
	}

	public checkProductConfig(offerVariables: OfferVariables, comp: Products): boolean {
		let check = false;
		if (offerVariables.productConfiguration && offerVariables.productConfiguration.length > 0) {
			let configList = offerVariables.productConfiguration;
			configList.forEach(config => {
				if (config && config.configItems !== null && config.configItems && config.configItems.length > 0) {
					config.configItems.forEach(item => {
						if (!check && comp && item.productName === comp.productName) {
							if (item.prodSelectionRule !== null && item.prodSelectionRule && item.prodSelectionRule.length > 0) {
								item.prodSelectionRule.forEach(rule => {
									if (comp && rule.action === GenericValues.cSelect && comp.productAttributes && comp.productAttributes[0]
										&& comp.productAttributes[0].compositeAttribute && comp.productAttributes[0].compositeAttribute[0]
										&& rule.value === comp.productAttributes[0].compositeAttribute[0].attributeValue) {
										check = true;
									}
								});
							}
						}
					});
				}
			});
		}
		return check;
	}

	public getProductConfig(offerVariables: OfferVariables, comp: Products, flag, val?, change?): any {
		let values = [];
		if (offerVariables.productConfiguration && offerVariables.productConfiguration.length > 0) {
			let configList = offerVariables.productConfiguration;
			configList.forEach(config => {
				let attributeExist = false;
				if (config && config.configItems !== null && config.configItems && config.configItems.length > 0) {
					config.configItems.forEach(item => {
						if (comp && item.productName === comp.productName) {
							if (item.prodSelectionRule !== null && item.prodSelectionRule && item.prodSelectionRule.length > 0) {
								item.prodSelectionRule.forEach(rule => {
									if (rule.action === GenericValues.cSelect && comp.productAttributes && comp.productAttributes[0]
										&& comp.productAttributes[0].compositeAttribute && comp.productAttributes[0].compositeAttribute[0]
										&& rule.value === comp.productAttributes[0].compositeAttribute[0].attributeValue) {
										attributeExist = true;
										values = offerVariables.tempConfig;
										if (flag && item.configDetails !== null && item.configDetails && item.configDetails.length > 0) {
											item.configDetails.forEach(det => {
												let isExistConfig = false;
												if (det.formName === GenericValues.cDevices) {
													det.formItems && det.formItems.forEach(form => {
														if (!offerVariables.reEntrant || !offerVariables.loadedConfig) {
															values = form.attributeValue;
															offerVariables.tempConfig = values;
															offerVariables.deviceMandatory = form.isMandatory;
														}
														if (offerVariables.configSelected.length > 0) {
															for (let i = 0; i < offerVariables.configSelected.length; i++) {
																if (offerVariables.configSelected[i].configItems[0].productName === comp.productName) {
																	isExistConfig = true;
																	break;
																}
															}
														}
														if (!isExistConfig && !offerVariables.reEntrant) {
															this.configRequest(offerVariables, config, values, true, comp);
														} else if (offerVariables.reEntrant && (!offerVariables.loadedConfig || change)) {
															let selectConfigList;
															if (offerVariables.cartCopyObject && offerVariables.cartCopyObject.payload && offerVariables.cartCopyObject.payload.productConfiguration) {
																selectConfigList = offerVariables.cartCopyObject.payload.productConfiguration;
															}
															if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
																for (let i = 0; i < selectConfigList.length; i++) {
																	selectConfigList[i].configItems && selectConfigList[i].configItems.forEach(selectedConf => {
																		if (comp && selectedConf.productName === comp.productName) {
																			let tempVal = [];
																			values && values.forEach(value => {
																				offerVariables.deviceMandatory = form.isMandatory;
																				if (value.value === offerVariables.selectedQuantity) {
																					tempVal.push({ value: value.value, isDefault: true })
																				} else {
																					tempVal.push({ value: value.value, isDefault: false })
																				}
																			});
																			values = tempVal;
																			offerVariables.tempConfig = values;
																		}
																	})
																}
															}
															this.configRequest(offerVariables, config, values, true, comp);
														}
														offerVariables.loadedConfig = true;
													});
												}
											});
										} else if (!flag) {
											this.configRequest(offerVariables, config, val, false, comp);
										}
									}
								});
							}
						} else {
							values = [];
						}
					});
				}
				if (!attributeExist) {
					this.configRequest(offerVariables, config, undefined, false, comp);
				}
			});
		}
		return values;
	}

	public checkCompatibilityEaseAndWireMaintenance(offerVariables: OfferVariables) {
		if (offerVariables.compatibilityArray && offerVariables.compatibilityArray.outputAttribute && offerVariables.compatibilityArray.outputAttribute.length > 0) {
			for (let i = offerVariables.compatibilityArray.outputAttribute.length - 1; i >= 0; i--) {
				let compArr = [] = offerVariables.compatibilityArray && offerVariables.compatibilityArray.outputAttribute[i];
				if ((compArr[2] === GenericValues.iData && compArr[8] === GenericValues.cHP && compArr[7] === GenericValues.includesNotRequired
					&& compArr[4].trim() === 'CENTURYLINK @ EASE' && compArr[10] === 'Inside Wire Maintenance Plan-R')) {
					offerVariables.wireMaintainenceHide = false;
					offerVariables.isWireMaintainanceNoSelected = true;
					offerVariables.isWireMaintainanceYesSelected = false;
					offerVariables.wireMaintainance = false;
					offerVariables.selectedMaintainance = undefined;
				}
			}
		}
	}

	public getSTBPrice(offerVariables: OfferVariables, prodName: string) {
		if (prodName === 'Wired Set Top Box') {
			offerVariables.wiredSTB = this.getProdComponent(offerVariables, prodName, offerVariables.selectedTotal);
		} else {
			offerVariables.wirelessSTB = this.getProdComponent(offerVariables, prodName, offerVariables.selectedWire);
		}
	}

	public checkExistingOnlyOfferingId(existingProduct, currentProduct, type) {
		let val = 'CHANGE';
		let undoChanges = true;
		if (type === 'internet' && existingProduct !== undefined && currentProduct !== undefined) {
			if (existingProduct.customerOrderSubItems !== null && existingProduct.customerOrderSubItems
				&& existingProduct.customerOrderSubItems.length > 0) {
				existingProduct.customerOrderSubItems.forEach(subItems => {
					if (undoChanges && subItems.componentType === GenericValues.cPrimary) {
						if (currentProduct.productOffer.productComponents) {
							currentProduct.productOffer.productComponents.forEach(currentItem => {
								if (undoChanges && currentItem.componentType === GenericValues.cPrimary
									&& subItems.productId === currentItem.product.productId) {
									val = 'NOCHANGE';
									undoChanges = false;
								}
							});
						}
					}
				});

			}
			return val;
		}
		else if (type === 'subinternet' && existingProduct !== undefined && currentProduct !== undefined) {
			if (existingProduct.existingServiceSubItems !== null && existingProduct.existingServiceSubItems
				&& existingProduct.existingServiceSubItems.length > 0) {
				existingProduct.existingServiceSubItems.forEach(subItems => {
					if (undoChanges && subItems.componentType === GenericValues.cPrimary) {
						if (currentProduct.productOffer.productComponents) {
							currentProduct.productOffer.productComponents.forEach(currentItem => {
								if (undoChanges && currentItem.componentType === GenericValues.cPrimary
									&& subItems.productId === currentItem.product.productId) {
									val = 'NOCHANGE';
									undoChanges = false;
								}
							});
						}
					}
				});

			}
			return val;
		}
		else {
			return 'NOCHANGE';
		}
	}

	/************************************************/
	/* HTML method calls for Offer Page(s)  - Start */
	/************************************************/
	public getActualPrice(filterBySpeed: string, category: string, internetCheck, phoneSelected, internerOffer, phoneOffer, videorOffer): number {
		let prod: Products;
		let price: number = 0;
		let offer: ProductOfferings[] = [];
		category === GenericValues.sData || category === GenericValues.iData ? offer = internerOffer : offer = videorOffer;
		offer && offer.forEach((item) => {
			if (!price && item && item.productOffer && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length > 0) {
				item.productOffer.offerAttributes.forEach(attr => {
					if (internetCheck && (!phoneOffer || (phoneOffer && phoneSelected === 'DHP')) && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'no') {
						price = this.getOfferPrice(item, prod, price, filterBySpeed, 'actual');
					} else if (phoneOffer && phoneSelected === 'HMP' && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'yes') {
						price = this.getOfferPrice(item, prod, price, filterBySpeed, 'actual');
					}
				});
			}
		});
		return price;
	}

	public getDiscountedPrice(filterBySpeed: string, category: string, internetCheck, phoneSelected, internerOffer, phoneOffer, videorOffer): number {
		let prod: Products;
		let price: number = 0;
		let offer: ProductOfferings[] = [];
		category === GenericValues.sData || category === GenericValues.iData ? offer = internerOffer : offer = videorOffer;
		offer && offer.forEach((item) => {
			if (!price && item && item.productOffer && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length > 0) {
				item.productOffer.offerAttributes.forEach(attr => {
					if (internetCheck && (!phoneOffer || (phoneOffer && phoneSelected === 'DHP')) && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'no') {
						price = this.getOfferPrice(item, prod, price, filterBySpeed, 'disc');
					} else if (phoneOffer && phoneSelected === 'HMP' && attr.attributeName === 'withPhone-HP' && attr.attributeValue.toLowerCase() === 'no') {
						price = this.getOfferPrice(item, prod, price, filterBySpeed, 'disc');
					}
				});
			}
		});
		return price;
	}

	public getModemType(compositeAttribute: CompositeAttribute[], flag?: boolean, newInstall?: boolean): string {
		let val: string = '';
		if (newInstall && compositeAttribute) {
			compositeAttribute.forEach(attr => {
				if (attr.attributeName && attr.attributeName.toLowerCase() !== 'modem type' && attr.attributeName.toLowerCase() !== 'modem class' && attr.attributeName !== GenericValues.cyberSecurity) {
					val = flag ? attr.attributeValue : attr.attributeDisplayName;
				}
			});
		}
		else if (!newInstall && compositeAttribute) {
			compositeAttribute.forEach(attr => {
				if (attr.attributeName === "Account Type" || attr.attributeName === "Service Level" || attr.attributeName === "Installation Number") {
					val = attr.attributeValue;
				}
				if (attr.attributeName === "allowSPSkipModemRules") {
					val = attr.attributeValue;
				}
			});
		}
		return val;
	}

	public getDisabledStatus = (item, offerVariables) => {
		let ret;
		if (item && item.compositeAttribute) {
			item.compositeAttribute.forEach((attr) => {
				if (attr.attributeName && attr.attributeName.toLowerCase() === 'allowSPSkipModemRules'.toLowerCase()) {
					if (offerVariables.selectedModem && offerVariables.selectedModem.productAttributes && offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeName.toLowerCase() === attr.attributeName.toLowerCase()) {
						ret = false;
					}
					else {
						ret = offerVariables.bypassModemRulesBool ? false : true;
					}
				}
			});
			return ret;
		}
	}

	/************************************************/
	/* HTML method calls for Offer Page(s)  - Stop  */
	/************************************************/

	public getCurrentModemType(productAttribute: AttributesCombination[]): string {
		let val: string = '';
		if (productAttribute && productAttribute.length > 0) {
			productAttribute.forEach(attr => {
				attr = this.updateModemAttrValue(attr, GenericValues.leaseWithCsAttrVAlue);
				if (attr.isPriceable) {
					attr.compositeAttribute.forEach(item => {
						if (item.attributeName === 'Account Type') {
							val = item.attributeValue
						}
					});
				}
			});
			return val;
		}
	}

	public getModemDisplayType(compositeAttribute: any[]): string {
		let val: string = '';
		if (compositeAttribute) {
			compositeAttribute.forEach(attr => {
				if (attr.attributeName === 'Account Type') {
					val = attr.attributeDisplayName;
				}
				if (attr.attributeName === 'allowSPSkipModemRules') {
					val = attr.attributeDisplayName;
				}
			});
			return val;
		}
	}

	public getModemTypeforRetain(compositeAttribute: CompositeAttribute[]): string {
		let val: string = '';
		compositeAttribute && (compositeAttribute.length > 0) && compositeAttribute.forEach(attr => {
			if (attr.attributeName && attr.attributeName.toLowerCase() !== 'modem type' && attr.attributeName && attr.attributeName.toLowerCase() !== 'modem class' && attr.attributeName.toLowerCase() !== 'cyber security') {
				val = attr.attributeValue;
			}
		});
		return val;
	}

	public getJackType(compositeAttribute: CompositeAttribute[]): string {
		let val: string = '';
		compositeAttribute && (compositeAttribute.length > 0) && compositeAttribute.forEach(attr => {
			val = attr.attributeDisplayName;
		});
		return val;
	}

	public getJackAttribName(compositeAttribute: CompositeAttribute[]): string {
		let val: string = '';
		compositeAttribute && (compositeAttribute.length > 0) && compositeAttribute.forEach(attr => {
			if (attr.attributeName === 'Installation Number') {
				val = attr.attributeValue;
			}
		});
		return val;
	}
	public findCustomerSubOrderObjectIndexOf(custObj: CustomerOrderItems, filterBy): Products {
		let val: Products;
		if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
			custObj.customerOrderSubItems.forEach(obj => {
				if (obj.productName.indexOf(filterBy) !== -1) {
					val = obj;
				}
			});
		}
		return val;
	}

	public findCustomerOrderObject(custObj: CustomerOrderItems[], filterBy, flag?): CustomerOrderItems {
		let val: CustomerOrderItems;
		if (custObj !== undefined) {
			custObj.forEach(obj => {
				if (!flag && obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER' && obj.action !== "VACRES-REMOVE" && obj.offerName !== VacationEnums.HSI_VAC_SUS_OFFER_NAME) {
					val = obj;
				} else if (flag && (obj.offerCategory === filterBy || obj.offerCategory === GenericValues.sData) && obj.offerType !== 'SUBOFFER' && obj.offerName !== "HSI Vacation" && obj.action !== VacationEnums.HSI_VAC_SUS_OFFER_NAME) {
					val = obj;
				}
			});
		}
		return val;
	}

	public checkTV(value: string, offerVariables: any) {
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		switch (flow) {
			case 'MOVE':
			case 'STACKAMEND':
			case 'CHANGE':
				offerVariables.newVideoSelected = value;
				if (offerVariables.newVideoSelected !== GenericValues.noTv && (!offerVariables.internetCheck && (!offerVariables.phoneOffer || (offerVariables.phoneOffer && offerVariables.phoneSelected !== GenericValues.homePhone)))) {
					if (flow === 'MOVE') {
						offerVariables.newInternetCheck = true;
					} else {
						offerVariables.newInternetCheck = true;
						offerVariables.internetCheck = true;
					}
				}
				if (!offerVariables.dtvExisting && offerVariables.newVideoSelected !== GenericValues.noTv) {
					offerVariables.undoFlag = true;
				}
				if (flow === 'CHANGE') { offerVariables.newVideoUpdated = true; }
				break;
			case 'BILLING':
				offerVariables.videoSelected = value;
				if (
					offerVariables.videoSelected !== GenericValues.noTv &&
					(!offerVariables.internetCheck &&
						(!offerVariables.phoneOffer || (offerVariables.phoneOffer && offerVariables.phoneSelected !== GenericValues.homePhone)))
				) {
					offerVariables.internetCheck = true;
				}
				if (!offerVariables.dtvExisting && offerVariables.videoSelected !== GenericValues.noTv) {
					offerVariables.undoFlag = true;
				}
				break;
			default:
				offerVariables.errorMsg = '';
				if (value === GenericValues.dtv) {
					if (offerVariables.newInternetCheck === false && offerVariables.newPhoneSelected !== GenericValues.homePhone) {
						offerVariables.errorMsg = 'DTV must have a Internet or Home Phone';
					}
					else {
						offerVariables.newVideoSelected = value;
					}
				}
				else if (value !== GenericValues.noTv && offerVariables.internetAvail) {
					offerVariables.newInternetCheck = true;
				} else if (value !== GenericValues.noTv && !offerVariables.internetAvail) {
					offerVariables.errorMsg = value + ' cannot be selected as Internet is unavailable';
				} else if (value === GenericValues.noTv) {
					offerVariables.newVideoSelected = value;
				}
				offerVariables.newVideoUpdated = true;
				break;
		}
	}

	public findCustomerSubOrderObjectForRetain(custObj: CustomerOrderItems, filterBy): Products {
		let val: Products;
		let subItems: Products[] = [];
		if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
			subItems = custObj.customerOrderSubItems;
		} else if (custObj !== undefined && custObj.existingServiceSubItems !== undefined) {
			subItems = custObj.existingServiceSubItems;
		}

		subItems && subItems.forEach(obj => {
			if (obj.productName === filterBy) {
				let values: AttributesCombination[] = [];
				let flag: boolean = false;
				obj.productAttributes.forEach(attr => {
					if (!flag) {
						flag = true;
						values.push(attr);
					}
				});
				obj = Object.assign({}, obj, { productAttributes: values });
				val = obj;
			}
		});
		return val;
	}

	public findCustomerSubOrderObject(custObj: CustomerOrderItems, filterBy): Products {
		let val: Products;
		let subItems: Products[] = [];
		if (custObj !== undefined && custObj.customerOrderSubItems !== undefined) {
			subItems = custObj.customerOrderSubItems;
		} else if (custObj !== undefined && custObj.existingServiceSubItems !== undefined) {
			subItems = custObj.existingServiceSubItems;
		}
		subItems && subItems.forEach(obj => {
			if (obj.productName === filterBy && filterBy === 'MODEM') {
				obj.productAttributes && obj.productAttributes.forEach(attr => {
					if (attr.isPriceable) {
						obj = Object.assign({}, obj, {
							productAttributes: [attr]
						});
						obj.productAttributes[0] = Object.assign({}, obj.productAttributes[0], {
							compositeAttribute: attr.compositeAttribute.sort(this.sortModemComposite)
						});
					}
				});
				val = obj;
			}
			else if (obj.productName === filterBy && filterBy !== 'MODEM' && obj.action !== 'REMOVE') {
				val = obj;
			}
		});
		return val;
	}

	public findCustomerOrderProduct(custObj: CustomerOrderItems[], filterBy, flag?): CustomerOrderItems {
		let val: CustomerOrderItems;
		if (custObj !== undefined) {
			custObj.forEach(obj => {
				if (!flag && obj.productType === filterBy) {
					val = obj;
				} else if (flag && (obj.productType === filterBy || obj.productType === GenericValues.sData || obj.offerCategory === GenericValues.iData)) {
					val = obj;
				}
			});
		}
		return val;
	}

	public primaryFromRetain(customerOrderSubItems: Products[], filterBy) {
		let product: Products = {};
		let flag: boolean = false;
		customerOrderSubItems && customerOrderSubItems.forEach((prod) => {
			if (!flag && prod.componentType === filterBy) {
				flag = true;
				return product = prod;
			}
		});
		return product;
	}

	public getExistingProducts(custObj, filterBy): any {
		let val: any;
		if (custObj !== undefined) {
			custObj.forEach(obj => {
				if (obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER') {
					val = obj;
				}
			});
		}
		return val;
	}

	public maskTelephone(number: string) {
		if (number && number.indexOf('-') === -1) {
			return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
		}
		else if (number) {
			return number;
		}
	}

	public getYMDTStoMDY(datetimestamp) {
		return new DatePipe('en-US').transform(datetimestamp, 'M/dd/yyyy');
	}

	public shipAndHandlingChargesForSelfInstall(data, selectedInternetOfferdId?) {
		let offers = data;
		let shippingObj: any;
		let selectedshippingObj: any;
		if (offers && offers.payload && offers.payload.offers && (offers.payload.offers.length > 0)) {
			offers.payload.offers.forEach((offer) => {
				if (offer && (offer.serviceCategory === 'DATA')) {
					if (offer && offer.catalogs && (offer.catalogs.length > 0) && offer.catalogs[0].catalogItems && (offer.catalogs[0].catalogItems.length > 0)) {
						offer.catalogs[0].catalogItems.forEach((catalogItem) => {
							if (catalogItem && catalogItem.productOffer && catalogItem.productOffer.productComponents && (catalogItem.productOffer.productComponents.length > 0)) {
								catalogItem.productOffer.productComponents.forEach((prodComponent) => {
									prodComponent.product.quantity = 1;
									prodComponent.product.componentType = 'COMPONENT';
									if (prodComponent.product.productName === 'SHIPPING') {
										delete prodComponent.product.isRegulated;
										delete prodComponent.product.productCategoryDisplayName;
										delete prodComponent.product.productDisplayName;
										if (selectedInternetOfferdId && catalogItem.productOfferingId === selectedInternetOfferdId) {
											selectedshippingObj = prodComponent.product
										}
										shippingObj = prodComponent.product;
									}
								});
							}
						});
					}
				}
			});
		}
		if (selectedshippingObj) { return selectedshippingObj } else { return shippingObj };
	}

	public isUseOwnModem = (modem: any, isReEntrant): boolean => {
		let IsUseOwnModem = false;
		if (modem !== undefined && modem.productAttributes) {
			modem.productAttributes.forEach(item => {
				item.compositeAttribute.forEach(att => {
					if (att.attributeDisplayName === 'Use Own Modem' || att.attributeValue === 'Use Own Modem' || att.attributeValue === 'Use Your Modem') {
						IsUseOwnModem = true;
					}
					if (isReEntrant && att.attributeDisplayName === 'Use Own Modem' || att.attributeValue === 'Use Own Modem' || att.attributeValue === 'Use Your Modem' || (att.attributeName === 'allowSPSkipModemRules' && att.attributeValue === 'YES')) {
						IsUseOwnModem = true;
					}
				});
			});
		}
		return IsUseOwnModem;
	}

	public checkForSelfinstall = (subOrderItems: any, offerVariables: any) => {
		subOrderItems.forEach(subOrderItem => {
			if (subOrderItem.productName === "TECH INSTALL" && subOrderItem.productAttributes) {
				subOrderItem.productAttributes.forEach(attributes => {
					if (attributes.compositeAttribute) {
						attributes.compositeAttribute.forEach(item => {
							if (item.attributeName === "Service Level") {
								if (item.attributeDisplayName === GenericValues.selfInstall) {
									offerVariables.selfinstallSelected = true;
								} else {
									offerVariables.selfinstallSelected = false;
								}
							}
						});
					}
				});
			}
		});
	}

	public getOfferDisplayName(data, offerName) {
		let offerNameAndDisplayName = [];
		if (data && data.payload && data.payload.offers && (data.payload.offers.length > 0)) {
			data.payload.offers.forEach((offer) => {
				if (offer && offer.catalogs && (offer.catalogs.length > 0) && offer.catalogs[0].catalogItems && (offer.catalogs[0].catalogItems.length > 0)) {
					offer.catalogs[0].catalogItems.forEach((catalogItem) => {
						if (catalogItem && catalogItem.productOffer) {
							if (catalogItem.productOffer.offerName && catalogItem.productOffer.offerDisplayName) {
								offerNameAndDisplayName.push(
									{
										offerName: catalogItem.productOffer.offerName,
										offerDisplayName: catalogItem.productOffer.offerDisplayName
									}
								);
							}
						}
					});
				}
			});
		}
		let offerDisplayName: any;
		if (offerNameAndDisplayName && offerNameAndDisplayName.length > 0) {
			offerNameAndDisplayName.forEach((obj) => {
				if (obj.offerName === offerName) {
					offerDisplayName = obj.offerDisplayName;
				}
			});
		}
		if (!offerDisplayName) { return offerName; }
		return offerDisplayName;
	}

	public removeShippingDiscountFromCart(subOrderItem, copyOfDiscountsAdded) {
		let discountAdded: any = [];
		if (subOrderItem && subOrderItem.productAttributes && (subOrderItem.productAttributes.length > 0)) {
			subOrderItem.productAttributes.forEach((attr) => {
				if (attr.discounts && (attr.discounts.length > 0)) {
					attr.discounts.forEach(disc => {
						if (copyOfDiscountsAdded && (copyOfDiscountsAdded.length > 0)) {
							discountAdded = copyOfDiscountsAdded.filter(dis => dis.discountId !== disc.discountId);
						}
					});
				}
			});
		}
		return discountAdded;
	}

	public setVariableDefaults(offerVariables: OfferVariables) {
		offerVariables = {} as OfferVariables;
		offerVariables.isPrepaidAccountPage = false;
		offerVariables.existingOfferName = '';
		offerVariables.currentComponentName = '';
		offerVariables.addOfferExpired = false;
		offerVariables.hpSelected = false;
		offerVariables.loading = false;
		offerVariables.retrieveOffersLoading = false;
		offerVariables.byPassBool = false;
		offerVariables.hasTechnology = false;
		offerVariables.unFilterBool = false;
		offerVariables.AllspeedList = [];
		offerVariables.selectedTech = "na";
		offerVariables.bypassModemRulesBool = false;
		offerVariables.selfInstall = false;
		offerVariables.newTechInstall = false;
		offerVariables.isModemCompatible = true;
		offerVariables.modemExist = false;
		offerVariables.deviceSelected = true;
		offerVariables.selectedQuantity = "na";
		offerVariables.deviceMandatory = false;
		offerVariables.configSelected = [];
		offerVariables.reEntrant = false;
		offerVariables.loadedConfig = false;
		offerVariables.wireMaintainenceHide = true;
		offerVariables.isWireMaintainanceNoSelected = false;
		offerVariables.isExistingModemChanged = false;
		offerVariables.isWireMaintainanceYesSelected = false;
		offerVariables.wireMaintainance = false;
		offerVariables.easeExist = false;
		offerVariables.hpExisting = false;
		offerVariables.isExistingSpeedChanged = false;
		offerVariables.existingProductName = '';
		offerVariables.discountSelected = false;
		offerVariables.discArray = [];
		offerVariables.selectedOffer = [] as ProductOfferings;
		offerVariables.selfinstallSelected = false;
		offerVariables.techInstallExist = false;
		offerVariables.isRemoved = false;
		offerVariables.isDHPRemoved = false;
		offerVariables.isHPRemoved = false;
		offerVariables.isOptedOut = false;
		offerVariables.isPOTS = false;
		offerVariables.potsAddAction = false;
		offerVariables.retainValueForPotsJack = '';
		offerVariables.potsWireMainMandatory = false;
		offerVariables.voiceMail = false;
		// offerVariables.isVoiceMailYesSelected = false;
		offerVariables.voiceMailCondi = false;
		offerVariables.wireMaintainCondi = false;
		offerVariables.potsVoiceMailMandatory = false;
		offerVariables.holdCalled = false;
		offerVariables.shippingNHandlingCharge = 0;
		// offerVariables.isVoiceMailNoSelected = false;
		offerVariables.voiceMailPresent = false;
		offerVariables.wireMaintainPresent = false;
		offerVariables.portingCheck = false;
		offerVariables.potsJacksMandatory = false;
		offerVariables.isPortingCheckNoSelected = false;
		offerVariables.isPortingCheckYesSelected = false;
		offerVariables.changeAfterReEntrant = false;
		offerVariables.discountsAdded = [];;
		offerVariables.isInternational = false;
		offerVariables.jackErrorForPots = false;
		offerVariables.potsPortingMandatory = false;
		offerVariables.internetCheck = false;
		offerVariables.videoOffer = false;
		offerVariables.videoOfferTemp = false;
		offerVariables.phoneOffer = false;
		offerVariables.NIPendingStackAmend = false;
		offerVariables.internetAddAction = false;
		offerVariables.isAmend = false;
		offerVariables.videoSelected = 'NoTV';
		offerVariables.removedProductItem = [];
		offerVariables.isReEntrant = false;
		offerVariables.retentionDiscountsToCart = [];
		offerVariables.dhpExisting = false;
		offerVariables.dhpIntlCalled = false;
		offerVariables.dhpIntlSelected = 'No';
		offerVariables.dhpIntlExisting = '';
		offerVariables.isInternetRemoved = false;
		offerVariables.isStack = false;
		offerVariables.retainValueForHSIJack = '';
		offerVariables.displayOffer = {};
		offerVariables.check = false;
		offerVariables.modemDropDown = false;
		offerVariables.hideShippingDiscount = false;
		offerVariables.onlyDHPRemoved = false;
		offerVariables.e911Called = false;
		offerVariables.cartObjectChanged = false;
		offerVariables.discloserPopUpSelected = '';
		offerVariables.discountsAdded = [];
		offerVariables.selectedValues = '';
		offerVariables.displayExistingCartOffer = '';
		offerVariables.existingPriceKey = '';
		offerVariables.existingDiscountId = false;
		offerVariables.internetData = '';
		offerVariables.enablechangetab = false;
		offerVariables.lifelineDHPExisting = false;
		offerVariables.lifelinePOTSExisting = false;
		offerVariables.lifelineHSIExisting = false;
		offerVariables.exisitngData = false;
		offerVariables.removal = {};
		offerVariables.currentSpeed = {};
		offerVariables.dropName = "All Speed options";
		offerVariables.filterObj = {
			name: "All Speed options",
			isExist: true
		};
		offerVariables.undoFlag = false;
		offerVariables.isOptedOut = false;
		offerVariables.optedOutCheck = false;
		offerVariables.internetCheck = false;
		offerVariables.internetAvail = false;
		offerVariables.videoAvail = false;
		offerVariables.phoneAvail = false;
		offerVariables.internetOffer = false;
		offerVariables.videoOffer = false;
		offerVariables.phoneOffer = false;
		offerVariables.modemMakeModelCheck = false;
		offerVariables.serviceSpec = [];
		offerVariables.videoSelected = '';
		offerVariables.processInstanceId = '';
		offerVariables.taskId = '';
		offerVariables.taskName = '';
		offerVariables.offersGenerated = false;
		offerVariables.offerResponse = {} as Product;
		offerVariables.discountedPrice = 0;
		offerVariables.discountedInternetOtcPrice = 0;
		offerVariables.actualInternetOtcPrice = 0;
		offerVariables.actualPrice = 0;
		offerVariables.actualTVPrice = 0;
		offerVariables.discountedTVPrice = 0;
		offerVariables.actualTVOtcPrice = 0;
		offerVariables.discountedTVOtcPrice = 0;
		offerVariables.selectedInternetOfferdId = '';
		offerVariables.selectedPhoneOfferdId = '';
		offerVariables.selectedVideoOfferdId = '';
		offerVariables.selectedDHPOfferdId = '';
		offerVariables.serviceUnavailable = '';
		offerVariables.directvAccountId = [];
		offerVariables.modemValues = {};
		offerVariables.easeValues = {};
		offerVariables.secureWifiValues = {};
		offerVariables.jackValues = {};
		offerVariables.jackValuesForPots = {};
		offerVariables.installationValues = {};
		offerVariables.productPriceValues = [];
		offerVariables.matchingOffers = [];
		offerVariables.selectedGroup = {};
		offerVariables.internerOffer = [];
		offerVariables.videorOffer = [];
		offerVariables.phoneOfferData = [];
		offerVariables.dhpOffer = [];
		offerVariables.speedList = [];
		offerVariables.tvList = [];
		offerVariables.selectedSpeed = '';
		offerVariables.selectedTV = '';
		offerVariables.selectedHP = '';
		offerVariables.selectedJack = undefined;
		offerVariables.selectedJackForPots = undefined;
		offerVariables.intraStateFee = {} as Products;
		offerVariables.discountedPriceList = [];
		offerVariables.totalDiscountAmount = {};
		offerVariables.maxWSTB = [];
		offerVariables.maxTSTB = [];
		offerVariables.warningMsg = '';
		offerVariables.cartObject = {};
		offerVariables.stb = {};
		offerVariables.hdPrice = 0;
		offerVariables.dvrPrice = 0;
		offerVariables.selectedInternetOfferPrice = 0;
		offerVariables.selectedVideoOfferPrice = 0;
		offerVariables.selectedDHPOfferPrice = 0;
		offerVariables.selectedPhoneOfferPrice = 0;
		offerVariables.selected = '';
		offerVariables.errorMsg = '';
		offerVariables.isShowRemoveRetentionDiscountMsg = false;
		offerVariables.existingDiscounts = {};
		offerVariables.hsiRemovedRetentiondiscounts = [];
		offerVariables.existingRetentionDiscounts = [];
		offerVariables.dataLink = {} as ServiceCategoryBasedOffers;
		offerVariables.videoLink = {} as ServiceCategoryBasedOffers;
		offerVariables.dtvLink = {} as ServiceCategoryBasedOffers;
		offerVariables.dhpLink = {} as ServiceCategoryBasedOffers;
		offerVariables.phoneLink = {} as ServiceCategoryBasedOffers;
		offerVariables.attrCombinations = {};
		offerVariables.noPrice = {};
		offerVariables.apiResponseError = {} as APIErrorLists;
		offerVariables.catalogSpecId = '';
		offerVariables.callingFeatures = {};
		offerVariables.dhpOfferPriceDiscountedOtc = 0;
		offerVariables.dhpOfferPriceDiscountedRc = 0;
		offerVariables.includedCallingFeatures = [];
		offerVariables.e911ValidatedAddress = [];
		offerVariables.phoneArray = [];
		offerVariables.videoArray = [];
		offerVariables.retentionDiscountsToCart = [];
		offerVariables.initialOfferResponse = [];
		offerVariables.removeMessage = [];
		offerVariables.productToRemove = [];
		offerVariables.moreServices = [];
		offerVariables.removeResponse = [];
		offerVariables.removedProductItem = [];
		offerVariables.preserveHSI = [];
		offerVariables.removeSelectedReason = [];
		offerVariables.serviceTerminationInfo = [];
		offerVariables.enabledServiceList = [];
		offerVariables.wireMaintainanceExist = false;
		offerVariables.cartContractTerm = '';
		offerVariables.cartContractTermDHP = '';
		offerVariables.cartContractTermDTV = '';
		offerVariables.dtvExisting = false;
		offerVariables.existingAddonsHSI = [];
		offerVariables.selectedModemToShow = {};
		offerVariables.maintainancePrice = 0;
		offerVariables.ban = [];
		offerVariables.internationalDialing = {};
		offerVariables.internationalPrice = 0;
		offerVariables.isDHP = false;
		offerVariables.hsiOnlyPresent = false;
		offerVariables.disconnectReq = {};
		offerVariables.hsiExisting = false;
		offerVariables.dhpIntlCalled = false;
		offerVariables.dhpIntlSelected = 'NO';
		offerVariables.dhpIntlExisting = '';
		offerVariables.check = false;
		offerVariables.isReEntrant = false;
		offerVariables.portingCheck = false;
		offerVariables.dtvCatalogId = '';
		offerVariables.installError = false;
		offerVariables.modemError = false;
		offerVariables.easeError = false;
		offerVariables.secureWifiError = false;
		offerVariables.jackError = false;
		offerVariables.configSubmited = false;
		offerVariables.retainedPotsBooleans = undefined;
		offerVariables.cartCopyObject = {};
		offerVariables.isE911Called = false;
		offerVariables.reentrantUI = false;
		offerVariables.offerNoLongerAvailable = '';
		offerVariables.depositHistory = [];
		offerVariables.calledFromConstructor = false;
		offerVariables.deviceQuantitySelected = [];
		offerVariables.holdCalled = false;
		offerVariables.holdedObjects = [];
		offerVariables.isCustomize = false;
		offerVariables.selectedVoiceMail = [];
		offerVariables.voiceMailPrice = 0;
		offerVariables.firstName = '';
		offerVariables.lastName = '';
		offerVariables.ensembleId = '';
		offerVariables.agentCuid = '';
		offerVariables.offerName = '';
		offerVariables.retainValueForPotsJack = '';
		offerVariables.retainValueForHSIJack = '';
		offerVariables.fromHold = false;
		offerVariables.changeAfterReEntrant = false;
		offerVariables.EaseDefault = false;
		offerVariables.secureWifiDefault = false;
		offerVariables.JacksWireDefault = false;
		offerVariables.modemMake = '';
		offerVariables.modemModel = '';
		offerVariables.modemClass = '';
		offerVariables.showHoverMessage = false;
		offerVariables.isDtvOpus = false;
		offerVariables.newInternetCheck = null;
		offerVariables.newPhoneSelected = '';
		offerVariables.newPhoneUpdated = false;
		offerVariables.newVideoSelected = '';
		offerVariables.isSalesExpiredMessageNeedtoHide = false;
		offerVariables.isSpeedSalesExpired = false;
		offerVariables.speedselected = '';
		offerVariables.isBundleSalesExpired = false;
		offerVariables.qualifiedFilter = [];
		offerVariables.offersByFilters = {} as OffersByFilters;
		offerVariables.qualifiedUnfilter = [];
		offerVariables.unQualifiedOffers = [];
		offerVariables.isProfileBypassLoopQual = false;
		offerVariables.isProfileBypassModemCheck = false;
		offerVariables.isProfileBypassHSISpeeds = false;
		offerVariables.disclosuresData = [];
		offerVariables.rccDisclosureDetails = [];
		offerVariables.rccDisclosureErrorMessage = [];
		offerVariables.disclosureArrList = [];
		offerVariables.selfInstallOffers = [];
		offerVariables.existingModemOffers = [];
		offerVariables.recomTechInstall = {};
		offerVariables.existingModem = undefined;
		offerVariables.recommendedError = '';
		offerVariables.e911Validation = ''
		offerVariables.reEntrantLoaded = false;
		offerVariables.oneTimeLoading = false;
		offerVariables.potsVoiceMailMandatory = false;
		offerVariables.potsWireMainMandatory = false;
		offerVariables.potsJacksMandatory = false;
		offerVariables.potsPortingMandatory = false;
		offerVariables.portingValue = '';
		offerVariables.wireMaintainanceValue = 'na';
		offerVariables.voiceMailValue = 'na';
		offerVariables.isDisclosureAllowed = true;
		offerVariables.undoSelected = false;
		offerVariables.cartOrderItems = {};
		offerVariables.newVideoUpdated = false;
		offerVariables.shippingNHandlingCharge = 0;
		offerVariables.isHSIExistingProduct = false;
		offerVariables.isRecommendationSuccess = false;
		offerVariables.recommendedObject = {};
		offerVariables.recommendedObj = {};
		offerVariables.recommendationFailure = false;
		offerVariables.copyOfDiscountsAdded = {};
		offerVariables.hideShippingDiscount = false;
		offerVariables.addDhpfromRecommendation = false;
		offerVariables.holdeisCustomizeObjects = false;
		offerVariables.offerBillingType = '';
		offerVariables.disableEase = false;
		offerVariables.canDisplayCS = true;
		offerVariables.isExpiredDiscounts = 0;
		offerVariables.cartData = {};
		offerVariables.nonCartItemsNotChanged = false;
		offerVariables.custData = {};
		offerVariables.existingTN = '';
		offerVariables.isExtendedAreaCallingPresent = false;
		offerVariables.isOffer1PtyResLineSelected = false;
		offerVariables.isExtendedAreaCallingYESSelected = false;
		offerVariables.isExtendedAreaCallingNASelected = true;
		offerVariables.selectedExtendedAreaCalling = undefined;
		offerVariables.extendedAreaCallingPrice = 0;
		offerVariables.isExtendedAreaCallingExits = false;
		offerVariables.isLatestPendingOrderNI = false;
		offerVariables.noWorkNeed = false;
		offerVariables.existingBillingType = '';
		offerVariables.billingTypeChanged = false;
		offerVariables.existingServicesForAction = undefined;
		offerVariables.hsiCatalogId = '';
		offerVariables.isRemovePhone = true;
		offerVariables.reqDeposit = false;
		offerVariables.amendForHSI = false;
		return offerVariables;
	}

	public setReentrantFlags(offerVariables: OfferVariables) {
		let user = <Observable<User>>this.store.select('user');
		let currentUser: User;
		let profileFlags = {} as ProfileFlags;
		let userSubscription = user.subscribe((data) => {
			currentUser = cloneDeep(data);
			profileFlags.byPassLoopQualFlag = offerVariables.byPassBool;
			profileFlags.removeFilteringFlag = offerVariables.unFilterBool;
			profileFlags.selectedTechnologyType = offerVariables.selectedTech;
			currentUser.profileFlags = profileFlags;
		});
		this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
		if (userSubscription) { userSubscription.unsubscribe(); }
	}

	public getReentrantFlags(offerVariables: OfferVariables) {
		let user = <Observable<User>>this.store.select('user');
		let userSubscription = user.subscribe((data) => {
			if (data && data.profileFlags) {
				if (data.profileFlags.removeFilteringFlag) {
					offerVariables.unFilterBool = data.profileFlags.removeFilteringFlag;
				}
				if (data.profileFlags.byPassLoopQualFlag) {
					offerVariables.byPassBool = data.profileFlags.byPassLoopQualFlag;
				}
				if (data.profileFlags.selectedTechnologyType) {
					if (data.profileFlags.selectedTechnologyType === "na") {
						offerVariables.hasTechnology = true;
					}
					else {
						offerVariables.selectedTech = data.profileFlags.selectedTechnologyType;
						offerVariables.hasTechnology = false;
					}
				}
			}
		});
		if (userSubscription) { userSubscription.unsubscribe(); }
	}

	/**
	 * Filter each product by Type from Offer Object
	 */
	public filterProductByType(
		offerVariables: OfferVariables,
		data: ProductOfferings,
		type: string,
		existingSpeed?: boolean,
		custSubObj?: CustomerOrderSubItem,
		isModem?): OfferProductComponents {
		let modem: OfferProductComponents;
		data.productOffer.productComponents
			.forEach((item) => {
				if (item.product.productName === type) {
					let values: AttributesCombination[] = [];
					if (item && item.product && item.product.productAttributes !== null && item.product.productAttributes
						&& item.product.productAttributes.length > 0) {
						item.product.productAttributes.forEach(val => {
							let price: Prices[] = [];
							let value: AttributesCombination;
							if (val.isPriceable) {
								let noDisplay = false;
								let comp: CompositeAttribute[] = [];
								val.compositeAttribute.forEach(attr => {
									if (attr.attributeValue === 'Self Install') {
										offerVariables.selfInstall = true;
									}
									if (attr.attributeName === 'Account Type') {
										comp.push(attr);
										if (attr.attributeDisplayName === 'NODISPLAY') {
											noDisplay = true;
										}
									} else if (attr.attributeName === 'Installation Number' && attr.attributeDisplayName === 'No work is needed') {
										offerVariables.noWorkNeed = true;
									}
								});
								if (!noDisplay) {
									val.compositeAttribute.forEach(attr => {
										if (attr.attributeName !== 'Account Type') {
											comp.push(attr);
										}
									});
									val = Object.assign({},
										val, {
										compositeAttribute: comp
									}
									);
									val.prices.forEach(v => {
										if (v.priceType === GenericValues.pPriceType) {
											value = val;
											price.push(v);
										}
									});
									if (!value && val.compositeAttribute && val.compositeAttribute[0] &&
										val.compositeAttribute[0].attributeName === 'allowSPSkipModemRules') {
										value = val;
									}
									value && value.prices.forEach(v => {
										if (v.priceType !== GenericValues.pPriceType) {
											price.push(v);
										}
									});
									value = Object.assign({},
										value, {
										prices: price
									}
									)
									values.push(value);
								}
							} else if (isModem && type === 'MODEM') {
								values.push(val);
							} else if (type === GenericValues.secureWifiComponent) {
								if (val && val.compositeAttribute[0] && val.compositeAttribute[0].attributeName && val.compositeAttribute[0].attributeValue) {
									if (val.compositeAttribute[0].attributeName === "Service Level" && val.compositeAttribute[0].attributeValue.toLowerCase() === 'no') {
										values.push(val);
									}
								}
							}
							else {
								val.compositeAttribute.forEach(attr => {
									if (attr.attributeName === 'TechInstallRecommended') {
										offerVariables.recommendedTech = val;
									}
								});
							}
						});
					} else if (!existingSpeed) {
						custSubObj && custSubObj.productAttributes ? values = custSubObj.productAttributes : values = [];
					}
					let cloneItem = cloneDeep(item);
					cloneItem.product = Object.assign({},
						cloneItem.product, {
						productAttributes: values
					}
					)
					let product = {
						productId: cloneItem.product.productId,
						productName: cloneItem.product.productName,
						productDisplayName: cloneItem.product.productDisplayName,
						productType: cloneItem.product.productType,
						componentType: cloneItem.componentType,
						productAttributes: cloneItem.product.productAttributes,
						productAssociations: cloneItem.product.productAssociations,
						productCategory: cloneItem.product.productCategory,
						quantity: cloneItem.product.quantity
					};
					modem = cloneItem;
					modem = Object.assign({},
						modem, {
						product: product
					}
					)
				}
			});
		return modem;
	}

	public isExistsInOffer(data, type1, type2?) {
		let val = false;
		if (data && data.payload && data.payload.offers && (data.payload.offers.length > 0)) {
			data.payload.offers.forEach((offer) => {
				if (offer && offer.catalogs && (offer.catalogs.length > 0) && offer.catalogs[0].catalogItems && (offer.catalogs[0].catalogItems.length > 0)) {
					offer.catalogs[0].catalogItems.forEach((catalogItem) => {
						if (catalogItem && catalogItem.productOffer && (catalogItem.productOffer.offerCategory === type1)) {
							val = true;
						}
						if (type2 && catalogItem && catalogItem.productOffer && (catalogItem.productOffer.offerCategory === type2)) {
							val = true;
						}
					});
				}
			});
		}
		return val;
	}

	public checkExistingSubOffers(offerVariables: OfferVariables, existingProduct, currentProduct, type, filter, subType) {
		let subOrderItem;
		if (existingProduct !== undefined && currentProduct !== undefined) {
			if (type === 'internet') {
				let oldPrice = 0, newPrice = 0;
				if (subType === GenericValues.install) {
					if (offerVariables.selectedInstallation !== undefined && offerVariables.selectedInstallation.productAttributes !== undefined && subType === GenericValues.install) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'TECH INSTALL');
						if (subOrderItem !== undefined && offerVariables.selectedInstallation !== undefined && offerVariables.selectedInstallation.productAttributes !== undefined) {
							if (offerVariables.selectedInstallation.productAttributes.length === 0) { return 'CHANGE'; }
							if (offerVariables.selectedInstallation.productAttributes.length > 0 && offerVariables.selectedInstallation.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
								return 'CHANGE';
							}
							if ((offerVariables.flow !== 'stackAmend' || (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType !== 'PREPAID')) &&
								offerVariables.newTechInstall) {
								return 'ADD';
							}
						} else if (subOrderItem === undefined && offerVariables.selectedInstallation !== undefined) {
							return 'ADD';
						} else if (subOrderItem !== undefined && offerVariables.selectedInstallation === undefined) {
							return 'REMOVE';
						}
					}
					if (filter === 'stackAmend') {
						({ newPrice, oldPrice } = this.priceComparison(offerVariables.selectedInstallation, newPrice, subOrderItem, oldPrice));
						if (oldPrice !== newPrice) {
							return 'ADD';
						}
					}
				}
				if (subType === GenericValues.modem) {
					subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'MODEM');
					if (subOrderItem !== undefined && offerVariables.selectedModem !== undefined && offerVariables.selectedModem.productAttributes !== undefined) {
						if (offerVariables.selectedModem.productAttributes.length === 0) { return 'CHANGE'; }
						if (offerVariables.selectedModem.productAttributes.length > 0 && offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
							return 'CHANGE';
						}
					} else if (subOrderItem === undefined && offerVariables.selectedModem !== undefined) {
						return 'ADD';
					} else if (subOrderItem !== undefined && offerVariables.selectedModem === undefined) {
						return 'REMOVE';
					}
					oldPrice = 0, newPrice = 0;
					if (filter === 'stackAmend') {
						({ newPrice, oldPrice } = this.priceComparison(offerVariables.selectedModem, newPrice, subOrderItem, oldPrice));
						if (oldPrice !== newPrice) {
							return 'ADD';
						}
					}
				}
				if (subType === GenericValues.ease) {
					subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'CENTURYLINK @ EASE');
					if (offerVariables.selectedEase !== undefined && offerVariables.selectedEase.productAttributes !== undefined && subOrderItem !== undefined) {
						if (offerVariables.selectedEase.productAttributes.length === 0) { return 'CHANGE'; }
						if (offerVariables.selectedEase.productAttributes.length > 0 && offerVariables.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
							return 'CHANGE';
						}
					} else if (subOrderItem === undefined && offerVariables.selectedEase !== undefined) {
						return 'ADD';
					} else if (subOrderItem !== undefined && offerVariables.selectedEase === undefined) {
						return 'REMOVE';
					}
				}
				if (subType === GenericValues.secureWifiComponent) {
					subOrderItem = this.findCustomerSubOrderObject(existingProduct, GenericValues.secureWifiComponent);
					if (subOrderItem === undefined && offerVariables.selectedSecureWifi !== undefined) {
						return 'ADD';
					} else if (subOrderItem !== undefined && (offerVariables.selectedSecureWifi === undefined || offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute.filter(attr => (attr.attributeName === GenericValues.serviceLevel && attr.attributeValue.toLowerCase() === 'no')).length > 0)) {
						return 'REMOVE';
					}
				}
				if (subType === GenericValues.shipping) {
					subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'SHIPPING');
					if (offerVariables.shippingNHandlingChargeObj !== undefined && offerVariables.shippingNHandlingChargeObj.productAttributes !== undefined && subOrderItem !== undefined) {
						if (offerVariables.shippingNHandlingChargeObj.productAttributes.length === 0) { return 'CHANGE'; }
						if (offerVariables.shippingNHandlingChargeObj.productAttributes.length > 0 && offerVariables.shippingNHandlingChargeObj.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
							return 'CHANGE';
						}
					} else if (subOrderItem === undefined && offerVariables.shippingNHandlingChargeObj !== undefined) {
						return 'ADD';
					} else if (subOrderItem !== undefined && offerVariables.shippingNHandlingChargeObj === undefined) {
						return 'REMOVE';
					}
				}
				if (subType === GenericValues.jack) {
					subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'Jack and Wire');
					if (subOrderItem !== undefined && offerVariables.selectedJack !== undefined && offerVariables.selectedJack.productAttributes !== undefined) {
						if (offerVariables.selectedJack.productAttributes.length === 0) { return 'CHANGE'; }
						if (offerVariables.selectedJack.productAttributes.length > 0 && offerVariables.selectedJack.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase()) {
							return 'CHANGE';
						}
					} else if (subOrderItem === undefined && offerVariables.selectedJack !== undefined) {
						return 'ADD';
					} else if (subOrderItem !== undefined && offerVariables.selectedJack === undefined) {
						return 'REMOVE';
					}
				}
			}
		}
		return 'NOCHANGE';
	}

	private priceComparison(product: Products, newPrice: number, subOrderItem: any, oldPrice: number) {
		product && product.productAttributes && product.productAttributes[0]
			&& product.productAttributes[0].prices && product.productAttributes[0].prices.forEach(price => {
				if (price && price.priceType === GenericValues.pPriceType) {
					newPrice = this.populateValues(price);
				}
			});
		subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes[0]
			&& subOrderItem.productAttributes[0].prices && subOrderItem.productAttributes[0].prices.forEach(price => {
				if (price && price.priceType === GenericValues.pPriceType) {
					oldPrice = this.populateValues(price);
				}
			});
		return { newPrice, oldPrice };
	}

	public checkExistingOfferingId(offerVariables: OfferVariables, existingProduct, currentProduct, type, filter, value?) {
		let subOrderItem;
		let val = 'CHANGE';
		offerVariables.undoChanges = true;
		if (existingProduct !== undefined && currentProduct !== undefined) {
			if (type === 'internet' && existingProduct !== undefined && currentProduct !== undefined) {
				if (existingProduct.productOfferingId !== currentProduct.productOfferingId) {
					offerVariables.undoChanges = true;
					val = 'CHANGE';
				} else { val = 'NOCHANGE'; }
			} else if (existingProduct.productOfferingId !== currentProduct.productOfferingId) {
				offerVariables.undoChanges = true;
				return 'CHANGE';
			} else if (type === 'dhp' && existingProduct.productOfferingId === currentProduct.productOfferingId) {
				offerVariables.undoChanges = true;
				return 'NOCHANGE';
			}
			if (val !== 'CHANGE' && !value) {
				offerVariables.undoChanges = false;
				if (type === 'internet') {
					if (offerVariables.selectedModem !== undefined && offerVariables.selectedModem.productAttributes !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'MODEM');
						subOrderItem.productAttributes[0] = this.updateModemAttrValue(subOrderItem.productAttributes[0], GenericValues.leaseWithCsAttrVAlue);
						if (subOrderItem !== undefined && offerVariables.selectedModem.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem !== undefined && offerVariables.selectedModem.action && offerVariables.selectedModem.action === 'REMOVE') {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
					}
					else if (offerVariables.selectedModem === undefined && offerVariables.modemExist && !offerVariables.isModemCompatible) {
						offerVariables.undoChanges = true;
						return 'CHANGE';
					}
					if (offerVariables.selectedEase !== undefined && offerVariables.selectedEase.productAttributes !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'CENTURYLINK @ EASE');
						if (subOrderItem !== undefined && offerVariables.selectedEase.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem !== undefined && offerVariables.selectedEase.action && offerVariables.selectedEase.action === 'REMOVE') {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
					}
					else if (offerVariables.selectedEase === undefined && offerVariables.easeExist) {
						offerVariables.undoChanges = true;
						return 'CHANGE';
					}
					if (offerVariables.selectedSecureWifi !== undefined && offerVariables.selectedSecureWifi.productAttributes !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, GenericValues.secureWifiComponent);
						if (subOrderItem !== undefined && offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem !== undefined && offerVariables.selectedSecureWifi.action && offerVariables.selectedSecureWifi.action === 'REMOVE') {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
					}
					else if (offerVariables.selectedSecureWifi === undefined && offerVariables.secureWifiExist) {
						offerVariables.undoChanges = true;
						return 'CHANGE';
					}
					if (offerVariables.selectedJack !== undefined && offerVariables.selectedJack.productAttributes !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'Jack and Wire');
						if (subOrderItem !== undefined && offerVariables.selectedJack
							&& offerVariables.selectedJack.productAttributes && offerVariables.selectedJack.productAttributes[0] && offerVariables.selectedJack.productAttributes[0].compositeAttribute
							&& offerVariables.selectedJack.productAttributes[0].compositeAttribute[0]
							&& offerVariables.selectedJack.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
						else if (subOrderItem !== undefined && offerVariables.selectedJack.action && offerVariables.selectedJack.action === 'REMOVE') {
							offerVariables.undoChanges = true;
							return 'CHANGE';
						}
					}
					else if (offerVariables.selectedJack === undefined && offerVariables.jackExist) {
						offerVariables.undoChanges = true;
						return 'CHANGE';
					}
				}
				if (type === 'prism' && filter !== undefined) {
					if ((filter === 'selectedSTB' || filter === 'any-filter') && offerVariables.selectedSTB !== null && offerVariables.selectedSTB !== undefined && offerVariables.selectedSTB.productAttributes[0] !== undefined && offerVariables.selectedSTB.productAttributes[0].compositeAttribute[0] !== undefined) {

						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'Prism WSTB Surcharge');

						if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && offerVariables.selectedSTB.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue && offerVariables.selectedSTB.productAttributes[0].compositeAttribute[1].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[1].attributeValue) {
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							return 'CHANGE';
						}
					}
					if ((filter === 'hdService' || filter === 'any-filter') && offerVariables.hdService !== null && offerVariables.hdService !== undefined && offerVariables.hdService.productAttributes[0] !== undefined && offerVariables.hdService.productAttributes[0].compositeAttribute[0] !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'HD Service');
						if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && offerVariables.hdService.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							return 'CHANGE';
						}
					}
					if ((filter === 'dvrService' || filter === 'any-filter') && offerVariables.dvrService !== null && offerVariables.dvrService !== undefined && offerVariables.dvrService.productAttributes[0] !== undefined && offerVariables.dvrService.productAttributes[0].compositeAttribute[0] !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'DVR Service');
						if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && offerVariables.dvrService.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							return 'CHANGE';
						}
					}
					if ((filter === 'wiredSTB' || filter === 'any-filter') && offerVariables.wiredSTB !== null && offerVariables.wiredSTB !== undefined && offerVariables.wiredSTB.productAttributes[0] !== undefined && offerVariables.wiredSTB.productAttributes[0].compositeAttribute[0] !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'Wired Set Top Box');
						if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && offerVariables.wiredSTB.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							return 'CHANGE';
						}
					}
					if ((filter === 'wirelessSTB' || filter === 'any-filter') && offerVariables.wirelessSTB !== null && offerVariables.wirelessSTB !== undefined && offerVariables.wirelessSTB.productAttributes[0] !== undefined && offerVariables.wirelessSTB.productAttributes[0].compositeAttribute[0] !== undefined) {
						subOrderItem = this.findCustomerSubOrderObject(existingProduct, 'Wireless Set Top Box');
						if (subOrderItem !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem.productAttributes[0].compositeAttribute[0] !== null && subOrderItem !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && subOrderItem.productAttributes[0].compositeAttribute[0] !== undefined && offerVariables.wirelessSTB.productAttributes[0].compositeAttribute[0].attributeValue !== subOrderItem.productAttributes[0].compositeAttribute[0].attributeValue) {
							return 'CHANGE';
						}
						else if (subOrderItem === undefined) {
							return 'CHANGE';
						}
					}
				}
				if (type === 'dhp') {
					if (offerVariables.selectedMaintainance !== undefined && offerVariables.selectedMaintainance.productAttributes !== undefined && offerVariables.wireMaintainance) {
						offerVariables.undoChanges = true;
						return 'CHANGE';
					}
				}
			} else if (val === 'CHANGE') {
				return val;
			}
			return 'NOCHANGE';
		}

	}

	public addincludedCallingFeatures(offerVariables: OfferVariables, productComponents, type, flag) {
		let callingFeatures = [];
		if (!offerVariables.hpExisting || (offerVariables.hpOfferType !== 'P4L' && offerVariables.phoneSelected === 'HMP' && offerVariables.selectedHPOffer && offerVariables.selectedHPOffer.productOffer.offerType === 'P4L')) {
			this.store.dispatch({ type: 'INCLUDING_FEATURE', payload: productComponents });
		}
		productComponents.forEach((item) => {
			if ((item && item.componentType === type && flag && item.displayOrder !== 0 && item.isDefault !== 0 && item.additionalUiAttrProduct &&
				item.additionalUiAttrProduct.includedFlag && item.additionalUiAttrProduct.includedFlag.toLowerCase() === 'yes') ||
				(item.componentType === type && !flag && item.isDefault !== 0 && item.displayOrder !== 0 && item.product.productCategory === 'VAS')) {
				callingFeatures.push(item.product.productDisplayName);
			}
		});
		return callingFeatures;
	}

	public fetchExistingProducts(offerVariables: OfferVariables, services, flag?) {
		offerVariables.existingProductContract = services[0].contractTerm;
		offerVariables.existingProductName = '';
		if (services !== undefined) {
			services.forEach((item) => {
				if (item !== undefined && item.existingServiceSubItems !== undefined) {
					item.existingServiceSubItems.forEach((subItem) => {
						if (subItem.componentType === 'PRIMARY') {
							offerVariables.existingProductName += subItem.productName + ' ';
						}
					});
				}
				if (item && item.existingServiceSubItems === undefined && item !== undefined && item.customerOrderSubItems !== undefined) {
					item.customerOrderSubItems.forEach((subItem) => {
						if (subItem.componentType === 'PRIMARY') {
							offerVariables.existingProductName += subItem.productName + ' ';
						}
					});
				}
			});
		}
		flag && offerVariables.existingObjects && offerVariables.existingObjects.existingProductsAndServices && offerVariables.existingObjects.existingProductsAndServices.forEach((item) => {
			item && item.productConfiguration && item.productConfiguration.forEach((data) => {
				if (data && data.productType === GenericValues.iData) {
					data.configItems && data.configItems.forEach((config) => {
						config && config.configDetails && config.configDetails.forEach((details) => {
							if (details && details.formName === 'Devices') {
								details.formItems && details.formItems.forEach((items) => {
									if (items && items.attributeName === 'Quantity') {
										if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
											offerVariables.selectedQuantity = items.attributeValue[0].value;
											offerVariables.deviceSelected = true;
										}
									}
								});
							}
						});
					});
				}
			});
		});
	}

	public defaultDiscounSelected(offerVariables: OfferVariables) {
		offerVariables.discountSelected = true;
		offerVariables.discArray && offerVariables.discArray.forEach(dis => {
			dis.selected = false;
		});
	}

	public checkDiscountSelected(offerVariables: OfferVariables) {
		offerVariables.discountSelected = false;
		offerVariables.discArray.forEach(disc => {
			if (!disc.selected) {
				offerVariables.discountSelected = true;
				offerVariables.hideDisplayDiscounts = false;
			}
		});
	}

	public serviceTerminate(offerVariables) {
		this.store.dispatch({ type: 'REMOVAL_REASON', payload: offerVariables.removeSelectedReason });
		for (let i = 0; i < offerVariables.removedProductItem.length; i++) {
			let addRemoveToAllSubItems = [];
			if (offerVariables.removedProductItem[i].existingServiceSubItems && offerVariables.removedProductItem[i].existingServiceSubItems.length) {
				offerVariables.removedProductItem[i].existingServiceSubItems.forEach(item => {
					if (item && item.action) { item.action = 'REMOVE'; }
					addRemoveToAllSubItems.push(item);
				});
			} else if (offerVariables.removedProductItem[i].customerOrderSubItems && offerVariables.removedProductItem[i].customerOrderSubItems.length) {
				offerVariables.removedProductItem[i].customerOrderSubItems.forEach(item => {
					if (item && item.action) { item.action = 'REMOVE'; }
					addRemoveToAllSubItems.push(item);
				});
			}
			offerVariables.undoChanges = true;
			offerVariables.removedProductItem[i].customerOrderSubItems = addRemoveToAllSubItems;
		}
		if (offerVariables.removedProductItem && offerVariables.removedProductItem[0]
			&& offerVariables.removedProductItem[0].offerCategory && offerVariables.flow !== 'MOVE') {
			offerVariables.serviceTerminationInfo = [{
				"serviceCategory": null,
				"offerCategory": offerVariables.removedProductItem[0].offerCategory,
				"product": null,
				"reasonList": {
					"reasonType": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.rsnType,
					"reason": [
						{
							"code": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.rsnCode,
							"description": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.chgDesc,
							"waiverFlag": "No",
							"reasonType": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.rsnType,
							"reasonText": null,
							"offerCategory": offerVariables.removedProductItem[0].offerCategory,
							"terminationFee": "0",
							"currencyCode": "USD"
						}
					]
				}
			}]
		}
		if (offerVariables.removedProductItem && offerVariables.removedProductItem[0] &&
			offerVariables.removedProductItem[0].offerCategory && offerVariables.flow === 'MOVE') {
			offerVariables.serviceTerminationInfo = [{

				"offerCategory": offerVariables.removedProductItem[0].offerCategory,

				"reasonList": [
					{
						"code": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.rsnCode,
						"description": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.chgDesc,
						"waiverFlag": "No",
						"reasonType": offerVariables.removeSelectedReason && offerVariables.removeSelectedReason.rsnType,
						"reasonText": null,
						"offerCategory": offerVariables.removedProductItem[0].offerCategory,
						"terminationFee": "0",
						"currencyCode": "USD"
					}]


			}]
		}
	}

	public checkPOTSAction(product, offerVariables) {
		if (product.indexOf('Wire Maintenance Plan') !== -1 && offerVariables.wireMaintainance) {
			if (offerVariables.wireMaintainCondi) { return 'NOCHANGE' } else { return 'ADD'; }
		}
		return 'NOCHANGE';
	}
	/* TEMPORARY */
	/* TEMPORARY */
	/* Try to Merge cartRequest for all flows */
	/* TEMPORARY */
	/* TEMPORARY */
	public shoppingCartRequest(offerVariables: OfferVariables) {
		this.defaultDiscounSelected(offerVariables);
		let orderItems: Products[] = [];
		let orderItemstoSend: CustomerOrderItems[] = [];
		offerVariables.discountedPriceList = [];
		let subOrderItems: Products[] = [];
		let subOrderItemsForCart: Products[] = [];
		let subOrderItemstoSend: Products[] = [];
		let subOrderItem: Products;
		let subOrderItemClone: Products;
		let orderItem: CustomerOrderItems;
		let install: boolean = false;
		let modem: boolean = false;
		let securityProduct: boolean = false;
		let ease: boolean = false;
		let jack: boolean = false;
		let internetExist = false;
		let prismExist = false;
		let dhpExist = false;
		let hpExist = false;
		let dtvExist = false;
		let internetProduct: CustomerOrderItems = {};
		let prismProduct: CustomerOrderItems = {};
		let dhpProduct: CustomerOrderItems = {};
		let isActionAddForAmend: boolean;
		isActionAddForAmend = (offerVariables.isLatestPendingOrderNI || offerVariables.internetAddAction) && offerVariables.isAmend;
		let custObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
		let user = <Observable<User>>this.store.select('user');
		if (!offerVariables.existingServices) {
			let customize = <Observable<any>>this.store.select('customize');
			customize.subscribe((data) => {
				// if ((data && data.dtvCartData && data.dtvCartData && data.dtvCartData.customerOrderItems.length) === (payload && payload.cart && payload.cart.customerOrderItems.length)) {
				// 	offerVariables.selectedDiscountsActive = true;
				// } else {
				// 	offerVariables.selectedDiscountsActive = false;
				// }
			});
		}
		let existingServices;
		if (offerVariables.existingServicesForAction) {
			existingServices = offerVariables.existingServicesForAction;
		} else {
			existingServices = offerVariables.existingServices;
		}
		if (existingServices !== undefined) {
			existingServices.forEach((item) => {
				if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData)
					&& item.offerType !== 'SUBOFFER') {
					internetExist = true;
					internetProduct = item;
				} else if (item.offerCategory === 'VIDEO-PRISM') {
					prismExist = true;
					prismProduct = item;
				} else if (item.offerCategory === 'VIDEO-DTV') {
					dtvExist = true;
					prismProduct = item;
				} else if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER') {
					dhpExist = true;
					dhpProduct = item;
				} else if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER') {
					hpExist = true;
					dhpProduct = item;
				}
			});
		}
		let val;
		let isMonthlyCharge = false;
		if (offerVariables.internetCheck) {
			if (!offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
				offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
					if (exItem.offerCategory === GenericValues.iData && exItem.offerSubType !== 'SUBOFFER') {
						internetProduct = exItem;
					}
				})
			}
			if (offerVariables.existingServices && offerVariables.displayOffer !== "CHANGE") {
				offerVariables.displayOffer = this.checkExistingOfferingId(offerVariables, internetProduct, offerVariables.selectedOffer, 'internet', undefined, true);
			}
			offerVariables.discountSelected = false;
			let changedAction = false;
			let sts;
			if (offerVariables.flow === 'MOVE') {
				sts = this.checkExistingOnlyOfferingId(internetProduct, offerVariables.selectedOffer, 'subinternet');
			} else {
				sts = this.checkExistingOnlyOfferingId(internetProduct, offerVariables.selectedOffer, 'internet');
			}
			if (offerVariables.selectedOffer !== undefined && offerVariables.selectedOffer.productOffer !== undefined) {
				subOrderItem = this.searchforPrimaryCart(offerVariables.selectedOffer
					.productOffer.productComponents, GenericValues.cPrimary, false);
				if (offerVariables.existingServices) {
					subOrderItem.action = !internetExist ? 'ADD' : sts;
					if (offerVariables.flow === 'stackAmend') { subOrderItem.action = isActionAddForAmend ? 'ADD' : !internetExist ? 'ADD' : this.checkExistingOnlyOfferingId(internetProduct, offerVariables.selectedOffer, 'internet'); }
					subOrderItemstoSend.push(subOrderItem);
					offerVariables.displayOffer = false;
					for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
						if (subOrderItem.productAttributes[i].isPriceable) {
							offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
						}
						if (subOrderItem.productAttributes[i] && subOrderItem.productAttributes[i].discounts && subOrderItem.productAttributes[i].discounts.length) {
							for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
								offerVariables.discArray && offerVariables.discArray.forEach(disc => {
									if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
										offerVariables.displayOffer = true;
										offerVariables.existingDiscountId = true;
									}
								})
							}
						}
					}
					if (!offerVariables.reEntrant) {
						if (offerVariables.currentSpeed === subOrderItem.productName || offerVariables.selectedSpeedValue === subOrderItem.productName) {
							offerVariables.hideDisplayDiscounts = true;
						} else {
							offerVariables.hideDisplayDiscounts = false;
						}
					} else {
						if (offerVariables.discloserPopUpSelected && subOrderItem && offerVariables.discloserPopUpSelected.length > 0 && offerVariables.discloserPopUpSelected === subOrderItem.productName.replace(/\s/g, '')) {
							offerVariables.hideDisplayDiscounts = true;
						} else {
							offerVariables.hideDisplayDiscounts = false;
						}
					}
					val = this.productService.checkDiscountExists(subOrderItem, subOrderItem.productName, offerVariables.displayOffer, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey);
					if (val && val.discArray) { offerVariables.discArray = val.discArray; }
					offerVariables.discountSelected = val && val.discountSelected;
				}
				subOrderItems.push(subOrderItem);
				subOrderItem = this.searchforPrimaryCart(offerVariables.selectedOffer
					.productOffer.productComponents, GenericValues.cPrimary, true);
				subOrderItemsForCart.push(subOrderItem);
				if (!offerVariables.existingServices && offerVariables.selectedValues !== undefined) {
					if (offerVariables.selectedValues === subOrderItem.productName) {
						offerVariables.selectedDiscountsActive = true;
					} else {
						offerVariables.selectedDiscountsActive = false;
					}
				}
			}
			let subOrderItemTech: Products;
			if (offerVariables.selectedInstallation !== undefined && offerVariables.selectedInstallation.productAttributes !== undefined) {
				subOrderItem = cloneDeep(offerVariables.selectedInstallation);
				if (offerVariables.existingServices) {
					subOrderItemTech = cloneDeep(offerVariables.selectedInstallation);
					subOrderItem.productAttributes = [];
					for (let i = 0; i < subOrderItemTech.productAttributes.length; i++) {
						let attr = subOrderItemTech.productAttributes[i];
						attr && attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
							if (comp.attributeName !== 'TechInstallRecommended') {
								subOrderItem.productAttributes.push(attr);
							}
						});
					}
				}
				if (offerVariables.recommendedTech) {
					if (!offerVariables.reEntrant) {
						subOrderItem.productAttributes.push(offerVariables.recommendedTech);
					}
				}
				if (offerVariables.existingServices) {
					subOrderItem.action = (isActionAddForAmend || offerVariables.isStack || !internetExist) ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedInstallation, 'internet', undefined, GenericValues.install);
					subOrderItemClone = cloneDeep(subOrderItem);
					subOrderItemstoSend.push(subOrderItemClone);
					if (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType === 'PREPAID') {
						subOrderItem.action = this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedInstallation, 'internet', 'stackAmend', GenericValues.install);
						/* isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
						if (!isMonthlyCharge && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
							subOrderItemsForCart.push(subOrderItem);
						} else if (isMonthlyCharge) {
							subOrderItemsForCart.push(subOrderItem);
						} */
						subOrderItemsForCart.push(subOrderItem);
					}
					if (offerVariables.flow === 'MOVE') {
						subOrderItem.action = 'ADD';
					}
					if(subOrderItem.action === 'CHANGE' || subOrderItem.action === 'ADD') { changedAction = true; }
					for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
						if (subOrderItem.productAttributes[i].isPriceable) {
							offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
						}

						for (let j = 0; j < subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes[i] && subOrderItem.productAttributes[i].discounts.length; j++) {
							offerVariables.discArray.forEach(disc => {
								if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
									offerVariables.displayOffer = true;
								}
							});
						}
					}
					val = this.productService.checkDiscountExists(offerVariables.selectedInstallation, GenericValues.install, false, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey);
					if (val && val.discArray) { offerVariables.discArray = val.discArray; }
					offerVariables.discountSelected = val && val.discountSelected;
				}
				subOrderItems.push(subOrderItem);
				install = true;
				if ((offerVariables.flow !== 'stackAmend' || (offerVariables.flow === 'stackAmend' && offerVariables.offerBillingType !== 'PREPAID')) &&
					((offerVariables.existingServices && subOrderItem.action !== 'REMOVE') || (!offerVariables.existingServices))) {
					subOrderItemsForCart.push(subOrderItem);
				}
			}
			let modemAdded = false;
			if ((offerVariables.existingServices && offerVariables.flow !== 'MOVE' && offerVariables.selectedModem === undefined &&
				(offerVariables.isModemCompatible && offerVariables.existingModem)) ||
				(offerVariables.flow === 'MOVE' && offerVariables.selectedModem === undefined && (!offerVariables.check || (offerVariables.check && offerVariables.isModemCompatible))
					&& !offerVariables.modemDropDown && offerVariables.existingModem)) {
				offerVariables.existingModem.action = "NOCHANGE";
				if (offerVariables.existingObject && offerVariables.existingObject.orderFlow &&
					offerVariables.existingObject.orderFlow.flow === 'billing' && offerVariables.existingObject.orderFlow.type === 'pending' &&
					this.isPurchasedModem(offerVariables.existingModem)) {
					offerVariables.existingModem.action = 'ADD';
					offerVariables.existingModem.dontShow = true;
					subOrderItemsForCart.push(offerVariables.existingModem);
				}
				subOrderItemstoSend.push(offerVariables.existingModem);
				if (offerVariables.existingModem && offerVariables.existingModem.productAttributes) {
					offerVariables.existingModem.productAttributes.forEach(modem => {
						let pushexistingModem = false;
						if (modem.isPriceable && modem.prices && modem.prices.length > 0) {
							modem.prices.forEach(price => {
								if (price.priceType === 'PRICE' && (price.discountedRc !== 0 || price.rc !== 0)) {
									pushexistingModem = true;
								}
							});
							if (pushexistingModem) {
								subOrderItemsForCart.push(offerVariables.existingModem);
							}
						}
					});
				}
				if (subOrderItem && subOrderItem.productAttributes) {
					for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
						if (subOrderItem.productAttributes[i].isPriceable) {
							offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
						}
						if (offerVariables.flow === 'MOVE' && subOrderItem.productAttributes[i].discounts !== null && subOrderItem.productAttributes[i].discounts.length > 0) {
							for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
								offerVariables.discArray.forEach(disc => {
									if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
										offerVariables.existingDiscountId = true;
									}
								});
							}
						}
					}
				}
				modemAdded = true;
				val = this.productService.checkDiscountExists(offerVariables.existingModem, GenericValues.modem, false, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey);
				if (val && val.discArray) { offerVariables.discArray = val.discArray; }
				offerVariables.discountSelected = val && val.discountSelected;
			}
			if (offerVariables.selectedModem !== undefined && offerVariables.selectedModem.productAttributes !== undefined) {
				subOrderItem = offerVariables.selectedModem;
				if (offerVariables.existingServices) {

					subOrderItem.action = (!internetExist || isActionAddForAmend) ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedModem, 'internet', undefined, GenericValues.modem);

					if (!offerVariables.isModemCompatible) {
						subOrderItem.action = 'ADD';
					}

					if (offerVariables.flow && ((['CHANGE', 'MOVE', 'BILLING'].indexOf(offerVariables.flow.toUpperCase()) > -1) || offerVariables.isStack) &&
						this.isPurchasedModem(offerVariables.selectedModem) && this.isPurchasedModem(offerVariables.existingModem)) {
						subOrderItem.action = 'ADD';
					}

					subOrderItemClone = cloneDeep(subOrderItem);
					subOrderItemstoSend.push(subOrderItemClone);
					if (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType === 'PREPAID') {
						subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedModem, 'internet', 'stackAmend', GenericValues.modem);
						/* isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
						if (!isMonthlyCharge && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
							subOrderItemsForCart.push(subOrderItem);
						} else if (isMonthlyCharge) {
							subOrderItemsForCart.push(subOrderItem);
						} */
						subOrderItemsForCart.push(subOrderItem);
					}
					if(subOrderItem.action === 'CHANGE' || subOrderItem.action === 'ADD') { changedAction = true; }
					for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
						if (subOrderItem.productAttributes[i].isPriceable) {
							offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
						}
						if (offerVariables.flow === 'MOVE' && subOrderItem.productAttributes[i].discounts !== null && subOrderItem.productAttributes[i].discounts.length > 0) {
							for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
								offerVariables.discArray.forEach(disc => {
									if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
										offerVariables.existingDiscountId = true;
									}
								});
							}
						}
					}
					if (offerVariables.flow === 'stackAmend') {
						if (subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes.length > 0 && subOrderItem.productAttributes[0].prices && subOrderItem.productAttributes[0].prices.length > 0) {
							isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
							if (subOrderItem.action === 'NOCHANGE' && isMonthlyCharge && offerVariables.offerBillingType !== 'PREPAID') {
								subOrderItemsForCart.push(subOrderItem);
							}
							if ((subOrderItem.action === 'CHANGE' || subOrderItem.action === 'ADD') && offerVariables.offerBillingType !== 'PREPAID') {
								subOrderItemsForCart.push(subOrderItem);
							}
						}
					}
					val = this.productService.checkDiscountExists(offerVariables.selectedModem, GenericValues.modem, true, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey);
					if (val && val.discArray) { offerVariables.discArray = val.discArray; }
					offerVariables.discountSelected = val && val.discountSelected;
				}

				subOrderItems.push(subOrderItem);
				modem = true;
				if (offerVariables.selectedModem && offerVariables.selectedModem.productAttributes && offerVariables.selectedModem.productAttributes !== undefined) {
					let discounts: Discounts[] = [];
					discounts = cloneDeep(offerVariables.selectedModem.productAttributes[0].discounts);
					if (discounts) {
						for (let discount of discounts) {
							if (discount.autoAttachInd === 'Y' && (discount.discountRule === null || discount.discountRule === 'A' || discount.discountRule === 'I' || discount.discountRule === 'O' || (discount.discountRule && discount.discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
								offerVariables.discountedPriceList.push(discount);
							}
						}
					}
					offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
						this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
				}
				if ((offerVariables.existingServices && subOrderItem.action !== 'REMOVE' && offerVariables.flow !== 'stackAmend')
					|| (!offerVariables.existingServices)) {
					subOrderItemsForCart.push(subOrderItem);
				}
				/* else if ((offerVariables.existingServices && subOrderItem.action !== 'REMOVE' && offerVariables.flow === 'stackAmend')
				||(!offerVariables.existingServices) ) {
					subOrderItemsForCart.push(subOrderItem);
				} */
			}
			if (offerVariables.selectedSecureWifi !== undefined && offerVariables.selectedSecureWifi.productAttributes !== undefined) {
				offerVariables.selectedSecureWifi.productAttributes.forEach(attr => {
					attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
						if (comp.attributeName !== GenericValues.serviceLevel || comp.attributeValue !== 'No') {
							subOrderItem = offerVariables.selectedSecureWifi;
							if (offerVariables.existingServices) {
								subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedSecureWifi, 'internet', undefined, GenericValues.secureWifiComponent);
								if (offerVariables.flow === 'stackAmend') { subOrderItem.action = isActionAddForAmend ? 'ADD' : !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedSecureWifi, 'internet', undefined, GenericValues.secureWifiComponent); }
								subOrderItemstoSend.push(subOrderItem);
								if(subOrderItem.action === 'CHANGE') { changedAction = true; }
								if (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType === 'PREPAID') {
									/* subOrderItem.action = (isActionAddForAmend || !internetExist) ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedSecureWifi, 'internet', undefined, GenericValues.secureWifiComponent);
									isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
									if (!isMonthlyCharge && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
										subOrderItemsForCart.push(subOrderItem);
									} else if (isMonthlyCharge) {
										subOrderItemsForCart.push(subOrderItem);
									} */
									subOrderItemsForCart.push(subOrderItem);
								}
								for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
									if (subOrderItem.productAttributes[i].isPriceable) {
										offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
									}
									if (offerVariables.flow === 'MOVE' && subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes[i] &&
										subOrderItem.productAttributes[i].discounts) {
										for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
											offerVariables.discArray.forEach(disc => {
												if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
													offerVariables.existingDiscountId = true;
												}
											});
										}
									}

								}
								val = this.productService.checkDiscountExists(offerVariables.selectedSecureWifi, GenericValues.secureWifiComponent, false, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey, this.isPurchasedModem(offerVariables.selectedModem));
								if (val && val.discArray) { offerVariables.discArray = val.discArray; }
								offerVariables.discountSelected = val && val.discountSelected;
							}
							if (this.isPurchasedModem(offerVariables.selectedModem) || (!offerVariables.reEntrant && this.getCurrentModemType(offerVariables.selectedModemToShow.productAttributes) === "Purchase")) {
								for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
									if (subOrderItem.productAttributes[i].isPriceable) {
										if (subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes[i] &&
											subOrderItem.productAttributes[i].discounts) {
											for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
												if (subOrderItem.productAttributes[i].discounts[j].autoAttachInd === 'Y' && (subOrderItem.productAttributes[i].discounts[j].discountRule === null || subOrderItem.productAttributes[i].discounts[j].discountRule === 'A' || subOrderItem.productAttributes[i].discounts[j].discountRule === 'I' || subOrderItem.productAttributes[i].discounts[j].discountRule === 'O' || (subOrderItem.productAttributes[i].discounts[j].discountRule && subOrderItem.productAttributes[i].discounts[j].discountRule.toUpperCase() === 'PARENT DISCOUNT'))) {
													offerVariables.discountedPriceList.push(subOrderItem.productAttributes[i].discounts[j]);
												}
											}
											offerVariables.totalDiscountAmount = offerVariables.discountedPriceList ?
												this.maxDiscountAmount(offerVariables.discountedPriceList) : 0;
										}
									}
								}
							}
							subOrderItems.push(subOrderItem);
							securityProduct = true;
							if ((offerVariables.flow !== 'stackAmend' || (offerVariables.flow === 'stackAmend' &&
								offerVariables.offerBillingType !== 'PREPAID')) &&
								((offerVariables.existingServices && subOrderItem.action !== 'REMOVE')
									|| !offerVariables.existingServices)) {
								subOrderItemsForCart.push(subOrderItem);
							}
						}
					});
				});
			}
			if (offerVariables.selectedEase !== undefined && offerVariables.selectedEase.productAttributes !== undefined) {
				subOrderItem = offerVariables.selectedEase;
				if (offerVariables.existingServices) {
					subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedEase, 'internet', undefined, GenericValues.ease);
					if (offerVariables.flow === 'stackAmend') { subOrderItem.action = isActionAddForAmend ? 'ADD' : !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedEase, 'internet', undefined, GenericValues.ease); }
					subOrderItemstoSend.push(subOrderItem);
					if(subOrderItem.action === 'CHANGE') { changedAction = true; }
					if (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType === 'PREPAID') {
						subOrderItem.action = (isActionAddForAmend || !internetExist) ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedEase, 'internet', undefined, GenericValues.ease);
						/* isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
						if (!isMonthlyCharge && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
							subOrderItemsForCart.push(subOrderItem);
						} else if (isMonthlyCharge) {
							subOrderItemsForCart.push(subOrderItem);
						} */
						subOrderItemsForCart.push(subOrderItem);
					}
					for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
						if (subOrderItem.productAttributes[i].isPriceable) {
							offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
						}
						if (offerVariables.flow === 'MOVE' && subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes[i] &&
							subOrderItem.productAttributes[i].discounts) {
							for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
								offerVariables.discArray.forEach(disc => {
									if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
										offerVariables.existingDiscountId = true;
									}
								});
							}
						}
					}
					val = this.productService.checkDiscountExists(offerVariables.selectedEase, GenericValues.ease, false, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey);
					if (val && val.discArray) { offerVariables.discArray = val.discArray; }
					offerVariables.discountSelected = val && val.discountSelected;
				}
				subOrderItems.push(subOrderItem);
				ease = true;
				if ((offerVariables.flow !== 'stackAmend' || (offerVariables.flow === 'stackAmend' && offerVariables.offerBillingType !== 'PREPAID'))
					&& ((offerVariables.existingServices && subOrderItem.action !== 'REMOVE')
						|| !offerVariables.existingServices)) {
					subOrderItemsForCart.push(subOrderItem);
				}
			}
			if (offerVariables.selectedModem !== undefined && offerVariables.selfinstallSelected && (offerVariables.shippingNHandlingCharge > 0)) {
				let IsUseOwnModem = this.isUseOwnModem(offerVariables.selectedModem, offerVariables.reEntrant);
				// macd Flow
				this.checkForSelfinstall(subOrderItems, offerVariables);
				if (!IsUseOwnModem && offerVariables.existingServices) {
					subOrderItem = offerVariables.shippingNHandlingChargeObj;
					subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.shippingNHandlingChargeObj, 'internet', undefined, GenericValues.shipping);
					if (offerVariables.flow === 'stackAmend') { subOrderItem.action = (offerVariables.isLatestPendingOrderNI || offerVariables.internetAddAction) && offerVariables.isAmend ? 'ADD' : !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.shippingNHandlingChargeObj, 'internet', undefined, GenericValues.shipping); }
					subOrderItems.push(subOrderItem);
					subOrderItemstoSend.push(subOrderItem);
					if(subOrderItem.action === 'CHANGE' || subOrderItem.action === 'ADD') { changedAction = true; }
					if (subOrderItem.action !== 'REMOVE' && (offerVariables.flow !== 'stackAmend' || (offerVariables.flow === 'stackAmend' &&
						offerVariables.offerBillingType !== 'PREPAID'))) {
						subOrderItemsForCart.push(subOrderItem);
					}
					if (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType === 'PREPAID') {
						subOrderItem.action = (!internetExist || isActionAddForAmend) ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedEase, 'internet', undefined, GenericValues.ease);
						/* isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
						if (!isMonthlyCharge && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
							subOrderItemsForCart.push(subOrderItem);
						} else if (isMonthlyCharge) {
							subOrderItemsForCart.push(subOrderItem);
						} */
						subOrderItemsForCart.push(subOrderItem);
					}
					for (let i = 0; i < subOrderItem.productAttributes.length; i++) {
						if (subOrderItem.productAttributes[i].isPriceable) {
							offerVariables.existingPriceKey = subOrderItem.productAttributes[i].prices[0].priceKey;
						}
						if (offerVariables.flow === 'MOVE' && subOrderItem && subOrderItem.productAttributes && subOrderItem.productAttributes[i] &&
							subOrderItem.productAttributes[i].discounts) {
							for (let j = 0; j < subOrderItem.productAttributes[i].discounts.length; j++) {
								offerVariables.discArray.forEach(disc => {
									if (disc.discountId === subOrderItem.productAttributes[i].discounts[j].discountId) {
										offerVariables.existingDiscountId = true;
									}
								});
							}
						}
					}
					val = this.productService.checkDiscountExists(offerVariables.shippingNHandlingChargeObj, 'SHIPPING', false, offerVariables.discArray, offerVariables.discountSelected, offerVariables.existingPriceKey);
					if (val && val.discArray) { offerVariables.discArray = val.discArray; }
					offerVariables.discountSelected = val && val.discountSelected;
				}
				// ni Flow
				if (!IsUseOwnModem && !offerVariables.existingServices) {
					if (offerVariables.selfinstallSelected) {
						subOrderItem = offerVariables.shippingNHandlingChargeObj;
						subOrderItems.push(subOrderItem);
						subOrderItemsForCart.push(subOrderItem);
					}
				}
			}
			if (offerVariables.selectedModem !== undefined && offerVariables.selfinstallSelected && (offerVariables.shippingNHandlingCharge === 0)) {
				let IsUseOwnModem = this.isUseOwnModem(offerVariables.selectedModem, offerVariables.reEntrant);
				this.checkForSelfinstall(subOrderItems, offerVariables);
				subOrderItem = offerVariables.shippingNHandlingChargeObj;
				if (subOrderItem) { subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.shippingNHandlingChargeObj, 'internet', undefined, GenericValues.shipping); }
				// ni
				if (!IsUseOwnModem && !offerVariables.existingServices && subOrderItem) { subOrderItems.push(subOrderItem); }
				// macd
				if (!IsUseOwnModem && offerVariables.existingServices && subOrderItem) {
					subOrderItems.push(subOrderItem);
					subOrderItemstoSend.push(subOrderItem);
				}
			}
			offerVariables.hideShippingDiscount = false;
			if (offerVariables.existingServices && offerVariables.isReEntrant && (!offerVariables.selfinstallSelected || (offerVariables.selfinstallSelected &&
				offerVariables.selectedModem === undefined)) && (offerVariables.shippingNHandlingCharge > 0)) {
				let IsUseOwnModem = this.isUseOwnModem(offerVariables.selectedModem, offerVariables.reEntrant);
				if (!IsUseOwnModem) {
					offerVariables.hideShippingDiscount = true;
					offerVariables.copyOfDiscountsAdded = this.removeShippingDiscountFromCart(offerVariables.shippingNHandlingChargeObj, offerVariables.copyOfDiscountsAdded);
				}
			}
			if ((!offerVariables.isPOTS && !offerVariables.existingServices) || (offerVariables.existingServices && offerVariables.selectedJack !== undefined &&
				(!offerVariables.phoneOffer || !offerVariables.hsiExisting || (offerVariables.phoneOffer && offerVariables.phoneSelected !== 'HMP')))) {
				offerVariables.retainValueForHSIJack = '';
				offerVariables.retainValueForPotsJack = '';
				if (offerVariables.selectedJack !== undefined && offerVariables.selectedJack.productAttributes !== undefined) {
					offerVariables.selectedJack.productAttributes.forEach(attr => {
						attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
							if (comp.attributeName === 'Installation Number' && comp.attributeValue !== 'No work is needed') {
								offerVariables.retainValueForPotsJack = comp.attributeName;
								offerVariables.retainValueForHSIJack = comp.attributeName;
								subOrderItem = offerVariables.selectedJack;
								jack = true;
								if (offerVariables.flow === 'stackAmend' && offerVariables.isAmend && offerVariables.offerBillingType === 'PREPAID') {
									subOrderItem.action = !internetExist ? 'ADD' : this.checkExistingSubOffers(offerVariables, internetProduct, offerVariables.selectedJack, 'internet', undefined, GenericValues.jack);
									/* isMonthlyCharge = this.isMonthly(subOrderItem, isMonthlyCharge);
									if (!isMonthlyCharge && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE') {
										subOrderItemsForCart.push(subOrderItem);
									} else if (isMonthlyCharge) {
										subOrderItemsForCart.push(subOrderItem);
									} */
									subOrderItemsForCart.push(subOrderItem);
								} else if ((offerVariables.existingServices && subOrderItem.action !== 'REMOVE' && subOrderItem.action !== 'NOCHANGE')
									|| (!offerVariables.existingServices)) {
									subOrderItemsForCart.push(subOrderItem);
								}
								if (offerVariables.existingServices) {
									subOrderItem.action = 'ADD';
									subOrderItemstoSend.push(subOrderItem);
								}
								subOrderItems.push(subOrderItem);
							}
							else {
								offerVariables.retainValueForPotsJack = '';
							}
						});
					});
				}
			}
			if (offerVariables.existingServices) {
				subOrderItemsForCart.forEach((sub) => {
					if (sub.productName === GenericValues.modem) {
						if (sub.productAttributes && sub.productAttributes.length > 0) {
							sub.productAttributes[0] = this.updateModemAttrValue(sub.productAttributes[0], GenericValues.leaseWithCsAttrVAlue);
						}
					}
				});
			}
			orderItem = {
				catalogId: offerVariables.hsiCatalogId,
				productOfferingId: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOfferingId,
				productType: GenericValues.sData,
				offerDisplayName: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOffer.offerDisplayName,
				quantity: 1,
				rc: offerVariables.actualPrice,
				discountedRc: offerVariables.selectedOffer && offerVariables.selectedOffer.defaultOfferPrice !== null ? offerVariables.selectedOffer.defaultOfferPrice.discountedRc : 0,
				customerOrderSubItems: subOrderItemsForCart,
			};
			if (!offerVariables.existingServices) {
				orderItem.install = install;
					orderItem.modem = modem;
					orderItem.securityProduct = securityProduct;
					orderItem.ease = ease;
					orderItem.jack = jack;
			}
			else if (offerVariables.flow === 'CHANGE' && offerVariables.flow === 'BILLING') {
				orderItem.action = !internetExist ? 'ADD' : changedAction ? 'CHANGE' : this.checkExistingOfferingId(offerVariables, internetProduct, offerVariables.selectedOffer, 'internet', undefined);
				orderItem.offerCategory = GenericValues.iData;
			}
			if (offerVariables.flow === 'MOVE') { orderItem.catalogId = offerVariables.hsiCatalogId; }
			orderItems.push(orderItem);
			if (offerVariables.existingServices && (offerVariables.flow === 'CHANGE' || offerVariables.flow === 'MOVE')) {
				if (offerVariables.selectedInstallation === undefined && offerVariables.techInstallExist) {
					subOrderItem = this.findCustomerSubOrderObject(custObj, 'TECH INSTALL');
					subOrderItem = Object.assign({}, subOrderItem, {
						action: 'REMOVE'
					});
					subOrderItemstoSend.push(subOrderItem);
				}
				if (offerVariables.selectedModem === undefined && offerVariables.modemExist && !modemAdded) {
					subOrderItem = this.findCustomerSubOrderObject(custObj, 'MODEM');
					subOrderItem = Object.assign({}, subOrderItem, {
						action: 'REMOVE'
					});
					subOrderItemstoSend.push(subOrderItem);
				}
				if (offerVariables.selectedEase === undefined && offerVariables.easeExist) {
					subOrderItem = this.findCustomerSubOrderObject(custObj, 'CENTURYLINK @ EASE');
					subOrderItem = Object.assign({}, subOrderItem, {
						action: 'REMOVE'
					});
					subOrderItemstoSend.push(subOrderItem);
				}
				let yesSelected;
				if (offerVariables.selectedSecureWifi && offerVariables.selectedSecureWifi.productAttributes.length > 0 &&
					offerVariables.selectedSecureWifi.productAttributes[0] && offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute) {
					yesSelected = offerVariables.selectedSecureWifi.productAttributes[0].compositeAttribute.filter(attr => (attr.attributeName === GenericValues.serviceLevel && attr.attributeValue.toLowerCase() === 'yes')).length > 0;
				}
				if ((offerVariables.selectedSecureWifi === undefined || !yesSelected) && offerVariables.secureWifiExist) {
					subOrderItem = this.findCustomerSubOrderObject(custObj, GenericValues.secureWifiComponent);
					subOrderItem = Object.assign({}, subOrderItem, {
						action: 'REMOVE'
					});
					subOrderItemstoSend.push(subOrderItem);
				}
				if (offerVariables.selectedJack === undefined && offerVariables.jackExist) {
					subOrderItem = this.findCustomerSubOrderObject(custObj, 'Jack and Wire');
					subOrderItem = Object.assign({}, subOrderItem, {
						action: 'REMOVE'
					});
					subOrderItemstoSend.push(subOrderItem);
				}
			}
			orderItem = {
				catalogId: offerVariables.hsiCatalogId,
				productOfferingId: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOfferingId,
				offerType: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOffer.offerType,
				offerSubType: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOffer.offerSubType,
				offerCategory: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOffer.offerCategory,
				quantity: 1,
				rc: offerVariables.actualPrice,
				discountedRc: offerVariables.selectedOffer && offerVariables.selectedOffer.defaultOfferPrice !== null ? offerVariables.selectedOffer.defaultOfferPrice.discountedRc : 0,
				otc: offerVariables.actualInternetOtcPrice,
				discountedOtc: offerVariables.discountedInternetOtcPrice,
				customerOrderSubItems: subOrderItems,
				offerName: offerVariables.selectedOffer === undefined ? '' : offerVariables.selectedOffer.productOffer.offerName
			};

			if (offerVariables.existingServices) {
				orderItem.customerOrderSubItems = subOrderItemstoSend
				orderItem.action = !internetExist ? 'ADD' : changedAction ? 'CHANGE' : this.checkExistingOfferingId(offerVariables, internetProduct, offerVariables.selectedOffer, 'internet', undefined);
				orderItem.contractTerm = offerVariables.cartContractTerm ? offerVariables.cartContractTerm : '0';

			}
			if (offerVariables.flow === 'stackAmend') { orderItem.action = isActionAddForAmend ? 'ADD' : !internetExist ? 'ADD' : changedAction ? 'CHANGE' : this.checkExistingOfferingId(offerVariables, internetProduct, offerVariables.selectedOffer, 'internet', undefined); }
			if (offerVariables.flow === 'MOVE') { orderItem.catalogId = offerVariables.hsiCatalogId; }
			orderItemstoSend.push(orderItem);
			if (offerVariables.existingServices && (offerVariables.isRemoved || offerVariables.isDHPRemoved || offerVariables.isHPRemoved || offerVariables.isOptedOut)) {
				this.serviceTerminate(offerVariables);
				offerVariables.removedProductItem.forEach(item => {
					if (!offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
						offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
							if (item.offerCategory === exItem.offerCategory && item.offerSubType === exItem.offerSubType) {
								orderItemstoSend.push(item);
							}
						})
					} else {
						orderItemstoSend.push(item);
					}
				});
			}
			if (!offerVariables.phoneOffer && !offerVariables.isLatestPendingOrderNI && offerVariables.isAmend && !offerVariables.isHPRemoved) {
				offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
					if (exItem.offerCategory === GenericValues.cHP) {
						let item = cloneDeep(exItem);
						item.action = 'REMOVE';
						item && item.customerOrderSubItems && item.customerOrderSubItems.map(subItem => {
							subItem.action = 'REMOVE';
						})
						orderItemstoSend.push(item);
					}
				})
			}
		} else {
			if (offerVariables.configSelected.length > 0) {
				for (let i = 0; i < offerVariables.configSelected.length; i++) {
					if (offerVariables.configSelected[i].productType === 'INTERNET') {
						offerVariables.configSelected.splice(i, 1);
						break;
					}
				}
			}
		}
		// internetCheck Ends
		if (offerVariables.videoOffer) {
			subOrderItems = [];
			if (offerVariables.selectedTVOffer !== undefined && offerVariables.selectedTVOffer.productOffer !== undefined) {
				subOrderItem = this.searchforPrimaryCart(offerVariables.selectedTVOffer
					.productOffer.productComponents, GenericValues.cPrimary);
				if (offerVariables.existingServices) {
					if (offerVariables.videoSelected === 'PTV') {
						subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOnlyOfferingId(prismProduct, offerVariables.selectedTVOffer, 'prism');
					}
					else {
						subOrderItem.action = !dtvExist ? 'ADD' : this.checkExistingOnlyOfferingId(prismProduct, offerVariables.selectedTVOffer, 'dtv');
						if (offerVariables.flow === 'stackAmend') { subOrderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : !dtvExist ? 'ADD' : this.checkExistingOnlyOfferingId(prismProduct, offerVariables.selectedTVOffer, 'dtv'); }
					}
				}
				subOrderItems.push(subOrderItem);
			}
			if (offerVariables.flow !== 'stackAmend') {
				if (offerVariables.selectedSTB !== null && offerVariables.selectedSTB !== undefined) {
					subOrderItem = offerVariables.selectedSTB;
					if (offerVariables.existingServices) { subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(offerVariables, prismProduct, offerVariables.selectedTVOffer, 'prism', 'selectedSTB'); }
					subOrderItems.push(subOrderItem);
				}
				if (offerVariables.hdService !== null && offerVariables.hdService !== undefined) {
					subOrderItem = offerVariables.hdService;
					if (offerVariables.existingServices) { subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(offerVariables, prismProduct, offerVariables.selectedTVOffer, 'prism', 'hdService'); }
					subOrderItems.push(subOrderItem);
				}
				if (offerVariables.dvrService !== null && offerVariables.dvrService !== undefined) {
					subOrderItem = offerVariables.dvrService;
					if (offerVariables.existingServices) { subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(offerVariables, prismProduct, offerVariables.selectedTVOffer, 'prism', 'dvrService'); }
					subOrderItems.push(subOrderItem);
				}
				if (offerVariables.wiredSTB !== null && offerVariables.wiredSTB !== undefined) {
					subOrderItem = offerVariables.wiredSTB;
					if (offerVariables.existingServices) { subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(offerVariables, prismProduct, offerVariables.selectedTVOffer, 'prism', 'wiredSTB'); }
					subOrderItems.push(subOrderItem);
				}
				if (offerVariables.wirelessSTB !== null && offerVariables.wirelessSTB !== undefined) {
					subOrderItem = offerVariables.wirelessSTB;
					if (offerVariables.existingServices) { subOrderItem.action = !prismExist ? 'ADD' : this.checkExistingOfferingId(offerVariables, prismProduct, offerVariables.selectedTVOffer, 'prism', 'wirelessSTB'); }
					subOrderItems.push(subOrderItem);
				}
			}
			orderItem = {
				catalogId: offerVariables.dtvCatalogId,
				productOfferingId: offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOfferingId,
				productType: GenericValues.cVideo,
				quantity: 1,
				rc: offerVariables.actualTVPrice,
				discountedRc: offerVariables.discountedTVPrice,
				customerOrderSubItems: subOrderItems
			};

			if (offerVariables.existingServices && offerVariables.flow !== 'BILLING') {
				orderItem.offerName = offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOffer.offerName;
			}
			if (offerVariables.flow === 'MOVE') { orderItem.catalogId = offerVariables.dtvCatalogId; }
			if (offerVariables.flow === 'stackAmend' || offerVariables.flow === 'BILLING' || offerVariables.flow === 'CHANGE') { orderItem.catalogId = offerVariables.dtvCatalogId; }
			orderItems.push(orderItem);
			orderItem = {
				catalogId: offerVariables.dtvCatalogId,
				productOfferingId: offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOfferingId,
				offerType: offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOffer.offerType,
				offerSubType: offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOffer.offerSubType,
				offerCategory: offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOffer.offerCategory,
				quantity: 1,
				rc: offerVariables.actualTVPrice,
				discountedRc: offerVariables.discountedTVPrice,
				otc: offerVariables.actualTVOtcPrice,
				discountedOtc: offerVariables.discountedTVOtcPrice,
				customerOrderSubItems: subOrderItems,
				offerName: offerVariables.selectedTVOffer === undefined ? '' : offerVariables.selectedTVOffer.productOffer.offerName
			};

			if (offerVariables.existingServices) {
				orderItem.action = !dtvExist ? 'ADD' : 'NOCHANGE';
				orderItem.contractTerm = offerVariables.cartContractTermDTV ? offerVariables.cartContractTermDTV : '0';

			}
			if (offerVariables.flow === 'MOVE') {
				orderItem.catalogId = offerVariables.hsiCatalogId;
				orderItem.contractTerm = offerVariables.selectedTVOffer !== undefined && offerVariables.selectedTVOffer.productOffer && offerVariables.selectedTVOffer.productOffer.contract && offerVariables.selectedTVOffer.productOffer.contract.contractTerm ? offerVariables.selectedTVOffer.productOffer.contract.contractTerm : '0';
			}
			if (offerVariables.flow === 'BILLING' || offerVariables.flow === 'CHANGE') {
				orderItem.catalogId = offerVariables.dtvCatalogId;
			}
			if (offerVariables.flow === 'stackAmend') {
				orderItem.catalogId = offerVariables.dtvCatalogId;
				orderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : !dtvExist ? 'ADD' : 'NOCHANGE';
			}
			orderItemstoSend.push(orderItem);
		}
		// video Offer ends
		if (offerVariables.phoneOffer) {
			offerVariables.discountSelected = false;
			subOrderItems = [];
			if (offerVariables.selectedDHPOffer !== undefined && offerVariables.selectedDHPOffer.productOffer !== undefined) {
				subOrderItem = this.searchforPrimaryCart(offerVariables.selectedDHPOffer
					.productOffer.productComponents, GenericValues.cPrimary);
				if (offerVariables.existingServices && !offerVariables.internetCheck) {
					offerVariables.hideDisplayDiscounts = false;
					val = this.productService.checkDiscountExists(subOrderItem, subOrderItem.productName, false, offerVariables.discArray, offerVariables.discountSelected);
					if (val && val.discArray) { offerVariables.discArray = val.discArray; }
					offerVariables.discountSelected = val && val.discountSelected;
				}
				subOrderItems.push(subOrderItem);
				let vmAction;
				if (offerVariables.existingServices) {
					vmAction = this.checkExistingOnlyOfferingId(dhpProduct, offerVariables.selectedDHPOffer, 'dhp');
					if (offerVariables.displayOffer !== "CHANGE") {
						offerVariables.displayOffer = vmAction;
					}
				}
				if (offerVariables.wireMaintainance && offerVariables.selectedMaintainance !== undefined) {
					subOrderItem = offerVariables.selectedMaintainance;
					if (offerVariables.existingServices) { subOrderItem.action = !offerVariables.wireMaintainCondi ? 'ADD' : 'NOCHANGE'; }
					if (offerVariables.flow === 'stackAmend') { subOrderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : !offerVariables.wireMaintainCondi ? 'ADD' : 'NOCHANGE'; }
					subOrderItems.push(subOrderItem);
					offerVariables.potsWireMainMandatory = false;
				}
				if (!offerVariables.wireMaintainance && offerVariables.selectedMaintainance !== undefined && offerVariables.wireMaintainanceValue === 'No') {
					offerVariables.potsWireMainMandatory = false;
				} else if (!offerVariables.wireMaintainance && offerVariables.selectedMaintainance !== undefined && offerVariables.retainedPotsBooleans === undefined) {
					offerVariables.potsWireMainMandatory = true;
				} else if (!offerVariables.wireMaintainance && offerVariables.wireMaintainanceValue === 'na') {
					offerVariables.potsWireMainMandatory = true;
				} else {
					offerVariables.potsWireMainMandatory = false;
				}
				if (offerVariables.selectedExtendedAreaCalling !== undefined) {
					subOrderItem = offerVariables.selectedExtendedAreaCalling;
					subOrderItem.action = 'ADD';
					if (offerVariables.existingServices) { subOrderItem.action = !offerVariables.isExtendedAreaCallingExits ? 'ADD' : 'NOCHANGE'; }
					subOrderItems.push(subOrderItem);
				}
				if (offerVariables.voiceMail && offerVariables.selectedVoiceMail !== undefined) {
					subOrderItem = offerVariables.selectedVoiceMail;
					if (offerVariables.existingServices) {
						subOrderItem.action = !offerVariables.voiceMailCondi ? 'ADD' : 'NOCHANGE';
						if (offerVariables.flow === 'stackAmend') { subOrderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : !offerVariables.voiceMailCondi ? 'ADD' : 'NOCHANGE'; }
						subOrderItem.dontShow = false;
						if (vmAction === 'CHANGE') { subOrderItem.action = vmAction; }
						subOrderItems.push(subOrderItem);

					} else {
						// if (offerVariables.isVoiceMailYesSelected) {
						if (offerVariables.voiceMail) {
							subOrderItems.push(subOrderItem);
						}
					}
					offerVariables.potsVoiceMailMandatory = false;
				}
				// if (!offerVariables.voiceMail && offerVariables.selectedVoiceMail !== undefined && offerVariables.isVoiceMailNoSelected) {
				if (!offerVariables.voiceMail && offerVariables.selectedVoiceMail !== undefined && offerVariables.voiceMailValue === 'No') {
					offerVariables.potsVoiceMailMandatory = false;
				} else if (!offerVariables.voiceMail && offerVariables.selectedVoiceMail !== undefined && offerVariables.retainedPotsBooleans === undefined) {
					offerVariables.potsVoiceMailMandatory = true;
				} else {
					offerVariables.potsVoiceMailMandatory = false;
				}
				if (offerVariables.selectedJackForPots !== undefined) {
					offerVariables.retainValueForPotsJack = '';
					if (offerVariables.selectedJackForPots.productAttributes && offerVariables.selectedJackForPots.productAttributes.length > 0) {
						offerVariables.selectedJackForPots.productAttributes.forEach(attr => {
							attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
								if (comp.attributeName === 'Installation Number' && comp.attributeValue !== 'No work is needed') {
									offerVariables.retainValueForPotsJack = comp.attributeValue;
									subOrderItem = offerVariables.selectedJackForPots;
									if (offerVariables.existingServices) { subOrderItem.action = 'ADD'; }
									subOrderItems.push(subOrderItem);
									offerVariables.potsJacksMandatory = false;
								} else if (comp.attributeName === 'Installation Number' && comp.attributeValue === 'No work is needed') {
									offerVariables.retainValueForPotsJack = comp.attributeValue;
								}
							});
							if (attr.compositeAttribute === undefined && offerVariables.retainValueForPotsJack === "") {
								offerVariables.selectedJackForPots = undefined;
							}
						});
					}
				}
				if(offerVariables.jackErrorForPots && offerVariables.selectedJackForPots === undefined) { offerVariables.potsJacksMandatory = true; }
				!offerVariables.hpExisting && !offerVariables.portingCheck && !offerVariables.isPortingCheckNoSelected && !offerVariables.isPortingCheckYesSelected ? offerVariables.potsPortingMandatory = true : offerVariables.potsPortingMandatory = false;
				offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer
					.productOffer.productComponents.forEach(products => {
						if (products.componentType !== GenericValues.cPrimary && products.product.productName !== 'Digital Home Phone Intl Call') {
							if (products && products.isDefault === 0 && products.isMandatory) {
								subOrderItem = this.getDHPComponents(products, offerVariables);
								if (offerVariables.existingServices) { subOrderItem.action = (offerVariables.phoneSelected === 'HMP' && !offerVariables.hpExisting) || (!offerVariables.dhpExisting && offerVariables.phoneSelected === 'DHP') ? 'ADD' : this.checkPOTSAction(subOrderItem.productName, offerVariables); }
								subOrderItem.dontShow = true;
								subOrderItems.push(subOrderItem);
							}
							else if (offerVariables.existingServices && offerVariables.voiceMail && offerVariables.selectedVoiceMail !== undefined && products.product.productName === 'Easy Access') {
								subOrderItem = this.getDHPComponents(products, offerVariables);
								subOrderItem.action = !offerVariables.voiceMailCondi ? 'ADD' : 'NOCHANGE';
								if (offerVariables.flow === 'stackAmend') { subOrderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : !offerVariables.voiceMailCondi ? 'ADD' : 'NOCHANGE'; }
								subOrderItem.dontShow = false;
								if (vmAction === 'CHANGE') { subOrderItem.action = vmAction; }
								if (vmAction === 'NOCHANGE') { subOrderItem.dontShow = true; }
								subOrderItems.push(subOrderItem);
							}
						}
					});
			}
			if (offerVariables.flow === 'stackAmend') {
				offerVariables.potsAddAction && offerVariables.phoneSelected === 'HMP' && subOrderItems.forEach(act => {
					act.action = 'ADD';
				})
			}

			orderItem = {
				catalogId: offerVariables.phoneSelected === 'HMP' ? offerVariables.phoneCatalogId : offerVariables.hsiCatalogId,
				productOfferingId: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOfferingId,
				productType: offerVariables.phoneSelected === 'DHP' ? GenericValues.cDHP : GenericValues.cHP,
				productDisplayName: this.productService.getPhoneDisplayName(offerVariables.selectedDHPOffer),
				offerDisplayName: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerDisplayName,
				quantity: 1,
				rc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.rc : 0,
				discountedRc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
				otc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.otc : 0,
				discountedOtc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
				customerOrderSubItems: subOrderItems,
				offerType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerType,
				offerCategory: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerCategory
			};
			if (offerVariables.selectedDHPOffer !== undefined) { offerVariables.hpOfferType = orderItem.offerType; }
			if (!offerVariables.existingServices) {
				orderItem.offerSubType = offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerSubType;
			}
			if (offerVariables.existingServices) {
				orderItem.catalogId = offerVariables.phoneCatalogId ? offerVariables.phoneCatalogId : offerVariables.hsiCatalogId;
				if (offerVariables.flow !== 'MOVE') {
					orderItem.productDisplayName = offerVariables.selectedDHPOffer !== undefined ? offerVariables.selectedDHPOffer.productOffer.offerDisplayName : '';
				}
				orderItem.offerName = offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerName;
			}
			if (offerVariables.flow === 'CHANGE' || offerVariables.flow === 'BILLING') {
				orderItem.action = (!dhpExist && offerVariables.phoneSelected === 'DHP') || (!hpExist && offerVariables.phoneSelected === 'HMP') ? 'ADD' : '';
			}
			orderItems.push(orderItem);
		}
		let payload: Payload;
		payload = this.getpayload(offerVariables, orderItems, payload)
		if (offerVariables.reEntrant && !offerVariables.changeAfterReEntrant) {
			let addons: CustomerOrderItems[] = [];
			let cart = <Observable<ShoppingCart>>this.store.select('cart');
			let cartSubscription = cart.subscribe((data) => {
				if (offerVariables.existingServices && data && data.payload && data.payload.cart !== undefined && data.payload.cart.customerOrderItems !== undefined && data.payload.cart.customerOrderItems.length > 0) {
					data.payload.cart.customerOrderItems.forEach(dat => {
						if (dat && dat.action !== undefined && dat.action !== "") {
							if (offerVariables.discloserPopUpSelected !== "CHANGE") {
								offerVariables.discloserPopUpSelected = dat.action;
							}
						}
					});
				}
				data && data.payload && data.payload.customerAddonOfferItems && data.payload.customerAddonOfferItems.forEach(cartItem => {
					if ((cartItem.offerCategory === GenericValues.cHP || (cartItem.offerCategory === 'WIRINGWORKS' && offerVariables.existingServices) && offerVariables.phoneSelected === 'HMP') ||
						(cartItem.offerCategory === GenericValues.cDHP && offerVariables.phoneSelected === 'DHP') ||
						((cartItem.offerCategory === GenericValues.iData || cartItem.offerCategory === GenericValues.sData || (cartItem.offerCategory === 'WIRINGWORKS' && offerVariables.existingServices) && offerVariables.internetCheck))) {
						addons.push(cartItem);
					}
				})
				if (offerVariables.flow === 'MOVE' && data && data.payload && data.payload.customerAddonOfferItems && data.payload.customerAddonOfferItems) {
					addons = data.payload.customerAddonOfferItems;
				}
			})
			let addedCartDiscounts = [];
			if (payload && payload.cart && payload.cart.customerOrderItems && payload.cart.customerOrderItems.length > 0) {
				payload.cart.customerOrderItems.forEach(dat => {
					dat.customerOrderSubItems.forEach(data => {
						data.productAttributes.forEach(discData => {
							if (discData && discData.discounts && discData.discounts.length > 0) {
								discData.discounts.forEach(disc => {
									addedCartDiscounts.push(disc);
								});
							}
						});
					});
				});
			}
			payload = this.getReentrantPayload(offerVariables, payload, orderItems, addons, addedCartDiscounts);

			if (cartSubscription !== undefined) { cartSubscription.unsubscribe(); }

		}
		offerVariables.cartObject = {
			success: offerVariables.offerResponse.success,
			orderRefNumber: offerVariables.offerResponse.orderRefNumber,
			processInstanceId: offerVariables.offerResponse.processInstanceId,
			taskId: offerVariables.offerResponse.taskId,
			taskName: offerVariables.offerResponse.taskName,
			payload: payload
		};
		offerVariables.cartOrderItems = cloneDeep(offerVariables.cartObject);
		if (offerVariables.billingTypeChanged && offerVariables.cartObject && offerVariables.cartObject.payload && offerVariables.cartObject.payload.discountItems && offerVariables.cartObject.payload.discountItems !== undefined && offerVariables.cartObject.payload.discountItems.length > 0) {
			offerVariables.cartObject.payload.discountItems = [];
		}
		this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartObject });
		if (!offerVariables.reEntrant && offerVariables.existingServices) { this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart }); }
		payload = this.getpayloadToSend(offerVariables, orderItemstoSend, payload, null)
		if (offerVariables.flow === 'MOVE' && offerVariables.isDHPRemoved && offerVariables.serviceTerminationInfo !== undefined) {
			let e911: any = {};
			if (offerVariables.e911ValidatedAddress && offerVariables.e911ValidatedAddress.streetDirectionPrefix) {
				e911 = {
					"streetDirectionPrefix": offerVariables.e911ValidatedAddress.streetDirectionPrefix,
					"streetAddress": offerVariables.e911ValidatedAddress.streetAddress,
					"location": offerVariables.e911ValidatedAddress.location,
					"streetNrFirst": offerVariables.e911ValidatedAddress.streetNrFirst,
					"city": offerVariables.e911ValidatedAddress.city,
					"stateOrProvince": offerVariables.e911ValidatedAddress.stateOrProvince,
					"postCode": offerVariables.e911ValidatedAddress.postCode,
					"postCodeSuffix": offerVariables.e911ValidatedAddress.postCodeSuffix
				}
			} else {
				e911 = {
					"streetDirectionPrefix": "",
					"streetAddress": "311 S MAYNE ST",
					"location": "VALLEY",
					"streetNrFirst": "311",
					"city": "VALLEY",
					"stateOrProvince": "NE",
					"postCode": "68064",
					"postCodeSuffix": ""
				}
			}
			if (offerVariables.onlyDHPRemoved) {
				payload = Object.assign({},
					payload, {
					dhpAdditionalInfo: {
						e911Address: e911,
						dhpDisclaimerAcceptDateTime: offerVariables.e911ValidatedAddress
							&& offerVariables.e911ValidatedAddress.streetDirectionPrefix ? offerVariables.e911ValidatedAddress && offerVariables.e911ValidatedAddress.acceptedData : new Date().toISOString()
					},
					servicesTerminationInfo: offerVariables.serviceTerminationInfo,
					productConfiguration: offerVariables.configSelected
				}
				);
			}
			else {
				payload = Object.assign({},
					payload, {
					servicesTerminationInfo: offerVariables.serviceTerminationInfo,
					productConfiguration: offerVariables.configSelected
				}
				);
			}
		}
		if ((offerVariables.phoneOffer && offerVariables.selectedDHPOffer && !offerVariables.existingServices) || (offerVariables.phoneOffer && offerVariables.existingServices)) {
			subOrderItems = [];
			if (offerVariables.selectedDHPOffer !== undefined && offerVariables.selectedDHPOffer.productOffer !== undefined) {
				subOrderItem = this.searchforPrimaryCart(offerVariables.selectedDHPOffer
					.productOffer.productComponents, GenericValues.cPrimary);
				subOrderItems.push(subOrderItem);
				let checkActionforExistingAmend = false;
				if (offerVariables.existingServices) {
					if (!offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
						offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
							if (exItem.offerCategory === GenericValues.cHP) {
								checkActionforExistingAmend = true;
							}
							if (dhpProduct.offerType !== offerVariables.selectedDHPOffer.productOffer.offerType) {
								offerVariables.isPOTSChanged = true;
							}
						})
					}
					subOrderItem.action = (offerVariables.phoneSelected === 'DHP' && !dhpExist)
						|| ((((offerVariables.isLatestPendingOrderNI) || (!offerVariables.isLatestPendingOrderNI && !checkActionforExistingAmend)) && offerVariables.isAmend) ||
							(offerVariables.phoneSelected === 'HMP' && !hpExist)) ? 'ADD' :
						this.checkExistingOnlyOfferingId(dhpProduct, offerVariables.selectedDHPOffer, 'internet');
				}
				offerVariables.selectedDHPOffer
					.productOffer.productComponents.forEach(products => {
						if (products.componentType !== GenericValues.cPrimary && products.product.productName !== 'Digital Home Phone Intl Call') {
							if ((products.product.productName.indexOf('Wire Maintenance Plan') !== -1 && offerVariables.wireMaintainance) ||

								((products.product.productName.indexOf('Voice Messaging') !== -1 && offerVariables.voiceMail && offerVariables.existingServices) ||
									// (products.product.productName.indexOf('Voice Messaging') !== -1 && offerVariables.voiceMail && offerVariables.isVoiceMailYesSelected && !offerVariables.existingServices))
									(products.product.productName.indexOf('Voice Messaging') !== -1 && offerVariables.voiceMail && !offerVariables.existingServices))
								|| (((products.product.productName.indexOf('Easy Access') !== -1 && offerVariables.existingServices && offerVariables.voiceMail)) || (products.product.productName.indexOf('Easy Access') !== -1 && offerVariables.flow === 'BILLING'))) {
								subOrderItem = this.getDHPComponents(products, offerVariables);
								if (offerVariables.existingServices) {
									if (products.product.productName.indexOf('Voice Messaging') !== -1 || products.product.productName.indexOf('Easy Access') !== -1) {
										if (offerVariables.voiceMailCondi) {
											subOrderItem.action = 'NOCHANGE';
										} else { subOrderItem.action = 'ADD'; }
										if (offerVariables.flow === 'stackAmend') {
											if (offerVariables.voiceMailCondi && (products.product.productName.indexOf('Voice Messaging') !== -1 || products.product.productName.indexOf('Easy Access') !== -1)) {
												subOrderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : 'NOCHANGE';
											} else { subOrderItem.action = 'ADD'; }
										}
									} else {
										if (offerVariables.wireMaintainCondi) { subOrderItem.action = 'NOCHANGE' } else { subOrderItem.action = 'ADD'; }
										if (offerVariables.flow === 'stackAmend') {
											if (offerVariables.wireMaintainCondi && products.product.productName.indexOf('Wire Maintenance Plan') !== -1) {
												subOrderItem.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : 'NOCHANGE';
											} else { subOrderItem.action = 'ADD'; }
										}
									}
								}

								subOrderItems.push(subOrderItem);
							}
							if (products.product.productName.indexOf('Jack and Wire') !== -1 && offerVariables.selectedJackForPots) {
								if (offerVariables.selectedJackForPots.productAttributes && offerVariables.selectedJackForPots.productAttributes.length > 0) {
									offerVariables.selectedJackForPots.productAttributes.forEach(attr => {
										attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
											if (comp.attributeName === 'Installation Number' && comp.attributeValue !== 'No work is needed') {
												subOrderItem = offerVariables.selectedJackForPots;
												if (offerVariables.existingServices) { subOrderItem.action = 'ADD'; }
												subOrderItems.push(subOrderItem);
											}
										});
									});
								}
							}
							if (products.product.productName.indexOf('Wire Maintenance Plan') === -1 &&
								products.product.productName.indexOf('Voice Messaging') === -1
								&& products.product.productName.indexOf('Jack and Wire') === -1
								&& ((products.product.productName.indexOf('Easy Access') === -1 && offerVariables.existingServices) || !offerVariables.existingServices)
							) {
								subOrderItem = this.getDHPComponents(products, offerVariables);
								if (offerVariables.existingServices) {
									subOrderItem.action = ((((offerVariables.isLatestPendingOrderNI) || (!offerVariables.isLatestPendingOrderNI && !checkActionforExistingAmend)) && offerVariables.isAmend) ||
										(offerVariables.phoneSelected === 'HMP' && !offerVariables.hpExisting)) ||
										(!offerVariables.dhpExisting && offerVariables.phoneSelected === 'DHP') ? 'ADD' : this.checkPOTSAction(subOrderItem.productName, offerVariables)
								}
								subOrderItems.push(subOrderItem);
							}
						}
					});

				if (offerVariables.phoneSelected === 'DHP' && offerVariables.internationalDialing && offerVariables.internationalDialing.product) {
					let flgSelected: boolean = false;
					let attributes: AttributesCombination[] = [];
					if (offerVariables.internationalDialing && offerVariables.internationalDialing.product && offerVariables.internationalDialing.product.productAttributes) {
						offerVariables.internationalDialing.product.productAttributes.forEach(attr => {
							if ((attr && attr.compositeAttribute !== null && attr.compositeAttribute.length === 0)) {
								attributes.push(attr);
							}
							if ((attr && attr.compositeAttribute !== null && attr.compositeAttribute && attr.compositeAttribute.length !== 0
								&& attr.compositeAttribute[0].attributeName !== 'Service Status')) {
								attributes.push(attr);
							}
							if ((!offerVariables.existingServices && attr && attr.compositeAttribute !== null && attr.compositeAttribute && attr.compositeAttribute.length !== 0
								&& attr.compositeAttribute[0].attributeName === 'Service Status')) {
								if (!flgSelected && offerVariables.isInternational && attr.compositeAttribute[0]
									&& (attr.compositeAttribute[0].attributeValue === 'Enabled' ||
										attr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes')) {
									attributes.push(attr);
									flgSelected = true;
								} else if (!flgSelected && !offerVariables.isInternational && attr.compositeAttribute[0]
									&& (attr.compositeAttribute[0].attributeValue === 'Disabled' ||
										attr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'no')) {
									attributes.push(attr);
									flgSelected = true;
								}
							}
							if ((offerVariables.existingServices && attr && attr.compositeAttribute !== null && attr.compositeAttribute && attr.compositeAttribute.length !== 0
								&& attr.compositeAttribute[0].attributeName === 'Service Status')) {
								if (offerVariables.dhpExisting && !offerVariables.dhpIntlCalled) {
									let dhp = this.getExistingProducts(offerVariables.existingServices, GenericValues.cDHP);
									if (dhp && dhp.customerOrderSubItems !== null && dhp.customerOrderSubItems
										&& dhp.customerOrderSubItems.length !== 0) {
										dhp.customerOrderSubItems.forEach(subItems => {
											if (subItems && subItems.productName === 'Digital Home Phone Intl Call') {
												subItems.productAttributes.forEach(subAttr => {
													if ((subAttr && subAttr.compositeAttribute !== null && subAttr.compositeAttribute.length !== 0
														&& subAttr.compositeAttribute[0].attributeName === 'Service Status')) {
														attributes.push(subAttr);
														subAttr.compositeAttribute[0].attributeValue === 'Enabled'
															|| subAttr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes' ? offerVariables.dhpIntlSelected = 'Yes' :
															offerVariables.dhpIntlSelected = 'No';
														offerVariables.dhpIntlExisting = cloneDeep(offerVariables.dhpIntlSelected);
													}
												});
											}
										});
									}
								}
								else {
									if (!flgSelected && offerVariables.isInternational && attr.compositeAttribute[0]
										&& (attr.compositeAttribute[0].attributeValue === 'Enabled' ||
											attr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes')) {
										attributes.push(attr);
										flgSelected = true;
									} else if (!flgSelected && !offerVariables.isInternational && attr.compositeAttribute[0]
										&& (attr.compositeAttribute[0].attributeValue === 'Disabled' ||
											attr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'no')) {
										attributes.push(attr);
										flgSelected = true;
									}
								}
							}
						});
					}
					let product = offerVariables.internationalDialing.product;
					product = {
						productId: product.productId,
						productName: product.productName,
						productType: product.productType,
						componentType: offerVariables.internationalDialing.componentType,
						productAttributes: attributes,
						productAssociations: product.productAssociations,
						productCategory: product.productCategory,
						quantity: 1
					}
					if (offerVariables.existingServices && product) { product.action = !offerVariables.dhpExisting ? 'ADD' : offerVariables.dhpIntlExisting === offerVariables.dhpIntlSelected ? 'NOCHANGE' : 'CHANGE'; }
					if (offerVariables.flow === 'stackAmend') { product.action = offerVariables.isLatestPendingOrderNI && offerVariables.isAmend ? 'ADD' : !offerVariables.dhpExisting ? 'ADD' : offerVariables.dhpIntlExisting === offerVariables.dhpIntlSelected ? 'NOCHANGE' : 'CHANGE'; }
					subOrderItems.push(product);
				}
			}
			let actn = this.checkExistingOfferingId(offerVariables, dhpProduct, offerVariables.selectedDHPOffer, 'dhp', 'any-filter');
			if (offerVariables.existingServices) {
				if (actn !== 'CHANGE' && dhpExist) {
					actn = offerVariables.dhpIntlExisting === offerVariables.dhpIntlSelected ? 'NOCHANGE' : 'CHANGE'
				}
			}
			orderItem = {
				catalogId: offerVariables.phoneSelected === 'HMP' ? offerVariables.phoneCatalogId : offerVariables.hsiCatalogId,
				productOfferingId: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOfferingId,
				offerType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerType,
				offerSubType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerSubType,
				offerCategory: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerCategory,
				quantity: 1,
				rc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.rc : 0,
				discountedRc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
				otc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.otc : 0,
				discountedOtc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
				customerOrderSubItems: subOrderItems,
				offerName: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerName
			};
			if (offerVariables.existingServices) {
				orderItem.catalogId = offerVariables.phoneCatalogId ? offerVariables.phoneCatalogId : offerVariables.hsiCatalogId;
				orderItem.action = (!dhpExist && offerVariables.phoneSelected === 'DHP') || (!hpExist && offerVariables.phoneSelected === 'HMP') ? 'ADD' : actn;
				orderItem.contractTerm = offerVariables.cartContractTermDHP ? offerVariables.cartContractTermDHP : '0';
				if (offerVariables.flow === 'stackAmend') {
					orderItem.action = (offerVariables.isLatestPendingOrderNI || offerVariables.potsAddAction) && offerVariables.isAmend ? 'ADD' : (!dhpExist && offerVariables.phoneSelected === 'DHP') || (!hpExist && offerVariables.phoneSelected === 'HMP') ? 'ADD' : actn;
				}
				if (offerVariables.isDHPRemoved && ((offerVariables.removedProductItem[0].offerCategory === GenericValues.cDHP && offerVariables.phoneSelected === 'HMP') || (offerVariables.removedProductItem[0].offerCategory === GenericValues.cHP && offerVariables.phoneSelected === 'DHP'))) {
					orderItem.action = 'ADD';
				}
				if (!offerVariables.isLatestPendingOrderNI && offerVariables.isAmend && orderItem.action === 'NOCHANGE' &&
					!offerVariables.isInternetRemoved && !offerVariables.internetCheck && offerVariables.hsiExistingOnCompleted) {
						orderItem.action = 'CHANGE';
				}
			}
			if (offerVariables.existingServices && offerVariables.flow === 'MOVE') {
				orderItem.catalogId = offerVariables.phoneCatalogId ? offerVariables.phoneCatalogId : offerVariables.hsiCatalogId;
				orderItem.contractTerm = offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.contract.contractTerm;
			}
			orderItemstoSend.push(orderItem);
			let e911 = {};
			let dhpAdditionalInfo = {};
			if (offerVariables.phoneSelected === 'DHP') {
				if (offerVariables.holdCalled && !offerVariables.existingServices) {
					let userSubscribe = user.subscribe(
						(data) => {
							let usr: any;
							usr = data;
							let address = usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.serviceAddress;
							e911 = {
								streetDirectionPrefix: '',
								streetAddress: address.streetAddress,
								location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
								streetNrFirst: address.streetNrFirst,
								city: address.city ? address.city : address.locality,
								stateOrProvince: address.stateOrProvince,
								postCode: address.postCode,
								postCodeSuffix: address.postCodeSuffix
							};
						});
					if (userSubscribe !== undefined) { userSubscribe.unsubscribe(); }
				} else {
					if (!offerVariables.existingServices || (offerVariables.existingServices && offerVariables.e911ValidatedAddress)) {
						e911 = {
							"streetDirectionPrefix": offerVariables.e911ValidatedAddress.streetDirectionPrefix,
							"streetAddress": offerVariables.e911ValidatedAddress.streetAddress,
							"location": offerVariables.e911ValidatedAddress.location,
							"streetNrFirst": offerVariables.e911ValidatedAddress.streetNrFirst,
							"city": offerVariables.e911ValidatedAddress.city,
							"stateOrProvince": offerVariables.e911ValidatedAddress.stateOrProvince,
							"postCode": offerVariables.e911ValidatedAddress.postCode,
							"postCodeSuffix": offerVariables.e911ValidatedAddress.postCodeSuffix
						};
					}
				}
				dhpAdditionalInfo = {
					e911Address: e911,
					dhpDisclaimerAcceptDateTime: offerVariables.holdCalled ? new Date().toISOString() : offerVariables.e911ValidatedAddress && offerVariables.e911ValidatedAddress.acceptedData
				}
			}
			payload = this.getpayloadToSend(offerVariables, orderItemstoSend, payload, dhpAdditionalInfo);


			if (offerVariables.flow === 'stackAmend') {
				if (offerVariables.phoneSelected === 'DHP' && offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
					dhpAdditionalInfo = offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument && offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo;
				}
				if(offerVariables.phoneSelected === 'DHP') { payload.dhpAdditionalInfo = dhpAdditionalInfo; }
			}

			if (offerVariables.existingServices) {
				if (offerVariables.isInternetRemoved) {
					this.serviceTerminate(offerVariables);
					offerVariables.removedProductItem.forEach(item => {
						if (!offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
							offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
								if (item.offerCategory === exItem.offerCategory) {
									orderItemstoSend.push(item);
								}
							})
						} else {
							orderItemstoSend.push(item);
						}
					});
				}
				if (offerVariables.isOptedOut) {
					this.serviceTerminate(offerVariables);
					offerVariables.removedProductItem.forEach(item => {
						orderItemstoSend.push(item);
					});
				}
				if (!offerVariables.internetCheck && !offerVariables.isLatestPendingOrderNI && offerVariables.isAmend && !offerVariables.isInternetRemoved) {
					offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
						if (exItem.offerCategory === GenericValues.iData) {
							let item = cloneDeep(exItem);
							item.action = 'REMOVE';
							item && item.customerOrderSubItems && item.customerOrderSubItems.map(subItem => {
								subItem.action = 'REMOVE';
							})
							orderItemstoSend.push(item);
						}
					})
				}
			}
		}

		if (offerVariables.existingServices) {
			if ((offerVariables.isInternetRemoved && offerVariables.serviceTerminationInfo !== undefined) || (offerVariables.isOptedOut &&
				offerVariables.serviceTerminationInfo !== undefined)) {
				payload = Object.assign({},
					payload, {
					servicesTerminationInfo: offerVariables.serviceTerminationInfo
				}
				);
			}
		}
		if (!offerVariables.existingServices) {
			offerVariables.cartObject = {
				success: offerVariables.offerResponse.success,
				orderRefNumber: offerVariables.offerResponse.orderRefNumber,
				processInstanceId: offerVariables.offerResponse.processInstanceId,
				taskId: offerVariables.offerResponse.taskId,
				taskName: offerVariables.offerResponse.taskName,
				payload: payload
			};
		}
		else {
			if (offerVariables.isConverted) {
				this.store.dispatch({ type: 'IS_CONVERTED', payload: true });
				payload = Object.assign({},
					payload, {
						addlOrderAttributes: [
							{
								"orderAttributeGroup": [
									{
										"orderAttributeGroupName": "convertToPurchaseModem",
										"orderAttributeGroupInfo": [
											{
												"orderAttributes": [
													{
														"orderAttributeName": "convertToPurchase",
														"orderAttributeValue": "YES"
													}
												]
											}
										]
									}
								]
							}
						]
				}
				);
			} else {
				this.store.dispatch({ type: 'IS_CONVERTED', payload: false });
			}
			offerVariables.cartObject = {
				success: offerVariables.offerResponse.success || true,
				orderRefNumber: offerVariables.offerResponse.orderRefNumber || offerVariables.orderRefNumber,
				processInstanceId: offerVariables.offerResponse.processInstanceId || offerVariables.processInstanceId,
				taskId: offerVariables.offerResponse.taskId || offerVariables.taskId,
				taskName: 'Get Addon Offers',
				payload: payload
			};
			this.checkDiscountSelected(offerVariables);
		}
	}

	private isMonthly(subOrderItem: Products, isMonthlyCharge: boolean) {
		isMonthlyCharge = false;
		subOrderItem.productAttributes[0].prices.forEach(price => {
			if (price.rc > 0) {
				isMonthlyCharge = true;
			}
		});
		return isMonthlyCharge;
	}

	public getpayload(offerVariables, orderItems, payload) {
		payload = {
			success: true,
			cart: {
				catalogSpecId: offerVariables.catalogSpecId,
				customerOrderItems: orderItems
			}

		};
		if (offerVariables.existingServices && offerVariables.flow !== 'MOVE') {
			payload.productConfiguration = offerVariables.configSelected;
		}
		if (offerVariables.flow !== 'BILLING' || (offerVariables.flow === 'BILLING' && offerVariables.offerBillingType === 'PREPAID')) {
			payload.billingType = offerVariables.offerBillingType === 'PREPAID' ? offerVariables.offerBillingType : 'POSTPAID';
		}
		return payload;
	}
	public getReentrantPayload(offerVariables, payload, orderItems, addons, cartDisc) {
		payload = {
			success: true,
			cart: {
				catalogSpecId: offerVariables.catalogSpecId,
				customerOrderItems: orderItems
			},
			customerAddonOfferItems: addons,
			productConfiguration: offerVariables.configSelected
		};
		let eligibleDiscounts = [];
		if (cartDisc && cartDisc !== undefined && cartDisc.length > 0) {
			cartDisc.forEach(disc => {
				offerVariables.discountsAdded.forEach(addedDisc => {
					if (disc.discountId === addedDisc.discountId) {
						eligibleDiscounts.push(addedDisc);
					}
				});
			});
		}
		if ((!offerVariables.existingServices && eligibleDiscounts !== null && eligibleDiscounts.length > 0 && offerVariables.selectedDiscountsActive) || (offerVariables.flow === 'BILLING' && offerVariables.isPendingFlow)) {
			payload.discountItems = eligibleDiscounts;
			return payload;
		} else {
			return payload;
		}
	}


	public getpayloadToSend(offerVariables, orderItemstoSend, payload, dhpAdditionalInfo) {
		payload = {
			cart: {
				catalogSpecId: offerVariables.catalogSpecId,
				customerOrderItems: orderItemstoSend
			},
			productConfiguration: offerVariables.configSelected
		};
		
		if (offerVariables.flow !== 'BILLING') {
			payload.billingType = offerVariables.offerBillingType === 'PREPAID' ? offerVariables.offerBillingType : 'POSTPAID';
		}
		if (offerVariables.existingServices && (offerVariables.isDHPRemoved || offerVariables.isRemoved) && offerVariables.serviceTerminationInfo !== undefined) {
			payload = Object.assign({},
				payload, {
				servicesTerminationInfo: offerVariables.serviceTerminationInfo
			}
			);
		}
		if ((offerVariables.phoneOffer && offerVariables.selectedDHPOffer && !offerVariables.existingServices) || (offerVariables.phoneOffer && offerVariables.existingServices)) {
			payload.dhpAdditionalInfo = dhpAdditionalInfo;
		}
		return payload;
	}

	/********************************************/
	/* Service Calls for Offer Page(s)  - Start */
	/********************************************/

	public getTechnologyTypes(offerVariables: OfferVariables) {
		this.logger.log("info", "offerHelper.service.ts", "getTechnologyTypesRequest", JSON.stringify(""));
		this.logger.startTime();
		offerVariables.loading = true;
		this.productService
			.getTechnologyTypes()
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offerHelper.service.ts", "getTechnologyTypesResponse", JSON.stringify(error));
				this.logger.log("error", "offerHelper.service.ts", "getTechnologyTypesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
				offerVariables.loading = false;
				this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "getTechnologyTypes", "offerHelper.service.ts", "getTechnologyTypes", error);
				return Observable.throwError(null);
			})
			.subscribe(
				respData => {
					this.logger.endTime();
					this.logger.log("info", "offerHelper.service.ts", "getTechnologyTypesResponse", JSON.stringify(respData ? respData : ""));
					this.logger.log("info", "offerHelper.service.ts", "getTechnologyTypesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.loading = false;
					offerVariables.technologyTypes = respData;
				},
				error => {
					this.logger.endTime();
					this.logger.log("error", "offerHelper.service.ts", "getTechnologyTypesResponse", JSON.stringify(error));
					this.logger.log("error", "offerHelper.service.ts", "getTechnologyTypesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					offerVariables.loading = false;
					if (error === undefined || error === null) { return; }
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						let apiResponseError = JSON.parse(error);
						if (
							apiResponseError !== undefined &&
							apiResponseError !== null &&
							apiResponseError.errorResponse &&
							apiResponseError.errorResponse.length > 0
						) {
							this.systemErrorService.logAndeRouteToSystemError(
								"error",
								"selectProductError ",
								"offerHelper.service.ts",
								"Offers Page",
								apiResponseError
							);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
							offerVariables.orderRefNumber
						);
						this.systemErrorService.logAndeRouteToSystemError(
							"error",
							"selectProductError ",
							"offerHelper.service.ts",
							"Offers Page",
							lAPIErrorLists
						);
					}
					offerVariables.retrieveOffersLoading = false;
				}
			);
	}

	public giftCardRules(selectedspeed, offerVariables) {
		let user = <Observable<User>>this.store.select('user');
		let applicableGiftcard: any = [];
		let catalogName: string;
		let customize = <Observable<any>>this.store.select('customize');
		let customizeSubscription = customize.subscribe((data) => {
			data.giftcards && data.giftcards.forEach((x: any) => {
				if (x.offerCategory === "INTERNET") {
					x.eligibleGiftCardOffer.forEach((g: any) => {
						if(x.offerName === selectedspeed && g.relationType === 'M') {
							 if(applicableGiftcard.indexOf(g.giftcardOfferName) === -1) { 
								 applicableGiftcard.push(g.giftcardOfferName);
							 }
						}
					});
				} else if (x.offerCategory === "VOICE-HP" || x.offerCategory === "VOICE-DHP" || x.offerCategory === "VIDEO-DTV") {
					x.eligibleGiftCardOffer.forEach((g: any) => {
						if(g.relationType === 'M') { 
							if(applicableGiftcard.indexOf(g.giftcardOfferName) === -1) {
								applicableGiftcard.push(g.giftcardOfferName);
							}
						}
					});
				}
			});
			if (data && data.offers) {
				data.offers.forEach((items: any) => {
					if (items.serviceCategory === 'DATA' && items.catalogs && items.catalogs[0].catalogName) { catalogName = items.catalogs[0].catalogName; }
				});
			} else {
				return;
			}
		});
		if (customizeSubscription) { customizeSubscription.unsubscribe(); }
		let eligibilityRequest = {
			"catalogName": catalogName,
			"city": "",
			"giftCardOfferName": applicableGiftcard,
			"state": "",
			"wireCenter": ""
		};
		let userSubscription = user.subscribe((data) => {
			eligibilityRequest.wireCenter = data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.wirecenter
			eligibilityRequest.city = data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.city;
			eligibilityRequest.state = data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.stateOrProvince;
		});
		if (userSubscription) { userSubscription.unsubscribe(); }
		this.store.dispatch({ type: 'ELIGIBLE_GIFTCARDS', payload: applicableGiftcard });
		if (applicableGiftcard && applicableGiftcard.length > 0) {
			this.logger.log("info", "offerHelper.service.ts", "giftcardCompatibilityRequest", JSON.stringify(eligibilityRequest));
			this.logger.startTime();
			offerVariables.loading = true;
			this.productService.giftCardEligibilityAndRelation(eligibilityRequest)
				.catch((error: any) => {
					this.logger.endTime();
					this.logger.log("error", "offerHelper.service.ts", "giftcardCompatibilityResponse", error);
					this.logger.log("error", "offerHelper.service.ts", "giftcardCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "submitTask - updateCart", "offerHelper.service.ts", "Product Offer Page", error);
                    return Observable.throwError(null);
				})
				.subscribe((data) => {
					this.logger.endTime();
					this.logger.log("info", "offerHelper.service.ts", "giftcardCompatibilityResponse", JSON.stringify(data ? data : ''));
					this.logger.log("info", "offerHelper.service.ts", "giftcardCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					this.store.dispatch({ type: 'GIFT_COMPATIBILITY_RULES', payload: data });
				},
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "offerHelper.service.ts", "giftcardCompatibilityResponse", error);
                    this.logger.log("error", "offerHelper.service.ts", "giftcardCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    if (error === undefined || error === null) return;
                });
		}

	}

	public compatibilityAPIcall(offerVariables: OfferVariables) {
		this.logger.log("info", "offerHelper.service.ts - getCompatibilityRules", "fetchRuleRequest", JSON.stringify(""));
		this.logger.startTime();
		offerVariables.loading = true;
		this.productService.getCompatibilityRules()
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offerHelper.service.ts - getCompatibilityRules", "fetchRuleResponse", error);
				this.logger.log("error", "offerHelper.service.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				offerVariables.loading = false;
				this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "SUBMIT_TASK", "offerHelper.service.ts", "CustomizeService Page", error);
				return Observable.throwError(null);
			})
			.subscribe((data) => {
				this.logger.endTime();
				this.logger.log("info", "offerHelper.service.ts - getCompatibilityRules", "fetchRuleResponse", JSON.stringify(data ? data : ''));
				this.logger.log("info", "offerHelper.service.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				offerVariables.compatibilityArray = data;
				this.store.dispatch({ type: 'COMPATIBILITY_RULES', payload: data });
			},
				(error) => {
					this.logger.endTime();
					this.logger.log("error", "offerHelper.service.ts - getCompatibilityRules", "fetchRuleResponse", error);
					this.logger.log("error", "offerHelper.service.ts - getCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.loading = false;
					if (error === undefined || error === null) {
						return;
					}
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						let apiResponseError = JSON.parse(error);
						if (apiResponseError !== undefined && apiResponseError !== null && apiResponseError.errorResponse &&
							apiResponseError.errorResponse.length > 0) {
							this.systemErrorService.logAndeRouteToSystemError("error", "fetchRulesError", "offerHelper.service.ts", "Offer Helper Service", apiResponseError);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
						this.systemErrorService.logAndeRouteToSystemError("error", "fetchRulesError", "offerHelper.service.ts", "Offer Helper Service", lAPIErrorLists);
					}
					window.scroll(0, 0);
				});
	}

	public checkCSCompatibitlity(offerVariables) {
		this.logger.log("info", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRuleRequest", JSON.stringify(""));
		this.logger.startTime();
		offerVariables.loading = true;
		this.productService.getCSCompatibilityRules()
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRuleResponse", error);
				this.logger.log("error", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				offerVariables.loading = false;
				this.systemErrorService.logAndRouteUnexpectedError(
					"error", "Not Applicable",
					"SUBMIT_TASK", "offerHelper.service.ts",
					"CustomizeService Page",
					error);
				return Observable.throwError(null);
			})
			.subscribe((data) => {
				this.logger.endTime();
				this.logger.log("info", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRuleResponse", JSON.stringify(data ? data : ''));
				this.logger.log("info", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				offerVariables.loading = false;
				offerVariables.csCompatibility = data;
				this.csForPurchasedModem(offerVariables);
				// this.store.dispatch({ type: 'COMPATIBILITY_RULES', payload: data });
			},
				(error) => {
					this.logger.endTime();
					this.logger.log("error", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRuleResponse", error);
					this.logger.log("error", "offerHelper.service.ts - getCSCompatibilityRules", "fetchRulesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.loading = false;
					if (error === undefined || error === null) {
						return;
					}
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						let apiResponseError = JSON.parse(error);
						if (apiResponseError !== undefined && apiResponseError !== null && apiResponseError.errorResponse &&
							apiResponseError.errorResponse.length > 0) {
							this.systemErrorService.logAndeRouteToSystemError("error", "fetchRulesError", "offerHelper.service.ts", "Offer Helper Service", apiResponseError);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
						this.systemErrorService.logAndeRouteToSystemError("error", "fetchRulesError", "offerHelper.service.ts", "Offer Helper Service", lAPIErrorLists);
					}
					window.scroll(0, 0);
				});
	}

	public csForPurchasedModem(offerVariables) {
		if (offerVariables.csCompatibility && offerVariables.csCompatibility.outputAttribute && offerVariables.csCompatibility.outputAttribute.length > 0) {
			let cyberSecurityDisplay = offerVariables.csCompatibility.outputAttribute[0];
			if (cyberSecurityDisplay[3].toLowerCase() === 'yes') {
				offerVariables.isCSCompatible = true;
			}
		}
	}

	/********************************************/
	/* Service Calls for Offer Page(s)  - Stop  */
	/********************************************/
	public staticPotsOffer() {
		return {
			"productOffer": {
				"productOfferingId": "EO000417",
				"offerName": "Price for Life Internet, Voice Package with ULD",
				"offerDisplayName": "Price for Life Internet and Home Phone with Unlimited LD",
				"offerType": "P4L",
				"offerSubType": "P4L",
				"offerCategory": "VOICE-HP",
				"offerAttributes": [
					{
						"attributeName": "with-INTERNET",
						"attributeValue": "YES"
					},
					{
						"attributeName": "withPhone-DHP",
						"attributeValue": "NO"
					},
					{
						"attributeName": "withPhone-HP",
						"attributeValue": "YES"
					},
					{
						"attributeName": "withTV-DTV",
						"attributeValue": "NO"
					},
					{
						"attributeName": "withTV-PRISM",
						"attributeValue": "NO"
					},
					{
						"attributeName": "isPriceForLife",
						"attributeValue": "YES"
					},
					{
						"attributeName": "bundlePromoId",
						"attributeValue": "420EQ"
					},
					{
						"attributeName": "priceTier",
						"attributeValue": "NO RESTRICTION"
					},
					{
						"attributeName": "noOfHighestSpeedsInTier",
						"attributeValue": "0"
					},
					{
						"attributeName": "EN_OFFER_TYPE",
						"attributeValue": "NON STANDALONE-BUNDLE"
					},
					{
						"attributeName": "speedGrandfathered",
						"attributeValue": "N"
					},
					{
						"attributeName": "qualificationColorName",
						"attributeValue": "GREEN"
					}
				],
				"productComponents": [
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "2",
							"grpMinSelect": "2",
							"grpMaxSelect": "2",
							"iSConfigurableOnAddOn": null,
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Other Features",
							"productId": "EP0052",
							"productName": "Long Distance  - IntraLata",
							"productDisplayName": "Long Distance  - IntraLata",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Long Distance  - IntraLata",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 5.0,
											"otc": 0.0,
											"discountedRc": 5.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": true,
						"isDefault": 0,
						"displayOrder": 0
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0063",
							"productName": "60 Select Call Reject",
							"productDisplayName": "60 Select Call Reject",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~60 Select Call Reject",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "AINP",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 3
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0046",
							"productName": "Caller ID With Call Waiting",
							"productDisplayName": "Caller ID With Call Waiting",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Caller ID With Call Waiting",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 14
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "2",
							"grpMinSelect": "1",
							"grpMaxSelect": "1",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "No",
							"selectionTextForUi": null,
							"productSubCategory": "VAS",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Other Features",
							"productId": "EP0139",
							"productName": "Call Detail",
							"productDisplayName": "Call Detail",
							"productType": "VOICE-HP",
							"productCategory": "VAS~CD",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "printOnBill",
											"attributeValue": "Yes",
											"uom": "NA",
											"attributeDisplayName": "Yes"
										}
									],
									"displayOrder": 1,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Detail",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 2
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "printOnBill",
											"attributeValue": "No",
											"uom": "NA",
											"attributeDisplayName": "No"
										}
									],
									"displayOrder": 1,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 1
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": true,
						"isDefault": 0,
						"displayOrder": 0
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "2",
							"grpMinSelect": "1",
							"grpMaxSelect": "1",
							"iSConfigurableOnAddOn": null,
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Other Features",
							"productId": "EP0051",
							"productName": "Economic Features Pack",
							"productDisplayName": "Economic Features Pack",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Economic Features Pack",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 2.85,
											"otc": 0.0,
											"discountedRc": 2.85,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": true,
						"isDefault": 0,
						"displayOrder": 0
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": "Call Forwarding"
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0032",
							"productName": "Call Forwarding  - Busy",
							"productDisplayName": "Call Forwarding  - Busy",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Forwarding  - Busy",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 6
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": "Call Forwarding"
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0072",
							"productName": "Call Forwarding",
							"productDisplayName": "Call Forwarding",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Forwarding",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 5
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0085",
							"productName": "Call Rejection   - Anonymous",
							"productDisplayName": "Call Rejection   - Anonymous",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Rejection   - Anonymous",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 10
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0071",
							"productName": "3 Way Calling",
							"productDisplayName": "3 Way Calling",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~3 Way Calling",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 2
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "6",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-VM",
							"subGroup": "Voice Mail"
						},
						"product": {
							"productCategoryDisplayName": "Voice Mail Features",
							"productId": "EP0040",
							"productName": "Voice Mail  - Visual",
							"productDisplayName": "Voice Mail  - Visual",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Voice Mail  - Visual",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 23
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0089",
							"productName": "Long Distance Alert",
							"productDisplayName": "Long Distance Alert",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Long Distance Alert",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 16
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0075",
							"productName": "Busy Redial",
							"productDisplayName": "Busy Redial",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Busy Redial",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 4
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0029",
							"productName": "Caller ID",
							"productDisplayName": "Caller ID",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Caller ID",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 13
					},
					{
						"additionalUiAttrProduct": null,
						"product": {
							"productCategoryDisplayName": null,
							"productId": "EP0033",
							"productName": "Inside Wire Maintenance Plan-R",
							"productDisplayName": "Inside Wire Maintenance Plan-R",
							"productType": "VOICE-HP",
							"productCategory": "VAS~WIRE",
							"quantity": null,
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Inside Wire Maintenance Plan-R",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 10.0,
											"otc": 0.0,
											"discountedRc": 10.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Level",
											"attributeValue": "IWM",
											"uom": "NA",
											"attributeDisplayName": "IWM"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 0
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": "Call Forwarding"
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0078",
							"productName": "Call Forwarding  - No Answer",
							"productDisplayName": "Call Forwarding  - No Answer",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Forwarding  - No Answer",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 8
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0048",
							"productName": "Call Forwarding  - Busy Fixed",
							"productDisplayName": "Select Call Forwarding",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Forwarding  - Busy Fixed",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "AINP",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 21
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0076",
							"productName": "Security Screen",
							"productDisplayName": "Security Screen",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Security Screen",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 19
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0030",
							"productName": "Selective Call Waiting ID",
							"productDisplayName": "Selective Call Waiting ID",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Selective Call Waiting ID",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 20
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0098",
							"productName": "No Solicitation",
							"productDisplayName": "No Solicitation",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~No Solicitation",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 18
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "6",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-VM",
							"subGroup": "Voice Mail"
						},
						"product": {
							"productCategoryDisplayName": "Voice Mail Features",
							"productId": "EP0077",
							"productName": "Voice Mail  - Indicator",
							"productDisplayName": "Voice Mail  - Indicator",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Voice Mail  - Indicator",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 22
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": null,
							"grpMinSelect": null,
							"grpMaxSelect": null,
							"iSConfigurableOnAddOn": null,
							"includedFlag": "No",
							"selectionTextForUi": null,
							"productSubCategory": null,
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Equipment",
							"productId": "EP0061",
							"productName": "Jack and Wire",
							"productDisplayName": "Need new jacks or wiring?",
							"productType": "WIRINGWORKS",
							"productCategory": "OPT-EQP-CORE",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Installation Number",
											"attributeValue": "0",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Shipping Method",
											"attributeValue": "Tech",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Shipping Method",
											"attributeValue": "Standard",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Shipping Method",
											"attributeValue": "Overnight",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Quantity",
											"attributeValue": "0",
											"uom": "NA",
											"attributeDisplayName": null
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Installation Number",
											"attributeValue": "No work is needed",
											"uom": null,
											"attributeDisplayName": "No work is needed"
										}
									],
									"displayOrder": 1,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Jack and Wire~Installation Number=No work is needed",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/NRC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": null,
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 1
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Installation Number",
											"attributeValue": "1",
											"uom": null,
											"attributeDisplayName": "1 jack"
										}
									],
									"displayOrder": 2,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Jack and Wire~Installation Number=1",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 99.0,
											"discountedRc": 0.0,
											"discountedOtc": 99.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 2
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 17
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "6",
							"grpMinSelect": "0",
							"grpMaxSelect": "2",
							"iSConfigurableOnAddOn": null,
							"includedFlag": "No",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-VM",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Voice Mail Features",
							"productId": "EP0079",
							"productName": "Voice Messaging",
							"productDisplayName": "Voice Mail",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Voice Messaging",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Yes"
										}
									],
									"displayOrder": 1,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 1
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "No"
										}
									],
									"displayOrder": 2,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 2
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 21
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": null,
							"grpMinSelect": null,
							"grpMaxSelect": null,
							"iSConfigurableOnAddOn": null,
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "CORE",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Core",
							"productId": "EP0055",
							"productName": "First Phone (P4L)",
							"productDisplayName": "First Phone (P4L)",
							"productType": "VOICE-HP",
							"productCategory": "CORE",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "FreezeTPVRequired",
											"attributeValue": "FALSE",
											"uom": "NA",
											"attributeDisplayName": "FALSE"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~First Phone (P4L)",
											"priceType": "BILLING",
											"priceTypeDescription": "Subscriber Line Charge",
											"rc": 6.5,
											"otc": 0.0,
											"discountedRc": 6.5,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										},
										{
											"priceKey": "ES00990~EC00990~EO000417~First Phone (P4L)",
											"priceType": "BILLING",
											"priceTypeDescription": "Access Recovery Charge",
											"rc": 0.15,
											"otc": 0.0,
											"discountedRc": 0.15,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										},
										{
											"priceKey": "ES00990~EC00990~EO000417~First Phone (P4L)",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 25.5,
											"otc": 0.0,
											"discountedRc": 25.5,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "0",
											"uom": "NA",
											"attributeDisplayName": "0"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "3",
											"uom": "NA",
											"attributeDisplayName": "3"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "6",
											"uom": "NA",
											"attributeDisplayName": "6"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "9",
											"uom": "NA",
											"attributeDisplayName": "9"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "12",
											"uom": "NA",
											"attributeDisplayName": "12"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "24",
											"uom": "NA",
											"attributeDisplayName": "24"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "48",
											"uom": "NA",
											"attributeDisplayName": "48"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Contract Term",
											"attributeValue": "60",
											"uom": "NA",
											"attributeDisplayName": "60"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Access Technology",
											"attributeValue": "PSTN",
											"uom": "NA",
											"attributeDisplayName": "PSTN"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Ensemble Product Type",
											"attributeValue": "QL",
											"uom": "NA",
											"attributeDisplayName": "QL"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Sub Service Group",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "isFirst",
											"attributeValue": "TRUE",
											"uom": "NA",
											"attributeDisplayName": "TRUE"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Group",
											"attributeValue": "ACCESS",
											"uom": "NA",
											"attributeDisplayName": "ACCESS"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Config Value",
											"attributeValue": "Unmeasured",
											"uom": "NA",
											"attributeDisplayName": "Unmeasured"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Max Quantity",
											"attributeValue": "1",
											"uom": "NA",
											"attributeDisplayName": "1"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Product Sub-Type",
											"attributeValue": "PT",
											"uom": "NA",
											"attributeDisplayName": "PT"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "pooledTNIndicator",
											"attributeValue": "NA",
											"uom": "NA",
											"attributeDisplayName": "NA"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "exchangeKey",
											"attributeValue": "NA",
											"uom": "NA",
											"attributeDisplayName": "NA"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "PRIMARY",
						"isMandatory": true,
						"isDefault": 0,
						"displayOrder": 1
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "6",
							"grpMinSelect": "0",
							"grpMaxSelect": "2",
							"iSConfigurableOnAddOn": null,
							"includedFlag": "No",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-VM",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Voice Mail Features",
							"productId": "EP0092",
							"productName": "Easy Access",
							"productDisplayName": "Easy Access",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Easy Access",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 15
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "2",
							"grpMinSelect": "2",
							"grpMaxSelect": "2",
							"iSConfigurableOnAddOn": null,
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Other Features",
							"productId": "EP0081",
							"productName": "Long Distance  - InterLata",
							"productDisplayName": "Long Distance  - InterLata",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Long Distance  - InterLata",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 5.0,
											"otc": 0.0,
											"discountedRc": 5.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": true,
						"isDefault": 0,
						"displayOrder": 0
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0044",
							"productName": "Call Waiting",
							"productDisplayName": "Call Waiting",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Waiting",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 12
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": null
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0088",
							"productName": "Call Return",
							"productDisplayName": "Call Return",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Return",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 1,
						"displayOrder": 11
					},
					{
						"additionalUiAttrProduct": {
							"selectionGroup": "1",
							"grpMinSelect": "0",
							"grpMaxSelect": "10",
							"iSConfigurableOnAddOn": "Yes",
							"includedFlag": "Yes",
							"selectionTextForUi": null,
							"productSubCategory": "VAS-CF",
							"subGroup": "Call Forwarding"
						},
						"product": {
							"productCategoryDisplayName": "Calling Features",
							"productId": "EP0065",
							"productName": "Call Forwarding  - Remote Activation",
							"productDisplayName": "Call Forwarding  - Remote Activation",
							"productType": "VOICE-HP",
							"productCategory": "VAS",
							"quantity": {
								"minQuantity": 1,
								"maxQuantity": 1,
								"defaultQuantity": 1
							},
							"productAttributes": [
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductDisconnectDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": true,
									"prices": [
										{
											"priceKey": "ES00990~EC00990~EO000417~Call Forwarding  - Remote Activation",
											"priceType": "PRICE",
											"priceTypeDescription": "MRC/OTC",
											"rc": 0.0,
											"otc": 0.0,
											"discountedRc": 0.0,
											"discountedOtc": 0.0,
											"frequency": "1",
											"currencyCode": "USD",
											"provisioningAction": null
										}
									],
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "allowMACD",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Default Price",
											"attributeValue": "Default",
											"uom": "NA",
											"attributeDisplayName": "Default"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Enabled",
											"uom": "NA",
											"attributeDisplayName": "Enabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "Service Status",
											"attributeValue": "Disabled",
											"uom": "NA",
											"attributeDisplayName": "Disabled"
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								},
								{
									"compositeAttribute": [
										{
											"attributeName": "ProductActivationDate",
											"attributeValue": "",
											"uom": "NA",
											"attributeDisplayName": ""
										}
									],
									"displayOrder": 0,
									"isPriceable": false,
									"prices": null,
									"discounts": [

									],
									"isDefault": 0
								}
							],
							"productAssociations": [

							],
							"isRegulated": false
						},
						"componentType": "COMPONENT",
						"isMandatory": false,
						"isDefault": 0,
						"displayOrder": 9
					}
				],
				"associatedOffers": [
					{
						"associatedOfferCategory": "VOICE-HP",
						"associationType": {
							"associationType": "ADDON",
							"selectionRule": "ANY",
							"associatedOfferIds": [
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000061",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000448",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000289",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000062",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000287",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000370",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000447",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000227",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000064",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000138",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000290",
									"discount": null
								}
							]
						}
					},
					{
						"associatedOfferCategory": "WIRINGWORKS",
						"associationType": {
							"associationType": "ADDON",
							"selectionRule": "ANY",
							"associatedOfferIds": [
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000368",
									"discount": null
								},
								{
									"displayOrder": 0,
									"associatedOfferId": "EO000369",
									"discount": null
								}
							]
						}
					}
				],
				"contract": {
					"contractTerm": 0,
					"isPriceLock": false,
					"priceLockDuration": 0,
					"etf": 0.0,
					"currencyCode": null
				},
				"validFor": {
					"saleExpired": "N",
					"bundleSaleExpired": "N",
					"saleEffectiveDate": "2019-06-01T00:00:00.000Z",
					"saleExpirationDate": "2019-07-01T00:00:00.000Z"
				}
			},
			"defaultOfferPrice": {
				"rc": 45.0,
				"otc": 0.0,
				"discountedRc": 45.0,
				"discountedOtc": 0.0
			},
			"productOfferingId": "EO000417",
			"displayOrder": 19,
			"isDefault": 19
		}
	}

	/* resetting back the Account Type attributeValue to 'Lease' before sending the cart in request */
	public resetCartModemAttrValue(subOrderItems) {
		subOrderItems.forEach(item => {
			if (item && item.productName === GenericValues.modem && item.productAttributes && item.productAttributes.length > 0) {
				item.productAttributes[0] = this.updateModemAttrValue(item.productAttributes[0], GenericValues.lease);
			}
		});
		return subOrderItems;
	}

	/* updateing the Account Type attributeValue for Leased Modem with Secure Wifi so that each modem will have unique attribute value(only for UI validations) */
	public updateModemAttrValue(prodAttrs, value) {
		if (prodAttrs && prodAttrs.compositeAttribute) {
			prodAttrs.compositeAttribute = prodAttrs.compositeAttribute.sort(this.sortModemComposite);
			if (prodAttrs.compositeAttribute.filter(attr => (attr.attributeName === GenericValues.cyberSecurity && attr.attributeValue === 'Enabled')).length > 0) {
				prodAttrs.compositeAttribute[0].attributeValue = value;
			}
			return prodAttrs;
		}
	}

	/* display Secure Wifi Component when purchased Modem selected and checking compatibility by rule 177 */
	public displayCS(offerVariables, modem) {
		return offerVariables.isCSCompatible && modem && modem.productAttributes &&
			modem.productAttributes.length > 0 && modem.productAttributes[0].compositeAttribute &&
			modem.productAttributes[0].compositeAttribute[0].attributeValue === 'Purchase';
	}

	/* to make Not needed as default during the reentrant/MACD if Secure Wifi is not added to cart for purchased modem */
	public selectNotNeeded(offerVariables, csComponent) {
		let prodAttrs: AttributesCombination[] = [];
		let component;
		csComponent && csComponent.product && csComponent.product.productAttributes.forEach(prodAttr => {
			prodAttr.compositeAttribute.forEach(comp => {
				if (comp.attributeValue === 'No') {
					prodAttrs.push(prodAttr);
					component = {
						productId: csComponent.product.productId,
						productName: csComponent.product.productName,
						productType: csComponent.product.productType,
						componentType: csComponent.product.componentType,
						productAttributes: prodAttrs,
						productAssociations: csComponent.product.productAssociations,
						productCategory: csComponent.product.productCategory,
						quantity: csComponent.product.quantity
					};

				}
			});
		});
		offerVariables.selectedSecureWifi = component;
	}

	/* storing the display name in the cart since displayName attribute won't be persent in the cart */
	public modemDisplayNameForCart(modem, modemList) {
		let displayName;
		if (modem && modemList && Object.keys(modemList).length > 0) {
			if (modem && modem.productAttributes && modem.productAttributes[0].compositeAttribute.filter(attr => (attr.attributeName === GenericValues.cyberSecurity && attr.attributeValue === 'Enabled')).length > 0) {
				modemList.product.productAttributes.forEach((attr) => {
					if (attr.compositeAttribute.filter(attr => (attr.attributeName === GenericValues.cyberSecurity && attr.attributeValue === 'Enabled')).length > 0) {
						displayName = attr.compositeAttribute[0].attributeDisplayName;
					}
				});
			} else {
				modemList && modemList.product && modemList.product.productAttributes.forEach((attr) => {
					if ((attr && attr.compositeAttribute && attr.compositeAttribute[0].attributeValue.toLowerCase() === (modem.productAttributes && modem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase())) && modem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() === "lease") {
						if (attr.compositeAttribute.filter(a => (a.attributeName === GenericValues.cyberSecurity && a.attributeValue === 'Enabled')).length === 0) {
							displayName = attr.compositeAttribute[0].attributeDisplayName;
						}
					}
				});
			}
		}

		if (displayName) {
			this.store.dispatch({ type: 'LEASED_DISPLAY_NAME', payload: displayName });
		}

	}

	public fetchPrice(product: Products): number {
		let val = 0;
		product && product.productAttributes && product.productAttributes.forEach(attr => {
			attr.isPriceable && attr.prices && attr.prices.forEach(price => {
				val = price.rc
			});
		});
		return val;
	}

	public isPurchasedModem(modem: Products) {
		let isPurchasedModem: boolean = false;
		if (modem && modem.productAttributes && modem.productAttributes.length && (modem.productAttributes.length > 0)) {
			if (modem.productAttributes[0].compositeAttribute && modem.productAttributes[0].compositeAttribute.length && (modem.productAttributes[0].compositeAttribute.length > 0)) {
				if (modem.productAttributes[0].compositeAttribute[0].attributeValue && modem.productAttributes[0].compositeAttribute[0].attributeValue.toLowerCase() === 'purchase') {
					isPurchasedModem = true;
				}
			}
		}
		return isPurchasedModem;
	}

	public removePotsFromRequest(apiRequest, offerVariables) {
		if (offerVariables && offerVariables.phoneSelected === GenericValues.noPhone) {
			if (apiRequest && apiRequest.payload && apiRequest.payload.cart && apiRequest.payload.cart.customerOrderItems) {
				apiRequest.payload.cart.customerOrderItems = apiRequest.payload.cart.customerOrderItems.filter(obj => obj.offerCategory !== 'VOICE-HP');
			}
		}
		return apiRequest;
	}

	public updateShipAndHandlingObj = (offerVariables: OfferVariables, selectedInternetOfferdId) => {
		offerVariables.shippingNHandlingChargeObj = this.shipAndHandlingChargesForSelfInstall(offerVariables.offerResponse, selectedInternetOfferdId);
		if (offerVariables.shippingNHandlingChargeObj) {
			offerVariables.shippingNHandlingCharge = 0;
			offerVariables.shippingNHandlingChargeObj.productAttributes && offerVariables.shippingNHandlingChargeObj.productAttributes.forEach((attr) => {
				if (attr.prices && (attr.prices.length > 0)) {
					attr.prices.forEach((p) => {
						if (p.priceType === 'PRICE') {
							offerVariables.shippingNHandlingCharge += this.ctlHelperService.getSummedOtc(attr.prices);
						}
					});
				}
			});
		}
		if (offerVariables.shippingNHandlingChargeObj && offerVariables.selfinstallSelected) {
			this.shoppingCartRequest(offerVariables);
		}
	}

	public isExAreaCallPresentAndFetchPrice(offerVariables: OfferVariables, data): void {
		let offers = data;
		if (offers && offers.payload && offers.payload.offers && (offers.payload.offers.length > 0)) {
			offers.payload.offers.forEach((offer) => {
				if (offer && (offer.serviceCategory === 'VOICE-HP')) {
					if (offer && offer.catalogs && (offer.catalogs.length > 0) && offer.catalogs[0].catalogItems && (offer.catalogs[0].catalogItems.length > 0)) {
						offer.catalogs[0].catalogItems.forEach((catalogItem) => {
							if (catalogItem && catalogItem.productOffer && catalogItem.productOffer.productComponents && (catalogItem.productOffer.productComponents.length > 0)) {
								catalogItem.productOffer.productComponents.forEach((prodComponent) => {
									if (prodComponent.product && prodComponent.product.productCategory && prodComponent.product.productName && prodComponent.product.productCategory === 'EAC' && prodComponent.product.productName === 'Extended Area Calling') {
										offerVariables.isExtendedAreaCallingPresent = true;
										offerVariables.extendedAreaCallingPrice = this.fetchPrice(prodComponent.product);
									}
								});
							}
						});
					}
				}
			});
		}
	}

	public onChangeExtendedAreaCalling(offerVariables: OfferVariables, value: string) {
		offerVariables.selectedExtendedAreaCalling = undefined;
		if (value === 'Yes') {
			offerVariables.isExtendedAreaCallingYESSelected = true;
			offerVariables.isExtendedAreaCallingNASelected = false;
			offerVariables.selectedHPOffer && offerVariables.selectedHPOffer
				.productOffer.productComponents.forEach(products => {
					if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Extended Area Calling') !== -1) {
						offerVariables.selectedExtendedAreaCalling = this.getDHPComponents(products, offerVariables);
						this.shoppingCartRequest(offerVariables);
					}
				});
		} else if (value === 'No') {
			offerVariables.isExtendedAreaCallingYESSelected = false;
			offerVariables.isExtendedAreaCallingNASelected = false;
			this.shoppingCartRequest(offerVariables);
		} else if (value === 'na') {
			offerVariables.isExtendedAreaCallingYESSelected = false;
			offerVariables.isExtendedAreaCallingNASelected = true;
			this.shoppingCartRequest(offerVariables);
		}
	}
	public legacyValue() {
		let isQwest = false;
		let legacy;
		let currentFlow;
		let currentStore = this.appStateService.getState();
		let userInfo = currentStore.user;
		let existingInfo = currentStore.existingProducts;
		if (existingInfo && existingInfo.orderFlow && existingInfo.orderFlow.flow) {
			currentFlow = existingInfo.orderFlow.flow;
		}
		if (currentFlow === "Change" || currentFlow === "Move" || currentFlow === "COR") {
			legacy = existingInfo.existingProductsAndServices &&
				existingInfo.existingProductsAndServices[0].serviceAddress &&
				existingInfo.existingProductsAndServices[0].serviceAddress.locationAttributes &&
				existingInfo.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
			let legacyFlow = legacy && legacy.split(" ");
			if (legacyFlow && legacyFlow[0] === "QWEST") {
				isQwest = true;
			}

		}
		if (currentFlow !== "Change" && currentFlow !== "Move") {
			if (userInfo && userInfo.orderInit && userInfo.orderInit.payload && userInfo.orderInit.payload.serviceAddress &&
				userInfo.orderInit.payload.serviceAddress.locationAttributes
				&& userInfo.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
				legacy = userInfo.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
				let legacyFlow = legacy && legacy.split(" ");
				if (legacyFlow && legacyFlow[0] === "QWEST") {
					isQwest = true;
				}
			}
		}
		return isQwest;
	}

	public createSlot(offerVariables, expiredSelectedSpeed?) {
		offerVariables.speedList = [];
		let speedList = [];
		speedList = [{
			productName: '',
			productDisplayName: '',
			techInstall: false,
			modem: false,
			tan: false,
			prices: '',
			offerBillingType: '',
			productOfferingId: ''
		}];
		let selectedExpiredOffer = [];
		let orderObservable = <Observable<any>>this.store.select('order');
		let orderSubscription = orderObservable.subscribe(ord => {
			offerVariables.selectedSalesExpiredOfferId = ord.offerId;
			selectedExpiredOffer = (ord.selectedExpiredOffer && ord.selectedExpiredOffer.length) ? ord.selectedExpiredOffer : []
		});
		orderSubscription.unsubscribe();
		if (selectedExpiredOffer.length > 0 && offerVariables.internerOffer.findIndex((a) => a.productOfferingId === selectedExpiredOffer[0].productOfferingId) === -1) {
			offerVariables.internerOffer.push(selectedExpiredOffer[0]);
		}
		let flag: boolean = false;
		if (offerVariables.internerOffer !== undefined && offerVariables.internerOffer.length > 0 && offerVariables.internetCheck) {
			if (expiredSelectedSpeed && expiredSelectedSpeed.productOfferingId) {
				this.findPrimaryProductName(offerVariables.internerOffer, expiredSelectedSpeed.productOfferingId, offerVariables);
			}
			let speedTemp: string = '';
			let custObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
			if (custObj) {
				let existingSpeed: string = this.primaryFromRetain(custObj.existingServiceSubItems ? custObj.existingServiceSubItems : custObj.customerOrderSubItems, GenericValues.cPrimary).productName;
				offerVariables.currentSpeed = existingSpeed;
				// nba preselected Offer
				if (offerVariables.isRecommendationSuccess && offerVariables.recommendedObj['DATA'].productName) {
					existingSpeed = offerVariables.recommendedObj['DATA'].productName;
				} else if (offerVariables.isRecommendationSuccess && offerVariables.recommendedObj['DATA'].offeringId) {
					let speed;
					offerVariables.internerOffer.forEach((item) => {
						let bundle = this.findBundlePromoId(item.productOffer);
						if (item.productOffer.productOfferingId === offerVariables.recommendedObj['DATA'].offeringId) {
							speed = this.searchforPrimary(item.productOffer.productComponents, GenericValues.cPrimary);
						} else if (item.productOffer.offerName === offerVariables.recommendedObj['DATA'].offerName && bundle === offerVariables.recommendedObj['DATA'].bundlePromoId) {
							speed = this.searchforPrimary(item.productOffer.productComponents, GenericValues.cPrimary);
						}
					});
					if (speed && speed.productName) {
						existingSpeed = speed.productName;
					}
				}
				if (offerVariables.flow === 'stackAmend') {
					offerVariables.currentTechnology = this.retrieveTechnologyForSpeed(existingSpeed, '');
				}
			}
			offerVariables.internerOffer.forEach((item) => {
				const speed = this.searchforPrimary(item.productOffer.productComponents,
					GenericValues.cPrimary);
				const prices = this.fetchPriceTypeFromPrimary(speed.productAttributes);
				let flg = false;
				const offerBillingType = item.productOffer.offerBillingType ? item.productOffer.offerBillingType : "POSTPAID"
				let name: any = {
					productName: speed.productName,
					productDisplayName: speed.productDisplayName,
					tan: false,
					prices: prices,
					offerBillingType: offerBillingType,
					productOfferingId: item.productOfferingId
				};
				for (let i = 0; i < speedList.length; i++) {
					if (speedList[i].productOfferingId === item.productOfferingId) {
						flg = true;
					}
				}
				offerVariables.selfInstallOffers = [];
				// adding Unique Speed to the list by filtering from OfferList
				if ((!flg && offerVariables.phoneSelected === 'DHP' && ((item.productOffer.offerBillingType === 'PREPAID' && offerVariables.isPrepaid) ||
					((item.productOffer.offerBillingType === undefined || item.productOffer.offerBillingType === 'POSTPAID' || item.productOffer.offerBillingType === null)
						&& offerVariables.isPostpaid))) || (!flg && offerVariables.phoneSelected !== 'DHP')) {
					if (item.productOffer.offerAttributes !== null && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length !== 0) {
						let offerAdded: boolean = false;
						name.productName = '';
						if (offerVariables && offerVariables.exisitngData && offerVariables.exisitngData.existingProductsAndServices && offerVariables.exisitngData.existingProductsAndServices[0].existingServices
							&& offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems && offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems[0].productOfferingId) {
							if (item.productOfferingId === offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems[0].productOfferingId && (item.productOffer.validFor.bundleSaleExpired === "Y" || item.productOffer.validFor.saleExpired === "Y")) {
								offerVariables.selectedSalesExpiredOfferId = offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems[0].productOfferingId;
							}

						}
						if ((item.productOffer.validFor.bundleSaleExpired === 'N' && item.productOffer.validFor.saleExpired === 'N') || offerVariables.selectedSalesExpiredOfferId === item.productOffer.productOfferingId) // checking for Sales Expired Offers.
						{
							item.productOffer.offerAttributes.forEach((attr) => {
								offerVariables.isTan = false;
								if (!offerAdded && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'yes') {
									item.productOffer.offerAttributes.forEach((checkAttr) => {
										if (checkAttr.attributeName === 'qualificationColorName' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'tan') {
											offerVariables.isTan = true;
											name.tan = offerVariables.isTan;
										}
										if (offerVariables.phoneSelected === 'NoPhone' && offerVariables.videoSelected === 'NoTV' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue.toLowerCase() === 'no') {
											name = this.filterLogic(offerVariables, item, speed);
											if (speedList[0].productName === '') {
												speedList[0] = name;
											} else {
												speedList.push(name);
											}
											if (name.productName === offerVariables.selectedSpeed) { flag = true; }
											if (name.techInstall) { offerVariables.selfInstallOffers.push(name.productName); }
											if (name.modem) { offerVariables.existingModemOffers.push(name.productName); }
											if (custObj && item.productOfferingId === custObj.productOfferingId) { name.productOfferingId = custObj.productOfferingId; }
											offerAdded = true;
										} else if (offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
											name = this.filterLogic(offerVariables, item, speed);
											if (speedList[0].productName === '') {
												speedList[0] = name;
											} else {
												speedList.push(name);
											}
											if (name.productName === offerVariables.selectedSpeed) { flag = true; }
											if (name.techInstall) { offerVariables.selfInstallOffers.push(name.productName); }
											if (name.modem) { offerVariables.existingModemOffers.push(name.productName); }
											if (custObj && item.productOfferingId === custObj.productOfferingId) { name.productOfferingId = custObj.productOfferingId; }
											offerAdded = true;
										} else if ((offerVariables.phoneSelected === 'DHP' || offerVariables.videoSelected !== 'NoTV') && (checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'no')) {
											name = this.filterLogic(offerVariables, item, speed);
											if (speedList[0].productName === '') {
												speedList[0] = name;
											} else {
												speedList.push(name);
											}
											if (name.productName === offerVariables.selectedSpeed) { flag = true; }
											if (name.techInstall) { offerVariables.selfInstallOffers.push(name.productName); }
											if (name.modem) { offerVariables.existingModemOffers.push(name.productName); }
											if (custObj && item.productOfferingId === custObj.productOfferingId) { name.productOfferingId = custObj.productOfferingId; }
											offerAdded = true;
										}
									});
								}
							});
						}
					}
				}
				// calling retaining speed
				// highlighting Offer by checking for isDefault as true from OfferList
				if (!flag && item.isDefault === 1 && !offerVariables.isReEntrant && !offerVariables.oneTimeLoading &&
					item.productOffer.validFor.bundleSaleExpired === 'N' && item.productOffer.validFor.saleExpired === 'N') {
					flag = true;
					offerVariables.selectedSpeed = speed.productName;
					speedTemp = speed.productName;
				}
			});
			offerVariables.AllspeedList = speedList;
			if (offerVariables.offerBillingType === '' || !offerVariables.offerBillingType) {
				offerVariables.offerBillingType = "PREPAID";
			}
			offerVariables.speedList = offerVariables.AllspeedList.filter(speed => { return speed.offerBillingType === offerVariables.offerBillingType });
			if (offerVariables.speedList && offerVariables.speedList.length === 0) {
				offerVariables.offerBillingType = "POSTPAID";
				offerVariables.speedList = offerVariables.AllspeedList.filter(speed => { return speed.offerBillingType === offerVariables.offerBillingType });
			}
			if(!offerVariables.oneTimeLoading) { flag = false; }
			if (offerVariables.oneTimeLoading && flag && !expiredSelectedSpeed) { this.availSpeedChecked(offerVariables.selectedSpeed, offerVariables); }
			if (expiredSelectedSpeed && expiredSelectedSpeed.productOfferingId) {
				this.availSpeedChecked(offerVariables.expiredProduct.productName, offerVariables);
				flag = true;
			}
			if (!flag && !offerVariables.isReEntrant) {
				let custObj = this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.iData, true);
				if (custObj) {
					let existingSpeed: string = this.primaryFromRetain(custObj.existingServiceSubItems ? custObj.existingServiceSubItems : custObj.customerOrderSubItems, GenericValues.cPrimary).productName;
					offerVariables.currentSpeed = existingSpeed;
					if (offerVariables.flow === 'stackAmend') {
						offerVariables.currentTechnology = this.retrieveTechnologyForSpeed(existingSpeed, '');
					}
					for (let i = 0; i < offerVariables.speedList.length; i++) {
						if (offerVariables.speedList[i] && offerVariables.speedList[i].productName === existingSpeed &&
							custObj.productOfferingId === offerVariables.speedList[i].productOfferingId) {
							this.availSpeedChecked(existingSpeed, offerVariables);
							flag = true;
							break;
						}
					}
					offerVariables.offerNoLongerAvailable = '';
				} else {
					this.availSpeedChecked(offerVariables.AllspeedList[0].productName, offerVariables);
					offerVariables.offerNoLongerAvailable = 'This Offer is no longer available. Some product changes may require switching to a different bundle.';
				}

				if (!flag) {
					custObj ? offerVariables.offerNoLongerAvailable = 'This Offer is no longer available. Some product changes may require switching to a different bundle.' :
						offerVariables.offerNoLongerAvailable = '';
					offerVariables.check = true;
					if (speedTemp === '' && offerVariables.speedList && offerVariables.speedList.length > 0
						&& offerVariables.speedList[0].productName) {
						this.availSpeedChecked(offerVariables.speedList[0].productName, offerVariables);
					} else {
						this.availSpeedChecked(speedTemp, offerVariables);
					}
				}
			} else if (offerVariables.isReEntrant) {
				offerVariables.check = true;
				let sts;
				let custObj;
				if (offerVariables.cartCopyObject && offerVariables.cartCopyObject !== undefined) {
					custObj = this.findCustomerOrderObject(offerVariables.cartCopyObject
						&& offerVariables.cartCopyObject.payload
						&& offerVariables.cartCopyObject.payload.cart
						&& offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
				}
				if (custObj && custObj.customerOrderSubItems) {
					sts = this.availSpeedChecked(this.primaryFromRetain(custObj.customerOrderSubItems ? custObj.customerOrderSubItems : custObj.existingServiceSubItems, GenericValues.cPrimary).productName, offerVariables);
				} else {
					sts = 'executionCompletedFlag';
				}
				if (sts === 'executionCompletedFlag' && offerVariables.retrieveOffersLoading && speedTemp === '' && offerVariables.speedList && offerVariables.speedList.length > 0 && offerVariables.speedList[0].productName) {
					this.availSpeedChecked(offerVariables.speedList[0].productName, offerVariables);
				} else if (sts === 'executionCompletedFlag' && offerVariables.retrieveOffersLoading && speedTemp !== '') {
					this.availSpeedChecked(offerVariables.speedList[0].productName, offerVariables);
				}
			}
		} else {
			let phoneObj = offerVariables.isReEntrant ? this.findCustomerOrderObject(offerVariables.cartCopyObject
				&& offerVariables.cartCopyObject.payload
				&& offerVariables.cartCopyObject.payload.cart
				&& offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.cHP, true) :
				this.findCustomerOrderObject(offerVariables.existingServices, GenericValues.cHP, true);
			let offerEnable = false;
			offerVariables.matchingOffers = [];
			offerVariables.phoneOfferData.forEach((items) => {
				if ((items.productOffer.validFor && items.productOffer.validFor.bundleSaleExpired === 'N' && items.productOffer.validFor.saleExpired === 'N') || offerVariables.selectedSalesExpiredOfferId === items.productOfferingId) // checking for Sales Expired Offers.
				{
					if (!offerVariables.videoOffer) {
						if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
							items.productOffer.offerAttributes.forEach((attr) => {
								if (offerVariables.phoneSelected === 'HMP' && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'no') {
									items.productOffer.offerAttributes.forEach((checkAttr) => {
										if (offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
											offerEnable = true;
										}
									});
								}
							});
						}
						if (offerEnable) {
							const offerItemsPhone: OfferItems[] = [];
							const offerItem1: OfferItems = {
								productOfferingId: items.productOfferingId,
								offerName: items.productOffer.offerName,
								offerDisplayName: items.productOffer.offerDisplayName,
								offerCategory: items.productOffer.offerCategory,
								offerBillingType: items.productOffer.offerBillingType ? items.productOffer.offerBillingType : 'Postpaid'
							}
							offerItemsPhone.push(offerItem1);
							const phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
							const phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
							const phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
							const phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
							const priceToAdd: Prices = {
								discountedOtc: phonediscountedOtc,
								discountedRc: phonediscountedRc,
								otc: phoneOtcPrice,
								rc: phoneRcPrice
							}
							let group1: OfferGroup;
							group1 = {
								offerItems: offerItemsPhone,
								prices: [priceToAdd]
							}
							offerVariables.matchingOffers.push(group1);
							if (offerVariables.offerName === null) {
								offerVariables.offerName = offerVariables.matchingOffersArray[0].offerItems[0].offerDisplayName;
							} else {
								let index: any;
								offerVariables.matchingOffers.forEach((off) => {
									if (index === -1) { index = off.offerItems.findIndex((a) => a.offerDisplayName === offerVariables.offerName); }
								});
								if (index === -1) {
									offerVariables.offerName = offerVariables.matchingOffers[0].offerItems[0].offerDisplayName
								}
							}
							let isOfferAvail = false;
							offerVariables.matchingOffers.forEach((offer) => {
								if (offer.offerItems[0].offerDisplayName === offerVariables.offerName) {
									this.selectedBundle(offer, offerVariables);
									isOfferAvail = true;
									flag = true;
								}
							});
							if (!isOfferAvail && (items.isDefault === 1 && !offerVariables.reEntrant && !offerVariables.hpExisting) || (!offerVariables.reEntrant && offerVariables.hpExisting && items.productOfferingId === phoneObj.productOfferingId) ||
								(offerVariables.reEntrant && offerVariables.hpExisting && phoneObj && items.productOfferingId === phoneObj.productOfferingId)) {
								this.selectedBundle(group1, offerVariables);
								flag = true;
							}
						}
					} else if (offerVariables.videoOffer) {
						offerVariables.videorOffer && offerVariables.videorOffer.forEach((dtv) => {
							if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
								items.productOffer.offerAttributes.forEach((attr) => {
									if (offerVariables.phoneSelected === 'HMP' && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'no') {
										items.productOffer.offerAttributes.forEach((checkAttr) => {
											if (offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
												offerEnable = true;
											}
										});
									}
								});
							}
							if (offerEnable) {
								const offerItemsPhone: OfferItems[] = [];
								let offerItem1: OfferItems = {
									productOfferingId: items.productOfferingId,
									offerName: items.productOffer.offerName,
									offerDisplayName: items.productOffer.offerDisplayName,
									offerCategory: items.productOffer.offerCategory,
									offerBillingType: items.productOffer.offerBillingType ? items.productOffer.offerBillingType : 'Postpaid'
								}
								offerItemsPhone.push(offerItem1);
								offerItem1 = {
									productOfferingId: dtv.productOfferingId,
									offerName: items.productOffer.offerName + ' ' + dtv.productOffer.offerName,
									offerDisplayName: items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
									offerCategory: dtv.productOffer.offerCategory
								}
								offerItemsPhone.push(offerItem1);
								const phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
								const phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
								const phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
								const phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
								const priceToAdd: Prices = {
									discountedOtc: dtv.defaultOfferPrice.discountedOtc + phonediscountedOtc,
									discountedRc: dtv.defaultOfferPrice.discountedRc + phonediscountedRc,
									otc: dtv.defaultOfferPrice.otc + phoneOtcPrice,
									rc: dtv.defaultOfferPrice.rc + phoneRcPrice
								}
								let group1: OfferGroup;
								group1 = {
									offerItems: offerItemsPhone,
									prices: [priceToAdd]
								}
								offerVariables.matchingOffers.push(group1);
								if (items.isDefault === 1 && !offerVariables.reEntrant || (offerVariables.reEntrant && offerVariables.reentrantUI && items.productOfferingId === offerVariables.selectedPhoneOfferdId) ||
									(!offerVariables.reEntrant && offerVariables.hpExisting && items.productOfferingId === phoneObj.productOfferingId)) {
									this.selectedBundle(group1, offerVariables);
									flag = true;
								}
							}
						});
					}
				}
				else {
					if (!offerVariables.internetCheck) {
						offerVariables.expiredOffers = [];
					}
					offerVariables.expiredOffers.push(items);
				}
			});
			if (!flag) { this.selectedBundle(offerVariables.matchingOffers[0], offerVariables); }

		}
	}

	public findBundlePromoId(item) {
		let bundle;
		if (item && item.offerAttributes && item.offerAttributes.length > 0) {
			item.offerAttributes.forEach((attr) => {
				if (attr.attributeName === 'bundlePromoId') {
					bundle = attr.attributeValue;
				}
			});
		}

		return bundle;
	}

	public availSpeedChecked(getSpeed: string, offerVariables, flag?) {
		offerVariables.disclosureArrList = [];
		if (!offerVariables.isReEntrant && !offerVariables.oneTimeLoading) {
			offerVariables.secureWifiDefault = true;
			offerVariables.EaseDefault = true;
			offerVariables.JacksWireDefault = true;
		}

		if (flag) {
			offerVariables.undoFlag = true;
			offerVariables.selectedTech = "na";
			if (flag === 'Technology: Unknown, must select') {
				offerVariables.hasTechnology = false;
			}
			else {
				offerVariables.hasTechnology = true;
			}
		}
		else {
			if (offerVariables.selectedTech === "na") {
				offerVariables.hasTechnology = true;
			}
			else {
				offerVariables.hasTechnology = false;
			}
		}

		offerVariables.matchingOffers = [];
		offerVariables.selectedSpeed = getSpeed;
		!offerVariables.existingServices ? offerVariables.matchingOffers = this.offerFilter(offerVariables.internerOffer, getSpeed, GenericValues.sData, GenericValues.cPrimary, offerVariables) :
			offerVariables.matchingOffers = this.offerFilter(offerVariables.internerOffer, getSpeed, GenericValues.iData, GenericValues.cPrimary, offerVariables);
		if (offerVariables.matchingOffers !== undefined && offerVariables.matchingOffers.length === 0) {
			this.makeDefault(offerVariables);
			if (offerVariables.videoSelected !== 'NoTV') {
				offerVariables.errorMsg += offerVariables.videoSelected === ' -PTV' ? 'PRISM' : ' -DIRECTV';
				offerVariables.errorMsg += ' Not Avail for Selected Speed'
				window.scroll(0, 0);
			}
		}
		return 'executionCompletedFlag';
	}

	private makeDefault(offerVariables) {
		let defaultProdOffer: ProductOfferings;
		let defaultProd: Products;
		let defaultOfferProd: OfferProductComponents;
		let defaultCustOrder: CustomerOrderSubItem;
		offerVariables.selectedTVOffer = defaultProdOffer;
		offerVariables.selectedOffer = defaultProdOffer;
		offerVariables.modemValues = defaultOfferProd;
		offerVariables.selectedModem = defaultCustOrder;
		offerVariables.secureWifiValues = defaultOfferProd;
		offerVariables.selectedSecureWifi = defaultCustOrder;
		offerVariables.easeValues = defaultOfferProd;
		offerVariables.selectedEase = defaultCustOrder;
		offerVariables.secureWifiValues = defaultOfferProd;
		offerVariables.selectedSecureWifi = defaultCustOrder;
		offerVariables.installationValues = defaultOfferProd;
		offerVariables.selectedInstallation = defaultCustOrder;
		offerVariables.jackValues = defaultOfferProd;
		offerVariables.selectedJack = defaultCustOrder;
		offerVariables.tvList = [];
		offerVariables.dvrPrice = 0;
		offerVariables.hdPrice = 0;
		offerVariables.hdService = defaultProd;
		offerVariables.dvrService = defaultProd;
		offerVariables.discountedPrice = 0;
		offerVariables.actualPrice = 0;
		this.shoppingCartRequest(offerVariables);
	}

	/**
	 * 
	 * @param data (OfferList)
	 * @param filterBySpeed (Selected Speed/TV)
	 * @param category (DATA/VIDEO)
	 * @param type (PRIMARY)
	 */
	public offerFilter(data: ProductOfferings[], filterBySpeed: string,
		category: string, type: string, offerVariables): OfferGroup[] {
		offerVariables.matchingOffersArray = [];
		if (offerVariables.videoOffer) {
			offerVariables.matchingOffersArray = this.getMatchingOffers(offerVariables.videoSelected, data, filterBySpeed,
				category, type, offerVariables);
		} else if (offerVariables.phoneOffer) {
			offerVariables.matchingOffersArray = this.getMatchingOffers(offerVariables.phoneSelected, data, filterBySpeed,
				category, type, offerVariables);
		} else {
			offerVariables.matchingOffersArray = this.getInternetDefault(data, filterBySpeed, category, offerVariables);
		}
		if (offerVariables.matchingOffersArray && offerVariables.matchingOffersArray.length > 0) {
			offerVariables.matchingOffersArray.forEach((match) => {
				match && match.offerItems && match.offerItems.forEach((offerItem) => {
					if (offerItem.offerBillingType === null) {
						offerItem.offerBillingType = "POSTPAID";
					}
				});
			});
			this.dynamicSortNestedArray(offerVariables.matchingOffersArray, "offerItems.offerBillingType", "DESC");
		}
		return offerVariables.matchingOffersArray;
	}

	public getMatchingOffers(selectedItem, data: ProductOfferings[], filterBySpeed: string,
		category: string, type: string, offerVariables) {
		switch (selectedItem) {
			case 'DHP':
				offerVariables.matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
					category, offerVariables);
				break;
			case 'HMP':
				offerVariables.matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
					category, offerVariables);
				break;
			case 'DTV':
				offerVariables.matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
					category, offerVariables);
				break;
			case 'PTV':
				offerVariables.matchingOffersArray = this.getInternetDefault(data, filterBySpeed,
					category, offerVariables);
				break;
		}
		return offerVariables.matchingOffersArray;
	}

	public getInternetDefault(data: ProductOfferings[], filterBySpeed: string, category: string, offerVariables) {
		let defaultCheck: boolean = false;
		let flag: boolean = false;
		offerVariables.matchingOffersArray = [];
		offerVariables.expiredOffers = [];
		data.forEach((item) => {
			if (offerVariables && offerVariables.exisitngData && offerVariables.exisitngData.existingProductsAndServices && offerVariables.exisitngData.existingProductsAndServices[0].existingServices
				&& offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems && offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems[0].productOfferingId) {
				if (item.productOfferingId === offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems[0].productOfferingId && (item.productOffer.validFor.bundleSaleExpired === "Y" || item.productOffer.validFor.saleExpired === "Y")) {
					offerVariables.selectedSalesExpiredOfferId = offerVariables.exisitngData.existingProductsAndServices[0].existingServices.existingServiceItems[0].productOfferingId;
				}
			}
			if ((item.productOffer.validFor.bundleSaleExpired === 'N' && item.productOffer.validFor.saleExpired === 'N') || offerVariables.selectedSalesExpiredOfferId === item.productOfferingId) // checking for Sales Expired Offers.
			{
				let offerEnable: boolean = false;
				if (item.productOffer.offerAttributes !== null && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length !== 0) {
					item.productOffer.offerAttributes.forEach((attr) => {
						if (attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'yes') {
							if (!offerEnable) {
								item.productOffer.offerAttributes.forEach((checkAttr) => {
									if (offerVariables.phoneSelected === GenericValues.noPhone && checkAttr.attributeName === 'with-INTERNET' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
										offerEnable = true;
									}
									if (offerVariables.phoneSelected === 'NoPhone' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'no') {
										offerEnable = true;
									} else if (offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
										offerEnable = true;
									} else if ((offerVariables.phoneSelected === 'DHP' || offerVariables.videoSelected !== 'NoTV') && (checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'no')) {
										offerEnable = true;
									}
								});
							}
						}
					});
				}
				if (this.searchforPrimary(item.productOffer.productComponents,
					GenericValues.cPrimary).productName === filterBySpeed && offerEnable) {
					let group: OfferGroup;
					let offerItem: OfferItems;
					const offerItems: OfferItems[] = [];
					const price: Prices = {
						discountedOtc: item.defaultOfferPrice.discountedOtc,
						discountedRc: item.defaultOfferPrice.discountedRc,
						otc: item.defaultOfferPrice.otc,
						rc: item.defaultOfferPrice.rc
					}

					offerItem = {
						productOfferingId: item.productOfferingId,
						offerName: item.productOffer.offerName,
						offerDisplayName: item.productOffer.offerBillingType === 'PREPAID' ? item.productOffer.offerDisplayName + ' (' + item.productOffer.offerBillingType + ')' : item.productOffer.offerDisplayName,
						offerCategory: item.productOffer.offerCategory,
						offerBillingType: item.productOffer.offerBillingType
					}
					offerItems.push(offerItem);
					let associatedOffers: AssociatedOffers[] = [];
					if ((category === GenericValues.sData || category === GenericValues.iData)
						&& (offerVariables.phoneSelected !== 'NoPhone' || offerVariables.phoneSelected !== GenericValues.noPhone)) {
						if (offerVariables.phoneSelected === 'HMP' && item.productOffer.associatedOffers !== null && item.productOffer.associatedOffers !== undefined
							&& item.productOffer.associatedOffers.length > 0) {
							associatedOffers = item.productOffer.associatedOffers;
							associatedOffers.forEach((associated) => {
								if (associated && associated.associatedOfferCategory === GenericValues.cHP && associated.associationType.associationType === GenericValues.bundle) {
									associated.associationType && associated.associationType.associatedOfferIds.forEach((assocId) => {
										// dhp
										offerEnable = false;
										offerVariables.phoneOfferData.forEach((items) => {
											if (assocId.associatedOfferId === items.productOfferingId) {
												({ offerEnable, defaultCheck } = this.hsiWithVoice(items, offerEnable, offerItem, item, defaultCheck, offerVariables));
											}
										});
									})
								}
							});
						} else {
							offerEnable = false;
							offerVariables.phoneOfferData.forEach((items) => {
								if (((!items.productOffer.offerBillingType && !item.productOffer.offerBillingType) || (items.productOffer.offerBillingType === null && item.productOffer.offerBillingType === null))
									|| (items.productOffer.offerBillingType === 'POSTPAID' && (!item.productOffer.offerBillingType || item.productOffer.offerBillingType === null))
									|| ((!items.productOffer.offerBillingType || items.productOffer.offerBillingType === null) && (item.productOffer.offerBillingType === 'POSTPAID'))
									|| (items.productOffer.offerBillingType === item.productOffer.offerBillingType)) {
									({ offerEnable, defaultCheck } = this.hsiWithVoice(items, offerEnable, offerItem, item, defaultCheck, offerVariables));
								}
							});
						}
					} else if ((category === GenericValues.sData || category === GenericValues.iData)
						&& offerVariables.videoSelected !== 'NoTV' && offerVariables.videoSelected === 'PTV') {
						if (item.productOffer.associatedOffers !== null && item.productOffer.associatedOffers !== undefined
							&& item.productOffer.associatedOffers.length > 0) {
							associatedOffers = item.productOffer.associatedOffers;
							associatedOffers.forEach((items) => {
								if (items.associatedOfferCategory === GenericValues.cVideo) {
									items.associationType.associatedOfferIds.forEach((assocId) => {
										flag = false;
										offerVariables.videorOffer.forEach((vidOffer) => {
											if (!flag && vidOffer.productOfferingId === assocId.associatedOfferId) {
												flag = true;
												const packages: Products = this.searchforPrimary(vidOffer.productOffer.productComponents,
													GenericValues.cPrimary);
												if (offerVariables.tvList.indexOf(packages.productName) === -1) {
													// adding Unique package to the list by filtering from OfferList
													offerVariables.tvList.push(packages.productName);
												}
												const offerItemsVid: OfferItems[] = [];
												offerItemsVid.push(offerItem);
												const offerItem1: OfferItems = {
													productOfferingId: assocId.associatedOfferId,
													offerName: item.productOffer.offerName + ' ' + vidOffer.productOffer.offerName,
													offerDisplayName: item.productOffer.offerDisplayName + ' ' + vidOffer.productOffer.offerDisplayName,
													offerCategory: vidOffer.productOffer.offerCategory
												}
												offerItemsVid.push(offerItem1);
												offerItems.push(offerItem);
												const priceToAdd: Prices = {
													discountedOtc: item.defaultOfferPrice.discountedOtc + vidOffer.defaultOfferPrice.discountedOtc,
													discountedRc: item.defaultOfferPrice.discountedRc + vidOffer.defaultOfferPrice.discountedRc,
													otc: item.defaultOfferPrice.otc + vidOffer.defaultOfferPrice.otc,
													rc: item.defaultOfferPrice.rc + vidOffer.defaultOfferPrice.rc
												}
												let group1: OfferGroup;
												group1 = {
													offerItems: offerItemsVid,
													prices: [priceToAdd]
												}
												offerVariables.matchingOffersArray.push(group1);
												if (!defaultCheck && offerVariables.offerBillingType
													&& group1.offerItems[0].offerBillingType === offerVariables.offerBillingType) {
													defaultCheck = true;
													this.selectedBundle(group1, offerVariables);
												}
											}
										});
									});
								}
							});
						}
					} else if ((category === GenericValues.sData || category === GenericValues.iData)
						&& offerVariables.videoSelected !== 'NoTV' && offerVariables.videoSelected === 'DTV') {
						offerVariables.videorOffer.forEach((dtv) => {
							const offerItemsPhone: OfferItems[] = [];
							offerItemsPhone.push(offerItem);
							const offerItem1: OfferItems = {
								productOfferingId: dtv.productOfferingId,
								offerName: item.productOffer.offerName,
								offerDisplayName: item.productOffer.offerBillingType === 'PREPAID' ? item.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName + ' (' + item.productOffer.offerBillingType + ')' : item.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
								offerCategory: dtv.productOffer.offerCategory
							}
							offerItemsPhone.push(offerItem1);
							const phonediscountedOtc = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.discountedOtc : 0;
							const phonediscountedRc = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.discountedRc : 0;
							const phoneOtcPrice = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.otc : 0;
							const phoneRcPrice = dtv.defaultOfferPrice ? dtv.defaultOfferPrice.rc : 0;
							const priceToAdd: Prices = {
								discountedOtc: item.defaultOfferPrice.discountedOtc + phonediscountedOtc,
								discountedRc: item.defaultOfferPrice.discountedRc + phonediscountedRc,
								otc: item.defaultOfferPrice.otc + phoneOtcPrice,
								rc: item.defaultOfferPrice.rc + phoneRcPrice
							}
							let group1: OfferGroup;
							group1 = {
								offerItems: offerItemsPhone,
								prices: [priceToAdd]
							}
							offerVariables.matchingOffersArray.push(group1);
							if (!defaultCheck && offerVariables.offerBillingType
								&& group1.offerItems[0].offerBillingType === offerVariables.offerBillingType) {
								defaultCheck = true;
								this.selectedBundle(group1, offerVariables);
							}
						});
					} else {
						offerItems.push(offerItem);
						group = {
							offerItems: offerItems,
							prices: [price]
						}
						offerVariables.matchingOffersArray.push(group);
						if (!defaultCheck && offerVariables.flow !== 'NEWINSTALL' && offerVariables.offerBillingType
							&& group.offerItems[0].offerBillingType === offerVariables.offerBillingType) {
							defaultCheck = true;
							this.selectedBundle(group, offerVariables);
						} else if (!defaultCheck && item.isDefault && offerVariables.offerName === null) {
							defaultCheck = true;
							this.selectedBundle(group, offerVariables);
						}
					}
				}
				if (item.productOffer.offerName !== null && item.productOffer.offerName && item.productOffer.offerName.indexOf(filterBySpeed) > -1) {
					if (item.productOffer.offerAttributes !== null && item.productOffer.offerAttributes && item.productOffer.offerAttributes.length !== 0) {
						item.productOffer.offerAttributes.forEach((checkAttr) => {
							if (checkAttr.attributeName === 'qualificationColorName' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'tan') {
								offerVariables.disclosureArrList = [
									{
										"name": "qualificationColorName",
										"value": "TAN"
									}
								]
							}
						});
					}
				}
			}
			else if (offerVariables.internetCheck) {
				offerVariables.expiredOffers.push(item);
			}
		});
		if (!defaultCheck) {
			if (offerVariables.offerName === null) {
				offerVariables.offerName = offerVariables.matchingOffersArray[0].offerItems[0].offerDisplayName;
			} else {
				let index: any;
				offerVariables.matchingOffersArray.forEach((off) => {
					if (index === -1) { index = off.offerItems.findIndex((a) => a.offerDisplayName === offerVariables.offerName); }
				});
				if (index === -1) {
					offerVariables.offerName = offerVariables.matchingOffersArray[0].offerItems[0].offerDisplayName;
				}
			}
			let isOfferAvail = false;
			offerVariables.matchingOffersArray.forEach((offer) => {
				if (offer.offerItems[0].offerDisplayName === offerVariables.offerName) {
					this.selectedBundle(offer, offerVariables);
					isOfferAvail = true;
				}
			});
			if (!isOfferAvail) {
				let offerGroup: any;
				if (offerVariables.offerBillingType) {
					offerGroup = offerVariables.matchingOffersArray.filter(function (item) {
						return item.offerItems[0].offerBillingType === offerVariables.offerBillingType;
					});
				}
				offerGroup && offerGroup[0] ? this.selectedBundle(offerGroup[0], offerVariables) : this.selectedBundle(offerVariables.matchingOffersArray[0], offerVariables);
			}
		}
		if (offerVariables.flow === 'CHANGE' && offerVariables.recommendedObject && offerVariables.recommendedObject.length > 0 && !offerVariables.reEntrant) {
			let isOfferAvail = false;
			if (!offerVariables.addDhpfromRecommendation || offerVariables.dhpExisting) {
				let offerID;
				if (offerVariables.recommendedObj['DATA']) {
					offerID = offerVariables.recommendedObj['DATA'].offeringId;
				}
				if (offerID) {
					offerVariables.matchingOffersArray.forEach((offer) => {
						if (offer.offerItems[0].productOfferingId === offerID) {
							this.selectedBundle(offer, offerVariables);
							isOfferAvail = true;
						} else if (offerVariables.recommendedObj['DATA'].offerName && offer.offerItems[0].offerName === offerVariables.recommendedObj['DATA'].offerName) {
							this.selectedBundle(offer, offerVariables);
							isOfferAvail = true;
						}
					});

				}
			}
			if (!isOfferAvail) { this.selectedBundle(offerVariables.matchingOffersArray[0], offerVariables); }
			this.addRecommendedDiscountsInCart(offerVariables);
		}
		return offerVariables.matchingOffersArray;
	}
	public addRecommendedDiscountsInCart(offerVariables) {
		let currentCart = this.appStateService.getState().cart;
		let cart = cloneDeep(currentCart);
		let allDiscounts: any[] = [];
		if (cart && cart.payload && cart.payload.cart && cart.payload.cart.customerOrderItems && cart.payload.cart.customerOrderItems.length > 0) {
			cart.payload.cart.customerOrderItems.forEach((item) => {
				if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
					item.customerOrderSubItems.forEach((subitem) => {
						if (subitem.componentType === GenericValues.component || subitem.componentType === GenericValues.cPrimary) {
							subitem.productAttributes.forEach((attr) => {
								if (attr.isPriceable) {
									if (attr.discounts && attr.discounts !== null && attr.discounts !== undefined && attr.discounts.length > 0) {
										allDiscounts = allDiscounts.concat(attr.discounts);
									}
								}
							});
						}
					});
				}
			});
		}

		let recommendedDiscounts = [];
		if (offerVariables.isRecommendationSuccess && offerVariables.recommendedObject && offerVariables.recommendedObject[0] && offerVariables.recommendedObject[0].serviceCategory && offerVariables.recommendedObject[0].serviceCategory.length > 0 && !offerVariables.reEntrant) {
			offerVariables.recommendedObject[0].serviceCategory.forEach((sc) => {
				if (sc.recommendedOffers && sc.recommendedOffers.length > 0 && sc.recommendedOffers[0].recommendedDiscounts && sc.recommendedOffers[0].recommendedDiscounts.length > 0) {
					recommendedDiscounts = recommendedDiscounts.concat(sc.recommendedOffers[0].recommendedDiscounts);
				}
			});
		}

		if (recommendedDiscounts && recommendedDiscounts.length > 0 && allDiscounts && allDiscounts.length > 0) {
			recommendedDiscounts.forEach((rd) => {
				for (let discount of allDiscounts) {
					if (rd.discountId === discount.discountId && discount.autoAttachInd === "N") {
						if ((offerVariables.retentionDiscountsToCart.findIndex(a => a.discountId === discount.discountId)) === -1) {
							offerVariables.retentionDiscountsToCart.push(discount);
						}
					}
				}
			});
		}
		if (!offerVariables.reEntrant) {
			this.store.dispatch({ type: 'CLOSERS_PROMOS', payload: offerVariables.retentionDiscountsToCart });
			this.store.dispatch({ type: 'CLOSERS_PROMOS_RECOMMENDATION', payload: offerVariables.retentionDiscountsToCart });
		}
	}

	public selectedBundle(group: OfferGroup, offerVariables) {
		if (group && group !== undefined && group.offerItems[0] && group.offerItems[0] !== undefined && group.offerItems[0].offerName && group.offerItems[0].offerName !== undefined) {
			offerVariables.offerName = group.offerItems[0].offerDisplayName;
			offerVariables.offerBillingType = group.offerItems[0].offerBillingType;
			offerVariables.offerBillingType = offerVariables.offerBillingType ? offerVariables.offerBillingType : "POSTPAID";
			if (offerVariables.AllspeedList && offerVariables.AllspeedList.length > 0) {
				const offerBillingType = offerVariables.offerBillingType ? offerVariables.offerBillingType : "POSTPAID"
				offerVariables.speedList = offerVariables.AllspeedList.filter((speed) => { return speed.offerBillingType === offerBillingType });
			}
			offerVariables.selectedVideoOfferPrice = undefined;
			offerVariables.selectedGroup = group;
		}
		let component: CustomerOrderItems;
		if (offerVariables.internetCheck) {
			if (offerVariables.reentrantUI) {
				component = this.findCustomerOrderObject(offerVariables.cartCopyObject
					&& offerVariables.cartCopyObject.payload
					&& offerVariables.cartCopyObject.payload.cart
					&& offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
			}
			offerVariables.selectedInternetOfferdId = offerVariables.reentrantUI && component && component.productOfferingId ?
				component.productOfferingId : this.getBundledOfferId(group, GenericValues.iData, true);
		}
		if (offerVariables.videoSelected !== 'NoTV') {
			const dataVal = this.getBundledOfferIdandPrice(offerVariables.videoSelected, group);
			offerVariables.selectedVideoOfferdId = dataVal.id;
			offerVariables.selectedVideoOfferPrice = dataVal.price;
		}
		if (offerVariables.phoneSelected !== 'NoPhone') {
			const dataVal = this.getBundledOfferIdandPrice(offerVariables.phoneSelected, group);
			if (offerVariables.reentrantUI) {
				component = this.findCustomerOrderObject(offerVariables.cartCopyObject
					&& offerVariables.cartCopyObject.payload
					&& offerVariables.cartCopyObject.payload.cart
					&& offerVariables.cartCopyObject.payload.cart.customerOrderItems, offerVariables.phoneSelected === 'HMP' ? GenericValues.cHP : GenericValues.cDHP);
			}
			offerVariables.selectedPhoneOfferdId = offerVariables.reentrantUI && component && component.productOfferingId ?
				component.productOfferingId : dataVal.id;
			offerVariables.selectedPhoneOfferPrice = dataVal.price;
		}
		if (offerVariables.offerName && offerVariables.offerName.toUpperCase() === '1 PTY RESIDENCE LINE') {
			offerVariables.isOffer1PtyResLineSelected = true;
		} else { offerVariables.isOffer1PtyResLineSelected = false; }
		this.getOfferById(group, offerVariables);
		offerVariables.selectedInternetOfferPrice = this.getBundleOfferPrice(group, offerVariables.internetCheck ? GenericValues.iData : GenericValues.cHP, offerVariables.internetCheck ? true : false);
		if (!offerVariables.existingServices) { this.updateShipAndHandlingObj(offerVariables, offerVariables.selectedInternetOfferdId); }
	}

	public getOfferById(group, offerVariables) {
		let flag: boolean = false;
		offerVariables.internerOffer.forEach((offer) => {
			if (offerVariables.internetCheck && !flag && offer.productOfferingId === offerVariables.selectedInternetOfferdId) {
				flag = true;
				this.internetSlot(offer, offerVariables);
			}
		});
		if (offerVariables.phoneOfferData) {
			let potsCalled = false;
			offerVariables.phoneOfferData.forEach((offer) => {
				if (offer.productOfferingId === offerVariables.selectedPhoneOfferdId && offerVariables.phoneSelected === 'DHP') {
					this.dhpSlot(offerVariables, offer);
				} else if (offer.productOfferingId === offerVariables.selectedPhoneOfferdId && offerVariables.phoneSelected === 'HMP') {
					this.hmpSlot(offerVariables, offer);
					potsCalled = true;
				}
			});
			let dataVal;
			if (!potsCalled && offerVariables.phoneSelected === 'HMP') {
				dataVal = this.getBundledOfferIdandPrice(offerVariables.phoneSelected, group);
				offerVariables.phoneOfferData.forEach((offer) => {
					if (offer.productOfferingId === dataVal.id) {
						this.hmpSlot(offerVariables, offer);
					}
				});
			}
		}
		if (offerVariables.videoOffer) {
			offerVariables.videorOffer.forEach((offer) => {
				if (offer.productOfferingId === offerVariables.selectedVideoOfferdId) {
					this.videoSlot(offerVariables, offer);
				}
			});
		}
	}

	private hsiWithVoice(items: ProductOfferings, offerEnable: boolean, offerItem: OfferItems, item: ProductOfferings, defaultCheck: boolean, offerVariables) {
		if ((item.productOffer.validFor.bundleSaleExpired === 'N' && item.productOffer.validFor.saleExpired === 'N') || offerVariables.selectedSalesExpiredOfferId === item.productOfferingId) // checking for Sales Expired Offers.
		{
			offerVariables.isTempExpiredOffer = true;
			if (items.productOffer.offerAttributes !== null && items.productOffer.offerAttributes && items.productOffer.offerAttributes.length !== 0) {
				items.productOffer.offerAttributes.forEach((attr) => {
					if (offerVariables.phoneSelected === 'HMP' && attr && attr.attributeName === 'with-INTERNET' && attr.attributeValue && attr.attributeValue.toLowerCase() === 'yes') {
						items.productOffer.offerAttributes.forEach((checkAttr) => {
							if (offerVariables.phoneSelected === 'HMP' && checkAttr.attributeName === 'withPhone-HP' && checkAttr.attributeValue && checkAttr.attributeValue.toLowerCase() === 'yes') {
								offerEnable = true;
							}
						});
					}
					else if (offerVariables.phoneSelected === 'DHP') {
						offerEnable = true;
					}
				});
			}
			if (offerEnable && ((offerVariables.phoneSelected === 'DHP' && offerVariables.videoOffer && items.productOffer.offerBillingType !== 'PREPAID') || offerVariables.phoneSelected === 'HMP' || !offerVariables.videoOffer)) {
				const offerItemsPhone: OfferItems[] = [];
				offerItemsPhone.push(offerItem);
				const offerItem1: OfferItems = {
					productOfferingId: items.productOfferingId,
					offerName: items.productOffer.offerName,
					offerDisplayName: offerVariables.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName : item.productOffer.offerBillingType === 'PREPAID' ? item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + '(' + item.productOffer.offerBillingType + ')' : item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName,
					offerBillingType: item.productOffer.offerBillingType,
					offerCategory: items.productOffer.offerCategory
				};
				offerItemsPhone.push(offerItem1);
				let group1: OfferGroup;
				if (offerVariables.videoOffer) {
					offerVariables.videorOffer.forEach((dtv) => {
						const offerItem1: OfferItems = {
							productOfferingId: dtv.productOfferingId,
							offerName: offerVariables.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName : item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
							offerDisplayName: offerVariables.phoneSelected === 'HMP' ? items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName : item.productOffer.offerBillingType === 'PREPAID' ? item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName + '(' + item.productOffer.offerBillingType + ')' : item.productOffer.offerDisplayName + ' ' + items.productOffer.offerDisplayName + ' ' + dtv.productOffer.offerDisplayName,
							offerBillingType: item.productOffer.offerBillingType,
							offerCategory: dtv.productOffer.offerCategory
						}
						offerItemsPhone.push(offerItem1);
						const phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
						const phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
						const phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
						const phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
						const priceToAdd: Prices = {
							discountedOtc: item.defaultOfferPrice.discountedOtc + phonediscountedOtc,
							discountedRc: item.defaultOfferPrice.discountedRc + phonediscountedRc,
							otc: item.defaultOfferPrice.otc + phoneOtcPrice,
							rc: item.defaultOfferPrice.rc + phoneRcPrice
						};
						group1 = {
							offerItems: offerItemsPhone,
							prices: [priceToAdd]
						}
						offerVariables.matchingOffersArray.push(group1);
					});
				} else {
					const phonediscountedOtc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedOtc : 0;
					const phonediscountedRc = items.defaultOfferPrice ? items.defaultOfferPrice.discountedRc : 0;
					const phoneOtcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.otc : 0;
					const phoneRcPrice = items.defaultOfferPrice ? items.defaultOfferPrice.rc : 0;
					const priceToAdd: Prices = {
						discountedOtc: item.defaultOfferPrice.discountedOtc + phonediscountedOtc,
						discountedRc: item.defaultOfferPrice.discountedRc + phonediscountedRc,
						otc: item.defaultOfferPrice.otc + phoneOtcPrice,
						rc: item.defaultOfferPrice.rc + phoneRcPrice
					};
					group1 = {
						offerItems: offerItemsPhone,
						prices: [priceToAdd]
					};
					offerVariables.matchingOffersArray.push(group1);
				}
				let componentHSI: CustomerOrderItems;
				let component: CustomerOrderItems;
				if (offerVariables.reentrantUI && offerVariables.cartCopyObject && offerVariables.cartCopyObject !== undefined) {
					componentHSI = this.findCustomerOrderObject(offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.iData, true);
					component = this.findCustomerOrderObject(offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.cHP);
				}
				if (offerVariables.reentrantUI && component && componentHSI && component.productOfferingId === items.productOfferingId && componentHSI.productOfferingId === item.productOfferingId) {
					defaultCheck = true;
					this.selectedBundle(group1, offerVariables);
				}
				if (!defaultCheck && offerVariables.offerBillingType
					&& group1.offerItems[0].offerBillingType === offerVariables.offerBillingType) {
					defaultCheck = true;
					this.selectedBundle(group1, offerVariables);
				}
				else if (!defaultCheck && items.isDefault === 1
					&& !offerVariables.offerBillingType) {
					defaultCheck = true;
					this.selectedBundle(group1, offerVariables);
				}
			}
			return { offerEnable, defaultCheck };
		}
		else if (offerVariables.internetCheck) {
			offerVariables.expiredOffers.push(item);
		}
	}

	public removePhone(offerVariables: OfferVariables) {
		offerVariables.phoneSelected = GenericValues.noPhone;
		offerVariables.newPhoneSelected = GenericValues.noPhone;
	}

	public checkInternet(offerVariables: OfferVariables, check: boolean) {
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		switch (flow) {
			case 'MOVE':
			case 'STACKAMEND':
			case 'CHANGE':
				if (offerVariables.newVideoSelected !== 'NoTV' && offerVariables.newPhoneSelected !== 'HMP') {
					offerVariables.warningMsg = 'Internet/POTS is Mandatory for Video Bundle';
				} else {
					offerVariables.newInternetCheck = check;
					offerVariables.undoFlag = true;
					if (flow === 'STACKAMEND') {
						offerVariables.internetCheck = check;
					}
				}
				break;
			case 'BILLING':
				if (offerVariables.videoSelected !== "NoTV") {
					offerVariables.warningMsg = "Internet is Mandatory for Video Bundle";
				} else {
					offerVariables.undoFlag = true;
					offerVariables.internetCheck = check;
					offerVariables.newInternetCheck = check;
				}
				break;
			default:
				offerVariables.errorMsg = '';
				if (offerVariables.newVideoSelected !== 'NoTV' && offerVariables.newVideoSelected !== 'DTV') {
					offerVariables.errorMsg = 'Internet is Mandatory for Video Bundle';
				}
				else if (!check) {
					if (offerVariables.newPhoneSelected === 'NoPhone') {
						offerVariables.errorMsg = 'Internet or Phone is Mandatory';
					}
					else if (offerVariables.newPhoneSelected === 'DHP' && !offerVariables.internetAvail) {
						offerVariables.errorMsg = 'DHP cannot be selected as Internet is unavailable';
					}
					else if (offerVariables.newPhoneSelected === 'DHP' && offerVariables.internetAvail) {
						offerVariables.errorMsg = 'Internet is Mandatory when ordering Digital Home Phone';
					}
					else {
						offerVariables.newInternetCheck = check;
					}
				}
				else {
					offerVariables.newInternetCheck = check;
				}
				break;
		}
	}

	public selectPhone(value: string, offerVariables: any, removeProduct: any) {
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		switch (flow) {
			case 'MOVE':
			case 'STACKAMEND':
			case 'CHANGE':
				if (flow === "STACKAMEND") {
					if (offerVariables.isAmend && value === GenericValues.dhp) { return; }
					if (offerVariables.isStack && (offerVariables.isCanAddCvoip === 'false' && value === GenericValues.dhp) || (offerVariables.isCanAddPots === 'false' && value === GenericValues.homePhone)) { return; }
				}
				if ((value === GenericValues.noPhone || value === GenericValues.dhp) && offerVariables.newVideoSelected !== GenericValues.noTv && !offerVariables.internetCheck) {
					offerVariables.warningMsg = 'Internet/POTS is Mandatory for Video Bundle';
				} else if (flow === "STACKAMEND" && value === GenericValues.noPhone && offerVariables.internetAvail && !offerVariables.internetCheck) {
					offerVariables.warningMsg = 'Internet or Phone is Mandatory';
				} else {
					if ((value !== GenericValues.noPhone || value === GenericValues.noPhone) &&
						((offerVariables.dhpExisting && !offerVariables.isDHPRemoved) || (offerVariables.hpExisting && !offerVariables.isHPRemoved))) {
						this.setMessage('More information is needed', offerVariables.dhpExisting ? 'removeDhp' : offerVariables.hpExisting ? 'removeHp' : '', offerVariables);
						removeProduct.open();
					}
					offerVariables.newPhoneSelected = value;
					if (offerVariables.newPhoneSelected !== GenericValues.noPhone && offerVariables.newPhoneSelected === GenericValues.dhp) {
						offerVariables.newPhoneSelected = value;
						offerVariables.newInternetCheck = true;
						if (flow === "CHANGE" || flow === "STACKAMEND") { offerVariables.internetCheck = true; }
					}
					if (!offerVariables.hpExisting && offerVariables.newPhoneSelected !== GenericValues.noPhone && offerVariables.newPhoneSelected === GenericValues.homePhone) {
						offerVariables.undoFlag = true;
					}
					if (!offerVariables.dhpExisting && offerVariables.newPhoneSelected === GenericValues.dhp) {
						offerVariables.undoFlag = true;
					}
					if (flow === "MOVE" || flow === "STACKAMEND") {
						if (offerVariables.newPhoneSelected === GenericValues.homePhone && offerVariables.hpExisting) { offerVariables.isHPRemoved = false; }
						if (offerVariables.newPhoneSelected === GenericValues.dhp && offerVariables.dhpExisting) { offerVariables.isDHPRemoved = false; }
					}
				}
				offerVariables.newPhoneUpdated = true;
				break;
			case 'BILLING':
				if (value === GenericValues.noPhone && offerVariables.videoSelected !== GenericValues.noTv &&
					!offerVariables.internetCheck) {
					offerVariables.warningMsg = "Internet/POTS is Mandatory for Video Bundle";
				} else {
					if ((value !== GenericValues.noPhone || value === GenericValues.noPhone) &&
						((offerVariables.dhpExisting && !offerVariables.isDHPRemoved) ||
							(offerVariables.hpExisting && !offerVariables.isHPRemoved))
					) {
						this.setMessage("More information is needed", offerVariables.phoneSelected === GenericValues.dhp ? "removeDhp" : offerVariables.phoneSelected === GenericValues.homePhone ? "removeHp" : "", offerVariables);
						removeProduct.open();
					}
					offerVariables.phoneSelected = value;
					offerVariables.phoneOffer = false;
					if (offerVariables.phoneSelected !== GenericValues.noPhone && offerVariables.phoneSelected === GenericValues.dhp) {
						offerVariables.internetCheck = true;
					}
					if (
						!offerVariables.hpExisting &&
						offerVariables.phoneSelected !== GenericValues.noPhone &&
						offerVariables.phoneSelected === GenericValues.homePhone
					) {
						offerVariables.undoFlag = true;
					}
					if (!offerVariables.dhpExisting && offerVariables.phoneSelected === GenericValues.dhp) {
						offerVariables.undoFlag = true;
					}
				}
				break;
			default:
				offerVariables.errorMsg = '';
				if (value !== GenericValues.noPhone && value === GenericValues.dhp && offerVariables.internetAvail) {
					offerVariables.newPhoneSelected = value;
					offerVariables.newInternetCheck = true;
					offerVariables.selectedDHPOffer = undefined;
				} else if (value === GenericValues.dhp && !offerVariables.internetAvail) {
					offerVariables.errorMsg = 'DHP cannot be selected as Internet is unavailable';
				} else if (value === GenericValues.homePhone) {
					offerVariables.newPhoneSelected = value;
				} else if (value === GenericValues.noPhone) {
					if (offerVariables.internetAvail && !offerVariables.internetCheck) {
						offerVariables.errorMsg = 'Internet or Phone is Mandatory';
					}
					else if (!offerVariables.internetAvail) {
						offerVariables.errorMsg = 'Internet is unavailable so Phone is Mandatory';
					}
					else { offerVariables.newPhoneSelected = value; }
				}
				offerVariables.newPhoneUpdated = true;
				break;
		}
	}

	// removeProduct
	public setMessage(msg: string, removeProduct: string, offerVariables: any) {
		offerVariables.removeMessage = msg;
		offerVariables.productToRemove = removeProduct;
	}

	public productRemoved(removed: string, offerVariables: any) {
		if (removed === 'offerCategory') {
			if (!offerVariables.newInternetCheck && offerVariables.hpExisting && !offerVariables.isHPRemoved && offerVariables.newVideoSelected !== GenericValues.noTv) {
				offerVariables.isRemovePhone = false;
				offerVariables.warningMsg = "Internet/POTS is Mandatory for Video Bundle";
			} else {
				offerVariables.isRemovePhone = true;
				offerVariables.undoFlag = true;
				offerVariables.removal.productType = offerVariables.hpExisting ? 'VOICE-HP' : 'VOICE-DHP';
			}
		} else {
			offerVariables.undoFlag = true;
			offerVariables.removal.productType = removed;
		}
	}

	private catalogEmptyError(offerVariables, notExpiredFlag) {
		const errorResponseArray: ErrorResponse[] = [];
		const localErrorResponse: ErrorResponse = {
			orderRefNumber: offerVariables.orderRefNumber,
			statusCode: notExpiredFlag === false ? serverErrorMessages.catalogArrayExpiredMessage : serverErrorMessages.catalogArrayEmptyErrMessage,
			reasonCode: notExpiredFlag === false ? serverErrorMessages.catalogArrayExpiredReasonCode : serverErrorMessages.catalogArrayEmptyErrMessage,
			message: notExpiredFlag === false ? serverErrorMessages.catalogArrayExpiredMessage : serverErrorMessages.catalogArrayEmptyErrMessage,
			messageDetail: notExpiredFlag === false ? serverErrorMessages.catalogArrayExpiredErrMessage : serverErrorMessages.catalogArrayEmptyErrMessage
		};
		errorResponseArray.unshift(localErrorResponse);
		const lAPIErrorLists: APIErrorLists = {
			errorResponse: errorResponseArray
		};
		this.systemErrorService.logAndeRouteToSystemError("error", offerVariables.taskName, "offerHelper.service.ts", "Offer Page", lAPIErrorLists);
		offerVariables.retrieveOffersLoading = false;
	}

	public availableCategory(offerVariables) {
		if (offerVariables.internetAvail && offerVariables.internetCheck) {
			offerVariables.selected = 'Internet,';
		}
		offerVariables.internetOffer = offerVariables.internetCheck;
		if (offerVariables.videoSelected !== 'NoTV') {
			offerVariables.videoOffer = true;
			offerVariables.selected += 'TV';
		}
		if (offerVariables.phoneSelected !== GenericValues.noPhone) {
			offerVariables.phoneOffer = true;
			if (offerVariables.phoneSelected === 'DHP') {
				offerVariables.selected += 'DHPhone';
				offerVariables.isDHP = true;
			}
			else {
				offerVariables.selected += 'HMPhone';
				offerVariables.isPOTS = true;
			}
		}
	}
	public createRecommendedDataObj(offerVariables, recommendedObject) {
		if (recommendedObject.serviceCategory && recommendedObject.serviceCategory.length > 0) {
			recommendedObject.serviceCategory.forEach(service => {
				if (service.recommendedOffers && service.recommendedOffers.length > 0) {
					if (service.recommendedOffers[0].productOfferingId) {
						let bundle = this.findBundlePromoId(service.recommendedOffers[0]);
						offerVariables.recommendedObj[service.serviceCategory] = {
							offeringId: service.recommendedOffers[0].productOfferingId,
							offerName: service.recommendedOffers[0].offerName,
							bundlePromoId: bundle
						}
					}
					if (service.recommendedOffers[0].recommendedProduct && service.recommendedOffers[0].recommendedProduct.length > 0 && service.recommendedOffers[0].recommendedProduct[0].productId) {
						if (offerVariables.recommendedObj[service.serviceCategory]) {
							offerVariables.recommendedObj[service.serviceCategory].productId = service.recommendedOffers[0].recommendedProduct[0].productId;
							offerVariables.recommendedObj[service.serviceCategory].productName = service.recommendedOffers[0].recommendedProduct[0].productName;
						} else {
							offerVariables.recommendedObj[service.serviceCategory] = {
								productId: service.recommendedOffers[0].recommendedProduct[0].productId,
								productName: service.recommendedOffers[0].recommendedProduct[0].productName
							}
						}
					}

					if (service.recommendedOffers[0].recommendedDiscounts && service.recommendedOffers[0].recommendedDiscounts.length > 0 && service.recommendedOffers[0].recommendedDiscounts[0].discountId) {
						if (offerVariables.recommendedObj[service.serviceCategory]) {
							offerVariables.recommendedObj[service.serviceCategory].recommendedDiscounts = service.recommendedOffers[0].recommendedDiscounts;
						} else {
							offerVariables.recommendedObj[service.serviceCategory] = {
								recommendedDiscounts: service.recommendedOffers[0].recommendedDiscounts
							}
						}
					}

				}
			});
		}
	}

	public disconnectMethod(data: any, offerVariables) {
		return {
			'ban': data.ban,
			'salesChannel': 'ESHOP-Customer Care',
			'customerOrderType': 'DISCONNECT',
			'serviceAddress': data && data.payload && data.payload.serviceCategory ? data.payload.serviceAddress : '',
			party: {
				id: offerVariables.agentCuid,
				firstName: offerVariables.firstName,
				lastName: offerVariables.lastName,
				type: "CSR",
				partyRoles: [
					{
						partyRole: env.CSR_NAME,
						sourceSystem: env.CSR_PROFILE,
						id: offerVariables.agentCuid
					},
					{
						partyRole: env.ENSEMBLEID,
						sourceSystem: env.ENS_OPERATOR,
						id: offerVariables.ensembleId
					}
				]
			}
		};
	}
	public dropDownPopulationforHP(existingItems: any, flag, offerVariables) {
		if (!offerVariables.isReEntrant) { offerVariables.voiceMail = false; }
		offerVariables.wireMaintainance = false;
		existingItems && existingItems.forEach((data) => {
			if (data.offerCategory === GenericValues.cHP && data.offerType !== 'SUBOFFER') {
				if (!offerVariables.isReEntrant) {
					offerVariables.voiceMailValue = 'No';
					offerVariables.wireMaintainanceValue = 'No';
				}
				offerVariables.isWireMaintainanceNoSelected = true;
				data.customerOrderSubItems && data.customerOrderSubItems.forEach((voiceData) => {
					voiceData.action = 'NOCHANGE';
					if (voiceData.productName === "Voice Messaging") {
						if (!flag) { offerVariables.voiceMailCondi = true; }
						if (!offerVariables.isReEntrant) {
							offerVariables.voiceMail = true;
							offerVariables.voiceMailValue = 'Yes';
						}
					}
					else if (voiceData.productName.indexOf('Wire Maintenance Plan') !== -1) {
						offerVariables.wireMaintainance = true;
						offerVariables.isWireMaintainanceYesSelected = true;
						offerVariables.isWireMaintainanceNoSelected = false;
						offerVariables.wireMaintainanceValue = 'Yes';
						if (!flag) { offerVariables.wireMaintainCondi = true; }
					} else if (voiceData.productName.indexOf('Jack and Wire') !== -1) {
						offerVariables.retainValueForPotsJack = voiceData.productAttributes[0].compositeAttribute[0].attributeValue;
						if (offerVariables.retainValueForPotsJack !== undefined && offerVariables.retainValueForPotsJack) {
							offerVariables.retainedPotsBooleans.retainValueForPotsJack = offerVariables.retainValueForPotsJack;
						}
					} else if (voiceData.productName.indexOf('Extended Area Calling') !== -1) {
						if (!flag) { offerVariables.isExtendedAreaCallingExits = true; }
					}
				});
			}
		});
	}

	public changeSelectProduct(data, state, offerVariables) {
		if (data && data.payload && data.payload.productConfiguration) {
			offerVariables.productConfiguration = data.payload.productConfiguration;
		}
		// to get Modem make and model
		let products: any;

		products = data.payload.existingServices.existingServiceItems[0].existingServiceSubItems;
		products && products.forEach((data) => {
			if (data && data.productName === "MODEM") {
				data && data.productAttributes && data.productAttributes.forEach((productAttributes) => {
					productAttributes && productAttributes.compositeAttribute && productAttributes.compositeAttribute.forEach((values) => {
						if (values && values.attributeName && values.attributeName === "modemMake" && values.attributeValue !== "null" && values.attributeValue !== null) {
							offerVariables.modemMake = values.attributeValue;
						} else if (values && values.attributeName && values.attributeName === "modemModel" && values.attributeValue !== "null" && values.attributeValue !== null) {
							offerVariables.modemModel = values.attributeValue;
						} else if (values && values.attributeName && values.attributeName === "Modem Class" && values.attributeValue !== "null" && values.attributeValue !== null) {
							offerVariables.modemClass = values.attributeValue;
						}
					});
				});
			}
		});
		offerVariables.existingServices = data.payload.existingServices.existingServiceItems;
		if (!offerVariables.holdCalled && offerVariables.existingServices && !offerVariables.isReEntrant) {
			this.dropDownPopulationforHP(offerVariables.existingServices, false, offerVariables);
		}
		let disconnectReq = this.disconnectMethod(data, offerVariables);
		offerVariables.disconnectReq = JSON.stringify(disconnectReq);

		if (data.payload && data.payload.retrievalTypes) {
			offerVariables.offersByFilters = this.retrieveOffersByFilter(data.payload.retrievalTypes);
			offerVariables.qualifiedFilter = offerVariables.offersByFilters.qualifiedFilter;
			offerVariables.unQualifiedOffers = offerVariables.offersByFilters.unQualifiedOffers;
			offerVariables.qualifiedUnfilter = offerVariables.offersByFilters.qualifiedUnfilter;
		}
		let offersPreserve;
		if (data.payload && data.payload.retrievalTypes) offersPreserve = data.payload.retrievalTypes[0].offers;
		if (data && data.payload && data.payload !== undefined && data.payload.giftCardOffers && (data.payload.giftCardOffers !== undefined && data.payload.giftCardOffers !== null)) {
			this.store.dispatch({ type: 'INCLUDING_GIFTCARDS', payload: data.payload.giftCardOffers });
		}
		if (data !== undefined && data.payload && data.payload.retrievalTypes &&
			data.payload.retrievalTypes[0] && (data.payload.retrievalTypes[0].offers !== undefined &&
				data.payload.retrievalTypes[0].offers !== null)) {
			this.store.dispatch({ type: 'INCLUDING_OFFERS', payload: data.payload.retrievalTypes[0].offers })
		}

		if (data.existingTN) {
			offerVariables.existingTN = this.maskTelephone(data.existingTN);
		}

		if (offersPreserve !== undefined && offersPreserve.length > 0) {
			offersPreserve.forEach((item) => {
				if (item.serviceCategory !== undefined && item.serviceCategory === GenericValues.sData) {
					offerVariables.preserveHSI = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.sData);
					offerVariables.dataLink = offerVariables.preserveHSI;
				}
				if (item.serviceCategory !== undefined && item.serviceCategory === 'DATA/VIDEO') {
					offerVariables.videoLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDATVID);
				}
				if (item.serviceCategory !== undefined && item.serviceCategory === 'VIDEO-DTV') {
					offerVariables.dtvLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDTV);
				}
				if (item.serviceCategory !== undefined && item.serviceCategory === 'VOICE-DHP') {
					offerVariables.dhpLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDHP);
				}
				if (item.serviceCategory !== undefined && item.serviceCategory === 'VOICE-HP') {
					offerVariables.phoneLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cHP);
				}
			});
		}
		if (offerVariables.catalogSpecId === undefined && data.payload) {
			offerVariables.catalogSpecId = data.payload.catalogSpecId;
		}
	}

	public initilizeAll(offerVariables, isUndoSelected?) {
		offerVariables.undoSelected = isUndoSelected ? isUndoSelected : false;
		offerVariables.hsiCatalogId = undefined;
		offerVariables.existingModem = undefined;
		offerVariables.isProfileBypassLoopQual = this.helperService.isAuthorized(ProfileEnums.BYPASS_LOOP_QUAL);
		offerVariables.isProfileBypassHSISpeeds = this.helperService.isAuthorized(ProfileEnums.BYPASS_HSI_SPEEDS);
		offerVariables.isProfileBypassModemCheck = this.helperService.isAuthorized(ProfileEnums.BYPASS_MODEM_CHECK);
		this.appStateService.setLocationURLs();
		let pendingObservable = <Observable<any>>this.store.select('pending');
		let orderObservable = <Observable<any>>this.store.select('order');
		offerVariables.discountedPriceList = [];
		offerVariables.internetCheck = false;
		offerVariables.newInternetCheck = null;
		offerVariables.isOptedOut = false;
		offerVariables.internetOffer = true;
		offerVariables.videoOffer = false;
		offerVariables.phoneOffer = false;
		offerVariables.internetAvail = false;
		offerVariables.videoAvail = false;
		offerVariables.phoneAvail = false;
		offerVariables.videoSelected = 'NoTV';
		offerVariables.newVideoSelected = 'NoTV';
		offerVariables.phoneSelected = GenericValues.noPhone;
		offerVariables.newPhoneSelected = GenericValues.noPhone;
		offerVariables.offersGenerated = true;
		offerVariables.serviceUnavailable = 'Service not available for your Address';
		offerVariables.expiredOffers = [];
		offerVariables.isSalesExpiredOfferSelected = false;
		offerVariables.addOfferExpired = false;
		let prod: Products = {
			productId: '608',
			productName: 'Intrastate Service Fee',
			productType: 'Service',
			isRegulated: false
		};
		let state: boolean = false;
		orderObservable.subscribe(ord => {
			offerVariables.holdeisCustomizeObjects = ord.taskName === 'Checkout & Scheduling' ? true : false;
			offerVariables.selectedSalesExpiredOfferId = ord.offerId;
		})
		offerVariables.intraStateFee = prod;
		let data = this.appStateService.getState().existingProducts;
		if (data.orderFlow.type === 'fromHold') {
			offerVariables.fromHold = true;
		}

		if (!offerVariables.recommendationFailure && data && data.orderInit && data.orderInit.payload && data.orderInit.payload.recommendedObject && data.orderInit.payload.recommendedObject.length > 0) {
			let recomObj = data.orderInit.payload.recommendedObject[0];
			offerVariables.isRecommendationSuccess = recomObj.errorInfo && recomObj.errorInfo.length > 0 && recomObj.errorInfo[0].status === '200';
			if (recomObj.serviceCategory && recomObj.serviceCategory.length > 0) {
				recomObj.serviceCategory.forEach(service => {
					if (service.recommendedOffers && service.recommendedOffers.length > 0) {
						if (service.recommendedOffers[0].productOfferingId === null) {
							offerVariables.isRecommendationSuccess = false;
						}
					}
				});
			}
			if (offerVariables.isRecommendationSuccess) {
				this.createRecommendedDataObj(offerVariables, recomObj);
			}
		}

		if (data) {
			if (data.existingDiscounts) {
				offerVariables.existingDiscounts = data.existingDiscounts;
			}
			if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo
				&& data.existingProductsAndServices[0].accountInfo.billingType) {
				offerVariables.offerBillingType = data.existingProductsAndServices[0].accountInfo.billingType === "PREPAID" ? data.existingProductsAndServices[0].accountInfo.billingType : "POSTPAID";
			}
		}

		this.getRemoveResponse(offerVariables);
		if (data && data.orderFlow && data.orderFlow.flow) { offerVariables.flow = data.orderFlow.flow.toUpperCase(); }
		if (data && data.orderFlow && data.orderFlow.flow === 'Change' && offerVariables.fromHold && !data.orderFlow.selectProductCalled && !offerVariables.holdCalled) {
			offerVariables.holdCalled = true;
			let pendingSubscription = pendingObservable.subscribe(pending => {
				offerVariables.holdedObjects = pending;
				offerVariables.loading = true;
				state = this.callApiForChange(offerVariables, this.store, state, data);
			})
			if (pendingSubscription !== undefined) { pendingSubscription.unsubscribe(); }
		} else {
			state = this.callApiForChange(offerVariables, this.store, state, data);
		}
	}
	private checkServiceRecommendation(offerVariables, service) {
		return (offerVariables.recommendedObj[service] !== undefined && offerVariables.recommendedObj[service] !== null);
	}
	private selectedProductsFromExisting(offerVariables, moreServices: any, data: any, state: any, initialCall?) {
		if (moreServices !== undefined && moreServices.length > 0) {
			moreServices.forEach((item) => {
				if (offerVariables.internetAvail && (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData)) {
					let hsiRecommended = false;
					if (offerVariables.isRecommendationSuccess) {
						hsiRecommended = this.checkServiceRecommendation(offerVariables, GenericValues.sData) || this.checkServiceRecommendation(offerVariables, GenericValues.iData);
					}
					if (!offerVariables.isRecommendationSuccess || hsiRecommended) {
						offerVariables.hsiExisting = true;
						if (item.offerType === 'SUBOFFER') {
							offerVariables.existingAddonsHSI = item;
						}
						offerVariables.newInternetCheck = true;
					}
				} else if (moreServices.length === 1 && item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
					if (!offerVariables.isRecommendationSuccess || (offerVariables.isRecommendationSuccess && this.checkServiceRecommendation(offerVariables, 'VOICE-HP'))) {
						offerVariables.selectedHP = item.productOfferingId;
						offerVariables.selectedPhoneOfferdId = item.productOfferingId;
						offerVariables.hpExisting = true;
						offerVariables.hpOfferType = item.offerType;
						offerVariables.phoneOffer = true;
						offerVariables.phoneSelected = 'HMP';
						offerVariables.newPhoneSelected = 'HMP';
						if (data && data.payload && data.payload.retrievalTypes) {
							offerVariables.phoneLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cHP);
						}
						state = false;
					}
				}

			});
		}

		if (moreServices !== undefined && moreServices.length > 1) {
			moreServices.forEach((item) => {
				if (item.offerCategory === 'VIDEO-PRISM') {
					offerVariables.videoOffer = true;
					offerVariables.videoSelected = 'PTV';
					if (data && data.payload && data.payload.retrievalTypes) {
						offerVariables.videoLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDATVID);
					}
					state = false;
				}
				if (item.offerCategory === 'VIDEO-DTV' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
					if (!offerVariables.isRecommendationSuccess || (offerVariables.isRecommendationSuccess && this.checkServiceRecommendation(offerVariables, 'VIDEO-DTV'))) {
						offerVariables.dtvExisting = true;
						offerVariables.videoOffer = true;
						offerVariables.videoSelected = 'DTV';
						offerVariables.newVideoSelected = 'DTV';
						if (data && data.payload && data.payload.retrievalTypes) {
							offerVariables.dtvLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDTV);
						}
						state = false;
					}
				}
				if (item.offerCategory === 'VOICE-DHP' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
					if (!offerVariables.isRecommendationSuccess || (offerVariables.isRecommendationSuccess && this.checkServiceRecommendation(offerVariables, 'VOICE-DHP'))) {
						offerVariables.dhpExisting = true;
						offerVariables.phoneOffer = true;
						offerVariables.phoneSelected = 'DHP';
						offerVariables.newPhoneSelected = 'DHP';
						if (data && data.payload && data.payload.retrievalTypes) {
							offerVariables.dhpLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cDHP);
						}
						state = false;
					}
				}
				if (item.offerCategory === 'VOICE-HP' && item.offerType !== 'SUBOFFER' && item.action !== 'REMOVE') {
					if (!offerVariables.isRecommendationSuccess || (offerVariables.isRecommendationSuccess && this.checkServiceRecommendation(offerVariables, 'VOICE-HP'))) {
						offerVariables.selectedHP = item.productOfferingId;
						offerVariables.selectedPhoneOfferdId = item.productOfferingId;
						offerVariables.hpExisting = true;
						offerVariables.hpOfferType = item.offerType;
						offerVariables.phoneOffer = true;
						offerVariables.phoneSelected = 'HMP';
						offerVariables.newPhoneSelected = 'HMP';
						if (data && data.payload && data.payload.retrievalTypes) {
							offerVariables.phoneLink = this.filterCategory(data.payload.retrievalTypes[0].offers, GenericValues.cHP);
						}
						state = false;
					}
				}
				if (offerVariables.internetAvail && item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData && item.action !== 'REMOVE') {
					let hsiRecommended = false;
					if (offerVariables.isRecommendationSuccess) {
						hsiRecommended = this.checkServiceRecommendation(offerVariables, GenericValues.sData) || this.checkServiceRecommendation(offerVariables, GenericValues.iData);
					}
					if (!offerVariables.isRecommendationSuccess || hsiRecommended) {
						if (item.offerType === 'SUBOFFER') {
							offerVariables.existingAddonsHSI = item;
						}
						offerVariables.internetCheck = true;
					}
				}
			});
		}
		return state;
	}
	private setServicefromRecommendation(offerVariables) {
		if (offerVariables.internetAvail && (offerVariables.recommendedObj[GenericValues.sData] || offerVariables.recommendedObj[GenericValues.iData])) {
			offerVariables.internetCheck = true;
		}
		if (offerVariables.recommendedObj['VIDEO-DTV']) {
			offerVariables.videoOffer = true;
			offerVariables.videoSelected = 'DTV';
			offerVariables.newVideoSelected = 'DTV';
		}
		if (offerVariables.recommendedObj['VOICE-DHP']) {
			offerVariables.addDhpfromRecommendation = true;
		}
		if (offerVariables.recommendedObj['VOICE-HP']) {
			offerVariables.phoneOffer = true;
			offerVariables.phoneSelected = 'HMP';
			offerVariables.newPhoneSelected = 'HMP';
		}
	}

	public notAvailProd(offerVariables) {
		if (!offerVariables.internetAvail && offerVariables.hsiExisting) {
			offerVariables.removeResponse && offerVariables.removeResponse.forEach(rsn => {
				if (rsn.rsnCode === 'MRNA') {
					offerVariables.removeSelectedReason = rsn;
				}
			});
			for (let i = 0; i < offerVariables.existingServices.length; i++) {
				let existProduct = cloneDeep(offerVariables.existingServices[i]);
				if (existProduct.offerCategory === GenericValues.sData || existProduct.offerCategory === GenericValues.iData
					|| existProduct.offerCategory === GenericValues.cDHP || existProduct.offerCategory === GenericValues.cDTV) {
					offerVariables.isInternetRemoved = true;
					existProduct.action = 'REMOVE';
					existProduct.catalogId = existProduct.catalogId === null ? offerVariables.hsiCatalogId : existProduct.catalogId;
					offerVariables.removedProductItem.push(existProduct);
				}
			}
		}
	}

	public callApiForChange(offerVariables, store: Store<AppStore>, state: boolean, data: any) {
		offerVariables.orderRefNumber = data.orderInit.orderRefNumber;
		offerVariables.processInstanceId = data.orderInit.processInstanceId;
		if (!offerVariables.taskId) {
			offerVariables.taskId = data.orderInit.taskId;
		}
		offerVariables.taskName = data.orderInit.taskName;
		offerVariables.serviceSpec = data.orderInit.payload.serviceCategory;
		offerVariables.videoAvail = data.videoCheck;
		offerVariables.phoneAvail = data.phoneCheck;
		offerVariables.phoneArray = data.phoneType;
		offerVariables.videoArray = data.videoType;
		offerVariables.internetAvail = data.internetCheck;
		offerVariables.enabledServiceList = data.enabledServiceList;
		offerVariables.ban = data.ban;
		let user = <Observable<User>>this.store.select('user');
		user.subscribe(
			(data) => {
				offerVariables.isDtvOpus = data.isDtvOpus;
				if (data.previousUrl !== '/existing-products') { offerVariables.isReEntrant = true; }
				if (data.selfinstallselected) { offerVariables.selfinstallSelected = true; }
				if (data && data.existsServices && data.existsServices.indexOf('INTERNET') > -1) {
					offerVariables.isHSIExistingProduct = true;
				}
				if (data && data.finalAddress && data.finalAddress.locationAttributes && data.finalAddress.locationAttributes.legacyProvider) {
					offerVariables.legacyProvider = data.finalAddress.locationAttributes.legacyProvider;
				}
			});
		offerVariables.holdCalled && data && data.existingProductsAndServices && data.existingProductsAndServices.forEach((item) => {
			let existingItems: any;
			if (data.orderFlow.type === 'fromHold') {
				existingItems = offerVariables.holdedObjects.orderDocument.existingServices;
			} else {
				existingItems = item.existingServices.existingServiceItems;
			}
			this.dropDownPopulationforHP(existingItems, false, offerVariables);
			item && item.productConfiguration && item.productConfiguration.forEach((data) => {

				if (!offerVariables.isDtvOpus) {
					if (data && data.productType === GenericValues.cDTV) {
						data.configItems && data.configItems.forEach((config) => {
							config && config.configDetails && config.configDetails.forEach((details) => {
								if (details && details.formName === 'DTV AccountID') {
									details.formItems && details.formItems.forEach((items) => {
										if (items && items.attributeName === 'DIRECTV Account ID') {
											if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
												offerVariables.directvAccountId = items.attributeValue[0].value;
											}
										}
									});
								}
							});
						});
					}
				}

				if (data && data.productType === GenericValues.iData) {
					data.configItems && data.configItems.forEach((config) => {
						config && config.configDetails && config.configDetails.forEach((details) => {
							if (details && details.formName === 'Devices') {
								details.formItems && details.formItems.forEach((items) => {
									if (items && items.attributeName === 'Quantity') {
										if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
											offerVariables.selectedQuantity = items.attributeValue[0].value;
											offerVariables.deviceSelected = true;
										}
									}
								});
							}
						});
					});
				}

			})
		})
		if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices &&
			data.existingProductsAndServices[0].existingServices.existingServiceItems) {
			let existServices = data.existingProductsAndServices[0].existingServices.existingServiceItems;
			offerVariables.existingServices = existServices;
			if (!offerVariables.isReEntrant) {
				state = this.selectedProductsFromExisting(offerVariables, existServices, data, state, true);
				this.setServicefromRecommendation(offerVariables);
			}
		}
		offerVariables.retainedPotsBooleans = {
			retainValueForPotsJack: offerVariables.retainValueForPotsJack
		}
		if (offerVariables.undoSelected) {
			offerVariables.voiceMailValue = 'No';
			offerVariables.voiceMailCondi = false;
			offerVariables.voiceMail = false;
			offerVariables.wireMaintainCondi = false;
			offerVariables.wireMaintainance = false;
			if (offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.retainValueForPotsJack) { offerVariables.retainedPotsBooleans.retainValueForPotsJack = undefined; }
		}

		if (offerVariables.holdCalled && offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument && offerVariables.holdedObjects.orderDocument.customerOrderItems) {
			let existingItems = offerVariables.holdedObjects.orderDocument.customerOrderItems;
			this.dropDownPopulationforHP(existingItems, true, offerVariables);
		}
		offerVariables.retainedPotsBooleans = {
			wireMaintainance: offerVariables.wireMaintainance,
			voiceMail: offerVariables.voiceMail,
			retainValueForPotsJack: offerVariables.retainValueForPotsJack
		}
		let userData = this.appStateService.getState().user;
		if (userData.autoLogin) {
			if (userData && userData.autoLogin && userData.autoLogin !== undefined && userData.autoLogin.oamData && userData.autoLogin.oamData !== null && userData.autoLogin.oamData !== undefined) {
				offerVariables.agentCuid = userData.autoLogin && userData.autoLogin.oamData.agentCuid ? userData.autoLogin.oamData.agentCuid : '';
				offerVariables.firstName = userData.autoLogin && userData.autoLogin.oamData.agentFirstName;
				offerVariables.lastName = userData.autoLogin && userData.autoLogin.oamData.agentLastName;
				offerVariables.ensembleId = userData.autoLogin && userData.autoLogin.oamData.ensembleId ? userData.autoLogin.oamData.ensembleId : '';
			}
		}
		let retSubscribe: Subscription;
		if (userData.previousUrl !== '/existing-products' || offerVariables.fromHold) {
			offerVariables.isReEntrant = true;
			offerVariables.reEntrant = true;
			offerVariables.reentrantUI = true;
			let retainVal = <Observable<any>>this.store.select('retain');
			retSubscribe = retainVal.subscribe(
				(retVal => {
					if (!state) {
						offerVariables.isConverted = retVal.isConverted;
						offerVariables.taskId = userData.taskId;
						if (retVal.potsBooleans) { offerVariables.retainedPotsBooleans = retVal.potsBooleans; }
						if (offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.wireMaintainance !== undefined) {
							offerVariables.wireMaintainance = offerVariables.retainedPotsBooleans.wireMaintainance;
							offerVariables.retainedPotsBooleans.wireMaintainance ? offerVariables.isWireMaintainanceYesSelected = true : offerVariables.isWireMaintainanceNoSelected = true
						}
						if (offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.voiceMail) {
							offerVariables.voiceMail = offerVariables.retainedPotsBooleans.voiceMail;
							offerVariables.voiceMailValue = 'Yes';
						}
						if (offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.portingCheck !== undefined) {
							offerVariables.portingCheck = offerVariables.retainedPotsBooleans.portingCheck;
						}
						if (offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.selectedMaintainance !== undefined) {
							offerVariables.selectedMaintainance = offerVariables.retainedPotsBooleans.selectedMaintainance;
						}
						if (offerVariables.retainedPotsBooleans && offerVariables.retainedPotsBooleans.isInternational !== undefined) {
							offerVariables.isInternational = offerVariables.retainedPotsBooleans.isInternational;
							offerVariables.dhpIntlSelected = offerVariables.isInternational ? 'Yes' : 'No';
						}
						offerVariables.cartObject = retVal.addOns;
						offerVariables.cartCopyObject = retVal.addOns;
						offerVariables.e911ValidatedAddress = retVal.e911ValidatedAddress;
						let custOrderItem: CustomerOrderItems[] = offerVariables.holdCalled ? offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument &&
							offerVariables.holdedObjects.orderDocument.customerOrderItems : retVal.addOns.payload.cart.customerOrderItems;

						if (!offerVariables.cartObject) {
							offerVariables.cartObject = {
								payload: {
									cart: {
										customerOrderItems: custOrderItem
									},
									productConfiguration: offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument &&
										offerVariables.holdedObjects.orderDocument.productConfiguration
								}
							}
						}
						// to retain jack values
						offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart && offerVariables.cartObject.payload.cart.customerOrderItems.forEach(cust => {
							if (cust && cust.offerCategory === GenericValues.cHP && cust.offerType !== 'SUBOFFER') {
								if (offerVariables.voiceMailValue !== 'Yes') { offerVariables.voiceMailValue = 'No'; }
								if (offerVariables.wireMaintainanceValue !== 'Yes') { offerVariables.wireMaintainanceValue = 'No'; }
								cust.customerOrderSubItems && cust.customerOrderSubItems.forEach(exSub => {
									if (exSub.productName.indexOf('Jack and Wire') !== -1) {
										offerVariables.retainValueForPotsJack = exSub.productAttributes[0].compositeAttribute[0].attributeValue
									}
								});
							}
						})
						if (offerVariables.retainValueForPotsJack !== undefined && offerVariables.retainValueForPotsJack) {
							offerVariables.retainedPotsBooleans.retainValueForPotsJack = offerVariables.retainValueForPotsJack;
						}
						offerVariables.cartCopyObject = cloneDeep(offerVariables.cartObject);
						if (offerVariables.cartCopyObject && offerVariables.cartCopyObject.payload && offerVariables.cartCopyObject.payload.productConfiguration) {
							let selectConfigList = offerVariables.cartCopyObject.payload.productConfiguration;
							if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
								for (let i = 0; i < selectConfigList.length; i++) {
									selectConfigList[i].configItems && selectConfigList[i].configItems.forEach(selectedConf => {
										offerVariables.selectedQuantity = selectedConf.configDetails[0].formItems[0].attributeValue[0].value;
										offerVariables.deviceSelected = true;
									});
								}
							}
						}
						if (offerVariables.cartObject) {
							if (offerVariables.cartObject.payload.cart.customerOrderItems !== undefined && offerVariables.cartObject.payload.cart.customerOrderItems.length > 0) {
								offerVariables.cartObject.payload.cart.customerOrderItems.forEach((item) => {
									if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
										if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { offerVariables.hsiExisting = true; }
									} else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
										offerVariables.removedProductItem.push(item);
									}
									if (item.offerCategory === 'VIDEO-PRISM' && item.action !== 'REMOVE') {
										offerVariables.videoOffer = true;
										offerVariables.videoSelected = 'PTV';
										state = false;
									}
									if (item.offerCategory === 'VIDEO-DTV' && item.action !== 'REMOVE') {
										if(item.action !== 'ADD') { offerVariables.dtvExisting = true; }
										offerVariables.videoOffer = true;
										offerVariables.videoSelected = 'DTV';
										state = false;
									} else if (item.offerCategory === 'VIDEO-DTV' && item.action === 'REMOVE') {
										offerVariables.removeSelectedReason = retVal.removeReason;
										offerVariables.removedProductItem.push(item);
										offerVariables.dtvExisting = true;
										state = false;
									}
									if (item.offerCategory === 'VOICE-DHP' && item.action !== 'REMOVE') {
										if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { offerVariables.dhpExisting = true; }
										offerVariables.phoneOffer = true;
										offerVariables.phoneSelected = 'DHP';
										state = false;
									} else if (item.offerCategory === 'VOICE-DHP' && item.action === 'REMOVE') {
										offerVariables.removeSelectedReason = retVal.removeReason;
										offerVariables.removedProductItem.push(item);
										offerVariables.dhpExisting = true;
										offerVariables.isDHPRemoved = true;
										state = false;
									}
									if (item.offerCategory === 'VOICE-HP' && item.action !== 'REMOVE') {
										if(item.action !== 'ADD' && item.offerType !== 'SUBOFFER') { offerVariables.hpExisting = true; }
										if(item.action === 'ADD' && item.offerType !== 'SUBOFFER') { offerVariables.hpExisting = false; }
										offerVariables.phoneOffer = true;
										offerVariables.phoneSelected = 'HMP';
										if (item.offerType !== 'SUBOFFER') {
											offerVariables.selectedPhoneOfferdId = item.productOfferingId;
											offerVariables.selectedHP = item.productOfferingId;
										}
										state = false;
									} else if (item.offerCategory === 'VOICE-HP' && item.action === 'REMOVE') {
										offerVariables.removeSelectedReason = retVal.removeReason;
										offerVariables.removedProductItem.push(item);
										offerVariables.hpExisting = true;
										offerVariables.isHPRemoved = true;
										state = false;
									}
									if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action !== 'REMOVE') {
										if (item.offerType === 'SUBOFFER') {
											offerVariables.existingAddonsHSI = item;
										}
										offerVariables.internetCheck = true;
										offerVariables.newInternetCheck = true;
									} else if ((item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) && item.action === 'REMOVE') {
										if (item.offerType === 'SUBOFFER') {
											offerVariables.removeSelectedReason = retVal.removeReason;
											offerVariables.removedProductItem.push(item);
											offerVariables.existingAddonsHSI = item;
										}
									}
									if (offerVariables.phoneSelected === 'DHP') {
										let dhp = this.getExistingProducts(offerVariables.cartCopyObject.payload.cart.customerOrderItems, GenericValues.cDHP);
										if (dhp && dhp.customerOrderSubItems !== null && dhp.customerOrderSubItems
											&& dhp.customerOrderSubItems.length !== 0) {
											dhp.customerOrderSubItems.forEach(subItems => {
												if (subItems && subItems.productName === 'Digital Home Phone Intl Call') {
													subItems.productAttributes.forEach(subAttr => {
														if ((subAttr && subAttr.compositeAttribute !== null && subAttr.compositeAttribute.length !== 0
															&& subAttr.compositeAttribute[0].attributeName === 'Service Status')) {
															subAttr.compositeAttribute[0].attributeValue === 'Enabled'
																|| subAttr.compositeAttribute[0].attributeValue.toString().toLowerCase() === 'yes' ? offerVariables.dhpIntlSelected = 'Yes' :
																offerVariables.dhpIntlSelected = 'No';
															offerVariables.dhpIntlSelected === 'Yes' ? offerVariables.isInternational = true : offerVariables.isInternational = false;
														}
													});
												}
											});
										}
										if (offerVariables.fromHold && offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument &&
											offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo && offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address) {
											offerVariables.e911ValidatedAddress = offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.e911Address;
											offerVariables.e911ValidatedAddress.acceptedData = offerVariables.holdedObjects.orderDocument.dhpAdditionalInfo.dhpDisclaimerAcceptDateTime;
										}
									}
								});
							}
						}
						state = true;
						offerVariables.calledFromConstructor = true;
					}
				})
			)
		}
		else {
			if (!state) {
				let moreServices = offerVariables.existingServices;

				if (!offerVariables.internetCheck && moreServices !== undefined && moreServices.length >= 1) {
					moreServices.forEach((item) => {
						if (item.offerCategory === 'VOICE-HP') {
							offerVariables.hpExisting = true;
							offerVariables.phoneOffer = true;
							offerVariables.phoneSelected = 'HMP';
							state = false;
						}
					});
				}

				if (offerVariables.hsiCatalogId === undefined && moreServices) {
					moreServices.forEach((item) => {
						if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
							offerVariables.hsiCatalogId = item.catalogId;
							offerVariables.cartContractTerm = item.contractTerm;
						}
						if ((item.offerCategory === 'VOICE-DHP' || item.offerCategory === 'VOICE-HP') && item.action !== 'REMOVE') {
							item.offerCategory === 'VOICE-HP' ? offerVariables.hpExisting = true : offerVariables.dhpExisting = true;
							offerVariables.phoneCatalogId = item.catalogId;
							offerVariables.cartContractTermDHP = item.contractTerm;
						}
						if (item.offerCategory === 'VIDEO-DTV' && item.action !== 'REMOVE') {
							offerVariables.dtvCatalogId = item.catalogId;
							offerVariables.cartContractTermDTV = item.contractTerm;
						}
					});
				}
				state = true;
				offerVariables.calledFromConstructor = true;
			}
		}
		if (offerVariables.isReEntrant && data.recommendedFailure) {
			offerVariables.recommendationFailure = data.recommendedFailure;
		}
		if (retSubscribe !== undefined) {
			retSubscribe.unsubscribe();
		}

		this.fetchExistingProducts(offerVariables, offerVariables.existingServices);
		this.notAvailProd(offerVariables);

		offerVariables.calledFromConstructor = true;
		this.retrieveOffers(offerVariables, true, 'fromSlot');

		return state;
	}
	public setDiscountsFromExistingDiscounts(offerVariables, existingDiscounts) {
		offerVariables.existingRetentionDiscounts = [];
		if (existingDiscounts && existingDiscounts.orderDiscounts && existingDiscounts.orderDiscounts[0] && existingDiscounts.orderDiscounts[0].productDiscounts) {
			for (let i = 0; i < existingDiscounts.orderDiscounts[0].productDiscounts.length; i++) {
				let exisProductDisc = existingDiscounts.orderDiscounts[0].productDiscounts[i];
				for (let j = 0; j < existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails.length; j++) {
					if ((existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'R' || existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'P')
						&& existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDuration >= 1) {
						var tempDiscDetail = existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j];
						tempDiscDetail.productType = exisProductDisc.productType;
						tempDiscDetail.discountExpiryDate = this.getYMDTStoMDY(tempDiscDetail.discountExpiryDate);
						offerVariables.existingRetentionDiscounts.push(tempDiscDetail);
						let exisTempDiscDetail = cloneDeep(tempDiscDetail);
						if (exisProductDisc.productName && offerVariables.discArray) {
							exisTempDiscDetail.productName = exisProductDisc.productName;
							exisTempDiscDetail.selected = false;
							offerVariables.discArray.push(exisTempDiscDetail);
						}
					}
				}
			}
		}
	}

	public onInitPage(offerVariables) {
		this.logger.metrics('OfferChangePage');
		window.scroll(0, 0);
		this.getReentrantFlags(offerVariables);
		this.getTechnologyTypes(offerVariables);
		this.compatibilityAPIcall(offerVariables);
		this.checkCSCompatibitlity(offerVariables);
		this.setDiscountsFromExistingDiscounts(offerVariables, offerVariables.existingDiscounts);
		let existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
		existingProductStore$.subscribe((respData) => {
			offerVariables.exisitngData = respData
			if (offerVariables.exisitngData && offerVariables.exisitngData.existingProductsAndServices && offerVariables.exisitngData.existingProductsAndServices[0] &&
				offerVariables.exisitngData.existingProductsAndServices[0].lifelineInfo) {
				respData.existingProductsAndServices[0].lifelineInfo.forEach((data) => {
					if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "INTERNET") {
						offerVariables.lifelineDHPExisting = true;
					}
					if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-HP") {
						offerVariables.lifelineDHPExisting = true;
					}
					if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-DHP") {
						offerVariables.lifelineDHPExisting = true;
					}
				});
			}
		});
		this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: { type: '', selected: '' } } });
	}
	public undoAll(offerVariables) {
		offerVariables.loading = true;
		offerVariables.undoSelected = true;
		this.initilizeAll(offerVariables, offerVariables.undoSelected);
		this.onInitPage(offerVariables);
		offerVariables.undoFlag = false;
		offerVariables.loading = false;
	}

	public retrieveOffers(offerVariables, flag: boolean, fromSlot?, isPOTS?: boolean, CB?: Function) {
		if (!flag && !fromSlot) { offerVariables.calledFromConstructor = false; }
		offerVariables.errorMsg = '';
		offerVariables.warningMsg = '';
		offerVariables.expiredOffers = [];
		offerVariables.retrieveOffersLoading = true;
		offerVariables.loading = true;
		offerVariables.matchingOffers = [];
		offerVariables.videoOffer = false;
		offerVariables.modemAvailable = false;
		offerVariables.selfInstallAvailable = false;
		offerVariables.phoneOffer = false;
		offerVariables.isDHP = false;
		offerVariables.isPOTS = false;
		offerVariables.secureWifiError = false;
		offerVariables.easeError = false;
		offerVariables.modemError = false;
		offerVariables.installError = false;
		offerVariables.deviceMandatory = false;
		offerVariables.totalDiscountAmount = 0;
		offerVariables.jackError = false;
		offerVariables.deviceSelected = true;
		// check values that were selected and set the values
		if (offerVariables.flow !== "BILLING" && offerVariables.flow !== "stackAmend") {
			if (offerVariables.newInternetCheck !== null && typeof (offerVariables.newInternetCheck) !== "undefined") {
				offerVariables.internetCheck = offerVariables.newInternetCheck;
			}
			else {
				offerVariables.newInternetCheck = offerVariables.internetCheck;
			}

			if (offerVariables.newPhoneSelected && !offerVariables.isReEntrant) {
				offerVariables.phoneSelected = offerVariables.newPhoneSelected;
			}
			else if (offerVariables.newPhoneSelected && offerVariables.isReEntrant && offerVariables.newPhoneUpdated) {
				offerVariables.phoneSelected = offerVariables.newPhoneSelected;
			}
			else {
				offerVariables.newPhoneSelected = offerVariables.phoneSelected;
			}

			if (offerVariables.newVideoSelected && !offerVariables.isReEntrant) {
				offerVariables.videoSelected = offerVariables.newVideoSelected;
			}
			else if (offerVariables.newVideoSelected && offerVariables.isReEntrant && offerVariables.newVideoUpdated) {
				offerVariables.videoSelected = offerVariables.newVideoSelected;
			}
			else {
				offerVariables.newVideoSelected = offerVariables.videoSelected;
			}
		} else if ((offerVariables.flow === "BILLING" && offerVariables.isReEntrant) || (offerVariables.flow === "BILLING" && offerVariables.isInternetRemoved === true)) {
			offerVariables.newInternetCheck = offerVariables.internetCheck;
		} else if (offerVariables.flow === "stackAmend") {
			if (offerVariables.newInternetCheck && !offerVariables.isReEntrant) {
				offerVariables.internetCheck = offerVariables.newInternetCheck;
			}
			else if (offerVariables.isReEntrant) {
				offerVariables.newInternetCheck = offerVariables.internetCheck;
			}

			if (offerVariables.newPhoneSelected && !offerVariables.isReEntrant && offerVariables.hpExisting && offerVariables.newPhoneSelected !== GenericValues.noPhone) {
				offerVariables.phoneSelected = offerVariables.newPhoneSelected;
			} else if (offerVariables.newPhoneSelected && !offerVariables.isReEntrant && !offerVariables.hpExisting) {
				offerVariables.phoneSelected = offerVariables.newPhoneSelected;
			}
			else if (offerVariables.newPhoneSelected && offerVariables.isReEntrant && offerVariables.newPhoneUpdated) {
				offerVariables.phoneSelected = offerVariables.newPhoneSelected;
			}
			else {
				offerVariables.newPhoneSelected = offerVariables.phoneSelected;
			}

			if (offerVariables.newVideoSelected && !offerVariables.isReEntrant) {
				offerVariables.videoSelected = offerVariables.newVideoSelected;
			}
			else {
				offerVariables.newVideoSelected = offerVariables.videoSelected;
			}
			if (offerVariables.hpExisting && offerVariables.voiceMailValue === 'na') { offerVariables.voiceMailValue = 'No'; }
		}
		offerVariables.newVideoSelected = offerVariables.videoSelected;
		if (offerVariables.removedProductItem && offerVariables.removedProductItem.length > 0) {
			for (let i = 0; i < offerVariables.removedProductItem.length; i++) {
				if ((offerVariables.removedProductItem[i].offerCategory === GenericValues.sData || offerVariables.removedProductItem[i].offerCategory === GenericValues.iData) && offerVariables.internetCheck) {
					offerVariables.removedProductItem.splice(i, 1);
					offerVariables.isInternetRemoved = false;
				} else if (offerVariables.removedProductItem[i].offerCategory === GenericValues.cHP && offerVariables.phoneSelected === 'HMP') {
					offerVariables.removedProductItem.splice(i, 1);
				} else if (offerVariables.removedProductItem[i].offerCategory === GenericValues.cDHP && offerVariables.phoneSelected === 'DHP') {
					offerVariables.removedProductItem.splice(i, 1);
				} else if (offerVariables.removedProductItem[i].offerCategory === GenericValues.cDTV && offerVariables.videoSelected === 'DTV') {
					offerVariables.removedProductItem.splice(i, 1);
					offerVariables.optedOutCheck = false;
					offerVariables.isOptedOut = false;
				}
			}
		}
		if (offerVariables.phoneSelected === 'DHP' && offerVariables.flow === 'MOVE') { offerVariables.selectedDHPOffer = undefined; }
		offerVariables.selected = '';
		if (offerVariables.flow === 'CHANGE' || offerVariables.flow === 'MOVE') {
			this.availableCategory(offerVariables);
			if (offerVariables.selected === '') {
				offerVariables.enabledServiceList && offerVariables.enabledServiceList.forEach(category => {
					if (category && category.serviceCategory === GenericValues.iData) {
						offerVariables.internetCheck = true;
					} else if (category && category.serviceCategory === GenericValues.cHP) {
						offerVariables.phoneSelected = 'HMP';
						offerVariables.newPhoneSelected = 'HMP';
					} else if (category && category.serviceCategory === GenericValues.cDHP) {
						offerVariables.phoneSelected = 'DHP'
						offerVariables.newPhoneSelected = 'DHP';
					}
					/* else if(category && category.serviceCategory === GenericValues.cDTV) {
						offerVariables.videoSelected = 'DTV'
					} */
				})
				this.availableCategory(offerVariables);
			}
		}
		this.filterSpeed("All Speed options", true, offerVariables);
		// offerVariables.offerBillingType = offerVariables.flow === 'NEWINSTALL'?  'ALL' : offerVariables.offerBillingType === "PREPAID" ? offerVariables.offerBillingType : "POSTPAID";
		if (offerVariables.flow !== 'NEWINSTALL') { offerVariables.offerBillingType = offerVariables.offerBillingType === "PREPAID" ? offerVariables.offerBillingType : "POSTPAID"; }
		offerVariables.filterCriteria = this.getfilterCriteria(offerVariables);
		const item: any = {
			offerBillingType: offerVariables.flow === 'NEWINSTALL' ? 'ALL' : offerVariables.offerBillingType,
			internet: offerVariables.flow === "stackAmend" ? offerVariables.internetCheck : offerVariables.newInternetCheck,
			tv: offerVariables.videoAvail,
			phone: offerVariables.phoneAvail,
			orderRefNumber: offerVariables.orderRefNumber,
			taskId: offerVariables.taskId,
			processInstanceId: offerVariables.processInstanceId,
			taskName: offerVariables.taskName,
			enabledServiceList: offerVariables.enabledServiceList,
			phoneSelected: offerVariables.phoneSelected,
			videoSelected: offerVariables.videoSelected,
			filterCriteria: offerVariables.filterCriteria
		};

		if (offerVariables.internetCheck) {
			offerVariables.selected = 'Internet,';
		}
		offerVariables.internetOffer = offerVariables.internetCheck;
		if (offerVariables.videoSelected !== 'NoTV') {
			offerVariables.videoOffer = true;
			offerVariables.selected += 'TV';
		}
		if (offerVariables.phoneSelected !== GenericValues.noPhone) {
			offerVariables.phoneOffer = true;
			if (offerVariables.phoneSelected === 'DHP') {
				offerVariables.selected += 'DHPhone';
				offerVariables.isDHP = true;
			} else {
				offerVariables.selected += 'HMPhone';
				offerVariables.isPOTS = true;
			}
		}
		if (offerVariables.phoneSelected === 'DHP') {
			offerVariables.voiceMail = undefined;
			offerVariables.selectedJackForPots = undefined;
			offerVariables.wireMaintainance = undefined;
		}
		offerVariables.phoneOfferTemp = offerVariables.phoneOffer;
		offerVariables.phoneSelectedTemp = offerVariables.phoneSelected;
		offerVariables.videoOfferTemp = offerVariables.videoOffer;
		offerVariables.videoSelectedTemp = offerVariables.videoSelected;
		let currentFlowName = '';
		if (offerVariables.flow === "BILLING" || offerVariables.flow === "BILLANDREC") {
			currentFlowName = 'billing';
		} else if (offerVariables.flow === "CHANGE" || offerVariables.flow === "stackAmend") {
			currentFlowName = 'change';
		} else if (offerVariables.flow === "MOVE") {
			currentFlowName = 'move';
		}
		let cart: ShoppingCart;
		cart = {
			selectedService: offerVariables.selected
		};
		this.store.dispatch({ type: 'CREATE_CART', payload: cart });
		if (offerVariables.flow === 'BILLING' || offerVariables.flow === "BILLANDREC" || offerVariables.flow === "CHANGE" || offerVariables.flow === "MOVE" || offerVariables.flow === "stackAmend") {
			if (flag || !flag) {
				this.logger.log("info", offerVariables.currentComponentName, "selectProductRequest", JSON.stringify(item));
				this.logger.log("info", offerVariables.currentComponentName, "getOffersRequest", JSON.stringify(item));
				this.logger.startTime();
				offerVariables.loading = true;
				this.productService.getOffers(item, currentFlowName)
					.catch((error: any) => {
						this.logger.endTime();
						this.logger.log("error", offerVariables.currentComponentName, "getOffersResponse", error);
						this.logger.log("error", offerVariables.currentComponentName, "getOffersSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
						offerVariables.loading = false;
						this.logger.log("error", offerVariables.currentComponentName, "selectProductResponse", JSON.stringify(error));
						this.logger.log("error", offerVariables.currentComponentName, "selectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit task - Offer ", offerVariables.currentComponentName, "Create Cart - Offer Page", error);
						return Observable.throwError(null);
					})
					.subscribe(
						(data) => {
							offerVariables.catalogSpecId = data.payload.cart.catalogSpecId;
							offerVariables.taskId = data.taskId;
							this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
							offerVariables.loading = false;
							this.logger.endTime();
							this.logger.log("info", offerVariables.currentComponentName, "selectProductResponse", JSON.stringify(data ? data : ''));
							this.logger.log("info", offerVariables.currentComponentName, "selectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
							if (!offerVariables.recommendationFailure && data.payload.recommendedObject && data.payload.recommendedObject.length > 0 && offerVariables.flow === 'CHANGE') {
								data.payload.recommendedObject.forEach((recom) => {
									if (recom.errorInfo && recom.errorInfo.length > 0) {
										offerVariables.isRecommendationSuccess = true;
										recom.errorInfo.forEach(error => {
											if (error.status !== '200') {
												offerVariables.isRecommendationSuccess = false;
											}
										});
									}
								});
								if (!offerVariables.isRecommendationSuccess) {
									offerVariables.recommendedObj = {};
									offerVariables.taskId = data.taskId;
									this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
									offerVariables.recommendationFailure = true;
									this.store.dispatch({ type: 'RECOMMENDATION_FAILURE_SHOWN', payload: offerVariables.recommendationFailure });
									this.undoAll(offerVariables);
									offerVariables.recommendedError.open();
									return;
								}
								if (offerVariables.recommendationFailure) {
									return;
								}
								offerVariables.recommendedObject = data.payload.recommendedObject;
								if (offerVariables.recommendedObject && offerVariables.recommendedObject.length > 0 && offerVariables.isRecommendationSuccess) {
									this.store.dispatch({ type: 'RECOMMENDATION', payload: true });
									this.createRecommendedDataObj(offerVariables, offerVariables.recommendedObject[0]);
								}
							}
							this.primaryHSIOffer(data, offerVariables);
							this.isExAreaCallPresentAndFetchPrice(offerVariables, data);
							offerVariables.shippingNHandlingChargeObj = this.shipAndHandlingChargesForSelfInstall(data);
							if (offerVariables.shippingNHandlingChargeObj) {
								offerVariables.shippingNHandlingCharge = 0;
								offerVariables.shippingNHandlingChargeObj.productAttributes && offerVariables.shippingNHandlingChargeObj.productAttributes.forEach((attr) => {
									if (attr.prices && (attr.prices.length > 0)) {
										attr.prices.forEach((p) => {
											if (p.priceType === 'PRICE') {
												offerVariables.shippingNHandlingCharge += this.ctlHelperService.getSummedOtc(attr.prices);
											}
										});
									}
								});
							}
							if (offerVariables.shippingNHandlingChargeObj && (offerVariables.shippingNHandlingCharge > 0) && offerVariables.selfinstallSelected && offerVariables.isReEntrant) {
								this.shoppingCartRequest(offerVariables);
							}
							if (CB) { CB(data); }
							offerVariables.loading = false;
							offerVariables.retrieveOffersLoading = false;
						},
						error => {
							offerVariables.loading = false;
							if (error === undefined || error === null) { return; }
							let unexpectedError = false;
							if (this.ctlHelperService.isJson(error)) {
								let apiResponseError = JSON.parse(error);
								if (
									apiResponseError !== undefined &&
									apiResponseError !== null &&
									apiResponseError.errorResponse &&
									apiResponseError.errorResponse.length > 0
								) {
									this.systemErrorService.logAndeRouteToSystemError(
										"error",
										"selectProductError ",
										offerVariables.currentComponentName,
										"Offers Page",
										apiResponseError
									);
								} else { unexpectedError = true; }
							} else { unexpectedError = true; }
							if (unexpectedError) {
								let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
									offerVariables.orderRefNumber
								);
								this.systemErrorService.logAndeRouteToSystemError(
									"error",
									"selectProductError ",
									offerVariables.currentComponentName,
									"Offers Page",
									lAPIErrorLists
								);
							}
							offerVariables.retrieveOffersLoading = false;
						}
					);
			} else {
				let payload: PayloadProduct;
				if (offerVariables.internetCheck && offerVariables.videoOffer && offerVariables.phoneOffer) {
					offerVariables.hsiOnlyPresent = false;
					let link: any;
					offerVariables.loading = true;
					offerVariables.retrieveOffersLoading = true;
					this.logger.log("info", offerVariables.currentComponentName, "selectProductFromDataLinkRequest", JSON.stringify(offerVariables.dataLink));
					this.logger.startTime();
					link = offerVariables.phoneSelected === 'DHP' ? offerVariables.dhpLink : offerVariables.phoneLink;
					this.getDATAoffers(payload, link);
				} else if (offerVariables.internetCheck && !offerVariables.videoOffer && !offerVariables.phoneOffer) {
					offerVariables.hsiOnlyPresent = true;
					this.logger.log(
						"info",
						offerVariables.currentComponentName,
						"selectProductFromDataLinkRequest",
						JSON.stringify(offerVariables.dataLink)
					);
					this.logger.startTime();
					this.getDATAoffers(payload, offerVariables);
				} else if (
					(offerVariables.internetCheck && offerVariables.videoOffer && !offerVariables.phoneOffer) ||
					(!offerVariables.internetCheck &&
						offerVariables.videoOffer &&
						offerVariables.phoneOffer &&
						offerVariables.phoneSelected === "HMP")
				) {
					offerVariables.hsiOnlyPresent = false;

					let link: any;
					link = offerVariables.videoSelected === "DTV" ? offerVariables.dtvLink : offerVariables.videoLink;
					if (!link) {
						offerVariables.errorMsg = "Cannot find Selected Offer in Response";
						offerVariables.retrieveOffersLoading = false;
						return;
					}

					if (offerVariables.videoSelected === "DTV") {
						offerVariables.loading = true;
						offerVariables.internetCheck
							? this.getDATAoffers(payload, offerVariables)
							: this.getPhoneOffers(payload, offerVariables.phoneLink, offerVariables);
					}

					if (offerVariables.internetCheck) {
						payload = offerVariables.retriveVideoOffers(link, payload);
					}
				} else if (
					(offerVariables.internetCheck && !offerVariables.videoOffer && offerVariables.phoneOffer) ||
					(!offerVariables.internetCheck && offerVariables.phoneSelected === "HMP")
				) {
					offerVariables.hsiOnlyPresent = false;
					let link: any;
					link = offerVariables.phoneSelected === "HMP" ? offerVariables.phoneLink : offerVariables.dhpLink;
					offerVariables.retrieveOffersLoading = true;
					if (offerVariables.internetCheck) {
						offerVariables.loading = true;
						this.getDATAoffers(payload, link);
					} else {
						this.getPhoneOffers(payload, link, offerVariables);
						offerVariables.dhpIntlSelected = "No";
					}
				}
			}
		}
		else {
			this.logger.log("info", "offer.component.ts", "selectProductRequest", JSON.stringify(item));
			this.logger.startTime();
			offerVariables.loading = true;
			this.productService.getOffers(item)
				.catch((error: any) => {
					this.logger.endTime();
					this.logger.log("error", "offer.component.ts", "selectProductResponse", error);
					this.logger.log("error", "offer.component.ts", "selectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.loading = false;
					this.systemErrorService.logAndRouteUnexpectedError(
						"error", 'Not Applicable',
						"submitTask - getOffers", "offer.component.ts",
						"Product Offer Page",
						error);
					return Observable.throwError(null);
				})
				.subscribe(
					(data) => {
						this.logger.endTime();
						this.logger.log("info", "offer.component.ts", "selectProductResponse", JSON.stringify(data ? data : ''));
						this.logger.log("info", "offer.component.ts", "selectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
						offerVariables.loading = false;
						const tempData = cloneDeep(data);
						offerVariables.taskId = data.taskId;
						this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
						this.primaryHSIOffer(tempData, offerVariables);
						this.isExAreaCallPresentAndFetchPrice(offerVariables, tempData);
						this.updateShipAndHandlingObj(offerVariables, offerVariables.selectedInternetOfferdId);
						if (CB) {
							CB(data);
						}
					},
					(error) => {
						this.logger.endTime();
						this.logger.log("error", "offer.component.ts", "selectProductResponse", error);
						this.logger.log("error", "offer.component.ts", "selectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
						offerVariables.loading = false;
						if (error === undefined || error === null || error.message.indexOf('Unexpected') !== -1) {
							return;
						}
						offerVariables.retrieveOffersLoading = false;

						if (this.ctlHelperService.isJson(error)) { offerVariables.apiResponseError = JSON.parse(error); }
						if (offerVariables.apiResponseError && offerVariables.apiResponseError.errorResponse && offerVariables.apiResponseError.errorResponse.length > 0) {
							offerVariables.apiResponseError.errorResponse[0].orderRefNumber = offerVariables.orderRefNumber;
							this.systemErrorService.logAndeRouteToSystemError("error", offerVariables.taskName, "offer.component.ts", "Offer Page", offerVariables.apiResponseError);
						} else {
							offerVariables.errorMsg = serverErrorMessages.serverDown;
							const errorResponseArray: ErrorResponse[] = [];
							const localErrorResponse: ErrorResponse = {
								orderRefNumber: offerVariables.orderRefNumber,
								statusCode: serverErrorMessages.serverDownNumber,
								reasonCode: serverErrorMessages.serverDownNumberErrMessage,
								message: serverErrorMessages.serverDownNumberErrMessage,
								messageDetail: serverErrorMessages.serverDownNumberErrMessage
							}
							errorResponseArray.unshift(localErrorResponse);
							const lAPIErrorLists: APIErrorLists = {
								errorResponse: errorResponseArray
							};
							this.systemErrorService.logAndeRouteToSystemError("error", offerVariables.taskName, "offer.component.ts", "Offer Page", lAPIErrorLists);
						}
					});
		}
	}

	public getfilterCriteria(offerVariables) {
		let filterCriteria: filterCriteria = { "retrievalTypes": undefined };
		if (offerVariables.reentrant) { this.getReentrantFlags(offerVariables); }
		offerVariables.unFilterBool ? (offerVariables.byPassBool ? filterCriteria.retrievalTypes = ["UNQUALIFIED"] : filterCriteria.retrievalTypes = ["UNFILTERED"]) : filterCriteria.retrievalTypes = ["FILTERED"];
		return filterCriteria;
	}

	public primaryHSIOffer(data: any, offerVariables) {
		offerVariables.catalogSpecId = data.payload.cart.catalogSpecId;
		offerVariables.taskId = data.taskId;
		offerVariables.tempTaskId = data.taskId;
		offerVariables.etfValueEnable = false;
		offerVariables.offerResponse = data;
		if (offerVariables.offerResponse && offerVariables.offerResponse.payload && offerVariables.offerResponse.payload !== undefined &&
			offerVariables.offerResponse.payload.retrievalTypes !== undefined && offerVariables.offerResponse.payload.retrievalTypes[0] !== undefined) {
			offerVariables.offerResponse.payload.offers = offerVariables.offerResponse.payload.retrievalTypes[0].offers;
			if (offerVariables.flow !== "MOVE" && offerVariables.offerResponse.payload.offers &&
				(offerVariables.offerResponse.payload.offers !== undefined && offerVariables.offerResponse.payload.offers !== null) &&
				(offerVariables.offerResponse.payload.offers[0].catalogs !== undefined && offerVariables.offerResponse.payload.offers[0].catalogs !== null)) {
				offerVariables.offerResponse.payload.offers[0].catalogs[0].catalogItems.forEach((item) => {
					if (item.productOffer.contract.etf > 0) {
						offerVariables.etfValue = item.productOffer.contract.etf;
						offerVariables.etfValueEnable = true;
					}
				});
			}
		}
		if (offerVariables.flow === 'BILLING' || offerVariables.flow === 'CHANGE') {
			offerVariables.taskId = data.taskId;
			if (data && data.payload && data.payload.serviceAddress) {
				this.store.dispatch({ type: "SERVICE_ADDRESS", payload: data.payload.serviceAddress });
			}
			data.offers = this.sortSpeeds(data.payload.retrievalTypes[0].offers);
			if (offerVariables.offerResponse && offerVariables.offerResponse.payload && offerVariables.offerResponse.payload !== undefined &&
				offerVariables.offerResponse.payload.retrievalTypes !== undefined && offerVariables.offerResponse.payload.retrievalTypes[0] !== undefined) {
				offerVariables.offerResponse.payload.offers = offerVariables.offerResponse.payload.retrievalTypes[0].offers;
			}
		}
		if (offerVariables.flow === 'CHANGE') {
			this.changeSelectProduct(data, false, offerVariables);
		}
		offerVariables.initialOfferResponse = data;
		if (offerVariables.initialOfferResponse && offerVariables.initialOfferResponse.payload && offerVariables.initialOfferResponse.payload !== undefined &&
			offerVariables.initialOfferResponse.payload.retrievalTypes !== undefined && offerVariables.initialOfferResponse.payload.retrievalTypes[0] !== undefined) {
			offerVariables.initialOfferResponse.payload.offers = offerVariables.initialOfferResponse.payload.retrievalTypes[0].offers;
		}
		if (offerVariables.initialOfferResponse && offerVariables.initialOfferResponse.payload && offerVariables.initialOfferResponse.payload.productConfiguration !== null
			&& offerVariables.initialOfferResponse.payload.productConfiguration && offerVariables.initialOfferResponse.payload.productConfiguration.length > 0) {
			offerVariables.productConfiguration = offerVariables.initialOfferResponse.payload.productConfiguration;
		}
		if (offerVariables.flow === "MOVE") {
			offerVariables.internetCheck = this.isExistsInOffer(offerVariables.initialOfferResponse, 'INTERNET', 'DATA');
		}
		if (data.payload.retrievalTypes) {
			offerVariables.offersByFilters = this.retrieveOffersByFilter(data.payload.retrievalTypes);
			offerVariables.qualifiedFilter = offerVariables.offersByFilters.qualifiedFilter;
			offerVariables.unQualifiedOffers = offerVariables.offersByFilters.unQualifiedOffers;
			offerVariables.qualifiedUnfilter = offerVariables.offersByFilters.qualifiedUnfilter;
		}
		this.framingSlot(offerVariables.offerResponse.payload.offers, offerVariables);
		offerVariables.offersGenerated = true;
		if (offerVariables.flow === "stackamend") {
			offerVariables.existingOfferName = this.getOfferDisplayName(data, offerVariables.existingOfferName);
		}
		if (offerVariables.offerResponse && offerVariables.offerResponse.payload && offerVariables.offerResponse.payload !== undefined && offerVariables.offerResponse.payload.giftCardOffers && (offerVariables.offerResponse.payload.giftCardOffers !== undefined && offerVariables.offerResponse.payload.giftCardOffers !== null)) {
			this.store.dispatch({ type: 'INCLUDING_GIFTCARDS', payload: offerVariables.offerResponse.payload.giftCardOffers });
		}
		if (offerVariables.offerResponse !== undefined && offerVariables.offerResponse.payload && offerVariables.offerResponse.payload.offers && (offerVariables.offerResponse.payload.offers !== undefined && offerVariables.offerResponse.payload.offers !== null)) {
			this.store.dispatch({ type: 'INCLUDING_OFFERS', payload: offerVariables.offerResponse.payload.offers })
		}
	}

	public getDATAoffers(payload: PayloadProduct, offerVariables: OfferVariables, link?) {
		this.logger.log("info", "offer-billing.component.ts", "selectProductFromDataLinkRequest", JSON.stringify(offerVariables.dataLink.offerDataLinkURL));
		this.logger.startTime();
		offerVariables.loading = true;
		this.productService
			.getOffersFromLink(offerVariables.dataLink.offerDataLinkURL)
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offer-billing.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(error));
				this.logger.log("error", "offer-billing.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
				offerVariables.loading = false;
				this.systemErrorService.logAndRouteUnexpectedError(
					"error",
					"Not Applicable",
					"Submit Task",
					"offer-billing.component.ts",
					"DataOffers - Offer Page",
					error
				);
				return Observable.throwError(null);
			})
			.subscribe(
				data => {
					this.logger.endTime();
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(data ? data : ""));
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					data.offers = this.sortSpeeds(data.retrievalTypes[0].offers);
					offerVariables.catalogId = data.offers[0].catalogs[0].catalogId;
					offerVariables.offerResponse = Object.assign({}, offerVariables.offerResponse, {
						payload: payload
					});
					offerVariables.internerOffer = this.filterCategory(data.offers, GenericValues.sData).catalogs[0].catalogItems;
					let primaryProdduct = this.searchforPrimary(
						offerVariables.internerOffer[0].productOffer.productComponents,
						GenericValues.cPrimary
					);
					this.store.dispatch({
						type: "CART_MAX_SPEED",
						payload: primaryProdduct
					});
					if (
						(offerVariables.phoneSelected === GenericValues.noPhone && offerVariables.videoSelected === "NoTV") ||
						offerVariables.videoSelected === "DTV" ||
						!link
					) {
						this.createSlot(offerVariables);
					}
					if (link) {
						this.getPhoneOffers(payload, link, offerVariables);
					}
					if (offerVariables.loading) {
						offerVariables.loading = false;
					}
				},
				error => {
					this.logger.endTime();
					this.logger.log("error", "offer-billing.component.ts", "selectProductFromDataLinkResponse", JSON.stringify(error));
					this.logger.log("error", "offer-billing.component.ts", "selectProductFromDataLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					offerVariables.loading = false;
					if (error === undefined || error === null) { return; }
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						offerVariables.apiResponseError = JSON.parse(error);
						if (
							offerVariables.apiResponseError !== undefined &&
							offerVariables.apiResponseError !== null &&
							offerVariables.apiResponseError.errorResponse &&
							offerVariables.apiResponseError.errorResponse.length > 0
						) {
							this.systemErrorService.logAndeRouteToSystemError(
								"error",
								"offer-billing.component.ts",
								offerVariables.taskName,
								"Offer Page",
								offerVariables.apiResponseError
							);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
							offerVariables.orderRefNumber
						);
						this.systemErrorService.logAndeRouteToSystemError(
							"error",
							"offer-billing.component.ts",
							offerVariables.taskName,
							"Offer Page",
							lAPIErrorLists
						);
					}
					offerVariables.loading = false;
					offerVariables.retrieveOffersLoading = false;
				}
			);
	}

	public getPhoneOffers(payload, link, offerVariables: OfferVariables) {
		this.logger.log("info", "offer-billing.component.ts", "selectProductFromDHPLinkRequest", JSON.stringify(link));
		this.logger.startTime();
		offerVariables.loading = true;
		let errorResolved = false;
		this.productService
			.getOffersFromLink(link.offerDataLinkURL)
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offer-billing.component.ts", "selectProductFromDHPLinkResponse", JSON.stringify(error));
				this.logger.log("error", "offer-billing.component.ts", "selectProductFromDHPLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
				offerVariables.loading = false;
				errorResolved = true;
				this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer-billing.component.ts", "Get Phone Offers - Offers Page", error);
				return Observable.throwError(null);
			})
			.subscribe(
				data => {
					this.logger.endTime();
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromDHPLinkResponse", JSON.stringify(data));
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromDHPLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					if (offerVariables.phoneSelected === "HMP") {
						if (
							!data || !data.retrievalTypes || !data.retrievalTypes[0] ||
							!data.retrievalTypes[0].offers[0] ||
							!data.retrievalTypes[0].offers[0].catalogs[0] ||
							data.retrievalTypes[0].offers[0].catalogs[0].catalogItems === null ||
							data.retrievalTypes[0].offers[0].catalogs[0].catalogItems === undefined ||
							data.retrievalTypes[0].offers[0].catalogs[0].catalogItems.length === 0
						) {
							offerVariables.errorMsg = "POTS Catalog coming as null";
						}
					}
					offerVariables.phoneCatalogId = data.retrievalTypes[0].offers[0].catalogs[0].catalogId;
					this.logger.endTime();
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromDHPLinkResponse", JSON.stringify(data ? data : ""));
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromDHPLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					payload = {
						offers: data.retrievalTypes[0].offers
					};
					offerVariables.offerResponse = Object.assign({}, offerVariables.offerResponse, {
						payload: payload
					});
					data.offers = this.sortSpeeds(data.retrievalTypes[0].offers);

					offerVariables.phoneOfferData = this.getOfferByCategory(
						offerVariables.phoneSelected,
						data, offerVariables.internetCheck, offerVariables.phoneSelected).categorys;
					if (offerVariables.phoneOfferData.length === 0) {
						offerVariables.retrieveOffersLoading = false;
					}

					if (offerVariables.videoOffer) {
						payload = this.retriveVideoOffers(offerVariables.dtvLink, payload, offerVariables);
					}
					if (!offerVariables.videoOffer) { this.createSlot(offerVariables); }
				},
				error => {
					if (!errorResolved) {
						this.logger.endTime();
						this.logger.log("error", "offer-billing.component.ts", "selectProductFromDHPLinkResponse", error);
						this.logger.log("error", "offer-billing.component.ts", "selectProductFromDHPLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					}
					offerVariables.loading = false;
					if (error === undefined || error === null) { return; }
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						offerVariables.apiResponseError = JSON.parse(error);
						if (
							offerVariables.apiResponseError !== undefined &&
							offerVariables.apiResponseError !== null &&
							offerVariables.apiResponseError.errorResponse &&
							offerVariables.apiResponseError.errorResponse.length > 0
						) {
							this.systemErrorService.logAndeRouteToSystemError(
								"error",
								"selectProductFromDHPLink ",
								"offer-billing.component.ts",
								"Offers Page",
								offerVariables.apiResponseError
							);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
							offerVariables.orderRefNumber
						);
						this.systemErrorService.logAndeRouteToSystemError(
							"error",
							"selectProductFromDHPLink ",
							"offer-billing.component.ts",
							"Offers Page",
							lAPIErrorLists
						);
					}
					offerVariables.retrieveOffersLoading = false;
				}
			);
	}

	private retriveVideoOffers(link: any, payload: PayloadProduct, offerVariables: OfferVariables) {
		this.logger.log("info", "offer-billing.component.ts", "selectProductFromVideoLinkRequest", JSON.stringify(link));
		this.logger.startTime();
		offerVariables.loading = true;
		let errorResolved = false;
		this.productService
			.getOffersFromLink(link.offerDataLinkURL)
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offer-billing.component.ts", "selectProductFromVideoLinkResponse", JSON.stringify(error));
				this.logger.log("error", "offer-billing.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
				offerVariables.loading = false;
				errorResolved = true;
				this.systemErrorService.logAndRouteUnexpectedError(
					"error",
					"Not Applicable",
					"Submit Task",
					"offer-billing.component.ts",
					"Get offer Data Link - Offer Page",
					error
				);
				return Observable.throwError(null);
			})
			.subscribe(
				data => {
					this.logger.endTime();
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromVideoLinkResponse", JSON.stringify(data ? data : ""));
					this.logger.log("info", "offer-billing.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					payload = {
						offers: data.retrievalTypes[0].offers
					};
					offerVariables.offerResponse = Object.assign({}, offerVariables.offerResponse, {
						payload: payload
					});
					data.offers = this.sortSpeeds(data.retrievalTypes[0].offers);
					if (offerVariables.videoSelected === "DTV") {
						if(data.offers.length > 0 && data.offers[0].catalogs.length > 0) {
							offerVariables.catalogDTVId = data.offers[0].catalogs[0].catalogId;
						}
					} else {
						offerVariables.internerOffer = this.filterBundleCategory(
							data.offers,
							GenericValues.cDATVID,
							GenericValues.sData
						);
					}
					offerVariables.videorOffer = this.getOfferByCategory(offerVariables.videoSelected, data, offerVariables.internetCheck, offerVariables.phoneSelected).categorys;
					if (offerVariables.internerOffer.length === 0) {
						offerVariables.errorMsg = "Catalogs are coming as empty";
						offerVariables.retrieveOffersLoading = false;
					} else if (offerVariables.videorOffer.length === 0) {
						offerVariables.errorMsg = "No Offers with respect to PRISM found";
						offerVariables.retrieveOffersLoading = false;
					}
					this.createSlot(offerVariables);
				},
				error => {
					if (!errorResolved) {
						this.logger.endTime();
						this.logger.log("info", "offer-billing.component.ts", "selectProductFromVideoLinkResponse", error);
						this.logger.log("info", "offer-billing.component.ts", "selectProductFromVideoLinkSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					}
					offerVariables.loading = false;
					if (error === undefined || error === null) { return; }
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						offerVariables.apiResponseError = JSON.parse(error);
						if (
							offerVariables.apiResponseError !== undefined &&
							offerVariables.apiResponseError !== null &&
							offerVariables.apiResponseError.errorResponse &&
							offerVariables.apiResponseError.errorResponse.length > 0
						) {
							this.systemErrorService.logAndeRouteToSystemError(
								"error",
								"selectProductFromVideoLink ",
								"offer-billing.component.ts",
								"Offers Page",
								offerVariables.apiResponseError
							);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
							offerVariables.orderRefNumber
						);
						this.systemErrorService.logAndeRouteToSystemError(
							"error",
							"selectProductFromVideoLink ",
							"offer-billing.component.ts",
							"Offers Page",
							lAPIErrorLists
						);
					}
					offerVariables.retrieveOffersLoading = false;
				}
			);
		return payload;
	}

	public validateForm(key, offerVariables) {
		this.giftCardRules(offerVariables.speedselected, offerVariables);
		switch (key) {
			case 'NI':
				this.store.dispatch({ type: 'CART_DATA_DTV', payload: offerVariables.cartObject.payload.cart });
				offerVariables.configSubmited = true;
				if (!offerVariables.isPOTS) {
					offerVariables.potsJacksMandatory = false;
					offerVariables.potsVoiceMailMandatory = false;
					offerVariables.potsWireMainMandatory = false;
					offerVariables.potsPortingMandatory = false;
				}
				if (offerVariables.deviceMandatory && offerVariables.selectedQuantity !== 'na') { offerVariables.deviceSelected = true; }
				if (offerVariables.isPOTS) {
					if (offerVariables.voiceMailValue !== 'na') {
						offerVariables.potsVoiceMailMandatory = false;
					} else {
						offerVariables.potsVoiceMailMandatory = true
					}
					if (!offerVariables.voiceMailPresent) { offerVariables.potsVoiceMailMandatory = false; }
					if (offerVariables.ismetroTNdisabled) { offerVariables.potsPortingMandatory = false; }
					if ((offerVariables.wireMaintainanceValue !== 'na') || (offerVariables.internetAvail && offerVariables.newInternetCheck && offerVariables.newPhoneSelected === 'HMP' && !offerVariables.wireMaintainenceHide)) {
						offerVariables.potsWireMainMandatory = false;
					} else {
						offerVariables.potsWireMainMandatory = true;
					}
				}
				if (offerVariables.secureWifiError || offerVariables.easeError || offerVariables.modemError || offerVariables.installError || offerVariables.jackError || (offerVariables.deviceMandatory && !offerVariables.deviceSelected) || (!offerVariables.internetCheck && offerVariables.phoneSelected === GenericValues.noPhone) || offerVariables.potsJacksMandatory || (offerVariables.voiceMailPresent && offerVariables.potsVoiceMailMandatory) || offerVariables.potsWireMainMandatory || (offerVariables.potsPortingMandatory && !offerVariables.ismetroTNdisabled)) {
					offerVariables.loading = false;
					return true;
				}
				break;
			case 'MOVE':
			case 'CHANGE':
				if (offerVariables.easeSelected && offerVariables.easeSelected.nativeElement.value === 'na') { offerVariables.easeError = true; }
				if (offerVariables.secureWifiSelected && offerVariables.secureWifiSelected.nativeElement.value === 'na') { offerVariables.secureWifiError = true; }
				if (!offerVariables.selectedModem && !offerVariables.isModemCompatible) { offerVariables.modemError = true; }
				if (offerVariables.jackSelected && offerVariables.jackValues.isMandatory && offerVariables.jackSelected.nativeElement.value === 'na') { offerVariables.jackError = true; }
				offerVariables.configSubmited = true;
				if (offerVariables.isPOTS) {
					if (offerVariables.voiceMailValue !== 'na') {
						offerVariables.potsVoiceMailMandatory = false;
					} else {
						offerVariables.potsVoiceMailMandatory = true;
					}
					if (!offerVariables.voiceMailPresent) { offerVariables.potsVoiceMailMandatory = false; }

					if ((offerVariables.wireMaintainanceValue !== 'na') || (offerVariables.internetAvail && offerVariables.newInternetCheck && offerVariables.newPhoneSelected === 'HMP' && !offerVariables.wireMaintainenceHide)) {
						offerVariables.potsWireMainMandatory = false;
					} else {
						offerVariables.potsWireMainMandatory = true
					}
					if (offerVariables.portingValue !== 'na') {
						offerVariables.potsPortingMandatory = false;
					} else {
						offerVariables.potsPortingMandatory = true;
					}
					if (offerVariables.ismetroTNdisabled) { offerVariables.potsPortingMandatory = false; }
					if (offerVariables.hpExisting) { offerVariables.potsPortingMandatory = false; }
				}
				if (!offerVariables.isPOTS) {
					offerVariables.potsJacksMandatory = false;
					offerVariables.potsVoiceMailMandatory = false;
					offerVariables.potsWireMainMandatory = false;
					offerVariables.potsPortingMandatory = false;
				}
				if (offerVariables.internetCheck && (offerVariables.easeError || offerVariables.modemError || offerVariables.secureWifiError || offerVariables.installError || (offerVariables.deviceMandatory && !offerVariables.deviceSelected) || offerVariables.potsJacksMandatory || (offerVariables.voiceMailPresent && offerVariables.potsVoiceMailMandatory) || (offerVariables.potsWireMainMandatory) || (offerVariables.potsPortingMandatory && !offerVariables.ismetroTNdisabled))) {
					return true;
				}
				break;
			case 'STACK_AMEND':
				if (offerVariables.easeSelected && offerVariables.easeSelected.nativeElement.value === 'na') { offerVariables.easeError = true; }
				if (offerVariables.secureWifiSelected && offerVariables.secureWifiSelected.nativeElement.value === 'na') { offerVariables.secureWifiError = true; }
				if (!offerVariables.selectedModem && !offerVariables.isModemCompatible) { offerVariables.modemError = true; }
				// modem error if modem not selected in case of ni pending amend
				if (!offerVariables.selectedModem && offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) { offerVariables.modemError = true; }
				offerVariables.configSubmited = true;
				if (offerVariables.isPOTS && !offerVariables.hpExisting) {
					if (offerVariables.voiceMailValue !== 'na') {
						offerVariables.potsVoiceMailMandatory = false;
					} else {
						offerVariables.potsVoiceMailMandatory = true;
					}
					if (!offerVariables.voiceMailPresent) { offerVariables.potsVoiceMailMandatory = false; }
					if ((offerVariables.wireMaintainanceValue !== 'na') || (offerVariables.internetAvail && offerVariables.newInternetCheck && offerVariables.newPhoneSelected === 'HMP' && !offerVariables.wireMaintainenceHide)) {
						offerVariables.potsWireMainMandatory = false;
					} else {
						offerVariables.potsWireMainMandatory = true
					}
					if (offerVariables.portingValue !== 'na') {
						offerVariables.potsPortingMandatory = false;
					} else {
						offerVariables.potsPortingMandatory = true
					}
					if (offerVariables.ismetroTNdisabled) { offerVariables.potsPortingMandatory = false; }
				}
				if (!offerVariables.isPOTS) {
					offerVariables.potsJacksMandatory = false;
					offerVariables.potsVoiceMailMandatory = false;
					offerVariables.potsWireMainMandatory = false;
					offerVariables.potsPortingMandatory = false;
				}
				if (!offerVariables.wireMaintainPresent) { offerVariables.potsWireMainMandatory = false; }
				if (offerVariables.isAmend || offerVariables.ismetroTNdisabled) { offerVariables.potsPortingMandatory = false; }
				if (offerVariables.internetCheck && (offerVariables.easeError || offerVariables.modemError || offerVariables.installError || offerVariables.secureWifiError || offerVariables.gponError || (offerVariables.deviceMandatory && !offerVariables.deviceSelected) || offerVariables.potsJacksMandatory || offerVariables.potsVoiceMailMandatory || offerVariables.potsWireMainMandatory || (offerVariables.potsPortingMandatory && !offerVariables.ismetroTNdisabled))) {
					return true;
				}
				break;
		}
		return false;
	}
	public updateUser(offerVariables) {
		offerVariables.loading = true;
		let offerings: ProductOfferings[] = [];
		let catalogs: Catalogs[] = [];
		let selectedProducts = [];
		if (offerVariables.internetCheck) {
			offerings.push(offerVariables.selectedOffer);
			catalogs.push({
				offerCategory: GenericValues.sData,
				catalogItems: offerings
			});
			selectedProducts.push({ type: 'data', selected: GenericValues.sData });
		}
		if (offerVariables.videoOffer) {
			offerings.push(offerVariables.selectedOffer);
			catalogs.push({
				offerCategory: GenericValues.sData,
				catalogItems: offerings
			});
			selectedProducts.push({ type: 'video', selected: this.getProductNameFromSelect(offerVariables.videoSelected) });
		}
		if (offerVariables.phoneOffer) {
			offerings.push(offerVariables.selectedOffer);
			catalogs.push({
				offerCategory: 'VOICE-DHP',
				catalogItems: offerings
			});
			selectedProducts.push({ type: 'phone', selected: this.getProductNameFromSelect(offerVariables.phoneSelected) });
		}
		this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: selectedProducts } });
		let serviceOffer: ServiceCategoryBasedOffers = {
			serviceCategory: offerVariables.selected,
			catalogs: catalogs
		};
		let serviceOffers: ServiceCategoryBasedOffers[] = [];
		serviceOffers.push(serviceOffer);
		let toReview: PayloadProduct = {
			offers: serviceOffers
		};
		this.store.dispatch({ type: 'REVIEW_ORDER', payload: toReview });
	}

	public getCustomerOrderItems(offerVariables) {
		// selected Technology
		let composite: CompositeAttribute[] = [];
		let customerOrderItems: CustomerOrderItems[] = [];
		let customerOrderSubItems: Products[] = [];
		let productAttributes: AttributesCombination[] = [];
		offerVariables.cartObject && offerVariables.cartObject.payload
			&& offerVariables.cartObject.payload.cart && offerVariables.cartObject.payload.cart.customerOrderItems
			&& offerVariables.cartObject.payload.cart.customerOrderItems.forEach(cartObj => {
				customerOrderSubItems = [];
				cartObj && cartObj.customerOrderSubItems && cartObj.customerOrderSubItems.forEach(sub => {
					productAttributes = [];
					sub.productAttributes && sub.productAttributes.forEach(subProd => {
						composite = [];
						subProd.compositeAttribute.forEach(comp => {
							if (!offerVariables.hasTechnology && cartObj.offerCategory === GenericValues.iData && sub.componentType === GenericValues.cPrimary
								&& subProd.isPriceable && comp.attributeName === 'Technology') {
								composite.push({
									attributeName: comp.attributeName,
									attributeValue: offerVariables.selectedTech,
									uom: comp.uom,
									attributeDisplayName: comp.attributeDisplayName
								});
							} else {
								composite.push({
									attributeName: comp.attributeName,
									attributeValue: comp.attributeValue,
									uom: comp.uom,
									attributeDisplayName: comp.attributeDisplayName
								});
							}
						});
						subProd.compositeAttribute = composite;
						productAttributes.push(subProd);
					});
					sub.productAttributes = productAttributes;
					customerOrderSubItems.push(sub);
				});
				cartObj.customerOrderSubItems = customerOrderSubItems;
				customerOrderItems.push(cartObj);
			});
		return customerOrderItems;
	}

	public updateCartStore(key, offerVariables) {
		if (offerVariables.cartOrderItems && offerVariables.reEntrant && !offerVariables.changeAfterReEntrant && offerVariables.cartOrderItems.payload &&
			offerVariables.cartOrderItems.payload.customerAddonOfferItems && offerVariables.cartOrderItems.payload.customerAddonOfferItems.length > 0) {
			const state = this.appStateService.getState();
			const retainState = state.retain;
			if (offerVariables.retainValueForPotsJack !== retainState.potsBooleans.retainValueForPotsJack) {
				for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
					const addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
					if (addOns.offerType === 'SUBOFFER' && addOns.offerCategory === 'WIRINGWORKS') {
						offerVariables.cartOrderItems.payload.customerAddonOfferItems.splice(i, 1);
					} else if (key === 'NI' && addOns.offerCategory === GenericValues.cHP && addOns.offerType !== 'SUBOFFER') {
						for (let j = 0; j < addOns.customerOrderSubItems.length; j++) {
							if (addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer' ||
								addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-Busy') {
								addOns.customerOrderSubItems.splice(j, 1);
							}
						}
					}
				}
				// this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
			} else {
				for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
					const addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
					if (addOns.offerType === 'SUBOFFER' && addOns.offerCategory === 'WIRINGWORKS' &&
						((addOns.productType === 'DATA ADDON OFFER' && offerVariables.phoneSelected === 'HMP') ||
							(addOns.productType === 'HP ADDON OFFER' && offerVariables.phoneSelected !== 'HMP'))) {
						offerVariables.cartOrderItems.payload.customerAddonOfferItems.splice(i, 1);
					}
				}
				// this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
			}
			if (offerVariables.hpOfferType !== retainState.potsBooleans.hpOfferType) {
				offerVariables.isPOTSChanged = true;
				for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
					const addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
					if (addOns.productType === 'HP ADDON OFFER') {
						offerVariables.cartOrderItems.payload.customerAddonOfferItems.splice(i, 1);
						i--;
					}
				}
			}
			this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
			if (offerVariables.voiceMail && (key === 'NI' || (!offerVariables.isHPRemoved && offerVariables.phoneSelected === 'HMP'))) {
				for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
					const addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
					if (addOns.offerCategory === GenericValues.cHP && addOns.offerType !== 'SUBOFFER') {
						for (let j = 0; j < addOns.customerOrderSubItems.length; j++) {
							if (addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer' ||
								addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-Busy') {
								addOns.customerOrderSubItems.splice(j, 1);
								j--;
							}
						}
					}
				}
				this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
			}
			if (key === 'MOVE') {
				for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
					let addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
					if (addOns.offerCategory === GenericValues.cHP && offerVariables.phoneSelected !== 'HMP') {
						offerVariables.cartOrderItems.payload.customerAddonOfferItems.splice(i, 1);
					}
				}
			}
		}
	}

	public viewRccsDisclosure(offerVariables) {
		if (offerVariables.flow === 'CHANGE') {
			let cart1 = <Observable<ShoppingCart>>this.store.select('cart');
			let cartDetails;
			offerVariables.cartSubscription = cart1.subscribe((data) => {
				cartDetails = offerVariables.cartObject.payload.cart;
			});
		}
		offerVariables.loading = true;
		let request;
		let isInternetInReq = false;
		if (offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart && offerVariables.cartObject.payload.cart.customerOrderItems) {
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach((custOrderItem) => {
				if (custOrderItem && custOrderItem.offerCategory && custOrderItem.offerCategory.toUpperCase() === 'INTERNET') {
					isInternetInReq = true;
				}
			});
			if (!isInternetInReq && offerVariables.disclosureArrList && (offerVariables.disclosureArrList.length > 0)) {
				offerVariables.disclosureArrList = offerVariables.disclosureArrList.filter(data => !(data.name === 'qualificationColorName' && data.value === 'TAN'))
			}
		}
		if (offerVariables.disclosureArrList.length === 0) {
			request = {
				orderRefNumber: offerVariables.orderRefNumber,
				rccGroupId: "SHOPPING",
				salesChannel: "ESHOP - Customer Care",
				versionNumber: "",
				cart: offerVariables.cartObject.payload.cart
			}
		} else {
			request = {
				orderRefNumber: offerVariables.orderRefNumber,
				rccGroupId: "SHOPPING",
				salesChannel: "ESHOP - Customer Care",
				versionNumber: "",
				cart: offerVariables.cartObject.payload.cart,
				attrList: offerVariables.disclosureArrList
			}
		}
		offerVariables.loading = true;
		let errorResolved = false;
		this.logger.log("info", "offer.component.ts", "retrieveRccDisclosuresRequest", JSON.stringify(request));
		this.logger.startTime();
		this.disclosuresService.viewRccsDisclosure(request)
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", "offer.component.ts", "retrieveRccDisclosuresResponse", error);
				this.logger.log("error", "offer.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				errorResolved = true;
				this.toConfig(offerVariables);
				return Observable.throwError(null);
			})
			.subscribe(
				(data: DisclosuresRes) => {
					this.logger.endTime();
					this.logger.log("info", "offer.component.ts", "retrieveRccDisclosuresResponse", JSON.stringify(data));
					this.logger.log("info", "offer.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.loading = false;
					if (data && data.rccGroup) {
						if (data && data.rccGroup && data.rccGroup.length > 0) {
							offerVariables.discloserPopUpSelected = true;
							this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: data });
							offerVariables.orderDisclosures.open();
						} else {
							this.toConfig(offerVariables);
						}
					}
				},
				(error) => {
					this.logger.endTime();
                    this.logger.log("error", "offerHelper.service.ts", "giftcardCompatibilityResponse", error);
                    this.logger.log("error", "offerHelper.service.ts", "giftcardCompatibilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    offerVariables.loading = false;
                    if (error === undefined || error === null) return;
				})
	}

	public toContinue(offerVariables, orderDisclosures) {
		offerVariables.orderDisclosures = orderDisclosures;
		if (!offerVariables.cartData) {
			offerVariables.cartData = offerVariables.cartObject.payload.cart;
		}
		const changesData = {
			unFilterBool: offerVariables.unFilterBool,
			byPassBool: offerVariables.byPassBool,
			bypassModemRulesBool: offerVariables.bypassModemRulesBool,
			retainValueForPotsJack: offerVariables.retainValueForPotsJack,
			selectedQuantity: offerVariables.selectedQuantity
		}
		if (offerVariables.discloserPopUpSelected || offerVariables.reEntrant) {
			offerVariables.customize = this.store.select('customize');
			offerVariables.customize.subscribe((data) => {
				offerVariables.custData = data;
				/*    if(offerVariables.reEntrant){  
							offerVariables.cartObject.payload.cart.customerOrderItems.forEach(custOrderData =>{
								custOrderData.customerOrderSubItems.forEach((subData) =>{                        
									subData.productAttributes.forEach((dat) =>{                        
										dat.compositeAttribute.forEach((data) =>{
											delete data["attributeDisplayName"]
										})                        
									})                                                     
								})  
							})                                              
						}   */
				if (data.offerChangeData && (changesData.unFilterBool === data.offerChangeData.unFilterBool) && (changesData.byPassBool === data.offerChangeData.byPassBool) && (changesData.bypassModemRulesBool === data.offerChangeData.bypassModemRulesBool) && (changesData.retainValueForPotsJack === data.offerChangeData.retainValueForPotsJack) && (changesData.selectedQuantity === data.offerChangeData.selectedQuantity)) {
					offerVariables.nonCartItemsNotChanged = true;
				} else {
					offerVariables.nonCartItemsNotChanged = false;
				}
			});
			if (offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart && offerVariables.custData.cartData && offerVariables.custData.cartData.cart && _.isEqual(JSON.stringify(offerVariables.cartObject.payload.cart), JSON.stringify((offerVariables.discloserPopUpSelected || offerVariables.reEntrant) ? offerVariables.custData.cartData.cart : offerVariables.cartData))) {
				offerVariables.cartObjectChanged = true;
			} else {
				offerVariables.cartObjectChanged = false;
			}
		}
		if (offerVariables.flow !== 'NEWINSTALL') {
			if (offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart.customerOrderItems && offerVariables.cartObject.payload.cart.customerOrderItems.length > 0) {
				offerVariables.cartObject.payload.cart.customerOrderItems.forEach((item) => {
					if (item.offerCategory === GenericValues.iData || item.offerCategory === GenericValues.sData) {
						item.customerOrderSubItems = this.resetCartModemAttrValue(item.customerOrderSubItems);
					}
				});
			}
		}
		if (offerVariables.isDisclosureAllowed && (!offerVariables.cartObjectChanged || !offerVariables.nonCartItemsNotChanged)) {
			this.viewRccsDisclosure(offerVariables);
		} else {
			this.toConfig(offerVariables);
		}
		this.store.dispatch({ type: 'CART_DATA', payload: offerVariables.cartObject.payload });
		this.store.dispatch({ type: 'OFFER_CHANGE_DATA', payload: changesData });
	}

	public potsDispatch(respData, offerVariables) {
		if (offerVariables.phoneSelected === 'HMP') {
			let subOrderItem: any;
			const subOrderItems: any[] = [];
			offerVariables.phoneOfferData.forEach((hmpOffer) => {
				if (hmpOffer.productOfferingId === offerVariables.selectedPhoneOfferdId) {
					hmpOffer.productOffer.productComponents.forEach((products) => {
						if (products.componentType !== GenericValues.cPrimary) {
							if ((products.product.productName.indexOf('Wire Maintenance Plan') !== -1 && offerVariables.wireMaintainance) ||
								(products.product.productName.indexOf('Voice Messaging') !== -1 && offerVariables.voiceMail)) {
								subOrderItem = products;
								subOrderItems.push(subOrderItem);
							}
							if (products.product.productName.indexOf('Jack and Wire') !== -1 && offerVariables.selectedJackForPots) {
								const offComp: OfferProductComponents = {
									product: offerVariables.selectedJackForPots
								};
								subOrderItem = offComp;
								subOrderItems.push(subOrderItem);
							}
							if (products.product.productName.indexOf('Wire Maintenance Plan') === -1 && products.product.productName.indexOf('Voice Messaging') === -1 && products.product.productName.indexOf('Jack and Wire') === -1) {
								subOrderItem = products;
								subOrderItems.push(subOrderItem);
							}
						}
					});
				}
			});
			const orderItem = {
				catalogId: offerVariables.phoneCatalogId,
				productOfferingId: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOfferingId,
				offerType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerType,
				offerSubType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerSubType,
				offerCategory: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerCategory,
				quantity: 1,
				rc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.rc : 0,
				discountedRc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
				otc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.otc : 0,
				discountedOtc: offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
				customerOrderSubItems: subOrderItems
			};
			this.store.dispatch({ type: 'POTS_OFFER', payload: orderItem });
		}
		let offering: ProductOfferings = offerVariables.selectedOffer;
		let offerings: ProductOfferings[] = [];
		offerings.push(offering);



		const catalogs: Catalogs[] = [];
		const selectedProducts = [];
		if (offerVariables.internetCheck) {
			offerings = [];
			offering = offerVariables.selectedOffer;
			offerings.push(offering);
			let catalog = {
				offerCategory: GenericValues.sData,
				catalogItems: offerings
			};
			catalogs.push(catalog);
			selectedProducts.push({ type: 'data', selected: GenericValues.sData });
		}
		if (offerVariables.videoOffer) {
			offerings = [];
			offering = offerVariables.selectedTVOffer;
			offerings.push(offering);
			let catalog = {
				offerCategory: 'VIDEO',
				catalogItems: offerings
			};
			catalogs.push(catalog);
			selectedProducts.push({ type: 'video', selected: this.getProductNameFromSelect(offerVariables.videoSelected) });
		}
		if (offerVariables.phoneOffer) {
			offerings = [];
			offering = offerVariables.selectedDHPOffer;
			offerings.push(offering);
			let catalog = {
				offerCategory: 'VOICE-DHP',
				catalogItems: offerings
			};
			catalogs.push(catalog);
			selectedProducts.push({ type: 'phone', selected: this.getProductNameFromSelect(offerVariables.phoneSelected) });
		}
		this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: selectedProducts } });
		const serviceOffer: ServiceCategoryBasedOffers = {
			serviceCategory: offerVariables.selected,
			catalogs: catalogs
		};
		const serviceOffers: ServiceCategoryBasedOffers[] = [];
		serviceOffers.push(serviceOffer);
		const toReview: PayloadProduct = {
			offers: serviceOffers
		};
		this.store.dispatch({ type: 'REVIEW_ORDER', payload: toReview });
		this.store.dispatch({ type: 'PRODUCT_CONFIG', payload: { prodConfig: respData.payload.productConfiguration } });
		this.router.navigate(['/customize-services']);
	}

	private getPotsBooleans(key, offerVariables) {
		let potsBooleans: any = {
			wireMaintainance: offerVariables.wireMaintainance,
			voiceMail: offerVariables.voiceMail,
			portingCheck: offerVariables.portingCheck,
			isInternational: offerVariables.isInternational,
			retainValueForPotsJack: offerVariables.retainValueForPotsJack
		}
		if (key === 'NI') {
			const JWCheck = true;
			const JWshowdrop = true;
			potsBooleans['JWCheck'] = JWCheck;
			potsBooleans['JWshowdrop'] = JWshowdrop;
			// potsBooleans['isVoiceMailNoSelected'] = offerVariables.isVoiceMailNoSelected;
			// potsBooleans['isVoiceMailYesSelected'] = offerVariables.isVoiceMailYesSelected;
			potsBooleans['isWireMaintainanceNoSelected'] = offerVariables.isWireMaintainanceNoSelected;
			potsBooleans['isWireMaintainanceYesSelected'] = offerVariables.isWireMaintainanceYesSelected;
			potsBooleans['isPortingCheckNoSelected'] = offerVariables.isPortingCheckNoSelected;
			potsBooleans['isPortingCheckYesSelected'] = offerVariables.isPortingCheckYesSelected;
			potsBooleans['isPOTSChanged'] = offerVariables.isPOTSChanged;
		} else if (key !== 'NI' && key !== 'MOVE') {
			potsBooleans['retainValueForHSIJack'] = offerVariables.retainValueForHSIJack;
		}
		return potsBooleans
	}

	private callCatch(error, offerVariables, componentName) {
		offerVariables.loading = false;
		this.logger.endTime();
		this.logger.log("error", componentName, "updateCartResponse", error);
		this.logger.log("error", componentName, "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
		this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "Submit Task", componentName, "Update Cart - Offers Page", error);
		return Observable.throwError(null);
	}

	private callError(error, offerVariables, componentName) {
		this.logger.endTime();
		this.logger.log("info", componentName, "updateCartResponse", JSON.stringify(error));
		this.logger.log("info", componentName, "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
		offerVariables.loading = false;
		if (error === undefined || error === null || error.message.indexOf('Unexpected') !== -1) { return; }
		let unexpectedError = false;
		if (this.ctlHelperService.isJson(error)) {
			offerVariables.apiResponseError = JSON.parse(error);
			if (offerVariables.apiResponseError !== undefined && offerVariables.apiResponseError !== null && offerVariables.apiResponseError.errorResponse &&
				offerVariables.apiResponseError.errorResponse.length > 0) {
				offerVariables.systemErrorService.logAndeRouteToSystemError("error", offerVariables.taskName, componentName, "Offers Page", offerVariables.apiResponseError);
			} else { unexpectedError = true; }
		} else { unexpectedError = true; }
		if (unexpectedError) {
			offerVariables.errorMsg = serverErrorMessages.serverDown;
			const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
			this.systemErrorService.logAndeRouteToSystemError("error", offerVariables.taskName, componentName, "Offers Page", lAPIErrorLists);
		}
		window.scroll(0, 0);
	}

	private setCartObject(key, offerVariables, componentName) {
		this.logger.log("info", componentName, "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
		let temp = offerVariables.cartCopyObject
		if (key === 'NI') { temp = offerVariables.previousLoaded; }
		if (offerVariables.holdCalled && temp.payload && temp.payload.cart && temp.payload.cart.customerOrderItems && temp.payload.cart.customerOrderItems.length && offerVariables.cartCopyObject
			&& offerVariables.cartCopyObject.payload
			&& offerVariables.cartCopyObject.payload.cart
			&& offerVariables.cartCopyObject.payload.cart.customerOrderItems) {
			for (let i = 0; i < offerVariables.cartCopyObject.payload.cart.customerOrderItems.length; i++) {
				let cust = offerVariables.cartCopyObject.payload.cart.customerOrderItems[i];
				if (cust.offerType === 'SUBOFFER') {
					if (key !== 'NI' && cust.customerOrderSubItems && cust.customerOrderSubItems.length > 0) {
						cust.existingServiceSubItems = cust.customerOrderSubItems
					} else if (key !== 'NI' && cust.existingServiceSubItems && cust.existingServiceSubItems.length > 0) {
						cust.customerOrderSubItems = cust.existingServiceSubItems
					}
					offerVariables.cartOrderItems.payload.cart.customerOrderItems.push(cust);
				} else if (cust.offerType !== 'SUBOFFER' && cust.offerCategory === GenericValues.cHP && cust.productOfferingId === offerVariables.selectedPhoneOfferdId && !offerVariables.isCustomize) {
					if (key !== 'NI' && cust.customerOrderSubItems && cust.customerOrderSubItems.length > 0) {
						cust.existingServiceSubItems = cust.customerOrderSubItems
					} else if (key !== 'NI' && cust.existingServiceSubItems && cust.existingServiceSubItems.length > 0) {
						cust.customerOrderSubItems = cust.existingServiceSubItems
					}
					for (let j = 0; j < offerVariables.cartOrderItems.payload.cart.customerOrderItems.length; j++) {
						const cartOrder = offerVariables.cartOrderItems.payload.cart.customerOrderItems[j];
						if (cartOrder && offerVariables.phoneSelected === 'HMP' && cartOrder.offerCategory === GenericValues.cHP &&
							cartOrder.offerType !== 'SUBOFFER') {
							if (cust && cust.customerOrderSubItems) {
								for (let k = 0; k < cust.customerOrderSubItems.length; k++) {
									const subs = cust.customerOrderSubItems[k];
									if (subs.componentType !== GenericValues.cPrimary && subs.productName.indexOf('Wire Maintenance Plan') === -1
										&& subs.productName.indexOf('Voice Messaging') === -1 && subs.productName.indexOf('Jack and Wire') === -1) {
										offerVariables.cartOrderItems.payload.cart.customerOrderItems[j].customerOrderSubItems.push(subs);
									}
								}
							}
						}
					}
				}
				if (!offerVariables.voiceMailPresent && (key === 'CHANGE')) { offerVariables.voiceMailValue = 'No'; }
				if (key !== 'NI' && offerVariables.isCustomize && offerVariables.existingServices) {
					for (let j = 0; j < offerVariables.cartOrderItems.payload.cart.customerOrderItems.length; j++) {
						const cartOrder = offerVariables.cartOrderItems.payload.cart.customerOrderItems[j];
						if (cartOrder && cartOrder.offerCategory === GenericValues.cHP && cartOrder.offerType !== 'SUBOFFER') {
							for (let n = 0; n < offerVariables.existingServices.length; n++) {
								const cust = offerVariables.existingServices[n];
								if (cust && cust.customerOrderSubItems) {
									for (let k = 0; k < cust.customerOrderSubItems.length; k++) {
										let subs = cust.customerOrderSubItems[k];
										if (subs.componentType !== GenericValues.cPrimary && subs.productName.indexOf('Wire Maintenance Plan') === -1
											&& subs.productName.indexOf('Voice Messaging') === -1 && subs.productName.indexOf('Jack and Wire') === -1
											&& subs.productName.indexOf('Easy Access') === -1) {
											offerVariables.cartOrderItems.payload.cart.customerOrderItems[j].customerOrderSubItems.push(subs);
										}
									}
								}
							}
						}
					}
				}
			}
			let flow = (key === 'NI') ? 'Newinstall' : (key === 'MOVE') ? 'Move' : (key === 'CHANGE') ? 'Change' : (key === 'BILLING') ? 'Billing' : 'Stack-Amend'
			this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
			this.store.dispatch({
				type: 'ORDER_FlOW', payload: {
					flow: flow,
					type: 'fromHold',
					selectProductCalled: true,
					customizeCalled: false
				}
			});
		}
	}

	private setPotsOffer(offerVariables) {
		if (offerVariables.phoneSelected === "HMP") {
			let subOrderItem: any;
			let subOrderItems: any[] = [];
			offerVariables.phoneOfferData.forEach(hmpOffer => {
				if (hmpOffer.productOfferingId === offerVariables.selectedPhoneOfferdId) {
					hmpOffer.productOffer.productComponents.forEach(products => {
						if (products.componentType !== GenericValues.cPrimary) {
							if ((products.product.productName.indexOf("Wire Maintenance Plan") !== -1 && offerVariables.wireMaintainance) || (products.product.productName.indexOf("Voice Messaging") !== -1 && offerVariables.voiceMail)) {
								subOrderItem = products;
								subOrderItems.push(subOrderItem);
							}
							if (products.product.productName.indexOf("Wire Maintenance Plan") === -1 && products.product.productName.indexOf("Voice Messaging") === -1 && products.product.productName.indexOf("Jack and Wire") === -1) {
								subOrderItem = products;
								subOrderItems.push(subOrderItem);
							}
						}
					});
				}
			});
			let orderItem = {
				catalogId: offerVariables.phoneCatalogId,
				productOfferingId: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOfferingId,
				offerType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerType,
				offerSubType: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerSubType,
				offerCategory: offerVariables.selectedDHPOffer === undefined ? '' : offerVariables.selectedDHPOffer.productOffer.offerCategory,
				quantity: 1,
				rc: offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.rc : 0,
				discountedRc: offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedRc : 0,
				otc: offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.otc : 0,
				discountedOtc: offerVariables.selectedDHPOffer.defaultOfferPrice !== null ? offerVariables.selectedDHPOffer.defaultOfferPrice.discountedOtc : 0,
				customerOrderSubItems: subOrderItems
			};
			this.store.dispatch({ type: "POTS_OFFER", payload: orderItem });
		}
	}

	public toConfig(offerVariables) {
		let potsBooleans: any = {};
		switch (offerVariables.currentFlow) {
			case 'NI':
				this.store.dispatch({ type: 'CART_DATA_DTV', payload: offerVariables.cartObject.payload.cart });
				if (offerVariables.portingCheck) {
					offerVariables.cartObject.payload.tnPortingRequested = true;
				}
				else {
					offerVariables.cartObject.payload.tnPortingRequested = false;
				}
				if (this.validateForm(offerVariables.currentFlow, offerVariables)) { return; }
				if (!offerVariables.isPrepaid && offerVariables.isPrepaidAccountPage) { this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: false }); }
				if (offerVariables.hpSelected) { this.store.dispatch({ type: 'HP_SELECTED', payload: offerVariables.hpSelected }); }
				offerVariables.cartObject.payload.cart.customerOrderItems = this.getCustomerOrderItems(offerVariables);
				this.updateCartStore(offerVariables.currentFlow, offerVariables);
				this.setReentrantFlags(offerVariables);
				offerVariables.loading = true;
				potsBooleans = this.getPotsBooleans(offerVariables.currentFlow, offerVariables);
				offerVariables.cartObject.taskId = offerVariables.tempTaskId;
				offerVariables.cartObject.payload.cart.customerOrderItems[0].customerOrderSubItems = this.resetCartModemAttrValue(offerVariables.cartObject.payload.cart.customerOrderItems[0].customerOrderSubItems);
				this.ctlHelperService.setLocalStorage(RE_ENTRANT_OFFERVARIABLE, offerVariables);
				this.logger.log("info", "offer.component.ts", "updateCartRequest", JSON.stringify(offerVariables.cartObject));
				this.logger.startTime();
				this.productService.updateCart(offerVariables.cartObject, false, potsBooleans, offerVariables.e911ValidatedAddress)
					.catch((error: any) => {
						this.logger.endTime();
						this.logger.log("error", 'offer.component.ts', "updateCartResponse", JSON.stringify(error));
						this.logger.log("error", 'offer.component.ts', "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						offerVariables.loading = false;
						return this.callCatch(error, offerVariables, 'offer.component.ts');
					})
					.subscribe(
						(respData) => {
							this.logger.endTime();
							this.logger.log("info", 'offer.component.ts', "updateCartResponse", JSON.stringify(respData ? respData : ''));
							this.logger.log("info", 'offer.component.ts', "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							this.setCartObject(offerVariables.currentFlow, offerVariables, 'offer.component.ts');
							this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: respData });
							this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
							if (offerVariables.reEntrant && !offerVariables.changeAfterReEntrant) {
								this.store.dispatch({ type: 'ISRENTRANT', payload: true });
							} else {
								this.store.dispatch({ type: 'ISRENTRANT', payload: false });
							}
							if (offerVariables.portingCheck === undefined || offerVariables.portingCheck === false) {
								this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: false });
								this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' });
							}
							this.potsDispatch(respData, offerVariables);
						},
						(error) => {
							this.logger.endTime();
							this.logger.log("error", 'offer.component.ts', "updateCartResponse", JSON.stringify(error));
							this.logger.log("error", 'offer.component.ts', "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							offerVariables.loading = false;
							this.callError(error, offerVariables, 'offer.component.ts');
						});
				break;
			case 'MOVE':
				if (this.validateForm(offerVariables.currentFlow, offerVariables)) { return; }
				this.updateCartStore(offerVariables.currentFlow, offerVariables);
				this.setReentrantFlags(offerVariables);
				this.compatibilityAPIcall(offerVariables);
				this.updateUser(offerVariables);
				potsBooleans = this.getPotsBooleans(offerVariables.currentFlow, offerVariables);
				if (!offerVariables.internetAvail) {
					let isDHP = false;
					offerVariables.removedProductItem && offerVariables.removedProductItem.forEach(rmvItem => {
						if (rmvItem.offerCategory === GenericValues.cDHP) { isDHP = true; }
						let cust = cloneDeep(rmvItem);
						cust.customerOrderSubItems = cloneDeep(rmvItem.existingServiceSubItems);
						delete cust.existingServiceSubItems;
						if (rmvItem.existingServiceSubItems && rmvItem.existingServiceSubItems.length > 0) { offerVariables.cartObject.payload.cart.customerOrderItems.push(cust); }
					});
					if (isDHP) {
						let request: any;
						let user: Observable<User>;
						let userSubscribe = user.subscribe(
							(data) => {
								let usr: any;
								usr = data;
								let address = usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.newLocation
									&& usr.orderInit.payload.newLocation.serviceAddress;
								request = {
									streetDirectionPrefix: '',
									streetAddress: address.streetName,
									location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
									streetNrFirst: address.streetNrFirst,
									city: address.city ? address.city : address.locality,
									stateOrProvince: address.stateOrProvince,
									postCode: address.postCode,
									postCodeSuffix: address.postCodeSuffix
								};
							});
						if (userSubscribe !== undefined) { userSubscribe.unsubscribe(); }
						let payload: Payload = {
							dhpAdditionalInfo: {
								e911Address: request,
								dhpDisclaimerAcceptDateTime: new Date().toISOString()
							},
							cart: offerVariables.cartObject.payload.cart
						}
						offerVariables.cartObject.payload = payload;
					}
				}
				offerVariables.cartObject.payload.cart.customerOrderItems = this.getCustomerOrderItems(offerVariables);
				if (offerVariables.cartObject && offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart && offerVariables.cartObject.payload.cart.customerOrderItems.length > 0 && offerVariables.cartObject.payload.cart.customerOrderItems[0] !== undefined && offerVariables.cartObject.payload.cart.customerOrderItems[0].offerCategory === "VOICE-HP" && offerVariables.cartObject.payload.cart.customerOrderItems[0].action === "NOCHANGE") {
					this.store.dispatch({ type: 'POTS_ACTIONTYPE', payload: offerVariables.cartObject.payload.cart.customerOrderItems[0].action });
				}
				if (offerVariables.offerBillingType === 'PREPAID') {
					offerVariables.cartObject.payload.billingType = offerVariables.offerBillingType;
				}
				if (offerVariables.cartObject.payload.cart.customerOrderItems && offerVariables.cartObject.payload.cart.customerOrderItems.length > 0) {
					offerVariables.cartObject.payload.cart.customerOrderItems.forEach((item) => {
						if (item.offerCategory === GenericValues.iData || item.offerCategory === GenericValues.sData) {
							item.customerOrderSubItems = this.resetCartModemAttrValue(item.customerOrderSubItems);
						}
					});
				}
				this.logger.log("info", "offer.component.ts", "updateCartRequest", JSON.stringify(offerVariables.cartObject));
				this.logger.startTime();
				offerVariables.loading = true;
				this.productService.updateCart(offerVariables.cartObject, 'move', potsBooleans, offerVariables.e911ValidatedAddress)
					.catch((error: any) => {
						this.logger.endTime();
						this.logger.log("error", 'offer-move.component.ts', "updateCartResponse", JSON.stringify(error));
						this.logger.log("error", 'offer-move.component.ts', "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						offerVariables.loading = false;
						return this.callCatch(error, offerVariables, 'offer-move.component.ts');
					})
					.subscribe(
						(respData) => {
							this.logger.endTime();
							this.logger.log("info", 'offer-move.component.ts', "updateCartResponse", JSON.stringify(respData ? respData : ''));
							this.logger.log("info", 'offer-move.component.ts', "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							this.setCartObject(offerVariables.currentFlow, offerVariables, 'offer-move.component.ts');
							this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: respData });
							this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
							if (offerVariables.reEntrant && !offerVariables.changeAfterReEntrant) {
								this.store.dispatch({ type: 'ISRENTRANT', payload: true });
							} else {
								this.store.dispatch({ type: 'ISRENTRANT', payload: false });
							}
							if (offerVariables.portingCheck === undefined || offerVariables.portingCheck === false) {
								this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: false });
								this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' });
							}
							if (respData.orderRefNumber) { this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: respData.orderRefNumber }); }
							this.router.navigate(['/customize-services']);
						},
						(error) => {
							this.logger.endTime();
							this.logger.log("error", 'offer-move.component.ts', "updateCartResponse", JSON.stringify(error));
							this.logger.log("error", 'offer-move.component.ts', "updateCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							offerVariables.loading = false;
							this.callError(error, offerVariables, 'offer-move.component.ts');
						});
				this.setPotsOffer(offerVariables);
				break;

			case 'CHANGE':
				if (this.validateForm(offerVariables.currentFlow, offerVariables)) { return; }
				this.setReentrantFlags(offerVariables);
				this.updateUser(offerVariables);
				offerVariables.cartObject.payload.cart.customerOrderItems = this.getCustomerOrderItems(offerVariables);
				this.logger.log("info", "offer-change.component.ts", "updateChangeCartRequest", JSON.stringify(offerVariables.cartObject));
				this.logger.startTime();
				offerVariables.loading = true;
				potsBooleans = this.getPotsBooleans(offerVariables.currentFlow, offerVariables);
				if (offerVariables.isRecommendationSuccess) {
					this.updateAction(offerVariables);
				}
				if (offerVariables.cartObject && offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart && offerVariables.cartObject.payload.cart.customerOrderItems.length > 0 && offerVariables.cartObject.payload.cart.customerOrderItems[0] !== undefined && offerVariables.cartObject.payload.cart.customerOrderItems[0].offerCategory === "VOICE-HP" && offerVariables.cartObject.payload.cart.customerOrderItems[0].action === "NOCHANGE") {
					this.store.dispatch({ type: 'POTS_ACTIONTYPE', payload: offerVariables.cartObject.payload.cart.customerOrderItems[0].action });
				}
				this.ctlHelperService.setLocalStorage(RE_ENTRANT_OFFERVARIABLE, offerVariables);
				this.productService.updateChangeCart(offerVariables.cartObject, potsBooleans, offerVariables.e911ValidatedAddress)
					.catch((error: any) => {
						this.logger.endTime();
						this.logger.log("error", 'offer-change.component.ts', "updateChangeCartResponse", JSON.stringify(error));
						this.logger.log("error", 'offer-change.component.ts', "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						offerVariables.loading = false;
						return this.callCatch(error, offerVariables, 'offer-change.component.ts');
					})
					.subscribe(
						(respData) => {
							this.logger.endTime();
							this.logger.log("info", 'offer-change.component.ts', "updateChangeCartResponse", JSON.stringify(respData ? respData : ''));
							this.logger.log("info", 'offer-change.component.ts', "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							this.setCartObject(offerVariables.currentFlow, offerVariables, 'offer-change.component.ts');
							if (offerVariables.voiceMail && !offerVariables.isHPRemoved && offerVariables.cartOrderItems && offerVariables.cartOrderItems.payload &&
								offerVariables.cartOrderItems.payload.customerAddonOfferItems && offerVariables.cartOrderItems.payload.customerAddonOfferItems.length > 0) {
								for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
									let addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
									if (addOns.offerCategory === GenericValues.cHP && addOns.offerType !== 'SUBOFFER') {
										for (let j = 0; j < addOns.customerOrderSubItems.length; j++) {
											if (addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer' ||
												addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-Busy') {
												addOns.customerOrderSubItems.splice(j, 1);
												j--;
											}
										}
									}
								}
								this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
							}
							let lifelineData;
							if (offerVariables.reEntrant && !offerVariables.changeAfterReEntrant) {
								let custData = <Observable<any>>this.store.select('customize');
								let custSubscription = custData.subscribe(data => {
									lifelineData = data;
								});
								if (custSubscription !== undefined) {
									custSubscription.unsubscribe();
								}
								this.store.dispatch({ type: 'ISRENTRANT', payload: true });
							} else {
								this.store.dispatch({ type: 'ISRENTRANT', payload: false });
							}
							this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: respData });
							if (lifelineData && lifelineData.lifelineaddedforinternet) {
								this.store.dispatch({ type: 'LIFELINE_CONFIG', payload: lifelineData.lifelineConfig });
								this.store.dispatch({ type: 'LIFELINE_CONFIG_DISCOUNTS', payload: lifelineData.lifelineDiscounts });
								this.store.dispatch({ type: 'LIFELINE_CONFIG_ADJUSTMENTS', payload: lifelineData.lifelineAdjustment });
							}
							if (lifelineData && (lifelineData.lifelinePots || lifelineData.lifelineDHP)) {
								this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG', payload: lifelineData.lifelinePotsConfig });
								this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_DISCOUNTS', payload: lifelineData.lifelinePotsDiscounts });
								this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_ADJUSTMENTS', payload: lifelineData.lifelinePotsAdjustment });
							}
							this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
							if (respData.orderRefNumber) { this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: respData.orderRefNumber }); }
							this.setPotsOffer(offerVariables);
							this.router.navigate(['/customize-services']);
						},
						(error) => {
							this.logger.endTime();
							this.logger.log("error", 'offer-change.component.ts', "updateChangeCartResponse", JSON.stringify(error));
							this.logger.log("error", 'offer-change.component.ts', "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							offerVariables.loading = false;
							this.callError(error, offerVariables, 'offer-change.component.ts');
						});
				break;

			case 'BILLING':
				this.giftCardRules(offerVariables.speedselected, offerVariables);
				offerVariables.configSubmited = true;
				if (offerVariables.internetCheck && (offerVariables.easeError || offerVariables.modemError || offerVariables.secureWifiError || offerVariables.installError || offerVariables.jackError || (offerVariables.deviceMandatory && !offerVariables.deviceSelected))) {
					return;
				}
				this.compatibilityAPIcall(offerVariables);
				offerVariables.loading = true;
				this.updateUser(offerVariables);
				offerVariables.cartObject.payload.cart.customerOrderItems = this.getCustomerOrderItems(offerVariables);
				offerVariables.cartObject.payload.billingType = offerVariables.offerBillingType;
				this.setReentrantFlags(offerVariables);
				this.logger.log("info", "offer-billing.component.ts", "updateBillingCartRequest", JSON.stringify(offerVariables.cartObject));
				this.logger.startTime();
				potsBooleans = this.getPotsBooleans(offerVariables.currentFlow, offerVariables);
				this.ctlHelperService.setLocalStorage(RE_ENTRANT_OFFERVARIABLE, offerVariables);
				this.productService.updateBillingCart(offerVariables.cartObject, potsBooleans)
					.catch((error: any) => {
						this.logger.endTime();
						this.logger.log("error", "offer-billing.component.ts", "updateBillingCartResponse", JSON.stringify(error));
						this.logger.log("error", "offer-billing.component.ts", "updateBillingCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						offerVariables.loading = false;
						return this.callCatch(error, offerVariables, 'offer-billing.component.ts');
					})
					.subscribe(
						respData => {
							this.logger.endTime();
							this.logger.log("info", "offer-billing.component.ts", "updateBillingCartResponse", JSON.stringify(respData));
							this.logger.log("info", "offer-billing.component.ts", "updateBillingCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							this.store.dispatch({ type: "CREATE_CUSTOMIZE_ADDONS", payload: respData });
							this.store.dispatch({ type: "TASK_ID", payload: respData.taskId });
							if (offerVariables.reEntrant) { this.store.dispatch({ type: "ISRENTRANT", payload: true }); }
							if (respData.orderRefNumber) { this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: respData.orderRefNumber }); }
							this.router.navigate(["/customize-services"]);
						},
						(error) => {
							this.logger.endTime();
							this.logger.log("error", "offer-billing.component.ts", "updateBillingCartResponse", JSON.stringify(error));
							this.logger.log("error", "offer-billing.component.ts", "updateBillingCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							offerVariables.loading = false;
							this.callError(error, offerVariables, 'offer-billing.component.ts');
						}
					);
				this.setPotsOffer(offerVariables);
				break;
			case 'STACK_AMEND':
				if (this.validateForm(offerVariables.currentFlow, offerVariables)) { return; }
				this.setReentrantFlags(offerVariables);
				this.compatibilityAPIcall(offerVariables);
				this.updateUser(offerVariables);
				let customerOrderItems = this.getCustomerOrderItems(offerVariables);
				if ((offerVariables.potsRemoveAction || offerVariables.cvoipRemoveAction) && offerVariables.previousRemovedItems !== undefined) {
					offerVariables.previousRemovedItems.forEach(item => {
						customerOrderItems.push(item);
					});
				}
				if (offerVariables.isAmend && Switch.enableAddPotsForAmend) { customerOrderItems = this.handleRemovedProdInCart(offerVariables, customerOrderItems); }
				offerVariables.cartObject.payload.cart.customerOrderItems = customerOrderItems;
				this.logger.log("info", "stack-amend-product.component.ts", "updateChangeCartRequest", JSON.stringify(offerVariables.cartObject));
				this.logger.startTime();
				offerVariables.loading = true;
				potsBooleans = this.getPotsBooleans(offerVariables.currentFlow, offerVariables);
				potsBooleans['isPOTSChanged'] = offerVariables.isPOTSChanged;
				this.ctlHelperService.setLocalStorage(RE_ENTRANT_OFFERVARIABLE, offerVariables);
				this.productService.updateChangeCart(offerVariables.cartObject, potsBooleans, offerVariables.e911ValidatedAddress)
					.catch((error: any) => {
						this.logger.endTime();
						this.logger.log("error", 'stack-amend-product.component.ts', "updateChangeCartResponse", JSON.stringify(error));
						this.logger.log("error", 'stack-amend-product.component.ts', "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						offerVariables.loading = false;
						return this.callCatch(error, offerVariables, 'stack-amend-product.component.ts');
					})
					.subscribe(
						(respData) => {
							this.logger.endTime();
							this.logger.log("info", 'stack-amend-product.component.ts', "updateChangeCartResponse", JSON.stringify(respData ? respData : ''));
							this.logger.log("info", 'stack-amend-product.component.ts', "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							this.setCartObject(offerVariables.currentFlow, offerVariables, 'stack-amend-product.component.ts');
							if (offerVariables.voiceMail && !offerVariables.isHPRemoved && offerVariables.cartOrderItems && offerVariables.cartOrderItems.payload &&
								offerVariables.cartOrderItems.payload.customerAddonOfferItems && offerVariables.cartOrderItems.payload.customerAddonOfferItems.length > 0) {
								for (let i = 0; i < offerVariables.cartOrderItems.payload.customerAddonOfferItems.length; i++) {
									let addOns = offerVariables.cartOrderItems.payload.customerAddonOfferItems[i];
									if (addOns.offerCategory === GenericValues.cHP && addOns.offerType !== 'SUBOFFER') {
										for (let j = 0; j < addOns.customerOrderSubItems.length; j++) {
											if (addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-NoAnswer' ||
												addOns.customerOrderSubItems[j].productName.replace(/\s/g, "") === 'CallForwarding-Busy') {
												addOns.customerOrderSubItems.splice(j, 1);
												j--;
											}
										}
									}
								}
								this.store.dispatch({ type: 'CREATE_CART', payload: offerVariables.cartOrderItems });
							}
							let lifelineData;
							if (offerVariables.reEntrant && !offerVariables.changeAfterReEntrant) {
								let custData = <Observable<any>>this.store.select('customize');
								let custSubscription = custData.subscribe(data => {
									lifelineData = data;
								})
								if (custSubscription !== undefined) {
									custSubscription.unsubscribe();
								}
								this.store.dispatch({ type: 'ISRENTRANT', payload: true });
							} else {
								this.store.dispatch({ type: 'ISRENTRANT', payload: false });
							}
							this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: respData });
							if (lifelineData && lifelineData.lifelineaddedforinternet) {
								this.store.dispatch({ type: 'LIFELINE_CONFIG', payload: lifelineData.lifelineConfig });
								this.store.dispatch({ type: 'LIFELINE_CONFIG_DISCOUNTS', payload: lifelineData.lifelineDiscounts });
								this.store.dispatch({ type: 'LIFELINE_CONFIG_ADJUSTMENTS', payload: lifelineData.lifelineAdjustment });
							}
							if (lifelineData && (lifelineData.lifelinePots || lifelineData.lifelineDHP)) {
								this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG', payload: lifelineData.lifelinePotsConfig });
								this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_DISCOUNTS', payload: lifelineData.lifelinePotsDiscounts });
								this.store.dispatch({ type: 'LIFELINE_POTS_CONFIG_ADJUSTMENTS', payload: lifelineData.lifelinePotsAdjustment });
							}
							this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
							if (respData.orderRefNumber) { this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: respData.orderRefNumber }); }
							this.store.dispatch({ type: 'RETAIN_INSTALL_OPTION', payload: offerVariables.selectedInstallation });
							this.store.dispatch({ type: 'RETAIN_VOICE_MAIL', payload: offerVariables.voiceMailValue });
							this.router.navigate(['/customize-services']);
						},
						(error) => {
							this.logger.endTime();
							this.logger.log("error", 'stack-amend-product.component.ts', "updateChangeCartResponse", JSON.stringify(error));
							this.logger.log("error", 'stack-amend-product.component.ts', "updateChangeCartSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
							offerVariables.loading = false;
							this.callError(error, offerVariables, 'stack-amend-product.component.ts');
						});
				this.setPotsOffer(offerVariables);
				break;
		}
	}

	public e911Response(response, offerVariables, flag?) {
		if (!flag && response.msagData && response.msagData !== null && response.msagData.length > 0) {
			const resp = response.msagData[0];
			offerVariables.e911ValidatedAddress = resp;
			offerVariables.e911ValidatedAddress.acceptedData = new Date().toISOString();
		} else if (offerVariables.flow === "MOVE") {
			let user = <Observable<User>>this.store.select('user');
			user.subscribe(
				(data) => {
					let usr: any;
					usr = data;
					let address = usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.newLocation
						&& usr.orderInit.payload.newLocation.serviceAddress;
					offerVariables.e911ValidatedAddress = {
						streetDirectionPrefix: '',
						streetAddress: address.streetName,
						location: address.unitNumber ? address.unitNumber : address.subAddress.combinedDesignator,
						streetNrFirst: address.streetNrFirst,
						city: address.city ? address.city : address.locality,
						stateOrProvince: address.stateOrProvince,
						postCode: address.postCode,
						postCodeSuffix: address.postCodeSuffix
					};
					offerVariables.e911ValidatedAddress.acceptedData = new Date().toISOString();
				});
		}
		if (offerVariables.addDhpfromRecommendation && !offerVariables.dhpExisting) {
			offerVariables.addDhpfromRecommendation = false;
			offerVariables.phoneOffer = true;
			offerVariables.phoneSelected = 'DHP';
			offerVariables.newPhoneSelected = 'DHP';
		}
		this.retrieveOffers(offerVariables, false);
		offerVariables.isE911Called = true
	}

	private updateAction(offerVariables) {
		offerVariables.existingServices.forEach(existing => {
			let found = false;
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => { if (item.offerCategory === existing.offerCategory) { found = true; } });
			if (!found) { this.removeItem(offerVariables, existing.offerCategory); }
		});
	}

	public removeItem(offerVariables, category) {
		offerVariables.existingServices.forEach(existing => {
			if (existing.offerCategory === category) {
				this.addRemoveActionToCart(offerVariables, existing);
			}
		});
	}

	private addRemoveActionToCart(offerVariables, item) {
		item.action = 'REMOVE';
		item.customerOrderSubItems.forEach(subItem => {
			subItem.action = 'REMOVE';
		});
		offerVariables.cartObject.payload.cart.customerOrderItems.push(item);
	}

	private retrieveTechnologyForSpeed(speed, technology: string) {
		speed && speed.productAttributes && speed.productAttributes.forEach(attr => {
			attr.compositeAttribute && attr.compositeAttribute.forEach(compAttr => {
				if (compAttr.attributeName === 'Technology' && compAttr.attributeValue && compAttr.attributeValue) {
					technology = compAttr.attributeValue;
				}
			});
		});
		return technology;
	}

	public onChangeTechnology(offerVariables, tech) {
		offerVariables.selectedTech = tech;

		if ((offerVariables.currentTechnology !== 'GPON' || offerVariables.currentTechnology !== 'GPON-ATM') && (offerVariables.selectedTech === 'GPON' || offerVariables.selectedTech === 'GPON-ATM') && offerVariables.isAmend) {
			offerVariables.gponError = true;
		} else {
			offerVariables.gponError = false;
		}
	}

	public handleRemovedProdInCart(offerVariables, customerOrderItems) {
		let orderItems = customerOrderItems;
		let multiplePendingOrders = false;
		let existingObservable = <Observable<any>>this.store.select('existingProducts');
		let existingSubscription = existingObservable.subscribe(data => {
			multiplePendingOrders = (data.pendingOrders && data.pendingOrders.length > 1);
		});
		if (existingSubscription !== undefined) { existingSubscription.unsubscribe(); }
		if (!multiplePendingOrders && offerVariables.NIPendingStackAmend) {
			orderItems = orderItems.filter(item => {
				return (item.action !== 'REMOVE');
			});
		} else if (multiplePendingOrders && offerVariables.NIPendingStackAmend) {
			orderItems = orderItems.filter(item => {
				if (item.action === 'REMOVE') {
					let existing = this.getExistingProducts(offerVariables.existingServicesForAction, item.offerCategory);
					return (existing !== undefined);
				}
				return true;
			});
		}
		return orderItems;
	}

	public onChangeJacksOrWiring(attrVal: string, offerVariables: OfferVariables) {
		let price = attrVal === "na" ? offerVariables.noPrice : this.getPriceDetailsByAttrVal(offerVariables.jackValuesForPots, attrVal, "");
		offerVariables.selectedJackForPots = this.searchForDefault(offerVariables, false, offerVariables.jackValuesForPots, price);
		if (attrVal === "na") {
			offerVariables.selectedJackForPots = undefined;
			offerVariables.potsJacksMandatory = true;
		} else {
			offerVariables.undoFlag = true;
		}
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		switch (flow) {
			case 'NEWINSTALL':
				offerVariables.retainValueForPotsJack = attrVal;
				break;
			case 'MOVE':
				offerVariables.jackErrorForPots = (attrVal !== 'na');
				break;
		}
		this.shoppingCartRequest(offerVariables);
	}

	public onChangeInternational(value, offerVariables) {
		offerVariables.dhpIntlCalled = true;
		offerVariables.undoFlag = true;
		offerVariables.isInternational = value === 'Yes' ? true : false;
		offerVariables.dhpIntlSelected = value;
		this.shoppingCartRequest(offerVariables);
	}

	public selectedVideo(offerVariables, selectedTV: string) {
		offerVariables.matchingOffers = [];
		offerVariables.selectedTV = selectedTV;
		offerVariables.matchingOffers = this.offerFilter(offerVariables.videorOffer, selectedTV, GenericValues.cVideo, GenericValues.cPrimary, offerVariables);
	}

	public byPass(offerVariables) {
		offerVariables.byPassBool = !offerVariables.byPassBool;
		offerVariables.unQualifiedOffers = [];
		this.retrieveOffers(offerVariables, false, undefined, undefined, (data) => {
			if (offerVariables.byPassBool) {
				offerVariables.internerOffer = offerVariables.unQualifiedOffers;
			} else {
				offerVariables.internerOffer = offerVariables.qualifiedUnfilter;
				offerVariables.selectedTech = "na";
			}
			this.createSlot(offerVariables);
		});
	}

	public onChangeVoiceMail(value: string, offerVariables) {
		offerVariables.voiceMail = false;
		offerVariables.undoFlag = true;
		offerVariables.voiceMailValue = value;
		this.store.dispatch({ type: 'RETAIN_VOICE_MAIL', payload: value });
		offerVariables.potsVoiceMailMandatory = false;
		if (offerVariables.voiceMailValue === 'na') {
			offerVariables.potsVoiceMailMandatory = true;
			return false;
		} else if (offerVariables.voiceMailValue === 'Yes') {
			offerVariables.voiceMail = true;
			this.shoppingCartRequest(offerVariables);
		} else {
			this.shoppingCartRequest(offerVariables);
		}
	}

	public onChangeWireless(value: string, offerVariables: OfferVariables) {
		offerVariables.selectedWire = value;
		offerVariables.undoFlag = true;
		this.fetchPriceforSTB(offerVariables);
	}

	public onChangeWireMaintainance(value: string, offerVariables: OfferVariables) {
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		switch (flow) {
			case 'MOVE':
			case 'STACKAMEND':
			case 'CHANGE':
				offerVariables.selectedMaintainance = undefined;
				offerVariables.wireMaintainance = false;
				offerVariables.undoFlag = true;
				offerVariables.potsWireMainMandatory = false;
				offerVariables.wireMaintainanceValue = value;
				if (offerVariables.wireMaintainanceValue === 'na') {
					offerVariables.potsWireMainMandatory = true;
					return false;
				}
				if (offerVariables.wireMaintainanceValue === 'Yes') {
					offerVariables.wireMaintainance = true;
					offerVariables.selectedDHPOffer
						.productOffer.productComponents.forEach(products => {
							if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Wire Maintenance Plan') !== -1) {
								offerVariables.selectedMaintainance = this.getDHPComponents(products, offerVariables);
								this.shoppingCartRequest(offerVariables);
							}
						});
				} else {
					this.shoppingCartRequest(offerVariables);
				}
				break;
			case 'BILLING':
				offerVariables.selectedMaintainance = undefined;
				offerVariables.wireMaintainance = false;
				offerVariables.undoFlag = true;
				if (value === "Yes") {
					offerVariables.wireMaintainance = true;
					offerVariables.selectedDHPOffer.productOffer.productComponents.forEach(products => {
						if (
							products.componentType !== GenericValues.cPrimary &&
							products.product.productName.indexOf("Wire Maintenance Plan") !== -1
						) {
							offerVariables.selectedMaintainance = this.getDHPComponents(products, offerVariables);
							this.shoppingCartRequest(offerVariables);
						}
					});
				} else {
					this.shoppingCartRequest(offerVariables);
				}
				break;
			default:
				offerVariables.selectedMaintainance = undefined;
				offerVariables.wireMaintainance = false;
				offerVariables.wireMaintainanceValue = value;
				if (value === 'No') {
					offerVariables.isWireMaintainanceNoSelected = true;
					offerVariables.potsWireMainMandatory = false;
					this.shoppingCartRequest(offerVariables);
				} else if (value === 'Yes') {
					offerVariables.wireMaintainance = true;
					offerVariables.isWireMaintainanceYesSelected = true;
					offerVariables.selectedDHPOffer && offerVariables.selectedDHPOffer
						.productOffer.productComponents.forEach((products) => {
							if (products.componentType !== GenericValues.cPrimary && products.product.productName.indexOf('Wire Maintenance Plan') !== -1) {
								offerVariables.selectedMaintainance = this.getDHPComponents(products, offerVariables);
								this.shoppingCartRequest(offerVariables);
							}
						});
				} else {
					offerVariables.isWireMaintainanceYesSelected = false;
					offerVariables.isWireMaintainanceNoSelected = false;
					this.shoppingCartRequest(offerVariables);
				}
		}
	}

	public onChangePortingCheck(value: string, offerVariables: OfferVariables) {
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		switch (flow) {
			case 'MOVE':
			case 'STACKAMEND':
			case 'CHANGE':
				offerVariables.portingCheck = false;
				offerVariables.undoFlag = true;
				offerVariables.portingValue = value;
				offerVariables.potsPortingMandatory = false;
				if (offerVariables.portingValue === 'na') {
					offerVariables.potsPortingMandatory = true;
					if (flow === 'CHANGE') {
						offerVariables.isPortingCheckNoSelected = false;
						offerVariables.isPortingCheckYesSelected = false;
					}
					return false;
				} else if (offerVariables.portingValue === 'Yes') {
					offerVariables.portingCheck = true;
					if (flow === 'CHANGE') {
						offerVariables.isPortingCheckYesSelected = true;
					}
					this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: offerVariables.portingCheck });
				} else {
					if (flow === 'CHANGE') {
						offerVariables.isPortingCheckNoSelected = true;
					}
					this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: offerVariables.portingCheck })
					if (flow === 'MOVE') {
						this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' });
					}
				}
				break;
			case 'BILLING':
				offerVariables.portingCheck = false;
				offerVariables.undoFlag = true;
				offerVariables.portingValue = value;
				offerVariables.potsPortingMandatory = false;
				if (offerVariables.portingValue === "na") {
					offerVariables.potsPortingMandatory = true;
					return false;
				} else if (offerVariables.portingValue === "Yes") {
					offerVariables.portingCheck = true;
					this.store.dispatch({
						type: "POTS_PORTING_CHECK",
						payload: offerVariables.portingCheck
					});
				} else {
					this.store.dispatch({
						type: "POTS_PORTING_CHECK",
						payload: offerVariables.portingCheck
					});
				}
				break;
			default:
				offerVariables.portingCheck = false;
				if (value === 'No') {
					offerVariables.isPortingCheckNoSelected = true;
					this.store.dispatch({ type: 'TELEPHONE_NUMBER_TYPE', payload: 'DEFAULTED' });
				} else {
					offerVariables.isPortingCheckNoSelected = false;
				}
				if (value === 'Yes') {
					offerVariables.isPortingCheckYesSelected = true;
					offerVariables.portingCheck = true;
					this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: offerVariables.portingCheck });
				}
				else {
					offerVariables.isPortingCheckYesSelected = false;
					this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: offerVariables.portingCheck });
				}
				if (!offerVariables.portingCheck && !offerVariables.isPortingCheckNoSelected && !offerVariables.isPortingCheckYesSelected && !offerVariables.ismetroTNdisabled) {
					offerVariables.potsPortingMandatory = true;
				} else {
					offerVariables.potsPortingMandatory = false;
				}
		}

	}

	public expiredDiscounts(offerVariables: OfferVariables) {
		offerVariables.isExpiredDiscounts = 0;
		for (let i = 0; i < offerVariables.discArray.length; i++) {
			if ((offerVariables.discArray[i].discountRule === null || offerVariables.discArray[i].discountRule === "A" || offerVariables.discArray[i].discountRule === "O" || offerVariables.discArray[i].discountRule === "I" || (offerVariables.discArray[i].discountRule && offerVariables.discArray[i].discountRule.toUpperCase() === 'PARENT DISCOUNT')) && ((!offerVariables.discArray[i].selected && offerVariables.discArray[i].discountDuration !== 1) || (offerVariables.discArray[i].discountDuration !== 1200 && offerVariables.discArray[i].discountDuration !== 1))) {
				offerVariables.isExpiredDiscounts = offerVariables.isExpiredDiscounts + 1;
			}
		}
		return offerVariables.isExpiredDiscounts;
	}
	public retrieveSecurityDepositHistoryForOptOut(offerVariables) {
		this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryRequest", JSON.stringify(offerVariables.ban));
		this.logger.startTime();
		this.bMService.getSecurityDepositHistory(offerVariables.ban)
			.catch((error: any) => {
				offerVariables.loading = false;
				this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryResponse", JSON.stringify(error));
				this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryResponse", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				this.systemErrorService.logAndRouteUnexpectedError("error", offerVariables.orderRefNumber, "retrieveSecurityDepositHistoryCall", offerVariables.currentComponentName, "Offer change Page", error);
				return Observable.throwError(null);
			})
			.subscribe((data) => {
				this.logger.endTime();
				this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryResponse", JSON.stringify(data ? data : ''));
				this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryResponse", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				if (data && data.depositInfo && data.depositInfo.length > 0) {
					offerVariables.depositHistory = data;
				}
			},
				(error) => {
					this.logger.endTime();
					this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryResponse", JSON.stringify(error));
					this.logger.log("info", offerVariables.currentComponentName, "getSecurityDepositHistoryResponse", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					offerVariables.loading = false;
					if (error === undefined || error === null) {
						return;
					}
					let unexpectedError = false;
					if (this.ctlHelperService.isJson(error)) {
						offerVariables.apiResponseError = JSON.parse(error);
						if (offerVariables.apiResponseError !== undefined && offerVariables.apiResponseError !== null && offerVariables.apiResponseError.errorResponse &&
							offerVariables.apiResponseError.errorResponse.length > 0) {
							this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", offerVariables.currentComponentName, "offer change Page", offerVariables.apiResponseError);
						} else { unexpectedError = true; }
					} else { unexpectedError = true; }
					if (unexpectedError) {
						let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
						this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", offerVariables.currentComponentName, "offer change Page", lAPIErrorLists);
					}
					offerVariables.retrieveOffersLoading = false;
					window.scroll(0, 0);
				}
			);
	}

	public existingProductsSelected(offerVariables, flag) {
		if (flag === 'CHANGE_EXISTING_TAB') {
			offerVariables.enablechangetab = true;
		} else if (flag === 'BILLING_EXISTING_TAB') {
			offerVariables.enableBillingtab = true;
		} else if (flag === 'PENDING_EXISTING_TAB') {
			offerVariables.enablependingtab = true;
		} else {
			// do nothing
		}
		this.store.dispatch({ type: "BILLING_EXISTING_TAB", payload: flag === "BILLING_EXISTING_TAB" ? true : false });
		this.store.dispatch({ type: "CHANGE_EXISTING_TAB", payload: flag === "CHANGE_EXISTING_TAB" ? true : false });
		this.store.dispatch({ type: "MOVE_EXISTING_TAB", payload: flag === "MOVE_EXISTING_TAB" ? true : false });
		this.store.dispatch({ type: "DISCONNECT_EXISTING_TAB", payload: flag === "DISCONNECT_EXISTING_TAB" ? true : false });
		this.store.dispatch({ type: 'PENDING_EXISTING_TAB', payload: flag === "PENDING_EXISTING_TAB" ? true : false });
		this.store.dispatch({ type: 'COR_EXISTING_TAB', payload: flag === "COR_EXISTING_TAB" ? true : false });
	}

	public isExists(custObj, filterBy, flag?): boolean {
		let val = false;
		if (custObj) {
			custObj.forEach(obj => {
				if (obj.action && obj.action !== 'REMOVE') {
					if (!flag && obj.offerCategory === filterBy && obj.offerType !== 'SUBOFFER') {
						val = true;
					} else if (flag && (obj.offerCategory === filterBy || obj.offerCategory === GenericValues.sData)
						&& obj.offerType !== 'SUBOFFER') {
						val = true;
					}
				}
			});
		}
		return val;
	}

	public expiredSpeed(offerVariables, expiredSelectedSpeed) {
		if (expiredSelectedSpeed.productOfferingId !== offerVariables.selectedInternetOfferdId) {
			offerVariables.selectedInternetOfferdId = expiredSelectedSpeed.productOfferingId;
			this.store.dispatch({ type: 'SELECTED_EXPIRED_OFFER', payload: [expiredSelectedSpeed] });
			// offerVariables.internerOffer.push(expiredSelectedSpeed);
			this.createSlot(offerVariables, expiredSelectedSpeed);
		}
	}

	public salesExpiredOfferSelected(offerVariables, offerId) {
		offerVariables.selectedSalesExpiredOfferId = offerId;
		this.store.dispatch({ type: 'EXPIRED_OFFERID', payload: offerId });
		offerVariables.undoFlag = true;
		offerVariables.isSalesExpiredOfferSelected = true;
		offerVariables.addOfferExpired = true;
	}

	public existingProductConfigCheck(offerVariables, item: any) {
		item && item.productConfiguration && item.productConfiguration.forEach((data) => {
			if (!offerVariables.isDtvOpus) {
				if (data && data.productType === GenericValues.cDTV) {
					data.configItems && data.configItems.forEach((config) => {
						config && config.configDetails && config.configDetails.forEach((details) => {
							if (details && details.formName === 'DTV AccountID') {
								details.formItems && details.formItems.forEach((items) => {
									if (items && items.attributeName === 'DIRECTV Account ID') {
										if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
											offerVariables.directvAccountId = items.attributeValue[0].value;
										}
									}
								});
							}
						});
					});
				}
			}
			if (data && data.productType === GenericValues.iData) {
				data.configItems && data.configItems.forEach((config) => {
					config && config.configDetails && config.configDetails.forEach((details) => {
						if (details && details.formName === 'Devices') {
							details.formItems && details.formItems.forEach((items) => {
								if (items && items.attributeName === 'Quantity') {
									if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
										offerVariables.selectedQuantity = items.attributeValue[0].value;
										offerVariables.deviceSelected = true;
									}
								}
							});
						}
					});
				});
			}
		});
	}

	public retrieveSecurityDepositHistory(offerVariables: OfferVariables, removeProduct: any, removeProductOpen: any, ) {
		if (offerVariables.isRemovePhone) {
			let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
			switch (flow) {
				case 'MOVE':
				case 'STACKAMEND':
				case 'CHANGE':
				case 'BILLING':
					this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistoryRequest", JSON.stringify(offerVariables.ban));
					this.logger.startTime();
					offerVariables.loading = true;
					this.bMService.getSecurityDepositHistory(offerVariables.ban)
						.catch((error: any) => {
							this.logger.endTime();
							this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistoryResponse", JSON.stringify(error));
							this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
							offerVariables.loading = false;
							this.systemErrorService.logAndRouteUnexpectedError("error", offerVariables.orderRefNumber, "retrieveSecurityDepositHistoryCall", "offerHelper.service.ts", "Offer Helper Service", error);
							return Observable.throwError(null);
						})
						.subscribe((data) => {
							this.logger.endTime();
							this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistoryResponse", JSON.stringify(data ? data : ''));
							this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
							offerVariables.loading = false;
							let flag = false;
							if (data && data.depositInfo && data.depositInfo.length > 0) {
								offerVariables.depositHistory = data;
								if (flow === "MOVE") {
									removeProduct.open();
								} else if (flow === "STACKAMEND") {
									flag = this.amountShownRemove(true, offerVariables);
									if (!flag && offerVariables.holdedObjects.orderReference.customerOrderType === 'NEWINSTALL') {
										this.removeExistingProduct(offerVariables, { type: offerVariables.productToRemove });
									}
									if (flag) removeProduct.open();
								}
							} else if (flow === "STACKAMEND") {
								if (!flag) {
									if (offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
										this.removeExistingProduct(offerVariables, { type: offerVariables.productToRemove });
									} else if (!offerVariables.isLatestPendingOrderNI && offerVariables.isAmend) {
										let exist = false;
										offerVariables.existingServicesForRemove && offerVariables.existingServicesForRemove.forEach(exItem => {
											if (!exist && ((offerVariables.productToRemove === 'removeHp' && exItem.offerCategory === GenericValues.cHP) ||
												(offerVariables.productToRemove !== 'removeHp' && (exItem.offerCategory === GenericValues.iData || exItem.offerCategory === GenericValues.sData)))) {
												removeProduct.open();
												exist = true;
											}
										})
										if (!exist) this.removeExistingProduct(offerVariables, { type: offerVariables.productToRemove });
									}
								}
							}
						},
							(error) => {
								this.logger.endTime();
								this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistoryResponse", JSON.stringify(error));
								this.logger.log("info", "offerHelper.service.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
								offerVariables.loading = false;
								if (error === undefined || error === null) {
									return;
								}
								let unexpectedError = false;
								if (this.ctlHelperService.isJson(error)) {
									offerVariables.apiResponseError = JSON.parse(error);
									if (offerVariables.apiResponseError !== undefined && offerVariables.apiResponseError !== null && offerVariables.apiResponseError.errorResponse &&
										offerVariables.apiResponseError.errorResponse.length > 0) {
										this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "offerHelper.service.ts", "Offer Helper Service", offerVariables.apiResponseError);
									} else { unexpectedError = true; }
								} else { unexpectedError = true; }
								if (unexpectedError) {
									let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
									this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "offerHelper.service.ts", "Offer Helper Service", lAPIErrorLists);
								}
								if (flow === "CHANGE") {
									offerVariables.retrieveOffersLoading = false;
								}
								window.scroll(0, 0);
							});
					if (flow === "CHANGE" || flow === "BILLING") {
						removeProductOpen.open();
					} else if (flow === "STACKAMEND") {
						// let flag = this.amountShownRemove(true, offerVariables);
						if (offerVariables.holdedObjects.orderReference.customerOrderType !== 'NEWINSTALL') {
							// removeProductOpen.open();
						}
						// if (flag) removeProduct.open();
					}
			}
		}
	}

	public amountShownRemove(flag, offerVariables) {
		if (offerVariables.removal.productType && offerVariables.removal.productType !== undefined && offerVariables.depositHistory && offerVariables.depositHistory.depositInfo !== null && offerVariables.depositHistory.depositInfo !== undefined) {
			for (let i = 0; i < offerVariables.depositHistory.depositInfo.length; i++) {
				if (offerVariables.removal.productType === offerVariables.depositHistory.depositInfo[i].productType) {
					return true;
				}
			}
		}
		return false;
	}

	public checkAction(component, offerVariables: OfferVariables) {
		let action: string = 'ADD';
		if (component === 'TECH INSTALL') {
			return 'NOCHANGE';
		}

		if (component === 'MODEM' && offerVariables.modemExist) {
			return 'CHANGE';
		}

		if (component === 'CENTURYLINK @ EASE' && offerVariables.easeExist) {
			return 'CHANGE';
		}

		if (component === GenericValues.secureWifiComponent && offerVariables.secureWifiExist) {
			return 'CHANGE';
		}

		if (component === 'Jack and Wire' && offerVariables.jackExist) {
			return 'CHANGE';
		}
		return action;
	}

	public removeTV(offerVariables: OfferVariables) {
		offerVariables.videoSelected = 'NoTV';
		offerVariables.newVideoSelected = 'NoTV';
		this.retrieveOffers(offerVariables, false);
	}

	public retrieveExpiredOffers(offerVariables, CB?: Function) {
		let currentFlowName = '';
		if (offerVariables.flow === "BILLING" || offerVariables.flow === "BILLANDREC") {
			currentFlowName = 'billing';
		} else if (offerVariables.flow === "CHANGE" || offerVariables.flow === "stackAmend") {
			currentFlowName = 'change';
		} else if (offerVariables.flow === "MOVE") {
			currentFlowName = 'move';
		}

		let userData = this.appStateService.getState().user;
		if (userData.autoLogin) {
			if (userData && userData.autoLogin && userData.autoLogin !== undefined && userData.autoLogin.oamData && userData.autoLogin.oamData !== null && userData.autoLogin.oamData !== undefined) {
				offerVariables.agentCuid = userData.autoLogin && userData.autoLogin.oamData.agentCuid ? userData.autoLogin.oamData.agentCuid : '';
				offerVariables.firstName = userData.autoLogin && userData.autoLogin.oamData.agentFirstName;
				offerVariables.lastName = userData.autoLogin && userData.autoLogin.oamData.agentLastName;
				offerVariables.ensembleId = userData.autoLogin && userData.autoLogin.oamData.ensembleId ? userData.autoLogin.oamData.ensembleId : '';
			}
		}
		let offerRequest: any;
		let retainVal = <Observable<any>>this.store.select('retain');
		let retSubscribe = retainVal.subscribe(
			(retVal => {
				if (retVal.selectProduct) {
					offerRequest = retVal.selectProduct;
				}
			}
			));
		retSubscribe.unsubscribe();
		offerRequest.taskId = userData.taskId;
		offerRequest.payload.filterCriteria = { "isExpiredOffersRequest": true };
		offerVariables.loading = true;
		this.logger.startTime();
		this.logger.log("info", offerVariables.currentComponentName, "ExpSelectProductRequest", JSON.stringify(offerRequest));
		this.productService.getExpOffers(offerRequest, currentFlowName)
			.catch((error: any) => {
				this.logger.endTime();
				this.logger.log("error", offerVariables.currentComponentName, "ExpSelectProductResponse", error);
				this.logger.log("error", offerVariables.currentComponentName, "ExpSelectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
				offerVariables.loading = false;
				this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit task - Offer ", offerVariables.currentComponentName, "Create Cart - Offer Page", error);
				return Observable.throwError(null);
			})
			.subscribe(
				(data) => {
					offerVariables.taskId = data.taskId;
					offerVariables.tempTaskId = data.taskId;
					this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
					offerVariables.loading = false;
					this.logger.endTime();
					this.logger.log("info", offerVariables.currentComponentName, "ExpSelectProductResponse", JSON.stringify(data ? data : ''));
					this.logger.log("info", offerVariables.currentComponentName, "ExpSelectProductSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
					if (data && data.payload && data.payload.retrievalTypes) {
						let offersByFilters = this.retrieveOffersByFilter(data.payload.retrievalTypes);
						if (offersByFilters) {
							for (let offers in offersByFilters) {
								offersByFilters[offers].forEach(item => offerVariables.expiredOffers.push(item));
							}
						}
						CB(data);
					}
				}, error => { });
	}

	public getModemCompatibiltyMsg(modemValues: OfferProductComponents, offerVariables: OfferVariables): string {
		let isModemCompatible = 'true';
		modemValues = offerVariables.modemCompatValues;
		modemValues && modemValues.product && modemValues.product.productAttributes && modemValues.product.productAttributes.forEach(attr => {
			attr && attr.compositeAttribute && attr.compositeAttribute.forEach(comp => {
				if (isModemCompatible === 'true' && comp && comp.attributeName === 'modemCompatibilityMessage') {
					isModemCompatible = comp.attributeValue;
				}
			})
		})
		return isModemCompatible;
	}

	public mouseEnter(div: string, offerVariables: OfferVariables) {
		let flow = offerVariables.flow && offerVariables.flow.toUpperCase();
		offerVariables.showHoverMessage = false;
		switch (flow) {
			case 'CHANGE':
				if (offerVariables.currentSpeed === offerVariables.selectedSpeed) {
					offerVariables.showHoverMessage = true;
				}
				break;
			case 'STACKAMEND':
				if (!((!offerVariables.selfInstall && (offerVariables.installationValues && offerVariables.installationValues.product && offerVariables.installationValues.product.productName === 'TECH INSTALL') && (offerVariables.recommendedTech && offerVariables.recommendedTech.compositeAttribute[0] && offerVariables.recommendedTech.compositeAttribute[0].attributeValue !== 'Y')) || (offerVariables.recommendedTech && offerVariables.recommendedTech.compositeAttribute[0] && offerVariables.recommendedTech.compositeAttribute[0].attributeValue === 'Y'))) {
					offerVariables.showHoverMessage = true;
				} else if (!offerVariables.installationValues) {
					offerVariables.showHoverMessage = true;
				}
				break;
		}
	}

	public mouseLeave(div: string, offerVariables: OfferVariables) {
		offerVariables.showHoverMessage = false;
	}

	public setOptOutMessage(iObject: any, offerVariables: OfferVariables) {
		offerVariables.removeMessage = iObject[0];
		offerVariables.productToRemove = iObject[1];
	}

	//Initialize NI and Move
	public initialize(offerVariables: OfferVariables, exist: any, state: boolean, store: Store<AppStore>) {
		let orderSubscription: Subscription;
		let orderObservable: Observable<any> = store.select('order');
		let pendingSubscription: Subscription;
		let pendingObservable: Observable<any> = store.select('pending');
		let pendingData: any;
		const flow = exist && exist.orderFlow && exist.orderFlow.flow;
		if (exist && exist.orderFlow && (flow === 'Newinstall' || flow === 'Move') && offerVariables.fromHold && !exist.orderFlow.selectProductCalled && !offerVariables.holdCalled) {
			pendingSubscription = pendingObservable.subscribe((pending) => {
				pendingData = pending;
				pending && pending.orderDocument && pending.orderDocument.creditReview && pending.orderDocument.creditReview.depositInfo &&
					pending.orderDocument.creditReview.depositInfo.depositRequired ? offerVariables.reqDeposit = true : offerVariables.reqDeposit = false;
				let inputAddress: any;
				const callerInfo: ContactInfo = {
					firstName: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.accountName &&
						pending.orderDocument.accountInfo.accountName.firstName ? pending.orderDocument.accountInfo.accountName.firstName : 'First Name',
					lastName: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.accountName &&
						pending.orderDocument.accountInfo.accountName.lastName ? pending.orderDocument.accountInfo.accountName.lastName : 'Last Name',
					phoneNumber: pending && pending.orderDocument && pending.orderDocument.accountInfo && pending.orderDocument.accountInfo.contact &&
						pending.orderDocument.accountInfo.contact.contactNumber ? pending.orderDocument.accountInfo.contact.contactNumber : '2424242424',
				};
				inputAddress = {
					addressLine: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetAddress,
					unitNumber: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.subAddress
						&& pending.orderDocument.serviceAddress.subAddress.combinedDesignator,
					stateOrProvince: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.stateOrProvince,
					city: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.city,
					postCode: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.zipCode,
					singleLine: true,
					orderReferenceNumber: pending && pending.orderReference && pending.orderReference.orderReferenceNumber,
					//to check
					streetNrFirst: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrFirst,
					streetNrFirstSuffix: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrFirstSuffix,
					streetNrLast: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrLast,
					streetNrLastSuffix: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetNrLastSuffix,
					streetName: pending && pending.orderDocument && pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.streetName,
				};
				offerVariables.prodConfig = pending && pending.orderDocument && pending.orderDocument.productConfiguration;
				if (offerVariables.prodConfig && flow === 'Move') this.existingProductConfigCheck(offerVariables, offerVariables.prodConfig);
				offerVariables.holdedObjects = pending;
				offerVariables.loading = true;
				this.logger.log("info", "offer.component.ts", "initRequest", JSON.stringify(inputAddress));
				this.logger.startTime();
				if (exist.orderFlow.flow === 'Newinstall') {
					this.addressService.checkAddress(inputAddress, true)
						.catch((error: any) => {
							this.logger.endTime();
							this.logger.log("error", "offer.component.ts", "initResponse", error);
							this.logger.log("error", "offer.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
							offerVariables.loading = false;
							this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "INIT - checkAddress", "offer.component.ts", "Address Page", error);
							return Observable.throwError(null);
						})
						.subscribe((data) => {
							({ orderSubscription, state } = this.addressCheck(data, offerVariables, callerInfo, inputAddress, orderSubscription, orderObservable, state, store, flow, pendingData));
						}, (error) => {
							this.logger.endTime();
							this.logger.log("error", "offer.component.ts", "initResponse", error);
							this.logger.log("error", "offer.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
							offerVariables.loading = false;
							if (error === undefined || error === null)
								return;
						});
				} else if (exist.orderFlow.flow === 'Move') {
					this.addressService.moveAddress(inputAddress, true, pending.orderDocument, true)
						.catch((error: any) => {
							this.logger.endTime();
							this.logger.log("error", "offer-move.component.ts", "moveAddressResponse", JSON.stringify(error));
							this.logger.log("error", "offer-move.component.ts", "moveAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
							this.ctlHelperService.setLocalStorage('error', error);
							offerVariables.loading = false;
							return Observable.throwError(null);
						})
						.subscribe(
							(data) => {
								({ orderSubscription, state } = this.addressCheck(data, offerVariables, callerInfo, inputAddress, orderSubscription, orderObservable, state, store, flow, pendingData));
							},
							(error) => {
								this.logger.endTime();
								this.logger.log("error", "offer-move.component.ts", "moveAddressResponse", JSON.stringify(error));
								this.logger.log("error", "offer-move.component.ts", "moveAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
								offerVariables.loading = false;
								let unexpectedError = false;
								if (this.ctlHelperService.isJson(error)) {
									offerVariables.apiResponseError = JSON.parse(error);
									if (offerVariables.apiResponseError !== undefined && offerVariables.apiResponseError !== null && offerVariables.apiResponseError.errorResponse &&
										offerVariables.apiResponseError.errorResponse.length > 0) {
										this.systemErrorService.logAndeRouteToSystemError("error", "offer.component.ts", offerVariables.taskName, "Offer Move Page", offerVariables.apiResponseError);
									} else unexpectedError = true;
								} else unexpectedError = true;
								if (unexpectedError) {
									let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(offerVariables.orderRefNumber);
									this.systemErrorService.logAndeRouteToSystemError("error", "offer-move.component.ts", offerVariables.taskName, "Offer Move Page", lAPIErrorLists);
								}
							})
				}
			});
		}
		else {
			state = this.selectProductAPI(offerVariables, state, store);
		}
		if (orderSubscription !== undefined) orderSubscription.unsubscribe();
		if (pendingSubscription !== undefined) pendingSubscription.unsubscribe();
		return state;
	}

	private addressCheck(data: any, offerVariables: OfferVariables, callerInfo: ContactInfo, inputAddress: any, orderSubscription: Subscription, orderObservable: Observable<any>, state: boolean, store: Store<AppStore>, flow: any, pendingData: any) {
		this.logger.endTime();
		this.logger.log("info", "offer.component.ts", "initResponse", JSON.stringify(data ? data : ''));
		this.logger.log("info", "offer.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
		offerVariables.loading = false;
		const response = data;
		let serviceCategory: any;
		if (flow === 'Newinstall') {
			serviceCategory = response.payload.serviceCategory
		} else if (flow === 'Move') {
			serviceCategory = response.payload.newLocation.serviceCategory
		}
		if (response && response.taskName === 'Select Product') {
			this.store.dispatch({ type: 'UPDATE_USER', payload: callerInfo });
			let internetCheck = false;
			let videoAvail;
			let phoneAvail: boolean = false;
			const phoneType = [];
			const videoType = [];
			if (this.addressService.checkCategoryId('DATA', serviceCategory) !== undefined) {
				internetCheck = true;
			}
			if (this.addressService.checkCategoryId('DATA/VIDEO', serviceCategory) !== undefined) {
				videoAvail = true;
				videoType.push({
					name: 'DATA/VIDEO',
					displayName: 'PRISM TV',
					code: 'PTV',
					tabName: 'PRISM'
				});
			}
			if (this.addressService.checkCategoryId('VIDEO-DTV', serviceCategory) !== undefined) {
				videoAvail = true;
				videoType.push({
					name: 'VIDEO-DTV',
					displayName: 'DIRECTV',
					code: 'DTV',
					tabName: 'DIRECTV'
				});
			}
			if (this.addressService.checkCategoryId('VOICE-DHP', serviceCategory) !== undefined) {
				phoneAvail = true;
				phoneType.push({
					name: 'VOICE-DHP',
					displayName: 'Digital(DHP)',
					code: 'DHP',
					tabName: 'DHP'
				});
			}
			if (this.addressService.checkCategoryId('VOICE-HP', serviceCategory) !== undefined) {
				phoneAvail = true;
				phoneType.push({
					name: 'VOICE-HP',
					displayName: 'Home Phone',
					code: 'HMP',
					tabName: 'Home Phone'
				});
			}
			const user: User = {
				id: 1,
				internetCheck,
				videoCheck: videoAvail,
				phoneCheck: phoneAvail,
				phoneType: phoneType,
				videoType: videoType,
				enabledServiceList: serviceCategory,
				ban: pendingData && pendingData.orderDocument && pendingData.orderDocument.accountInfo && pendingData.orderDocument.accountInfo.ban
			};
			offerVariables.videoAvail = videoAvail;
			offerVariables.phoneAvail = phoneAvail;
			offerVariables.phoneArray = phoneType;
			offerVariables.videoArray = videoType;
			offerVariables.enabledServiceList = serviceCategory;
			this.store.dispatch({ type: 'UPDATE_USER', payload: user });
			this.store.dispatch({ type: 'FINAL_ADDRESS', payload: inputAddress });
			orderSubscription = orderObservable.subscribe((ord) => {
				if (ord.orderRefNumber) {
					data.orderRefNumber = ord.orderRefNumber;
					data.processInstanceId = ord.processInstanceId;
					data.taskId = ord.taskId;
					if (flow === 'Move') { this.store.dispatch({ type: 'TASK_ID', payload: data.taskId }); }
					offerVariables.isCustomize = ord && ord.taskName === 'Checkout & Scheduling' ? true : false;
					this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
					if (!offerVariables.holdCalled) {
						offerVariables.holdCalled = true;
						state = this.selectProductAPI(offerVariables, state, store, true);
					}
				}
				else {
					if (!offerVariables.holdCalled) {
						offerVariables.isPortingCheckYesSelected = false;
						offerVariables.isPortingCheckNoSelected = false;
						if (offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument
							&& offerVariables.holdedObjects.orderDocument.reservedTN
							&& offerVariables.holdedObjects.orderDocument.reservedTN.length > 0) {
							offerVariables.holdedObjects.orderDocument.reservedTN.forEach((tn) => {
								if (tn && tn.productType === GenericValues.cHP && tn.tnType === 'EXTPORTED') {
									offerVariables.isPortingCheckYesSelected = true;
									offerVariables.isPortingCheckNoSelected = false;
									offerVariables.portingCheck = true;
									this.store.dispatch({ type: 'POTS_PORTING_CHECK', payload: offerVariables.portingCheck });
								}
							});
						}
						this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
						this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
						offerVariables.holdCalled = true;
						state = this.selectProductAPI(offerVariables, state, store, true);
					}
				}
			});
		}
		return { orderSubscription, state };
	}



	public selectProductAPI(offerVariables: OfferVariables, state: boolean, store: Store<AppStore>, flag?: boolean) {
		let user = store.select('user');
		let retainVal: Observable<any>;
		let userSubscription: Subscription = user.subscribe((data) => {
			if (data.selfinstallselected) offerVariables.selfinstallSelected = true;
			if (!state) {
				offerVariables.internetAvail = data.internetCheck;
				let retSubscribe: Subscription;
				if (data && data !== undefined && data.orderInit && data.orderInit !== undefined && data.orderInit.orderRefNumber && data.orderInit.orderRefNumber !== undefined) {
					offerVariables.orderRefNumber = data.orderInit.orderRefNumber;
				}
				if (data && data !== undefined && data.orderInit && data.orderInit !== undefined && data.orderInit.processInstanceId && data.orderInit.processInstanceId !== undefined) {
					offerVariables.processInstanceId = data.orderInit.processInstanceId;
				}
				if (data && data !== undefined && data.orderInit && data.orderInit !== undefined && data.orderInit.taskId && data.orderInit.taskId !== undefined) {
					offerVariables.taskId = data.orderInit.taskId;
				}
				if (data && data !== undefined && data.orderInit && data.orderInit !== undefined && data.orderInit.taskName && data.orderInit.taskName !== undefined) {
					offerVariables.taskName = data.orderInit.taskName;
				}
				if (data && data !== undefined && data.orderInit && data.orderInit !== undefined && data.orderInit.payload && data.orderInit.payload !== undefined && data.orderInit.payload.serviceCategory && data.orderInit.payload.serviceCategory !== undefined) {
					offerVariables.serviceSpec = data.orderInit.payload.serviceCategory;
				}
				if (data && data !== undefined && data.orderInit && data.orderInit !== undefined && data.orderInit.payload && data.orderInit.payload !== undefined && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
					offerVariables.legacyProvider = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
				}
				offerVariables.videoAvail = data.videoCheck;
				offerVariables.phoneAvail = data.phoneCheck;
				offerVariables.phoneArray = data.phoneType;
				offerVariables.videoArray = data.videoType;
				offerVariables.enabledServiceList = data.enabledServiceList;
				if (data.previousUrl !== '/' && (data.previousUrl !== '/home' || offerVariables.fromHold) && data.previousUrl !== '/multipleMatchAddress') {
					offerVariables.isReEntrant = true;
					offerVariables.reEntrant = true;
					offerVariables.reentrantUI = true;
					this.appStateService.setLocationURLs();
					offerVariables.existingBillingType = data && data.prepaidFlag ? data.prepaidFlag : '';
					retainVal = this.store.select('retain');
					retSubscribe = retainVal.subscribe(((retVal) => {
						offerVariables.taskId = data.taskId;
						offerVariables.taskName = retVal.selectProduct.taskName;
						offerVariables.cartObject = retVal.addOns;
						offerVariables.cartCopyObject = retVal.addOns;
						offerVariables.isPrepaidAccountPage = retVal.isPrepaidAccountPage;
						offerVariables.previousLoaded = {
							payload: {
								productConfiguration: offerVariables.holdCalled ? offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument &&
									offerVariables.holdedObjects.orderDocument.productConfiguration : retVal.addOns.payload.productConfiguration
							}
						};
						if (offerVariables.previousLoaded && offerVariables.previousLoaded.payload && offerVariables.previousLoaded.payload.productConfiguration) {
							const selectConfigList = offerVariables.previousLoaded.payload.productConfiguration;
							if (selectConfigList !== null && selectConfigList && selectConfigList.length > 0) {
								for (let i = 0; i < selectConfigList.length; i++) {
									selectConfigList[i].configItems && selectConfigList[i].configItems.forEach((selectedConf) => {
										offerVariables.selectedQuantity = selectedConf.configDetails[0].formItems[0].attributeValue[0].value;
									})
								}
							}
						}
						if (offerVariables.holdCalled) {
							offerVariables.isWireMaintainanceNoSelected = true;
							offerVariables.isVoiceMailNoSelected = true;
							offerVariables.previousLoaded.payload.productConfiguration = offerVariables.prodConfig;
						}
						let foundInternet = false;
						if (retVal.potsBooleans && retVal.potsBooleans !== undefined) {
							offerVariables.retainedPotsBooleans = retVal.potsBooleans;
							offerVariables.voiceMail = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.voiceMail : offerVariables.voiceMail;
							offerVariables.voiceMail ? offerVariables.voiceMailValue = 'Yes' : offerVariables.voiceMailValue = 'No';
							offerVariables.wireMaintainPresent ? offerVariables.wireMaintainanceValue = 'Yes' : offerVariables.wireMaintainanceValue = 'No';
							// offerVariables.isVoiceMailNoSelected = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.isVoiceMailNoSelected : offerVariables.isVoiceMailNoSelected;
							// offerVariables.isVoiceMailYesSelected = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.isVoiceMailYesSelected : offerVariables.isVoiceMailYesSelected;
							offerVariables.isWireMaintainanceNoSelected = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.isWireMaintainanceNoSelected : offerVariables.isWireMaintainanceNoSelected;
							offerVariables.isWireMaintainanceYesSelected = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.isWireMaintainanceYesSelected : offerVariables.isWireMaintainanceYesSelected;
							offerVariables.isPortingCheckNoSelected = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.isPortingCheckNoSelected : offerVariables.isPortingCheckNoSelected;
							offerVariables.isPortingCheckYesSelected = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.isPortingCheckYesSelected : offerVariables.isPortingCheckYesSelected;
							offerVariables.portingCheck = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.portingCheck : offerVariables.portingCheck;
							offerVariables.retainValueForPotsJack = offerVariables.retainedPotsBooleans ? offerVariables.retainedPotsBooleans.retainValueForPotsJack : offerVariables.retainValueForPotsJack;
						}
						const custOrderItem: CustomerOrderItems[] = offerVariables.holdCalled ? offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument &&
							offerVariables.holdedObjects.orderDocument.customerOrderItems : retVal.addOns.payload.cart.customerOrderItems;
						const prodConfigfromretVal = offerVariables.holdCalled ? offerVariables.holdedObjects && offerVariables.holdedObjects.orderDocument &&
							offerVariables.holdedObjects.orderDocument.productConfiguration : retVal.addOns.payload.productConfiguration;
						if (offerVariables.cartObject && offerVariables.cartObject.payload) {
							offerVariables.cartObject.payload = {
								cart: {
									customerOrderItems: custOrderItem
								},
								productConfiguration: prodConfigfromretVal
							}
						} else {
							offerVariables.cartObject = {
								payload: {
									cart: {
										customerOrderItems: custOrderItem
									},
									productConfiguration: prodConfigfromretVal
								}
							}
						}
						offerVariables.previousLoaded = cloneDeep(offerVariables.cartObject);
						if (offerVariables.holdCalled) offerVariables.previousLoaded.payload.productConfiguration = offerVariables.prodConfig;
						if (custOrderItem.length > 0) {
							custOrderItem.forEach((item) => {
								if (item.offerCategory === GenericValues.cHP) {
									offerVariables.hpSelected = true;
									offerVariables.phoneOfferTemp = true;
									offerVariables.phoneSelectedTemp = 'HMP';
									offerVariables.phoneSelected = 'HMP';
									offerVariables.newPhoneUpdated = true;
								}
								else if (item.offerCategory === GenericValues.cDHP) {
									offerVariables.e911ValidatedAddress = retVal.e911ValidatedAddress;
									offerVariables.isE911Called = true;
									offerVariables.phoneOfferTemp = true;
									offerVariables.phoneSelectedTemp = 'DHP';
									offerVariables.phoneSelected = 'DHP';
									offerVariables.newPhoneUpdated = true;
								}
								else if (item.offerCategory === GenericValues.iData) {
									foundInternet = true;
								}
								else if (item.offerCategory === GenericValues.cDTV) {
									offerVariables.videoOfferTemp = true;
									offerVariables.videoSelectedTemp = 'DTV';
									offerVariables.newVideoSelected = 'DTV';
									offerVariables.newVideoUpdated = true;
								}
							});
						}
						if (offerVariables.hpSelected && retVal.potsBooleans === undefined && offerVariables.fromHold) {
							offerVariables.voiceMail ? offerVariables.voiceMailValue = 'Yes' : offerVariables.voiceMailValue = 'No';
							offerVariables.wireMaintainPresent ? offerVariables.wireMaintainanceValue = 'Yes' : offerVariables.wireMaintainanceValue = 'No';
						}
						if (!state && !foundInternet) {
							offerVariables.phoneSelected = offerVariables.phoneSelectedTemp;;
							offerVariables.phoneOffer = offerVariables.phoneOfferTemp;
							if (offerVariables.videoOfferTemp) {
								offerVariables.videoOffer = true;
								offerVariables.videoSelected = 'DTV';
							}
							offerVariables.internetCheck = false;
							offerVariables.EaseDefault = true;
							state = true;
							this.retrieveOffers(offerVariables, false, true);
						}
						if (!state && foundInternet) {
							offerVariables.internetCheck = true;
							offerVariables.newInternetCheck = true
							offerVariables.internetAvail = true;
							state = true;
							this.retrieveOffers(offerVariables, true);
						}
					}));
				}
				else {
					if (!state) {
						state = true;
						if (offerVariables.internetAvail) {
							offerVariables.internetCheck = data.internetCheck;
							this.retrieveOffers(offerVariables, true);
						}
						else {
							if (offerVariables.phoneArray && offerVariables.phoneArray.length > 0) {
								offerVariables.phoneArray.forEach((offer) => {
									if (offer && (offer.name === GenericValues.cHP)) {
										offerVariables.phoneSelected = 'HMP';
										offerVariables.phoneOffer = true;
										this.retrieveOffers(offerVariables, false, true);
									}
								});
							}
						}
					}
				}
				if (retSubscribe !== undefined)
					retSubscribe.unsubscribe();
				if (offerVariables.cartObject) {
					offerVariables.cartObject.payload && offerVariables.cartObject.payload.cart && offerVariables.cartObject.payload.cart.customerOrderItems.forEach((cust) => {
						if (cust && cust.offerCategory === GenericValues.cHP && cust.offerType !== 'SUBOFFER') {
							cust.customerOrderSubItems && cust.customerOrderSubItems.forEach((exSub) => {
								if (exSub.productName === "Voice Messaging") {
									offerVariables.voiceMail = true;
									// offerVariables.isVoiceMailYesSelected = true;
									// offerVariables.isVoiceMailNoSelected = false;
								}
								else if (exSub.productName.indexOf('Wire Maintenance Plan') !== -1) {
									offerVariables.wireMaintainance = true;
									offerVariables.isWireMaintainanceYesSelected = true;
									offerVariables.isWireMaintainanceNoSelected = false;
								} else if (exSub.productName.indexOf('Jack and Wire') !== -1) {
									offerVariables.retainValueForPotsJack = exSub.productAttributes[0].compositeAttribute[0].attributeValue
								}
							});
						}
					})
					if (offerVariables.holdCalled) {
						if (!offerVariables.retainValueForPotsJack || offerVariables.retainValueForPotsJack === '') {
							offerVariables.retainValueForPotsJack = 'No work is needed';
						}
						offerVariables.retainedPotsBooleans = {
							wireMaintainance: offerVariables.wireMaintainance,
							voiceMail: offerVariables.voiceMail,
							retainValueForPotsJack: offerVariables.retainValueForPotsJack
						}
					}
				}
			}
		});
		if (userSubscription !== undefined) userSubscription.unsubscribe();
		return state;
	}
	public removeExistingProduct(offerVariables, removed: any) {
		let flow = offerVariables.flow.toUpperCase()
		if (flow === 'BILLING' || flow === 'MOVE' || flow === 'STACKAMEND') {
			offerVariables.undoFlag = true
		}
		else {
			offerVariables.undoFlag = false;
		}
		offerVariables.removeSelectedReason = removed.removeReason;
		//existingDeleteexSub method is explicitly for stack amend 
		function existingDeleteexSub(i: number, offerVariables) {
			offerVariables.existingServices[i].action = 'REMOVE';
			let exServ = cloneDeep(offerVariables.existingServices[i]);
			if (exServ.existingServiceSubItems) {
				exServ.customerOrderSubItems = exServ.existingServiceSubItems;
				delete exServ.existingServiceSubItems;
			}
			offerVariables.removedProductItem.push(exServ);
		}
		//end of existingDeleteexSub method
		if (removed.type === "removeInternetNotLast") {
			//iterate over cartObject
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
				if (item.offerCategory === GenericValues.sData ||
					item.offerCategory === GenericValues.iData) {
					for (let i = 0; i < offerVariables.existingServices.length; i++) {
						if (offerVariables.existingServices[i].offerCategory === item.offerCategory) {
							offerVariables.existingServices[i].action = "REMOVE";
							offerVariables.existingServices[i].catalogId = offerVariables.existingServices[i].catalogId === null ? offerVariables.hsiCatalogId : offerVariables.existingServices[i].catalogId;
							flow !== 'STACKAMEND' ?
								offerVariables.removedProductItem.push(offerVariables.existingServices[i]) :
								existingDeleteexSub(i, offerVariables);
						}
					}
					item.action = "REMOVE";
					offerVariables.isInternetRemoved = true;
					offerVariables.internetCheck = false;
					offerVariables.newInternetCheck = false;

					this.retrieveOffers(offerVariables, (flow === 'MOVE' || flow === 'STACKAMEND') ? false : true);
				}
			});
		}
		if (removed.type === "optOut") {
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
				if (item.offerCategory === GenericValues.cDTV) {
					for (let i = 0; i < offerVariables.existingServices.length; i++) {
						if (offerVariables.existingServices[i].offerCategory === item.offerCategory) {
							offerVariables.existingServices[i].action = "REMOVE";
							offerVariables.existingServices[i].catalogId = offerVariables.existingServices[i].catalogId === null ? offerVariables.hsiCatalogId : offerVariables.existingServices[i].catalogId;
							flow !== 'STACKAMEND' ?
								offerVariables.removedProductItem.push(offerVariables.existingServices[i]) :
								existingDeleteexSub(i, offerVariables);
						}
					}
					item.action = "REMOVE";
					offerVariables.isOptedOut = true;
					offerVariables.videoOffer = false;
					offerVariables.videoSelected = "NoTV";
					offerVariables.newVideoSelected = 'NoTV';
					offerVariables.optedOutCheck = true;
					this.retrieveOffers(offerVariables, (flow === 'MOVE' || flow === 'STACKAMEND') ? false : true);
				}
			});
		}
		if (removed.type === "removePrism") {
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
				if (item.offerCategory === "VIDEO-PRISM") {
					item.action = "REMOVE";
					offerVariables.removedProductItem.push(item);
					offerVariables.isRemoved = true;
					offerVariables.videoOffer = false;
					offerVariables.videoSelected = "NoTV";
					offerVariables.newVideoSelected = 'NoTV';
					if (offerVariables.dataLink === undefined && offerVariables.preserveHSI !== undefined) {
						offerVariables.dataLink = offerVariables.preserveHSI;
					}
					this.retrieveOffers(offerVariables, (flow === 'MOVE' || flow === 'STACKAMEND') ? false : true);
				}
			});
		}
		if (removed.type === "removeDhp" || removed.type === "removeHp") {
			//iterate over cartObject
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
				if (item.offerCategory === "VOICE-DHP" || item.offerCategory === "VOICE-HP") {
					for (let i = 0; i < offerVariables.existingServices.length; i++) {
						if (offerVariables.existingServices[i].offerCategory === item.offerCategory) {
							offerVariables.existingServices[i].action = "REMOVE";
							offerVariables.existingServices[i].catalogId = offerVariables.existingServices[i].catalogId === null ? offerVariables.hsiCatalogId : offerVariables.existingServices[i].catalogId;
							flow !== 'STACKAMEND' ?
								offerVariables.removedProductItem.push(offerVariables.existingServices[i]) :
								existingDeleteexSub(i, offerVariables);
						}
					}
					item.action = "REMOVE";
					let is911 = false;
					removed.type === "removeDhp"
						? (offerVariables.isDHPRemoved = true)
						: (offerVariables.isHPRemoved = true);
					if ((offerVariables.phoneSelected === "DHP" || offerVariables.newPhoneSelected === 'DHP') && !offerVariables.dhpExisting) {
						offerVariables.e911Validation.open();
						is911 = true;
					} else if (
						((offerVariables.phoneSelected === "HMP" || offerVariables.newPhoneSelected === 'HMP') && removed.type === "removeHp") ||
						((offerVariables.phoneSelected === "DHP" || offerVariables.newPhoneSelected === 'DHP') && removed.type === "removeDhp")
					) {
						offerVariables.phoneOffer = false;
						offerVariables.phoneSelected = GenericValues.noPhone;
						offerVariables.newPhoneSelected = GenericValues.noPhone;
					}

					if (!is911) { this.retrieveOffers(offerVariables, (flow === 'MOVE' || flow === 'STACKAMEND') ? false : true); }
					if (flow === 'MOVE' && item.offerCategory === 'VOICE-DHP') {
						offerVariables.onlyDHPRemoved = true;
					}
				}
			});
		}
		if (removed.type === "removeInternet" || (removed.type === "removeLastInternet" && removed.subType === "Remove Internet and Add Home Phone")) {
			//iterate over cartObject
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
				if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
					if (flow === 'CHANGE' || flow === 'MOVE' || flow === 'STACKAMEND') {
						for (let i = 0; i < offerVariables.existingServices.length; i++) {
							if (offerVariables.existingServices[i].offerCategory === item.offerCategory && offerVariables.existingServices[i].customerOrderSubItems &&
								offerVariables.existingServices[i].customerOrderSubItems.length > 0) {
								offerVariables.existingServices[i].action = 'REMOVE';
								offerVariables.existingServices[i].catalogId = offerVariables.existingServices[i].catalogId === null ? offerVariables.hsiCatalogId : offerVariables.existingServices[i].catalogId;
								flow !== 'STACKAMEND' ?
									offerVariables.removedProductItem.push(offerVariables.existingServices[i]) :
									existingDeleteexSub(i, offerVariables);
							}
						}
					}
					item.action = "REMOVE";
					if (flow === 'BILLING') { offerVariables.removedProductItem.push(item); }
					offerVariables.isInternetRemoved = true;
					offerVariables.internetCheck = false;
					offerVariables.phoneSelected = "HMP";
					offerVariables.newInternetCheck = false;
					offerVariables.newPhoneSelected = 'HMP';
					this.retrieveOffers(offerVariables, (flow === 'MOVE' || flow === 'STACKAMEND') ? false : true);
				}
			});
		}
		if (removed.type === "removeLastInternet" && removed.subType === "Remove Internet and Close") {
			offerVariables.cartObject.payload.cart.customerOrderItems.forEach(item => {
				if (item.offerCategory === GenericValues.sData || item.offerCategory === GenericValues.iData) {
					offerVariables.removedProductItem.push(item);
				}
			});
			let services = [{
				offerCategory: offerVariables.removedProductItem[0].offerCategory,
				reasonType: offerVariables.removeSelectedReason.rsnType,
				reasonText: null,
				reasonList: [{
					code: offerVariables.removeSelectedReason.rsnCode,
					description: offerVariables.removeSelectedReason.chgDesc,
					waiverFlag: "No"
				}],
				etfInfo: {
					terminationFee: "0",
					currencyCode: "USD",
					contractExpiryDate: null
				}
			}];
			let apiRequest = {
				orderRefNumber: offerVariables.orderRefNumber,
				processInstanceId: offerVariables.processInstanceId,
				taskId: offerVariables.taskId,
				taskName: "Select Disconnect Reason",
				payload: {
					disconnectInfo: services
				}
			};
			offerVariables.loading = true;
			this.logger.log("info", "offerHelper.service.ts", "disconnectSubmitInfoRequest", JSON.stringify(apiRequest));
			this.logger.startTime();
			this.disconnectServiceCall.submitInformation(apiRequest)
				.catch((error: any) => {
					this.logger.endTime();
					this.logger.log("error", "offerHelper.service.ts", "disconnectSubmitInfoResponse", JSON.stringify(error));
					this.logger.log("error", "offerHelper.service.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
					offerVariables.loading = false;
					this.systemErrorService.logAndRouteUnexpectedError(
						"error", "Not Applicable",
						"Submit Task", "offerHelper.service.ts",
						"Disconnect call - Offers Page",
						error);
					return Observable.throwError(null);
				})
				.subscribe(
					data => {
						this.logger.endTime();
						this.logger.log("info", "offerHelper.service.ts", "disconnectSubmitInfoResponse", JSON.stringify(data));
						this.logger.log("info", "offerHelper.service.ts", "disconnectSubmitInfoServc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
						offerVariables.loading = false;
						this.store.dispatch({ type: "SCHEDULE_SHIPPING", payload: data });
						this.router.navigate(["/disconnect-schedule"]);
					},
					error => {
						this.logger.endTime();
						this.logger.log("error", "offerHelper.service.ts", "disconnectSubmitInfoResponse", JSON.stringify(error));
						this.logger.log("error", "offerHelper.service.ts", "disconnectSubmitInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
						offerVariables.loading = false;
						if (error === undefined || error === null) return;
						let unexpectedError = false;
						if (this.ctlHelperService.isJson(error)) {
							offerVariables.apiResponseError = JSON.parse(error);
							if (
								offerVariables.apiResponseError !== undefined &&
								offerVariables.apiResponseError !== null &&
								offerVariables.apiResponseError.errorResponse &&
								offerVariables.apiResponseError.errorResponse.length > 0
							) {
								this.systemErrorService.logAndeRouteToSystemError(
									"error",
									"Pending Summary",
									"offerHelper.service.ts",
									"Offers Page",
									offerVariables.apiResponseError
								);
							} else unexpectedError = true;
						} else unexpectedError = true;
						if (unexpectedError) {
							let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
								offerVariables.orderRefNumber
							);
							this.systemErrorService.logAndeRouteToSystemError(
								"error",
								"Pending Summary",
								"offerHelper.service.ts",
								"Offers Page",
								lAPIErrorLists
							);
						}
						offerVariables.retrieveOffersLoading = false;
						window.scroll(0, 0);
					}
				);
		}
	}

	public getSelected(modemValues, selectedModem, offerVariables) {
		if (selectedModem === modemValues.attributeValue && modemValues && modemValues.attributeDisplayName === 'Convert to Purchased Modem' && offerVariables.isConverted) {
			return true;
		} else if (selectedModem === modemValues.attributeValue && modemValues.attributeDisplayName !== 'Convert to Purchased Modem') {
			return true;
		} 
		// else if (selectedModem !== null && selectedModem !== 'purchase') {
		// 	return true;
		// } 
		else {
			return false;
		}
	}
}