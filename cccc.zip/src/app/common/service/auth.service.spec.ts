/* tslint:disable */
import {} from 'jasmine';
import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { Http, BaseRequestOptions, ConnectionBackend, RequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Response, ResponseOptions, RequestMethod } from '@angular/http';
import { MockConnection } from '@angular/http/testing';
import { ShoppingCart } from '../models/cart.model';
import { Store, StoreModule } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { Observable } from 'rxjs/Rx';
import { Observer } from 'rxjs/Observer';
import { userReducer } from '../reducers/user.reducer';
import { AuthService } from './auth.service';
import { RouterModule, Router } from '@angular/router';
import { ReflectiveInjector, Injector } from '@angular/core';
import { AppStateService } from './app-state.service';
import { Logger } from "../logging/default-log.service";
import { User } from '../models/user.model';

xdescribe('Auth Service', () => {
   let authToken:string = '';
let nameListService: AuthService;
    let mockBackend: MockBackend;
    let initialResponse: any
  let router: Router;
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      BaseRequestOptions,
      MockBackend,
         {
          provide:AuthService,useClass: class {AuthService}
         } ,
       {
        provide: Http,
        useFactory: function(backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
          return new Http(backend, defaultOptions);
        },
        deps: [MockBackend, BaseRequestOptions]
      },
      { 
        provide: Router, 
        useClass: class { navigate = jasmine.createSpy("navigate"); }
      },
      AuthService,
       StoreModule.forRoot({user: userReducer}),
       AuthService,
       RouterModule,
       AppStateService,
       Logger
    ]}));
      it('Should have "AuthService" intitalized', inject([AuthService ], (service:AuthService) => {
        expect(service instanceof AuthService).toEqual(true);
    }));

     it('Should have cart Data equal to Observable', inject([AuthService], (service:AuthService) => {
      let actual = service.user;
       expect(actual).toEqual(jasmine.any(Observable));
     }));

     it('Should have "ngOnInit"  will be  defined`',inject([ AuthService ], (service:AuthService) => {
        expect(service.ngOnInit).toBeDefined; 
    }));

   it('Should have "clearTokens"  response will be valid data`',inject([ AuthService ], (service:AuthService) => {
   service.clearTokens();
    expect (service.updateUserToken('1234567')).toBe(undefined);
    expect (service.updateJWTToken('8901234')).toBe(undefined);
   let token={
      token: '1234567', jwtToken: '8901234', id: 12112
   }
    service.user.subscribe(g => {
      expect(g).toEqual(token);
    });    
    }));


 it('Should have "updateUserToken" response will be valid url and data ', 
    inject(
      [AuthService, MockBackend],
      fakeAsync((service:AuthService, backend: MockBackend) => {
        backend.connections.subscribe((connection: MockConnection) => {
        expect(connection.request.method).toBe(RequestMethod.Get);
         expect(connection.request.url).toMatch(/user/);
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json'); 
        });
      service.updateUserToken('');
      let token={
         token: '123333' , id: 1234
      }
        service.user.subscribe(g => {
      expect(g).toEqual(token);
    }); 
      })));

   it('Should have "updateJWTToken" response will be valid url and data ', 
    inject(
      [AuthService, MockBackend],
      fakeAsync((service:AuthService, backend: MockBackend) => {
        backend.connections.subscribe((connection: MockConnection) => {
        expect(connection.request.method).toBe(RequestMethod.Get);
         expect(connection.request.url).toMatch(/user/);
        expect(connection.request.headers.get('Content-Type')).toEqual('application/json'); 
        });
      service.updateJWTToken('eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhcGljbGllbnRAY3RsLmNvbSIsImlzcyI6IkN0bCIsImlhdCI6MTQ3OTgxNTA5MSwiZXhwIjoxNzkwODU1MDkxfQ.kc-P35bWdS_7qWslOXs7mtcW3CcSZ8fU2jTDtc6uRUiBMhWr1U_3cG3Yoew9nYjgGkvcaRHMl_QHDiEarIrHdA');
      let token={
         jwtToken: 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhcGljbGllbnRAY3RsLmNvbSIsImlzcyI6IkN0bCIsImlhdCI6MTQ3OTgxNTA5MSwiZXhwIjoxNzkwODU1MDkxfQ.kc-P35bWdS_7qWslOXs7mtcW3CcSZ8fU2jTDtc6uRUiBMhWr1U_3cG3Yoew9nYjgGkvcaRHMl_QHDiEarIrHdA' , id: 123
      }
        service.user.subscribe(g => {
      expect(g).toEqual(token);
    }); 
      })));

  it('Should have "getJWTToken" response will be valid data`',inject([ AuthService ], (service:AuthService) => {
      expect(service.getJWTToken()).toEqual('eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhcGljbGllbnRAY3RsLmNvbSIsImlzcyI6IkN0bCIsImlhdCI6MTQ3OTgxNTA5MSwiZXhwIjoxNzkwODU1MDkxfQ.kc-P35bWdS_7qWslOXs7mtcW3CcSZ8fU2jTDtc6uRUiBMhWr1U_3cG3Yoew9nYjgGkvcaRHMl_QHDiEarIrHdA');
    }));

   it('Should have "setRequestOptions" response will be valid data  ', 
    inject(
      [AuthService, MockBackend],
      fakeAsync((service:AuthService, backend: MockBackend) => {
        backend.connections.subscribe((connection: MockConnection) => {
        expect(connection.request.headers.toJSON()).toBe({ 'X-Authorization': 'Bearer ' + 767, 'Content-Type': 'application/json' });
        expect(service.getJWTToken()).toBe('eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhcGljbGllbnRAY3RsLmNvbSIsImlzcyI6IkN0bCIsImlhdCI6MTQ3OTgxNTA5MSwiZXhwIjoxNzkwODU1MDkxfQ.kc-P35bWdS_7qWslOXs7mtcW3CcSZ8fU2jTDtc6uRUiBMhWr1U_3cG3Yoew9nYjgGkvcaRHMl_QHDiEarIrHdA');     
        });
        service.setRequestOptions('12','767') ;
      })));    
});
