import { TestBed, async } from "@angular/core/testing";
import { Observable } from 'rxjs/Rx';
import { BlueMarbleService } from './bm.service';
import { Subject } from 'rxjs/Subject';
import { Store } from '@ngrx/store';
import { ReviewOrderService } from './review-order.service';
import { MockBlueMarbleService } from "../../common/service/mockServices.test";
import { MockServer } from '../../MockServer.test';

describe('AccountService', () => {
    let mockServer = new MockServer();
    let reviewOrderService: ReviewOrderService;
    let mockBMService: MockBlueMarbleService;
    let active = 'active';
    const mockRedux: any = {
        dispatch(action) {},
        configureStore() {},
        select(reducer) {
            return Observable.of(
                mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    }
    let mockStore = {provide: Store, useValue: mockRedux}

    beforeEach(async(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            providers: [
              ReviewOrderService,
                { provide: BlueMarbleService, useClass: MockBlueMarbleService },
                mockStore
            ]
        });
    }));

    beforeEach(() => {
      reviewOrderService = TestBed.get(ReviewOrderService)
      mockBMService = TestBed.get(BlueMarbleService)
    });

    it("should create account.service", () => {
        expect(reviewOrderService).toBeDefined();
    });

    it("should call fetchPrimaryProductName", () => {
        let temp = reviewOrderService.fetchPrimaryProductName();
        expect(temp).toBeDefined();
    });

    it("should call postSubmitTaskService", () => {
        let temp = reviewOrderService.postSubmitTaskService(active, "Change");
        expect(temp).toBeDefined();
        temp = reviewOrderService.postSubmitTaskService(active, "COR");
        expect(temp).toBeDefined();
        temp = reviewOrderService.postSubmitTaskService(active, "submit");
        expect(temp).toBeDefined();
    });

    it("should call postVacationSubmitTaskService", () => {
        let temp = reviewOrderService.postVacationSubmitTaskService(active);
        expect(temp).toBeDefined();
    });

    it("should call putSubmitTaskService", () => {
        let temp = reviewOrderService.putSubmitTaskService(active);
        expect(temp).toBeDefined();
    });

    it("should call getBillQuoteDetails", () => {
        let temp = reviewOrderService.getBillQuoteDetails(active);
        expect(temp).toBeDefined();
    });

    it("should call returnOptions", () => {
        let temp = reviewOrderService.returnOptions(['1','2','3']);
        expect(temp).toEqual(['0','1','2']);
    });

    it("should call checkExist", () => {
        let temp = reviewOrderService.checkExist([true], true);
        expect(temp).toEqual(true);
    });

    it("should call camelCaseCapitaliseTax", () => {
        let temp = reviewOrderService.camelCaseCapitaliseTax('123');
        expect(temp).toBe('123 TAX');
    });

    it("should call computedAdditionalServices", () => {
        let temp = reviewOrderService.computedAdditionalServices([
          {
            billAmount : 10
          },
          {
            billAmount : 12
          }]);
        expect(temp).toBe(22);
    });

    it("should call computedTaxes", () => {
        let temp = reviewOrderService.computedTaxes([12,12,12]);
        expect(temp).toBe(36);
    });

    it("should call getMoveReviewOrderInfo", () => {
        let temp = reviewOrderService.getMoveReviewOrderInfo(active, "submit");
        expect(temp).toBeDefined();
    });

    it("should call getChangeReviewOrderInfo", () => {
        let temp = reviewOrderService.getChangeReviewOrderInfo(active);
        expect(temp).toBeDefined();
    });

    it("should call getVacationReviewOrderInfo", () => {
        let temp = reviewOrderService.getVacationReviewOrderInfo(active);
        expect(temp).toBeDefined();
    });

    it("should call getReasonsForHoldCall", () => {
        let temp = reviewOrderService.getReasonsForHoldCall(active);
        expect(temp).toBeDefined();
    });

    it("should call submitOrderHold", () => {
        let temp = reviewOrderService.getHoldOrderSubmisson(active);
        expect(temp).toBeDefined();
    });

    it("should call removeOrderFromHold", () => {
        let temp = reviewOrderService.removeOrderFromHold(active, "change");
        expect(temp).toBeDefined();
    });

    it("should call retrieveRcc", () => {
        let temp = reviewOrderService.retrieveRcc(active);
        expect(temp).toBeDefined();
    });

    it("should call retrieveProductDealerCodeInfo", () => {
        let temp = reviewOrderService.retrieveProductDealerCodeInfo(active);
        expect(temp).toBeDefined();
    });

    it("should call validateDealerCode", () => {
        let temp = reviewOrderService.validateDealerCode(active);
        expect(temp).toBeDefined();
    });

    it("should call prepaidCancelOrderCode", () => {
        let temp = reviewOrderService.prepaidCancelOrderCode(active);
        expect(temp).toBeDefined();
    });
});