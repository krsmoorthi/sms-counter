import { Injectable } from '@angular/core';
import { BlueMarbleService } from './bm.service';
import { EnterpriseAddress } from '../models/cart.model';
import { ServiceCategoryId } from '../models/product.model';
import { CountryStateService } from './country-state.service';
import { Country } from '../models/country.model';
import { AppStore } from '../models/appstore.model';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { User } from '../models/user.model';
import * as moment from 'moment-timezone';
import { env } from '../../../environments/environment';

@Injectable()
export class AddressService {
    public countries: Country[];
    private user: Observable<User>;
    private sfdcAccountId: string;
    private sfdcBillingAccountID: string;
    private agentCuid: string;
    private firstName: string;
    private lastName: string;
    private ensembleId: string = '';
    private callStartTime: string;
    private ucid: string;
    private tfn: string;
    private sfdcBan: string;
    private reuseBan: boolean = false;

    constructor(public bMService: BlueMarbleService,
        public countryStateService: CountryStateService,
        public store: Store<AppStore>) {
        this.countries = this.countryStateService.getCountries();
        this.user = <Observable<User>>store.select('user');
        this.user.subscribe((data) => {
            if (data.autoLogin !== null && data.autoLogin !== undefined) {
                if (data.autoLogin.sfcData) {
                    this.sfdcAccountId = data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : '';
                    this.sfdcBillingAccountID = data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID : '';
                    this.sfdcBan = data.autoLogin.sfcData.accountBAN;
                    this.reuseBan = (data.autoLogin.sfcData.type === 'ReopenBAN');
                    if (data.autoLogin.sfcData.orderActivity) {
                        if (data.autoLogin.sfcData.orderActivity.callStartTime) {
                            this.callStartTime = data.autoLogin.sfcData.orderActivity.callStartTime;
                            if (this.callStartTime && this.callStartTime.length > 0 && this.callStartTime !== "NA") {
                                var UTCTime = moment.utc(this.callStartTime).toDate();
                                var MSTTime = moment(UTCTime).tz('America/Denver').format('YYYY-MM-DD HH:mm:ss');
                                this.callStartTime = MSTTime;
                            }
                            else {
                                this.callStartTime = "NA";
                            }
                        }
                        else {
                            this.callStartTime = "NA";
                        }
                        if (data.autoLogin.sfcData.orderActivity.ucid) {
                            this.ucid = data.autoLogin.sfcData.orderActivity.ucid;
                        }
                        else {
                            this.ucid = "NA";
                        }
                        if (data.autoLogin.sfcData.orderActivity.tfn) {
                            this.tfn = data.autoLogin.sfcData.orderActivity.tfn;
                        }
                        else {
                            this.tfn = "NA";
                        }
                    }
                    else {
                        this.callStartTime = "NA";
                        this.ucid = "NA";
                        this.tfn = "NA";
                    }

                }

                if (data.autoLogin.oamData) {
                    this.agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    this.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    this.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    this.ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                }
            }

        });
    }

    /**
     * Address API call from home page
     */
    public checkAddress(item: any, flag: boolean, move?, inRange?) {
        let validAddressInput = this.getAddress(item, flag, inRange);
        if (flag) {
            return this.bMService.initAddress(validAddressInput);
        } else if (move) {
            return this.bMService.submitTask(validAddressInput, "move");
        } else {
            return this.bMService.submitTask(validAddressInput);
        }
    }

    public checkBillingRecAddress(item: any, flag: boolean, billing?) {
        let validAddressInput = this.getAddress(item, flag);
        if (flag) {
            return this.bMService.initAddress(validAddressInput);
        } else if (billing) {
            return this.bMService.billingSubmitTask(validAddressInput, true);
        } else {
            return this.bMService.submitTask(validAddressInput);
        }
    }

    public getAddress(item: any, flag: boolean, inRange?: any) {
        let address: any;
        if (flag && item.inRangeResponse === undefined) {
            address = {
                salesChannel: 'ESHOP-Customer Care',
                customerType: 'INDIVIDUAL',
                customerSegment: 'Regular',
                customerOrderType: 'NEWINSTALL',
                orderRefNumber: item.orderReferenceNumber,
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
                address: {
                    postalAddressFlag: false,
                    addressLine: item.singleLine ? "" : item.addressLine,
                    unitNumber: item.unitNumber ? item.unitNumber : "",
                    streetAddress: item.singleLine ? item.addressLine : "",
                    streetNrFirst: item.streetNrFirst ? item.streetNrFirst : "",
                    streetNrFirstSuffix: item.streetNrFirstSuffix ? item.streetNrFirstSuffix : "",
                    streetNrLast: item.streetNrLast ? item.streetNrLast : "",
                    streetNrLastSuffix: item.streetNrLastSuffix ? item.streetNrLastSuffix : "",
                    streetName: item.streetName ? item.streetName : "",
                    streetType: item.streetType ? item.streetType : "",
                    locality: item.locality ? item.locality : item.city,
                    city: item.city ? item.city : item.locality,
                    stateOrProvince: item.stateOrProvince ? item.stateOrProvince : '',
                    postCode: item.postCode ? item.postCode : "",
                    postCodeSuffix: item.postCodeSuffix ? item.postCodeSuffix : "",
                    country: item.country ? item.country : this.countries[0].countryCode,
                    geoAddressId: item.geoAddressId ? item.geoAddressId : "",
                    geoSubAddressId: item.subAddress && item.subAddress.geoSubAddressId ? item.subAddress.geoSubAddressId : ""
                },
            };
            if (this.reuseBan) {
                address.ban = this.sfdcBan;
            }

            if (this.sfdcBillingAccountID && this.sfdcBillingAccountID.length > 0 && this.sfdcAccountId && this.sfdcAccountId.length > 0) {
                address.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
            address = this.addAddlOrderAttributes(address);

        } else if (item.inRangeResponse !== undefined && item.inRangeResponse.InRangeFlag === "AddressNotInRange") {
            address = {
                salesChannel: 'ESHOP-Customer Care',
                customerType: 'INDIVIDUAL',
                customerSegment: 'Regular',
                customerOrderType: 'NEWINSTALL',
                orderRefNumber: item.inRangeResponse.orderRefNumber,
                processInstanceId: item.inRangeResponse.processInstanceId,
                taskId: item.inRangeResponse.taskId,
                taskName: item.inRangeResponse.taskName,
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
                address: {
                    postalAddressFlag: false,
                    inRangeAddress: false,
                    addressLine: item.singleLine ? "" : item.addressLine,
                    unitNumber: item.unitNumber ? item.unitNumber : "",
                    streetAddress: item.singleLine ? item.addressLine : "",
                    streetNrFirst: item.streetNrFirst ? item.streetNrFirst : "",
                    streetNrFirstSuffix: item.streetNrFirstSuffix ? item.streetNrFirstSuffix : "",
                    streetNrLast: item.streetNrLast ? item.streetNrLast : "",
                    streetNrLastSuffix: item.streetNrLastSuffix ? item.streetNrLastSuffix : "",
                    streetName: item.streetName ? item.streetName : "",
                    streetType: item.streetType ? item.streetType : "",
                    locality: item.locality ? item.locality : item.city,
                    city: item.city ? item.city : item.locality,
                    stateOrProvince: item.stateOrProvince ? item.stateOrProvince : '',
                    postCode: item.postCode ? item.postCode : "",
                    postCodeSuffix: item.postCodeSuffix ? item.postCodeSuffix : "",
                    country: item.country ? item.country : this.countries[0].countryCode,
                    geoAddressId: item.geoAddressId ? item.geoAddressId : "",
                    geoSubAddressId: item.subAddress && item.subAddress.geoSubAddressId ? item.subAddress.geoSubAddressId : ""
                },
            };
            if (this.sfdcBillingAccountID && this.sfdcBillingAccountID.length > 0 && this.sfdcAccountId && this.sfdcAccountId.length > 0) {
                address.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
            address = this.addAddlOrderAttributes(address);

        } else if (inRange === 'AddressAddConfirmation') {
            address = {
                success: true,
                orderRefNumber: item.orderRefNumber,
                processInstanceId: item.processInstanceId,
                taskId: item.taskId,
                taskName: item.taskName,
                payload: {
                    postalAddressFlag: false,
                    inRangeAddress: item.payload.result === "Found" ? true : false,
                    addressLine: item.addressLine ? item.addressLine : "",
                    unitNumber: item.subAddress ? item.subAddress.combinedDesignator ? item.subAddress.combinedDesignator : "" : "",
                    streetAddress: item.payload.parsedAddress.streetAddress ? item.payload.parsedAddress.streetAddress : "",
                    streetNrFirst: item.payload.ranges[0].streetNrFirst ? item.payload.ranges[0].streetNrFirst : "",
                    streetNrLastSuffix: item.payload.parsedAddress.streetNrLastSuffix ? item.payload.parsedAddress.streetNrLastSuffix : "",
                    streetNrFirstSuffix: item.payload.parsedAddress.streetNrFirstSuffix ? item.payload.parsedAddress.streetNrFirstSuffix : "",
                    streetNrLast: item.payload.ranges[0].streetNrLast ? item.payload.ranges[0].streetNrLast : "",
                    streetName: item.payload.parsedAddress.streetName ? item.payload.parsedAddress.streetName : "",
                    streetType: item.payload.parsedAddress.streetType ? item.payload.parsedAddress.streetType : "",
                    locality: item.payload.parsedAddress.locality ? item.payload.parsedAddress.locality : item.payload.parsedAddress.city,
                    city: item.payload.parsedAddress.city ? item.payload.parsedAddress.city : item.payload.parsedAddress.locality,
                    stateOrProvince: item.payload.parsedAddress.stateOrProvince ? item.payload.parsedAddress.stateOrProvince : "",
                    postCode: item.payload.parsedAddress.postCode ? item.payload.parsedAddress.postCode : "",
                    postCodeSuffix: item.payload.parsedAddress.postCodeSuffix ? item.payload.parsedAddress.postCodeSuffix : "",
                    country: item.payload.parsedAddress.country ? item.payload.parsedAddress.country : this.countries[0].countryCode,
                    geoAddressId: item.payload && item.payload.parsedAddress && item.payload.parsedAddress.geoAddressId ? item.payload.parsedAddress.geoAddressId : "",
                    geoSubAddressId: item.payload && item.payload.parsedAddress && item.payload.parsedAddress.subAddress && item.payload.parsedAddress.subAddress.geoSubAddressId ? item.payload.parsedAddress.subAddress.geoSubAddressId : ""
                }
            };
        } else {
            address = {
                success: true,
                orderRefNumber: item.orderRefNumber,
                processInstanceId: item.processInstanceId,
                taskId: item.taskId,
                taskName: item.taskName,
                payload: {
                    postalAddressFlag: false,
                    inRangeAddress: false,
                    addressLine: item.addressLine ? item.addressLine : "",
                    unitNumber: item.subAddress ? item.subAddress.combinedDesignator ? item.subAddress.combinedDesignator : "" : "",
                    streetAddress: item.streetAddress ? item.streetAddress : "",
                    streetNrFirst: item.streetNrFirst ? item.streetNrFirst : "",
                    streetNrLastSuffix: item.streetNrLastSuffix ? item.streetNrLastSuffix : "",
                    streetNrFirstSuffix: item.streetNrFirstSuffix ? item.streetNrFirstSuffix : "",
                    streetNrLast: item.streetNrLast ? item.streetNrLast : "",
                    streetName: item.streetName ? item.streetName : "",
                    streetType: item.streetType ? item.streetType : "",
                    locality: item.locality ? item.locality : item.city,
                    city: item.city ? item.city : item.locality,
                    stateOrProvince: item.stateOrProvince ? item.stateOrProvince : "",
                    postCode: item.postCode ? item.postCode : "",
                    postCodeSuffix: item.postCodeSuffix ? item.postCodeSuffix : "",
                    country: item.country ? item.country : this.countries[0].countryCode,
                    geoAddressId: item.geoAddressId ? item.geoAddressId : "",
                    geoSubAddressId: item.subAddress && item.subAddress.geoSubAddressId ? item.subAddress.geoSubAddressId : ""
                }
            }
        };
        return address;
    }

    public getGeoamsrvcl(item: any) {
        return this.bMService.geoamServiceCall(item);
    }

    public checkCategoryId(type: string, specList: ServiceCategoryId[]): ServiceCategoryId {
        return specList.find((item) =>
            item.serviceCategory.indexOf(type) !== -1);
    }

    public getGeoesAddress(address: EnterpriseAddress, civicOrpostal) {
        let addressLine1 = address.streetAddress ? address.streetAddress : address.addressLine1;
        let addressLine2 = address.addressLine2 ? '&addressLine2=' + address.addressLine2 : '';
        let addressRequest = civicOrpostal + 'Validations?addressLine1=' + addressLine1 + addressLine2 + '&locality=' + address.city + '&stateOrProvince=' + address.stateOrProvince + '&postCode=' + address.postCode;
        return this.bMService.geoesServiceCall(addressRequest);
    }

    public getInitChangeCall(request: any) {
        let combinedSfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
        if (combinedSfdcAccountId && combinedSfdcAccountId.length > 0) {
            request.sfdcAccountId = (combinedSfdcAccountId ? combinedSfdcAccountId : '');
        }
        request = this.addAddlOrderAttributes(request);
        return this.bMService.initChangeCall(request);
    }

    public moveAddress(item: any, flag: boolean, existingProd: any, isHold?: boolean) {
        let validAddressInput = this.moveAddressRequest(item, existingProd, isHold);
        if (item.inRangeResponse !== undefined && (item.inRangeResponse.InRangeFlag === 'AddressAddConfirmation' || item.inRangeResponse.InRangeFlag === 'AddressNotInRange')) {
            return this.bMService.submitTask(validAddressInput, true);
        } else {
            return this.bMService.moveAddress(validAddressInput);
        }
    }

    public moveAddressRequest(item: any, existingProd: any, isHold?: boolean) {
        let address: any;
        if (item.inRangeResponse !== undefined && (item.inRangeResponse.InRangeFlag === 'AddressAddConfirmation' || item.inRangeResponse.InRangeFlag === 'AddressNotInRange')) {
            address = {
                success: true,
                orderRefNumber: item.inRangeResponse.orderRefNumber,
                processInstanceId: item.inRangeResponse.processInstanceId,
                taskId: item.inRangeResponse.taskId,
                taskName: item.inRangeResponse.taskName,
                payload: {
                    postalAddressFlag: false,
                    inRangeAddress: item.inRangeResponse.payload.result === "Found" ? true : false,
                    addressLine: item.inRangeResponse.addressLine ? item.inRangeResponse.addressLine : "",
                    unitNumber: item.inRangeResponse.subAddress ? item.inRangeResponse.subAddress.combinedDesignator ? item.inRangeResponse.subAddress.combinedDesignator : "" : "",
                    streetAddress: item.inRangeResponse.payload.parsedAddress.streetAddress ? item.inRangeResponse.payload.parsedAddress.streetAddress : "",
                    streetNrFirst: item.inRangeResponse.payload.ranges[0].streetNrFirst ? item.inRangeResponse.payload.ranges[0].streetNrFirst : "",
                    streetNrLastSuffix: item.inRangeResponse.payload.parsedAddress.streetNrLastSuffix ? item.inRangeResponse.payload.parsedAddress.streetNrLastSuffix : "",
                    streetNrFirstSuffix: item.inRangeResponse.payload.parsedAddress.streetNrFirstSuffix ? item.inRangeResponse.payload.parsedAddress.streetNrFirstSuffix : "",
                    streetNrLast: item.inRangeResponse.payload.ranges[0].streetNrLast ? item.inRangeResponse.payload.ranges[0].streetNrLast : "",
                    streetName: item.inRangeResponse.payload.parsedAddress.streetName ? item.inRangeResponse.payload.parsedAddress.streetName : "",
                    streetType: item.inRangeResponse.payload.parsedAddress.streetType ? item.inRangeResponse.payload.parsedAddress.streetType : "",
                    locality: item.inRangeResponse.payload.parsedAddress.locality ? item.inRangeResponse.payload.parsedAddress.locality : item.inRangeResponse.payload.parsedAddress.city,
                    city: item.inRangeResponse.payload.parsedAddress.city ? item.inRangeResponse.payload.parsedAddress.city : item.inRangeResponse.payload.parsedAddress.locality,
                    stateOrProvince: item.inRangeResponse.payload.parsedAddress.stateOrProvince ? item.inRangeResponse.payload.parsedAddress.stateOrProvince : "",
                    postCode: item.inRangeResponse.payload.parsedAddress.postCode ? item.inRangeResponse.payload.parsedAddress.postCode : "",
                    postCodeSuffix: item.inRangeResponse.payload.parsedAddress.postCodeSuffix ? item.inRangeResponse.payload.parsedAddress.postCodeSuffix : "",
                    country: item.inRangeResponse.payload.parsedAddress.country ? item.inRangeResponse.payload.parsedAddress.country : this.countries[0].countryCode,
                    geoAddressId: item.inRangeResponse.payload.parsedAddress.geoAddressId ? item.inRangeResponse.payload.parsedAddress.geoAddressId : '',
                    geoSubAddressId: item.inRangeResponse.payload.parsedAddress.geoSubAddressId ? item.item.inRangeResponse.payload.parsedAddress.geoSubAddressId : ''
                }
            };
        } else {
            address = {
                ban: isHold ? existingProd.accountInfo.ban : existingProd.existingProductsAndServices[0].accountInfo.ban,
                salesChannel: "ESHOP-Customer Care",
                customerOrderType: "MOVE",
                orderRefNumber: item.orderReferenceNumber,
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
                toServiceAddress: {
                    postalAddressFlag: false,
                    addressLine: item.singleLine ? '' : item.addressLine,
                    unitNumber: item.unitNumber ? item.unitNumber : '',
                    streetAddress: item.singleLine ? item.addressLine : '',
                    streetNrFirst: isHold ? item && item.streetNrFirst : '',
                    streetNrFirstSuffix: isHold ? item && item.streetNrFirstSuffix : '',
                    streetNrLast: isHold ? item && item.streetNrLast : '',
                    streetNrLastSuffix: isHold ? item && item.streetNrLastSuffix : '',
                    streetName: isHold ? item && item.streetName : '',
                    streetType: item.streetType ? item.streetType : '',
                    locality: item.city ? item.city : '',
                    city: item.city ? item.city : '',
                    stateOrProvince: item.stateOrProvince ? item.stateOrProvince : '',
                    postCode: item.postCode ? item.postCode : '',
                    country: item.country ? item.country : this.countries[0].countryCode,
                    geoAddressId: item.geoAddressId ? item.geoAddressId : '',
                    geoSubAddressId: item.geoSubAddressId ? item.geoSubAddressId : ''
                },
                fromServiceAddress: isHold ? existingProd.existingServiceAddress : existingProd.existingProductsAndServices[0].serviceAddress
            };
            if (this.sfdcBillingAccountID && this.sfdcBillingAccountID.length > 0 && this.sfdcAccountId && this.sfdcAccountId.length > 0) {
                address.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
            address = this.addAddlOrderAttributes(address);
        }
        return address;
    }

    public billingRecordsAddress(item: any, flag: boolean, serviceAddrsChangeChk: any, existingProd: any, banNo: any) {
        let validAddressInput = this.billingRecAddressRequest(item, serviceAddrsChangeChk, existingProd, banNo);
        if (item !== undefined && (item.InRangeFlag === 'AddressAddConfirmation' || item.InRangeFlag === 'AddressNotInRange')) {
            return this.bMService.billingSubmitTask(validAddressInput, true);
        } else {
            return this.bMService.billingRecAddress(validAddressInput);
        }
    }

    public billingRecAddressRequest(item: any, serviceAddrsChangeChk: any, existingProd: any, banNo: any) {
        let address: any;
        if (item !== undefined && (item.InRangeFlag === 'AddressAddConfirmation' || item.InRangeFlag === 'AddressNotInRange')) {
            address = {
                success: true,
                orderRefNumber: item.orderRefNumber,
                processInstanceId: item.processInstanceId,
                taskId: item.taskId,
                taskName: item.taskName,
                payload: {
                    postalAddressFlag: false,
                    inRangeAddress: item.payload.result === "Found" ? true : false,
                    addressLine: item.addressLine ? item.addressLine : "",
                    unitNumber: item.subAddress ? item.subAddress.combinedDesignator ? item.subAddress.combinedDesignator : "" : "",
                    streetAddress: item.payload.parsedAddress.streetAddress ? item.payload.parsedAddress.streetAddress : "",
                    streetNrFirst: item.payload.ranges[0].streetNrFirst ? item.payload.ranges[0].streetNrFirst : "",
                    streetNrLastSuffix: item.payload.parsedAddress.streetNrLastSuffix ? item.payload.parsedAddress.streetNrLastSuffix : "",
                    streetNrFirstSuffix: item.payload.parsedAddress.streetNrFirstSuffix ? item.payload.parsedAddress.streetNrFirstSuffix : "",
                    streetNrLast: item.payload.ranges[0].streetNrLast ? item.payload.ranges[0].streetNrLast : "",
                    streetName: item.payload.parsedAddress.streetName ? item.payload.parsedAddress.streetName : "",
                    streetType: item.payload.parsedAddress.streetType ? item.payload.parsedAddress.streetType : "",
                    locality: item.payload.parsedAddress.locality ? item.payload.parsedAddress.locality : item.payload.parsedAddress.city,
                    city: item.payload.parsedAddress.city ? item.payload.parsedAddress.city : item.payload.parsedAddress.locality,
                    stateOrProvince: item.payload.parsedAddress.stateOrProvince ? item.payload.parsedAddress.stateOrProvince : "",
                    postCode: item.payload.parsedAddress.postCode ? item.payload.parsedAddress.postCode : "",
                    postCodeSuffix: item.payload.parsedAddress.postCodeSuffix ? item.payload.parsedAddress.postCodeSuffix : "",
                    country: item.payload.parsedAddress.country ? item.payload.parsedAddress.country : this.countries[0].countryCode,
                    geoAddressId: item.geoAddressId ? item.geoAddressId : "",
                    geoSubAddressId: item.geoSubAddressId ? item.geoSubAddressId : ""
                }
            };
        } else {
            address = {
                ban: existingProd.existingProductsAndServices ? existingProd.existingProductsAndServices[0].accountInfo.ban : banNo,
                salesChannel: "ESHOP-Customer Care",
                customerOrderType: "BILLANDREC",
                serviceAddressChanged: serviceAddrsChangeChk,
                serviceAddress: {
                    addressLine: item.addressLine,
                    streetAddress: item.singleLine ? item.addressLine : item.streetAddress,
                    streetNrFirst: item.streetNrFirst,
                    streetNrFirstSuffix: item.singleLine ? '' : item.streetNrFirstSuffix,
                    streetNrLast: '',
                    streetNrLastSuffix: '',
                    streetName: item.singleLine ? '' : item.streetName,
                    streetNamePrefix: '',
                    streetType: '',
                    locality: item.city ? item.city : '',
                    city: item.city ? item.city : '',
                    stateOrProvince: item.stateOrProvince ? item.stateOrProvince : '',
                    postCode: item.postCode ? item.postCode : '',
                    postCodeSuffix: 2395,
                    geoAddressId: item.geoAddressId ? item.geoAddressId : "",
                    geoSubAddressId: item.geoSubAddressId ? item.geoSubAddressId : "",
                    sourceId: 'CLSPCOMA16ACF',
                    source: 'LFACS',
                    subAddress: {
                        sourceId: "CLSPCOMA1NT9V.1",
                        source: "LFACS",
                        geoSubAddressId: 1,
                        combinedDesignator: "BLDG 1",
                        elements: [
                            {
                                designator: "APT",
                                value: 2
                            }
                        ]
                    },
                    country: item.country ? item.country : this.countries[0].countryCode
                },
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
            };
            if (this.sfdcBillingAccountID && this.sfdcBillingAccountID.length > 0 && this.sfdcAccountId && this.sfdcAccountId.length > 0) {
                address.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
            address = this.addAddlOrderAttributes(address);
        }
        return address;
    }

    public billingFromHold(request) {
        request = this.addAddlOrderAttributes(request);
        return this.bMService.billingRecAddress(request);
    }

    public addAddlOrderAttributes(request: any): any {
        let addlOrderAttributes = [
            {
                orderAttributeGroup: [
                    {
                        orderAttributeGroupName: "sfcAttrData",
                        orderAttributeGroupInfo: [
                            {
                                orderAttributes: [
                                    {
                                        orderAttributeName: "tfn",
                                        orderAttributeValue: this.tfn
                                    },
                                    {
                                        orderAttributeName: "ucid",
                                        orderAttributeValue: this.ucid
                                    },
                                    {
                                        orderAttributeName: "callStartTime",
                                        orderAttributeValue: this.callStartTime
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ];
        request.addlOrderAttributes = addlOrderAttributes;
        return request;
    }

    /* 
    * Change Of Responsibility INIT Call Function
    */
    public getInitCORespCall(request: any) {
        let combinedSfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
        if (combinedSfdcAccountId && combinedSfdcAccountId.length > 0) {
            request.sfdcAccountId = (combinedSfdcAccountId ? combinedSfdcAccountId : '');
        }
        request = this.addAddlOrderAttributes(request);
        return this.bMService.initCORespCall(request);
    }

}
