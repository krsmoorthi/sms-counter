import { Injectable } from '@angular/core';
import { BlueMarbleService } from './bm.service';

@Injectable()
export class AutoLoginService {

    constructor(public bMService: BlueMarbleService) {
        
    }

    /**
     * AutoLogin API call from home page
     */
    public getAutoLoginData(token: string) {
        return this.bMService.autoLogin(token);
    }

}
