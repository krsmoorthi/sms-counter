import { TestBed } from '@angular/core/testing';

import { AddressService } from './address.service';
import { BlueMarbleService } from './bm.service';
import { MockBlueMarbleService, MockCountryStateService } from './mockServices.test';
import { CountryStateService } from './country-state.service';
import { Store } from '@ngrx/store';
import { MockServer } from 'app/MockServer.test';
import { Observable } from 'rxjs';
import "rxjs/add/observable/of";
import { EnterpriseAddress } from '../models/cart.model';

describe('AddressService', () => {

  let mockServer = new MockServer();
  
  const mockRedux: any = {
    dispatch(obj) {return obj},
    configureStore() {},
    select(reducer) {
        return Observable.of(
          mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  };

  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      AddressService,
      { provide: BlueMarbleService, useClass: MockBlueMarbleService},
      {provide: CountryStateService, useClass: MockCountryStateService},
      {provide: Store, useValue: mockRedux}
    ]
  }));

  it('should be created address service', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    expect(addressService).toBeTruthy();
  });

  it('should match the address when flag is true', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    let enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const service = addressService.getAddress(enterpriseAddress, true);
    expect(service).toBeDefined();
  });

  it('should call the check address', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    let enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const service = addressService.checkAddress(enterpriseAddress, true);
    expect(service).toBeDefined();
  });

  it('should call the check address', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    let enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const flag = false;
    const move = true;
    const service = addressService.checkAddress(enterpriseAddress, flag, move);
    expect(service).toBeDefined();
  });

  it('should call the check address', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    let enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const flag = false;
    const move = false;
    const service = addressService.checkAddress(enterpriseAddress, flag, move);
    expect(service).toBeDefined();
  });

  it('should match the address when flag is false', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    let enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India',
      geoAddressId: '1234',
      subAddress: { geoSubAddressId: '1234', source: 'BM', sourceSystemId: '1234' }
    };
    const service = addressService.getAddress(enterpriseAddress, false);
    expect(service).toBeDefined();
  });

  it('should call the checkBillingRecAddress when flag is true', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const flag = true;
    const getAddress = addressService.getAddress(enterpriseAddress, flag);
    const checkBillingRecAddress = addressService.checkBillingRecAddress(enterpriseAddress, flag);
    expect(getAddress).toBeDefined();
    expect(checkBillingRecAddress).toBeDefined();
  });

  it('should call the checkBillingRecAddress for billing flow', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const flag = false;
    const billing = true;
    const getAddress = addressService.getAddress(enterpriseAddress, flag);
    const checkBillingRecAddress = addressService.checkBillingRecAddress(enterpriseAddress, flag, billing);
    expect(getAddress).toBeDefined();
    expect(checkBillingRecAddress).toBeDefined();
  });

  it('should call the checkBillingRecAddress when flag is false', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const flag = false;
    const billing = false;
    const getAddress = addressService.getAddress(enterpriseAddress, flag);
    const checkBillingRecAddress = addressService.checkBillingRecAddress(enterpriseAddress, flag, billing);
    expect(getAddress).toBeDefined();
    expect(checkBillingRecAddress).toBeDefined();
  });

  it('should call the getGeoesAddress', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const enterpriseAddress: EnterpriseAddress = {
      addressLine: 'ETA 3',
      street: 'Navalur',
      city: 'Chennai',
      stateOrProvince: 'Tamilnadu',
      postCode: '522509',
      country: 'India'
    };
    const getGeoesAddress = addressService.getGeoesAddress(enterpriseAddress, '');
    expect(getGeoesAddress).toBeDefined();
  });

  it('should call the getInitChangeCall', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const request = {};
    const getInitChangeCall = addressService.getInitChangeCall(request);
    expect(getInitChangeCall).toBeDefined();
  });

   it('should call the getInitCORespCall', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const request = {};
    const getInitCORespCall = addressService.getInitCORespCall(request);
    expect(getInitCORespCall).toBeDefined();
  });

  it('should call the billingFromHold', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const request = {};
    const billingFromHold = addressService.billingFromHold(request);
    expect(billingFromHold).toBeDefined();
  });

  it('should call the getGeoamsrvcl', () => {
    const addressService: AddressService = TestBed.get(AddressService);
    const getGeoamsrvcl = addressService.getGeoamsrvcl({});
    expect(getGeoamsrvcl).toBeDefined();
  });

});
