import { TestBed } from '@angular/core/testing';

import { ProductService } from './product.service';
import { MockBlueMarbleService, MockAppStateService } from './mockServices.test';
import { BlueMarbleService } from './bm.service';
import { AppStateService } from './app-state.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { MockServer } from 'app/MockServer.test';
import { env } from '../../../environments/environment';


describe('ProductService', () => {
  const req = {};
  let service: ProductService;
  const mockServer = new MockServer();

  const mockRedux: any = {
    dispatch(obj) {return obj},
    configureStore() {},
    select(reducer) {
        return Observable.of(
          mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  };

  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        ProductService,
        { provide: BlueMarbleService, useClass: MockBlueMarbleService},
        {provide: AppStateService, useClass: MockAppStateService},
        {provide: Store, useValue: mockRedux}
      ]
    })
  });

  beforeEach(() => {
    service = TestBed.get(ProductService);
  });

  it('should be created product service', () => {
    expect(service).toBeTruthy();
  });

  it('checks getOffers', () => {
    const item =  mockServer.getResponseForReducerAndApi('user-agent1');
    const actual = service.getOffers(item);
    expect(actual).toBeDefined();
  });

  it('checks getOfferRequest', () => {
    const item =  mockServer.getResponseForReducerAndApi('user-agent1');
    const actual = service.getOffers(item);
    expect(actual).toBeDefined();
  });

  it('checks getResponseForCheckOut', () => {
    const actual = service.getResponseForCheckOut(req, 'change');
    expect(actual).toBeDefined();
  })

  it('should call getResponseForCheckOut', () => {
    const actual1 = service.getResponseForCheckOut(req, 'change');
    expect(actual1).toBeDefined();
    const actual2 = service.getResponseForCheckOut(req, 'move');
    expect(actual2).toBeDefined();
    const actual3 = service.getResponseForCheckOut(req, 'billing');
    expect(actual3).toBeDefined();
    const actual4 = service.getResponseForCheckOut(req);
    expect(actual4).toBeDefined();
  })

  it('should call getCustomizeAddons', () => {
    const actual1 = service.getCustomizeAddons(req);
    expect(actual1).toBeDefined();
  })

  it('should call getE911APICall', () => {
    const actual1 = service.getE911APICall(req);
    expect(actual1).toBeDefined();
  })

  it('should call getAvailableTNs', () => {
    const actual1 = service.getAvailableTNs(req);
    expect(actual1).toBeDefined();
  })

  it('should call getAvailableNumber', () => {
    const actual1 = service.getAvailableNumber(req);
    expect(actual1).toBeDefined();
  })

  it('should call getNPANXXList', () => {
    const actual1 = service.getNPANXXList(req);
    expect(actual1).toBeDefined();
  })

  it('should call doReserveTN', () => {
    const actual1 = service.doReserveTN(req);
    expect(actual1).toBeDefined();
  })

  it('should call doReleaseTN', () => {
    const actual1 = service.doReleaseTN(req);
    expect(actual1).toBeDefined();
  })

  it('should call getTnPortingStatus', () =>  {
    const legacyProvider = 'Qwest';
    const actual1 = service.getTnPortingStatus(req);
    expect(actual1).toBeDefined();
  });

  it('should call getCompatibilityRules', () => {
    const actual1 = service.getCompatibilityRules();
    expect(actual1).toBeUndefined();
  });

  it('should call getCompatibilityRulesforClosers', () => {
    const actual1 = service.getCompatibilityRulesforClosers(req);
    expect(actual1).toBeDefined();
  });

  it('should call getOfferDisplayName', () => {
    const actual1 = service.getCompatibilityRulesforClosers(req);
    expect(actual1).toBeDefined();
  });

  it('should call getLATA', () => {
    const offerName = '';
    const ruleId =  '';
    const wirecenter =  '';
    const city =  '';
    const state =  '';
    const actual1 = service.getLATA(offerName, ruleId, wirecenter, city, state);
    expect(actual1).toBeDefined();
  });

  it('should call getHolidaysDate', () => {
    const actual1 = service.getHolidaysDate(req);
    expect(actual1).toBeDefined();
  });

  it('should call getBillingRecOffers', () => {
    const item =  mockServer.getResponseForReducerAndApi('user-agent1');
    const actual1 = service.getBillingRecOffers(item);
    expect(actual1).toBeDefined();
  });

  it('should call updateCart', () => {
    const actual1 = service.updateCart({}, true);
    expect(actual1).toBeDefined();
    const actual2 = service.updateCart({});
    expect(actual2).toBeDefined();
  });

  it('should call updateChangeCart', () => {
    const actual1 = service.updateChangeCart({}, true);
    expect(actual1).toBeDefined();
    const actual2 = service.updateChangeCart({});
    expect(actual2).toBeDefined();
  });

  it('should call updateBillingCart', () =>  {
    const actual1 = service.updateBillingCart({}, true);
    expect(actual1).toBeDefined();
    const actual2 = service.updateBillingCart({});
    expect(actual2).toBeDefined();
  });

  it('should call getResponseForRemove', () => {
    const actual1 = service.getResponseForRemove(req);
    expect(actual1).toBeDefined();
  });

  it('should call getCarrierInfo', () => {
    const url = 'https://localhost/igServiceCall/test3';
    const actual1 = service.getCarrierInfo(url);
    expect(actual1).toBeDefined();
  });

  it('should call getOffersFromLink', () =>  {
    const DATA_LINK = env.DATA_LINK;
    const url = `${DATA_LINK}`;
    const actual1 = service.getOffersFromLink(url);
    expect(actual1).toBeDefined();
  });

  it('should call getCommunityRules', () => {
    const actual1 = service.getCommunityRules();
    expect(actual1).toBeUndefined();
  });

  it('should call getTechnologyTypes', () => {
    const actual = service.getTechnologyTypes();
    expect(actual).toBeUndefined();
  });

  
  it('should call getRccDisclosure', () => {
    const actual = service.getRccDisclosure({});
    expect(actual).toBeDefined();
  });

  it('should call giftCardEligibilityAndRelation', () => {
    const actual = service.giftCardEligibilityAndRelation({});
    expect(actual).toBeDefined();
  });

});
