import { Injectable, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { Router } from '@angular/router';
import 'rxjs/add/operator/take';

@Injectable()
export class AppStateService implements OnInit {

    constructor(public store: Store<AppStore>,
                private router: Router) { }

    public getState(): AppStore {
        let state: AppStore;
        this.store.take(1).subscribe((s) => state = s);
        return state;
    }

    public ngOnInit() {}

    public setLocationURLs() {
        let currentURL = this.router.url;
        let currentStore = this.getState();
        let storeCurrentURL = (currentStore.user.currentUrl !== undefined) ?
            currentStore.user.currentUrl : '';
        if (currentStore.user.currentUrl !== currentURL) {
            this.store.dispatch({ type: 'PREVIOUS_URL', payload: storeCurrentURL });
            this.store.dispatch({ type: 'CURRENT_URL', payload: currentURL });
        }
    }

}
