import { BlueMarbleService } from './bm.service';
import { Injectable } from '@angular/core';

@Injectable()
export class PropertiesService {

    constructor(
        public bMService: BlueMarbleService) {
    }

    /**
     * Properteis API call from home page
     */
    public getProperties() {
        let properties = {
            system: 'ESHOP'
        };

        return this.bMService.properties(properties);
    }

}
