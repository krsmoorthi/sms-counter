import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {map, timeout, retry} from 'rxjs/operators';
import { AuthService } from './auth.service';
import { env } from '../../../environments/environment';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';

@Injectable()
export class BlueMarbleService {

    constructor(private http: HttpClient, 
        public authService: AuthService,
        private propertiesHelperService: PropertiesHelperService) { }

    /**
     * Properties API call
     */
    public properties(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        let response = this.http.post(env.BASE_URL_PROPERTIES, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PROPERTIES_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
        return response;
    }
    
    /**

    /**
     * INIT Address API call
     */
    public initAddress(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.INIT_ADDRESS_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * submitTask API for all requests
     */
    public submitTask(payload: any, flow?: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        if (flow === 'change') {
            return this.http.put(env.BASE_CHANGE_URL_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
                .pipe(
                    timeout(env.CHANGE_SERVICE_TIMEOUT),
                    retry(env.retryIteration),
                    map((res: any) => res)
                );
        } else if (flow === 'billing') {
            return this.http.put(env.BILLING_RECORDS_SUBMIT, JSON.stringify(payload), requestOptions)
                .pipe(
                    timeout(env.BILLING_RECORDS_TIMEOUT),
                    retry(env.retryIteration),
                    map((res: any) => res)
                );
        } else if (flow === 'move') {
            return this.http.put(env.MOVE_SUBMIT, JSON.stringify(payload), requestOptions)
                .pipe(
                    timeout(env.MOVE_SERVICE_TIMEOUT),
                    retry(env.retryIteration),
                    map((res: any) => res)
                );
        }
        else {
            return this.http.put(env.BASE_URL_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
                .pipe(
                    timeout(env.SUBMIT_TASK_TIMEOUT),
                    retry(env.retryIteration),
                    map((res: any) => res)
                )
        }
    }
    public cardEligibility(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestedOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.GIFTCARD_COMPATIBILITY, JSON.stringify(payload), requestedOptions)
            .pipe(
                timeout(env.GIFTCARD_COMPATIBILITY_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    public billingSubmitTask(payload: any, flag?) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.BILLING_RECORDS_SUBMIT, JSON.stringify(payload), requestOptions)
                .pipe(
                    timeout(env.BILLING_RECORDS_TIMEOUT),
                    retry(env.retryIteration),
                    map((res: any) => res)
                );
    }

    public moveSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.MOVE_SUBMIT, JSON.stringify(payload), requestOptions)
            .pipe(
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public initChangeCall(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_CHANGE_URL_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public changeSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.BASE_CHANGE_URL_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    public movePaymentSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.MOVE_SUBMIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getRemoveChange(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.REMOVE_CHANGE, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    
    public prepaidCancelOrderCode(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PREPAID_CANCEL_ORDER, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.LINK_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getCarrierInfo(url: string) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        let apiUrl = env.production ? env.CURRENT_ENVIRONMENT + env.SERVICECALL + url : env.CURRENT_ENVIRONMENT + env.SERVICECALL + env.BUILD_NAME + url;
        return this.http.get(apiUrl, requestOptions)
            .pipe(
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * GEOAM Address Service Call
     * Directly hits the API and return the response
     */
    public geoamServiceCall(item: any) {
        return this.http.get(env.BASE_URL_GEOAM + item)
            .pipe(map((res: any) => res));
    }

    /**
     * getOffers from Response link while click retrieve offers
     */
    public getOffersFromLink(link: string) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.get(env.DATA_LINK + link, requestOptions)
            .pipe(
                timeout(env.LINK_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public initSup1(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.SUP1_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.INIT_TASK_SUP1_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    public supRemarkUpdate(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PENDING_ORDER_REMARK_UPDATE_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PENDING_ORDER_REMARK_UPDATE_INIT_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    
    public initNonpaySupspend(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.NONPAY_SUSPEND_INIT, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }
    public submitNonpaySupspend(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.NONPAY_SUSPEND_SUBMIT, JSON.stringify(payload), requestOptions)
            .pipe(
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    public initDisconnect(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.DISCONNECT_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.DISCONNECT_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public submitTaskDisconnect(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.DISCONNECT_SUBMIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.DISCONNECT_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }


    /**
     * submitTask API for all requests
     */
    public submitTaskSup1(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.SUP1_SUBMIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.SUBMIT_TASK_SUP1_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public initSup2(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.SUP2_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.INIT_TASK_SUP2_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * submitTask API for all requests
     */
    public submitTaskSup2(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.SUP2_SUBMIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.SUBMIT_TASK_SUP2_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public pendingSummary(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PENDING_SUMMARY, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PENDING_SUMMARY_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getPaymentDetails(sessionId: string) {
        return this.http.get(env.PAYMENT_INFO + sessionId)
            .pipe(map((res: any) => res));
    }

    public getExistingDiscountsByBan(ban: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        ban = ban + '?eligibleDiscounts=active';
        return this.http.get(env.EXISTING_DISCOUNTS + ban, requestOptions)
            .pipe(map((res: any) => res));
    }

    public getBillQuoteDetails(quoteId: string) {
        let propertyBillQuoteWaitTime = this.propertiesHelperService.getPropertyValueAsNumber(PropertyEnums.BILL_QUOTE_WAIT_TIME,3000);
        this.sleep(propertyBillQuoteWaitTime);
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.get(env.BILL_QUOTE + quoteId, requestOptions)
            .pipe(
                timeout(env.BILL_QUOTE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * submitTask API for E911 addresss
     */
    public getE911API(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_E911, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.E911_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * GEOES Address Service Call
     * Directly hits the API and return the response
     */
    public geoesServiceCall(addressItem: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.get(env.GEOES_URL + addressItem, requestOptions)
            .pipe(map((res: any) => res));
    }

    /**
     * product Config Atomic Service
     * Directly hits the API and save dtv account id
     */
    public productConfigCall(req: any) {
        let jwtToken = this.authService.getJWTToken();

        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.PRODUCT_CONFIG_URL, JSON.stringify(req), requestOptions)
            .pipe(
                timeout(env.PRODUCT_CONFIG_URL_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public moveAddress(req: any) {
        let jwtToken = this.authService.getJWTToken();

        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.MOVE_INIT_URL, JSON.stringify(req), requestOptions)
            .pipe(
                timeout(env.MOVE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public billingRecAddress(req: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BILLING_RECORDS_INIT, JSON.stringify(req), requestOptions)
            .pipe(
                timeout(env.BILLING_RECORDS_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getAvailableTNs(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_AVAILABLE_TN, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.AVAILABLE_TN_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getAvailableNumber(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_AVAILABLE_NUMBER, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.AVAILABLE_NUMBER_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getPotsTnAvailability(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.CHECK_POTS_TN_AVAILABILITY, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.AVAILABLE_NUMBER_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getNPANXXList(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_NPA_NXX, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.URL_NPA_NXX_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public reserveTNCall(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_RESERVE_TN, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.RESERVE_TN_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public releaseTNCall(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_URL_RELEASE_TN, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.RELEASE_TN_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public doTnPortingCheck(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let url: any;
         url = env.BASE_URL_TN_PORTING;
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(url, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.RELEASE_TN_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getOrderProgressStatus(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.GET_ORDER_PROCESS_STATUS, JSON.stringify(payload), requestOptions)
            .pipe(
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getSecurityDepositHistory(ban: any) {
        let payload: any = "";
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.RETRIEVE_DEPOSIT_HISTORY + ban, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.ORDER_PROCESS_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * autoLogin API for all requests
     */
    public autoLogin(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.get(`${env.AUTO_LOGIN}` + payload, requestOptions)
            .pipe(
                timeout(env.AUTO_LOGIN_TIMEOUT), 
                retry(env.retryIteration), 
                map((res: any) => res)
            );
    }


    /**
     * For getting reasons for Holding orders
     */
    public getReasonsForHold(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.HOLD_REASONS, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.HOLD_ORDER_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * Remove Order from Hold
     */
    public removeOrderFromHold(payload: any, flow) {
        let url: string;
        if (flow === "CHANGE") {
            url = env.UNHOLD_CHANGE;
        }
        else if (flow === "MOVE") {
            url = env.UNHOLD_MOVE;
        } else if (flow === "DISCONNECT") {
            url = env.UNHOLD_DISCONNECT;
        } else if (flow === "BILLANDREC") {
            url = env.UNHOLD_BILLANDREC;
        } else {
            url = env.HOLD_ORDER;
        }
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(url, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.HOLD_ORDER_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );


    }


    /**
     * Submit order for Hold
     */
    public submitOrderHold(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.HOLD_ORDER, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.HOLD_ORDER_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getCompatibilityRulesforClosers(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.CLOSERS_PROMOSE_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            /* .timeout(HOLD_ORDER_TIMEOUT)
            .pipe(retry(retryIteration)) */
            .pipe(map((res: any) => res));
    }

    public getInternationalBillingCountryList(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(map((res: any) => res));
    }
    public getCarrierList(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(map((res: any) => res));
    }
    public getOfferDisplayName(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(map((res: any) => res));
    }

    public getSwitchByTN(request) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.SWITCH_COMPATIBILITY, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public getCompatibilityRules(togetOnholdDetails?: boolean) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        let payload;
        if (togetOnholdDetails && togetOnholdDetails !== undefined) {
            payload = {
                "inputAttribute": [
                    {
                        "attributeName": "ruleName",
                        "attributeValue": [
                            "customerOrderStatusDisplayText"
                        ]
                    }
                ],
                "outputAttribute": [
                    {
                        "attributeName": "ruleName"
                    },
                    {
                        "attributeName": "customerOrderStatus"
                    },
                    {
                        "attributeName": "orderDate"
                    },
                    {
                        "attributeName": "displayValue"
                    }
                ],
                "requestDate": " ",
                "ruleId": "61"
            }
        } else {
            payload = {
                "inputAttribute": [
                    {
                        "attributeName": "salesChannel",
                        "attributeValue": [
                            "ESHOP-Customer Care"
                        ]
                    }
                ],
                "outputAttribute": [
                    {
                        "attributeName": "salesChannel"
                    },
                    {
                        "attributeName": "compatibilityRuleType"
                    },
                    {
                        "attributeName": "OfferCategory_A"
                    },
                    {
                        "attributeName": "productId_A"
                    },
                    {
                        "attributeName": "productName_A"
                    },
                    {
                        "attributeName": "attributeName_A"
                    },
                    {
                        "attributeName": "attributeValue_A"
                    },
                    {
                        "attributeName": "compatibilityType"
                    },
                    {
                        "attributeName": "OfferCategory_B"
                    },
                    {
                        "attributeName": "productId_B"
                    },
                    {
                        "attributeName": "productName_B"
                    },
                    {
                        "attributeName": "selectGroup"
                    },
                    {
                        "attributeName": "selectOrder"
                    },
                    {
                        "attributeName": "grpMinSelect"
                    },
                    {
                        "attributeName": "grpMaxSelect"
                    },
                    {
                        "attributeName": "ruleText"
                    }
                ],
                "requestDate": null,
                "ruleId": "21"
            }
        }
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PRODUCT_COMPATIBILITY_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getCSCompatibilityRules() {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        let payload = {
            "inputAttribute": [
              {
                "attributeName": "accountType",
                "attributeValue": [
                  "Purchase"
                ]
              },
              {
                "attributeName": "cyberSecurity",
                "attributeValue": [
                  "Disabled"
                ]
              },
              {
                "attributeName": "attributeDisplayNAme",
                "attributeValue": [
                  "Purchase Modem"
                ]
              }
            ],
            "outputAttribute": [
              {
                "attributeName": "accountType"
              },
              {
                "attributeName": "cyberSecurity"
              },
              {
                "attributeName": "attributeDisplayNAme"
              },
              {
                "attributeName": "cyberSecurityDisplay"
              }
            ],
            "requestDate": null,
            "ruleId": "177"
        }
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PRODUCT_COMPATIBILITY_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getCommunityRules() {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        let payload = {
            "inputAttribute": [
                {
                    "attributeName": "dataType",
                    "attributeValue": [
                        "STREET_DIRECTION",
                        "STREET_SUFFIX",
                        "STATE_COMMUNITY"
                    ]
                }
            ],
            "outputAttribute": [
                {
                    "attributeName": "dataType"
                },
                {
                    "attributeName": "streetDirAbbr"
                },
                {
                    "attributeName": "streetDir"
                },
                {
                    "attributeName": "streetSfxAbbr"
                },
                {
                    "attributeName": "streetSfx"
                },
                {
                    "attributeName": "stateAbbr"
                },
                {
                    "attributeName": "communityName"
                }

            ],
            "requestDate": "string",
            "ruleId": "24"
        }
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PRODUCT_COMPATIBILITY_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /**
     * appointment override function service call US248579
     */
    public overrideApptCall(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        let req = JSON.parse(JSON.stringify(request));
        if (req.startDateTime) {
            req.startDateTime = req.startDateTime.substring(0, 10) + 'T00:00:00.000Z';
        }
        return this.http.post(env.OVERRIDE_APPT, JSON.stringify(req), requestOptions)
            .pipe(map((res: any) => res));
    }
    public RetrieveARNApptCall(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.RETRIEVE_ARN, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));

    }
    public getLATA(request) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(request), requestOptions)
            .pipe(
                timeout(env.PRODUCT_COMPATIBILITY_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public sleep(milliseconds) {
        var start = new Date().getTime();
        for (var i = 0; i < 1e7; i++) {
            if ((new Date().getTime() - start) > milliseconds) {
                break;
            }
        }
    }

    public getHolidaysDate(request: any): any {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.GET_HOLIDAYS_LIST, JSON.stringify(request), requestOptions)
            .pipe(
                timeout(env.PRODUCT_COMPATIBILITY_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getVendorLocations(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.DTV_INIT, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public captureDtvRequest(request) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.CAPTURE_DTV_REQUEST, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public orderDtvProcess(request) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.ORDER_DTV_PROCESS, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public enterDTVManually(request) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.ORDER_DTV_PROCESS, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public retrieveDtvOrder(request) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.RETRIEVE_DTV_ORDER, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public supHoldInit(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.SUP2_INIT, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public supHoldSubmit(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.SUP2_SUBMIT, JSON.stringify(request), requestOptions)
            .pipe(map((res: any) => res));
    }

    public initVacationCall(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.BASE_VACATION_URL_INIT, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public scheduleVacationCall(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.VAC_SUSPEND_SCHEDULING_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public vacationSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.BASE_VACATION_URL_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public vacationSchedulingSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.BASE_VACATION_URL_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public vacationAccountSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.BASE_VACATION_URL_SUBMIT_TASK, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public retrieveRcc(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.RETRIEVE_RCC_URL, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getRccDisclosure(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.GET_RCC_DISCLOSURE_URL, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.CHANGE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getFreezeDropDown(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PRODUCT_COMPATIBILITY, JSON.stringify(payload), requestOptions)
            .pipe(map((res: any) => res));
    }

    public getProfile(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.PROFILE_SERVICE, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.PROFILE_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public getTechnologyTypes() {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.get(env.GET_TECHNOLOGY_TYPES, requestOptions)
            .pipe(
                timeout(env.LINK_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public retrieveProductDealerCodeInfo(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.RETRIEVE_DEALER_CODE, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.LINK_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public validateDealerCode(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.VALIDATE_DEALER_CODE, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.LINK_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    public validateStackAmend(request: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.VALIDATE_DEALER_CODE, JSON.stringify(request), requestOptions)
            .pipe(
                timeout(env.SUBMIT_TASK_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }
    public getBypassGiftCards(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.RETRIEVE_GIFTCARDS, JSON.stringify(payload), requestOptions)
            /* .timeout(HOLD_ORDER_TIMEOUT)
            .pipe(retry(retryIteration)) */
            .pipe(map((res: any) => res));
    }

    public getBypassInternetDiscounts(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(`${env.RETRIEVE_INTERNET_DISCOUNTS}`, JSON.stringify(payload), requestOptions)
            /* .timeout(HOLD_ORDER_TIMEOUT)
            .retry(retryIteration) */
            .pipe(map((res: any) => res));
    }

    public quickConnectData(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptionsBaseAuth("", jwtToken);
        return this.http.post(env.QUICK_CONNECT, JSON.stringify(payload), requestOptions)
            .pipe(map((res: any) => res));
    }

    /* 
    * Change Of Responsibility INIT Call Function
    */
    public initCORespCall(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.post(env.COR_INIT_URL, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.COR_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

    /* 
    * Change Of Responsibility Submit Call Function
    */
    public CORSubmitTask(payload: any) {
        let jwtToken = this.authService.getJWTToken();
        let requestOptions = this.authService.setRequestOptions('', jwtToken);
        return this.http.put(env.COR_SUBMIT_URL, JSON.stringify(payload), requestOptions)
            .pipe(
                timeout(env.COR_SERVICE_TIMEOUT),
                retry(env.retryIteration),
                map((res: any) => res)
            );
    }

}
