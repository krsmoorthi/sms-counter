/* tslint:disable */
import { Injectable, OnInit } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { User } from '../models/user.model';
import { ShoppingCart } from '../models/cart.model';
import { AppStateService } from './app-state.service';
const CryptoJS = require("crypto-js");
const base64 = require("crypto-js/enc-base64");
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Rx';

/**
 * Authentication Service for Storing the current auth token
*/
@Injectable()
export class AuthService implements OnInit {
    private fingerPrint: string;
    private userSubscription: Subscription;
    public user: Observable<User>;
    shoppingCartId: string;
    userToken: string;
    currentStore: AppStore;
    public static LOGIN_ERROR_CODE: string = "202";
    public static LOGIN_ERROR_MESSAGE: string = "INVALID USER";

    constructor(
        public store: Store<AppStore>,
        public appStateService: AppStateService
    ) {
        this.currentStore = this.appStateService.getState();
        if (this.currentStore.user.token !== undefined) {
            this.userToken = this.currentStore.user.token;
        }

        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe(
            (data) => {
                this.fingerPrint = data.fingerPrint;
            }
        );
    }

    ngOnInit() { }

    public clearTokens() {
        this.updateUserToken('');
        this.updateJWTToken('');
    }

    public init() {
        let user: User = {
            id: 1,
            paymentDone: false,
            freezePage: false,
            oTCustomize: false,
            reEntrant: false
        }
        this.store.dispatch({ type: 'UPDATE_USER', payload: user });
        let cart: ShoppingCart = {
            serviceCategoryBasedOffers: []
        }
        this.store.dispatch({ type: 'CREATE_CART', payload: cart });
    }

    public getFingerPrint() {
        let uuid = this.generateUUID();
        let self = this;
        self.store.dispatch({ type: 'ADD_FINGERPRINT', payload: { fingerPrint: uuid } });
    }

    /**
     * Update User state with the User API token
     */
    public updateUserToken(tokenValue: string) {
        this.store.dispatch({ type: 'ADD_USER_TOKEN', payload: { token: tokenValue } });
    }

    /**
     * Update User state with the JWT API token
     */
    public updateJWTToken(tokenValue: string) {
        this.store.dispatch({ type: 'ADD_JWT_TOKEN', payload: { jwtToken: tokenValue } });
    }

    /**
     * Get JWT Token
     * Check if JWT exists and is valid return the token
     * If not fetch new JWT token and return an observable for the same
     */
    public getJWTToken(force?: boolean): any {
        let jwtTok = 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhcGljbGllbnRAY3RsLmNvbSIsImlzcyI6IkN0bCIsImlhdCI6MTQ3OTgxNTA5MSwiZXhwIjoxNzkwODU1MDkxfQ.kc-P35bWdS_7qWslOXs7mtcW3CcSZ8fU2jTDtc6uRUiBMhWr1U_3cG3Yoew9nYjgGkvcaRHMl_QHDiEarIrHdA';

        if (force !== undefined && force) {
            this.updateJWTToken(jwtTok);
            return jwtTok;
        }
        if (this.currentStore.user.jwtToken !== undefined &&
            this.currentStore.user.jwtToken !== '') {
            return this.currentStore.user.jwtToken;
        } else {
            this.updateJWTToken(jwtTok);
            return jwtTok;
        }
    }

    public setRequestOptions(authToken:
        string, jwtTok?:
            string) {
        // create authorization header with jwt token
        let authTokenStatic = 'ZXNob3BhcHA6aHlGWDhzRHRZTWtjYnNXWkN1Q1hiMjRT';
        if (jwtTok) {
            let headers =
                new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Accept': '*/*',
                    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                    'Access-Control-Allow-Headers': 'X-Custom-Header',
                    'Access-Control-Allow-Origin': '*',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-B3-TraceID': this.fingerPrint
                });

            if (authToken &&
                authToken !== "") {
                headers = new HttpHeaders({
                        'Authorization': 'Basic ' + jwtTok,
                        'Content-Type': 'application/json',
                        'authToken': authToken,
                        'X-B3-TraceID': this.fingerPrint

                    });
            } else {
                headers = new HttpHeaders({
                        'Authorization': 'Basic ' + authTokenStatic,
                        'Content-Type': 'application/json',
                        'authToken': jwtTok,
                        'X-B3-TraceID': this.fingerPrint

                    });
            }
            
                var epochTime = new Date().getTime().toString();
                var hmac = CryptoJS.HmacSHA256(epochTime, "AKI1443262019032820211378679142", { asBytes: true });
                var base64String = base64.stringify(hmac);
                var appToken = "APPKEY596132019032820211378667325";
                headers = new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Accept': '*/*',
                        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                        'Access-Control-Allow-Headers': 'X-Custom-Header',
                        'Access-Control-Allow-Origin': '*',
                        'X-Requested-With': 'XMLHttpRequest',
                        "X-Digest": base64String,
                        "X-Digest-Time": epochTime,
                        "X-Application-Key": appToken,
                        'X-B3-TraceID': this.fingerPrint
                    });

            return { headers }
        } else {
            let headers =
                new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Accept': '*/*',
                    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                    'Access-Control-Allow-Headers': 'X-Custom-Header',
                    'Access-Control-Allow-Origin': '*',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-B3-TraceID': this.fingerPrint
                });
            return { headers }
        }

    }

    public setRequestOptionsBaseAuth(authToken:
        string, jwtTok:
            string) {
        // create authorization header with jwt token
        let authTokenStatic = 'ZXNob3BhcHA6aHlGWDhzRHRZTWtjYnNXWkN1Q1hiMjRT';
        if (jwtTok) {
            let headers =
                new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Accept': '*/*',
                    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                    'Access-Control-Allow-Headers': 'X-Custom-Header',
                    'Access-Control-Allow-Origin': '*',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-B3-TraceID': this.fingerPrint
                });

            if (authToken &&
                authToken !== "") {
                headers = new HttpHeaders({
                        'Authorization': 'Basic ' + jwtTok,
                        'Content-Type': 'application/json',
                        'authToken': authToken,
                        'X-B3-TraceID': this.fingerPrint
                    });
            } else {
                headers = new HttpHeaders({
                        'Authorization': 'Basic ' + authTokenStatic,
                        'Content-Type': 'application/json',
                        'authToken': jwtTok,
                        'X-B3-TraceID': this.fingerPrint
                    });
            }

            let user = 'eshopapp'; // BMPAPP
            let password = 'hyFX8sDtYMkcbsWZCuCXb24S'; // FM59wYtos4WceVHT2nLaxRQh
            headers = new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Accept': '*/*',
                    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                    'Access-Control-Allow-Headers': 'X-Custom-Header',
                    'Access-Control-Allow-Origin': '*',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Authorization': 'Basic ' + btoa(user + ":" + password),
                    'X-B3-TraceID': this.fingerPrint
                });

            return { headers }
        }

    }

    public setRequestOptionsGeoes(authToken: string, jwtTok: string) {
        // create authorization header with jwt token
        let authTokenStatic = 'ZXNob3BhcHA6aHlGWDhzRHRZTWtjYnNXWkN1Q1hiMjRT';

        if (jwtTok) {
            let headers = new HttpHeaders({
                'Content-Type': 'application/json', 'Accept': '*/*', 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                'Access-Control-Allow-Headers': 'X-Custom-Header',
                'Access-Control-Allow-Origin': '*', 'X-Requested-With': 'XMLHttpRequest',
                'X-B3-TraceID': this.fingerPrint
            });
            if (authToken && authToken !== "") {
                headers = new HttpHeaders({
                    'Authorization': 'Basic ' + jwtTok, 'Content-Type': 'application/json',
                    'authToken': authToken,
                    'X-B3-TraceID': this.fingerPrint
                });
            } else {
                headers = new HttpHeaders({
                    'Authorization': 'Basic ' + authTokenStatic, 'Content-Type': 'application/json',
                    'authToken': jwtTok,
                    'X-B3-TraceID': this.fingerPrint
                });
            }
            return { headers };
        }
    }

    private generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    };

}