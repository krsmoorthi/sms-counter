import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { catchError, map } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { env } from '../../../environments/environment';

@Injectable()
export class ORNInterceptorService implements HttpInterceptor {
    
    constructor(private store: Store<AppStore>) {

    }

    intercept(request: HttpRequest<any>, next: HttpHandler) : Observable<HttpEvent<any>>{
        let authReq = request.clone();
        if( request.url.indexOf("apigeeCall")>-1 && !env.production ){
            if( request && request.body){
                let body =JSON.parse(request.body);
            if(body && (body.orderRefNumber || (body.customerOrderType && body.customerOrderType === "NEWINSTALL"))) {
            let user = <any>this.store.select('user');
            let userSubscription = user.subscribe((data) => {
               if( data &&  data.logicalSystemDate)
               {
                body.logicalDate= data.logicalSystemDate;
               }
           });
            authReq = request.clone({body: body});
            }
            }
            
        } 
        return next.handle(authReq).pipe(
            
            catchError((error: HttpErrorResponse) => {
                if(error && error.error && error.error.errorResponse && (error.error.errorResponse.length > 0)) {
                    if(error.error.errorResponse[0].orderRefNumber) {
                        this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: error.error.errorResponse[0].orderRefNumber });
                    }
                }
                return throwError(error);
            }),

            map((event: HttpEvent<any>) => {
                if(event instanceof HttpResponse) {
                    if(event.body && event.body.orderRefNumber) {
                        this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: event.body.orderRefNumber });
                    }
                    if(event.body && event.body.orderReference && event.body.orderReference.orderReferenceNumber) {
                        this.store.dispatch({ type: 'ADD_ORDER_REF_NO', payload: event.body.orderReference.orderReferenceNumber });
                    }
                }
                return event;
            })

        );
    }
}