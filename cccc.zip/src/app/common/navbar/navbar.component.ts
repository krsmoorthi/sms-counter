import { HelperService } from '../../common/service/helper.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user.model';
import { AppStore } from '../models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { FirstCustomizePipe } from '../pipes/firstcapcustom.pipe';
import { SecurityElement } from '../models/profile.model';
import { ProfileEnums } from 'app/common/enums/profileEnums';

@Component({
    selector: 'ctl-nav-bar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css']
})
export class NavBarComponent implements OnInit, OnDestroy {
    public orderType: any;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public isAddrPage: boolean = true;
    public addressLine1: string = '';
    public addressLine2: string = '';
    public currUrl: string;
    public prevUrl: string;
    public schedulingUrl: string;
    public isretentionOfferAllowed: boolean = false;
    public iconsObj = { prodUrl: '', schUrl: '', accUrl: '', revUrl: '' };
    public productUrl: string;
    public accountUrl: string;
    public existingData: any;
    public existingServiceAddress: any;
    public orderFlow: string;
    public isdisplayORN: boolean = false;
    public ornNumber: any;
    public onlyHSISuspended: boolean = false;
    public legacy: string = '';
    public singleLine: boolean = false;
    public profileId: string;
    public securityElements: SecurityElement[];
    public cuid: string;
    public ensembleId: string;
    public vacationObservable: Observable<any>;
    public vacationSubscription: Subscription;
    public reentrant: any;
    public vacationsuspend: any;
    public vacationrestore: any;
    public poReview: any;
    public stackflow: any;
    public pendingSummaryObservable: Observable<any>;
    public pendingSummarySubscription: Subscription;
    public stackpending: boolean;
    public isPrepaid: boolean;
    public isAmend: boolean;
    public appointment: Observable<any>;
    public schedulingURL1: string;
    private existsServices: string[] = [];
    public traceId: any = "";

    constructor(private router: Router,
        public store: Store<AppStore>,
        public helperService: HelperService) {
        this.user = <Observable<User>>store.select('user');
        this.appointment = this.store.select('appointment');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointment.subscribe((data) => {
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    if (data.payload.cart || !data.payload.appointmentInfo) {
                        this.schedulingURL1 = '/schedule-appt-ship';
                    } else {
                        this.schedulingURL1 = '/schedule-appt';
                    }
                }
            });
        }
        this.userSubscription = this.user.subscribe((data) => {
            let usr: any = data;
            if (data.previousUrl === '/pending-order' && data.currentUrl === '/po-review-order') {
                this.poReview = true;
            }
            if (data && data.prepaidFlag && data.prepaidFlag === "true") {
                this.isPrepaid = true;
            }
            this.isretentionOfferAllowed = this.helperService.isAuthorized(ProfileEnums.ALLOW_RETENTION_OFFERS);
            // Populate Profile Data
            if (data && data.profile) {
                if (data && data.fingerPrint && data.fingerPrint !== null && data.fingerPrint !== undefined) {
                    this.traceId = data.fingerPrint;
                }
                if (data && data.profile) {
                    this.profileId = data.profile.profileId;
                    if (data.profile.securityElements && data.profile.securityElements.length > 0) {
                        this.securityElements = data.profile.securityElements;
                    }
                }
                if (data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.agentCuid) {
                    this.cuid = data.autoLogin.oamData.agentCuid;
                }
                if (data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.ensembleId) {
                    this.ensembleId = data.autoLogin.oamData.ensembleId;
                } if (data.orderRefNumber !== undefined && data.orderRefNumber !== '') {
                    this.isdisplayORN = true;
                    this.ornNumber = data.orderRefNumber;
                }
            }
            if (this.orderFlow !== "Change" && this.orderFlow !== "Move") {
                if (usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.serviceAddress &&
                    usr.orderInit.payload.serviceAddress.locationAttributes
                    && usr.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
                    this.legacy = usr.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
                    let filter = new FirstCustomizePipe();
                    this.legacy = filter.transform(this.legacy);
                }
            } else if (this.orderFlow === "Move" && this.legacy === '') {
                if (usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.newLocation && usr.orderInit.payload.newLocation.serviceAddress &&
                    usr.orderInit.payload.newLocation.serviceAddress.locationAttributes
                    && usr.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider) {
                    this.legacy = usr.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider;
                    let filter = new FirstCustomizePipe();
                    this.legacy = filter.transform(this.legacy);
                }
            }
            this.currUrl = data.currentUrl;
            this.prevUrl = data.previousUrl;
            if (this.currUrl === '/home' || this.currUrl === '/') {
                this.isdisplayORN = false;
            }
            if (this.currUrl === '/home' || this.currUrl === '/' || (this.currUrl !== undefined && this.currUrl.indexOf('auto-login') > -1)
                || this.currUrl === '/multipleMatchAddress' || this.currUrl === '/order-confirmation' || this.currUrl === '/disconnect-confirmation' || this.currUrl === '/po-order-confirmation' || this.currUrl === '/order-cancelled' || this.currUrl === '/system-error') {
                this.isAddrPage = true;

            } else {
                this.isAddrPage = false;
            }
            let addr = data.finalAddress;
            if (addr) {
                this.singleLine = addr.singleLine;
                if (addr.addressLine) {
                    let addressChanges = false;
                    this.addressLine1 = addr.addressLine;
                    this.addressLine2 = '';
                    if (addr.unitNumber && !(this.addressLine1.indexOf('UNIT') > -1)) {
                        this.addressLine1 = this.addressLine1 + ', ' + addr.unitNumber;
                        addressChanges = true;
                    }
                    if (addr.subAddress && addr.subAddress !== undefined && addr.subAddress.combinedDesignator !== undefined) {
                        this.addressLine1 = this.addressLine1 + ', ' + addr.subAddress.combinedDesignator;
                        addressChanges = true;
                    }

                    if (addr.city) {
                        this.addressLine2 = addr.city ? addr.city : addr.locality;
                        addressChanges = true;
                    }

                    if (addr.stateOrProvince) {
                        this.addressLine2 = this.addressLine2 + ', ' + addr.stateOrProvince;
                        addressChanges = true;
                    }

                    if (addr.postCode) {
                        this.addressLine2 = this.addressLine2 + ', ' + addr.postCode;
                        addressChanges = true;
                    }

                    if (!addressChanges) {
                        this.addressLine1 = this.addressLine1.replace(',USA', '');
                        this.addressLine1 = this.addressLine1.replace(new RegExp(',', 'g'), ', ');
                    }
                } else if (addr.streetAddress) {
                    this.addressLine1 = addr.streetAddress;
                    this.addressLine2 = '';
                    if (addr.unitNumber && !(this.addressLine1.indexOf('UNIT') > -1)) {
                        this.addressLine1 = this.addressLine1 + ', ' + addr.unitNumber;
                    }
                    if (addr.subAddress.combinedDesignator) {
                        this.addressLine1 = this.addressLine1 + ', ' + addr.subAddress.combinedDesignator;
                    }

                    if (addr.city) {
                        this.addressLine2 = addr.city ? addr.city : addr.locality;
                    }

                    if (addr.stateOrProvince) {
                        this.addressLine2 = this.addressLine2 + ', ' + addr.stateOrProvince;
                    }

                    if (addr.postCode) {
                        this.addressLine2 = this.addressLine2 + ', ' + addr.postCode;
                    }

                } else if (addr.streetNrFirst) {
                    this.addressLine1 = addr.streetNrFirst;
                    if (addr.streetName) {
                        this.addressLine1 = this.addressLine1 + ' ' + addr.streetName;
                    }

                    if (addr.city) {
                        this.addressLine2 = addr.city ? addr.city : addr.locality;
                    }

                    if (addr.stateOrProvince) {
                        this.addressLine2 = this.addressLine2 + ', ' + addr.stateOrProvince;
                    }

                    if (addr.postCode) {
                        this.addressLine2 = this.addressLine2 + ', ' + addr.postCode;
                    }
                }

            }
            switch (data.currentUrl) {
                case '/product-offer':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'product-offer';
                    break;
                case '/customize-services':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    break;
                case '/offer-change':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'offer-change';
                    break;
                case '/existing-products':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'existing-products';
                    break;
                case '/billing-product':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'billing-product';
                    break;
                case '/pending-order':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'pending-order';
                    break;
                case '/schedule-appt':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = this.schedulingURL1; // 'schedule-appt';
                    break;
                case '/billing-schedule-appt-ship':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = 'billing-schedule-appt-ship';
                    break;
                case '/schedule-non-appt':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = 'schedule-non-appt';
                    break;
                case '/schedule-appt-ship':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = this.schedulingURL1; // 'schedule-appt-ship';
                    if (this.isAmend) {
                        this.productUrl = 'stack-amend-product';
                    }
                    break;
                case '/pending-schedule-appt':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = 'pending-schedule-appt';
                    break;
                case '/disconnect-schedule':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = 'disconnect-schedule';
                    break;
                case '/vacation-schedule-appt-ship':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = 'vacation-schedule-appt-ship';
                    break;
                case '/po-review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIconcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    break;
                case '/billing-review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    break;
                case '/co-review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIconcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    if (this.isAmend && this.isPrepaid) {
                        this.schedulingUrl = 'schedule-appt-ship';
                        this.productUrl = 'stack-amend-product';
                        this.accountUrl = 'amend-account';
                    }
                    break;
                case '/account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'account';
                    if (this.orderFlow === "COR" && this.prevUrl === '/change-responsibility') {
                        this.productUrl = 'change-responsibility';
                    } else if (this.orderFlow === "COR" && (this.prevUrl === '/existing-products' || this.prevUrl === '/account' || this.prevUrl === '/schedule-appt-ship')) {
                        this.productUrl = 'existing-products';
                    } else {
                        this.productUrl = 'product-offer';
                    }
                    break;
                case '/reuse-ban-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'reuse-ban-account';
                    this.productUrl = 'product-offer';
                    break;
                case '/amend-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'amend-account';
                    this.productUrl = 'stack-amend-product';
                    this.schedulingUrl = 'schedule-appt-ship';
                    break;
                case '/disconnect-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'disconnect-account';
                    break;
                case '/vacation-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'disconnect-account';
                    break;
                case '/review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIconcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    break;
                case '/disconnect-review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIconcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    break;
                case '/vacation-review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIconcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    break;
                case '/move-product':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'move-product';
                    break;
                case '/move-schedule-appt-ship':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnav.png';
                    this.schedulingUrl = 'move-schedule-appt-ship';
                    break;
                case '/move-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'move-account';
                    break;
                case '/directv-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    this.accountUrl = 'directv-account';
                    break;
                case '/mo-review-order':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIconcheck.png';
                    this.iconsObj.revUrl = './assets/img/revieworder.png';
                    break;
                case '/change-account':
                    this.iconsObj.prodUrl = './assets/img/product_shopcheck.png';
                    this.iconsObj.schUrl = './assets/img/calendarnavcheck.png';
                    this.iconsObj.accUrl = './assets/img/AccountIcon.png';
                    break;
                case '/change-responsibility':
                    this.iconsObj.prodUrl = './assets/img/product_shop.png';
                    this.productUrl = 'change-responsibility';
                    break;
                default: break;
            }
        });

        this.existingObservable = <Observable<any>>store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            this.existingData = data;
            if (data.orderFlow && data.orderFlow.flow) {
                this.orderFlow = data.orderFlow.flow;
                this.orderType = data.orderFlow.type;
                this.stackflow = data && data.stackamend && data.stackamend.stackAmendFlag;
                if (data.existingProductsAndServices) {
                    this.existingServiceAddress = data.existingProductsAndServices[0].serviceAddress;
                } else if (data.pendingAddress) {
                    this.existingServiceAddress = data.pendingAddress
                }
            }
            if (data && data.stackamend && data.stackamend.stackAmendFlag === 'amendOrder') {
                this.isAmend = true;
            }
            if ((this.orderFlow === "Change" || this.orderFlow === "COR" || this.orderFlow === "billing") && this.legacy === '') {
                this.legacy = this.existingData.existingProductsAndServices &&
                    this.existingData.existingProductsAndServices[0].serviceAddress &&
                    this.existingData.existingProductsAndServices[0].serviceAddress.locationAttributes &&
                    this.existingData.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
                let filter = new FirstCustomizePipe();
                this.legacy = filter.transform(this.legacy);
            }
        });
    }

    public ngOnInit() {
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            this.reentrant = data.reentrantoption;
            if (data && data !== undefined && data.vacFlowName && data.vacFlowName !== undefined && data.vacFlowName.isVacSusFlow && data.vacFlowName.isVacSusFlow !== undefined) {
                this.vacationsuspend = data.vacFlowName.isVacSusFlow;
            }
            if (data && data !== undefined && data.vacFlowName && data.vacFlowName !== undefined && data.vacFlowName.isVacResFlow && data.vacFlowName.isVacResFlow !== undefined) {
                this.vacationrestore = data.vacFlowName.isVacResFlow;
            }
            if (data && data.selectedVacationData && data.selectedVacationData.length > 1 && data.selectedVacationData[1].toUpperCase() === "INTERNET VACATION SUSPEND" && data.selectedVacationData[0].toUpperCase() === "VOICE-HP NOT ADDED (ACTIVE)") {
                this.onlyHSISuspended = true;
            }
            if (data && data.existsProducts) {
                this.existsServices = data.existsProducts;
            }
        });
        this.pendingSummaryObservable = <Observable<any>>this.store.select('pending');
        this.pendingSummarySubscription = this.pendingSummaryObservable.subscribe((pendingData) => {
            if (pendingData && pendingData.orderReference && pendingData.orderReference.customerOrderStatus && pendingData.orderReference.customerOrderStatus === 'PENDING') {
                this.stackpending = true;
            }
        });
    }

    public gotoAddress() {
        this.router.navigate(['/home']);
    }

    public displayPreviousScreen() {
        switch (this.currUrl) {
            case '/product-offer': this.router.navigate(['/home']);
                break;
            case '/existing-products': this.router.navigate(['/home']);
                break;
            case '/customize-services': this.router.navigate(['/' + this.productUrl]);
                if (this.vacationrestore) {
                    this.router.navigate(['/vacation-product-offer']);
                }
                if (this.vacationsuspend && this.isretentionOfferAllowed && this.onlyHSISuspended) {
                    this.router.navigate(['/existing-products']);
                }
                if (this.vacationsuspend && this.isretentionOfferAllowed && !this.onlyHSISuspended && (this.existsServices.indexOf('VOICE-HP') > -1) && !this.helperService.isLCAddress()) {
                    this.router.navigate(['/vacation-option']);
                }
                if (this.orderFlow === "Change" && this.stackflow) {
                    this.router.navigate(['/stack-amend-product']);
                }
                break;
            case '/stack-amend-product':
                if (this.stackpending) {
                    this.router.navigate(['/pending-order']);
                }
                break;
            case '/offer-change': this.router.navigate(['/existing-products']);
                break;
            case '/move-product': this.router.navigate(['/existing-products']);
                break;
            case '/billing-product':
                if (this.orderType === "pending" && this.orderFlow === "billing") {
                    this.router.navigate(['/pending-order']);
                } else {
                    this.router.navigate(['/existing-products']);
                }

                break;
            case '/schedule-non-appt':
                this.router.navigate(['/customize-services']);
                break;
            case '/schedule-appt':
                if (this.prevUrl === '/order-unhold') {
                    break;
                }
                this.router.navigate(['/customize-services']);
                break;
            case '/schedule-appt-ship':
                if (this.orderFlow === "COR" && this.prevUrl === '/change-responsibility') {
                    this.router.navigate(['/change-responsibility']);
                } else if (this.orderFlow === "COR" && (this.prevUrl === '/existing-products' || this.prevUrl === '/account')) {
                    this.router.navigate(['/existing-products']);
                } else {
                    this.router.navigate(['/customize-services']);
                }
                break;
            case '/billing-schedule-appt-ship':
                this.router.navigate(['/customize-services']);
                break;
            case '/pending-order':
                this.router.navigate([this.prevUrl]);
                break;
            case '/pending-schedule-appt':
                this.router.navigate(['/pending-order']);
                break;
            case '/po-review-order':
                if (this.poReview) {
                    this.router.navigate(['/pending-order']);
                } else {
                    this.router.navigate(['/pending-schedule-appt']);
                }
                break;
            case '/billing-review-order':
                this.router.navigate(['billing-schedule-appt-ship']);
                break;
            case '/po-order-confirmation':
                this.router.navigate(['/po-review-order']);
                break;
            case '/account': this.router.navigate(['/' + this.schedulingUrl]);
                break;
            case '/review-order': this.router.navigate(['/' + this.accountUrl]);
                break;
            case '/disconnect-schedule':
                this.router.navigate(['/existing-products']);
                break;
            case '/disconnect-account':
                this.router.navigate(['/' + this.schedulingUrl]);
                break;
            case '/disconnect-review-order':
                if (this.prevUrl === '/disconnect-schedule') {
                    this.router.navigate(['/' + this.prevUrl]);
                } else {
                    this.router.navigate(['/disconnect-account']);
                }
                break;
            case '/vacation-review-order': this.router.navigate(['/vacation-account']);
                break;
            case '/co-review-order':
                if (this.prevUrl === '/change-account') {
                    this.router.navigate(['/change-account']);
                    break;
                } else if (this.prevUrl === '/account') {
                    this.router.navigate(['/account'])
                    break;
                } else if (this.prevUrl === '/amend-account') {
                    this.router.navigate(['/amend-account'])
                    break;
                } else {
                    this.router.navigate(['/' + this.schedulingUrl]);
                    break;
                }
            case '/move-schedule-appt-ship':
                this.router.navigate(['/customize-services']);
                break;
            case '/amend-account': this.router.navigate(['/' + this.schedulingUrl]);
                break;
            case '/directv-account':
                this.router.navigate(['/' + this.schedulingUrl]);
                break;
            case '/change-account':
                this.router.navigate(['/' + this.schedulingUrl]);
                break;
            case '/move-account':
                if (this.prevUrl === "/directv-account") {
                    this.router.navigate(['/directv-account']);
                } else {
                    this.router.navigate(['/move-schedule-appt-ship']);
                }
                break;
            case '/mo-review-order':
                this.router.navigate(['/move-account']);
                break;
            case '/vacation-schedule-appt-ship':
                if (this.vacationsuspend && this.isretentionOfferAllowed) {
                    this.router.navigate(['/customize-services']);
                }
                if (this.vacationrestore) {
                    this.router.navigate(['/customize-services']);
                }
                break;
            case '/vacation-account':
                this.router.navigate(['/vacation-schedule-appt-ship']);
                break;
            case '/vacation-option':
                this.router.navigate(['/existing-products']);
                break;
            case '/nonpay-suspend':
                this.router.navigate(['/existing-products']);
                break;
            case '/vacation-product-offer':
                this.router.navigate(['/existing-products']);
                break;
            case '/reuse-ban-account': this.router.navigate(['/' + this.schedulingUrl]);
                break;
            case '/change-responsibility': this.router.navigate(['/existing-products']);
                break;
            default: break;
        }

    }
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
    }
}