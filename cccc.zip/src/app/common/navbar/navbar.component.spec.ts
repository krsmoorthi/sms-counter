import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NavBarComponent } from './navbar.component';
import { Observable } from 'rxjs/observable';
import { MockServer } from 'app/MockServer.test';
import { Logger } from '../logging/default-log.service';
import { MockLogger, MockHelperService, MockAppStateService, MockAccountService, MockRouter } from '../service/mockServices.test';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import "rxjs/add/observable/of";
import { HelperService } from '../service/helper.service';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from 'app/shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppStateService } from '../service/app-state.service';
import { AccountService } from '../service/account.service';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { CartSummaryComponent } from '../cart/cart.component';


describe('NavBarComponent', () => {
  let component: NavBarComponent;
  let fixture: ComponentFixture<NavBarComponent>;

  const mockServer = new MockServer();
  
  const mockRedux: any = {
      dispatch(obj) {return obj},
      configureStore() {},
      select(reducer) {
          return Observable.of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
      }
  };

  const imports = [
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    SharedModule,
    SharedCommonModule,
    RouterTestingModule,
  ];

  const logger = { provide: Logger, useClass: MockLogger}
  const router = { provide: Router, useClass: MockRouter };
  const store = { provide: Store, useValue: mockRedux };
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  
  
  const providers = [
      logger, router, store, helperService,appStateService,accountService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [NavBarComponent, CartSummaryComponent],
    providers: providers
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `ngOnInit `  ', () => {
    const returnVal = component.ngOnInit();
    expect(returnVal).toBeUndefined();

  });

  it('should call gotoAddress', () => {
    let actual = component.gotoAddress();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen ` should go to home  ', () => {
    component.currUrl = '/product-offer';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen ` should go to home  ', () => {
    component.currUrl = '/existing-products';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen ', () => {
    component.currUrl = '/customize-services';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen , should go to pending-order', () => {
    component.currUrl = '/stack-amend-product';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen , should go to existing-products', () => {
    component.currUrl = '/offer-change';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen, should go to existing-products', () => {
    component.currUrl = '/move-product';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/billing-product';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });
  
  it('Should call `displayPreviousScreen, should go to customize-services', () => {
    component.currUrl = '/schedule-non-appt';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });
  
  it('Should call `displayPreviousScreen, should go to order-unhold', () => {
    component.currUrl = '/schedule-appt';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });
  
  it('Should call displayPreviousScreen', () => {
    component.currUrl = '/schedule-appt-ship';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });
  
  it('Should call `displayPreviousScreen, should go to customize-services', () => {
    component.currUrl = '/billing-schedule-appt-ship';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/pending-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen, should go to pending-order', () => {
    component.currUrl = '/pending-schedule-appt';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/po-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/billing-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/po-order-confirmation';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/disconnect-schedule';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/disconnect-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/disconnect-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/vacation-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/co-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/move-schedule-appt-ship';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/amend-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/directv-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/change-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/move-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/mo-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/vacation-schedule-appt-ship';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/mo-review-order';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/vacation-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/vacation-option';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/nonpay-suspend';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/vacation-product-offer';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/reuse-ban-account';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

  it('Should call `displayPreviousScreen', () => {
    component.currUrl = '/change-responsibility';
    let actual = component.displayPreviousScreen();
    expect(actual).toBeUndefined();
  });

});
