import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from './models/appstore.model';
import { CTLHelperService } from './service/ctlHelperService';
import { HelperService } from './service/helper.service';
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor(private ctlHelperService: CTLHelperService) { }
    
    handleError(error: any): void {
        console.error(error);
        if(error.status === undefined && error.toString() !== undefined) {
            let message = this.ctlHelperService.toSubstring(error.toString(), 750);
            if(
                (message.indexOf('/services/collector/event') > -1) 
                || 
                (message.indexOf('URL:') > -1) 
                ||
                (message.indexOf('ExpressionChangedAfterItHasBeenCheckedError') > -1))
            {
                return;
            } else {
                 this.ctlHelperService.setErrorHandler(message) 
            }
        }
    }

}