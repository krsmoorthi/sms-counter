import { Component } from '@angular/core';
import { env } from '../../environments/environment';
import { Store } from '@ngrx/store';
import { AppStore } from '../common/models/appstore.model';

@Component({
    selector: 'build-details',
    styles: [`.fixed {
        position: fixed;
        bottom: 0;
        right: 0;
        padding: 5px 10px;
        border: 2px solid #0047BB;
        font-weight: 700;
    } 
    .lsDate-class{
        display: block;
    text-align: center;
    background-color: yellow;
    font-size: x-small;
    }`],
    template: '<span class="fixed" *ngIf="isDisplay"><span class="lsDate-class">{{logicalSystemDate|date:"mediumDate":"+000"}}</span> {{eshopBuildName}} >> {{bmBuildName}}</span>'
})

export class BuildDetailsComponent {
public eshopBuildName: string = env.CURRENT_ENVIRONMENT; 
public bmBuildName: string = env.BUILD_NAME;
public isDisplay: boolean = true;
public user:any;
public logicalSystemDate:any;
constructor( public store: Store<AppStore>){
    this.user = <any>this.store.select('user');
    let userSubscription = this.user.subscribe((data) => {
       if(data)
       {
           this.logicalSystemDate= data.logicalSystemDate;
       }
   });
}

public ngOnInit(){
    let eBN = this.eshopBuildName.split('//');
    eBN = eBN[1].split('.');
    this.eshopBuildName = eBN[0];
    let bmBN = this.bmBuildName.split('/');
    this.bmBuildName = bmBN[1];
   
}

}