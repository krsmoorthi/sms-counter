/* tslint:disable */
import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { Http, BaseRequestOptions, ConnectionBackend } from '@angular/http';
import { AbstractControl, FormControl, Validators } from '@angular/forms';
import { MockBackend } from '@angular/http/testing';
import { Router, RouterModule, provideRoutes } from '@angular/router';
import { Response, ResponseOptions, RequestMethod } from '@angular/http';
import { MockConnection } from '@angular/http/testing';
import { Validations } from './validations';
describe('Validation:', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: Http,
          useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          useClass: class { navigate = jasmine.createSpy("navigate"); }
        },
        Validations
  
      ]
    })
  });

  it('Should have getValidatorErrorMessage required Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("required", "mahesh")).toEqual('Required')
  });

  it('Should have getValidatorErrorMessage invalidCreditCard Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidCreditCard", "mahesh")).toEqual('Enter a valid credit card number')
  });

  it('Should have getValidatorErrorMessage invalidEmailAddress Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidEmailAddress", "mahesh")).toEqual('Enter a valid email address')
  });

  it('Should have getValidatorErrorMessage invalidPassword Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidPassword", "mahesh")).toEqual('Enter a valid password. Password must be at least 6 characters long, and contain a number.')
  });

  it('Should have getValidatorErrorMessage minlength  will be return Valid length', () => {
    expect(Validations.getValidatorErrorMessage("minlength", "mahesh")).toEqual("Minimum length undefined")
  });

  it('Should have getValidatorErrorMessage invalidZipCode Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidZipCode", "mahesh")).toEqual('Enter a valid zipcode')
  });

  it('Should have getValidatorErrorMessage invalidPhoneNumber Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidPhoneNumber", "mahesh")).toEqual('Enter a valid phone number')
  });

  it('Should have getValidatorErrorMessage invalidName Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidName", "mahesh")).toEqual('Enter a valid Name')
  });

  it('Should have getValidatorErrorMessage invalidPhoneNumberExtn Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidPhoneNumberExtn", "mahesh")).toEqual('Enter a valid Extention')
  });

  it('Should have getValidatorErrorMessage invalidPhoneNumberExtn Validator will be return Valid Message', () => {
    expect(Validations.getValidatorErrorMessage("invalidPhoneNumberExtn", "mahesh")).toEqual('Enter a valid Extention')
  });

  xit('Should have nameValidator error on an empty string', inject([Validations], (valida: Validations) => {
    expect(Validations.nameValidator((new FormControl('')))).toEqual({ 'invalidName': true });
  }));

  it('Should have nameValidator not error on a valid string', () => {
    expect(Validations.nameValidator(new FormControl('not empty'))).toEqual(null);
  });

  it('Should have nameValidator not accept zero as valid', () => {
    expect(Validations.nameValidator(new FormControl('0'))).toEqual({ 'invalidName': true });
  });

  it('Should have emailValidator not error on a valid string', () => {
    expect(Validations.emailValidator(new FormControl('mahesh@gmail.com'))).toEqual(null);
  });
  it('Should have emailValidator  error on a not valid string', () => {
    expect(Validations.emailValidator(new FormControl('maheshgmail.com'))).toEqual({ 'invalidEmailAddress': true });
  });

  xit('Should have phoneValidator error on an empty string', () => {
    expect(Validations.phoneValidator(new FormControl(''))).toEqual({ 'invalidPhoneNumber': true });
  });

  it('Should have phoneValidator not error on a valid  Number', () => {
    expect(Validations.phoneValidator(new FormControl('1234567890'))).toEqual(null);
  });

  it('Should have phoneValidator  error on a not valid Number', () => {
    expect(Validations.phoneValidator(new FormControl('ABC'))).toEqual({ 'invalidPhoneNumber': true });
  });

  it('Should have phoneExtnValidator null on an empty string', () => {
    expect(Validations.phoneExtnValidator(new FormControl(''))).toEqual(null);
  });

  it('Should have phoneExtnValidator not error on a valid  Extention', () => {
    expect(Validations.phoneExtnValidator(new FormControl('--'))).toEqual(null);
  });
  it('Should have zipCodeValidator error on an empty string', () => {
    expect(Validations.zipCodeValidator(new FormControl(''))).toEqual({ 'invalidZipCode': true });
  });

  it('Should have zipCodeValidator not error on a valid  Number', () => {
    expect(Validations.zipCodeValidator(new FormControl('12345-6789'))).toEqual(null);
  });

  it('Should have zipCodeValidator  error on a not valid zipCode', () => {
    expect(Validations.zipCodeValidator(new FormControl('ABC'))).toEqual({ 'invalidZipCode': true });
  });
  it('Should have creditCardValidator error on an empty string', () => {
    expect(Validations.creditCardValidator(new FormControl(''))).toEqual({ 'invalidCreditCard': true });
  });

  it('Should have creditCardValidator not error on a valid  Number', () => {
    expect(Validations.creditCardValidator(new FormControl('4012345678992'))).toEqual(null);
  });

  it('Should have creditCardValidator error on a not valid  creditCard Number', () => {
    expect(Validations.creditCardValidator(new FormControl('Misa'))).toEqual({ 'invalidCreditCard': true });
  });
  it('Should have passwordValidator error on an empty string', () => {
    expect(Validations.passwordValidator(new FormControl(''))).toEqual({ 'invalidPassword': true });
  });

  it('Should have passwordValidator not error on a valid  Number', () => {
    expect(Validations.passwordValidator(new FormControl('123456'))).toEqual(null);
  });

  it('Should have passwordValidator error on a not valid  password', () => {
    expect(Validations.passwordValidator(new FormControl('+'))).toEqual({ 'invalidPassword': true });
  });

  it('Should have dobValidator error on a not valid  dob', () => {
    expect(Validations.dobValidator(13, 32, 2016)).toEqual({ 'invalidDOB': true, message: 'Enter a valid date of birth' });
  });

  it('should validate the account password field as invalid', () => {
    expect(Validations.accountPasswordValidator({value:'     '})).toEqual({ invalidAccPass: true });
  });
  
  it('should validate the account password field as valid', () => {
    expect(Validations.accountPasswordValidator({value:'Will Smith@1'})).toEqual(null);
  });

});
