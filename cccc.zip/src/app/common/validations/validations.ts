export class Validations {
    public static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            required: 'Required',
            autoLoginInvalidAddressLine: 'Please enter a valid address and re-submit',
            invalidCreditCard: 'Enter a valid credit card number',
            invalidEmailAddress: 'Enter a valid email address',
            // tslint:disable-next-line:max-line-length
            invalidPassword: 'Enter a valid password. Password must be at least 6 characters long, and contain a number.',
            invalidAccPassSpace: 'Enter a valid password',
            invalidAccPassLength: 'Password must not be more than 20',
            minlength: `Minimum length ${validatorValue.requiredLength}`,
            invalidZipCode: 'Enter a valid zipcode',
            invalidPhoneNumber: 'Enter a valid phone number',
            invalidName: 'Enter a valid Name',
            invalidNumber: 'Enter a valid number',     
            invalidAccount: 'Enter a valid Account number',
            invalidOrderNumber: 'Enter a valid Order or Reference number',
            invalidPhoneNumberExtn: 'Enter a valid Extention',
            invalidAddressLine: 'Only Civic Address format is allowed',
            invalidAddress: 'Enter a valid address',
            emptyEmailAddress: 'Email Address Required',
            invalidcbrPhoneNumber: ''
        };

        return config[validatorName];
    }

    public static autoLoginAddressLineValidator() {
        return { autoLoginInvalidAddressLine : true };
    }

    public static nameValidatorWithSomeCharAllowed(control) {
        // Name validation with whitespace, . and ' allowed
        if (control.value.match(/^[A-Za-z.' ]{1,30}$/)) {
            return null;
        } else {
            return { invalidName: true };
        }
    }
   
    public static accountValidator(control) {
       if (control.value.match(/^[a-zA-Z0-9]*$/i) || control.value === '') {
            return null;
        } else {
            return { invalidAccount: true };
        }
    }

    public static orderNumberValidator(control) {
        if (control.value.match(/^[0-9]+$/i) || control.value.match(/^ORN-\d*$/i) || control.value === '') {
             return null;
         } else {
             return { invalidOrderNumber: true };
         }
     }
    
    public static tnValidator(control) {
     if (control.value !== null && (control.value.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/) || control.value === '')) {
         return null;
     } else {
         return { invalidNumber: true };
     }
    } 
    
    public static nameValidator(control) {
        // Name validation with whitespace
        if (control.value !== null && (control.value.match(/^[a-z ,.'-]+$/i) || control.value === '')) {
            return null;
        } else {
            return { invalidName: true };
        }
    }
    
    public static accountNameValidator(control) {
        // Name validation with whitespace
        if (control.value !== null && (control.value.match(/^[a-z ,'-]+$/i) || control.value === '')) {
            return null;
        } else {
            return { invalidName: true };
        }
    }

    public static prepaidUnameValidator(control) {
        if(control && control.value !== null && control.value !== '' && control.value.length >= 6) {
            return true;
        } else {
            return false;
        }
    }

    public static prepaidEmailValidator(control) {
        if (control.value !== null && control.value !== '' && control.value.length > 5) {
            if (control.value.match(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/)) {
                let afterAt = control.value.substr(control.value.lastIndexOf('@') + 1);
                let afterDot = control.value.substr(control.value.lastIndexOf('.') + 1);
                if (control.value.indexOf('.') === -1) {
                    return false;
                } else if(afterAt.length === 1) {
                    return false
                } else if(afterAt.indexOf('.') === -1){
                    return false;
                } else if(afterDot.length === 1) {
                    return false;
                } else {
                    return true;
                }
            } 
        } else {
            return false;
        }
    }

    public static emailValidator(control) {
        // RFC 2822 compliant regex

        if (control.value && control.value.length > 5) {
            // tslint:disable-next-line:max-line-length
            if (control.value.match(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/)) {
                if (control.value.indexOf('.') === -1) {
                    return { invalidEmailAddress: true };
                }
                let afterAt = control.value.substr(control.value.lastIndexOf('@') + 1);
                if (afterAt.length === 1) {
                    return { invalidEmailAddress: true };
                }
                let afterDot = control.value.substr(control.value.lastIndexOf('.') + 1);
                if (afterDot.length === 1) {
                    return { invalidEmailAddress: true };
                }
                if (afterAt.indexOf('.') === -1) {
                    return { invalidEmailAddress: true };
                }
                return null;
            } else {
                return { invalidEmailAddress: true };
            }
        } else {
            return { emptyEmailAddress: true };
        }
    }

    public static phoneValidator(control) {
        // regex 1234567890 or (123) 123 1234 or any US format
        if (control && control.value === '') {
            return { emptyPhoneNumber: true };
        }
        if (control.value !== null && typeof control.value == "string" &&  control.value.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)) {
            return null;
        } else {
            return { invalidPhoneNumber: true };
        }
    }
    public static cbrphoneValidator(control) {
        // regex 1234567890 or (123) 123 1234 or any US format
        if (control.value === '') {
            return { emptyPhoneNumber: true };
        }
        if (control.value !== null && control.value.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)) {
            return null;
        } else {
            return { invalidcbrPhoneNumber: true };
        }
    }

    public static phoneExtnValidator(control) {
        // regex 1234
        if (control.value.indexOf('_') === -1) {
            return null;
        } else {
            return { invalidPhoneNumberExtn: true };
        }
    }

    public static zipCodeValidator(control) {
        // regex eg. 12345 or 12345-6789
        if (control && control.value && control.value.match(/^\d{5}(-\d{4})?$/)) {
            return null;
        } else {
            return { invalidZipCode: true };
        }
    }

    public static zipCodeValidatorInt(control) {
        // regex eg. 12345 or 12345-6789
        return null;
    }

    public static addressLinePOBoxValidator(control) {
        // Address line input validator for PO Box
        let addressLineValue = control.value.toUpperCase();
        let substring = 'POB';
        let substring1 = 'PBOX';
        let substring2 = 'PO BOX';
        let substring3 = 'P.O. BOX';
        let substring4 = 'P.O.BOX';
        if ((addressLineValue.indexOf(substring) !== -1) ||
            (addressLineValue.indexOf(substring1) !== -1) ||
            (addressLineValue.indexOf(substring2) !== -1) ||
            (addressLineValue.indexOf(substring3) !== -1) ||
            (addressLineValue.indexOf(substring4) !== -1)) {
            return { invalidAddressLine: true };
        } else {
            return null;
        }
    }

    public static creditCardValidator(control) {
        // Visa, MasterCard, American Express, Diners Club, Discover, JCB
        // tslint:disable-next-line:max-line-length
        if (control && control.value && control.value.match(/^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/)) {
            return null;
        } else {
            return { invalidCreditCard: true };
        }
    }

    public static passwordValidator(control) {
        // {6,100}           - Assert password is between 6 and 100 characters
        // (?=.*[0-9])       - Assert a string has at least one number
        if (control && control.value && control.value.match(/^(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{6,100}$/)) {
            return null;
        } else {
            return { invalidPassword: true };
        }
    }
    
    public static accountPasswordValidator(control) {
        // {0,20}           - Assert password is between 0 and 20 charachters
        if(control && control.value && control.value.match(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~\s- ]{0,20}$/)) {
            let spacecounter = control.value.trim().length === 0 ? true : false; 
            if(spacecounter) return { invalidAccPass: true };
            else return null;
        } else return null;
    }

    public static dateofbirthValidation(month, day, year){
        let currYear = new Date().getFullYear();       
        if(month && (month < 1 || month > 12)){
            return { invalidDOB: true, message: 'Enter a valid date of birth' };
        } 
        if(day && (day < 1 || day > 31)){
            return { invalidDOB: true, message: 'Enter a valid date of birth' };
        }
        if(year && (year < 1900 || year > currYear - 1)){
           return { invalidDOB: true, message: 'Enter a valid date of birth' };
        } else {
            return null;
        }     
    }

    public static dobValidator(month, day, year) {
        let currYear = new Date().getFullYear();let pattern = new RegExp(/[~`!#@$%\^&*+=\-\[\]\\';,/{}|\\":<>\?]/); 
        let patterns=new RegExp(/^[A-Za-z]/);
        if (pattern.test(month)||patterns.test(month)) {
                      return { invalidDOB: true, message: 'Enter a valid date of birth' };
            } 
        if (pattern.test(day) || patterns.test(day)) {
                      return { invalidDOB: true, message: 'Enter a valid date of birth' };
            } 
        if (pattern.test(year)|| patterns.test(year)) {
                      return { invalidDOB: true, message: 'Enter a valid date of birth' };
            }  
        if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1900 || year > currYear - 1) {
            return { invalidDOB: true, message: 'Enter a valid date of birth' };
        }
        if (month === 1 || month === 3 || month === 5 || month === 7 || month === 8 || month === 10 || month === 12) {
            if (day < 1 || day > 31) {
                return { invalidDOB: true, message: 'Enter a valid date of birth' };
            }
        }
        if (month === 4 || month === 6 || month === 9 || month === 11) {
            if (day < 1 || day > 30) {
                return { invalidDOB: true, message: 'Enter a valid date of birth' };
            }
        }
        if(month === 2) {
            if(this.isLeapYear(year) && (day < 1 || day > 29)) {
                return { invalidDOB: true, message: 'Enter a valid date of birth' };
            } else if(!this.isLeapYear(year) && (day < 1 || day > 28)) {
                return { invalidDOB: true, message: 'Enter a valid date of birth' };
            }
        }
        else {
            return null;
        }
    }

    private static isLeapYear(year) {
        return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
    }

    public static addressLineValidator(control) {
        // address line validator which allows ,.!#_+-
        if (control !== undefined && control.value !== undefined
            && control.value.match(/^[A-Za-z0-9,.!#_+\- ]{1,250}$/)) {
            return null;
        } else {
            return { invalidAddress: true };
        }
    }
}