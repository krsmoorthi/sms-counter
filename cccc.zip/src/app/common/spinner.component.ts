import { Component, Input } from '@angular/core';

@Component({
  selector: 'spinner',
  templateUrl: './spinner.component.html',
  styles: [`
#interstitial {
    height: 100%; 
    width: 100%; 
    position: fixed;
    left: 0px; 
    top: 0px; 
    z-index:4000;
    background-color:rgba(211,211,211,.75); 
}

#interstitial-image {
    color: #333; 
    height:108px;
    left: calc(50% - 55px);
    position: fixed;
    top: calc(50% - 55px)
}
  
.glyphicon-refresh-animate {
    animation: spin .7s infinite linear;
    -webkit-animation: spin2 .7s infinite linear;
    font-size: 1em;
}

@-webkit-keyframes spin2 {
    from { -webkit-transform: rotate(0deg);}
    to { -webkit-transform: rotate(360deg);}
}

@keyframes spin {
    from { transform: scale(1) rotate(0deg);}
    to { transform: scale(1) rotate(360deg);}
}`]
})
export class SpinnerComponent {
    @Input() public loading: boolean;
}
