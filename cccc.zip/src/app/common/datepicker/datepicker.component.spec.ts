// import { MockServer } from './../../MockServer.test';
// /* tslint:disable */
// import { inject, TestBed, fakeAsync } from '@angular/core/testing';
// import { Http, BaseRequestOptions, ConnectionBackend, RequestOptions } from '@angular/http';
// import { MockBackend } from '@angular/http/testing';
// import { MockConnection } from '@angular/http/testing';
// import { RouterModule, Router } from '@angular/router';
// import { Component, Input, Output, EventEmitter} from '@angular/core';
// import { DatepickerModule } from 'ngx-bootstrap/datepicker';
// import { FormsModule } from '@angular/forms';
// import { DatePipe } from '@angular/common';
// import { CustomDatePickerComponent } from './datepicker.component';
// import 'intl';
// import 'intl/locale-data/jsonp/en';
// describe('DatePicker DueDate Effective Bill Date Component', () => {
// 	let mockRouter = {
// 		navigate: jasmine.createSpy('navigate')
//     };
//     let datePicker = new CustomDatePickerComponent();
//     let mockServ = new MockServer();
//     let req = {
//         taskName : 'Shipping'
//     };

// 	beforeEach(() => TestBed.configureTestingModule({
// 		providers: [
// 			BaseRequestOptions,
// 			{
// 				provide: Http,
// 				useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
// 					return new Http(backend, defaultOptions);
// 				},
// 				deps: [MockBackend, BaseRequestOptions]
// 			},
// 			{
// 				provide: Router,
// 				useValue: mockRouter
// 			},
// 		]
//     }));
   
//     it('ngOnInit should have been called...', () => {
//         expect(datePicker.dt).toBeDefined;
//         expect(datePicker.originalDate).toBeDefined;
//         expect(datePicker.selectedDay).toBeDefined;
//         expect(datePicker.minDate).toBeDefined;
//         expect(datePicker.events).toBeDefined;
//         expect(datePicker.tomorrow).toBeDefined;
//         expect(datePicker.afterTomorrow).toBeDefined
//         expect(datePicker.dateDisabled).toBeDefined
        
//       });

//       it('should set date...', () => {
//         datePicker.Date = '2017-10-06';
//         expect(datePicker._date).toBe('2017-10-06'); 
//       });

//       it('should disable date...', () => {
//         datePicker.Date = '2017-10-06';
//         expect(datePicker._date).toBe('2017-10-06'); 
//       });

//       it('should set Appointment...', () => {
//         datePicker.setAppointment();
//         expect(datePicker.originalDate).toBe(datePicker.dt); 
//       });
//       it('should cancel Appointment...', () => {
//         datePicker.cancelClick();
//         expect(datePicker.dt).toBe(datePicker.originalDate); 
//       });

//       it('should clear Appointment...', () => {
//         datePicker.clear();
//         expect(datePicker.dateDisabled).toBe(undefined); 
//       });

//        it('should open Appointment...', () => {
//         expect(datePicker.open()).toHaveBeenCalled; 
//       });

//        it('should call Disabled...', () => {
//         expect(datePicker.disabled(new Date(),'day')).toHaveBeenCalled; 
//       });

//       it('should toogle Min...', () => {
//         datePicker.minDate = new Date();
//         datePicker.toggleMin();
//         expect(datePicker.dt).toEqual(datePicker.minDate); 
//       });

//        it('should call getDayClass...', () => {
//          let date = new Date();
//          let result = datePicker.getDayClass(date,'day');
//          expect(result).toBe(''); 
//       });
// });