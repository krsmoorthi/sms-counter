import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { AvailableAppointment } from '../../common/models/appointment.model';
import { User } from '../../common/models/user.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { SchedulingService } from '../../common/service/scheduling.service';
import { cloneDeep, filter } from 'lodash';
import { CTLHelperService } from '../service/ctlHelperService';
import { Logger } from '../../common/logging/default-log.service';
import { SystemErrorService } from '../../common/service/system-error.service';
import { APIErrorLists } from '../../common/models/common.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'eservicing-appointment',
    templateUrl: './datepicker.appointment.html',
    styleUrls: ['./datepicker.appointment.scss']
})

export class AppointmentDatePickerComponent implements OnInit, OnDestroy {
    public appointmentSet: boolean = false;
    public isApptChanged: any;
    private retainObservable: Observable<any>;
    private retainSubscription: Subscription;
    public reservedTimeRetain = '';
    public reservedDateRetain = '';
    private rightMostDate;
    public enableLeftClick = false;
    public enableRightClick = true;
    public showSuccessImage: boolean;
    public _appointment: AvailableAppointment[];
    private selectedAppointment: AvailableAppointment;
    public reservedAppointment: AvailableAppointment;
    public negativeButton = 'Cancel';
    public positiveButton = 'Reserve It';
    public reservedDate = '';
    public firstPendingFlag: boolean = false;
    public multiplePendingflag: boolean = false;
    public FirstPendingDuedate: string = '';
    public secondPendingDuedate: string = '';
    public secondPendingEnddate: string = '';
    public reservedTime = '';
    private reservedFullDate: Date;
    private curr = new Date();
    public appointmentDate: string = '';
    public appointmentTime: string = '';
    private appointmentFullDate: Date;
    private FIRSTDATE = new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay()));
    private LASTDATE = new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 6));
    private firstday = this.FIRSTDATE.getMonth();
    private lastday = this.LASTDATE.getMonth();
    public weekInfo = '';
    public errorText = '';
    public loading: boolean = false;
    private monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    private monthFullNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    private isDefaultSlotSelected = false;
    private currentRightDate;
    private currentLeftDate;
    private originalAppointmentArray: AvailableAppointment[];
    private overriddenAppointmentArray: AvailableAppointment[];
    public header = {
        day1Date: this.FIRSTDATE,
        day1Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay())).toString().split(' ')[0],
        day1: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay())).getDate(),
        day2Date: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 1)),
        day2Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 1)).toString().split(' ')[0],
        day2: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 1)).getDate(),
        day3Date: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 2)),
        day3Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 2)).toString().split(' ')[0],
        day3: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 2)).getDate(),
        day4Date: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 3)),
        day4Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 3)).toString().split(' ')[0],
        day4: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 3)).getDate(),
        day5Date: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 4)),
        day5Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 4)).toString().split(' ')[0],
        day5: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 4)).getDate(),
        day6Date: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 5)),
        day6Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 5)).toString().split(' ')[0],
        day6: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 5)).getDate(),
        day7Name: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 6)).toString().split(' ')[0],
        day7: new Date(this.curr.setDate(this.curr.getDate() - this.curr.getDay() + 6)).getDate(),
        day7Date: this.LASTDATE
    };
    public orderRefNumber: string;
    public dataArray = [
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: '',
            day2Data: '8:00AM-10:00AM',
            day2Appointment: null,
            day3: '',
            day3Data: '9:00AM-11:00AM',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: '',
            day5Data: '8:00AM-12:00PM',
            day5Appointment: null,
            day6: '',
            day6Data: '8:00AM-12:00PM',
            day6Appointment: null,
            day7: '',
            day7Data: '1:00PM-3:00PM',
            day7Appointment: null
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: '',
            day2Data: '8:00AM-12:00PM',
            day2Appointment: null,
            day3: '',
            day3Data: '10:00AM-12:00PM',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: '',
            day5Data: '10:00AM-12:00PM',
            day5Appointment: null,
            day6: '',
            day6Data: '10:00AM-12:00PM',
            day6Appointment: null,
            day7: '',
            day7Data: '2:00PM-4:00PM',
            day7Appointment: null,
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: '',
            day2Data: '10:00AM-12:00PM',
            day2Appointment: null,
            day3: '',
            day3Data: '1:00PM-3:00PM',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: '',
            day5Data: '1:00PM-3:00PM',
            day5Appointment: null,
            day6: '',
            day6Data: '1:00PM-2:00PM',
            day6Appointment: null,
            day7: '',
            day7Data: '3:00PM-5:00PM',
            day7Appointment: null,
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: 'disabled',
            day2Data: '',
            day2Appointment: null,
            day3: 'disabled',
            day3Data: '',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: 'disabled',
            day5Data: '',
            day5Appointment: null,
            day6: '',
            day6Data: '2:00PM-4:00PM',
            day6Appointment: null,
            day7: 'disabled',
            day7Data: '',
            day7Appointment: null,
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: 'disabled',
            day2Data: '',
            day2Appointment: null,
            day3: 'disabled',
            day3Data: '',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: 'disabled',
            day5Data: '',
            day5Appointment: null,
            day6: '',
            day6Data: '3:00PM-5:00PM',
            day6Appointment: null,
            day7: 'disabled',
            day7Data: '',
            day7Appointment: null,
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: 'disabled',
            day2Data: '',
            day2Appointment: null,
            day3: 'disabled',
            day3Data: '',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: 'disabled',
            day5Data: '',
            day5Appointment: null,
            day6: '',
            day6Data: '4:00PM-6:00PM',
            day6Appointment: null,
            day7: 'disabled',
            day7Data: '',
            day7Appointment: null
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: 'disabled',
            day2Data: '',
            day2Appointment: null,
            day3: 'disabled',
            day3Data: '',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: 'disabled',
            day5Data: '',
            day5Appointment: null,
            day6: '',
            day6Data: '5:00PM-7:00PM',
            day6Appointment: null,
            day7: 'disabled',
            day7Data: '',
            day7Appointment: null,
        },
        {
            day1: 'disabled',
            day1Data: '',
            day1Appointment: null,
            day2: 'disabled',
            day2Data: '',
            day2Appointment: null,
            day3: 'disabled',
            day3Data: '',
            day3Appointment: null,
            day4: 'disabled',
            day4Data: '',
            day4Appointment: null,
            day5: 'disabled',
            day5Data: '',
            day5Appointment: null,
            day6: '',
            day6Data: '6:00PM-8:00PM',
            day6Appointment: null,
            day7: 'disabled',
            day7Data: '',
            day7Appointment: null
        }
    ];
    public check: boolean;
    public reservation: boolean;
    public appointmentid: any;
    public startDateTime: any;
    public endDateTime: any;
    public commitmentDateTime: any;
    public timeSlotSource: any;
    public timeSlotType: any;
    public accountRentrantValue: any;
    public apptObservable: Observable<any>;
    public apptSubscription: Subscription;
    public overrideReqd: any;
    public existingPendingOrderData: any;
    public oneTimeCheck = false;
    public doEmittoParent: boolean;
    public taskId: string;
    public processInstanceId: string;
    public orderFlow: any;
    public showOverRideApptChatLink: boolean = false;
    public retrieveARNCalled: boolean = false;
    public isOverrideClicked: boolean = false;
    public appointmentReservationNumber: string = 'null';
    public apiResponseError: APIErrorLists;
    @Input() public CalculatedDueDate;
    @Input() public isReEntrant: boolean = false;
    @Input() public isStack;
    @Input() public isAmend;
    @Input() public isEnableOverride: boolean = true;
    @Input() set Success(showReserveItButton: boolean) {
        this.showSuccessImage = showReserveItButton;
    }
    @Input() set Appointment(appointments: AvailableAppointment[]) {
        if (appointments && appointments.length > 0) {
            this.originalAppointmentArray = cloneDeep(appointments);
            let appointment = appointments[0];
            let appointmentLast = appointments[appointments.length - 1];
            let commitedDate: any;
            commitedDate = appointment.timeSlot.startDateTime;
            let commitedDateLast = appointmentLast.timeSlot.startDateTime;
            this.firstDate = new Date(commitedDate);
            this.rightMostDate = new Date(commitedDateLast);
        }
        this.loadAppointments(appointments);
    }
    @Output() public appointmentUpdated = new EventEmitter();
    @Output() public apptChanged = new EventEmitter();
    @Output() public resrvatnId = new EventEmitter();
    @Output() public earliestAvalAppt = new EventEmitter();
    public ngOnDestroy$ = new Subject();

    public constructor(
        private store: Store<AppStore>,
        private logger: Logger,
        private schedulingService: SchedulingService,
        private ctlHelperService: CTLHelperService,
        private systemErrorService: SystemErrorService) 
    {
        this.oneTimeCheck = false;
        let user = <Observable<User>>store.select('user');
        let userSubscription = user
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe(
            (usr) => {
                let existingObservable = <Observable<any>>store.select('existingProducts');
                let existingSubscription = existingObservable
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe((ext) => {
                    this.orderFlow = ext.orderFlow && ext.orderFlow.flow;
                });
                if (usr.orderInit) {
                    this.orderRefNumber = usr.orderInit.orderRefNumber;
                    this.taskId = usr.taskId ? usr.taskId : usr.orderInit.taskId;
                    this.processInstanceId = usr.orderInit.processInstanceId;
                    if(usr.orderInit.payload && usr.orderInit.payload.serviceAddress)
                        this.showOverRideApptChatLink = usr.orderInit.payload && usr.orderInit.payload.serviceAddress && usr.orderInit.payload.serviceAddress.source === 'Martens' ? true : false;
                    else if(usr.orderInit.payload && usr.orderInit.payload.newLocation && usr.orderInit.payload.newLocation.serviceAddress)
                        this.showOverRideApptChatLink = usr.orderInit.payload && usr.orderInit.payload.newLocation.serviceAddress && usr.orderInit.payload.newLocation.serviceAddress.source === 'Martens' ? true : false;
                } else {
                    existingObservable
                    .pipe(takeUntil(this.ngOnDestroy$))
                    .subscribe(
                        (ext) => {
                            if (usr.taskId) {
                                this.taskId = usr.taskId;
                                this.orderRefNumber = usr.orderRefNumber;
                            } else if (ext.orderInit) {
                                this.orderRefNumber = ext.orderInit.orderRefNumber;
                                this.taskId = ext.orderInit.taskId;
                                this.processInstanceId = ext.orderInit.processInstanceId;
                            }
                            if (ext && ext.existingProductsAndServices && ext.existingProductsAndServices[0] &&
                                ext.existingProductsAndServices[0].pendingOrders && ext.existingProductsAndServices[0].pendingOrders[0]) {
                                this.existingPendingOrderData = ext.existingProductsAndServices[0].pendingOrders[0];
                                if (this.existingPendingOrderData && this.existingPendingOrderData !== undefined && this.existingPendingOrderData.orderDocument.schedule && this.existingPendingOrderData.orderDocument.schedule !== undefined && this.existingPendingOrderData.orderDocument.schedule.appointmentInfo && this.existingPendingOrderData.orderDocument.schedule.appointmentInfo !== undefined) {
                                    this.SetVAlues(this.existingPendingOrderData.orderDocument.schedule.appointmentInfo);
                                }
                            } else {
                                this.existingPendingOrderData = '';
                            }
                            this.showOverRideApptChatLink = ext && ext.existingProductsAndServices && ext.existingProductsAndServices[0].serviceAddress.source === 'Martens' ? true : false;
                            let pendingObservable = <Observable<any>>store.select('pending');
                            let pendingSubscription = pendingObservable
                            .pipe(takeUntil(this.ngOnDestroy$))
                            .subscribe(
                                (pending) => {
                                    if (pending.orderReference) {
                                        this.orderRefNumber = pending.orderReference.orderReferenceNumber;
                                        this.processInstanceId = pending.orderReference.processInstanceId;
                                        this.taskId = pending.orderReference.taskId;
                                        this.showOverRideApptChatLink = pending.orderDocument.serviceAddress && pending.orderDocument.serviceAddress.source === 'Martens' ? true : false;
                                    }
                                    if (ext.pendingOrders && ext.pendingOrders.length > 1) {
                                        this.multiplePendingflag = true;
                                        if (ext.pendingOrders && ext.pendingOrders[0] && ext.pendingOrders[0].orderReference
                                            && pending && pending.orderReference && pending.orderReference.customerOrderNumber
                                            && ext.pendingOrders[0].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber &&
                                            ext.pendingOrders[0].orderDocument.schedule &&
                                            ext.pendingOrders[0].orderDocument.schedule.appointmentInfo && this.existingPendingOrderData !== '') {
                                            this.SetVAlues(ext.pendingOrders[0].orderDocument.schedule.appointmentInfo);
                                        } else if (ext.pendingOrders && ext.pendingOrders[1] && ext.pendingOrders[1].orderReference
                                            && pending && pending.orderReference && pending.orderReference.customerOrderNumber
                                            && ext.pendingOrders[1].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber &&
                                            ext.pendingOrders[1].orderDocument.schedule &&
                                            ext.pendingOrders[1].orderDocument.schedule.appointmentInfo && this.existingPendingOrderData !== '') {
                                            this.SetVAlues(ext.pendingOrders[1].orderDocument.schedule.appointmentInfo);
                                        }
                                        if (ext.pendingOrders && ext.pendingOrders[0] && ext.pendingOrders[0].orderReference
                                            && ext.pendingOrders[0].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber
                                            && ext.pendingOrders[0].orderReference.customerOrderNumber < ext.pendingOrders[1].orderReference.customerOrderNumber)
                                            this.firstPendingFlag = true;
                                        else if (ext.pendingOrders && ext.pendingOrders[1] && ext.pendingOrders[1].orderReference
                                            && ext.pendingOrders[1].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber
                                            && ext.pendingOrders[1].orderReference.customerOrderNumber < ext.pendingOrders[0].orderReference.customerOrderNumber)
                                            this.firstPendingFlag = true;
                                        if (ext.pendingOrders[0] && ext.pendingOrders[0].orderDocument && ext.pendingOrders[0].orderDocument.schedule &&
                                            ext.pendingOrders[0].orderDocument.schedule.dates && ext.pendingOrders[0].orderDocument.schedule.dates.finalDueDate
                                            && ext.pendingOrders[0].orderReference.customerOrderNumber < ext.pendingOrders[1].orderReference.customerOrderNumber) {
                                            this.FirstPendingDuedate = ext.pendingOrders[0].orderDocument.schedule.dates.finalDueDate;
                                            this.secondPendingDuedate = ext.pendingOrders[1].orderDocument.schedule.dates.finalDueDate;
                                        }
                                        if (ext.pendingOrders && ext.pendingOrders[1] && ext.pendingOrders[1].orderDocument && ext.pendingOrders[1].orderDocument.schedule && ext.pendingOrders[1].orderDocument.schedule.dates && ext.pendingOrders[1].orderDocument.schedule.dates.finalDueDate
                                            && ext.pendingOrders[0].orderReference.customerOrderNumber > ext.pendingOrders[1].orderReference.customerOrderNumber) {
                                            this.FirstPendingDuedate = ext.pendingOrders[1].orderDocument.schedule.dates.finalDueDate;
                                            this.secondPendingDuedate = ext.pendingOrders[0].orderDocument.schedule.dates.finalDueDate;
                                            this.secondPendingEnddate = this.secondPendingDuedate;
                                        }
                                    }
                                });
                            pendingSubscription.unsubscribe();
                            this.apptObservable = <Observable<any>>this.store.select('appointment');
                            this.apptSubscription = this.apptObservable
                            .pipe(takeUntil(this.ngOnDestroy$))
                            .subscribe((data) => {
                                if (data && data.taskId && this.taskId === undefined) {
                                    this.taskId = data.taskId;
                                    this.orderRefNumber = data.orderRefNumber;
                                    if(this.orderFlow === 'SUP2' || this.orderFlow === 'Change') { this.processInstanceId = data.processInstanceId; }
                                }
                                if (data && data.processInstanceId && this.processInstanceId === undefined)
                                    this.processInstanceId = data.processInstanceId;
                            })
                            this.apptSubscription.unsubscribe();
                        });
                }
                existingSubscription.unsubscribe();
            });
        userSubscription.unsubscribe();
        this.reservedFullDate = new Date();
        this.appointmentFullDate = new Date();
        this.setWeekInfo();
    }
    
    public ngOnInit() {
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            if (data && data.earliestAppt && data.earliestAppt.reserveDate && data.earliestAppt.reserveTime) {
                this.reservedDateRetain = data.earliestAppt.reserveDate;
                this.reservedTimeRetain = data.earliestAppt.reserveTime;
            }
            if (this.doEmittoParent) {
                this.doEmittoParent = false;
                if (this.reservedAppointment && this.reservedAppointment !== undefined && this.reservedAppointment.reservationId && this.reservedAppointment.reservationId !== undefined) {
                    delete this.reservedAppointment.reservationId;
                    this.appointmentUpdated.emit(this.reservedAppointment);
                    this.store.dispatch({ type: 'SELECTED_APPOINTMENT', payload: this.reservedAppointment });
                    this.store.dispatch({ type: 'FINALDUEDATE_APPOINTMENT', payload: this.reservedAppointment.commitmentDateTime });
                    this.store.dispatch({ type: 'RETAIN_EARLIEST_APPT', payload: { earliestAppt: { reserveDate: this.appointmentDate, reserveTime: this.appointmentTime } } });
                }
            }
        });
    }

    public getDayOnly(day) {
        var weekday = new Array(7);
        weekday[0] = "Sunday";
        weekday[1] = "Monday";
        weekday[2] = "Tuesday";
        weekday[3] = "Wednesday";
        weekday[4] = "Thursday";
        weekday[5] = "Friday";
        weekday[6] = "Saturday";
        var n = weekday[day.getDay()];
        return n;
    }

    public SetVAlues(respData) {
        if (respData && respData !== undefined && respData.appointmentId && respData.appointmentId !== undefined) {
            this.appointmentid = respData.appointmentId;
        }
        if (respData && respData !== undefined && respData.timeSlot && respData.timeSlot !== undefined && respData.timeSlot.startDateTime && respData.timeSlot.startDateTime !== undefined) {
            this.startDateTime = respData.timeSlot.startDateTime;
        }
        if (respData && respData !== undefined && respData.timeSlot && respData.timeSlot !== undefined && respData.timeSlot.endDateTime && respData.timeSlot.endDateTime !== undefined) {
            this.endDateTime = respData.timeSlot.endDateTime;
        }
        if (respData && respData !== undefined && respData.commitmentDateTime && respData.commitmentDateTime !== undefined) {
            this.commitmentDateTime = respData.commitmentDateTime;
        }
        if (respData && respData !== undefined && respData.timeSlotSource && respData.timeSlotSource !== undefined) {
            this.timeSlotSource = respData.timeSlotSource;
        }
        if (respData && respData !== undefined && respData.timeSlotType && respData.timeSlotType !== undefined) {
            this.timeSlotType = respData.timeSlotType;
        }
        if (respData && respData !== undefined && respData.overrideReqd && respData.overrideReqd !== undefined) {
            this.overrideReqd = respData.overrideReqd;
        }
        respData.defaultTimeSlot = false;
        if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
            this.accountRentrantValue = respData.accountreentrant;
        }
        this.doEmittoParent = true;
        if (respData && respData !== undefined && respData.timeSlot && respData.timeSlot !== undefined && respData.timeSlot.startDateTime && respData.timeSlot.startDateTime !== undefined) {
            let lCommitmentDate = respData.timeSlot.startDateTime;
            lCommitmentDate.trim().substr(0, 10).replace(/-/g, '\/');
            lCommitmentDate = new Date(lCommitmentDate);
            let showDay = this.getDayOnly(lCommitmentDate);
            let showMonth = this.monthFullNames[lCommitmentDate.getMonth()];
            let showDate = lCommitmentDate.getDate();
            this.appointmentDate = showDay + ' ' + showMonth + ' ' + showDate;
            let st = this.existingPendingOrderData.orderDocument.schedule.appointmentInfo.timeSlot.startDateTime.substring(11, 16);
            let st1 = st.substring(0, 2) > 12 ? parseInt(st.substring(0, 2)) - 12 + st.substring(2) + ' PM' : st + ' AM';
            let et = this.existingPendingOrderData.orderDocument.schedule.appointmentInfo.timeSlot.endDateTime.substring(11, 16);
            let et1 = et.substring(0, 2) > 12 ? parseInt(et.substring(0, 2)) - 12 + et.substring(2) + ' PM' : et + ' AM';
            if (st1 === '08:00' && et1 === '18:00') {
                this.appointmentTime = "ALL DAY";
                respData.allDayAppt = true;
            } else {
                this.appointmentTime = st1 + '-' + et1;
                respData.allDayAppt = false;
            }
            this.reservedAppointment = respData;
            this.appointmentUpdated.emit(this.reservedAppointment);
            this.store.dispatch({ type: 'SELECTED_APPOINTMENT', payload: this.reservedAppointment });
            this.store.dispatch({ type: 'FINALDUEDATE_APPOINTMENT', payload: this.reservedAppointment.commitmentDateTime });
        }
    }

    public reentrantAppt() {
        if (!this.isOverrideClicked) {
            this.currentLeftDate = new Date();
        }
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((respData) => {
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.appointmentId && respData.selectedappointment.appointmentId !== undefined) {
                this.appointmentid = respData.selectedappointment.appointmentId;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.startDateTime && respData.selectedappointment.timeSlot.startDateTime !== undefined) {
                this.startDateTime = respData.selectedappointment.timeSlot.startDateTime;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.endDateTime && respData.selectedappointment.timeSlot.endDateTime !== undefined) {
                this.endDateTime = respData.selectedappointment.timeSlot.endDateTime;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.commitmentDateTime && respData.selectedappointment.commitmentDateTime !== undefined) {
                this.commitmentDateTime = respData.selectedappointment.commitmentDateTime;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlotSource && respData.selectedappointment.timeSlotSource !== undefined) {
                this.timeSlotSource = respData.selectedappointment.timeSlotSource;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlotType && respData.selectedappointment.timeSlotType !== undefined) {
                this.timeSlotType = respData.selectedappointment.timeSlotType;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.overrideReqd && respData.selectedappointment.overrideReqd !== undefined) {
                this.overrideReqd = respData.selectedappointment.overrideReqd;
            }
            if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
                this.accountRentrantValue = respData.accountreentrant;
            }
        });
        if (this.retainSubscription !== undefined) {
            this.retainSubscription.unsubscribe();
        }
        
        this.currentLeftDate = new Date();
        let reentrantApiCall;
        if (this.firstPendingFlag && this.multiplePendingflag) {
            reentrantApiCall = {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "startDateTime": this.currentLeftDate,
                    "endDateTime": this.secondPendingDuedate,
                    "calculatedDueDate": this.CalculatedDueDate,
                    "unavailableSlotsReqd": (this.overrideReqd === 'YES') ? 'Yes' : 'No',
                    "existingAppointment": {
                        "appointmentId": this.appointmentid,
                        "timeSlot": {
                            "startDateTime": this.startDateTime,
                            "endDateTime": this.endDateTime
                        },
                        "overrideReqd": this.overrideReqd,
                        "commitmentDateTime": this.commitmentDateTime,
                        "timeSlotType": this.timeSlotType,
                        "timeSlotSource": this.timeSlotSource
                    }
                }
            };
        } else {
            reentrantApiCall = {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "startDateTime": this.currentLeftDate,
                    "calculatedDueDate": this.CalculatedDueDate,
                    "unavailableSlotsReqd": (this.overrideReqd === 'YES') ? 'Yes' : 'No',
                    "existingAppointment": {
                        "appointmentId": this.appointmentid,
                        "timeSlot": {
                            "startDateTime": this.startDateTime,
                            "endDateTime": this.endDateTime
                        },
                        "overrideReqd": this.overrideReqd,
                        "commitmentDateTime": this.commitmentDateTime,
                        "timeSlotType": this.timeSlotType,
                        "timeSlotSource": this.timeSlotSource
                    }
                }
            };
        }
        if (this.accountRentrantValue) {
            this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentRequest", JSON.stringify(reentrantApiCall));
            this.logger.startTime();
            this.loading = true;
            this.schedulingService.overRideAppointment(reentrantApiCall, this.orderFlow)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", error);
                    this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    return Observable.throw(error);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(data));
                        this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        let latestApptData = data && data.payload && data.payload.availableAppointment;
                        this.taskId = data.taskId;
                        this.processInstanceId = data.processInstanceId;
                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                        this.store.dispatch({ type: 'PROCESSINSTANCEID', payload: data.processInstanceId });
                        if (latestApptData.length > 0) {
                            let appointment = latestApptData[0];
                            let appointmentLast = latestApptData[latestApptData.length - 1];
                            let commitedDate = appointment.timeSlot.startDateTime;
                            let commitedDateLast = appointmentLast.timeSlot.startDateTime;
                            this.firstDate = new Date(commitedDate);
                            this.rightMostDate = new Date(commitedDateLast);
                        }
                        this.loadAppointments(latestApptData);
                        this.appointmentReservationNumber = data.payload.reservationId;
                        this.loading = false;
                    }, (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", error);
                        this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        if (error === undefined || error === null)
                            return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", lAPIErrorLists);
                        }
                    });
        }
    }

    public getFullDayName(partialDay) {
        switch (partialDay) {
            case 'Sun': return 'Sunday';
            case 'Mon': return 'Monday';
            case 'Tue': return 'Tuesday';
            case 'Wed': return 'Wednesday';
            case 'Thu': return 'Thursday';
            case 'Fri': return 'Friday';
            case 'Sat': return 'Saturday';
            default: return '';
        }
    }

    public ApptmentsSelected() {
        this.setAppointment(true);
        this.earliestApptSelected();
    }

    public earliestApptSelected() {
        this.showSuccessImage = false;
        this.earliestAvalAppt.emit(true);
    }

    public setAppointment(doSet?: boolean) {
        if (this.reservedDate) {
            this.errorText = '';
            this.appointmentDate = this.reservedDate;
            this.appointmentTime = this.reservedTime;
            this.appointmentFullDate = this.reservedFullDate;
            this.selectedAppointment = this.reservedAppointment;
            this.isApptChanged = doSet;
            this.apptChanged.emit(this.isApptChanged);
            this.appointmentUpdated.emit(this.selectedAppointment);
            if (doSet) {
                this.showSuccessImage = false;
                this.store.dispatch({ type: 'SELECTED_APPOINTMENT', payload: this.selectedAppointment });
                this.store.dispatch({ type: 'FINALDUEDATE_APPOINTMENT', payload: this.selectedAppointment.commitmentDateTime });
            } else {
                this.store.dispatch({ type: 'SELECTED_APPOINTMENT', payload: this.selectedAppointment });
            }
        } else {
            this.errorText = "Please select timeslot!!!";
        }
    }

    public checkOverride() {
        if(this.showOverRideApptChatLink && this.appointmentReservationNumber !== null) {
            this.retrieveARNCalled = true;
            this.reservation = true;
            this.resrvatnId.emit(this.appointmentReservationNumber);
            return false;
        }
        this.check = true;
        this.setAppointment();
        this.apptObservable = <Observable<any>>this.store.select('appointment');
        this.apptSubscription = this.apptObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            if (data && data !== undefined && data.overideAppointmentid && data.overideAppointmentid !== undefined) {
                this.appointmentid = data.overideAppointmentid;
            }
        })
        let request = {
            orderRefNumber: this.orderRefNumber,
            availableAppointment: {
                appointmentId: this.selectedAppointment.appointmentId,
                timeSlot: {
                    startDateTime: this.selectedAppointment.timeSlot.startDateTime,
                    endDateTime: this.selectedAppointment.timeSlot.endDateTime
                },
                commitmentDateTime: this.selectedAppointment.commitmentDateTime,
                defaultTimeSlot: true,
                allDayAppt: this.selectedAppointment.allDayAppt,
                timeSlotType: this.selectedAppointment.timeSlotType,
                timeSlotSource: this.selectedAppointment.timeSlotSource,
                overrideReqd: 'NO'
            }
        }
        this.logger.log("info", "datepicker.appointment.component.ts", "retrieveARNcodeRequest", JSON.stringify(request));
        this.logger.startTime();
        this.loading = true;
        this.schedulingService.retrieveARNcode(request)
            .catch((error: any) => { 
                this.logger.endTime();
                this.logger.log("error", "datepicker.appointment.component.ts", "retrieveARNcodeResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "retrieveARNcodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false; 
                return Observable.throw(error); })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "datepicker.appointment.component.ts", "retrieveARNcodeResponse", JSON.stringify(data));
                    this.logger.log("info", "datepicker.appointment.component.ts", "retrieveARNcodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    // this.loadAppointments(data.availableAppointment); // TODO
                    this.loading = false;
                    if (data && data.reservationId) {
                        this.appointmentReservationNumber = data && data.reservationId;
                        this.resrvatnId.emit(this.appointmentReservationNumber);
                        this.retrieveARNCalled = true;
                        this.reservation = true;
                    } else {
                        let errorresponse = data;
                        if (errorresponse && errorresponse.errorResponse && errorresponse.errorResponse[0] && errorresponse.errorResponse[0].messageDetail) {
                            let message = errorresponse.errorResponse[0].messageDetail;
                            this.appointmentReservationNumber = message.substring(message.indexOf(this.selectedAppointment.appointmentId), message.indexOf(this.selectedAppointment.appointmentId) + 10);
                            this.retrieveARNCalled = true;
                            this.reservation = false;
                        }
                    }
                }, (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "datepicker.appointment.component.ts", "retrieveARNcodeResponse", JSON.stringify(error));
                    this.logger.log("error", "datepicker.appointment.component.ts", "retrieveARNcodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let errorresponse = error.error;
                    if (errorresponse && errorresponse.errorResponse && errorresponse.errorResponse[0] && errorresponse.errorResponse[0].messageDetail) {
                        let message = errorresponse.errorResponse[0].messageDetail;
                        this.appointmentReservationNumber = message.substring(message.indexOf(this.selectedAppointment.appointmentId), message.indexOf(this.selectedAppointment.appointmentId) + 10);
                        this.retrieveARNCalled = true;
                        this.reservation = false;
                    }
                })
    }
    
    public cancelAppointment() {
        this.errorText = '';
        this.reservedDate = this.appointmentDate;
        this.reservedTime = this.appointmentTime;
        this.reservedDateRetain = this.appointmentDate;
        this.reservedTimeRetain = this.appointmentTime;
        this.reservedFullDate = this.appointmentFullDate;
        this.reservedAppointment = this.selectedAppointment;
        for (let data of this.dataArray) {
            if (data.day1 === 'selected') {
                data.day1 = '';
            }
            if (data.day2 === 'selected') {
                data.day2 = '';
            }
            if (data.day3 === 'selected') {
                data.day3 = '';
            }
            if (data.day4 === 'selected') {
                data.day4 = '';
            }
            if (data.day5 === 'selected') {
                data.day5 = '';
            }

            if (data.day6 === 'selected') {
                data.day6 = '';
            }
            if (data.day7 === 'selected') {
                data.day7 = '';
            }
        }
        this.highlightSelectedItem();
    }
    
    public firstDate: any;
    private loadAppointments(appointments: AvailableAppointment[]) {
        this._appointment = appointments;
        this.dataArray = [];
        let appointment;
        if (this._appointment && this._appointment.length > 0) {
            let defaultappointment = filter(this._appointment, { defaultTimeSlot: true });
            appointment = defaultappointment[0];
            let commitedDate = appointment.timeSlot.startDateTime;
            commitedDate = commitedDate.trim().substr(0, 10).replace(/-/g, '\/');
            let dateCommited = new Date(commitedDate);
            this.currentLeftDate = dateCommited;
            while (dateCommited.setHours(0, 0, 0, 0) < this.header.day1Date.setHours(0, 0, 0, 0) || dateCommited.setHours(0, 0, 0, 0) > this.header.day7Date.setHours(0, 0, 0, 0)) {
                if (dateCommited.setHours(0, 0, 0, 0) < this.header.day1Date.setHours(0, 0, 0, 0)) {
                    this.onLeftArrowClicked(false);
                } else
                    if (dateCommited.setHours(0, 0, 0, 0) > this.header.day7Date.setHours(0, 0, 0, 0)) {
                        this.onRightArrowClicked(false);
                    } else {
                        break;
                    }
            }
        }
        let defaultTimeSlotIndex = this._appointment && this._appointment.findIndex(apt => apt.defaultTimeSlot === true);
        this._appointment && this._appointment.splice(defaultTimeSlotIndex,1);
        this._appointment && this._appointment.unshift(appointment);
        this.prepareDataForHeader(this._appointment);
        if (this.appointmentSet || !this.isReEntrant) {
            this.setAppointment();
        }
    }

    private duplicateTime(dataArr, time, updatedslot) {
        var sample = [];
        if (this.isOverrideClicked || !this.isOverrideClicked) {
            dataArr.map(x => {
                sample.push(x[time]);
            });
            return sample.indexOf(updatedslot[time]);
        }
    }

    public getAppointmetDetailsByDay(data, day) {
        switch (day) {
            case 'day1': return data.day1Appointment;
            case 'day2': return data.day2Appointment;
            case 'day3': return data.day3Appointment;
            case 'day4': return data.day4Appointment;
            case 'day5': return data.day5Appointment;
            case 'day6': return data.day6Appointment;
            case 'day7': return data.day7Appointment;
        }
    }

    private selectIndexForSlot(data, day) {
        let ext;
        let existingObservable = <Observable<any>>this.store.select('existingProducts');
        let existingSubscription = existingObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe(
            (extt) => {
                ext = extt;
            });
        if (!this.isDefaultSlotSelected && !this.oneTimeCheck) {
            if (data) {
                let appointmentByDay = this.getAppointmetDetailsByDay(data, day);
                if (ext && ext.existingProductsAndServices && ext.existingProductsAndServices[0] &&
                    ext.existingProductsAndServices[0].pendingOrders && ext.existingProductsAndServices[0].pendingOrders[0]) {
                    let existingPendingOrderDataTC = ext.existingProductsAndServices[0].pendingOrders[0];
                    if (existingPendingOrderDataTC && existingPendingOrderDataTC.orderDocument && appointmentByDay && appointmentByDay.timeSlot) {
                        let dayPicker = day + 'Appointment';
                        if (data[dayPicker]) {
                            this.slotSelected(this.dataArray.indexOf(data), day);
                            this.isDefaultSlotSelected = true;
                            this.oneTimeCheck = true;
                        }
                    } else if (this.isStack || this.isAmend) {
                        let dayPicker = day + 'Appointment';
                        if (data[dayPicker]) {
                            this.slotSelected(this.dataArray.indexOf(data), day);
                            this.isDefaultSlotSelected = true;
                            this.oneTimeCheck = true;
                        }
                    }
                } else if (!this.isDefaultSlotSelected && !this.oneTimeCheck) {
                    let dayPicker = day + 'Appointment';
                    if (data[dayPicker].defaultTimeSlot) {
                        this.slotSelected(this.dataArray.indexOf(data), day);
                        this.isDefaultSlotSelected = true;
                        this.oneTimeCheck = true;
                    }
                }
            }
        }
        existingSubscription.unsubscribe();
    }

    private prepareDataForHeader(appointments: AvailableAppointment[]) {
        this.isDefaultSlotSelected = false;
        this.dataArray = [];
        if (appointments && appointments.length > 0) {
            for (let appointment of appointments) {
                let commitedDate = appointment.timeSlot.startDateTime;
                commitedDate = commitedDate.trim().substr(0, 10).replace(/-/g, '\/');
                let dateCommited = new Date(commitedDate);
                if (dateCommited.setHours(0, 0, 0, 0) === this.header.day1Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day1Data.length === 0) {
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day1Data = "ALL DAY";
                            } else {
                                data.day1Data = startDate + '-' + endDate;
                            }
                            data.day1Appointment = appointment;
                            data.day1 = '';
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day1');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: '',
                        day1Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day1Appointment: appointment,
                        day2: 'disabled',
                        day2Data: '',
                        day2Appointment: null,
                        day3: 'disabled',
                        day3Data: '',
                        day3Appointment: null,
                        day4: 'disabled',
                        day4Data: '',
                        day4Appointment: null,
                        day5: 'disabled',
                        day5Data: '',
                        day5Appointment: null,
                        day6: 'disabled',
                        day6Data: '',
                        day6Appointment: null,
                        day7: 'disabled',
                        day7Data: '',
                        day7Appointment: null
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day1Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day1');
                } else if (dateCommited.setHours(0, 0, 0, 0) === this.header.day2Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day2Data.length === 0) {
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day2Data = "ALL DAY";
                            } else {
                                data.day2Data = startDate + '-' + endDate;
                            }
                            data.day2Appointment = appointment;
                            data.day2 = '';
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day2');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: 'disabled',
                        day1Data: '',
                        day1Appointment: null,
                        day2: '',
                        day2Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day2Appointment: appointment,
                        day3: 'disabled',
                        day3Data: '',
                        day3Appointment: null,
                        day4: 'disabled',
                        day4Data: '',
                        day4Appointment: null,
                        day5: 'disabled',
                        day5Data: '',
                        day5Appointment: null,
                        day6: 'disabled',
                        day6Data: '',
                        day6Appointment: null,
                        day7: 'disabled',
                        day7Data: '',
                        day7Appointment: null
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day2Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day2');
                } else if (dateCommited.setHours(0, 0, 0, 0) === this.header.day3Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day3Data.length === 0) {
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day3Data = "ALL DAY";
                            } else {
                                data.day3Data = startDate + '-' + endDate;
                            }
                            data.day3Appointment = appointment;
                            data.day3 = '';
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day3');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: 'disabled',
                        day1Data: '',
                        day1Appointment: null,
                        day2: 'disabled',
                        day2Data: '',
                        day2Appointment: null,
                        day3: '',
                        day3Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day3Appointment: appointment,
                        day4: 'disabled',
                        day4Data: '',
                        day4Appointment: null,
                        day5: 'disabled',
                        day5Data: '',
                        day5Appointment: null,
                        day6: 'disabled',
                        day6Data: '',
                        day6Appointment: null,
                        day7: 'disabled',
                        day7Data: '',
                        day7Appointment: null
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day3Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day3');
                } else if (dateCommited.setHours(0, 0, 0, 0) === this.header.day4Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day4Data.length === 0) {
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day4Data = "ALL DAY";
                            } else {
                                data.day4Data = startDate + '-' + endDate;
                            }
                            data.day4Appointment = appointment;
                            data.day4 = '';
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day4');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: 'disabled',
                        day1Data: '',
                        day1Appointment: null,
                        day2: 'disabled',
                        day2Data: '',
                        day2Appointment: null,
                        day3: 'disabled',
                        day3Data: '',
                        day3Appointment: null,
                        day4: '',
                        day4Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day4Appointment: appointment,
                        day5: 'disabled',
                        day5Data: '',
                        day5Appointment: null,
                        day6: 'disabled',
                        day6Data: '',
                        day6Appointment: null,
                        day7: 'disabled',
                        day7Data: '',
                        day7Appointment: null
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day4Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day4');
                } else if (dateCommited.setHours(0, 0, 0, 0) === this.header.day5Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day5Data.length === 0) {
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day5Data = "ALL DAY";
                            } else {
                                data.day5Data = startDate + '-' + endDate;
                            }
                            data.day5Appointment = appointment;
                            data.day5 = '';
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day5');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: 'disabled',
                        day1Data: '',
                        day1Appointment: null,
                        day2: 'disabled',
                        day2Data: '',
                        day2Appointment: null,
                        day3: 'disabled',
                        day3Data: '',
                        day3Appointment: null,
                        day4: 'disabled',
                        day4Data: '',
                        day4Appointment: null,
                        day5: '',
                        day5Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day5Appointment: appointment,
                        day6: 'disabled',
                        day6Data: '',
                        day6Appointment: null,
                        day7: 'disabled',
                        day7Data: '',
                        day7Appointment: null
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day5Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day5');
                } else if (dateCommited.setHours(0, 0, 0, 0) === this.header.day6Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day6Data.length === 0) {
                            data.day6 = '';
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day6Data = "ALL DAY";
                            } else {
                                data.day6Data = startDate + '-' + endDate;
                            }
                            data.day6Appointment = appointment;
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day6');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: 'disabled',
                        day1Data: '',
                        day1Appointment: null,
                        day2: 'disabled',
                        day2Data: '',
                        day2Appointment: null,
                        day3: 'disabled',
                        day3Data: '',
                        day3Appointment: null,
                        day4: 'disabled',
                        day4Data: '',
                        day4Appointment: null,
                        day5: 'disabled',
                        day5Data: '',
                        day5Appointment: null,
                        day6: '',
                        day6Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day6Appointment: appointment,
                        day7: 'disabled',
                        day7Data: '',
                        day7Appointment: null
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day6Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day6');
                } else if (dateCommited.setHours(0, 0, 0, 0) === this.header.day7Date.setHours(0, 0, 0, 0)) {
                    let startDate = this.tConv24(appointment.timeSlot.startDateTime.substring(11, 16));
                    let endDate = this.tConv24(appointment.timeSlot.endDateTime.substring(11, 16));
                    let isDataSet = false;
                    for (let data of this.dataArray) {
                        if (data.day7Data.length === 0) {
                            data.day7 = '';
                            if (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) {
                                data.day7Data = "ALL DAY";
                            } else {
                                data.day7Data = startDate + '-' + endDate;
                            }
                            data.day7Appointment = appointment;
                            isDataSet = true;
                            this.selectIndexForSlot(data, 'day7');
                            break;
                        }
                    }
                    if (isDataSet) {
                        continue;
                    }
                    let data1 = {
                        day1: 'disabled',
                        day1Data: '',
                        day1Appointment: null,
                        day2: 'disabled',
                        day2Data: '',
                        day2Appointment: null,
                        day3: 'disabled',
                        day3Data: '',
                        day3Appointment: null,
                        day4: 'disabled',
                        day4Data: '',
                        day4Appointment: null,
                        day5: 'disabled',
                        day5Data: '',
                        day5Appointment: null,
                        day6: 'disabled',
                        day6Data: '',
                        day6Appointment: null,
                        day7: '',
                        day7Data: (appointment && appointment.allDayAppt !== undefined && appointment.allDayAppt) ? "ALL DAY" : startDate + '-' + endDate,
                        day7Appointment: appointment
                    };
                    var dataVal = this.duplicateTime(this.dataArray, "day7Data", data1);
                    if ((this.isOverrideClicked && dataVal === -1) || (!this.isOverrideClicked && dataVal === -1)) {
                        this.dataArray.push(data1);
                    }
                    this.selectIndexForSlot(data1, 'day7');
                }
            }
        }
        
            while (this.dataArray.length < 7) {
                let data = {
                    day1: 'disabled',
                    day1Data: '',
                    day1Appointment: null,
                    day2: 'disabled',
                    day2Data: '',
                    day2Appointment: null,
                    day3: 'disabled',
                    day3Data: '',
                    day3Appointment: null,
                    day4: 'disabled',
                    day4Data: '',
                    day4Appointment: null,
                    day5: 'disabled',
                    day5Data: '',
                    day5Appointment: null,
                    day6: 'disabled',
                    day6Data: '',
                    day6Appointment: null,
                    day7: 'disabled',
                    day7Data: '',
                    day7Appointment: null
                };
                this.dataArray.push(data);
            }
        
    }

    private tConv24(time24) {
        let ts = time24;
        let H = +ts.substr(0, 2);
        let h: any = (H % 12) || 12;
        h = (h < 10) ? ('0' + h) : h;
        let ampm = H < 12 ? ' AM' : ' PM';
        ts = h + ts.substr(2, 3) + ampm;
        return ts;
    }

    private setWeekInfo() {
        let firstMonth = this.monthNames[this.firstday];
        let lastMonth = this.monthNames[this.lastday];
        if (firstMonth === lastMonth) {
            this.weekInfo = firstMonth + ' ' + this.header.day1 + ' - ' + this.header.day7;
        } else {
            this.weekInfo = firstMonth + ' ' + this.header.day1 + ' - ' + lastMonth + ' ' + this.header.day7;
        }
    }

    private onLeftArrowClicked(populateData) {
        if (this.enableLeftClick) {
            let RIGHTDATE = this.header.day1Date;
            let LEFTDATE = new Date(RIGHTDATE.setDate(RIGHTDATE.getDate() - RIGHTDATE.getDay() - 7));
            let LEFTFIRSTDATE = new Date(LEFTDATE);
            RIGHTDATE = this.header.day1Date;
            let RIGHTENDDATE = new Date(RIGHTDATE.setDate(RIGHTDATE.getDate() - RIGHTDATE.getDay() + 6));
            this.currentLeftDate = cloneDeep(LEFTFIRSTDATE);
            this.currentRightDate = cloneDeep(RIGHTENDDATE);
            if (this.currentLeftDate.setHours(0, 0, 0, 0) <= this.firstDate.setHours(0, 0, 0, 0) && this.firstDate.setHours(0, 0, 0, 0) <= this.currentRightDate.setHours(0, 0, 0, 0)) {
                this.enableLeftClick = false;
            }
            let LEFTFIRSTWEEKNAME = LEFTFIRSTDATE.getMonth();
            let RIGHTWEEKNAME = RIGHTENDDATE.getMonth();
            this.header = {
                day1Date: LEFTDATE,
                day1Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay())).toString().split(' ')[0],
                day1: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay())).getDate(),
                day2Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 1)),
                day2Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 1)).toString().split(' ')[0],
                day2: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 1)).getDate(),
                day3Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 2)),
                day3Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 2)).toString().split(' ')[0],
                day3: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 2)).getDate(),
                day4Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 3)),
                day4Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 3)).toString().split(' ')[0],
                day4: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 3)).getDate(),
                day5Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 4)),
                day5Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 4)).toString().split(' ')[0],
                day5: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 4)).getDate(),
                day6Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 5)),
                day6Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 5)).toString().split(' ')[0],
                day6: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 5)).getDate(),
                day7Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 6)).toString().split(' ')[0],
                day7: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 6)).getDate(),
                day7Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 6))
            };
            let firstMonth = this.monthNames[LEFTFIRSTWEEKNAME];
            let lastMonth = this.monthNames[RIGHTWEEKNAME];
            if (firstMonth === lastMonth) {
                this.weekInfo = firstMonth + ' ' + this.header.day1 + ' - ' + this.header.day7;
            } else {
                this.weekInfo = firstMonth + ' ' + this.header.day1 + ' - ' + lastMonth + ' ' + this.header.day7;
            }
            if (populateData) {
                this.prepareDataForHeader(this._appointment);
            }
            this.highlightSelectedItem();
        }
    }

    private highlightSelectedItem() {
        let index = -1;
        if (this.ctlHelperService.convertDateFormat(this.header.day1Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
            index = 1;
        } else
            if (this.ctlHelperService.convertDateFormat(this.header.day2Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
                index = 2;
            } else
                if (this.ctlHelperService.convertDateFormat(this.header.day3Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
                    index = 3;
                } else
                    if (this.ctlHelperService.convertDateFormat(this.header.day4Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
                        index = 4;
                    } else
                        if (this.ctlHelperService.convertDateFormat(this.header.day5Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
                            index = 5;
                        } else
                            if (this.ctlHelperService.convertDateFormat(this.header.day6Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
                                index = 6;
                            } else
                                if (this.ctlHelperService.convertDateFormat(this.header.day7Date) === this.ctlHelperService.convertDateFormat(this.reservedFullDate)) {
                                    index = 7;
                                }
        if (index !== -1) {
            for (let data of this.dataArray) {
                if (data['day' + index + 'Data'] === this.reservedTime) {
                    data['day' + index] = 'selected';
                    break;
                }
            }
        }
    }

    public onRightArrowClicked(populateData) {
        if (this.enableRightClick) {
            let RIGHTDATE = this.header.day7Date;
            let LEFTDATE = new Date(RIGHTDATE.setDate(RIGHTDATE.getDate() - RIGHTDATE.getDay() + 7));
            let LEFTFIRSTDATE = new Date(LEFTDATE);
            RIGHTDATE = this.header.day7Date;
            let RIGHTENDDATE = new Date(RIGHTDATE.setDate(RIGHTDATE.getDate() - RIGHTDATE.getDay() + 6));
            if (populateData) {
                this.enableLeftClick = true;
                this.currentLeftDate = cloneDeep(LEFTFIRSTDATE);
                this.currentRightDate = cloneDeep(RIGHTENDDATE);
            }
            let LEFTFIRSTWEEKNAME = LEFTFIRSTDATE.getMonth();
            let RIGHTWEEKNAME = RIGHTENDDATE.getMonth();
            this.header = {
                day1Date: LEFTDATE,
                day1Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay())).toString().split(' ')[0],
                day1: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay())).getDate(),
                day2Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 1)),
                day2Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 1)).toString().split(' ')[0],
                day2: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 1)).getDate(),
                day3Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 2)),
                day3Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 2)).toString().split(' ')[0],
                day3: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 2)).getDate(),
                day4Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 3)),
                day4Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 3)).toString().split(' ')[0],
                day4: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 3)).getDate(),
                day5Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 4)),
                day5Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 4)).toString().split(' ')[0],
                day5: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 4)).getDate(),
                day6Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 5)),
                day6Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 5)).toString().split(' ')[0],
                day6: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 5)).getDate(),
                day7Name: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 6)).toString().split(' ')[0],
                day7: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 6)).getDate(),
                day7Date: new Date(LEFTFIRSTDATE.setDate(LEFTFIRSTDATE.getDate() - LEFTFIRSTDATE.getDay() + 6))
            };
            let firstMonth = this.monthNames[LEFTFIRSTWEEKNAME];
            let lastMonth = this.monthNames[RIGHTWEEKNAME];
            if (firstMonth === lastMonth) {
                this.weekInfo = firstMonth + ' ' + this.header.day1 + ' - ' + this.header.day7;
            } else {
                this.weekInfo = firstMonth + ' ' + this.header.day1 + ' - ' + lastMonth + ' ' + this.header.day7;
            }
            if (populateData) {
                this.prepareDataForHeader(this._appointment);
            }
            this.highlightSelectedItem();
            if (populateData && this.dataArray.length > 0) {
                let allEmpty = true;
                for (let i = 0; i < this.dataArray.length; i++) {
                    if (this.dataArray[i].day2Appointment === null ||
                        this.dataArray[i].day3Appointment === null ||
                        this.dataArray[i].day4Appointment === null ||
                        this.dataArray[i].day5Appointment === null ||
                        this.dataArray[i].day6Appointment === null) {
                        allEmpty = true;
                        break;
                    } else if (this.dataArray[i].day1Appointment !== null ||
                        this.dataArray[i].day2Appointment !== null ||
                        this.dataArray[i].day3Appointment !== null ||
                        this.dataArray[i].day4Appointment !== null ||
                        this.dataArray[i].day5Appointment !== null ||
                        this.dataArray[i].day6Appointment !== null ||
                        this.dataArray[i].day7Appointment !== null) {
                        allEmpty = false;
                        break;
                    }
                }
                if (allEmpty && this.header.day7Date.getTime() > this.rightMostDate.getTime()) {
                    this.overrideNormalApptCall();
                }
            }
        }
    }

    public slotSelected(i, day, flag?) {
        this.errorText = '';
        let reserveCounter = 0;
        //flag && flag === 'true' ? this.isReEntrant = false && reserveCounter++ : this.isReEntrant;
        if (i >= 0 && i < this.dataArray.length) {
            if (this.dataArray[i][day] === 'selected') {
                this.dataArray[i][day] = '';
                this.reservedTime = '';
                this.reservedDate = '';
                this.reservedAppointment = null;
            } else {
                for (let data of this.dataArray) {
                    if (data.day1 === 'selected') {
                        data.day1 = '';
                    }
                    if (data.day2 === 'selected') {
                        data.day2 = '';
                    }
                    if (data.day3 === 'selected') {
                        data.day3 = '';
                    }
                    if (data.day4 === 'selected') {
                        data.day4 = '';
                    }
                    if (data.day5 === 'selected') {
                        data.day5 = '';
                    }
                    if (data.day6 === 'selected') {
                        data.day6 = '';
                    }
                    if (data.day7 === 'selected') {
                        data.day7 = '';
                    }
                }
                if(!this.isReEntrant) { this.dataArray[i][day] = 'selected'; }
                this.reservedFullDate = new Date(this.header[day + 'Date'].valueOf());
                this.reservedTime = this.dataArray[i][day + 'Data'];
                this.reservedAppointment = this.dataArray[i][day + 'Appointment'];
                this.reservedDate = this.getFullDayName(this.header[day + 'Name']) + ' ' + this.monthFullNames[this.header[day + 'Date'].getMonth()] + ' ' + this.header[day];
            }
        }
        if(flag && flag === 'true' || !this.isReEntrant) { this.store.dispatch({ type: 'RETAIN_EARLIEST_APPT', payload: { earliestAppt: { reserveDate: this.reservedDate, reserveTime: this.reservedTime } } }); }
        this.retrieveARNCalled = false;
      //  flag && flag === 'true' ? this.isReEntrant = true : this.isReEntrant;
    }

    public lcOverrideRequestUpdates(request) {
        return request.payload.availableAppointment = {
            "appointmentId": this.appointmentid,
            "timeSlot": {
                "startDateTime": this.startDateTime,
                "endDateTime": this.endDateTime
            },
            "overrideReqd": "yes",
            "commitmentDateTime": this.commitmentDateTime,
            "timeSlotType": this.timeSlotType,
            "timeSlotSource": this.timeSlotSource
        };
    }

    public overrideApptCall() {
        if (!this.isOverrideClicked) {
            this.currentLeftDate = new Date();
        }
        let request: any;
        if (this.firstPendingFlag && this.multiplePendingflag) {
            request = {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "calculatedDueDate": this.CalculatedDueDate,
                    "startDateTime": this.currentLeftDate,
                    "endDateTime": this.secondPendingDuedate,
                    "unavailableSlotsReqd": "Yes"
                }
            };
        } else {
            request = {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "calculatedDueDate": this.CalculatedDueDate,
                    "startDateTime": this.currentLeftDate,
                    "unavailableSlotsReqd": "Yes"
                }
            };
        }
        if(this.showOverRideApptChatLink) {
            this.lcOverrideRequestUpdates(request);
        }
        this.loading = true;
        this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentRequest", JSON.stringify(request));
        this.logger.startTime();
        this.schedulingService.overRideAppointment(request, this.orderFlow)
            .catch((error: any) => { 
                this.logger.endTime(); 
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                return Observable.throw(error); })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(data));
                this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.taskId = data.taskId;
                this.processInstanceId = data.processInstanceId;
                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                this.store.dispatch({ type: 'PROCESSINSTANCEID', payload: data.processInstanceId });
                let latestApptData = data && data.payload && data.payload.availableAppointment;
                if (latestApptData) {
                    let appointment = <Observable<any>>this.store.select('appointment');
                    let appointmentlist = appointment
                    .pipe(takeUntil(this.ngOnDestroy$))
                    .subscribe((appointments) => {
                        if (appointments.payload.appointmentInfo.availableAppointment) {
                            appointments.payload.appointmentInfo.availableAppointment = latestApptData;
                        }
                    })
                    appointmentlist.unsubscribe();
                    if (!this.isOverrideClicked) {
                        this.isOverrideClicked = true;
                        this.overriddenAppointmentArray = latestApptData;
                        let commitedDateLast = latestApptData[latestApptData.length - 1];
                        this.rightMostDate = new Date(commitedDateLast.timeSlot.startDateTime);
                        this.enableLeftClick = true;
                        let appointment = cloneDeep(this.overriddenAppointmentArray[0]);
                        let commitedDate = appointment.timeSlot.startDateTime;
                        this.firstDate = new Date(commitedDate);
                    } else {
                        let commitedDate = latestApptData[latestApptData.length - 1];
                        this.rightMostDate = new Date(commitedDate.timeSlot.startDateTime);
                        if (latestApptData.length !== this.overriddenAppointmentArray.length) {
                            var c = latestApptData.concat(this.overriddenAppointmentArray);
                        } else {
                            c = this.overriddenAppointmentArray;
                        }
                        var d = c.filter(function (item, pos) { return c.indexOf(item) === pos });
                        this.overriddenAppointmentArray = cloneDeep(d);
                    }
                    this.appointmentReservationNumber = data.payload.reservationId;
                    this.loadAppointments(this.overriddenAppointmentArray);
                }
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (error === undefined || error === null)
                    return;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", this.apiResponseError);
                    } else unexpectedError = true;
                } else unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", lAPIErrorLists);
                }
            });
    }

    public isNormalClicked: boolean = false;
    public overrideApptCallRentrant() {
        if (!this.isOverrideClicked) {
            this.currentLeftDate = new Date();
        }
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((respData) => {
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.appointmentId && respData.selectedappointment.appointmentId !== undefined) {
                this.appointmentid = respData.selectedappointment.appointmentId;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.startDateTime && respData.selectedappointment.timeSlot.startDateTime !== undefined) {
                this.startDateTime = respData.selectedappointment.timeSlot.startDateTime;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.endDateTime && respData.selectedappointment.timeSlot.endDateTime !== undefined) {
                this.endDateTime = respData.selectedappointment.timeSlot.endDateTime;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.commitmentDateTime && respData.selectedappointment.commitmentDateTime !== undefined) {
                this.commitmentDateTime = respData.selectedappointment.commitmentDateTime;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlotSource && respData.selectedappointment.timeSlotSource !== undefined) {
                this.timeSlotSource = respData.selectedappointment.timeSlotSource;
            }
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlotType && respData.selectedappointment.timeSlotType !== undefined) {
                this.timeSlotType = respData.selectedappointment.timeSlotType;
            }
            if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
                this.accountRentrantValue = respData.accountreentrant;
            }
        });
        this.retainSubscription.unsubscribe();
        if (this.appointmentSet || !this.isReEntrant) {
            this.setAppointment();
        }
        
        this.currentLeftDate = new Date();
        let reentrantApiCall;
        if (this.firstPendingFlag && this.multiplePendingflag) {
            reentrantApiCall =
            {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "startDateTime": this.currentLeftDate,
                    "endDateTime": this.secondPendingDuedate,
                    "calculatedDueDate": this.CalculatedDueDate,
                    "unavailableSlotsReqd": 'Yes',
                    "existingAppointment": {
                        "appointmentId": this.appointmentid,
                        "timeSlot": {
                            "startDateTime": this.startDateTime,
                            "endDateTime": this.endDateTime
                        },
                        "overrideReqd": "yes",
                        "commitmentDateTime": this.commitmentDateTime,
                        "timeSlotType": this.timeSlotType,
                        "timeSlotSource": this.timeSlotSource
                    }
                }
            };
        } else {
            reentrantApiCall =
            {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "startDateTime": this.currentLeftDate,
                    "calculatedDueDate": this.CalculatedDueDate,
                    "unavailableSlotsReqd": 'Yes',
                    "existingAppointment": {
                        "appointmentId": this.appointmentid,
                        "timeSlot": {
                            "startDateTime": this.startDateTime,
                            "endDateTime": this.endDateTime
                        },
                        "overrideReqd": "yes",
                        "commitmentDateTime": this.commitmentDateTime,
                        "timeSlotType": this.timeSlotType,
                        "timeSlotSource": this.timeSlotSource
                    }
                }
            };
        }
        this.loading = true;
        this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentRequest", JSON.stringify(reentrantApiCall));
        this.logger.startTime();
        this.schedulingService.overRideAppointment(reentrantApiCall, this.orderFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                return Observable.throw(error);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(data));
                this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.taskId = data.taskId;
                this.processInstanceId = data.processInstanceId;
                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                this.store.dispatch({ type: 'PROCESSINSTANCEID', payload: data.processInstanceId });
                let latestApptData = data && data.payload && data.payload.availableAppointment;
                if (latestApptData) {
                    if (!this.isOverrideClicked) {
                        this.isOverrideClicked = true;
                        this.overriddenAppointmentArray = latestApptData;
                        let commitedDateLast = latestApptData[latestApptData.length - 1];
                        this.rightMostDate = new Date(commitedDateLast.timeSlot.startDateTime);
                        this.enableLeftClick = true;
                        let appointment = cloneDeep(this.overriddenAppointmentArray[0]);
                        let commitedDate = appointment.timeSlot.startDateTime;
                        this.firstDate = new Date(commitedDate);
                    } else {
                        let commitedDate = latestApptData[latestApptData.length - 1];
                        this.rightMostDate = new Date(commitedDate.timeSlot.startDateTime);
                        if (latestApptData.length !== this.overriddenAppointmentArray.length) {
                            var c = latestApptData.concat(this.overriddenAppointmentArray);
                        } else {
                            c = this.overriddenAppointmentArray;
                        }
                        var d = c.filter(function (item, pos) { return c.indexOf(item) === pos });
                        this.overriddenAppointmentArray = cloneDeep(d);
                    }
                    this.appointmentReservationNumber = data.payload.reservationId;
                    this.loadAppointments(this.overriddenAppointmentArray);
                }
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (error === undefined || error === null)
                    return;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", this.apiResponseError);
                    } else unexpectedError = true;
                } else unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", lAPIErrorLists);
                }
            });
    }

    public overrideNormalApptCall() {
        let request: any;
        if (this.firstPendingFlag && this.multiplePendingflag) {
            request = {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "calculatedDueDate": this.CalculatedDueDate,
                    "startDateTime": this.rightMostDate,
                    "endDateTime": this.secondPendingDuedate,
                    "unavailableSlotsReqd": this.isOverrideClicked ? 'Yes' : 'No'
                }
            };
        } else {
            request = {
                "orderRefNumber": this.orderRefNumber,
                "processInstanceId": this.processInstanceId,
                "taskId": this.taskId,
                "taskName": "Confirm Scheduling",
                "schedulingAction": "ADDITIONALSLOTS",
                "payload": {
                    "calculatedDueDate": this.CalculatedDueDate,
                    "startDateTime": this.rightMostDate,
                    "unavailableSlotsReqd": this.isOverrideClicked ? 'Yes' : 'No'
                }
            };
        }
        this.loading = true;
        this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentRequest", JSON.stringify(request));
        this.logger.startTime();
        this.schedulingService.overRideAppointment(request, this.orderFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                return Observable.throw(error);
            })
            .subscribe((data) => {
                this.logger.endTime();                
                this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(data));
                this.logger.log("info", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.taskId = data.taskId;
                this.processInstanceId = data.processInstanceId;
                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                this.store.dispatch({ type: 'PROCESSINSTANCEID', payload: data.processInstanceId });
                let latestApptData = data && data.payload && data.payload.availableAppointment;
                if (latestApptData) {
                    if (this.isOverrideClicked) {
                        let commitedDate = latestApptData[latestApptData.length - 1];
                        this.rightMostDate = new Date(commitedDate.timeSlot.startDateTime);
                        var c = latestApptData.concat(this.overriddenAppointmentArray);
                        var d = c.filter(function (item, pos) { return c.indexOf(item) === pos; });
                        this.overriddenAppointmentArray = cloneDeep(d);
                        this.loadAppointments(this.overriddenAppointmentArray);
                    } else {
                        let commitedDate = latestApptData[latestApptData.length - 1];
                        this.rightMostDate = new Date(commitedDate.timeSlot.startDateTime);
                            var c = latestApptData.concat(this.originalAppointmentArray);
                        
                        var d = c.filter(function (item, pos) { return c.indexOf(item) === pos });
                        this.originalAppointmentArray = cloneDeep(d);
                        this.loadAppointments(this.originalAppointmentArray);
                    }
                    this.appointmentReservationNumber = data.payload.reservationId;
                }
            }, (error) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", "datepicker.appointment.component.ts", "overRideAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (error === undefined || error === null)
                    return;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", this.apiResponseError);
                    } else unexpectedError = true;
                } else unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "Datepicker", "datepicker.appointment.component.ts", "Datepicker Page", lAPIErrorLists);
                }
            });
    }

    ngOnDestroy() {
        this.ngOnDestroy$.next();
    }
}