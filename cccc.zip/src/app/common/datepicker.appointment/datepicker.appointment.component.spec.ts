import { MockServer } from './../../MockServer.test';
/* tslint:disable */
import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { Http, BaseRequestOptions, ConnectionBackend, RequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { MockConnection } from '@angular/http/testing';
import { RouterModule, Router } from '@angular/router';
import { Component, Input, Output, EventEmitter} from '@angular/core';
import { AvailableAppointment,Appointment } from '../../common/models/appointment.model';
import { AppointmentDatePickerComponent } from './datepicker.appointment.component';
import { AppStore } from '../common/models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
/**
describe('DatePicker Appointment Component', () => {
	let mockRouter = {
		navigate: jasmine.createSpy('navigate')
    };
    let datePicker = new AppointmentDatePickerComponent();
    datePicker.enableLeftClick = true;
    datePicker.enableRightClick = true;
    let mockServ = new MockServer();
    let req = {
        taskName : 'Appointments'
    };
    let response:Appointment = mockServ.getResponseForRequest('submitTask',req);
	beforeEach(() => TestBed.configureTestingModule({
		providers: [
			BaseRequestOptions,
			{
				provide: Http,
				useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
					return new Http(backend, defaultOptions);
				},
				deps: [MockBackend, BaseRequestOptions]
			},
			{
				provide: Router,
				useValue: mockRouter
			},
			
		]
    }));

    
    // it('should call LeftArrwoCLicked...', () => {
    //     datePicker.enableLeftClick = true;
    //     datePicker.onLeftArrowClicked(true);
    //     expect(datePicker.enableLeftClick).toBe(true);
    // });


    it('should call set success with true...', () => {
        datePicker.Success = true;
        expect(datePicker.showSuccessImage).toBe(true);
    });

    it('should call set success with false...', () => {
        datePicker.Success = false;
        expect(datePicker.showSuccessImage).toBe(false);
    });

    it('should call set Appointments with data...', () => {
        datePicker.Appointment = response.payload.appointmentInfo.availableAppointment;
        expect(datePicker._appointment).toBe(response.payload.appointmentInfo.availableAppointment);
    });

    it('should call cancel Appointments with data...', () => {
        expect(datePicker.cancelAppointment()).toHaveBeenCalled;
    });


    it('should call getFullDayName  with value...', () => {
        expect(datePicker.getFullDayName('Sun')).toBe('Sunday');
        expect(datePicker.getFullDayName('Mon')).toBe('Monday');
        expect(datePicker.getFullDayName('Tue')).toBe('Tuesday');
        expect(datePicker.getFullDayName('Thu')).toBe('Thursday');
        expect(datePicker.getFullDayName('Fri')).toBe('Friday');
        expect(datePicker.getFullDayName('Sat')).toBe('Saturday');
        
        
    });
});
 */