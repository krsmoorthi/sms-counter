import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AccordionModule } from './accordion.module';

const html = `
  <accordion [closeOthers]="oneAtATime">

    <accordion-group heading="Panel 1"
                     [isOpen]="panels[0].isOpen">
      Content of panel 1
    </accordion-group>

    <accordion-group heading="Panel 2"
                     [isOpen]="panels[1].isOpen">
      Content of panel 2
    </accordion-group>

    <accordion-group heading="Panel 3"
                     [isOpen]="panels[2].isOpen">
      Content of panel 3
    </accordion-group>

  </accordion>
`;

function getPanels(element:HTMLElement):Element[] {
  return Array.from(element.querySelectorAll('accordion-group'));
}

function expectOpenPanels(nativeEl:HTMLElement, openPanelsDef:boolean[]):void {
  const panels = getPanels(nativeEl);
  expect(panels.length).toBe(openPanelsDef.length);
  for (let i = 0; i < panels.length; i++) {
    if (openPanelsDef[i] && panels.length > 0) {
      expect(panels[i].classList).toContain('panel-open');
    } else if(panels.length > 0){
      expect(panels[i].classList).not.toContain('panel-open');
    }
  }
}

function hasTitle(element:HTMLElement, str:string):boolean {
  return element.textContent === str;
}

describe('Component: Accordion', () => {
  let fixture:ComponentFixture<TestAccordionComponent>;
  let context:any;
  let element:any;

  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({declarations: [TestAccordionComponent], imports: [AccordionModule]});
    TestBed.overrideComponent(TestAccordionComponent, {set: {template: html}});
    fixture = TestBed.createComponent(TestAccordionComponent);
    context = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('should have no open panels', () => {
    expectOpenPanels(element, [false, false, false]);
  });

  it('should have open panel based on binding', () => {
    context.panels[1].isOpen = true;
    fixture.detectChanges();
    expectOpenPanels(element, [false, false, false]);
  });
  it('should have the appropriate heading', () => {
    const titles = Array.from(element.querySelectorAll('.panel-heading a span'));
    titles.forEach((title:HTMLElement, idx:number) => expect(hasTitle(title, `Panel ${idx + 1}`)).toBe(true));
  });
  it('should have only one open panel even if binding says otherwise', () => {
    context.panels[0].isOpen = true;
    context.panels[1].isOpen = true;
    // which of panels should be opened there? the first or the last one? (now - last)
    fixture.detectChanges();
    expectOpenPanels(element, [false, false, false]);
  });

});

@Component({
  selector: 'accordion-test',
  template: ''
})

class TestAccordionComponent {
  public oneAtATime:boolean = true;
  public panels:Array<any> = [
    {isOpen: false, isDisabled: false},
    {isOpen: false, isDisabled: false},
    {isOpen: false, isDisabled: false}
  ];
}
