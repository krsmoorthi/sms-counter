export interface DisconnectStore{
    disconnect_review_order: DisconnectReviewOrderModel;
	disconnect_review_order_submit: any;
	dtvExists?: any;
}
export interface DisconnectConfirmation{
    disconnectSubmitresponse:DisconnectConfirmModel
    formData:DisconnectReviewOrderForm;
}
export interface DisconnectReviewOrderForm {
	pricingCheck: string;
	remarks: string;
	disableNotification: string;
}
export interface DueDate {
	requestedDueDate: string;
	calculatedDueDate: string;
	finalDueDate: string;
	overrideFlag: boolean;
}

export interface Element {
	designator: string;
	value: string;
}

export interface SubAddres {
	sourceId?: any;
	source?: any;
	geoSubAddressId: number;
	combinedDesignator: string;
	elements: Element;
}

export interface LocationAttribute {
	isMdu: boolean;
	legacyProvider: string;
	rateCenter: string;
	npa: number;
	nxx: number;
	wireCenter: string;
	cala: string;
	tarCode: string;
	tta: number;
}

export interface BillingAddres {
	isValidated: boolean;
	streetAddress: string;
	streetNr: string;
	streetNamePrefix: string;
	streetName: string;
	streetType: string;
	locality: string;
	city: string;
	stateOrProvince: string;
	postCode: string;
	postCodeSuffix: string;
	source: string;
	subAddress: SubAddres;
	country: string;
	locationAttributes: LocationAttribute;
}

export interface AttributesCombination {
	name: string;
	value: string;
	uom?: any;
	isDefault: boolean;
	displayOrder: number;
}

export interface PurchasePrice {
	attributesCombination: AttributesCombination;
	pricetype: string;
	rc: number;
	otc: number;
	discountedRc: number;
	discountedOtc: number;
	currencyCode: string;
}

export interface ReturnEquipment {
	offerCategory: string;
	productType: string;
	productId: number;
	productName: string;
	isLeasedEquipment: boolean;
	purchasePrice: PurchasePrice;
}

export interface Charge {
	chargeType: string;
	chargeName: string;
	billAmount: number;
	discount: number;
	taxes: number;
}

export interface AdditionalNote {
	text: string;
}

export interface Payload {
	dueDate?: DueDate;
	billingAddress?: BillingAddres;
	isFinalBillAddressChanged?: boolean;
	returnEquipments?: ReturnEquipment[];
	returnDateOfEquipment?: string;
	charges?: Charge[];
	chargeSummaryAck?: boolean;
	additionalNotes?: AdditionalNote;
	disableCustomerNotification?: boolean;
	billEstimate: any;
	finalPaymentDate:any;
}

export interface DisconnectReviewOrderModel {
	success?: boolean;
	orderRefNumber: string;
	processInstanceId: string;
	taskId: string;
	taskName: string;
	payload: Payload;
}
export interface DisconnectConfirmModel {
	success: boolean;
	orderRefNumber: string;
	processInstanceId: string;
	taskId: string;
	taskName: string;
	payload: ConfirmPayload;
}

export interface ConfirmPayload {
    message:string;
    orderNumber:string;
}