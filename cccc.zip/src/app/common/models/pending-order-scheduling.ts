import { AddlOrderAttributes } from './customize-services.model';
export interface DueDate {
	calculatedDueDate: string;
	requestedDueDate?: any;
	finalDueDate: string;
	overrideFlag: boolean;
	effectiveBillDate?: any;
	isCRDAvailable?: any;
}

export interface DueDateExceptionDay {
	exceptionDate: string;
}

export interface ExceptionDaysInfo {
	durationStartDate: string;
	durationEndDate: string;
	dueDateExceptionDays: DueDateExceptionDay[];
}

export interface SubAddres {
	combinedDesignator: string;
	elements: any[];
	geoSubAddressId: string;
	source: string;
	sourceId: string;
}

export interface LocationAttribute {
	isMdu: boolean;
	legacyProvider: string;
	rateCenter: string;
	wirecenter: string;
	npa: string;
	nxx: string;
	tta: string;
	tarCode: string;
	cala: string;
}

export interface ShippingAddres {
	isValidated: boolean;
	streetAddress: string;
	streetNrFirstSuffix: string;
	streetNrFirst: string;
	streetName: string;
	streetType: string;
	streetNamePrefix?: any;
	city: string;
	locality: string;
	stateOrProvince: string;
	postCode: string;
	source: string;
	postCodeSuffix: string;
	country: string;
	subAddress: SubAddres;
	locationAttributes: LocationAttribute;
}

export interface ShippingInfo {
	shippingName?: any;
	shipDueDate?: any;
	shippingAddlInfo?: any;
	shippingAddress: ShippingAddres;
	isShipAddrSameAsServiceAddress: boolean;
	shippingMethod?: any;
}

export interface ProductAssociation {
	productAssociationType: string;
	productIds: any[];
}

export interface Price {
	priceType: string;
	frequency: string;
	currencyCode: string;
	provisioningAction?: any;
	discountedOtc: number;
	discountedRc: number;
	otc: number;
	rc: number;
	priceTypeDescription: string;
	priceKey: string;
}

export interface CompositeAttribute {
	attributeName: string;
	attributeValue: string;
	uom?: any;
}

export interface ProductAttribute {
	isDefault: boolean;
	displayOrder: number;
	isPriceable: boolean;
	prices: Price[];
	discounts?: any;
	compositeAttribute: CompositeAttribute[];
}

export interface CustomerOrderSubItem {
	quantity: number;
	productId: string;
	productName: string;
	action?: any;
	productType: string;
	componentType: string;
	productCategory: string;
	productAssociations: ProductAssociation[];
	productAttributes: ProductAttribute[];
}

export interface CustomerOrderItem {
	action?: any;
	catalogId: string;
	contractTerm: string;
	customerOrderSubItems: CustomerOrderSubItem[];
	discountedOtc: number;
	discountedRc: number;
	offerCategory: string;
	offerSubType: string;
	offerType: string;
	otc: number;
	productOfferingId: string;
	quantity: number;
	rc: number;
}

export interface Cart {
	catalogSpecId?: any;
	customerOrderItems: CustomerOrderItem[];
}

export interface Reason {
	code: string;
	description?: any;
	waiverFlag?: any;
	reasonType: string;
	reasonText: string;
	offerCategory?: any;
	terminationFee?: any;
	currencyCode?: any;
}

export interface EqpShipmentInfo {
	equipmentShipped: boolean;
	equipmentReturnDate: string;
}

export interface Payload {
	dueDate: DueDate;
	exceptionDaysInfo: ExceptionDaysInfo;
	exceptionfromDueDaysInfo?: ExceptionDaysInfo;
	appointmentInfo?: any;
	shippingInfo: ShippingInfo;
	catalogSpecId?: any;
	shippingOffers?: any;
	cart: Cart;
	reason: Reason[];
	eqpShipmentInfo: EqpShipmentInfo[];
	addlOrderAttributes?: AddlOrderAttributes[];
}

export interface PendingOrderScheduling {
	success: boolean;
	orderRefNumber: string;
	processInstanceId: string;
	taskId: string;
	taskName: string;
	payload: Payload;
}