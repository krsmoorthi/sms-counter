import { EnterpriseAddress } from './cart.model';
import { AccountInfo } from './account.model';
import { AddlOrderAttributes } from './customize-services.model';
export interface Order {
    success?: boolean;
    orderRefNumber: string;
    processInstanceId?: string;
    taskId: string;
    taskName?: string;
    payload: OrderPayload;
    rccDetails?: any;    
    loginDetails?:any;
}

export interface OrderPayload {
    orderSummary: OrderSummary;
    accountInfo: AccountInfo;
    paymentInfo: Payment[];
    billEstimate: BillEstimate;
    additionalInfo?: AdditionalInfo;
    orderRemarks?: OrderRemarks[];
    returnDateOfEquipment?: string;
    returnEquipments: any;
    addlOrderAttributes: AddlOrderAttributes[];
    currentBillQuote?: any;
}

export interface OrderSummary {
    orderDate?: string;
    finalDueDate: string;
    serviceAddress: EnterpriseAddress;
    appointmentInfo: AppointmentInfo;
    reservedTN: ReservedTN[];
    shippingInfo: ShippingInfo;
    apptNotes: Notes;
    contact?: Contact;
}

export interface ReservedTN {
    productType: string;
    requestedTelephoneNumber: number;
    mainTelephoneNumber: number;
    stateOrProvince: string;
}

export interface AppointmentInfo {
    appointmentId: string;
    commitmentDateTime: string;
    reservationId: number;
    timeSlot: TimeSlot;
    timeSlotSource: string;
    timeSlotType: string;
}

export interface TimeSlot {
    startDateTime: string;
    endDateTime: string;
}

export interface ShippingInfo {
    shippingDate: string;
    shippingName: string;
    ShippingAddlInfo: string;
    isShipAddrSameAsServiceAddress : boolean;
    shippingAddress: EnterpriseAddress;
}

export interface Notes {
    animalsPresent: boolean;
    electricFence: boolean;
    lockedGate: boolean;
    notes: Remarks[];
}

export interface Remarks {
    name: number;
    value: string;
    date?: string;
    author?: string;
}

export interface Contact {
    contactNumber: number;
    smsNumber: number;
    emailAddress?: string;
    emailAddrDeclined?: boolean;
    disableNotifications?: boolean;
}
// completes Order Summary

// export interface AccountInfo {
//     customerInfo: CustomerInfo;
//     billingAddress: BillingAddress;
//     ban: string;
//     accountPin: string;
//     billCycle: string;
//     accountType: string;
//     accountPreferences: AccountPreferences;
//     contact: Contact;
//     accountName?: ContactInfo;
//     billingAddressType?: string;
//     billingAdditionalInfo?: string;
//     isBillAddrSameAsServiceAddress?: boolean;
// }

export interface BillingAddress {
    isSameAsServiceAddress: boolean;
    address: EnterpriseAddress;
}

export interface CustomerInfo {
    businessName: string;
    firstName: string;
    generation: string;
    lastName: string;
    middleName: string;
    title: string;
}

export interface AccountPreferences {
    paperlessBilling: boolean;
    spanishBillPrint: boolean;
    largePrint: boolean;
    braille: boolean;
    noTeleMarketing: boolean;
    noEmail: boolean;
    noDirectMail: boolean;
    emailNotification: Notification;
    textNotification: Notification;
}

// export interface BillingOptions {}

export interface Notification {
    billingNotification: boolean;
    orderingNotification: boolean;
    repairNotification: boolean;
}
// completes Account Info

export interface Payment {
    id?: string;
    depositCollected?: number;
    totalDeposit?: number;
    ban?: string;
    paidAmount?: number;
    paymentDate: string;
    paymentMethod: string;
    paymentRefNo?: string;
    totalPaymentDue?: string;
    lastFourDigitsCreditCard?: string;
    paymentType?: string;
    noOfInstallments?: string;
    serviceGroup?: string;
    subServiceGroup?: string;
}
// Completes Payment

export interface BillEstimate {
    month: Month[];
}

export interface Month {
    monthId: string;
    charges: Charges[];
}

export interface Charges {
    chargeType: string;
    prorated: boolean;
    summary: BillSummary;
    details: BillDetails[];
}

export interface BillSummary {
    totalBillAmount: number;
    totalDiscount: number;
    totalTaxes: number;
}

export interface BillDetails {
    serviceCategory: string;
    serviceSubscriptionId: string;
    primaryService: BillService[];
    additionalServices: BillService[];
}

export interface BillService {
    productName: string;
    componentType: string;
    billAmount: number;
    discountAmount: number;
    taxes: Taxes;
}

export interface Taxes {
    cassSalesTAX: number;
    federalExciseTAX: number;
    stateSalesTAX: number;
}
// Completes Bill Estimates

export interface OrderNotes {
    additionalInfo?: AdditionalInfo;
    orderRemarks?: OrderRemarks[];
    // chargeSummaryAck?: boolean;
    additionalNotes?: {
        text: string;
    };
    disableNotifications?: boolean;
    dealerCodeChangeInfo?: any;
    partnerInfo?: {
        isPartnerFlag: boolean,
        partnerOrderID: string,
        partnerReferenceID: string,
    }
}

export interface OrderRq {
    orderRefNumber?: string;
    processInstanceId?: string;
    taskId?: string;
    taskName?: string;
    payload?: OrderNotes;
}

export interface ReviewProductInformation {
    terms?: string;
    offerName?: string;
    isAutopay?: boolean;
    internetExpiry?: string;
    prismExpiry?: string;
    dhpExpiry?: string;
    autopayRate?: number;
    etf?: number;
}

export interface AdditionalInfo {
    chargeSummaryAck?: boolean;
    disableOrderNotification?: boolean;
}

export interface OrderRemarks {
    name?: string;
    value?: string;
    date?: string;
    author?: string;
}
