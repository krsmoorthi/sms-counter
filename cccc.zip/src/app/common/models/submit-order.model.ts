export interface SubmitOrder {
    orderNumber:string;
    message:string;
}