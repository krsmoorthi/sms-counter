import { AppointmentPayload } from "app/common/models/appointment.model";
export interface DueDate {
	calculatedDueDate: string;
	requestedDueDate?: any;
	finalDueDate: string;
	overrideFlag: boolean;
	effectiveBillDate?: string;
	isCRDAvailable?: boolean;
}

export interface TimeSlot {
	startDateTime: string;
	endDateTime: string;
}

export interface AvailableAppointment {
	appointmentId: string;
	timeSlot: TimeSlot;
	timeSlotType: string;
	commitmentDateTime: string;
	timeSlotSource: string;
}

export interface ApptNote {
	animalsPresent: boolean;
	electricFence: boolean;
	lockedGate: boolean;
	notes: any[];
}

export interface AppointmentInfo {
	availableAppointment: AvailableAppointment[];
	apptNotes: ApptNote;
}

export interface SubAddres {
	combinedDesignator: string;
	elements: any[];
	geoSubAddressId: string;
	source: string;
	sourceId: string;
}

export interface LocationAttribute {
	isMdu: boolean;
	legacyProvider: string;
	rateCenter: string;
	wirecenter: string;
	npa: string;
	nxx: string;
	tta: string;
	tarCode: string;
	cala: string;
}

export interface ShippingAddres {
	isValidated: boolean;
	streetAddress: string;
	streetNrFirstSuffix: string;
	streetNrFirst: string;
	streetName: string;
	streetType: string;
	streetNamePrefix?: any;
	city: string;
	locality: string;
	stateOrProvince: string;
	postCode: string;
	source: string;
	postCodeSuffix: string;
	country: string;
	subAddress: SubAddres;
	locationAttributes: LocationAttribute;
}

export interface ShippingInfo {
	shippingName?: any;
	shippingAddlInfo?: any;
	shippingAddress?: any;
	isShipAddrSameAsServiceAddress: boolean;
	shippingMethod?: any;
}

export interface ProductAssociation {
	productAssociationType: string;
	productIds: any[];
}

export interface Price {
	priceKey: string;
	priceType: string;
	frequency: string;
	currencyCode: string;
	provisioningAction?: any;
	discountedOtc: number;
	discountedRc: number;
	otc: number;
	rc: number;
	priceTypeDescription: string;
}

export interface CompositeAttribute {
	attributeName: string;
	attributeValue: string;
	uom?: any;
}

export interface ProductAttribute {
	isDefault: boolean;
	displayOrder: number;
	isPriceable: boolean;
	prices: Price[];
	discounts?: any;
	compositeAttribute: CompositeAttribute[];
}

export interface CustomerOrderSubItem {
	quantity: number;
	productId: string;
	productName: string;
	productType: string;
	componentType: string;
	productCategory: string;
	productAssociations: ProductAssociation[];
	productAttributes: ProductAttribute[];
}

export interface CustomerOrderItem {
	catalogId: string;
	offerType: string;
	offerSubType: string;
	offerCategory: string;
	contractTerm: string;
	quantity: number;
	rc: number;
	otc: number;
	discountedOtc: number;
	discountedRc: number;
	productOfferingId: string;
	customerOrderSubItems: CustomerOrderSubItem[];
}

export interface Cart {
	catalogSpecId?: any;
	customerOrderItems: CustomerOrderItem[];
}

export interface Payload {
	dueDate: DueDate;
	exceptionDaysInfo?: ExceptionDaysInfo;
	addlOrderAttributes?: any;
	appointmentInfo: AppointmentInfo;
	shippingInfo: ShippingInfo;
	cart: Cart;
	reason?:any;
	referralRequired?: any;
	productConfiguration?: any;
	billeffectiveDateInfo?: any;
    offers?: any;
}

export interface ExceptionDaysInfo {
	durationEndDate? : string;
	durationStartDate?: string;
	dueDateExceptionDays?: DueDateExceptionDays[];
}

export interface DueDateExceptionDays {
	exceptionDate?: string;
}

export interface AppointmentShipping {
    appointmentInfoNoValue?: boolean;
	success: boolean;
	orderRefNumber: string;
	processInstanceId: string;
	taskId: string;
	taskName: string;
	payload: AppointmentPayload;
	reservedCbr?: any;
	effectiveBillDateChange?: boolean;
}