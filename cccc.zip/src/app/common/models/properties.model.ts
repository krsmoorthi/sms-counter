/**
 * Properties API Response Interface
 * Response from API for Properties
**/

export interface Properties {
    system?: string;
    properties?: PropertiesKeyValue[];
}

export interface PropertiesKeyValue {
	name?: string;
	value?: string[];
}
