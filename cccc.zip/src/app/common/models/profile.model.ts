
/**
 * Profile API Response Interface
 * Response from API for Profile
**/

export interface Profile {
    profileId?: string;
    loginType?: string;
    validEshopProfile?: boolean;
    securityElements?: SecurityElement[]
}

export interface SecurityElement {
    securityElementName?: string,
    securityElementFlag?: string
}
