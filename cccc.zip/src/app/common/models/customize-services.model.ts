import { Cart } from './cart.model';
import { ServiceCategoryBasedOffers, OfferAttributes } from './product.model';

/**
 * CustomizeServices data model
 */
export interface CustomizeServices {
    success?: boolean;
    orderRefNumber: string;
    processInstanceId: string;
    taskId: string;
    taskName: string;
    payload: PayloadCustomAddOn;    
}

export interface PayloadCustomAddOn {
    catalogSpecId?: string; // number
    addOnOffers?: ServiceCategoryBasedOffers[];
    cart: Cart;
    reservedTN: ReservedTN[];
    productConfiguration: ProductConfiguration[];
    addlOrderAttributes?: AddlOrderAttributes[];
    lifeLineConfiguration?: any;    
    portCheckSimplePortFlag?:any;
    allowOTCAdjustment?:string;
}

export interface AddlOrderAttributes {
    orderAttributeGroup: OrderAttributeGroup[]
}

export interface OrderAttributeGroup {
    orderAttributeGroupName: string;
    orderAttributeGroupInfo: OrderAttributeGroupInfo[];
}

export interface OrderAttributeGroupInfo {
    orderAttributes: OrderAttributes[];
}

export interface OrderAttributes {
    orderAttributeName?: string;
    orderAttributeValue?: string;
}

export interface ReservedTN {
    productType: string;
    requestedTelephoneNumber: string;
    mainTelephoneNumber?: string;
    stateOrProvince?: string;
    tnType?: string;
    workingTN?: string;
}

export interface ProductConfiguration {
    productType: string;
    // requiredItems: RequiredItems[];
    // optionalItems: OfferAttributes[];
    configItems: ConfigItems[];
}

export interface ConfigItems {
    configDetails: ConfigDetails[];
    productId: string;
    productName: string;
}

export interface ConfigDetails {
    formItems: FormItems[];
    formName: string;
    isConfigRequired: boolean;
}

export interface FormItems {
    attributeName: string;
    attributeType: string;
    attributeValue: AttributeValue[];
    isMandatory: boolean;
}

export interface AttributeValue {
    isDefault: boolean;
    value: string;
}

export interface RequiredItems {
    productId: string;
    productName: string;
    additionConfiguration: AdditionConfiguration[];
}

export interface AdditionConfiguration {
    formName: string;
    formItems: OfferAttributes[];
}
