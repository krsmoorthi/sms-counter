import { ContactInfo, EnterpriseAddress } from './cart.model';

/**
 * Account API Response Interface
 * Respose from API for new account creation
**/

export interface AccountInfomation {
    success?: boolean;
    orderRefNumber?: string;
    processInstanceId?: string;
    taskId?: string;
    taskName?: string;
    payload: AccountInfo;
    addressType?: any;
    personaldetails?: any;
    contact?: any;
    accountPassword?: any;
    accountPreferences?: any;
    accountreentrant?: any;
    moveaccountreentrant?: any;
    accountReqDetails?: any;
    billingaddr?: any;
    isAuthorizedParties?:AuthUsersList;
    loginDetails?:any;
}

export interface AccountInfo {
    accountName?: ContactInfo;
    paperlessInfo?: PaperlessInfo;
    billingAddress?: EnterpriseAddress;
    ban?: string;
    accountPin?: string;
    billCycle?: string;
    accountType?: string;
    accountSubType?: string;
    creditClass?: string;
    geoCode?: string;
    contact?: AccountContactDetails;
    personalDetails?: PersonalDetails;
    accountPreferences?: AccountPreferences;
    billingAddressType?: string;
    billingAdditionalInfo?: string;
    isBillAddrSameAsServiceAddress?: boolean;
    accountInfo?: any;
    depositInfo?: any;
    personaldetails?: any;
    accountPassword?: any;
    billingaddr?: any;
    addlOrderAttributes?: any;
    creditInfo?: any;
    paymentDetails?: any;
    loginDetails?:LoginDetails;
}

export interface AccountContactDetails {
    contactNumber?: string;
    smsNumber?: string;
    emailAddress?: string;
    emailAddrDeclined?: boolean;
    disableNotifications?: boolean;
}

export interface PersonalDetails {
    dLExpirationDate?: string;
    dLlicenseNo?: string;
    dLlicenseState?: string;
    dateOfBirth?: string;
    ssn?: string;
    taxId?: string;
    creditCheck?: boolean;
    underAgeAck?: boolean;
}

export interface LoginDetails {
    secretAnswer?: string;
    secretQuestion?: string;
    userPassword?: string;
    userName?: string;
}

export interface AccountPreferences {
    paperlessBilling?: boolean;
    spanishBillPrint?: boolean;
    largePrint?: boolean;
    braille?: boolean;
    noTeleMarketing?: boolean;
    noEmail?: boolean;
    noDirectMail?: boolean;
    emailNotification?: NotificationSettings;
    textNotification?: NotificationSettings;
}

export interface AuthUsersList{
    firstNameFirst:string,
    lastNameFirst:string,
    contactFirst:number,
    firstNameSecond:string,
    lasttNameSecond:string,
    contactSecond:number
}

export interface NotificationSettings {
    billingNotification?: boolean;
    orderingNotification?: boolean;
    repairNotification?: boolean;
}

export interface PaperlessInfo {
    paperlessBilling?: boolean;
    emailAddress?: string;
    isPaperlessBillAllowed?: boolean;
}