import { AutoLogin } from './auto-login.model';
import { Profile } from './profile.model';
import { EnterpriseAddress } from './cart.model';
import { OrderInit } from './product.model';
import { SystemError } from './common.model';
import { SecurityError } from './common.model';
import { DisclosuresRes } from './disclosures.model';
import { ProfileFlags } from './offers.model';
import { Properties } from './properties.model';

/**
 * User detail data model
 */
export interface User {
    id: number;
    profile?: Profile;
    properties?: Properties;
    email?: string;
    token?: string;                     // User service auth token
    jwtToken?: string;                  // API Token
    previousUrl?: string;
    orderId?: string;
    message?: string;
    orderInit?: OrderInit;
    enteredAddress?: string;
    paymentdepositdata?: any;
    finalAddress?: EnterpriseAddress;
    yellowAddress?: EnterpriseAddress[];
    internetCheck?: boolean;
    videoCheck?: boolean;
    phoneCheck?: boolean;
    username?: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    companyName?: string;
    einNumber?: string;
    currentUrl?: string;
    fingerPrint?: string;
    phoneType?: any[];
    videoType?: any[];
    enabledServiceList?: any[];
    securityError?: SecurityError;
    systemError?: SystemError;
    currentSelected?: any[];
    dtvOpus?: any;
    dtvQuestionForm?: any;
    isDtvOpus?: boolean;
    taskId?: string;
    reEntrant?: boolean;
    ban?: any;
    paymentDone?: boolean;
    freezePage?: boolean;
    userName?: string;
    ipAddress?: string;
    browserType?: string;
    browserVersion?: string;
    osType?: string;
    osVersion?: string;
    mobileIndicator?: string;
    eshopChannel?: string;
    autoLogin?: AutoLogin;
    oTCustomize?: boolean;
    ccDone?: boolean;
    isDisconnectLandLineSelected?: boolean;
    shippingName?: string;
    selfinstallselected?: boolean;
    offerDisplayName?: any;
    orderRefNumber?: string;
    techInstallSelected?: boolean;
    paymentStatusChk?: boolean;
    orderDisclosers?: DisclosuresRes;
    profileFlags?: ProfileFlags;
    existsServices?: string[];
    prepaidFlag?: string;
    emailAddress?: string[];
    showRefundBanner?: any;
    workingServiceInfo?: any[];
    locationAvailable?: any;
}
