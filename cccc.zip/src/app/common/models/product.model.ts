export interface Product {
    success: boolean;
    orderRefNumber: string;
    processInstanceId: string;
    taskId: string;
    taskName: string;
     payload?: PayloadProduct;
}

export interface filterObjModel{
    name: string;
    isExist : boolean;
}

export interface PayloadProduct {
    catalogSpecId?: string;
    retrievalTypes?: RetrievalTypes[];
    offers?: ServiceCategoryBasedOffers[];
    cart?: Cart;
    productConfiguration?: any;
     giftCardOffers?:any[];
    // offerSummary?: OfferSummary[];
}

export interface RetrievalTypes {
    retrievalType: string;
    offers?: ServiceCategoryBasedOffers[];
}

export interface Cart {
    catalogSpecId?: string;
}

export interface ServiceCategoryBasedOffers {
    serviceCategory: string;
    catalogs: Catalogs[];
    offerDataLinkURL?: string;
}

export interface Catalogs {
    catalogId?: string;
    catalogType?: string;
    catalogName?: string;
    offerCategory?: string;
    catalogItems: ProductOfferings[];
}

export interface ProductOfferings {
    displayOrder?: number;
    isDefault?: any;
    productOfferingId?: string;
    productOffer?: ProductOffer;
    // category?: Category[];
    defaultOfferPrice?: DefaultOfferPrice;
}

export interface Category {
    categoryId: number;
    name: string;
    description: string;
    isRoot: boolean;
    lastUpdate: string;
   lifecycleStatus: string;
    parentId: number;
}

export interface ProductOffer {
    productOfferingId?: string;
    offerCategory?: string;
    offerDisplayName?: string;
    offerName?: string;
    offerSubType?: string;
    offerType: string;
    validFor?: ValidFor;
    contract: Contract;
    productComponents?: OfferProductComponents[];
    associatedOffers?: AssociatedOffers[];
    categoryId?: string;
    description?: string;
    name?: string;
    productOfferingAssociations?: ProductOfferingAssociations[];
    offerAttributes: OfferAttributes[];
    offerBillingType?:string;
}

export interface OfferAttributes {
    attributeName: string;
    attributeValue: string;
}

export interface AssociatedOffers {
    associatedOfferCategory?: string;
    associationType?: AssociationType;
}

export interface AssociationType {
    associationType?: string;
    selectionRule?: string;
    associatedOfferIds?: AssociatedOfferIds[];
}

export interface AssociatedOfferIds {
    associatedOfferId?: string;
    displayOrder?: number;
    discount?: Discounts;
}

export interface ProductOfferingAssociations {
    productOfferingAssociationType: string;
    productOfferings: ProductOfferingAssoc[];
}

export interface ProductOfferingAssoc {
    displayOrder: number;
    productOfferingId: number;
}

export interface ValidFor {
    salesStartDateTime: string;
    salesEndDateTime: string;
    saleEffectiveDate?: string;
    saleExpirationDate?: string;
    saleExpired?: string;
    bundleSaleExpired?: string;
}
export interface Contract {
    isPriceLock: boolean;
    priceLockDuration: number;
    priceTerm?: string;
    contractTerm?: any; // string
    currencyCode?: string;
    etf: number;
}

export interface OfferProductComponents {
    componentType?: string;
    displayOrder?: number;
    isDefault?: any;
    isMandatory?: boolean;
    product?: Products;
    additionalUiAttrProduct?:AddAttr;
}

export interface AddAttr {
    includedFlag: string;
    iSConfigurableOnAddOn: string;
    productSubCategory: string;
    grpMinSelect: string;
    grpMaxSelect: string;
    selectionGroup: string;
    selectionTextForUi: any;
    subGroup: string;
}


export interface Products {
    productId?: string;
    isRegulated?: boolean;
    productName?: string;
    productDisplayName?: string;
    productType?: string;
    componentType?: string;
    productAttributes?: AttributesCombination[];
    productAssociations?: ProductAssociations[];
    productCategory?: string;
    quantity?: any;
    action?: string;
    productOfferingId?: string;
    additionalUiAttrProduct?: any;
    provisioningAction?: any;
    dontShow?: boolean;
    productCategoryDisplayName?: any;
}

export interface ProductAssociations {
    productAssociationType?: string;
    productId?: number;
}

export interface BillingOnlyCharges {
    name?: string;
    rc: number;
    otc: number;
    frequency?: string;
    currencyCode?: string;
    provisioningAction?: string;
}

export interface Prices {
    currencyCode?: string;
    discountedOtc?: number;
    discountedRc?: number;
    frequency?: string;
    otc?: number;
    priceKey?: string;
    priceType?: string;
    priceTypeDescription?: string;
    provisioningAction?: string;
    rc?: number;
}

export interface AttributesCombination {
    displayOrder?: number;
    isDefault?: any;
    isPriceable?: boolean;
    compositeAttribute?: CompositeAttribute[];
    prices?: Prices[];
    discounts?: Discounts[];
}

export interface CompositeAttribute {
    attributeName?: string;
    attributeValue?: string;
    attributeDisplayName?: string;
    uom?: string;
}

export interface Discounts {
    autoAttachInd?: string;
    discountCategory?: string;
    discountDescription?: string;
    discountDuration?: number;
    discountId?: string;
    discountAmount?: number;
    discountIdSequence?: number;
    discountLevel?: string;
    discountMaxAmount?: number;
    discountMethod?: string;
    discountMinimumAmount?: number;
    discountRate?: number;
    discountRule?: string;
    discountType?: string;
}

/* OrderInit*/
export interface OrderInit {
    orderRefNumber: string;
    processInstanceId?: string;
    taskId: string;
    taskName?: string;
    qualification?: OrderInitPayload;
    payload?: OrderInitPayload;
    success?: boolean;
}

export interface OrderInitPayload {
    newLocation?: NewLocation;
    geoAddressId?: string;
    qualificationResult?: string;
    serviceCategory?: ServiceCategoryId[];
    catalogs?: Catalogs;
    serviceAddress?:any;
}

export interface NewLocation {
    serviceCategory?: ServiceCategoryId[];
    serviceAddress?:any;
}

export interface ServiceCategoryId {
    id?: number;
    name?: string;
    accessType?: string;
    serviceCategory?: string;
    serviceDescription?: string;
    serviceQualification?: ServiceQual;
    orderFeasibilityCheck?: OrderFeasible[];
    serviceCharacteristic?: ServiceCharacteristic[]; // AttributesCombination[];
}

export interface ServiceCharacteristic {
    displayOrder?: number;
    isDefault?: boolean;
    name?: string;
    uom?: string;
    value?: string;
}

export interface ServiceQual {
    qualificationResult: string;
    comment: string;
    qualificationResultDate: string;
}

export interface OrderFeasible {
    eligibilityResult: string;
    eligibilityUnavailablityReason: EligiblityReason[];
}

export interface EligiblityReason {
    code: string;
    label: string;
}
export interface OfferSummary {
    serviceCategoryId?: string;
    offerGroup?: OfferGroup[];
}
export interface OfferGroup {
    offerItems?: OfferItems[];
    prices?: Prices[];
}
export interface OfferItems {
    productOfferingId?: string;
    offerName?: string;
    offerDisplayName?: string;
    offerCategory?: string;
    offerBillingType?:string;
}
export interface DefaultOfferPrice {
    rc?: number;
    otc?: number;
    discountedRc?: number;
    discountedOtc?: number;
}

export interface RetainedPotsBooleans {
    retainValueForPotsJack?: any;
    wireMaintainance?: any;
    voiceMail?: any;
    portingCheck?: any;
    selectedMaintainance?: any;
    isInternational?: any;
}
