import { EnterpriseAddress } from './cart.model';
import { AccountInfo } from './account.model';

/**
 * CreditCheck data model
 */
export interface CreditCheck {
    success?: boolean;
    orderRefNumber: string;
    processInstanceId: string;
    taskId: string;
    taskName: string;
    payload: CreditCheckPayload;
    creditcheckedaddlattr?:any;
    creditchecked?:any; 
    creditreviewdepositdata?:any;
    paymentdone?:any;
    credit_detail?:any;
}

export interface CreditCheckPayload {
    success?: boolean;
    accountInfo?: AccountInfo;
    creditInfo?: CreditInfo;
    depositInfo?: DepositInfo;
    depositBillpaymentURL?: BillURL;
    finalBillpaymentURL?: BillURL;
    addlOrderAttributes?: any;
    paymentDetails?: any;
    pastDueAmount?:any;
    currentBillQuote?:any;    
    paymentInfo?:any;
}

export interface BillURL {
    paymentCategory?: string;
    paymentURL?: string;
    sessionId?: string;
}

export interface CreditInfo {
    success?: boolean;
    pastDueFound?: boolean;
    creditRiskRating?: string;
    customerAccounts?: CustomerAccount[];
    finalBillInfo?: FinalBillInfo[];
    creditClass?: string;
    finalBillInd?: boolean;
    creditApplicationRefNumber?: any;
}

export interface FinalBillInfo {
    btn?: string;
    cusCode?: number;
    entityFinalBillFlag?: boolean;
    finalBillAddress?: EnterpriseAddress;
    finalBillAmt?: Amount;
    finalBillDate?: string;
    finalBillEntityList?: FinalBillEntity;
    finalBillName?: string;
    paymentRequiredInd?: boolean;
    ssn?: string;
}

export interface Amount {
    amount?: number;
}

export interface FinalBillEntity {
    finalBillEntity?: Entity;
}

export interface Entity {
    entityCode?: string;
    dueAmt?: number;
}

export interface CustomerAccount {
    serviceReturn?: ServiceReturn;
    isFinalBill?: boolean;
    name?: string;
    customerAccountIdentification?: AccountIdentification;
    customerAccountAddresses?: EnterpriseAddress;
    creditCompanySourceCustomerAccountBalances?: AccountBalance[];
    internalSourceCustomerAccountBalances?: AccountBalance;
    paymentURL?: PaymentURL;
}

export interface ServiceReturn {
    hasErrors?: boolean;
    messageKeys?: ErrorDetails;
}

export interface ErrorDetails {
    returnCode?: string;
    reasonCode?: string;
    message?: string;
}

export interface AccountIdentification {
    id?: number;
    accountSource?: string;
}

export interface AccountBalance {
    balanceAmount?: number;
    balanceUnits?: string;
    balanceClass?: string;
}

export interface PaymentURL {
    paymentURL?: string;
    paymentType?: string;
}

export interface DepositInfo {
    success?: boolean;
    depositRequired?: boolean;
    products?: ProductDepositInfo[];
    paymentURL?: PaymentURL;
}

export interface ProductDepositInfo {
    productType?: string;
    serviceCategoryId?: string;
    serviceGroup?: string;
    subServiceGroup?: string;
    paymentURL?: PaymentURL;
    depositAmount?: DepositAmount;
    installmentInd?: boolean;
    installmentOptions?: InstallmentOptions[];
}

export interface DepositAmount {
    amount?: number;
    units?: string;
}

export interface InstallmentOptions {
    noOfInstallments?: number;
    paymentAmount?: number;
}

export interface PaymentInfo {
    // ban?: string;
    // paidAmount?: string;
    // paymentDate?: string;
    // paymentRefNo?: string;
    // totalPaymentDue?: string;
    // paymentMethod?: string;
    // lastFourDigitsCreditCard?: string;
    // paymentType?: string;
    // noOfInstallments?: string;
    // depositType?: string;
    // serviceGroup?: string;
    // subServiceGroup?: string;
    sessionId?: string;
    paymentCategory: string;
    paymentStatus: string;
    paymentErr: any;
}

export interface PaymentsRq {
    orderRefNumber?: string;
    processInstanceId?: string;
    taskId?: string;
    taskName?: string;
    payload?: {
        paymentStatus?: PaymentInfo[];
        creditReviewAction?: string;
        accountName?: any;
        personalDetails?: any;
        addlOrderAttributes?: any;
    };
}
