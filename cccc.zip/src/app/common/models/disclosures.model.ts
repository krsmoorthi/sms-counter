export interface DisclosuresRes {
    rccGroup: rccGroup[]
}

export interface rccGroup {
    rccGroupId: string;
    rccGroupName: string;
    rccGroupDisplayOrder: number;
    rccDetails: rccDetails[];
}

export class rccDetails {
    public rccNameId: string;
    public rccName: string;
    public rccDesc: string;
    public rccDisplayOrder: number;
}