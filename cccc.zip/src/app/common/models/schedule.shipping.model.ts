import { DueDate, AccountName, AccountAddress } from './appointment.model';
import { Contact } from './order.model';
import { PersonalDetails, AccountPreferences } from './account.model';
import { SubAddress, WaivedOtcInfo } from './cart.model';
import {  AvailableAppointment, AppointmentPayload } from '../../common/models/appointment.model';
import { AppointmentShipping } from 'app/common/models/schedule-shipping.model';
import { APIErrorLists } from 'app/common/models/common.model';
import { Reason } from 'app/common/models/pending-order-scheduling';
import { User } from 'app/common/models/user.model';

export interface ScheduleShipping {
    success?: boolean;
    orderRefNumber: string;
    processInstanceId?: string;
    taskId: string;
    taskName?: string;
    payload: ScheduleShippingPayload;
}

export interface ScheduleShippingPayload {
    dueDate: DueDate;
    ShippingAddress: ShippingAddress;
    product: Product;
    componentType: string;
    isMandatory: boolean;
    isDefault: boolean;
    displayOrder: number;
}

export interface SchedulingVariables {
    shippingAddressObject: any; 
    isNotFromContinue: boolean;
    previousUrl: string;
    taskId: string;
    nextPaymentDate: any;
    effectiveBillDate: string;
    addressStreet: string;
    shippingName: string;
    addressLoading: boolean;
    yellowNewAddresses: boolean;
    isRedAddressReturned: boolean;
    inputAddress: any;
    responseFlag: string;
    yellowAddresses:any;
    isVacationFlow: boolean;
    validatedAddress: boolean;
    validatedNewAddress: any;  
    shippingAddress: any;
    changeShippingAdr: boolean;
    vacScheOrderRefNumber: any;
    vacScheProcessInstanceId: any
    orderDisclosures: any;
    currentComponet: string;
    isRTDChk: boolean;
    potsRemoved: boolean;
    phonenoChanged: any;
    isAmend: boolean;
    isStack:boolean;
    vacScheTaskId: any;
    vacScheTaskName: any;
    apiResponseError:APIErrorLists;
    discloserPopUpSelected: boolean;
    errorMsg: string;
    isChangeFlow: boolean;
    animalsPresentCheckBox: any;
    electricFenceCheckBox:any;
    lockedGateCheckBox:any;
    drivingDirections:any;
    additionalComments:any;
    reservedAppointment: AvailableAppointment;
    schedulingShippingPage: boolean;
    selectedAppointment: boolean;
    appointmentResponse: AppointmentShipping;
    reservedCount:number;
    earliestAvailableAppt: string;
    postalAddressValidated: boolean;
    addressNotValidatedMsg: string;   
    showReserveItButton: boolean;
    isCbr: boolean;
    isdateChanged: any;
    finalDateInfo: any;
    isRTD: boolean;
    retainedSchedulingData: any;
    techdropped: boolean;
    isReEntrant: boolean;
    appointmentPayload: AppointmentPayload;
    dueDate: string;
    isApptUpdated: boolean;
    isDueDateUpdated: boolean;
    prevDate: any;
    currentUrl: any;
    showChangeApptReasons:boolean;
    isPendingFlow:boolean;
    selectedAppointmentDate:any;
    selectedDueDate:any;
    calculatedDueDate:any;
    showRefundMessage: boolean;
    referralRequest:any;
    loading: boolean;
    requestReason:any;
    changeEffectiveBillAddress:boolean;
    formattedContactNumber: any;
    formattedNumber: any;
    reasonReschedule: Reason[]; 
    isCORFlow: boolean;
    dueDateStartText: any;
    dueDateEndText: any;    
    fromCalculatedDueDate:any;
    showSplitDueDateLink: boolean;
    fromFinalDueDate:any;    
    changeShippingAddressSelected: boolean;
    showShippingAddress: boolean;
    addressArray: any;
    mandatorySubOffers: any;
    orderFlow: string;  
    userStore: User;  
    isChange: boolean; 
    reuseBan: boolean
    orderRefNumber: string;
    dtvYes:boolean;
    myForm: any;
    cbrForm: any;        
    selectedAddress: any
    selectedResonSchedule: string;
    showErrorReason: boolean;
    remarkObj: any;
    techRemark: string;
    firstname: string;
    lastname: string;
    agentFirstName: string;
    agentLastName: string;
    apiRequest: any;
    shippingValidateAddress: boolean;
    isPrepaid: boolean;
    isCenturyLink: boolean;
    changeEffectiveBillAddressCalendar: any;
    isWaiveOtcAllowed: boolean;
    adjustableOtcProducts: any;
    waivedReasonList: any;
    eligibleCharges: number;
    waivedOtcInfo: WaivedOtcInfo;
}
export interface Product {
    id: string;
    name: string;
    productType: string;
    isRegulated: boolean;
    prices: Prices[];
    productAssociations: ProductAssociations[];
}

export interface Prices {
    attributesCombination: AttributesCombination[];
    pricetype: string;
    rc: number;
    otc: number;
    discountedRc: number;
    discountedOtc: number;
    frequency?: number;
    currencyCode: string
    provisioningAction: string;
    discounts: Discounts[];
}

export interface Discounts {
    autoAttachInd?: number;
    discountId?: number;
    discountDescription?: number;
    discountRate?: number;
    discountMethod?: number;
    discountLevel?: number;
    discountDuration?: number;
    discountType?: number;
    discountCategory?: number;
    discountMaxAmount?: number;
    discountMinimumAmount?: number;
    discountIdSequence?: number;
    discountRule?: number;
}

export interface AttributesCombination {
    name: string;
    value: string;
    uom: string;
    isDefault: boolean;
    displayOrder: number;
}

export interface ProductAssociations {
    productId: number;
    productAssociationType: string;
    selectionRule: string;
}

export interface ShippingAddress {
    success: boolean;
    result: string;
    isValidated: boolean;
    streetAddress: string;
    streetNrFirst: string;
    streetNamePrefix: string;
    streetName: string;
    streetType: string;
    locality: string;
    city: string;
    stateOrProvince: string;
    postCode: string;
    postCodeSuffix: string;
    source: string;
    subAddress: SubAddress;
    country: string;
}


export interface ScheduleShippingConfirmation {
    success?: boolean;
    orderRefNumber: string;
    processInstanceId?: string;
    taskId: string;
    taskName?: string;
    payload: ScheduleShippingConfirmationPayload;
}

export interface ScheduleShippingConfirmationPayload {
    accountName: AccountName;
    accountAddress: AccountAddress;
    ban?: number
    accountPin?: number
    billCycle?: number
    accountType?: string
    accountSubType?: string
    creditClass?: number
    contact: Contact;
    personalDetails: PersonalDetails;
    accountPreferences: AccountPreferences;
    billingAddress?: any;
    paymentDetails?: any;
}  