export let serverErrorMessages = {
    empty: '',
    selectNearMatch: 'Please select near match address.',
    serverDown: 'Server down. Please try after sometime.',
    serviceDown: 'Service down. Please try after sometime.',
    timeoutException: "A service is taking too long.  It has timed out.",
    notFoundException: 'A 404 Not Found message was returned from the call.  Please investigate end-points.',
    priceObjectNull: 'Price Object coming as null',
    //
    // Naming convention for ESHOP DEFINED error
    // First Node - Examples
    // BM - Blue Marble
    //
    // Second Node - Examples
    // INIT - init
    // ST - Submit Task API
    //
    // Third Node - Examples
    // SP - selectProduct task name
    // GAO - Get Add Ons
    //
    // Fourth Node
    // D00001 - Data issue (D) - 00001 - unique number for error
    //
    catalogArrayEmptyErrNumber: 'BM-ST-SP-D00001',
    catalogArrayEmptyErrMessage: 'Catalog Array returned is empty',
    catalogArrayExpiredMessage: 'There are no valid offers available for this address.',
    catalogArrayExpiredReasonCode:'Catalog Array returned only expired offers',
    catalogArrayExpiredErrMessage: 'Sorry, we cannot continue with this order.Please check with your supervisor or HelpDesk. ',
    serverDownNumber: 'BM-ST-SP-S00001',
    serverDownNumberErrMessage: 'Backend Server did not respond',
    statusCode: '0',
    serverDownAddress: 'BM-INIT-AP-S00001',
    serverDownYellowAddress: 'BM-INIT-MAP-S00002',
    serverDownAddressErrMessage: 'Backend Address Server did not respond',
    serverDownAddons: 'BM-ST-GAO-S00001',
    serverDownSchedule01: 'BM-ST-SCH-S00001',
    serverDownSchedule02: 'BM-ST-SCH-S00002',
    serverTimeoutErrNumber: 'BM-ALL-CA-S00001',
    serverTimeoutErrMessage: 'Backend call took too long.  It exceeded the timeout parameter.',
    notFoundErrNumber: 'BM-ALL-NF-S00001',
    notFoundErrMessage: 'A 404 Not Found message was returned from the call.  Please investigate end-points.',
    telephoneNumberEmpty: 'Telephone number is coming as empty',
    telephoneNotFound: 'Telephone Number Not Found',
    telephoneNotAvailable: 'Telephone Number Not Available. Please choose another Number',
    proxyMessageDetail: 'The proxy server received an invalid response from an upstream server.',
    productConfigEmpty: 'Product Config Object coming as empty'
};

export let GenericValues = {
    iData: 'INTERNET',
    sData: 'DATA',
    cVideo: 'VIDEO-PRISM',
    cDATVID: 'DATA/VIDEO',
    cPrimary: 'PRIMARY',
    cHD: 'HD Service',
    cDVR: 'DVR Service',
    cSurcharge: 'Prism WSTB Surcharge',
    cTotalSTB: 'Total STB',
    cWSTB: 'Wireless STB Qty',
    pPriceType: 'PRICE',
    modem: 'MODEM',
    ease: 'CENTURYLINK @ EASE',
    install: 'TECH INSTALL',
    selfInstall: 'Self Install',
    cDHP: 'VOICE-DHP',
    cHP: 'VOICE-HP',
    cDTV: 'VIDEO-DTV',
    cSelect: 'SELECT',
    cDevices: 'Devices',
    incompatible: 'INCOMPATIBLE',
    requiresSelectGrp: 'REQUIRES-SELECTGROUP',
    includesNotRequired: 'INCLUDES-NOTREQUIRED',
    isEnable: 'ENABLE',
    requires: 'REQUIRES',
    jack: 'Jack and Wire',
    llServiceType:'BNDVCBB',
    bundle: 'BUNDLEITEM',
    component: 'COMPONENT',
    downspeed: 'Derived DownSpeed',
    upspeed: 'Derived Upspeed',
    technology: 'Technology',
    shipping: 'SHIPPING',
    leaseWithCsAttrVAlue: 'Lease Secure Wifi',
    lease: 'Lease',
    secureWifiComponent: 'Secure WiFi Standalone',
    cyberSecurity: 'Cyber Security',
    serviceLevel: 'Service Level',
    noPhone: 'NoPhone',
    dtv:'DTV',
    dhp:'DHP',
    noTv: 'NoTV',
    homePhone : 'HMP',
    accountType : 'Account Type',
    purchasedModem : 'Purchase',
    hpAddOn : 'HP ADDON OFFER'
};

export let Switch = {
    amendMultiple : true,
    enableAddPotsForAmend : true
}

export interface APIErrorLists {
    errorResponse: ErrorResponse[];
}

export interface ErrorResponse {
    statusCode?: string;
    reasonCode?: string;
    message?: string;
    messageDetail?: string;
    source?: string;
    timestamp?: string;
    orderRefNumber?: string;
    serverDown?:string;
    tnNotFound?:string;
    tnNotAvail?:string;
}

export interface SystemError {
    orderRefNumber?: string;
    sourcePage?: string;
    taskName?: string;
    statusCode?: string;
    reasonCode?: string;
    message?: string;
    messageDetail?: string;
    serverDown?:string;
    tnNotFound?:string;
    tnNotAvail?:string;
}

export interface SecurityError {
    message?: string;
    messageDetail?: string;
}
