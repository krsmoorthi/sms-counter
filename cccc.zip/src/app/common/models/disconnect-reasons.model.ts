export interface Product {
	serviceGroup?: any;
	subServiceGroup?: any;
	terminationFee: string;
	currencyCode: string;
	contractExpiryDate: string;
}

export interface ReasonList {
	code: string;
	description?: any;
	waiverFlag: string;
}

export interface Service {
	serviceCategory?: any;
	offerCategory: string;
	reasonType : string;
	reasonText : string;
	etfInfo: Product;
	reasonList: ReasonList[];
}

export interface Payload {
    disconnectInfo: Service[];
}

export interface DisconnectProduct {
    serviceGroup?: string,
    subServiceGroup?: string,
    terminationFee?: number,
    currencyCode?: string,
    contractExpiryDate?: string
}

export interface DisconnectReasons {
	success: boolean;
	orderRefNumber: string;
	processInstanceId: string;
	taskId: string;
	taskName: string;
	payload: Payload;
}

export interface DueDate {
	calculatedDueDate?: string;
	requestedDueDate?: string;
	finalDueDate?: string;
	overrideFlag: boolean;
	effectiveBillDate?: string;
	isCRDAvailable?: boolean;
}

export interface DisconnectPayload {
	ban: string;
	dueDate: DueDate;
	offers: any;
	accountName:any;
	reservedTN:any;
	referralRequired:any;
	cart:any;
	productConfiguration:any;
	addlOrderAttributes: any;
	billeffectiveDateInfo:any;
}

export interface DisconnectSchedulingResponse {
	success: boolean;
	orderRefNumber: string;
	processInstanceId: string;
	taskId: string;
	taskName: string;
	billeffectiveDateInfo:any;
	payload: DisconnectPayload;
	
}