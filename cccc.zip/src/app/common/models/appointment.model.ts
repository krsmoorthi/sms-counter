import { TimeSlot } from './order.model';
import { SubAddress } from './cart.model';
import { Cart } from 'app/common/models/schedule-shipping.model';

export interface Appointment {
    appointmentInfoNoValue?: boolean;
    success?: boolean;
    orderRefNumber: string;
    processInstanceId?: string;
    taskId: string;
    taskName?: string;
    payload: AppointmentPayload;
    selectedappointment?: any;
    reservedCbr?: any;
    
}

export interface AppointmentPayload {
    dueDate: DueDate;
    referralRequired?: any;
    productConfiguration?: any;
    appointmentInfo: AppointmentInfo;
    exceptionDaysInfo: ExceptionDaysInfo;  
    exceptionfromDueDaysInfo?: ExceptionDaysInfo;  
    shippingInfo: ShippingInfo;
    addlOrderAttributes?: any; 
    billeffectiveDateInfo?: any;
    reason: any;
    offers: any;
    cart: Cart;
    accountName:any;
    apptNotes:AppointmentNotes;
    reservedTN:any;
    ban:any;
}

export interface AppointmentInfo {
    availableAppointment: AvailableAppointment[];
    apptNotes: AppointmentNotes;
    apptmntSvcsDown?: any;
}

export interface AvailableAppointment {
    appointmentId: string;
    timeSlot: TimeSlot;
    commitmentDateTime: string;
    timeSlotType: string;
    timeSlotSource: string;
    overrideReqd?: string;
    allDayAppt?: string;
    defaultTimeSlot? : boolean;
    reservationId?: any;
}

export interface DueDate {
    dueDateId?: any;
    effectiveBillDate?: string;
    isCRDAvailable? : boolean;
    requestedDueDate: string;
    calculatedDueDate: string;
    finalDueDate: string;
    overRideFlag: boolean;
}

export interface AppointmentNotes {
    animalsPresent: boolean;
    electricFence: boolean;
    lockedGate: boolean;
    notes: Notes[];
}

export interface Notes {
    name: string;
    value: string;
    date: string;
    author: string;
}

export interface AccountName {
    businessName: string;
    firstName: string;
    middleName: string;
    lastName: string;
    generation: string;
    title: string;
}

export interface AccountAddress {
    isValidated: boolean;
    streetAddress: string;
    streetNrFirst: string;
    streetNamePrefix: string;
    streetName: string;
    streetType: string;
    locality: string;
    city: string;
    stateOrProvince: string;
    postCode: string;
    postCodeSuffix: string;
    source: string;
    subAddress: SubAddress;
    country: string;
}

export interface ExceptionDaysInfo {
    durationStartDate: string;
    durationEndDate: string;
    dueDateExceptionDays: DueDateExceptionDays[];
}

export interface DueDateExceptionDays {
    exceptionDate: string;
}

export interface ShippingInfo {
    shippingName: any;
    shippingAddlInfo: any;
    isShipAddrSameAsServiceAddress: boolean;
    shippingAddress: any;
    shippingMethod: any;
}

export interface LocationAttributes {
    isMdu: boolean;
    legacyProvider: string;
    rateCenter: string;
    npa: number;
    nxx: number;
    wirecenter: string;
    cala: string;
    tarCode: string;
    tta: number;
}

export interface Reason {
    code: string;
	description?: any;
	waiverFlag?: any;
	reasonType: string;
	reasonText: string;
	offerCategory?: any;
	terminationFee?: any;
	currencyCode?: any;
}
