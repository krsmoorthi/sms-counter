import { User } from './user.model';
import { Product } from './product.model';
import { ShoppingCart } from './cart.model';
import { Order } from './order.model';

/**
 * Application Store for state management
 */
export interface AppStore {
    user: User;           // user state/profile
    cart: ShoppingCart;   // user related shopping cart
    product: Product;     // displayed products information
    order: Order;
    existingProducts: any;
    retain: any;
    customize: any;
    creditReview: any;
    pending: any;
}
