export interface CancelOrderModel {
	success?: true;
	orderRefNumber?: string;
	processInstanceId?: string;
	taskId?: string;
	taskName?: string;
	payload?: CancelOrderPayload
}

export interface CancelOrderPayload {
	customerOrderNumber?: string;
	orderVersion?: string;
	reasonCode?: ReasonCode[];
}

export interface submitCancel {

	success?: boolean,
	orderRefNumber?: string,
	processInstanceId?: number,
	taskId?: number,
	taskName?: string,
	payload?: submitCancelPayload
}

export interface submitCancelPayload {
	selectedReasonCode?: any;
	reasonRemark?: string;
}
export interface ReasonCode {
	code?: string;
	description?: string;
	waiverFlag?: string;
} 
