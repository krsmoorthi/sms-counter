import {
  AttributesCombination, OfferProductComponents, Products, ProductOfferings,
  Product, ServiceCategoryId, OfferGroup, Discounts, filterObjModel, ServiceCategoryBasedOffers
} from 'app/common/models/product.model';
import { ShoppingCart, CustomerOrderItems } from 'app/common/models/cart.model';
import { APIErrorLists } from 'app/common/models/common.model';
export interface OffersByFilters {
  qualifiedFilter: any;
  qualifiedUnfilter: any;
  unQualifiedOffers: any;
}

export interface ProfileFlags {
  removeFilteringFlag: any;
  byPassLoopQualFlag: any;
  selectedTechnologyType: any;
}

export interface OfferVariables {
  isPOTSChanged: boolean;
  hsiExistingOnCompleted: boolean;
  potsExistingOnCompleted: boolean;
  isConverted: any;
  amendForHSI: boolean;
  isRemovePhone: boolean;
  isPendingFlow: boolean;
  catalogId: any;
  catalogDTVId: any;
  recommendedError: any;
  e911Validation: any;
  addOfferExpired: boolean;
  currentComponentName: string;
  /* Changes Flags */
  undoChanges: boolean;
  /* Common Variables for Offer Page(s) */
  loading: boolean;
  retrieveOffersLoading: boolean;

  orderRefNumber: string;

  /* Profile Filtering Flags */
  byPassBool: boolean;
  hasTechnology: boolean;
  unFilterBool: boolean;
  selectedTech: string;

  /* Technology Types */
  technologyTypes: any;

  /* Compatibility */
  compatibilityArray: any;

  /* Offers */
  existingProductName: string;
  existingObjects: any;
  existingProductContract: number;
  existingServices: any;
  existingServicesForAction: any;
  existingModem: Products;
  flow: any;
  selectedDiscountsActive: boolean;
  selectedValues: any;
  internetCheck: boolean;
  videoOffer: boolean;
  videoOfferTemp: boolean;
  videoSelected: string;
  phoneOffer: boolean;
  discountedInternetOtcPrice: number;
  actualInternetOtcPrice: number;
  actualPrice: number;
  actualTVPrice: number;
  discountedTVPrice: number;
  actualTVOtcPrice: number;
  discountedTVOtcPrice: number;
  cartContractTermDTV: string;
  catalogSpecId: string;
  isExistingModemChanged: boolean;
  isExistingSpeedChanged: boolean;
  modemMakeModelCheck: boolean;
  e911ValidatedAddress: any;
  retainedPotsBooleans: any;
  phoneOfferTemp: boolean;
  selectedVoiceMail: any;
  voiceMailPresent: boolean;
  cartOrderItems: ShoppingCart;
  offerBillingType: string;
  selectedOffer: ProductOfferings;
  selfinstallSelected: boolean;
  isPOTS: boolean;
  retainValueForPotsJack: string;
  selectedDHPOffer: ProductOfferings;
  potsWireMainMandatory: boolean;
  voiceMail: boolean;
  isVoiceMailYesSelected: boolean;
  potsVoiceMailMandatory: boolean;
  potsAddAction: boolean;
  voiceMailCondi: boolean;
  wireMaintainCondi: boolean;
  selectedJackForPots: Products;
  holdCalled: boolean;
  cartObject: ShoppingCart;
  offerResponse: Product;
  shippingNHandlingCharge: number;
  isVoiceMailNoSelected: boolean;
  portingCheck: boolean;
  potsJacksMandatory: boolean;
  isPortingCheckNoSelected: boolean;
  isPortingCheckYesSelected: boolean;
  ismetroTNdisabled: boolean;
  changeAfterReEntrant: boolean;
  discountsAdded: string[];
  internationalDialing: OfferProductComponents;
  isInternational: boolean;
  jackErrorForPots: boolean;
  potsPortingMandatory: boolean;
  techInstallExist: boolean;
  cartContractTerm: string;
  isRemoved: boolean;
  isDHPRemoved: boolean;
  isHPRemoved: boolean;
  isOptedOut: boolean;
  isCanAddCvoip: any;
  isCanAddPots: any;
  cartContractTermDHP: string;
  removedProductItem: CustomerOrderItems[];
  isReEntrant: boolean;
  retentionDiscountsToCart: any;
  serviceTerminationInfo: any;
  dhpExisting: boolean;
  dhpIntlCalled: boolean;
  dhpIntlSelected: string;
  dhpIntlExisting: string;
  holdedObjects: any;
  isInternetRemoved: boolean;
  processInstanceId: string;
  taskId: string;
  isStack: boolean;
  retainValueForHSIJack: string;
  displayOffer: any;
  existingDiscountId: boolean;
  existingPriceKey: string;
  currentSpeed: any;
  check: boolean;
  modemDropDown: boolean;
  hideShippingDiscount: boolean;
  copyOfDiscountsAdded: any;
  hsiCatalogId: any;
  phoneCatalogId: any;
  dtvCatalogId: any;
  displayExistingCartOffer: string;
  onlyDHPRemoved: boolean;
  e911Called: boolean;
  selectedSpeedValue: string;
  hsiExisting: boolean;
  existingObject: any;
  expiredOffers: any;
  selectedSalesExpiredOfferId: string;
  isSalesExpiredOfferSelected: boolean;
  enablependingtab: boolean;
  enableBillingtab: boolean;

  /* Products */
  reEntrant: boolean;
  productConfiguration: any;
  tempConfig: any;
  loadedConfig: boolean;

  /* Discounts */
  discountSelected: boolean;
  hideDisplayDiscounts: boolean;
  discArray: any[];

  /* Home Phone */
  hpExisting: boolean;
  hpOfferType: string;
  phoneSelected: string;
  selectedHPOffer: ProductOfferings;

  /* Modem */
  selectedModem: Products;
  modemCompatValues: OfferProductComponents;
  isModemCompatible: boolean;
  modemAvailable: boolean;
  bypassModemRulesBool: boolean;
  modemExist: boolean;

  /* Install Options */
  recommendedTech: AttributesCombination;
  selfInstall: boolean;
  selfInstallAvailable: boolean;
  deviceSelected: boolean;
  deviceMandatory: boolean;
  selectedQuantity: string;
  isTan: boolean;
  configSelected: any[];
  selectedInstallation: Products;
  newTechInstall: boolean;

  /* Ease */
  selectedEase: Products;
  easeExist: boolean;

  /* Secure wifi Product for Purchased Modem */
  selectedSecureWifi: Products;
  secureWifiExist: boolean;

  /* Cyber Security */
  csCompatibility: any;
  isCSCompatible: boolean;

  /* Jacks */
  selectedJack: Products;
  jackExist: boolean;

  /* Wire Maintenance */
  wireMaintainenceHide: boolean;
  isWireMaintainanceNoSelected: boolean;
  isWireMaintainanceYesSelected: boolean;
  wireMaintainance: boolean;
  selectedMaintainance: Products;

  /* TV Offer */
  selectedTVOffer: ProductOfferings;
  wiredSTB: Products;
  wirelessSTB: Products;
  selectedTotal: string;
  selectedWire: string;
  selectedSTB: Products;
  hdService: Products;
  dvrService: Products;

  /* Shopping Cart Variables */
  cartCopyObject: ShoppingCart;
  previousLoaded: ShoppingCart;

  /* Shipping & Handling */
  shippingNHandlingChargeObj: any;

  /* Stack Amend */
  NIPendingStackAmend: boolean;
  internetAddAction: boolean;
  isAmend: boolean;
  isLatestPendingOrderNI: boolean;
  currentTechnology: string;
  gponError: boolean;
  previousRemovedItems: any[];
  potsRemoveAction: boolean;
  cvoipRemoveAction: boolean;
  existingData: any;

  /* Prepaid Variables */
  isPostpaid: boolean;
  isPrepaid: boolean;

  /* offer-change variables */
  cartObjectChanged: boolean;
  discloserPopUpSelected: any;
  offerVariables: OfferVariables;
  internetData: any;

  enablechangetab: boolean;
  lifelineDHPExisting: boolean;
  lifelinePOTSExisting: boolean;
  lifelineHSIExisting: boolean;
  exisitngData: any;
  removal: any;
  dropName: string;
  filterObj: filterObjModel;
  undoFlag: boolean;
  optedOutCheck: boolean;
  internetAvail: boolean;
  videoAvail: boolean;
  phoneAvail: boolean;
  internetOffer: boolean;
  serviceSpec: ServiceCategoryId[];
  taskName: string;
  offersGenerated: boolean;
  isSecureWifi: boolean;
  discountedPrice: number;
  selectedInternetOfferdId: string;
  selectedPhoneOfferdId: string;
  selectedVideoOfferdId: string;
  selectedDHPOfferdId: string;
  serviceUnavailable: string;
  directvAccountId: any;
  modemValues: OfferProductComponents;
  easeValues: OfferProductComponents;
  secureWifiValues: OfferProductComponents;
  jackValues: OfferProductComponents;
  jackValuesForPots: OfferProductComponents;
  installationValues: OfferProductComponents;
  productPriceValues: any;
  matchingOffers: OfferGroup[];
  selectedGroup: OfferGroup;
  internerOffer: ProductOfferings[];
  videorOffer: ProductOfferings[];
  phoneOfferData: ProductOfferings[];
  dhpOffer: ProductOfferings[];
  speedList: any[];
  AllspeedList: any[];
  tvList: string[];
  selectedSpeed: string;
  selectedTV: string;
  selectedHP: string;
  discountedPriceList: Discounts[];
  intraStateFee: Products;
  totalDiscountAmount: any;
  maxTSTB: any;
  maxWSTB: any;
  warningMsg: string;
  stb: Products;
  holdeisCustomizeObjects: boolean;
  hdPrice: number;
  dvrPrice: number;
  selectedInternetOfferPrice: number;
  selectedVideoOfferPrice: number;
  selectedDHPOfferPrice: number;
  selectedPhoneOfferPrice: number;
  selected: string;
  errorMsg: string;
  isShowRemoveRetentionDiscountMsg: boolean;
  existingDiscounts: any;
  hsiRemovedRetentiondiscounts: any;
  existingRetentionDiscounts: any;
  dataLink: ServiceCategoryBasedOffers;
  videoLink: ServiceCategoryBasedOffers;
  dtvLink: ServiceCategoryBasedOffers;
  dhpLink: ServiceCategoryBasedOffers;
  phoneLink: ServiceCategoryBasedOffers;
  attrCombinations: AttributesCombination;
  noPrice: AttributesCombination;
  apiResponseError: APIErrorLists;
  callingFeatures: OfferProductComponents;
  dhpOfferPriceDiscountedOtc: number;
  dhpOfferPriceDiscountedRc: number;
  includedCallingFeatures: any;
  phoneArray: any;
  videoArray: any;
  initialOfferResponse: any;
  removeMessage: any;
  productToRemove: any;
  moreServices: any;
  removeResponse: any[];
  preserveHSI: any;
  removeSelectedReason: any;
  enabledServiceList: any;
  wireMaintainanceExist: boolean;
  dtvExisting: boolean;
  existingAddonsHSI: any;
  selectedModemToShow: Products;
  maintainancePrice: number;
  ban: any;
  internationalPrice: number;
  isDHP: boolean;
  hsiOnlyPresent: boolean;
  disconnectReq: any;
  installError: boolean;
  modemError: boolean;
  easeError: boolean;
  secureWifiError: boolean;
  jackError: boolean;
  configSubmited: boolean;
  isE911Called: boolean;
  reentrantUI: boolean;
  offerNoLongerAvailable: string;
  depositHistory: any;
  calledFromConstructor: boolean;
  deviceQuantitySelected: any;
  isCustomize: boolean;
  voiceMailPrice: number;
  firstName: string;
  lastName: string;
  ensembleId: string;
  agentCuid: string;
  offerName: string;
  fromHold: boolean;
  EaseDefault: boolean;
  secureWifiDefault: boolean;
  addDhpfromRecommendation: boolean;
  JacksWireDefault: any;
  modemMake: string;
  modemModel: string;
  modemClass: string;
  showHoverMessage: boolean;
  isDtvOpus: boolean;
  newInternetCheck: boolean;
  newPhoneSelected: string;
  newPhoneUpdated: boolean;
  newVideoSelected: string;
  isSalesExpiredMessageNeedtoHide: boolean;
  speedselected: string;
  isSpeedSalesExpired: boolean;
  isBundleSalesExpired: boolean;
  qualifiedFilter: any;
  offersByFilters: OffersByFilters;
  qualifiedUnfilter: any;
  unQualifiedOffers: any;
  isProfileBypassLoopQual: boolean;
  isAllowBypassLoopQualForLQ: boolean;
  isProfileBypassHSISpeeds: boolean;
  isProfileBypassModemCheck: boolean;
  disclosuresData: any;
  rccDisclosureDetails: any;
  rccDisclosureErrorMessage: any;
  disclosureArrList: any;
  selfInstallOffers: string[];
  existingModemOffers: string[];
  recomTechInstall: OfferProductComponents;
  reEntrantLoaded: boolean;
  oneTimeLoading: boolean;
  portingValue: string;
  wireMaintainanceValue: string;
  voiceMailValue: string;
  isDisclosureAllowed: boolean;
  undoSelected: boolean;
  newVideoUpdated: boolean;
  isHSIExistingProduct: boolean;
  isRecommendationSuccess: boolean;
  recommendedObject: any;
  recommendedObj: any;
  recommendationFailure: boolean;
  disableEase: boolean;
  canDisplayCS: boolean;
  isExpiredDiscounts: number;
  cartData: any;
  nonCartItemsNotChanged: boolean;
  custData: ShoppingCart;
  existingTN: string;
  techdropped: boolean;
  isExtendedAreaCallingPresent: boolean;
  isOffer1PtyResLineSelected: boolean;
  isExtendedAreaCallingYESSelected: boolean;
  isExtendedAreaCallingNASelected: boolean;
  selectedExtendedAreaCalling: Products;
  extendedAreaCallingPrice: any;
  isExtendedAreaCallingExits: boolean;
  noWorkNeed: boolean;
  wireMaintainPresent: boolean;
  currentStore: any;
  existingBillingType: any;
  billingTypeChanged: boolean;
  expiredProduct: Products;
  videoSelectedTemp: string;
  phoneSelectedTemp: string;
  etfValue: number;
  etfValueEnable: boolean;
  tempTaskId: string;
  isPrepaidAccountPage: boolean;
  hpSelected: boolean;
  currentFlow: string;
  secureWifiSelected: any;
  easeSelected: any;
  voiceMailInput: any;
  wireMaintainanceInput: any;
  portingInput: any;
  selectedSalesExpiresOffer?: any;
  existingOfferName?: any;
  modemBillingType?: string;
  legacyProvider?: string;
  prodConfig?: any;
  reqDeposit?: boolean;
  filterCriteria?: filterCriteria;
  wliLocationAvail?: any;
  existingServicesForRemove: any;
}

export interface filterCriteria { isExpiredOffersRequest?: boolean, retrievalTypes?: [string] };
