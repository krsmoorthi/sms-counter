

export interface LogMessage {
    time?: number;
    index?: string;
    host?: string;
    source?: string;
    sourcetype?: string;
    event?: string;
}
