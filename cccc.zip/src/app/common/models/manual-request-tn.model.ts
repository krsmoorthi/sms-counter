export interface manualRequestReq {
    transactionId?: string;
    tnType?: string;
    telephoneNumbers?: telephoneNumber[];
}

export interface telephoneNumber {
    telephoneNumber?: number;
}

export interface checkPotsTnAvailabilityResponse {
    tnStatus?: tnStatus[];
}

export interface tnStatus {
    transactionId?: string;
    tn?: string;
    returnCode?: number;
    isAgingTN?: string;
    agingDurationinDays?: number;
    tnAvailabityStatus?: string;
    message?: string;
    tnOrderAvailability?: tnOrderAvailability;
}

export interface tnOrderAvailability {
    tnAvailabilityDetail?: tnAvailabilityDetail[];
}

export interface tnAvailabilityDetail {
    sourceSystem?: string;
    pendingOrderDetails?: pendingOrderDetails[];
}

export interface pendingOrderDetails {
    customerOrderNumber?: number;
    orderNumber?: number;
    btn?: number;
    ban?: number;
    mainTelephoneNumber?: number;
    orderNumberStatus?: string;
    dueDate?: string;
    statusMessage?: string;
}