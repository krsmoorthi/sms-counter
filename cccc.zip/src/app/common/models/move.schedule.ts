export interface DueDateExceptionDay {
	exceptionDate: string;
}


export interface TimeSlot {
	startDateTime: string;
	endDateTime: string;
}

export interface AvailableAppointment {
	appointmentId: string;
	timeSlot: TimeSlot;
	commitmentDateTime: string;
	timeSlotType: string;
	timeSlotSource: string;
}


export interface Note {
	name: string;
	value: string;
	date: string;
	author: string;
}

export interface Element {
	designator: string;
	value: number;
}

export interface SubAddres {
	sourceId: string;
	source: string;
	geoSubAddressId: number;
	combinedDesignator: string;
	elements: Element[];
}

export interface LocationAttribute {
	isMdu: boolean;
	legacyProvider: string;
	rateCenter: string;
	npa: number;
	nxx: number;
	wirecenter: string;
	cala: string;
	tarCode: string;
	tta?: any;
}

export interface ShippingAddres {
	isValidated: boolean;
	streetAddress: string;
	streetNrFirst: number;
	streetNrFirstSuffix: string;
	streetNamePrefix: string;
	streetName: string;
	streetType: string;
	locality: string;
	city: string;
	stateOrProvince: string;
	postCode: number;
	postCodeSuffix: string;
	source: string;
	subAddress: SubAddres;
	country: string;
	locationAttributes: LocationAttribute;
}

export interface OfferAttribute {
	attributeName: string;
	attributeValue: string;
}

export interface CompositeAttribute {
	attributeName: string;
	attributeValue: number;
	uom: string;
}

export interface Price {
	priceType: string;
	priceTypeDescription: string;
	priceKey: string;
	rc: number;
	otc: number;
	discountedRc: number;
	discountedOtc: number;
	frequency: string;
	currencyCode: string;
	provisioningAction: string;
}

export interface Discount {
	autoAttachInd: string;
	discountId?: any;
	discountDescription?: any;
	discountRate: number;
	discountDuration: number;
	discountMaxAmount: number;
	discountMinimumAmount: number;
}

export interface ProductAttribute {
	compositeAttribute: CompositeAttribute[];
	isDefault: number;
	displayOrder: number;
	isPriceable: boolean;
	prices: Price[];
	discounts: Discount[];
}

export interface Product {
	productId: number;
	productName: string;
	productDisplayName: string;
	productType: string;
	productCategory: string;
	isRegulated: boolean;
	quantity: string;
	productAttributes: ProductAttribute[];
}

export interface ProductComponent {
	product: Product;
	componentType: string;
	isMandatory: boolean;
	isDefault: number;
	displayOrder: number;
}

export interface Contract {
	contractTerm: number;
	isPriceLock: boolean;
	priceLockDuration: number;
	etf: number;
	currencyCode: string;
}

export interface ValidFor {
	salesStartDateTime: string;
	salesEndDateTime: string;
}

export interface Discount {
	discountId?: any;
	discountDescription?: any;
	discountAmount?: any;
}

export interface AssociatedOfferId {
	displayOrder?: any;
	associatedOfferId?: any;
	discount: Discount;
}

export interface AssociationType {
	associationType?: any;
	selectionRule?: any;
	associatedOfferIds: AssociatedOfferId[];
}

export interface AssociatedOffer {
	associatedOfferCategory?: any;
	associationType: AssociationType[];
}

export interface ProductOffer {
	productOfferingId: string;
	offerName: string;
	offerDisplayName: string;
	offerType: string;
	offerSubType: string;
	offerCategory: string;
	offerAttributes: OfferAttribute[];
	productComponents: ProductComponent[];
	contract: Contract;
	validFor: ValidFor;
	associatedOffers: AssociatedOffer[];
}

export interface DefaultOfferPrice {
	rc: number;
	otc: number;
	discountedRc: number;
	discountedOtc: number;
}

export interface CatalogItem {
	productOfferingId: string;
	productOffer: ProductOffer;
	defaultOfferPrice: DefaultOfferPrice;
	isDefault: number;
	displayOrder: number;
}

export interface Catalog {
	catalogId: string;
	catalogName: string;
	catalogType: string;
	catalogItems: CatalogItem[];
}

export interface ShippingOffer {
	serviceCategory: string;
	catalogs: Catalog[];
}

export interface CompositeAttribute {
	attributeName: string;
	attributeValue: number;
	uom: string;
}

export interface Price {
	priceType: string;
	priceTypeDescription: string;
	priceKey: string;
	rc: number;
	otc: number;
	discountedRc: number;
	discountedOtc: number;
	frequency: string;
	currencyCode: string;
	provisioningAction: string;
}

export interface Discount {
	autoAttachInd: string;
	discountId?: any;
	discountDescription?: any;
	discountRate: number;
	discountDuration: number;
	discountMaxAmount: number;
	discountMinimumAmount: number;
}

export interface ProductAttribute {
	compositeAttribute: CompositeAttribute[];
	isDefault: number;
	displayOrder: number;
	isPriceable: boolean;
	prices: Price[];
	discounts: Discount[];
}

export interface CustomerOrderSubItem {
	productId: string;
	productName: string;
	productType: string;
	componentType: string;
	productCategory: string;
	quantity: number;
	action: string;
	productAttributes: ProductAttribute[];
}

export interface CustomerOrderItem {
	catalogId: string;
	productOfferingId: string;
	offerType: string;
	offerSubType: string;
	offerCategory: string;
	quantity: string;
	contractTerm: number;
	rc: number;
	otc: number;
	discountedRc: number;
	discountedOtc: number;
	action: string;
	customerOrderSubItems: CustomerOrderSubItem[];
}

export interface Cart {
	catalogSpecId: string;
	customerOrderItems: CustomerOrderItem[];
}

