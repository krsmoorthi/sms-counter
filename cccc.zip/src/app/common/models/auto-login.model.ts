/**
 * AutoLogin API Response Interface
 * Response from API for auto login
**/

export interface AutoLogin {
    oamData?: OAMData;
    sfcData?: SFCData;
}

export interface OrderActivity {
    callStartTime?: string,
    ucid?: string,
    tfn?: string
}

export interface OAMData {
    ensembleId?: string,
    agentCuid?: string,
    agentFullName?: string,
    agentFirstName?: string,
    agentLastName?: string,
    agentEmailId?: string,
    workstationId?: string,
    roomNumber?: string
}

export interface SFCData {
    accountBAN?: string,
    accountNumber?: string,
    actionCode?: string,
    token?: string,
    alternateContactNumber?: string,
    callerFirstName?: string,
    callerLastName?: string,
    callerMiddleName?: string,
    callReason?: string,
    callRemarks?: string,
    contactNumber?: string,
    contactNumberSecond?: string,
    emailID?: string,
    envInfo?: string,
    infoCPNI?: string,
    orderReferenceNumber?: string,
    orderStatus?: string,
    orderActivityType?: string,
    orderType?: string,
    serviceAddress?: string,
    serviceAddressUnit?: string,
    sfdcBillingAccountID?: string,
    sfdcID?: string,
    geoAddressId?: string,
    geoSubAddressId?: string,
    orderActivity?: OrderActivity,
    isPrimaryPhoneSms? : boolean,
    emailDeclined? : boolean,
    type?: string
    recommendedItems?: object,
    recommendVacationOffer?: boolean
}