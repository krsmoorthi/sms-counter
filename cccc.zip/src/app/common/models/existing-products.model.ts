export interface SubAddres {
	combinedDesignator: string;
	elements: any[];
	geoSubAddressId: string;
	source: string;
	sourceId: string;
}

export interface GeoPoint {
	accuracy: string;
	coordinateLevel: string;
	latitude: number;
	longitude: number;
	source: string;
}

export interface LocationAttribute {
	isMdu: boolean;
	legacyProvider: string;
	rateCenter: string;
	wirecenter: string;
	npa: string;
	nxx: string;
	tta: string;
	tarCode: string;
	cala: string;
}

export interface TimeZone {
	ianaName: string;
	isDaylightSavingsTime: boolean;
	name: string;
	offset: string;
}

export interface Npa {
	code: string;
}

export interface Nxx {
	code: string;
}

export interface NpaNxxList {
	npa: Npa;
	nxx: Nxx;
}

export interface ServiceAddres {
	addressId: string;
	streetAddress: string;
	streetNrFirst: string;
	streetNrFirstSuffix: string;
	streetNrLast: string;
	streetNrLastSuffix: string;
	streetName: string;
	streetType: string;
	locality: string;
	city: string;
	stateOrProvince: string;
	postCode: string;
	postCodeSuffix: string;
	sourceId: string;
	source: string;
	geoAddressId: string;
	subAddress: SubAddres;
	country: string;
	geoPoint: GeoPoint[];
	locationAttributes: LocationAttribute;
	timeZone: TimeZone;
	npaNxxList: NpaNxxList[];
}

export interface AccountName {
	firstName: string;
	lastName: string;
	middleName?: any;
	businessName?: any;
	title: string;
	generation?: any;
}

export interface EmailNotification {
	billingNotification?: any;
	orderingNotification?: any;
	repairNotification?: any;
}

export interface TextNotification {
	billingNotification?: any;
	orderingNotification?: any;
	repairNotification?: any;
}

export interface AccountPreference {
	paperlessBilling?: any;
	spanishBillPrint?: any;
	noTeleMarketing?: any;
	noEmail?: any;
	noDirectMail?: any;
	braille?: any;
	largePrint?: any;
	emailNotification: EmailNotification;
	textNotification: TextNotification;
}

export interface SubAddres {
	combinedDesignator: string;
	elements: any[];
	geoSubAddressId: string;
	source: string;
	sourceId: string;
}

export interface LocationAttribute {
	isMdu: boolean;
	legacyProvider: string;
	rateCenter: string;
	wirecenter: string;
	npa: string;
	nxx: string;
	tta: string;
	tarCode: string;
	cala: string;
}

export interface BillingAddres {
	isValidated: boolean;
	streetAddress: string;
	streetNrFirstSuffix: string;
	streetNrFirst: string;
	streetName: string;
	streetType: string;
	streetNamePrefix?: any;
	city: string;
	locality: string;
	stateOrProvince: string;
	postCode: string;
	source: string;
	postCodeSuffix: string;
	country: string;
	subAddress: SubAddres;
	locationAttributes: LocationAttribute;
}

export interface Contact {
	contactNumber: string;
	smsNumber?: any;
	emailAddress?: any;
	emailAddrDeclined: boolean;
}

export interface PersonalDetail {
	dateOfBirth?: any;
	dLExpirationDate?: any;
	dLlicenseNo?: any;
	dLlicenseState?: any;
	ssn: string;
	taxId?: any;
	creditCheck: boolean;
	underAgeAck?: any;
}

export interface AccountInfo {
	isBillAddrSameAsServiceAddress: boolean;
	accountName: AccountName;
	accountPin: string;
	accountSubType: string;
	accountType: string;
	accountPreferences: AccountPreference;
	ban: string;
	billCycle: number;
	billingAddress: BillingAddres;
	contact: Contact;
	creditClass: string;
	geoCode?: any;
	personalDetails: PersonalDetail;
	billingAdditionalInfo?: any;
    billingAddressType?: any;
    billingType?: any;
    subAddress?: any;
}

export interface ProductAssociation {
	productAssociationType: string;
	productIds: any[];
}

export interface Price {
	priceType: string;
	frequency?: any;
	currencyCode: string;
	discountedOtc: number;
	discountedRc: number;
	otc: number;
	rc: number;
	priceTypeDescription: string;
	priceKey: string;
	provisioningAction?: any;
}

export interface CompositeAttribute {
	attributeName: string;
	attributeValue: string;
	uom?: any;
}

export interface ProductAttribute {
	isDefault: number;
	displayOrder: number;
	isPriceable: boolean;
	prices: Price[];
	discounts?: any;
	compositeAttribute: CompositeAttribute[];
}

export interface ExistingServiceSubItem {
	quantity: number;
	productId: string;
	productName: string;
	action?: any;
	productType: string;
	componentType: string;
	productCategory: string;
	productAssociations: ProductAssociation[];
	productAttributes: ProductAttribute[];
}

export interface ExistingServiceItem {
	action?: any;
	catalogId: string;
	contractTerm: string;
	existingServiceSubItems: ExistingServiceSubItem[];
	customerOrderSubItems: ExistingServiceSubItem[];
	discountedOtc: number;
	discountedRc: number;
	offerCategory: string;
	offerSubType: string;
	offerType: string;
	otc: number;
	productOfferingId: string;
	quantity: number;
	rc: number;
}

export interface ExistingService {
	catalogSpecId?: any;
	existingServiceItems: ExistingServiceItem[];
}

export interface ServiceCharacteristic {
	name: string;
	value: string;
	uom: string;
}

export interface ServiceCategory {
	serviceCategory: string;
	serviceCharacteristic: ServiceCharacteristic[];
}
export interface OrderFlowItem {
	flow: string;
	type: string;
}

export interface ExistingProductsAndService {
	telephoneNumber: string;
	serviceAddress: ServiceAddres;
	accountInfo: AccountInfo;
	existingServices: ExistingService;
	pendingOrders: any[];
	productConfiguration: any[];
	serviceCategory: ServiceCategory[];
	addlOrderAttributes?:any;
    validateResponse?: any;
}

export interface ExistingProducts {
	success: boolean;
	existingProductsAndServices: ExistingProductsAndService[];
	orderFlow: OrderFlowItem;
	ban?: string;
	existingDiscounts?: any;
    stackamend?: any;
	changeRespInit?: any;
	pendingOrders?: any;
}