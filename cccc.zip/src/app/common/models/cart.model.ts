import { ServiceCategoryBasedOffers, Products, Discounts } from './product.model';

/**
 * Shopping Cart interface
 */
export interface ShoppingCart {
    id?: string;
    price?: any;
    selectedService?: string;
    selectedReferral?: string;
    Otc?: OTCcart[];
    oneTimeCharge?: OneTimeCharge;
    monthlyCharge?: MonthlyCharge;
    success?: boolean;
    orderRefNumber?: string;
    processInstanceId?: string;
    taskId?: string;
    taskName?: string;
    payload?: Payload;
    terminationFee?: any;
    e911ValidatedAddress?: any;
    serviceCategoryBasedOffers?: ServiceCategoryBasedOffers[];
    maxSpeed?: any;
    cartData?:any;
    offerChangeData?: any;
    leasedModemDisplayName?: any;
    recommendedDiscounts?:any;
    waivedOtcInfo?: WaivedOtcInfo;
}

export interface OTCcart {
    quantity?: any;
    name?: any;
    max?: any;
    price? : any;
    selected?: any;   
}
export interface Payload {
    success?: boolean;
    dhpAdditionalInfo?: any;
    cart?: Cart;
    customerAddonOfferItems?: CustomerOrderItems[];
    shipping?: any;
    productConfiguration?: any;
    servicesTerminationInfo?: any;
    discountItems?: any;
    listing?: any;
    billingType ?:string;
}

export interface Cart {
    catalogSpecId?: string;
    customerOrderItems?: CustomerOrderItems[];
}

export interface CustomerOrderItems {
    catalogId?: any; // number;
    productOfferingId?: string;
    offerName?: string;
    offerDisplayName?: string;
    offerType?: string;
    offerSubType?: string;
    productDisplayName?: string;
    offerCategory?: string;
    productType?: string;
    quantity?: number;
    contractTerm?: any;
    rc?: number;
    otc?: number;
    discountedRc?: number;
    discountedOtc?: number;
    customerOrderSubItems?: Products[];
    existingServiceSubItems?: Products[];
    action?: string;
    install?: boolean;
    modem?: boolean;
    ease?: boolean;
    jack?: boolean;
    contractStartDate?: string;
    securityProduct?: boolean;
}

export interface CustomerOrderSubItem {
    productId?: string;
    productName?: string;
    productType?: string;
    productAttributes?: AttributesCombination[];
    prices?: CartPrices[];
    productCategory?: string;
    productAssociations?: ProductAssociations[];
    componentType?: string;
    action?:string;
    dontShow?: boolean;
}

export interface CartProducts {
    productId?: string;
    productName?: string;
    productType?: string;
    prices?: CartPrices[];
}



export interface AttributesCombination {
    name?: string;
    value?: string;
    uom?: string;
    isDefault?: boolean;
    displayOrder?: number;
}

export interface CartPrices {
    attributesCombination: AttributesCombination[];
    priceType?: string;
    rc?: number;
    otc?: number;
    discountedRc?: number;
    discountedOtc?: number;
    uom?: string;
    currencyCode?: string;
    provisioningAction?: string;
    frequency?: string;
    discounts?: Discounts[];
}

export interface ProductAssociations {
    productAssociationType?: string;
    productId?: number;
    selectionRule?: string;
}

export interface OneTimeCharge {
    internetActivation?: string;
    isFreeInternetActivation?: boolean;
    standardShipping?: string;
    phoneActivation?: string;
}

export interface MonthlyCharge {
    highSpeedInternet?: HSI;
    tvServices?: TV;
    homePhone?: HomePhone;
}

export interface HSI {
    hsiSpeed?: string;
    hsiCost?: number;
    modemItem?: string;
    modemCost?: number;
    easeItem?: string;
    easeCost?: number;
    intraStateServiceFee?: string;
}

export interface TV {
    prismPreferred?: string;
    prismSTB?: string;
    isSTBfree?: boolean;
    freeSTB?: string;
    isPremiumChannelsAdded?: boolean;
    premiumChannels?: string;
    regionalSportsNetworkFee?: string;
    localBroadcastFee?: string;
}

export interface HomePhone { }

export interface ContactInfo {
    id?: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    phoneNumberExtn?: string;
    desiredDueDate?: string;
    checkAddress?: boolean;
    userName?: string;
    businessName?: string;
    middleName?: string;
    generation?: string;
    title?: string;
}

export interface EnterpriseAddress {
    name?:string;
    id?: string;
    addressLine?: string;
    street?: string;
    streetAddress?: string;
    streetName?: string;
    singleLine?: boolean;
    city?: string;
    floor?: string;
    country?: string;
    stateOrProvince?: string;
    postCode?: string;
    serviceProvider?: string;
    applicanceName?: string;
    unitNumber?: string;
    geoAddressId?: string;
    subAddress?: SubAddress;
    source?: string;
    streetNamePrefix?: string;
    streetType?: string;
    streetNrFirst?: string;
    locality?: string;
    postCodeSuffix?: string;
    isValidated?: boolean;
    addressType?: string;
    boxNumber?: string;
    ruralRoute?: string;
    addressLine1?: string;
    addressLine2?: string;
    apoFpoDpo?: string;
    armedForceLoc?: string;
    streetDirectionPrefix?: string;
    streetNrFirstSuffix?: any;
    addressTypeSelected?: any;
    inRangeResponse?: any;
    geoSubAddressId?: string;
    locationAttributes?: LocationAttributes;
    location?: any;
}

export interface LocationAttributes {
    isMdu?: boolean;
	legacyProvider?: string;
	rateCenter?: string;
	wirecenter?: string;
	npa?: string;
	nxx?: string;
	tta?: string;
	tarCode?: string;
	cala?: string;
}

export interface SubAddress {
    geoSubAddressId?: string;
    source?: string;
    sourceSystemId?: string;
    combinedDesignator?: string;
    sourceId?: string;
    elements?: SubAddressElements[];
}

export interface SubAddressElements {
    designator?: string;
    value?: string;
}

export interface WaivedOtcInfo {
    totalWaivedOtc?: number;
    otcWaiverList? : any;
}