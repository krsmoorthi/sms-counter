import { TestBed } from '@angular/core/testing';

import { SplunkLogService } from './splunk-log.service';
import { HttpClientModule } from '@angular/common/http';
import { of, Observable } from 'rxjs';
import { MockServer } from 'app/MockServer.test';
import { Store } from '@ngrx/store';
import { CTLHelperService } from '../service/ctlHelperService';

describe('SplunkLogService', () => {
  let service: SplunkLogService;
  const mockServer = new MockServer();

  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }

  const store = { provide: Store, useValue: mockRedux}

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [
        SplunkLogService,
        store,
        CTLHelperService
      ]
    });
    service = TestBed.get(SplunkLogService);
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
