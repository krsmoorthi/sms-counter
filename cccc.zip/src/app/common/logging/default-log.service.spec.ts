import { TestBed } from '@angular/core/testing';
import { Logger } from './default-log.service';

describe('DefaultLogService', () => {
    let logger: Logger;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
              Logger
            ]
        }).compileComponents();
    });

    beforeEach(() => {
      logger = TestBed.get(Logger);
    });

    it("assert should be defined...", () => {
      expect(logger.assert).toBeDefined();
    });

    it("error should be defined...", () => {
      expect(logger.error).toBeDefined();
    });

    it("group should be defined...", () => {
      expect(logger.group).toBeDefined();
    });

    it("groupEnd should be defined...", () => {
      expect(logger.groupEnd).toBeDefined();
    });

    it("info should be defined...", () => {
      expect(logger.info).toBeDefined();
    });

    it("warn should be defined...", () => {
      expect(logger.warn).toBeDefined();
    });

    it("log should be defined...", () => {
      expect(logger.log).toBeDefined();
    });

});