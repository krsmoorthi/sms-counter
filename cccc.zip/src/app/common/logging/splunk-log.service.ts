import { LogMessage } from '../models/logmessage.model';

/**
 * Declare the console as an ambient value so that TypeScript doesn't complain.
 */
declare var console: any;

// Import the application components and services.
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppStore } from '../models/appstore.model';
import { Store } from '@ngrx/store';
import { User } from '../models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Rx';
import { ILogger } from './default-log.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import 'rxjs/add/operator/toPromise';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

/**
 * Console log service
 * Log values to the ambient console object.
 */
@Injectable()
export class SplunkLogService implements ILogger {

    LogObj: LogMessage = {};

    private start: number;
    private end: number;
    private fingerPrint: string;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public startingTime: number;
    public endingTime: number;

    public startTime(): void {
        this.start = new Date().getTime();
    }

    public startTotalTime(): void {
        this.startingTime = new Date().getTime();
    }

    public endTime(): void {
        this.end = new Date().getTime();
    }

    public endTotalTime(): void {
        this.endingTime = new Date().getTime();
    }

    public calculateTotalDifference(timeFormat: string): any {
        switch (timeFormat) {
            case 'Seconds': return ((this.endingTime - this.startingTime) / 1000);
            case 'MilliSeconds': return (this.endingTime - this.startingTime);
            default: return (this.endingTime - this.startingTime);
        }
    }

    public calculateDifference(timeFormat: string): string {
        switch (timeFormat) {
            case 'Seconds': return ((this.end - this.start) / 1000) + ' Seconds';
            case 'MilliSeconds': return (this.end - this.start) + ' Milli Seconds';
            default: return (this.end - this.start) + 'Milli Seconds';
        }
    }

    constructor(
        private http: HttpClient,
        public store: Store<AppStore>,
        private ctlHelperService: CTLHelperService
    ) {
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe(
            (data) => {
                this.fingerPrint = data.fingerPrint;
            }
        );
    }


    public assert(...args: any[]): void {
        // convert input into JSON string
        this.sendmessage(args[0], args[1], args[2], args[3].toString());
    }


    public error(...args: any[]): void {
        this.sendmessage(args[0], args[1], args[2], args[3].toString());
    }


    public group(...args: any[]): void {
        // convert input into JSON string
        this.sendmessage(args[0], args[1], args[2], args[3].toString());
    }


    public groupEnd(...args: any[]): void {
        (console && console.groupEnd) && console.groupEnd(...args);
    }


    public info(...args: any[]): void {
        // convert input into JSON string
        this.sendmessage(args[0], args[1], args[2], args[3].toString());
    }

    public metrics(pageName: string): void {
        let currentUser: User;
        this.userSubscription = this.user.subscribe(
            (data) => {
                currentUser = data;
            }
        );

        this.LogObj.time = Date.now();
        this.LogObj.host = window.location.origin;
        let maskedMsg = this.getObject(currentUser);
        let splunkMsg = '{"severity":"info","dataType":"metrics","pageName":"' + pageName + '","data":' + maskedMsg + '}';
        this.LogObj.event = splunkMsg
        // set  headers
        let options = this.setRequestOptions();

        this.http.post(`${env.SPLUNK_URL}`, JSON.stringify(this.LogObj), options)
            .toPromise()
            .then()
            .catch();
    }

    public getLegacyProviderValue() {
        let existingLegacyProvider: string;
        let legacyProvider: string;
        let user = this.store.select('user');
        user.subscribe((data) => {
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes !== undefined) {
                legacyProvider = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
        });
        let existingObservable = this.store.select('existingProducts');
        existingObservable.subscribe((data) => {
            if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress && data.existingProductsAndServices[0].serviceAddress.locationAttributes) {
                existingLegacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
            }
        });
        if (legacyProvider && legacyProvider !== undefined) {
            return legacyProvider;
        } else if (existingLegacyProvider && existingLegacyProvider !== undefined) {
            return existingLegacyProvider;
        } else {
            return;
        }
    }

    public getCurrentFlow() {
        let currentFlow: string;
        let existingObservable = this.store.select('existingProducts');
        existingObservable.subscribe((data) => {
            currentFlow = data && data.orderFlow && data.orderFlow.flow.toUpperCase();
        });
        return currentFlow;
    }
    //this method would be primarily used send mesagess to splunk
    public sendmessage(severity: string, className: string, taskName: string, msg: string, ): void {
        this.LogObj.time = Date.now();
        this.LogObj.host = window.location.origin;

        // This is specifically to add the OrderRefNumber to the timings.
        // Adding agent information to splunk logging
        var agentCuid;
        var agentFirstName;
        var agentLastName;
        var agentEnsembleId;
        var agentRoomNumber;

        var userData;
        var offerBillingType;
        this.userSubscription = this.user.subscribe((data) => {
            if (data.prepaidFlag) {
                offerBillingType = data && data.prepaidFlag;
            }
        });
        var properties;
        this.userSubscription = this.user.subscribe((data) => {
            if (data.properties) {
                properties = data && data.properties && data.properties.system;
            }
        });
        var legacy = this.getLegacyProviderValue();
        var orderType = this.getCurrentFlow();
        this.userSubscription = this.user.subscribe(
            (data) => {
                userData = data;
                // Adding agent information to splunk logging
                if (typeof data !== 'undefined' && typeof data.autoLogin !== 'undefined' && typeof data.autoLogin.oamData !== 'undefined') {
                    agentCuid = data.autoLogin.oamData.agentCuid;
                    agentFirstName = data.autoLogin.oamData.agentFirstName;
                    agentLastName = data.autoLogin.oamData.agentLastName;
                    agentEnsembleId = data.autoLogin.oamData.ensembleId;
                    agentRoomNumber = data.autoLogin.oamData.roomNumber;
                }
            }
        );

        if (msg && (msg.indexOf('elapsedTime') > -1)) {
            if (typeof userData !== 'undefined' && typeof userData.orderInit !== 'undefined' && typeof userData.orderInit.orderRefNumber !== 'undefined'
                && userData.orderInit.orderRefNumber !== null && userData.orderInit.orderRefNumber.length > 0) {
                var passedInJSON = JSON.parse(msg);
                passedInJSON.orderRefNumber = userData.orderInit.orderRefNumber;
                msg = JSON.stringify(passedInJSON);
            }
        }
        let maskedMsg;
        if (this.ctlHelperService.isJson(msg)) {
            maskedMsg = this.getObject(JSON.parse(msg));
        } else if (typeof msg === 'string') {
            const message = JSON.stringify({ message: msg });
            maskedMsg = this.getObject(JSON.parse(message));
        }
        let splunkMsg = '{"severity":"' + severity + '","taskName":"' + taskName + '","className":"' + className + '","fingerPrint":"' + this.fingerPrint + '","agentCuid":"' + agentCuid + '","agentFirstName":"' + agentFirstName + '","agentLastName":"' + agentLastName + '","agentEnsembleId":"' + agentEnsembleId + '","agentRoomNumber":"' + agentRoomNumber + '","offerBillingType":"' + offerBillingType + '","data":' + maskedMsg + '}';
        if ((legacy || orderType) && splunkMsg) {
            splunkMsg = splunkMsg.substring(0, splunkMsg.length - 1);
            splunkMsg += ',"territory":"' + legacy + '","orderType":"' + orderType + '"}';
        }
        this.LogObj.event = splunkMsg

        //set  headers
        let options = this.setRequestOptions();

        this.http.post(`${env.SPLUNK_URL}`, JSON.stringify(this.LogObj), options)
            .toPromise()
            .then()
            .catch();
    }

    public log(...args: any[]): void {
        // convert input into JSON string
        if (args[3] && typeof args[3] === 'string') {
            this.sendmessage(args[0], args[1], args[2], args[3].toString());
        }
        else {
            // We are assuming this is an error coming back in the service response
            // Need to investigate and handle accordingly
            let error = args[3];
            let currentError;
            let jsonError;
            if (this.ctlHelperService.isJson(error)) {
                jsonError = error.json();
            }
            if (jsonError && jsonError.errorResponse) {
                currentError = jsonError;
            }
            else if (error !== undefined && error !== null) {
                if (error.message) {
                    currentError = error.message;
                }
                else if (error.status) {
                    currentError = error.status;
                }
            }
            this.sendmessage(args[0], args[1], args[2], JSON.stringify(currentError));
        }
    }

    public setRequestOptions() {
        let headers = new HttpHeaders({
            'Content-Type': 'text/plain; charset=UTF-8',
            'Authorization': env.SPLUNK_TK,
            'X-B3-TraceID': this.fingerPrint
        });
        return { headers };
    }

    public warn(...args: any[]): void {
        // convert input into JSON string
        this.sendmessage(args[0], args[1], args[2], args[3].toString());
    }

    private getObject(theObject: any) {
        var maskKeys = `${env.MASK_KEYS}`;
        var maskKeysArray = maskKeys.split(",");

        if (theObject instanceof Array) {
            for (var i = 0; i < theObject.length; i++) {
                this.getObject(theObject[i]);
            }
        }
        else {
            for (var prop in theObject) {
                for (var i = 0; i < maskKeysArray.length; i++) {
                    if (prop === maskKeysArray[i]) {
                        theObject[prop] = "##########";
                    }
                }

                if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
                    this.getObject(theObject[prop]);
                }
            }
        }
        return JSON.stringify(theObject);
    }
}