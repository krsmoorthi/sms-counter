import { TestBed } from '@angular/core/testing';
import { ConsoleLogService } from './console-log.service';

describe('ConsoleLogService', () => {
    let consoleLogService: ConsoleLogService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
              ConsoleLogService
            ]
        }).compileComponents();
    });

    beforeEach(() => {
      consoleLogService = TestBed.get(ConsoleLogService);
    });

    it('assert should be defined...', () => {
      spyOn(consoleLogService, 'assert');
      consoleLogService.assert('Sample assert');
      expect(consoleLogService.assert).toHaveBeenCalled();
    });

    it('error should be defined...', () => {
      spyOn(consoleLogService, 'error');
      consoleLogService.error('Sample Error');
      expect(consoleLogService.error).toHaveBeenCalledWith('Sample Error');
    });

    it('group should be defined...', () => {
      spyOn(consoleLogService, 'group');
      consoleLogService.group('Sample Group');
      expect(consoleLogService.group).toHaveBeenCalledWith('Sample Group');
    });

    it('groupEnd should be defined...', () => {
      spyOn(consoleLogService, 'groupEnd');
      consoleLogService.groupEnd('Sample GroupEnd');
      expect(consoleLogService.groupEnd).toHaveBeenCalledWith('Sample GroupEnd');
    });

    it('info should be defined...', () => {
      spyOn(consoleLogService, 'info');
      consoleLogService.info('Sample Info');
      expect(consoleLogService.info).toHaveBeenCalledWith('Sample Info');
    });
  
    it('warn should be defined...', () => {
      spyOn(consoleLogService, 'warn');
      consoleLogService.warn('Sample Warning');
      expect(consoleLogService.warn).toHaveBeenCalledWith('Sample Warning');
    });

    it('log should be defined...', () => {
      spyOn(consoleLogService, 'log');
      let action = consoleLogService.log('Sample log');
      expect(consoleLogService.log).toHaveBeenCalledWith('Sample log');
    });

});