/**
 * Logging interface for log implementation
 */ 
export interface ILogger {
    assert( ...args: any[] ) : void;
    error( ...args: any[] ) : void;
    group( ...args: any[] ) : void;
    groupEnd( ...args: any[] ) : void;
    info( ...args: any[] ) : void;
    log( ...args: any[] ) : void;
    warn( ...args: any[] ) : void;
    metrics( ...args: any[] ) : void;
    startTime(): void;
    endTime() : void;
    calculateDifference(timeFormat : string) : string;
}

/**
 * Set up the default logger. The default logger doesn't actually log anything; but, it
 * provides the Dependency-Injection (DI) token that the rest of the application can use
 * for dependency resolution. Each platform can then override this with a platform-
 * specific logger implementation, like the ConsoleLogService (below).
 */
export class Logger implements ILogger {

    public startTime(): void {

    }
    public endTime() : void {

    }
    public endTotalTime() : void {

    }

    public startTotalTime() : void {

    }

    public calculateDifference = (timeFormat: string) : string => {
        return '';
    }

    public calculateTotalDifference = (timeFormat: string) : string => {
        return '';
    }
    public assert( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public error( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public group( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public groupEnd( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public info( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public log( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public warn( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

    public metrics( ...args: any[] ) : void {
        // ... the default logger does no work.
    }

}