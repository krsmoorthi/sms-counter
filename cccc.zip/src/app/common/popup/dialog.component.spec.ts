/* tslint:disable */
import { inject, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { MockBackend } from '@angular/http/testing';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Rx';
import { AuthService } from '../service/auth.service';
import { Logger } from '../logging/default-log.service';
import { AppStateService } from '../service/app-state.service';
import { Http, ConnectionBackend, BaseRequestOptions } from '@angular/http';
import { DialogComponent } from './dialog.component';
import { ReviewOrderService } from '../service/review-order.service';
import { BlueMarbleService } from '../service/bm.service';
import { PendingOrderService } from '../service/pending-order.service';
import { AccountService } from '../service/account.service';
import { DisconnectService } from '../service/disconnect.service';
import { ProductService } from '../service/product.service';
import { AddressService } from '../service/address.service';
import { CountryStateService } from '../service/country-state.service';
import { FormBuilder } from '@angular/forms';
import { SystemErrorService } from '../service/system-error.service';
import { TextMaskService } from '../service/text-mask.service';
import { MockServer } from '../../MockServer.test';
import { CTLHelperService } from '../service/ctlHelperService';
import { DirectvService } from '../service/directv.services';

//disabling this file for now - need to redesign again with TestBed
xdescribe('DialogComponent Tests', () => {

  let mockRouter: any = {
    navigate: jasmine.createSpy('navigate')
  };
  let mockServer = new MockServer();

  describe('DialogComponent Tests for Change Flow', () => {
    let finalAddr = mockServer.getResponseForReducerAndApi('user-agent2');
    let finalAddr1 = mockServer.getResponseForReducerAndApi('user-agent1');

    class mockStore { 
      select(reducer) {
        if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-user-reducer'));
        else if (reducer == 'pending') return Observable.of(mockServer.getResponseForReducerAndApi('pending'));
        else if (reducer == 'order') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-order-reducer'));
        else if (reducer == 'existingProducts') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-existingProducts-reducer'));
        else if (reducer == 'customize') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-customize-reducer'));
      }
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    beforeEach(() => TestBed.configureTestingModule({
      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { public AuthService; }
        }
        ,
        {
          provide: Http,
          useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          // tslint:disable-next-line:max-classes-per-file
          useClass: class { public navigate = jasmine.createSpy('navigate'); }
        },
        DialogComponent,
        PendingOrderService,
        AccountService,
        DisconnectService,
        ProductService,
        AddressService,
        CountryStateService,
        FormBuilder,
        SystemErrorService,
        TextMaskService,
        AuthService,
        BlueMarbleService,
        CTLHelperService,
        {provide: Store, useClass: mockStore},
        ReviewOrderService, Logger, AppStateService, CTLHelperService, DirectvService
      ]
    }));
    it('Should have dialog closable', inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.closable).toBeTruthy;
    }));
  
    it('Should description input not be number',
      inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.descriptionHtml).toBeNaN;
    }));
  
    it('Should title input not be number', inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.title).toBeNaN;
    }));
  
    it('Should pdf input not be number', inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.pdfURL).toBeNaN;
    }));
  
    it('Should be cart type is equal to Observable',
      inject([DialogComponent], (dialog: DialogComponent) => {
      let check = dialog.cart;
      expect(check).not.toEqual(jasmine.any(Observable));
    }));
  
    it('Should be cartSubscription undefined',
      inject([DialogComponent], (dialog: DialogComponent) => {
      let check = dialog.cartSubscription;
      expect(dialog.cartSubscription).toBeUndefined;
    }));

    it('Should be totalPrice type is equal to number',
      inject([DialogComponent], (dialog: DialogComponent) => {
      let check = dialog.totalPrice;
      expect(check).toEqual(jasmine.any(Number));
    }));
  
    it('Should have ngOnInit called', inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.ngOnInit()).toHaveBeenCalled;
    }));
    
    it('Should have close called', inject([DialogComponent], (dialog: DialogComponent) => {
      const action = dialog.close(true);
      expect(dialog.enable).toBe(false);
    }));
  
    it('Should have open called', inject([DialogComponent], (dialog: DialogComponent) => {
      const action = dialog.open();
      expect(dialog.enable).toBe(true);
    }));
  
    it('Should have sendValue called', inject([DialogComponent], (dialog: DialogComponent) => {
      const action = dialog.sendValue(true);
      expect(dialog.enable).toBe(false);
    }));
  
    it('Should enable Button', inject([DialogComponent], (dialog: DialogComponent) => {
      const action = dialog.enableButton(true);
      expect(dialog.enable).toBe(true);
    }));
  
    it('Should disable Button', inject([DialogComponent], (dialog: DialogComponent) => {
      const action = dialog.enableButton(false);
      expect(dialog.enable).toBe(false);
    }));
  
    xit('Should have `cancelOrder() ` will be called',
      inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.cancelOrder()).toHaveBeenCalled;
    }));

    it('Should have `ngOnDestroy() ` will be called',
      inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.ngOnDestroy()).toHaveBeenCalled;
    }));
  
    it('Should have enableButton checked', inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.enableButton).toBeTruthy;
    }));

  });

  describe('DialogComponent Tests for Billing Flow', () => {
    let finalAddr = mockServer.getResponseForReducerAndApi('user-agent2');
    let finalAddr1 = mockServer.getResponseForReducerAndApi('user-agent1');

    class mockStore { 
      select(reducer) {
        if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('billing-flow-user-reducer'));
        else if (reducer == 'pending') return Observable.of(mockServer.getResponseForReducerAndApi('pending'));
        else if (reducer == 'order') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-order-reducer'));
        else if (reducer == 'existingProducts') return Observable.of(mockServer.getResponseForReducerAndApi('billing-flow-existingProducts-reducer'));
        else if (reducer == 'customize') return Observable.of(mockServer.getResponseForReducerAndApi('billing-flow-customize-reducer'));
        else if (reducer == 'cart') return Observable.of(mockServer.getResponseForReducerAndApi('billing-flow-cart-reducer'));
        else if (reducer == 'retain') return Observable.of(mockServer.getResponseForReducerAndApi('billing-flow-retain-reducer'));
      }
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    beforeEach(() => TestBed.configureTestingModule({
      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { public AuthService; }
        }
        ,
        {
          provide: Http,
          useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          // tslint:disable-next-line:max-classes-per-file
          useClass: class { public navigate = jasmine.createSpy('navigate'); }
        },
        DialogComponent,
        PendingOrderService,
        AccountService,
        DisconnectService,
        ProductService,
        AddressService,
        CountryStateService,
        FormBuilder,
        SystemErrorService,
        TextMaskService,
        AuthService, BlueMarbleService,
        {provide: Store, useClass: mockStore},
        ReviewOrderService, Logger, AppStateService, CTLHelperService, DirectvService
      ]
    }));


  });

  describe('DialogComponent Tests for Move Flow', () => {
    let finalAddr = mockServer.getResponseForReducerAndApi('user-agent2');
    let finalAddr1 = mockServer.getResponseForReducerAndApi('user-agent1');

    class mockStore { 
      select(reducer) {
        if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('move-flow-hsi-pots-user-reducer'));
        else if (reducer == 'pending') return Observable.of(mockServer.getResponseForReducerAndApi('pending'));
        else if (reducer == 'order') return Observable.of(mockServer.getResponseForReducerAndApi('move-flow-hsi-pots-order-reducer'));
        else if (reducer == 'existingProducts') return Observable.of(mockServer.getResponseForReducerAndApi('move-flow-hsi-pots-existingProducts-reducer'));
        else if (reducer == 'customize') return Observable.of(mockServer.getResponseForReducerAndApi('move-flow-hsi-pots-customize-reducer'));
        else if (reducer == 'cart') return Observable.of(mockServer.getResponseForReducerAndApi('move-flow-hsi-pots-cart-reducer'));
      
      }
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    beforeEach(() => TestBed.configureTestingModule({
      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { public AuthService; }
        }
        ,
        {
          provide: Http,
          useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          // tslint:disable-next-line:max-classes-per-file
          useClass: class { public navigate = jasmine.createSpy('navigate'); }
        },
        DialogComponent,
        PendingOrderService,
        AccountService,
        DisconnectService,
        ProductService,
        AddressService,
        CountryStateService,
        FormBuilder,
        SystemErrorService,
        TextMaskService,
        AuthService, BlueMarbleService,
        {provide: Store, useClass: mockStore},
        ReviewOrderService, Logger, AppStateService, CTLHelperService, DirectvService
      ]
    }));


  });

  describe('DialogComponent Tests for Hold Flow', () => {
    let finalAddr = mockServer.getResponseForReducerAndApi('user-agent2');
    let finalAddr1 = mockServer.getResponseForReducerAndApi('user-agent1');

    class mockStore { 
      select(reducer) {
        if (reducer == 'user') return Observable.of(mockServer.getResponseForReducerAndApi('user-reducer-on-hold'));
        else if (reducer == 'pending') return Observable.of(mockServer.getResponseForReducerAndApi('pending-reducer-on-hold'));
        else if (reducer == 'order') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-order-reducer'));
        else if (reducer == 'existingProducts') return Observable.of(mockServer.getResponseForReducerAndApi('fromHold-flow-existingProducts'));
        else if (reducer == 'customize') return Observable.of(mockServer.getResponseForReducerAndApi('fromHold-flow-customize'));
      
      }
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    beforeEach(() => TestBed.configureTestingModule({
      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { public AuthService; }
        }
        ,
        {
          provide: Http,
          useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          // tslint:disable-next-line:max-classes-per-file
          useClass: class { public navigate = jasmine.createSpy('navigate'); }
        },
        DialogComponent,
        PendingOrderService,
        AccountService,
        DisconnectService,
        ProductService,
        AddressService,
        CountryStateService,
        FormBuilder,
        SystemErrorService,
        TextMaskService,
        AuthService, BlueMarbleService,
        {provide: Store, useClass: mockStore},
        ReviewOrderService, Logger, AppStateService, CTLHelperService, DirectvService
      ]
    }));


  });

  describe('DialogComponent Tests for NI Flow', () => {
    let user = {
      firstName: 'John',
      lastName: 'Peter',
      creditCheckData: {
        dob: '01/01/1950',
        ssn: 'xxx-xx-8932'
      }
    }
    class mockStore { 
      select(reducer) {
        if (reducer == 'user') return Observable.of(user);
        else if (reducer == 'pending') return Observable.of(mockServer.getResponseForReducerAndApi('pending-reducer-on-hold'));
        else if (reducer == 'order') return Observable.of(mockServer.getResponseForReducerAndApi('change-flow-hsi-pots-order-reducer'));
        else if (reducer == 'existingProducts') return Observable.of(mockServer.getResponseForReducerAndApi('fromHold-flow-existingProducts'));
        else if (reducer == 'customize') return Observable.of(mockServer.getResponseForReducerAndApi('fromHold-flow-customize'));
      }
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    beforeEach(() => TestBed.configureTestingModule({
      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { public AuthService; }
        }
        ,
        {
          provide: Http,
          useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          // tslint:disable-next-line:max-classes-per-file
          useClass: class { public navigate = jasmine.createSpy('navigate'); }
        },
        DialogComponent,
        PendingOrderService,
        AccountService,
        DisconnectService,
        ProductService,
        AddressService,
        CountryStateService,
        FormBuilder,
        SystemErrorService,
        TextMaskService,
        AuthService, BlueMarbleService,
        {provide: Store, useClass: mockStore},
        ReviewOrderService, Logger, AppStateService, CTLHelperService, DirectvService
      ]
    }));

    it('should be able to read firstname, lastname and credit check data from the store', inject([DialogComponent], (dialog: DialogComponent) => {
      expect(dialog.callerFirstName).toBe('John');
      expect(dialog.callerLastName).toBe('Peter');
      expect(dialog.dob).toBe('01/01/1950');
      expect(dialog.ssn).toBe('xxx-xx-8932');
    }));


  });
  
  
  
  
});
