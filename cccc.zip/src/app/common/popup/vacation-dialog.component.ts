import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';
import { Store } from '@ngrx/store';
import { AppStore } from '../models/appstore.model';
import { Observable, Subscription } from 'rxjs';
import { Order } from '../models/order.model';
import { CTLHelperService } from '../service/ctlHelperService';
import { Router } from '@angular/router';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { BlueMarbleService } from '../service/bm.service';
import { APIErrorLists, GenericValues } from '../models/common.model';
import { SystemErrorService } from '../service/system-error.service';
import { Cart, ShoppingCart } from '../models/cart.model';
import { Logger } from '../logging/default-log.service';
import 'rxjs/add/operator/switchMap';
import { ExistingServiceItem } from '../models/existing-products.model';
import { User } from '../models/user.model';
import { map, omit } from 'lodash';
import { HelperService } from '../service/helper.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisclosuresRes, rccDetails } from 'app/common/models/disclosures.model';
import { VacationEnums } from '../enums/vacationEnums';
import "rxjs/add/operator/catch";

interface ICartData {
    productOfferingId: string;
    catalogId: string;
}

@Component({
    selector: 'vacation-dialog',
    templateUrl: './vacation-dialog.component.html',
    styleUrls: ['./dialog.component.scss'],
    animations: [
        trigger('vacationDialog', [
            transition('void => *', [
                style({ transform: 'scale3d(.3, .3, .3)' }),
                animate(100)
            ]),
            transition('* => void', [
                animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
            ])
        ])
    ]
})

export class VacationDialogComponent implements OnInit, OnDestroy {    
    public authorized: boolean = false;   
    public viewRccSelected: boolean;
    // tslint:disable-next-line:no-input-rename
    @Input('suspendIneligibilityReason') public suspendIneligibilityReason;
    @Input() public title: string;
    @Input() public invokeCall: string;
    @Input() public closable = true;
    @Input() public isPOTSExisintgProduct;
    @Output() public saveVacationSuspend: EventEmitter<any> = new EventEmitter<any>();
    @Output() public onContinueFromResModal: EventEmitter<any> = new EventEmitter<any>();
    @Output() public resetOrderRefNumber: EventEmitter<any> = new EventEmitter<any>();
    public enable: boolean = false;
    public visible: boolean = false;
    public isretentionOfferAllowed: boolean = false;
    public errorScreen: boolean = false;
    public existingProductItems = [];
    public existingTelephoneNo: any;
    public vacationOptionSelected = [];
    public vacationOptions = [];
    public vacationRestoreOptions = [];
    public vacationOptionsLink;
    private vacationObservable;
    private userObservable: Observable<User>;
    public userSubscription;
    private vacationSubscription;
    private vacOrderRefNumber: any;
    private vacTaskId: any;
    private vacProcessInstanceId: any;
    private isHPSuspended: boolean = false;
    private isHSISuspended: boolean = false;
    public isVacationContinueBtnEnabled: boolean = false;
    private vacRequest: any;
    private isHsiSuspendEligible: boolean = false;
    private isPotsSuspendEligible: boolean = false;
    public isLifeLinePresent: boolean = false;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public exisingProdSubscribe: Subscription;
    public existingProductFromStore;
    private isRedirectToVacOptionPage: boolean = false;
    private vacSusOffers: any;
    private vacSusPOTSOffers: any;
    public restoralFee: number = 0;
    public isDiscountDurationNeedToShow: boolean = false;
    public discountDuration: number;
    private existingVacationCart: Cart = {
        customerOrderItems: []
    };
    public hsiRecurringCharges: any;
    public potsRecurringCharges: any;
    private isVacSusFlow: boolean = false;
    private isVacResFlow: boolean = false;
    private isHSISuspendRequiresProduct: boolean = false;
    private isPOTSSuspendRequiresProduct: boolean = false;
    public discountDurationForHSI: number;
    public discountDurationForPOTS: number;
    public oneTimeChargeForPOTS: number;
    public oneTimeChargeForHSI: number;

    //Vacation Restore related variable
    private isHSIRestoreRequiresProduct: boolean = false;
    private isPOTSRestoreRequiresProduct: boolean = false;
    private isVacSusActiveForHSI: boolean = false;
    public isVacSusActiveForPOTS: boolean = false;
    public restore = {
        rcForHSI: 0,
        otcForHSI: 0,
        rcForPOTS: 0,
        otcForPOTS: 0,
        discountDurationForHSI: 0,
        discountDurationForPOTS: 0,
        restoralFee: 0
    };
    private vacResCart: Cart = {
        customerOrderItems: []
    };
    private existsProducts = [];
    private reconnectOffer: any;
    private cHP: any;
    private cDHP: any;
    private iData: any;
    private cDTV: any;
    public internetTelephoneNumber: any;
    public potsTelephoneNumber: any;
    public dhpTelephoneNumber: any;
    @Output() public toConfig: EventEmitter<any> = new EventEmitter<any>();
    public orderDisclosuresDetails: rccDetails[];
    private existsCartData: ICartData[] = [];
    private existsServCatalogItems = [];
    private existsProductIds: string[] = [];

    constructor(
        private store: Store<AppStore>,
        public ctlHelperService: CTLHelperService,
        private router: Router,
        private bMService: BlueMarbleService,
        private systemErrorService: SystemErrorService,
        private logger: Logger,
        private disclosuresService: DisclosuresService,
        public helperService: HelperService
    ) { }

    public ngOnInit() {
        this.existingProductFromStore = <Observable<Order>>this.store.select('existingProducts');
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.userObservable = <Observable<User>>this.store.select('user');        
        this.userSubscription = this.userObservable.subscribe(data => {
            this.authorized = this.helperService.isAuthorized(ProfileEnums.ALLOW_RETENTION_OFFERS);
            if(data && data.orderDisclosers && data.orderDisclosers.rccGroup && (data.orderDisclosers.rccGroup.length > 0) && data.orderDisclosers.rccGroup[0].rccDetails && (data.orderDisclosers.rccGroup[0].rccDetails.length > 0)) {
                this.orderDisclosuresDetails = data.orderDisclosers.rccGroup[0].rccDetails;
            }
        });

        this.vacationSubscription = this.vacationObservable.switchMap((data) => {
            if (data && data.vacSusInitRes && data.vacSusInitRes.payload && data.vacSusInitRes.payload.addlOrderAttributes && data.vacSusInitRes.payload.addlOrderAttributes[0] !== undefined) {
                if (data.vacSusInitRes.payload.addlOrderAttributes[0].orderAttributeGroup) {
                    data.vacSusInitRes.payload.addlOrderAttributes[0].orderAttributeGroup.map((orderAttributeGroupObj) => {
                        if (orderAttributeGroupObj.orderAttributeGroupName.toUpperCase() === 'HSISUSPENDELIGIBILITY') {
                            orderAttributeGroupObj.orderAttributeGroupInfo && orderAttributeGroupObj.orderAttributeGroupInfo.map((orderAttrGroupInfoObj) => {
                                orderAttrGroupInfoObj.orderAttributes && orderAttrGroupInfoObj.orderAttributes.map((orderAttrObj) => {
                                    if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'ISHSISUSPENDALLOWED')) {
                                        if (orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                                            this.isHsiSuspendEligible = true;
                                        } else {
                                            this.isHsiSuspendEligible = false;
                                        }
                                    }
                                    if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'HSISUSPENDREQUIRESPRODUCT')) {
                                        // If address is NM or ID-S that time we will get orderAttributeValue as VOICE-HP otherwise we get empty string
                                        if (orderAttrObj.orderAttributeValue.toUpperCase() === 'VOICE-HP') {
                                            this.isHSISuspendRequiresProduct = true;
                                        } else {
                                            this.isHSISuspendRequiresProduct = false;
                                        }
                                    }
                                    if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'LIFELINEPRESENT')) {
                                        if (orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                                            this.isLifeLinePresent = true;
                                        } else {
                                            this.isLifeLinePresent = false;
                                        }
                                    }
                                });
                            });
                        }
                        if (orderAttributeGroupObj.orderAttributeGroupName.toUpperCase() === 'POTSSUSPENDELIGIBILITY') {
                            orderAttributeGroupObj.orderAttributeGroupInfo && orderAttributeGroupObj.orderAttributeGroupInfo.map((orderAttrGroupInfoObj) => {
                                orderAttrGroupInfoObj.orderAttributes && orderAttrGroupInfoObj.orderAttributes.map((orderAttrObj) => {
                                    if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'ISPOTSSUSPENDALLOWED')) {
                                        if (orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                                            this.isPotsSuspendEligible = true;
                                        } else {
                                            this.isPotsSuspendEligible = false;
                                        }
                                    }
                                    if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'POTSSUSPENDREQUIRESPRODUCT')) {
                                        if (orderAttrObj.orderAttributeValue.toUpperCase() === GenericValues.iData) {
                                            this.isPOTSSuspendRequiresProduct = true;
                                        } else {
                                            this.isPOTSSuspendRequiresProduct = false;
                                        }
                                    }
                                    if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'LIFELINEPRESENT')) {
                                        if (orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                                            this.isLifeLinePresent = true;
                                        } else {
                                            this.isLifeLinePresent = false;
                                        }
                                    }
                                });
                            });
                        }
                    })
                }
            }
            if (data && data.vacSusInitRes && data.vacSusInitRes.orderRefNumber) {
                this.vacOrderRefNumber = data.vacSusInitRes.orderRefNumber;
            }
            if (data && data.vacSusInitRes && data.vacSusInitRes.taskId) {
                this.vacTaskId = data.vacSusInitRes.taskId;
            }
            if (data && data.vacSusInitRes && data.vacSusInitRes.processInstanceId) {
                this.vacProcessInstanceId = data.vacSusInitRes.processInstanceId;
            }
            if (data.vacSusInitRes && data.vacSusInitRes.payload && data.vacSusInitRes.payload.cart) {
                this.existsCartData = [];
                let vacCart = data.vacSusInitRes.payload.cart;
                this.existingVacationCart.catalogSpecId = vacCart.catalogSpecId;
                this.existingVacationCart.customerOrderItems = [];
                vacCart && vacCart.customerOrderItems && vacCart.customerOrderItems.map((custOrderItem) => {
                    this.existsProductIds = [];
                    if(custOrderItem && custOrderItem.customerOrderSubItems && (custOrderItem.customerOrderSubItems.length > 0)) {
                        custOrderItem.customerOrderSubItems.map(subItem => {
                            if(subItem.productId) {
                                this.existsProductIds.push(subItem.productId);
                            }
                        });
                    }
                    this.existsCartData.push({productOfferingId: custOrderItem.productOfferingId, catalogId: custOrderItem.catalogId});
                    this.existingVacationCart.customerOrderItems.push(custOrderItem);
                });
            }
            if (data && data.vacSusInitRes && data.vacSusInitRes.payload && data.vacSusInitRes.payload.retrievalTypes && (data.vacSusInitRes.payload.retrievalTypes.length > 0)) {
                this.existsServCatalogItems = [];
                this.vacSusOffers = data.vacSusInitRes.payload.retrievalTypes[0];
                this.vacSusOffers && this.vacSusOffers.offers && this.vacSusOffers.offers.map((offer) => {
                    offer && offer.catalogs && offer.catalogs.map((catalog) => {
                        catalog && catalog.catalogItems && catalog.catalogItems.map((catalogItem) => {
                            if (catalogItem && catalogItem.productOffer && catalogItem.productOffer.offerName.toUpperCase() === VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                                this.hsiRecurringCharges = catalogItem.defaultOfferPrice && catalogItem.defaultOfferPrice.discountedRc;
                                this.oneTimeChargeForHSI = catalogItem.defaultOfferPrice && catalogItem.defaultOfferPrice.discountedOtc;
                            }
                            if (catalogItem && catalogItem.productOffer && catalogItem.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_SUS_OFFER_NAME.toUpperCase()) {
                                this.potsRecurringCharges = catalogItem.defaultOfferPrice && catalogItem.defaultOfferPrice.discountedRc;
                                this.oneTimeChargeForPOTS = catalogItem.defaultOfferPrice && catalogItem.defaultOfferPrice.discountedOtc;
                            }
                            if (catalogItem && catalogItem.productOffer && catalogItem.productOffer.offerCategory.toUpperCase() === GenericValues.iData) {
                                catalogItem.productOffer.productComponents && catalogItem.productOffer.productComponents.map((prodCompoObj) => {
                                    if (prodCompoObj.product && prodCompoObj.product.productName && prodCompoObj.product.productName.toUpperCase() === 'MODEM') {
                                        prodCompoObj.product.productAttributes && prodCompoObj.product.productAttributes.map((prodAttr) => {
                                            prodAttr.discounts && prodAttr.discounts.map((discount) => {
                                                if (discount.discountDescription.toUpperCase() === 'VACATION EQUIP. FEE DISCOUNT') {
                                                    this.discountDurationForHSI = discount.discountDuration;
                                                }
                                            })
                                        });
                                    }
                                });
                            }
                            if(catalogItem && (this.existsCartData.length > 0)) {
                                this.existsCartData.forEach(data => {
                                    if(data.productOfferingId === catalogItem.productOfferingId) {
                                        catalogItem.catalogId = data.catalogId;
                                        this.existsServCatalogItems.push(catalogItem);
                                    }
                                });
                            }
                        });
                    });
                });
            }
            if (data && data.vacVoiceHpOffer) {
                this.vacSusPOTSOffers = data.vacVoiceHpOffer;
                this.reconnectOffer = this.getCustomerOrderItem(this.vacSusPOTSOffers);
                this.reconnectOffer = omit(this.reconnectOffer, ['offerDisplayName']);
                data.vacVoiceHpOffer && data.vacVoiceHpOffer.retrievalTypes && data.vacVoiceHpOffer.retrievalTypes.map((retrievalType) => {
                    retrievalType && retrievalType.offers && retrievalType.offers.map((offerObj) => {
                        offerObj && offerObj.catalogs && offerObj.catalogs.map((catalogObj) => {
                            catalogObj && catalogObj.catalogItems.map((catalogItemObj) => {
                                if (catalogItemObj && catalogItemObj.productOffer && catalogItemObj.productOffer.offerName && catalogItemObj.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_RES_OFFER_NAME.toUpperCase()) {
                                    this.restoralFee = catalogItemObj.defaultOfferPrice.otc;
                                }

                                if (catalogItemObj && catalogItemObj.productOffer && catalogItemObj.productOffer.offerName && catalogItemObj.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_SUS_OFFER_NAME.toUpperCase() ) {
                                    this.potsRecurringCharges = catalogItemObj.defaultOfferPrice && catalogItemObj.defaultOfferPrice.discountedRc;
                                    this.oneTimeChargeForPOTS = catalogItemObj.defaultOfferPrice && catalogItemObj.defaultOfferPrice.discountedOtc;
                                    catalogItemObj.productOffer.productComponents && catalogItemObj.productOffer.productComponents.map((prodComponentObj) => {
                                        if (prodComponentObj && prodComponentObj.componentType.toUpperCase() === 'PRIMARY') {
                                            prodComponentObj.product && prodComponentObj.product.productAttributes && prodComponentObj.product.productAttributes.map((prodAttrObj) => {
                                                if (prodAttrObj.isPriceable) {
                                                    if (prodAttrObj.discounts && prodAttrObj.discounts[0] !== undefined && prodAttrObj.discounts[0].discountDuration) {
                                                        if (prodAttrObj.discounts[0].discountDuration === 1200) {
                                                            this.isDiscountDurationNeedToShow = false
                                                        } else {
                                                            this.isDiscountDurationNeedToShow = true
                                                            this.discountDuration = prodAttrObj.discounts[0].discountDuration;
                                                        };
                                                    }
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    });
                });
            }
            if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacSusFlow) this.isVacSusFlow = true;
                else this.isVacSusFlow = false;

                if (data.vacFlowName.isVacResFlow) this.isVacResFlow = true;
                else this.isVacResFlow = false;
            }
            if (data.vacSusActiveProducts) {
                if (data.vacSusActiveProducts.isHSISuspendActive === true) {
                    this.isVacSusActiveForHSI = true;
                }
                if (data.vacSusActiveProducts.isPOTSSuspendActive === true) {
                    this.isVacSusActiveForPOTS = true;
                }
            }
            if (data && data.vacResInitRes) {
                if (data && data.vacResInitRes && data.vacResInitRes.payload && data.vacResInitRes.payload.addlOrderAttributes && data.vacResInitRes.payload.addlOrderAttributes[0] !== undefined) {
                    if (data.vacResInitRes.payload.addlOrderAttributes[0].orderAttributeGroup) {
                        data.vacResInitRes.payload.addlOrderAttributes[0].orderAttributeGroup.map((orderAttributeGroupObj) => {
                            if (orderAttributeGroupObj.orderAttributeGroupName.toUpperCase() === 'HSIRESTOREELIGIBILITY') {
                                orderAttributeGroupObj.orderAttributeGroupInfo && orderAttributeGroupObj.orderAttributeGroupInfo.map((orderAttrGroupInfoObj) => {
                                    orderAttrGroupInfoObj.orderAttributes && orderAttrGroupInfoObj.orderAttributes.map((orderAttrObj) => {
                                        if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'HSIRESTOREREQUIRESPRODUCT')) {
                                            // If address is NM or ID-S that time we will get orderAttributeValue as VOICE-HP otherwise we get empty string
                                            if (orderAttrObj.orderAttributeValue.toUpperCase() === GenericValues.cHP) {
                                                this.isHSIRestoreRequiresProduct = true;
                                            } else {
                                                this.isHSIRestoreRequiresProduct = false;
                                            }
                                        }
                                        if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'LIFELINEPRESENT')) {
                                            if (orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                                                this.isLifeLinePresent = true;
                                            } else {
                                                this.isLifeLinePresent = false;
                                            }
                                        }
                                    });
                                });
                            }
                            if (orderAttributeGroupObj.orderAttributeGroupName.toUpperCase() === 'POTSRESTOREELIGIBILITY') {
                                orderAttributeGroupObj.orderAttributeGroupInfo && orderAttributeGroupObj.orderAttributeGroupInfo.map((orderAttrGroupInfoObj) => {
                                    orderAttrGroupInfoObj.orderAttributes && orderAttrGroupInfoObj.orderAttributes.map((orderAttrObj) => {
                                        if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'POTSRESTOREREQUIRESPRODUCT')) {
                                            if (orderAttrObj.orderAttributeValue.toUpperCase() === GenericValues.iData) {
                                                this.isPOTSRestoreRequiresProduct = true;
                                            } else {
                                                this.isPOTSRestoreRequiresProduct = false;
                                            }
                                        }
                                        if (orderAttrObj && orderAttrObj.orderAttributeName && (orderAttrObj.orderAttributeName.toUpperCase() === 'LIFELINEPRESENT')) {
                                            if (orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                                                this.isLifeLinePresent = true;
                                            } else {
                                                this.isLifeLinePresent = false;
                                            }
                                        }
                                    });
                                });
                            }
                        })
                    }
                }
                if (data.vacResInitRes.orderRefNumber) {
                    this.vacOrderRefNumber = data.vacResInitRes.orderRefNumber;
                }
                if (data.vacResInitRes.taskId) {
                    this.vacTaskId = data.vacResInitRes.taskId;
                }
                if (data.vacResInitRes.processInstanceId) {
                    this.vacProcessInstanceId = data.vacResInitRes.processInstanceId;
                }
                this.vacResCart.customerOrderItems = [];
                if(this.reconnectOffer && this.reconnectOffer.customerOrderSubItems && (this.reconnectOffer.customerOrderSubItems.length > 0) && this.isVacSusActiveForPOTS) {
                    this.vacResCart.customerOrderItems.push(this.reconnectOffer);
                }
                data.vacResInitRes.payload && data.vacResInitRes.payload.cart && data.vacResInitRes.payload.cart.customerOrderItems && data.vacResInitRes.payload.cart.customerOrderItems.map((custOrderItem) => {
                    this.vacResCart.customerOrderItems.push(custOrderItem);
                    if (custOrderItem && custOrderItem.action && custOrderItem.offerCategory && custOrderItem.action.toUpperCase() === 'VACRES-ADD' && custOrderItem.offerCategory.toUpperCase() === GenericValues.iData) {
                        this.restore.rcForHSI = custOrderItem.discountedRc;
                        this.restore.otcForHSI = custOrderItem.discountedOtc;
                    }
                    if (custOrderItem && custOrderItem.action && custOrderItem.offerCategory && custOrderItem.action.toUpperCase() === 'VACRES-ADD' && custOrderItem.offerCategory.toUpperCase() === GenericValues.cHP) {
                        this.restore.rcForPOTS = custOrderItem.discountedRc;
                        this.restore.otcForPOTS = custOrderItem.discountedOtc;
                    }
                });
            }
            let selectedProducts = [];
            if (data && data.existsProducts) {
                this.existsProducts = data.existsProducts;
                let selected = '';
                if (this.existsProducts.indexOf('INTERNET') > -1) {
                    selected = 'Internet,';
                    selectedProducts.push({ type: 'data', selected: GenericValues.sData });
                }
                
                if (this.existsProducts.indexOf('VOICE-HP') > -1) {
                    selected += 'HMPhone,';
                    selectedProducts.push({ type: 'phone', selected: GenericValues.cHP}); 
                }
                if (this.existsProducts.indexOf('VOICE-DHP') > -1) {
                    selected += 'DHPhone,';
                    selectedProducts.push({ type: 'phone', selected: GenericValues.cDHP}); 
                }
                if (this.existsProducts.indexOf('TV') > -1) {
                    selected += 'TV';
                    selectedProducts.push({ type: 'video', selected: GenericValues.cDTV}); 
                }
                let cart: ShoppingCart;
                cart = {
                    selectedService: selected
                };
                this.store.dispatch({ type: 'UPDATE_USER', payload: { currentSelected: selectedProducts } }); 
                this.store.dispatch({ type: 'CREATE_CART', payload: cart });
            }
            if(data && data.vacSusInitRes && data.vacSusInitRes.payload && data.vacSusInitRes.payload.reservedTN) {
                data.vacSusInitRes.payload.reservedTN && data.vacSusInitRes.payload.reservedTN.map((reservedTn) => {
                    if(reservedTn.productType === GenericValues.cHP) {
                        this.potsTelephoneNumber = this.ctlHelperService.maskTelephone(reservedTn.requestedTelephoneNumber);
                    }
                    if(reservedTn.productType === GenericValues.iData) {
                        this.internetTelephoneNumber = this.ctlHelperService.maskTelephone(reservedTn.requestedTelephoneNumber);
                    }
                    if(reservedTn.productType === GenericValues.cDHP) {
                        this.dhpTelephoneNumber = this.ctlHelperService.maskTelephone(reservedTn.requestedTelephoneNumber);
                    }
                });
            }
            if(data && data.vacResInitRes && data.vacResInitRes.payload && data.vacResInitRes.payload.reservedTN) {
                data.vacResInitRes.payload.reservedTN && data.vacResInitRes.payload.reservedTN.map((reservedTn) => {
                    if(reservedTn.productType === GenericValues.cHP) {
                        this.potsTelephoneNumber = this.ctlHelperService.maskTelephone(reservedTn.requestedTelephoneNumber);
                    }
                    if(reservedTn.productType === GenericValues.iData) {
                        this.internetTelephoneNumber = this.ctlHelperService.maskTelephone(reservedTn.requestedTelephoneNumber);
                    }
                    if(reservedTn.productType === GenericValues.cDHP) {
                        this.dhpTelephoneNumber = this.ctlHelperService.maskTelephone(reservedTn.requestedTelephoneNumber);
                    }
                });
            }
            return <Observable<any>>this.store.select('existingProducts');
        }).subscribe((data) => {
            if (data && data.existingProductsAndServices && data.existingProductsAndServices !== undefined) {
                data.existingProductsAndServices.map((existProdAndServices) => {
                    let existsItems = [];
                    existProdAndServices && existProdAndServices.existingServices && existProdAndServices.existingServices.existingServiceItems && existProdAndServices.existingServices.existingServiceItems.map((obj: ExistingServiceItem) => {
                        if (this.existsProducts.indexOf(obj.offerCategory) > -1 && !(existsItems.indexOf(obj.offerCategory) > -1)) {
                            if (obj.offerCategory === GenericValues.iData) {
                                obj['isDisabled'] = false;
                                obj['prodDisplayName'] = 'Internet';
                                obj['isSuspendAllowed'] = this.isHsiSuspendEligible;
                                if (this.isVacSusActiveForHSI) {
                                    obj['isVacSusActive'] = true;
                                    obj['vacOptions'] = [VacationEnums.VACATION_SUSPEND, VacationEnums.VACATION_RESTORE];
                                } else {
                                    obj['vacOptions'] = [VacationEnums.NOT_ADDED_ACTIVE, VacationEnums.VACATION_SUSPEND];
                                    if (this.isVacResFlow) {
                                        obj['isDisabled'] = true;
                                    }
                                }
                                this.iData = obj;
                            } else if (obj.offerCategory === GenericValues.cHP) {
                                obj['isDisabled'] = false;
                                obj['prodDisplayName'] = 'Home Phone';
                                this.isPOTSExisintgProduct = true;
                                obj['isVacSusActive'] = false;
                                obj['isSuspendAllowed'] = this.isPotsSuspendEligible;
                                if (this.isVacSusActiveForPOTS) {
                                    obj['isVacSusActive'] = true;
                                    obj['vacOptions'] = [VacationEnums.VACATION_SUSPEND, VacationEnums.VACATION_RESTORE];
                                } else {
                                    obj['vacOptions'] = [VacationEnums.NOT_ADDED_ACTIVE, VacationEnums.VACATION_SUSPEND];
                                    if (this.isVacResFlow) {
                                        obj['isDisabled'] = true;
                                    }
                                }
                                this.cHP = obj;
                            } else if (obj.offerCategory === GenericValues.cDTV) {
                                obj['prodDisplayName'] = '';
                                obj['isSuspendAllowed'] = false;
                                this.cDTV = obj;
                            } else if (obj.offerCategory === GenericValues.cDHP) {
                                obj['prodDisplayName'] = 'Digital Home Phone';
                                obj['isSuspendAllowed'] = false;
                                this.cDHP = obj;
                            }
                        }
                        if (!(existsItems.indexOf(obj.offerCategory) > -1)) {
                            existsItems.push(obj.offerCategory);
                        }
                    })
                });
                if((data.existingProductsAndServices.length > 0) && data.existingProductsAndServices[0].serviceAddress) {
                    this.store.dispatch({ type: 'FINAL_ADDRESS', payload: data.existingProductsAndServices[0].serviceAddress });
                }
            }
            this.existingProductItems = [];
            if(this.cHP) {
                this.existingProductItems.push(this.cHP);
            }
            if(this.cDHP) {
                this.existingProductItems.push(this.cDHP);
            }
            if(this.iData) {
                this.existingProductItems.push(this.iData);
            }
            if(this.cDTV) {
                this.existingProductItems.push(this.cDTV);
            }
        });

    }

    public open() {
        this.visible = true;
        this.errorScreen = false;
        this.isVacationContinueBtnEnabled = false;
        this.vacationOptionsLink = VacationEnums.ADD_TO_ALL;
        if (this.invokeCall && (this.invokeCall.toUpperCase() === VacationEnums.VACATION_RESTORE.toUpperCase())) {
            this.vacationRestoreOptions = [VacationEnums.VACATION_SUSPEND, VacationEnums.VACATION_RESTORE];
            this.existingProductItems.forEach((value, index) => {
                if (value.isVacSusActive) {
                    this.vacationOptionSelected[index] = value.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
                } else {
                    this.vacationOptionSelected[index] = value.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
                }
            });
        }
        if (this.invokeCall && (this.invokeCall.toUpperCase() === VacationEnums.VACATION_SUSPEND.toUpperCase())) {
            this.title = 'Vacation Service';
            this.vacationOptions = [VacationEnums.NOT_ADDED_ACTIVE, VacationEnums.VACATION_SUSPEND];
            this.existingProductItems.forEach((value, index) => {
                this.vacationOptionSelected[index] = value.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
            });
        }
    }

    public close(flag?: boolean) {
        if (flag) {
            this.enable = false;
            this.visible = false;
            if (this.invokeCall === "Order Disclosures") {
                this.ctlHelperService.setDisclosureModalOpen(false);
            } else if (this.invokeCall === "Vacation Suspend") {
                this.resetOrderRefNumber.emit();
            }
            if (this.vacationSubscription !== undefined) {
                this.vacationSubscription.unsubscribe();
            }
            if (this.userSubscription !== undefined) {
                this.userSubscription.unsubscribe();
            }
        } else {
            this.enable = true;
            this.visible = true;
        }
    }

    public onVacationLinkChange() {
        if (this.vacationOptionsLink === VacationEnums.ADD_TO_ALL && this.isVacSusFlow) {
            this.vacationOptionsLink = VacationEnums.RESTORE_ALL;
            this.isVacationContinueBtnEnabled = true;
            this.existingProductItems.forEach((value, index) => {
                value.isDisabled = false;
                this.vacationOptionSelected[index] = value.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
            });
        } else if (this.isVacSusFlow) {
            this.vacationOptionsLink = VacationEnums.ADD_TO_ALL;
            this.isVacationContinueBtnEnabled = false;
            this.existingProductItems.forEach((value, index) => {
                value.isDisabled = false;
                this.vacationOptionSelected[index] = value.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
            });
        }

        if (this.vacationOptionsLink === VacationEnums.ADD_TO_ALL && this.isVacResFlow) {
            this.vacationOptionsLink = VacationEnums.RESTORE_ALL;
            this.isVacationContinueBtnEnabled = true;
            this.existingProductItems.forEach((obj, index) => {
                if (obj.isVacSusActive) {
                    obj.isDisabled = false;
                    this.vacationOptionSelected[index] = obj.offerCategory + ' ' + VacationEnums.VACATION_RESTORE;
                } else {
                    obj.isDisabled = true;
                    this.vacationOptionSelected[index] = obj.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
                }
            });
        } else if (this.isVacResFlow) {
            this.vacationOptionsLink = VacationEnums.ADD_TO_ALL;
            this.isVacationContinueBtnEnabled = false;
            this.existingProductItems.forEach((obj, index) => {
                if (obj.isVacSusActive) {
                    obj.isDisabled = false;
                    this.vacationOptionSelected[index] = obj.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
                } else {
                    obj.isDisabled = true;
                    this.vacationOptionSelected[index] = obj.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
                }
            });
        }
    }

    /**
     * this function will call when user select option from vacation modal and it will apply automatic rules for required product. It also handles continue CTA enabling functinality.
     * @param value (this param will pass selected value from select box) 
     */
    public onVacationOptionSelected(value) {
        if (this.isVacSusFlow) {
            if (value.indexOf(GenericValues.cHP) > -1 && this.isPOTSSuspendRequiresProduct) {
                this.existingProductItems.forEach((val, index) => {
                    if (val.offerCategory.toUpperCase() === GenericValues.iData) {
                        if (value.toUpperCase() === VacationEnums.VOICE_HP_VACATION_SUSPEND) {
                            val.isDisabled = true;
                            this.isVacationContinueBtnEnabled = true;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
                        } else if (value.toUpperCase() === VacationEnums.VOICE_HP_NOT_ADDED_ACTIVE) {
                            val.isDisabled = false;
                            this.isVacationContinueBtnEnabled = false;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
                        }
                    }
                });
            } else if (value.indexOf(GenericValues.iData) > -1 && this.isHSISuspendRequiresProduct) {
                this.existingProductItems.forEach((val, index) => {
                    if (val.offerCategory.toUpperCase() === GenericValues.cHP) {
                        if (value.toUpperCase() === VacationEnums.INTERNET_VACATION_SUSPEND) {
                            val.isDisabled = true;
                            this.isVacationContinueBtnEnabled = true;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
                        } else if (value.toUpperCase() === VacationEnums.INTERNET_NOT_ADDED_ACTIVE) {
                            val.isDisabled = false;
                            this.isVacationContinueBtnEnabled = false;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.NOT_ADDED_ACTIVE;
                        }
                    }
                });
            } else if (value.indexOf(VacationEnums.VACATION_SUSPEND) > -1) {
                this.isVacationContinueBtnEnabled = true;
            } else {
                this.isVacationContinueBtnEnabled = false;
            }
        }

        if (this.isVacResFlow) {
            if (value.indexOf(GenericValues.cHP) > -1 && this.isPOTSRestoreRequiresProduct) {
                this.existingProductItems.forEach((val, index) => {
                    if (val.offerCategory.toUpperCase() === GenericValues.iData) {
                        if (value.toUpperCase() === VacationEnums.VOICE_HP_VACATION_RESTORE) {
                            val.isDisabled = true;
                            this.isVacationContinueBtnEnabled = true;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.VACATION_RESTORE;
                        } else if (value.toUpperCase() === VacationEnums.VOICE_HP_VACATION_SUSPEND) {
                            val.isDisabled = false;
                            this.isVacationContinueBtnEnabled = false;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
                        }
                    }
                });
            } else if (value.indexOf(GenericValues.iData) > -1 && this.isHSIRestoreRequiresProduct) {
                this.existingProductItems.forEach((val, index) => {
                    if (val.offerCategory.toUpperCase() === GenericValues.cHP) {
                        if (value.toUpperCase() === VacationEnums.INTERNET_VACATION_RESTORE) {
                            val.isDisabled = true;
                            this.isVacationContinueBtnEnabled = true;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.VACATION_RESTORE;
                        } else if (value.toUpperCase() === VacationEnums.INTERNET_VACATION_SUSPEND) {
                            val.isDisabled = false;
                            this.isVacationContinueBtnEnabled = false;
                            this.vacationOptionSelected[index] = val.offerCategory + ' ' + VacationEnums.VACATION_SUSPEND;
                        }
                    }
                });
            } else if (value.indexOf(VacationEnums.VACATION_RESTORE) > -1) {
                this.isVacationContinueBtnEnabled = true;
            } else {
                this.isVacationContinueBtnEnabled = false;
            }
        }
    }

    public getCustomerOrderItem(offer: any) {
        let custOrderItem: any;
        offer && offer.retrievalTypes && offer.retrievalTypes.map((retrievalType) => {
            retrievalType && retrievalType.offers && retrievalType.offers.map((offerObj) => {
                offerObj.catalogs && offerObj.catalogs.map((catalogObj) => {
                    catalogObj.catalogItems && catalogObj.catalogItems.map((catalogItemObj) => {
                        if (catalogItemObj.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_RES_OFFER_NAME.toUpperCase()) {
                            custOrderItem = this.ctlHelperService.getCustomerOrderItem(catalogItemObj, 'vacReconnect');
                        }
                    });
                });
            });
        });
        return custOrderItem;
    }

    public getProductByProductId(existingProd, prodId: any) {
        existingProd && existingProd.customerOrderSubItems.map((custOrderSubItemObj) => {
            if (custOrderSubItemObj.productId === prodId) {
                return custOrderSubItemObj;
            }
        });
        return null;
    }

    private fromOffersPushToVacSusCartItem = (): any => {
        let hsiCustomerOrderItem: any;
        if(this.vacSusOffers && this.vacSusOffers.offers && (this.vacSusOffers.offers.length > 0)) {
            this.vacSusOffers.offers.map((offer) => {
                if(offer.serviceCategory === GenericValues.sData) {
                    if(offer.catalogs && (offer.catalogs.length > 0)) {
                        offer.catalogs.map((catalog) => {
                            if(catalog && catalog.catalogItems && (catalog.catalogItems.length > 0)) {
                                catalog.catalogItems.map(catalogItem => {
                                    catalogItem.catalogId = catalog.catalogId;
                                    if(catalogItem && catalogItem.productOffer && catalogItem.productOffer.offerName && (catalogItem.productOffer.offerName.toUpperCase() === VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase())) {
                                        hsiCustomerOrderItem = this.ctlHelperService.getCustomerOrderItem(catalogItem, 'vacSusOffer');
                                    }
                                });
                            }
                        });
                    }
                }
            });
        }
        return hsiCustomerOrderItem;
    }

    // Please don't remove
    // private fromOffersPushToExistsCartItem = () => {
    //     if(this.existsServCatalogItems && (this.existsServCatalogItems.length > 0)) {
    //         this.existingVacationCart.customerOrderItems = [];
    //         this.existsServCatalogItems.map(catalogItem => {
    //             let custOrderItem = this.ctlHelperService.getCustomerOrderItem(catalogItem, 'vacSusExistsCart', this.existsProductIds);
    //             this.existingVacationCart.customerOrderItems.push(custOrderItem);
    //         })
    //     }
    // }

    /**
     * this function is used to create the request for checkout & scheduling with changes in action when user is suspending only HSI or navigate to vacation-option page if user suspend both
     * @param isHsiSuspendEligible (this param will be true if user is eligible and suspended HSI) 
     * @param isPotsSuspendEligible (this param will be true if user is eligible and suspended POTS)
     */
    public changeActionForVacSusCart(isHsiSuspendEligible?: any, isPotsSuspendEligible?: any) {
        this.vacRequest = {
            orderRefNumber: this.vacOrderRefNumber,
            taskId: this.vacTaskId,
            processInstanceId: this.vacProcessInstanceId,
            taskName: "Checkout & Scheduling",
            payload: {
                cart: {
                    customerOrderItems: []
                }
            }
        }
        if (isHsiSuspendEligible && isPotsSuspendEligible) {
            //this.fromOffersPushToExistsCartItem();
            let hsiCustomerOrderItem = this.fromOffersPushToVacSusCartItem();
            this.store.dispatch({ type: 'HSI_CUSTOMER_ORDER_ITEM_FOR_REQUEST', payload: hsiCustomerOrderItem });
            this.store.dispatch({ type: 'CART_FOR_VACATION_OPTION', payload: this.existingVacationCart });
            this.router.navigate(['/vacation-option']);
        } else if (isHsiSuspendEligible) {
            //this.fromOffersPushToExistsCartItem();
            this.existingVacationCart && this.existingVacationCart.customerOrderItems.map((customerOrderItemObj) => {
                if (customerOrderItemObj.offerCategory.toUpperCase() === GenericValues.iData) {
                    customerOrderItemObj.action = 'VACSUS-REMOVE';
                    customerOrderItemObj.customerOrderSubItems && customerOrderItemObj.customerOrderSubItems.forEach((custOrderSubItemObj) => {
                        if(custOrderSubItemObj.productName.toUpperCase() === 'MODEM') {
                            custOrderSubItemObj.productAttributes && custOrderSubItemObj.productAttributes.map((prodAttribute) => {
                                prodAttribute.compositeAttribute && prodAttribute.compositeAttribute.map((compoAttr) => {
                                    if(compoAttr.attributeName && compoAttr.attributeValue && compoAttr.attributeName.toUpperCase() === 'ACCOUNT TYPE' && compoAttr.attributeValue.toUpperCase() === 'PURCHASE') {
                                        custOrderSubItemObj.action = 'NOCHANGE';
                                    } else if(compoAttr.attributeName && compoAttr.attributeValue && compoAttr.attributeName.toUpperCase() === 'ACCOUNT TYPE' && compoAttr.attributeValue.toUpperCase() === 'LEASE') { 
                                        custOrderSubItemObj.action = 'VACSUS-REMOVE';
                                    }
                                });
                            });
                        } else if(custOrderSubItemObj.productName.toUpperCase() === 'SECURE WIFI STANDALONE') {
                            custOrderSubItemObj.action = 'NOCHANGE';
                        } else {
                            custOrderSubItemObj.action = 'VACSUS-REMOVE';
                        }
                    });
                }
            });
            if(this.existingVacationCart.customerOrderItems && this.existingVacationCart.customerOrderItems.length>0) {
                this.existingVacationCart.customerOrderItems.forEach((custItem) => {
                    this.vacRequest.payload.cart.customerOrderItems.push(custItem);
                });
            }
            let hsiCustomerOrderItem = this.fromOffersPushToVacSusCartItem();
            this.vacRequest.payload.cart.customerOrderItems.push(hsiCustomerOrderItem);
            this.createCart();
        } else if (isPotsSuspendEligible) {
            //this.fromOffersPushToExistsCartItem();
            this.createCart();
            this.store.dispatch({ type: 'CART_FOR_VACATION_OPTION', payload: this.existingVacationCart });
            this.router.navigate(['/vacation-option']);
        }
    }

    public createCart(custOrderItems?: any) {
        let customerOrderItems;
        if (custOrderItems) {
            customerOrderItems = custOrderItems;
        } else {
            customerOrderItems = this.vacRequest.payload.cart.customerOrderItems;
        }
        let payload = {
            cart: {
                customerOrderItems: customerOrderItems
            },
        };
        let cartObject = {
            payload: payload,
        };
        this.store.dispatch({ type: 'CREATE_CART', payload: cartObject });
    }

    public viewRccsDisclosure() {        
               
        let saveVacationService = {
            'saveChanges': true
        }
        this.saveVacationSuspend.emit(saveVacationService);

        this.vacationOptionSelected && this.vacationOptionSelected.map((selectedObj) => {
            if (selectedObj.toUpperCase().indexOf(VacationEnums.VOICE_HP_VACATION_SUSPEND) > -1) this.isHPSuspended = true;
            if (selectedObj.toUpperCase().indexOf(VacationEnums.INTERNET_VACATION_SUSPEND) > -1) this.isHSISuspended = true;
        });

        if ((this.isHsiSuspendEligible && this.isPotsSuspendEligible) && (this.isHPSuspended && this.isHSISuspended)) {
            this.isRedirectToVacOptionPage = true;
            let vacationData;
            this.store.dispatch({ type: 'VACATION_SUSPEND_DATA', payload: vacationData })
            this.changeActionForVacSusCart(this.isHPSuspended, this.isHSISuspended);
        }
        else if (this.isPotsSuspendEligible && this.isHPSuspended) {
            this.isRedirectToVacOptionPage = true;
            this.changeActionForVacSusCart(false, this.isHPSuspended);
        }
        else if (this.isHsiSuspendEligible && this.isHSISuspended)
            this.changeActionForVacSusCart(this.isHSISuspended, false);

        if (!this.isRedirectToVacOptionPage) {
            this.loading = true;
            this.store.dispatch({ type: 'FINAL_VAC_CART', payload: this.vacRequest.payload.cart });
            let request = {
                orderRefNumber: this.vacOrderRefNumber,
                rccGroupId: "SHOPPING",
                salesChannel: "ESHOP - Customer Care",
                versionNumber: "",
                cart: {
                    customerOrderItems: []
                }
            }             
            let customerOrderItems = map(this.vacRequest.payload.cart.customerOrderItems, (obj) => {
                return omit(obj, ['offerDisplayName']);
            });
            if(customerOrderItems && this.isHPSuspended) {
                customerOrderItems.forEach(cust => {
                    if(cust && cust.offerCategory === GenericValues.cHP && cust.action === 'VACSUS-REMOVE') {
                      customerOrderItems.forEach(cust => {
                        if(cust && cust.offerCategory === GenericValues.cHP && cust.offerType === 'SUBOFFER') {
                          cust.customerOrderSubItems && cust.customerOrderSubItems.forEach(sub => {
                            if(sub.productName.indexOf('Directory List') === -1) {
                              cust.action = 'VACSUS-REMOVE';
                              sub.action = 'VACSUS-REMOVE';
                            }
                          });
                        }
                      });
                    }
                });
            }
            request.cart.customerOrderItems = customerOrderItems;           
            this.loading = true;
            let errorResolved = false;
            this.logger.log("info", "vacation-dialog.component.ts", "retrieveRccDisclosuresRequest", JSON.stringify(request));
            this.logger.startTime();
            this.disclosuresService.viewRccsDisclosure(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "vacation-dialog.component.ts", "retrieveRccDisclosuresResponse", error);
                    this.logger.log("error", "vacation-dialog.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorResolved = true;
                    this.vacationSuspendProceed();
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data: DisclosuresRes) => {                    
                        this.logger.endTime();
                        this.logger.log("info", "vacation-dialog.component.ts", "retrieveRccDisclosuresResponse", JSON.stringify(data));
                        this.logger.log("info", "vacation-dialog.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;                   
                        if (data && data.rccGroup) {
                            this.close(true);
                            if (data && data.rccGroup && data.rccGroup.length > 0) {
                                this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: data });
                                //this.existingProductsComponet.onDisclosureModalOpen();
                                this.ctlHelperService.setDisclosureModalOpen(true);
                            } else {
                                this.vacationSuspendProceed();
                            }
                        }
                    },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "vacation-dialog.component.ts", "retrieveRccDisclosuresResponse", error);
                        this.logger.log("error", "vacation-dialog.component.ts", "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        if(!errorResolved) {
                            this.vacationSuspendProceed();
                            this.loading = false;
                        }
                    }) 
        }             
        
      }      
      public isDisclosureAllowed: boolean = true;      
      public toContinue() {
          if (this.isDisclosureAllowed) {
              this.viewRccsDisclosure();              
              this.store.dispatch({ type: 'SELECTED_VACATION_DATA', payload: this.vacationOptionSelected })              
          } else {
              this.vacationSuspendProceed();
          }
      }

      public toConfigFn() {       
        this.vacationSuspendProceed(true);
      }

    public vacationSuspendProceed(value?) {
        if (this.isVacSusFlow) {
            if(this.vacationOptionSelected.length === 0){
                this.vacationObservable = <Observable<any>>this.store.select('vacation');
                this.vacationSubscription = this.vacationObservable.subscribe((data) => {
                    this.vacationOptionSelected = data.selectedVacationData;
                });
            }
            const hasInternetVacationSuspend = this.vacationOptionSelected.find((vacOption) =>
                vacOption.toUpperCase() === VacationEnums.INTERNET_VACATION_SUSPEND);
                        if(value){
                            this.viewRccSelected = true;
                        } else{
                            this.viewRccSelected = false;
                        }
            if (!this.errorScreen && hasInternetVacationSuspend  && !this.viewRccSelected) {
                this.errorScreen = true;
            }
            else {
                let saveVacationService = {
                    'saveChanges': true
                }
                this.saveVacationSuspend.emit(saveVacationService);

                this.vacationOptionSelected && this.vacationOptionSelected.map((selectedObj) => {
                    if (selectedObj.toUpperCase().indexOf(VacationEnums.VOICE_HP_VACATION_SUSPEND) > -1) this.isHPSuspended = true;
                    if (selectedObj.toUpperCase().indexOf(VacationEnums.INTERNET_VACATION_SUSPEND) > -1) this.isHSISuspended = true;
                });

                if ((this.isHsiSuspendEligible && this.isPotsSuspendEligible) && (this.isHPSuspended && this.isHSISuspended)) {
                    this.isRedirectToVacOptionPage = true;
                    let vacationData;
                    this.store.dispatch({ type: 'VACATION_SUSPEND_DATA', payload: vacationData })
                    this.changeActionForVacSusCart(this.isHPSuspended, this.isHSISuspended);
                }
                else if (this.isPotsSuspendEligible && this.isHPSuspended) {
                    this.isRedirectToVacOptionPage = true;
                    this.changeActionForVacSusCart(false, this.isHPSuspended);
                }
                else if (this.isHsiSuspendEligible && this.isHSISuspended)
                    this.changeActionForVacSusCart(this.isHSISuspended, false);
                if (!this.isRedirectToVacOptionPage && this.authorized) {
                    this.loading = true;
                    this.store.dispatch({ type: 'FINAL_VAC_CART', payload: this.vacRequest.payload.cart });
                    let req = {
                        orderRefNumber: this.vacOrderRefNumber,
                        taskId: this.vacTaskId,
                        processInstanceId: this.vacProcessInstanceId,
                        taskName: "Get Addon Offers",
                        payload: {
                            cart: {
                                catalogSpecId: this.existingVacationCart.catalogSpecId,
                                customerOrderItems: []
                            },
                            productConfiguration: [],
                            dhpAdditionalInfo: {}
                        }
                    }
                                        
                    let customerOrderItems = map(this.vacRequest.payload.cart.customerOrderItems, (obj) => {
                        return omit(obj, ['offerDisplayName']);
                    });
                    if(customerOrderItems && this.isHPSuspended) {
                        customerOrderItems.forEach(cust => {
                            if(cust && cust.offerCategory === GenericValues.cHP && cust.action === 'VACSUS-REMOVE') {
                              customerOrderItems.forEach(cust => {
                                if(cust && cust.offerCategory === GenericValues.cHP && cust.offerType === 'SUBOFFER') {
                                  cust.customerOrderSubItems && cust.customerOrderSubItems.map(sub => {
                                    if(sub.productName.indexOf('Directory List') === -1) {
                                      cust.action = 'VACSUS-REMOVE';
                                      sub.action = 'VACSUS-REMOVE';
                                    }
                                  })
                                }
                              });
                            }
                        })
                    }
                    req.payload.cart.customerOrderItems = customerOrderItems;
                    this.store.dispatch({ type: 'VACATION_CART', payload: req.payload.cart.customerOrderItems });
                    this.logger.log("info", "vacation-dialog.component.ts", "scheduleVacationCallSubmitRequest", JSON.stringify(req));
                    this.logger.startTime();
                    this.bMService.scheduleVacationCall(req)
                        .catch((error: any) => {
                            this.logger.endTime();
                            this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitResponse", error);
                            this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.loading = false;
                            this.systemErrorService.logAndRouteUnexpectedError("error", " ", "checkoutAndSchedulingSubmit", "vacation-dialog.component.ts", "Vacation Modal", error);
                            return Observable.throwError(null);
                        })
                        .subscribe(
                            (data) => {
                                this.logger.endTime();
                                this.logger.log("info", "vacation-dialog.component.ts", "scheduleVacationCallSubmitResponse", JSON.stringify(data));
                                this.logger.log("info", "vacation-dialog.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                                this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                                if (this.isPOTSExisintgProduct) {
                                    this.createCart();
                                }
                                this.ctlHelperService.removeLocalStorage('vacation-reconnect');
                                this.ctlHelperService.storeRequestProcessData(data, 'customize-services', 'submit', 'vacation');                             
                                this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: data });
                                this.router.navigate(['/customize-services']);
                            },
                            (error) => {
                                this.logger.endTime();
                                this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitResponse", error);
                                this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                this.systemErrorService.getAPIResponseError(error, 'INIT', 'vacation-dialog.component.ts', 'Existing Product Page');
                            }
                        )
                }
                else if(!this.authorized && !this.isRedirectToVacOptionPage) {
                    this.loading = true;
                    this.store.dispatch({ type: 'FINAL_VAC_CART', payload: this.vacRequest.payload.cart });
                    let req = {
                        orderRefNumber: this.vacOrderRefNumber,
                        taskId: this.vacTaskId,
                        processInstanceId: this.vacProcessInstanceId,
                        taskName: "Checkout & Scheduling",
                        payload: {
                            cart: {
                                customerOrderItems: []
                            }
                        }
                    }
                    let customerOrderItems = map(this.vacRequest.payload.cart.customerOrderItems, (obj) => {
                        return omit(obj, ['offerDisplayName']);
                    });
                    if(customerOrderItems && this.isHPSuspended) {
                        customerOrderItems.forEach(cust => {
                            if(cust && cust.offerCategory === GenericValues.cHP && cust.action === 'VACSUS-REMOVE') {
                              customerOrderItems.forEach(cust => {
                                if(cust && cust.offerCategory === GenericValues.cHP && cust.offerType === 'SUBOFFER') {
                                  cust.customerOrderSubItems && cust.customerOrderSubItems.forEach(sub => {
                                    if(sub.productName.indexOf('Directory List') === -1) {
                                      cust.action = 'VACSUS-REMOVE';
                                      sub.action = 'VACSUS-REMOVE';
                                    }
                                  })
                                }
                              })
                            }
                        })
                    }
                    req.payload.cart.customerOrderItems = customerOrderItems;
                    this.logger.log("info", "vacation-dialog.component.ts", "scheduleVacationCallSubmitRequest", JSON.stringify(req));
                    this.logger.startTime();
                    this.bMService.scheduleVacationCall(req)
                        .catch((error: any) => {
                            this.logger.endTime();
                            this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitResponse", error);
                            this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.loading = false;
                            this.systemErrorService.logAndRouteUnexpectedError("error", " ", "checkoutAndSchedulingSubmit", "vacation-dialog.component.ts", "Vacation Modal", error);
                            return Observable.throwError(null);
                        })
                        .subscribe(
                            (data) => {
                                this.logger.endTime();
                                this.logger.log("info", "vacation-dialog.component.ts", "scheduleVacationCallSubmitResponse", JSON.stringify(data));
                                this.logger.log("info", "vacation-dialog.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                                this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
                                if (this.isPOTSExisintgProduct) {
                                    this.createCart(data.payload.cart.customerOrderItems);
                                }
                                this.ctlHelperService.removeLocalStorage('vacation-reconnect');
                                this.router.navigate(['/vacation-schedule-appt-ship']);
                            },
                            (error) => {
                                this.logger.endTime();
                                this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitResponse", error);
                                this.logger.log("error", "vacation-dialog.component.ts", "scheduleVacationCallSubmitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                this.systemErrorService.getAPIResponseError(error, 'INIT', 'vacation-dialog.component.ts', 'Existing Product Page');
                            }
                        )
                }
                this.close(true);
            }
        }
        if (this.isVacResFlow) {
            this.vacRequest = {
                orderRefNumber: this.vacOrderRefNumber,
                taskId: this.vacTaskId,
                processInstanceId: this.vacProcessInstanceId,
                taskName: "Checkout & Scheduling",
                payload: {
                    cart: {
                        customerOrderItems: []
                    }
                }
            }
            this.vacRequest.payload.cart = this.vacResCart;
            this.store.dispatch({ type: 'VAC_RES_CART', payload: this.vacRequest });
            let vacReconnectOffer = this.ctlHelperService.getLocalStorage('vacation-reconnect');
            if (vacReconnectOffer && this.isVacSusActiveForPOTS) {
                this.store.dispatch({type:'VACATION_RECONNECT_OFFER', payload: vacReconnectOffer})
            }
            this.ctlHelperService.removeLocalStorage('vacation-reconnect');
            this.router.navigate(['/vacation-product-offer']);
        }
    }

    public vacationSuspendReturn() {
        if (this.errorScreen) {
            this.errorScreen = false;
        }
    }

    public ngOnDestroy() {
        if (this.exisingProdSubscribe !== undefined) this.exisingProdSubscribe.unsubscribe();
        if (this.vacationSubscription !== undefined) {
            this.vacationSubscription.unsubscribe();
        }
    }
}