import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VacationDialogComponent } from './vacation-dialog.component';
import { MockServer } from 'app/MockServer.test';
import { Observable, of } from 'rxjs';
import { Store } from '@ngrx/store';
import { MockBlueMarbleService, MockAppStateService, MockSystemErrorService, MockLogger, MockDisclosuresService, MOCK_ROUTES } from '../service/mockServices.test';
import { BlueMarbleService } from '../service/bm.service';
import { CTLHelperService } from '../service/ctlHelperService';
import { RouterTestingModule } from '@angular/router/testing';
import { SystemErrorService } from '../service/system-error.service';
import { Logger } from '../logging/default-log.service';
import { DisclosuresService } from '../service/disclosures.service';
import { HelperService } from '../service/helper.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { AccordionModule, TabsModule } from 'ngx-bootstrap';
import { AuthService } from '../service/auth.service';
import { AppStateService } from '../service/app-state.service';

describe('VacationDialogComponent', () => {
  let component: VacationDialogComponent;
  let fixture: ComponentFixture<VacationDialogComponent>;
  const mockServer = new MockServer();

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    TextMaskModule,
    SharedCommonModule,
    SharedModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES),
    BrowserAnimationsModule
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }

  const store = { provide: Store, useValue: mockRedux };
  const cTLHelperService = CTLHelperService;
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const logger = { provide: Logger, useClass: MockLogger };
  const disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const helperService = HelperService;
  const authService = AuthService;

  const providers = [
    store, cTLHelperService, blueMarbleService, systemErrorService, logger, disclosuresService, helperService,
    authService, appStateService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [ VacationDialogComponent ],
    providers: providers
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VacationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should have vacation dialog closable', () => {
    expect(component.closable).toBeTruthy;
  });

  it('should have vacation suspend eligibility data', () => {
      expect((component as any).isHsiSuspendEligible).toBeTruthy;
      expect((component as any).isHSISuspendRequiresProduct).toBe(false);
      expect((component as any).isLifeLinePresent).toBe(false);
  });

  it('should call open and close function of vacation suspend flow', () => {
    component.invokeCall = 'Vacation Suspend';
    component.open();
    component.onVacationLinkChange();
    expect(component.visible).toBe(true);
    component.close(true);
  });

  it('on vacation option selected for hsi, it should select pots programatically', () => {
    component.invokeCall = 'Vacation Restore';
    component.open();
    expect(component.visible).toBe(true);
    component.close(false);
  });

  it('on call onVacationOptionSelected', () => {
    const returnVal = component.onVacationOptionSelected('VOICE-HP');
    component.onVacationOptionSelected('INTERNET');
    component.onVacationOptionSelected('Vacation Suspend');
    (component as any).isVacResFlow = true;
    component.onVacationOptionSelected('VOICE-HP');
    component.onVacationOptionSelected('INTERNET');
    component.onVacationOptionSelected('Vacation Suspend');
    expect(returnVal).toBeUndefined();
  });

  it('on call changeActionForVacSusCart', () => {
    const returnVal = component.changeActionForVacSusCart(true, true);
    component.changeActionForVacSusCart(false, true);
    component.changeActionForVacSusCart(true, false);
    component.changeActionForVacSusCart(false, false);
    expect(returnVal).toBeUndefined();
  });

  it('on call toContinue', () => {
    component.isDisclosureAllowed = false;
    component.toContinue();
    component.toConfigFn();
    expect((component as any).isVacSusFlow).toBe(true);
  });

  it('on call getProductByProductId', () => {
    component.vacationSuspendReturn();
    const returnVal = component.getProductByProductId(null, null);
    expect(returnVal).toEqual(null);
  });

  it('on call vacationSuspendReturn', () => {
    const returnVal = component.vacationSuspendReturn();
    expect(returnVal).toEqual(undefined);
  });

});
