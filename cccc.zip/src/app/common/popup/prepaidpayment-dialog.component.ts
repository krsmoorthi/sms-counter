import { Component, OnInit, OnDestroy, Input, Output, EventEmitter,  NgZone} from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'prepaid-dialog',
  templateUrl: './prepaidpayment-dialog.component.html',
  styleUrls: ['./dialog.component.scss'],
  animations: [
    trigger('pastdialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class PerpaidPaymentDialogComponent implements OnInit, OnDestroy {
  @Input() public closable = true;
  @Input() public visibleOverlay: boolean;
  @Input() public title: string;
  @Input() public invokeCall: string;
  @Input() public paymentObj: any;
  @Output() public updateAccount: EventEmitter<object> = new EventEmitter<object>();
  public enable: boolean = false;
  public errorMsg: string;
  public loading: boolean = false;
  public success: boolean = false;
  private duePaymentCallbackInvoked: boolean = false;

  constructor(
    private zone: NgZone
  ) {
  }

  public ngOnInit() {
  }

  public open() {
    window['angularComponentRef'] = {
      zone: this.zone,
      componentFn: (value) => this.pastduePaymentCallback(value),
      component: this
    };
    this.enable = true;
    this.visibleOverlay = true;
  }

  public closePastdueDialog() {
    window['angularComponentRef'] = {
      zone: this.zone,
      componentFn: (value) => '',
      component: this
    };
    this.enable = false;
    this.visibleOverlay = false;
    if (!this.duePaymentCallbackInvoked) {
      this.updateAccount.emit({
        error: 'Cancelled', sessionId: '',
        isDepositCallback: this.paymentObj.isDepositModal,
        paymentStatus: 'Cancelled', invokeCall: this.invokeCall
      });
    }
  }

  public pastduePaymentCallback(callbackParam) {
    this.duePaymentCallbackInvoked = true;
    var vars = callbackParam.split("&");
    var session;
    let paymentStatus;
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split("=");
      if (pair[0] === 'status') {
        paymentStatus = pair[1];
      }
      if (pair[0] === 'PaymentID') {
        session = pair[1];
      } else if (session === undefined && pair[0] === 'ErrorCode') {
        session = pair[1];
        this.closePastdueDialog();
      } else if (pair[0] === 'success') {
      }
    }
    this.updateAccount.emit({ error: paymentStatus, sessionId: session, isDepositCallback: this.paymentObj.isDepositModal, paymentStatus: paymentStatus, invokeCall: this.invokeCall });
    this.closePastdueDialog();
  }

  public ngOnDestroy() {
  }
}
