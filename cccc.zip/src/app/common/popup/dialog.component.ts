import { DatePipe } from "@angular/common";
// tslint:disable-next-line:no-unused-variable
import { Component, EventEmitter, Input, NgZone, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild, ElementRef } from "@angular/core";
import { trigger, style, animate, transition } from '@angular/animations';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DomSanitizer } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { Store } from "@ngrx/store";
import { DisconnectReasons, Service } from "app/common/models/disconnect-reasons.model";
import { State } from "app/common/models/state.model";
import { SystemErrorService } from "app/common/service/system-error.service";
import { cloneDeep, groupBy, keys, sortBy } from "lodash";
import { ModalDirective } from "ngx-bootstrap";
// tslint:disable-next-line:no-unused-variable
import { TypeaheadMatch } from "ngx-bootstrap/typeahead";
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";
import { MultimatchBillingComponent } from "../address/multimatch-billing.component";
import { MultimatchMoveComponent } from "../address/multimatch-move.component";
import { WorkingServiceMoveComponent } from "../address/workingservice-move.component";
import { Logger } from "../logging/default-log.service";
import { AppStore } from "../models/appstore.model";
import { ContactInfo, CustomerOrderItems, EnterpriseAddress, OTCcart, ShoppingCart } from "../models/cart.model";
import { Order, OrderRemarks } from "../models/order.model";
import { AttributesCombination, Catalogs, ProductOfferings, Products } from "../models/product.model";
import { AccountService } from "../service/account.service";
import { AddressService } from "../service/address.service";
import { BlueMarbleService } from "../service/bm.service";
import { CTLHelperService } from "../service/ctlHelperService";
import { DirectvService } from "../service/directv.services";
import { PendingOrderService } from "../service/pending-order.service";
import { ReviewOrderService } from "../service/review-order.service";
import { Validations } from "../validations/validations";
import { APIErrorLists, ErrorResponse, GenericValues, serverErrorMessages } from "./../models/common.model";
import { User } from "./../models/user.model";
import { CustomizeServices } from "./../models/customize-services.model";
import { CountryStateService } from "./../service/country-state.service";
import { DisconnectService } from "./../service/disconnect.service";
import { ProductService } from "./../service/product.service";
import { TextMaskService } from "./../service/text-mask.service";
import { CreditCheck } from "app/common/models/credit-check.model";
import { manualRequestReq, telephoneNumber, tnStatus, checkPotsTnAvailabilityResponse } from "../models/manual-request-tn.model";
import { rccDetails } from "../models/disclosures.model";
import { debounceTime, mergeMap } from "rxjs/operators";
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';
import { request } from 'http';

@Component({
    selector: "app-dialog",
    templateUrl: "./dialog.component.html",
    styleUrls: ["./dialog.component.scss"],
    animations: [
        trigger("dialog", [
            transition("void => *", [
                style({ transform: "scale3d(.3, .3, .3)" }),
                animate(100)
            ]),
            transition("* => void", [
                animate(100, style({ transform: "scale3d(.0, .0, .0)" }))
            ])
        ])
    ]
})
export class DialogComponent implements OnInit, OnDestroy, OnChanges {
    public allowStackOrders: boolean;
    public legacyProvider: any;
    public contactNumValue: string = "";
    public lastNameValue: string = "";
    public contactNumberValue: string = "";
    public secContactNumberValue: string = "";
    public secLastNameValue: string = "";
    public secFirstNameValue: string = "";
    public showCarrierList: any;
    public selectedCarrierRestoredList: any;
    public selectedCarrierSuspendedList: any;
    public authUsers: any;
    public firstNameFirst: string = "";
    public lastNameFirst: string = "";
    public contactFirst: string = "";
    public firstNameSecond: string = "";
    public lastNameSecond: string = "";
    public contactSecond: string = "";
    public discountSelectedValue: boolean;
    public giftCardSelected: boolean;
    public selectedGiftCardDiscounts: any;
    public selectedDiscounts: any;
    public fetchRuleCarreirListres: any;
    public updatedAllLdCarriers: boolean = false;
    public allRestoreCarriersSelected: boolean;
    public lbBLockContinueButtonActive: boolean = false;
    public listofRestoreCarriers: any;
    public nonpaySuspendLdRestoreAtive: boolean = false;
    public ldBlock: FormGroup;
    public setOfListCarriers: any;
    public searchFlag: boolean = false;
    public countCarrierCodeList: number;
    public countList: number = 1;
    public listCarrierListAll: any;
    public restoreListOfCarriers: any;
    public listofCarriers: any = [];
    public addAuthUserForm: FormGroup;
    public disableViewAllCarrier: boolean = false;
    public displayViewAllCarriers: boolean = false;
    public uncheckedCarrierList: any = [];
    public selectedExistingData: any = [];
    public checked: boolean;
    public viewSelectedCarriers: boolean = false;
    public viewAllCarriers: boolean = true;
    public selectedListCarriers: any = [];
    public vacationResData: any;
    public creditRevObsv: Observable<CreditCheck>;
    public creditRevObsvData: any;
    public accountObservable: Observable<any>;
    public accountObservableData: any;
    public nonpaySuspendRestoreInitData: any;
    public showDtvRestoreProd: boolean = false;
    public showLDRestoreProd: boolean = false;
    public showPotsRestoreProd: boolean = false;
    public showDhpRestoreProd: boolean = false;
    public showInternetRestoreProd: boolean = false;
    public suspendedAllSubItems: boolean = false;
    public suspendedAll: boolean = false;
    public suspendedAccountnum: any;
    public suspendTelephoneNumber: any;
    public showDtvSuspendProd: boolean = false;
    public showInternetSuspendProd: boolean = false;
    public showDhpSuspendProd: boolean = false;
    public showLDsuspendProd: boolean = false;
    public showPotsSuspendProd: boolean = false;
    public suspendedProducts: any;
    public lifelineAdjustmentPotsData: any;
    public lifelineDiscountsPotsData: any;
    public lifelineConfigPotsData: any;
    public lifelineRequestData: any;
    public lifelineAdjustmentData: any;
    public lifelineDiscountsData: any;
    public lifelineConfigData: any;
    public lifelineInternet: any;
    public isRentrant: boolean = false;
    public isMoveAllowed: boolean;
    public offerDisplayName: any;
    public orderSummary: any;
    public custdata: any;
    public shipping: boolean;
    public schedule: boolean;
    public amountShown: any;
    public adjustmentsNonRecurring: boolean = false;
    public arcstartDatefour: {
        llarcCreditInd: boolean;
        discountCode: string;
        recurringStateCreditDesc: any;
        startDate: any;
        endDate: string;
        zone1Ind: boolean;
        zone2Ind: boolean;
        WireMaintanaceInd: boolean;
        actionType: string;
    };
    public arcstartDatethree: {
        llarcCreditInd: boolean;
        discountCode: string;
        recurringStateCreditDesc: any;
        startDate: any;
        endDate: string;
        zone1Ind: boolean;
        zone2Ind: boolean;
        WireMaintanaceInd: boolean;
        actionType: string;
    };
    public discountCode: any;
    public saveButton: boolean = false;
    public ruralNewAddress: boolean = false;
    public LifeLineDiscounts: { discounts: any[] };
    public discountsUpdates: any[];
    public recurringStateCreditDescone: any;
    public WireMaintanaceIndRes: any;
    public zone2IndRes: any;
    public zone1IndRes: any;
    public azCreditsEndDateRes: any;
    public azCreditsStartDateRes: any;
    public recurringStateCreditDescRes: any;
    public arcCreditsEndDateRes: any;
    public arcCreditsStartDateRes: any;
    public llarcCreditIndRes: any;
    public arcstartDateFour: {
        llarcCreditInd: any;
        discountCode: any;
        startDate: string;
        endDate: string;
        recurringStateCreditDesc: any;
        zone1Ind: any;
        zone2Ind: any;
        WireMaintanaceInd: any;
        actionType: any;
    };
    public arcstartDateThree: {
        llarcCreditInd: any;
        discountCode: any;
        startDate: string;
        endDate: string;
        recurringStateCreditDesc: any;
        zone1Ind: any;
        zone2Ind: any;
        WireMaintanaceInd: any;
        actionType: any;
    };
    public stateCreditrecurring: boolean = false;
    public lifeLineDic = [];
    public arcstartDateTwo: {
        llarcCreditInd: any;
        discountCode: any;
        startDate: string;
        endDate: string;
        recurringStateCreditDesc: any;
        zone1Ind: any;
        zone2Ind: any;
        WireMaintanaceInd: any;
        actionType: any;
    };
    public arcstartDateone: {
        llarcCreditInd: any;
        discountCode: any;
        recurringStateCreditDesc: any;
        startDate: any;
        endDate: string;
        zone1Ind: any;
        zone2Ind: any;
        WireMaintanaceInd: any;
        actionType: any;
    };
    public WireMaintanaceInd: any;
    public legacy: string;
    public tnAssUrl: any;
    public zone2Ind: any;
    public zone1Ind: any;
    public recurringStateCredit: any = "ARC Credit (LLARC)";
    public llarcCreditInd: any;
    public adjustmentAmount: any;
    public nonRecurringStateCreditDesc: any;
    public recurringStateCreditDesc: any;
    @Input() public errModal: ModalDirective;
    @Input() public portedTNExists: boolean;
    @Input() public PONRChanged: boolean;
    @Input() public NIPendingStackAmend: boolean;
    @Input() public enableAZMEDIoption: boolean;
    @Input() public closable = true;
    @Input() public lifelineReponseData: any;
    @Input() public lifelineRespData: any;
    @Input() public visible: boolean;
    @Input() public descriptionHtml: string;
    @Input() public title: string;
    @Input() public pdfURL: string;
    @Input() public pendingCancel: string;
    @Input() public invokeCall: string;
    @Input() public disconnectResume: string;
    @Input() public moveResume: string;
    @Input() public addId: string;
    @Input() public otcData: any[];
    @Input() private paymentObj: any;
    @Input() public disconnectMsg: string;
    @Input() public cancelMsg: string;
    @Input() public cancelBack: string;
    @Input() public reasonsRemove: any;
    @Input() public removeMsg: string;
    @Input() public contentCheck: string;
    @Input() public reasonsList: any;
    @Input() public rccDetails: any;
    @Input() public e911address: any;
    @Input() public otcInstallObj: any;
    @Input() public productType: string;
    @Input() public orderReferenceNumber: string;
    @Input() public disconnectReq: any;
    @Input() public defaultTN: string;
    @Input() public carrierList: any;
    @Input() public carrierInfo: any;
    @Input() public addlOrderAttributesPorting: any;
    @Input() public telephoneNumber: string;
    @Input() public fromPOReview: string;
    @Input() public savedPhoneTN: any;
    @Input() public ban: string;
    @Input() public addressListing: any;
    @Input() public updatedListedAddressInput: any;
    @Input() public selectedListedType: string;
    @Input() public personalDetails: any;
    @Input() public reEntrant: any;
    @Input() public unabletoStackMsg: string;
    @Input() public unabletoCancelMsg: string;
    @Input() public scheduledPendingDueDate: any;
    @Input() public orderType: string;
    @Input() public unabletoAmendMsg: string;
    @Input() public othrOdrActDpSelected: string;
    @Input() public fromExisting: boolean;
    @Input() public messageRecommendUp: string;
    @Output() public addOfferExpired: EventEmitter<object> = new EventEmitter<object>();
    @Input() public messageRecommendDown: string;
    @Input() public billingType: string;
    @Input() public waivableOTC: any;
    @Input() public retainWaivedReason: any;
    @Output() waivedOtc: EventEmitter<any> = new EventEmitter<any>();
    public adjustableOtcProducts: any;
    public otcWaiverList = { waivers: [], reason: '' };
    public addonAttributes: any;
    public cartObservable: Observable<any>;
    public cartObservableData: any;
    public customizeObservable: Observable<any>;
    public customizeSubscription: Subscription;
    public potsExists: boolean;
    public names: any;
    public nam: any;
    public location: boolean;
    public vendorLocations: any;
    public centerLocations: any;
    public retailLocations: any;
    public selectedLocType: any;
    public newReserveTNObject: any;
    public exchangeKeyValue: any;
    public pooledTNIndicatorValue: any;
    public isrccAcknowledged: any;
    public rccErrorMessage: any;
    public isRccErrorFound: boolean = false;
    public vacationObservable: Observable<any>;
    public vacationSubscription: Subscription;
    public vacationopton: any;
    public cityselected: any;
    public validatedDC: any;
    public isValidDealerCode: boolean;
    public dealerCodeChanged: boolean;
    private productDealerCodeInfo: any;
    public stackChange: any = "";
    private opusCancelFlag: boolean = false;
    public backUpCarrierList: any;
    public viewCarrier: boolean = false;
    public hasError: boolean;
    public stackData: any;
    private TnOrders: any[];
    private pendingTNs: any[] = [];
    public crisBTN: any;
    public edsFlag: boolean = false;
    public newLocation: any;
    public offerexpired: any;
    public prepaidAmountDone: any;
    public waivedReason: any;
    public showReasonList: boolean = false;
    public waivedCharge: number = 0;
    @Input() set addonAttributesListing(event: any) {
        this.addonAttributes = event;
        if (this.addonAttributes && this.addonAttributes !== undefined) {
            this.addOnAttribForm = this.fb.group({
                title1: this.addonAttributes.title1 ? this.addonAttributes.title1 : "",
                title2: this.addonAttributes.title2 ? this.addonAttributes.title2 : "",
                lineage: this.addonAttributes.lineage ? this.addonAttributes.lineage : "",
                designation: this.addonAttributes.designation ? this.addonAttributes.designation : "",
                Nickname: this.addonAttributes.Nickname ? this.addonAttributes.Nickname : ""
            });
        }
    }
    @Output() public opusSessionInfoNotFoundCallback: EventEmitter<any> = new EventEmitter<any>();
    @Output() public tncValue: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public otcDataUpdated: EventEmitter<any> = new EventEmitter<any>();
    @Output() public continueDisconnect: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public continueCancel: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public discardCanceledOrder: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public discardSession: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public discardViewingOrder: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public callRetOffer: EventEmitter<any> = new EventEmitter<any>();
    @Output() public updateAccount: EventEmitter<object> = new EventEmitter<object>();
    @Output() public onTnSelected: EventEmitter<string> = new EventEmitter<string>();
    @Output() public onTnBackSelected: EventEmitter<object> = new EventEmitter<object>();
    @Output() public onSaveUpdates: EventEmitter<object> = new EventEmitter<object>();
    @Output() public saveDiscounts: EventEmitter<object> = new EventEmitter<object>();
    @Output() public removeClicked: EventEmitter<any> = new EventEmitter<any>();
    @Output() public portingAccountDetails: EventEmitter<any> = new EventEmitter<any>();
    @Output() public addlOrderAttributes: EventEmitter<any> = new EventEmitter<any>();
    @Output() public selectedRecurringEvent = new EventEmitter();
    @Output() public isReferralRequired: EventEmitter<any> = new EventEmitter<any>();
    @Output() public expiredOfferSelected: EventEmitter<any> = new EventEmitter<any>();
    @Output() public SalesExpiredOfferSelected: EventEmitter<any> = new EventEmitter<any>();
    @Input() public nladData: string;
    @Input() public lifeLineMasterRecurringCredits: any;
    @Input() public lifeLineMasterNonRecurringCredits: any;
    @Output() public updatedListedAddress: EventEmitter<any> = new EventEmitter<any>();
    @Output() public saveupdatesSelected: EventEmitter<any> = new EventEmitter<any>();
    @Input() public waivedReasonList: any;
    @Input() public depositHistory: any;
    @Input() public enableAZMEDI: boolean;
    @Input() public removedProduct: any;
    @Input() public NewChangeTN: any;
    @Input() public schedulingURL: any;
    @Input() public isPrepaid: any;
    //get nunmber of pending order
    @Input() public multiplePending: any;
    @Input() public pendingDueDate: any;
    public phoneMask: any;
    public phoneMaskUSA: any;
    public errorScreen: boolean = false;
    public vacationOptionsLink: any;
    public vacationOptionSelected: any[];
    public existingProductItems: any;
    public saveVacationSuspend: any;
    public enable: boolean = false;
    public isLifelineShow: boolean = true;
    public otcCart: OTCcart[] = [];
    public cartSubscription: Subscription;
    public cart: Observable<ShoppingCart>;
    public totalPrice: number;
    public errorMsg: string;
    public canMove: boolean = false;
    public loading: boolean = false;
    public orderObservable;
    public selectdExpiredSpeed;
    public selectdExpiredSpeedId;
    public cancelorderObservable;
    public clonedOtcData: any;
    public existingServices: any;
    public otcTotal: number = 0;
    public servicestatus: any;
    public selectedMonth: number;
    public isOtcSelected: string = "no";
    public isCheckedStatus: string = "No";
    public otcResponse: any;
    public otcResponse1: any[];
    public existingProductFromStore;
    public exisingProdSubscribe: Subscription;
    public exisitngProduct: any;
    public cancelSelectedReason: string = "Choose your option..";
    public orderSubscription: Subscription;
    public reviewOrder: Order;
    public isRemoveInternet: string;
    public ppllnlad: boolean = true;
    public submitted: boolean = false;
    public removeSelectedReason: any;
    public pendingOrderCancelledNotes: string;
    public cancelOrderSubscription: Subscription;
    public newLegacyProvider: string;
    public reasonRemark: string;
    public displayPaySucBtn: boolean = false;
    public e911ValidatedAddress: EnterpriseAddress;
    public apiResponseError: APIErrorLists;
    public e911Response: any;
    public payOtcAmount: any;
    public e911ResponseError: any;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public paymentURL: boolean;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public existingData: any;
    private disconnectResponse: DisconnectReasons;
    private disconnectHSIService: Service;
    private disconnectPRISMService: Service;
    private disconnectDHPService: Service;
    private disconnectPOTSService: Service;
    private disconnectDTVServce: Service;
    private isDTVFeeWaived = false;
    private isInternetFeeWaived = false;
    private isPRISMFeeWaived = false;
    private isDHPFeeWaived = false;
    private isPOTSFeeWaived = false;
    private internetSelectedReason;
    private prismSelectedReason;
    private dhpSelectedReason;
    private potsSelectedReason;
    private dtvSelectedReason;
    public errorText: string;
    public selectedReason: string;
    public TNQuery: string = "";
    public npanxxList;
    public npaList;
    public nxxList = [];
    public additionalTnForm: FormGroup;
    public additionalAttribForm: FormGroup;
    public addOnAttribForm: FormGroup;
    public additionalCreditsForm: FormGroup;
    public retrieveTnFlag = false;
    public checkTnFlag = false;
    public phoneSelectedFlag = false;
    public success: boolean = false;
    public noMatch: boolean = false;
    public multipleMatch: boolean = false;
    public workingService: boolean = false;
    public moveAddressLine: boolean = true;
    public myForm: FormGroup;
    public listedAddressUpdateForm: FormGroup;
    public addressForm: FormGroup;
    public autoAttach: boolean = false;
    public addressLineShow: boolean = false;
    public asyncSelected: string;
    public asyncUnitSelected: string;
    public addressStreet: string;
    public typeaheadLoading: boolean;
    public typeaheadNoResults: boolean;
    public addressSource: Observable<any>;
    public existingAddressLineShow: boolean = false;
    public addressComplex: any[] = [];
    public inputAddress: EnterpriseAddress;
    public initLoad: boolean = true;
    public responseFlag: string = "";
    public slower: boolean;
    public availabledownSpeed: number;
    public downSpeed: number;
    public upSpeed: number;
    public faster: boolean;
    public availableupSpeed: number;
    public same: boolean;
    public speed: boolean = false;
    private terminationFee: any[] = [];
    private paymentCallbackInvoked: boolean = false;
    public portingAccountTnForm: FormGroup;
    public maskForUsaZip = [/[1-9]/, /\d/, /\d/, /\d/, /\d/];
    public avalableTNsList: any[];
    public selectedMoreTN: string;
    public invalidRange: boolean;
    public invalidLine: boolean;
    public availableNumber: string;
    public notAvailableTN: boolean = false;
    public TNListLoading: boolean = false;
    public TNCallHappening: boolean = false;
    public isRemoveInternetLast: string = "";
    public disconnectResponseData: any;
    public holdReasonsList: any[] = [];
    public holdSelectedReason: string = "Choose your option..";
    public holdReasonRemark: string;
    public holdorderObservable;
    public holdOrderSubscription: Subscription;
    public cancelReasonsList: any[] = [];
    public cancelNewSelectedReason: string = "Choose your option..";
    public cancelReasonRemark: string;
    public cancelNewOrderObservable;
    public cancelNewOrderSubscription: Subscription;
    public selectedCarrier: any;
    public carrierSelectedFlag: boolean = false;
    public proceedToAccountInfo: boolean = false;
    public filteredItems: any;
    public states: State[];
    public notValidForm: boolean = false;
    public refreshSessionObservable;
    public refreshSessionSubscription: Subscription;
    public billingRecObservable;
    public billingRecSubscription: Subscription;
    private customerOrderType: any;
    private customerOrderStatus: any;
    private serviceAddress: any;
    public brcBanObservable: any;
    public brcBanSubscription: any;
    public banNo: any;
    public existingError;
    public formShow: boolean;
    public unHoldReasonList: any[] = [];
    public rmOdrOnHoldObservable;
    public rmOdrOnHoldObservableSubscrptn: Subscription;
    public unHoldSelectedReason: string = "Choose your option..";
    public unHoldReasonRemark: string;
    public cartObject: ShoppingCart;
    public selected: string;
    public cancelOrderPONR: boolean = false;
    public holdOrderPONR: boolean = false;
    public communityResponse: any;
    public loadingCommunityData: boolean = false;
    public streetDirections: any[] = [];
    public streetSuffixes: any[] = [];
    public communityStates: any[] = [];
    public statesCityList;
    public statesList;
    public cityList: any[] = [];
    public showDepositPage: boolean = false;
    public hideReasonDiv: boolean = false;
    public depositAmount: any;
    public disconnectedHSI: boolean = false;
    public displayDeposit: boolean = false;
    public displayDepositDisConnect: boolean = false;
    public customerOrderItems: any;
    public newDownSpeedUOM: string;
    public newUpSpeedUOM: string;
    private flow: string;
    public phoneOnly: boolean = true;
    public retainObservable;
    public retainSubscription: Subscription;
    public addressChanged: boolean = false;
    @ViewChild("movemulticontinue", { static: false, })
    public multimatchMoveComponent: MultimatchMoveComponent;
    @ViewChild("billingmulticontinue", { static: false, })
    @ViewChild("movewlicontinue", { static: false, })
    public multimatchBillingComponent: MultimatchBillingComponent;
    public workingservicemoveComponent: WorkingServiceMoveComponent;
    private isReferralSelected: string;
    private potsPrice = 0;
    @Output() public emitReferral: EventEmitter<any> = new EventEmitter<any>();
    @Output() public getCreditInformation: EventEmitter<any> = new EventEmitter<any>();
    @Output() public toConfig: EventEmitter<any> = new EventEmitter<any>();
    public callerFirstName: string;
    public callerLastName: string;
    public callerDOB: string;
    public callerSSN: string;
    public dob;
    public ssn;
    public inRangeResponse: any;
    public orderRefNumber: string;
    public isAcknowledgeSelected: boolean = false;
    public isOPUSEnabled: boolean = false;
    public userData: any;
    public prepaid: boolean = false;
    @Input() public prepaidAmount: any;
    public fromNIPrepaid: boolean = false;
    public accountID: string = "";
    public prepaidPayment: boolean = false
    @Output() public isAcknowledgeContinued: EventEmitter<any> = new EventEmitter<any>();
    @Input() set DisconnectResponse(disconnectResponse: DisconnectReasons) {
        if (disconnectResponse !== null && disconnectResponse !== undefined && disconnectResponse.payload !== null && disconnectResponse.payload !== undefined) {
            this.disconnectResponse = disconnectResponse;
            let counter = 0;
            for (let i = 0; i < this.disconnectResponse.payload.disconnectInfo.length; i++) {
                switch (this.disconnectResponse.payload.disconnectInfo[i].offerCategory) {
                    case "INTERNET":
                        this.disconnectHSIService = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectHSIService.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                    case "DATA":
                        this.disconnectHSIService = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectHSIService.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                    case "VIDEO-PRISM":
                        this.disconnectPRISMService = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectPRISMService.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                    case "VOICE-DHP":
                        this.disconnectDHPService = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectDHPService.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                    case "VOICE-HP":
                        this.disconnectPOTSService = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectPOTSService.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                    case "VIDEO-DTV":
                        this.disconnectDTVServce = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectDTVServce.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                    default:
                        this.disconnectHSIService = this.disconnectResponse.payload.disconnectInfo[i];
                        if (!this.isPrepaid && +this.disconnectHSIService.etfInfo.terminationFee > 0) {
                            counter++;
                        }
                        break;
                }
            }
            if (counter > 0) {
                if (this.disconnectMsg.indexOf("Customer contract is still active") === -1) {
                    this.disconnectMsg += ". Customer contract is still active.";
                }
            } else {
                if (this.disconnectMsg.indexOf("to disconnect these services") === -1) {
                    this.disconnectMsg += " to disconnect these services.";
                }
            }
        }
    }
    public arcCreditEnable: boolean = true;
    public stateCreditEnable: boolean = true;
    public nonCreditEnable: boolean = true;
    public zoneOneEnable: boolean = false;
    public zoneTwoEnable: boolean = false;
    public zoneThreeEnable: boolean = false;
    public fltransLifeline: any = false;
    public zoneFourEnable: any = false;
    private firstName: string;
    private lastName: string;
    private ensembleId: string;
    private sfdcAccountId: string;
    private agentCuid: string;
    public dtvForm: FormGroup;
    public opusSessionNotFoundForm: FormGroup;
    public dtvManualPriceplanEntryForm: FormGroup;
    public dtvAccountInfo: any;
    public dtvSessionInfo: any;
    private pendingObject: any;
    public searchBox: FormGroup;
    public orderDisclosuresDetails: rccDetails[];
    public expiredOffer: any;
    public reqCity: string;
    public reqState: string;
    public wirecenter: string;
    public reqTNType: string;
    public orderFlow: string;
    public isCenturyLink: boolean = false;
    public partnerInfo = {
        isPartnerFlag: false,
        partnerOrderID: '',
        partnerReferenceID: '',
    }
    public workingservinfo: any = [];
    public isWorkingServiceAllowed: boolean = false;
    public currentFlow: any = "";
    public isWliAvailable: boolean = false;
    public enabledContinue: boolean = false;
    public initResp: any;
    public movingToServices: boolean = false;
    public legacyName: any;

    constructor(private reviewOrderService: ReviewOrderService,
        private pendingOrderService: PendingOrderService,
        private router: Router,
        private logger: Logger,
        private zone: NgZone,
        private sanitizer: DomSanitizer,
        private store: Store<AppStore>,
        private accountService: AccountService,
        private disconnectServiceCall: DisconnectService,
        private productService: ProductService,
        private addressService: AddressService,
        private bMService: BlueMarbleService,
        private fb: FormBuilder,
        private systemErrorService: SystemErrorService,
        private countryStateService: CountryStateService,
        private textMask: TextMaskService,
        private ctlHelperService: CTLHelperService,
        private directvService: DirectvService,
        private propertiesHelperService: PropertiesHelperService) {
        this.totalPrice = 0;
        this.paymentURL = false;
        this.initLoad = true;
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.phoneMaskUSA = this.textMask.getPhoneNumberMaskFormat();
        this.states = this.countryStateService.getStates();
        this.orderObservable = <Observable<Order>>store.select("order");
        this.cancelorderObservable = <Observable<Order>>store.select("pending");
        this.retainObservable = <Observable<User>>this.store.select("retain");
        this.isMoveAllowed = propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_INTERTERITORY_MOVE);
        this.allowStackOrders = propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_STACK_ORDERS);
        this.existingProductFromStore = <Observable<Order>>(store.select("existingProducts"));
        this.retainObservable.subscribe(data => { this.expiredOffer = data.expiredOffers })
        this.exisingProdSubscribe = this.existingProductFromStore.subscribe(data => {
            if (data && data.orderFlow && data.orderFlow.flow) {
                this.currentFlow = data.orderFlow.flow;
            }
            if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].serviceAddress && data.existingProductsAndServices[0].serviceAddress.locationAttributes && data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider) {
                this.legacyName = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
            }
            if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.ban)
                this.ban = data.existingProductsAndServices[0].accountInfo.ban;
            this.stackData = data && data.orderInit;
            this.exisitngProduct = data;
            if (this.exisitngProduct && this.exisitngProduct.pendingOrders && this.exisitngProduct.pendingOrders[0] && this.exisitngProduct.pendingOrders[0].orderReference &&
                this.exisitngProduct.pendingOrders[0].orderReference.customerOrderType === 'NEWINSTALL') {
                this.displayDeposit = true;
            }
            this.suspendTelephoneNumber = this.exisitngProduct && this.exisitngProduct.existingProductsAndServices && this.exisitngProduct.existingProductsAndServices[0] && this.exisitngProduct.existingProductsAndServices[0].telephoneNumber;
            this.suspendedAccountnum = this.exisitngProduct && this.exisitngProduct.existingProductsAndServices && this.exisitngProduct.existingProductsAndServices.length > 0 &&
                this.exisitngProduct.existingProductsAndServices[0].accountInfo !== null && this.exisitngProduct.existingProductsAndServices[0].accountInfo.ban;
            if (data && data.nonpayLdRequest !== undefined && data.nonpayLdRequest === "") {
                this.selectedListCarriers = [];
                this.backUpCarrierList = [];
                this.listofCarriers = [];
                this.updatedAllLdCarriers = false;
                this.lbBLockContinueButtonActive = false;
                this.allRestoreCarriersSelected = false;
                this.searchBox.get("search").setValue('');
            }
            if (this.exisitngProduct &&
                this.exisitngProduct.nonpaySuspendLdRes &&
                this.exisitngProduct.nonpaySuspendLdRes !== undefined) {
                for (let i = 0; i < this.exisitngProduct.nonpaySuspendLdRes.outputAttribute.length; i++) {
                    this.listCarrierListAll = (this.exisitngProduct.nonpaySuspendLdRes.outputAttribute[i][1] + ": " + this.exisitngProduct.nonpaySuspendLdRes.outputAttribute[i][0]);
                    this.listofCarriers.push(this.listCarrierListAll);
                }
            } else {
                if (this.exisitngProduct.nonpayLdcarrierlistInitRes && this.exisitngProduct.nonpayLdcarrierlistInitRes !== undefined) {
                    this.nonpaySuspendLdRestoreAtive = true;
                    this.listofRestoreCarriers = this.exisitngProduct.nonpayLdcarrierlistInitRes;
                }
            }
            this.fetchRuleCarreirListres = this.exisitngProduct.nonpaySuspendLdRes;
            if (this.exisitngProduct && this.exisitngProduct.nonPaySuspendProductsReq && this.exisitngProduct.nonPaySuspendProductsReq !== undefined) {
                this.suspendedProducts = this.exisitngProduct.nonPaySuspendProductsReq.payload.cart.customerOrderItems;
                this.suspendedProducts.map(data => {
                    if (data.offerCategory === GenericValues.cHP) {
                        if (data.action === "SUSPEND") {
                            this.showPotsSuspendProd = true;
                        } else if (data.action === "RESTORE") {
                            this.showPotsRestoreProd = true;
                        } else {
                            this.showPotsRestoreProd = false;
                            this.showPotsSuspendProd = false;
                        }
                        data.customerOrderSubItems.map(subData => {
                            if (subData.productName.indexOf("Long Distance") > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
                                if (subData.action === "SUSPEND") {
                                    this.showLDsuspendProd = true;
                                } else if (subData.action === "RESTORE") {
                                    this.showLDRestoreProd = true;
                                } else {
                                    this.showLDsuspendProd = false;
                                    this.showLDRestoreProd = false;
                                }
                            }
                            if (subData.productName === "Selective Carrier Denial") {
                                if (subData.action === "ADD") {
                                    this.showLDsuspendProd = true;
                                } else if (subData.action === "CHANGE" || subData.action === "REMOVE") {
                                    this.showLDRestoreProd = true;
                                }
                            }
                        });
                    }
                    if (data.offerCategory === GenericValues.cDHP) {
                        if (data.action === "SUSPEND") {
                            this.showDhpSuspendProd = true;
                        } else if (data.action === "RESTORE") {
                            this.showDhpRestoreProd = true;
                        } else {
                            this.showDhpSuspendProd = false;
                            this.showDhpRestoreProd = false;
                        }
                    }
                    if (data.offerCategory === GenericValues.iData) {
                        if (data.action === "SUSPEND") {
                            this.showInternetSuspendProd = true;
                        } else if (data.action === "RESTORE") {
                            this.showInternetRestoreProd = true;
                        } else {
                            this.showInternetSuspendProd = false;
                            this.showInternetRestoreProd = false;
                        }
                    }
                    if (data.offerCategory === GenericValues.cDTV) {
                        if (data.action === "SUSPEND") {
                            this.showDtvSuspendProd = true;
                        } else if (data.action === "RESTORE") {
                            this.showDtvRestoreProd = true;
                        } else {
                            this.showDtvSuspendProd = false;
                            this.showDtvRestoreProd = false;
                        }
                    }
                });
                this.exisitngProduct.nonPaySuspendProductsReq.payload.addlOrderAttributes[0].orderAttributeGroup.map(data => {
                    if (data.orderAttributeGroupName === "selectiveCarrierDenial") {
                        this.selectedCarrierSuspendedList = data.orderAttributeGroupInfo[0].orderAttributes;
                    }
                    if (data.orderAttributeGroupName === "selectiveCarrierRestore") {
                        this.selectedCarrierRestoredList = data.orderAttributeGroupInfo[0].orderAttributes;
                    }
                    if (this.showLDsuspendProd) {
                        this.showCarrierList = this.selectedCarrierSuspendedList;
                    } else if (this.showLDRestoreProd) {
                        this.showCarrierList = this.selectedCarrierRestoredList;
                    }
                })
            }
            if (this.exisitngProduct && this.exisitngProduct.nonPayInitRes !== undefined && this.exisitngProduct.nonPayInitRes !== null) {
                this.nonpaySuspendRestoreInitData = this.exisitngProduct.nonPayInitRes;
            }
            this.orderFlow = data && data.orderFlow && data.orderFlow.flow;
            this.isReferralSelected = "No referral needed";
        }
        );
        this.orderSubscription = this.orderObservable.subscribe(data => {
            this.reviewOrder = data;
            if (data.productSalesIdInfo !== undefined) {
                this.productDealerCodeInfo = data.productSalesIdInfo.productDealerCodeInfo;
                if (this.productDealerCodeInfo && this.productDealerCodeInfo.length > 0) {
                    for (let index = 0; index < this.productDealerCodeInfo.length; index++) {
                        let temp = {};
                        if (this.productDealerCodeInfo[index].productname === "CENTURYLINK @ EASE" && this.productDealerCodeInfo[index + 1] && this.productDealerCodeInfo[index + 1].productType === "INTERNET") {
                            temp = JSON.parse(JSON.stringify(this.productDealerCodeInfo[index]));
                            this.productDealerCodeInfo[index] = JSON.parse(JSON.stringify(this.productDealerCodeInfo[index + 1]));
                            this.productDealerCodeInfo[index + 1] = JSON.parse(JSON.stringify(temp));
                        }
                    }
                }
            }
        });
        this.cancelOrderSubscription = this.cancelorderObservable.subscribe(
            data => {
                if (data.deposit) {
                    this.servicestatus = JSON.parse(localStorage.getItem("serviceStatus"));
                    if (this.servicestatus && this.servicestatus !== null) {
                        this.depositAmount = this.getDepositmount(data.deposit.depositInfo, this.servicestatus);
                    }
                }
            }
        );
        this.creditRevObsv = <Observable<CreditCheck>>this.store.select("creditReview");
        this.creditRevObsv.subscribe((data) => {
            if (data && data.payload && data.payload.currentBillQuote && data.payload.currentBillQuote.firstMonthList && data.payload.currentBillQuote.firstMonthList.totalCharges) {
                this.prepaidAmountDone = data.payload.currentBillQuote.firstMonthList.totalCharges;
            }
            this.creditRevObsvData = data;
            if (this.creditRevObsvData && this.creditRevObsvData.credit_detail && this.creditRevObsvData.credit_detail.prepaidPaymentStatus) {
                this.prepaidPayment = true
            }
        });
        this.accountObservable = <Observable<any>>store.select('account');
        this.accountObservable.subscribe((data) => {
            this.accountObservableData = data;
            if (data && data.isAuthorizedParties !== undefined && data.isAuthorizedParties !== null) {
                this.authUsers = data.isAuthorizedParties;
                this.firstNameFirst = this.authUsers[0].firstName;
                this.lastNameFirst = this.authUsers[0].lastName;
                this.contactFirst = this.authUsers[0].contactPhone;
                this.firstNameSecond = this.authUsers[1].firstName;
                this.lastNameSecond = this.authUsers[1].lastName;
                this.contactSecond = this.authUsers[1].contactPhone;
                this.addAuthUserForm = this.fb.group({
                    'firstNameFirst': [this.firstNameFirst, [Validators]],
                    'lastNameFirst': [this.lastNameFirst, [Validators]],
                    'contactFirst': [this.contactFirst, [Validators]],
                    'firstNameSecond': [this.firstNameSecond],
                    'lastNameSecond': [this.lastNameSecond],
                    'contactSecond': [this.contactSecond]
                });
            }
        });
        this.cartObservable = <Observable<ShoppingCart>>store.select('cart');
        this.cartObservable.subscribe((data) => {
            this.cartObservableData = data;
            if (data && data.payload && data.payload.discountItems && data.payload.discountItems !== undefined)
                this.selectedDiscounts = data.payload.discountItems;
        });
        let userData;
        this.customizeObservable = <Observable<any>>store.select("customize");
        this.customizeSubscription = this.customizeObservable.subscribe(data => {
            if (data && data.selectedGiftCard && data.selectedGiftCard !== undefined) {
                this.selectedGiftCardDiscounts = data.selectedGiftCard;
            }
            if (data && data.payload && data.payload.productConfiguration && data.payload.productConfiguration[0] && data.payload.productConfiguration[0].configItems[0]) {
                let x = data.payload.productConfiguration[0].configItems[0];
                x.configDetails[0].formItems.map(val => {
                    if (val.attributeName === "Unit") {
                        this.location = true;
                    }
                });
            }
            if (data && data.selectedGiftCard && data.selectedGiftCard !== undefined && data.selectedGiftCard.length > 0) {
                this.giftCardSelected = true;
            } else {
                this.giftCardSelected = false;
            }
            if (data && data.payload && data.payload.reservedTN && data.payload.reservedTN.length > 0 && data.payload.reservedTN[0].tnType) {
                this.reqTNType = data.payload && data.payload.reservedTN && data.payload.reservedTN[0].tnType;
            }
        });
        this.cartObservable = <Observable<ShoppingCart>>store.select('cart');
        this.cartObservable.subscribe((data) => {
            this.cartObservableData = data;
            if (data && data.payload && data.payload.discountItems && data.payload.discountItems !== undefined && data.payload.discountItems.length > 0) {
                this.discountSelectedValue = true;
            } else {
                this.discountSelectedValue = false;
            }
        });
        this.user = <Observable<User>>store.select("user");
        this.userSubscription = this.user.subscribe(data => {
            this.orderReferenceNumber = data.orderRefNumber;
            if (Array.isArray(data.currentSelected) && data.isDtvOpus) {
                data.currentSelected.forEach((val: any) => {
                    if (val.selected === GenericValues.cDTV) {
                        this.isOPUSEnabled = true;
                    }
                });
            }
            userData = data;
            this.userData = data;
            if(this.userData.prepaidFlag) { this.prepaid = true; }
            if (data && data.offerDisplayName && data.offerDisplayName !== undefined && data.offerDisplayName.outputAttribute && data.offerDisplayName.outputAttribute !== undefined) {
                if (data.offerDisplayName.outputAttribute.length === 1) {
                    if (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" || data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                        this.offerDisplayName = data.offerDisplayName.outputAttribute[0][2];
                    }
                } else if (data.offerDisplayName.outputAttribute.length > 1) {
                    if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP")) {
                        if (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") {
                            this.offerDisplayName = data.offerDisplayName.outputAttribute[0][2];
                        } else if (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                            this.offerDisplayName = data.offerDisplayName.outputAttribute[1][2];
                        }
                    } else if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" || (data.offerDisplayName.outputAttribute[0][3] === "VOICE-DHP" ||
                        data.offerDisplayName.outputAttribute[0][3] === "VIDEO-DTV")) && (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" ||
                            (data.offerDisplayName.outputAttribute[1][3] === "VOICE-DHP" || data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV")) &&
                        (data.offerDisplayName.outputAttribute[0][2] !== null && data.offerDisplayName.outputAttribute[1][2] !== null)) {
                        this.offerDisplayName = (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV") ||
                            (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DHP") ? data.offerDisplayName.outputAttribute[0][2] +
                            " " + data.offerDisplayName.outputAttribute[1][2] : data.offerDisplayName.outputAttribute[1][2] + " " + data.offerDisplayName.outputAttribute[0][2];
                    }
                }
            }
            if (data.autoLogin && data.autoLogin.oamData) {
                this.agentCuid = data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : "";
                this.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                this.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                this.ensembleId = data.autoLogin.oamData.ensembleId;
                if (data.autoLogin && data.autoLogin.sfcData && data.autoLogin.sfcData.sfdcID && data.autoLogin.sfcData.sfdcBillingAccountID) {
                    this.sfdcAccountId = (data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID + ":" : "") + (data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : "");
                }
            }
            if (userData) {
                this.callerFirstName = userData.firstName;
                this.callerLastName = userData.lastName;
            }
            if (userData.creditCheckData) {
                this.dob = userData.creditCheckData.dob;
                this.ssn = userData.creditCheckData.ssn;
            }
            if (userData.currentUrl === "/pending-order") {
                this.billingRecObservable = this.store.select("pending");
                this.billingRecSubscription = this.billingRecObservable.subscribe(
                    data => {
                        this.pendingObject = data;
                        if (data && data.orderReference) {
                            this.customerOrderStatus = data.orderReference.customerOrderStatus;
                            this.customerOrderType = data.orderReference.customerOrderType;
                        }
                        if (data && data.orderDocument) {
                            this.serviceAddress = data.orderDocument.serviceAddress;
                        }
                    }
                );
            }
            let addr = data.finalAddress;
            if (addr) {
                if (addr.addressLine) {
                    this.addressStreet = addr.addressLine;
                    if (addr.subAddress) {
                        this.addressStreet = this.addressStreet + ", " + addr.subAddress.combinedDesignator;
                    }
                    if (addr.city) {
                        this.addressStreet = this.addressStreet + ", " + addr.city;
                    }
                    if (addr.stateOrProvince) {
                        this.addressStreet = this.addressStreet + ", " + addr.stateOrProvince;
                    }
                    if (addr.postCode) {
                        this.addressStreet = this.addressStreet + ", " + addr.postCode;
                    }
                } else if (addr.streetAddress) {
                    this.addressStreet = addr.streetAddress;
                    if (addr.subAddress) {
                        this.addressStreet = this.addressStreet + ", " + addr.subAddress.combinedDesignator;
                    }
                    if (addr.city) {
                        this.addressStreet = this.addressStreet + ", " + addr.city;
                    }
                    if (addr.stateOrProvince) {
                        this.addressStreet = this.addressStreet + ", " + addr.stateOrProvince;
                    }
                    if (addr.postCode) {
                        this.addressStreet = this.addressStreet + ", " + addr.postCode;
                    }
                }
            }
            if (userData.orderInit && userData.orderInit.payload && userData.orderInit.payload.serviceAddress) {
                this.reqCity = userData.orderInit.payload.serviceAddress.city;
                this.reqState = userData.orderInit.payload.serviceAddress.stateOrProvince;
                this.wirecenter = userData.orderInit.payload.serviceAddress.locationAttributes.wirecenter;
                this.isCenturyLink = userData.orderInit.payload.serviceAddress.locationAttributes.legacyProvider === "CENTURYLINK" ? true : false;
            }
        });
        this.addressLineShow = false;
        this.asyncSelected = "";
        this.myForm = this.fb.group({
            firstName: ["", [Validators.required, <any>Validations.nameValidator]],
            lastName: ["", [Validators.required, <any>Validations.nameValidator]],
            phoneNumber: ["", [Validators.required, <any>Validations.phoneValidator]],
            singleAddressLine: this.addressLineShow ? [""] : ["", [Validators.required, <any>Validations.addressLineValidator]],
            addressLine: this.addressLineShow ? ["", [Validators.required, <any>Validations.addressLineValidator]] : [""],
            singleUnitNumber: [""],
            unitNumber: [""],
            state: this.addressLineShow ? ["", Validators.required] : [""],
            city: this.addressLineShow ? ["", [Validators.required, <any>Validations.nameValidator]] : [""],
            zipCode: this.addressLineShow ? ["", Validations.zipCodeValidator] : [""],
            accountNumber: [""],
            orderNumber: [""],
            number: [""]
        });
        this.addressSource = Observable.create((observer: any) => { observer.next(this.asyncSelected); }).pipe(mergeMap((token: string) => this.getAddressesAsObservable(token)));
        this.retainObservable.subscribe(data => {
            if (data.dtvAccountInfo) {
                this.dtvAccountInfo = data.dtvAccountInfo;
            }
            if (data.dtvSessionInfo) {
                this.dtvSessionInfo = data.dtvSessionInfo;
            }
        });
        this.dtvForm = this.fb.group({
            directvLocations: ["Center", [Validators.required]],
            selectedLocation: ["", [Validators.required]],
            ctlemployee: ["", [Validators.required]]
        });
        this.opusSessionNotFoundForm = this.fb.group({
            dtvCreated: ['Yes', [Validators.required]],
            dtv_account_id: ['', [Validators.required]]
        });
        if (this.dtvAccountInfo) {
            this.dtvManualPriceplanEntryForm = this.fb.group({
                dtvCreated: [this.dtvAccountInfo.dtvCreated, [Validators.required]],
                dtv_account_id: [this.dtvAccountInfo.dtv_account_id, [Validators.required]]
            });
        } else {
            this.dtvManualPriceplanEntryForm = this.fb.group({
                dtvCreated: ['Yes', [Validators.required]],
                dtv_account_id: ['', [Validators.required]]
            });
        }
        this.searchBox = this.fb.group({
            search: ['', []]
        });
    }
    public arcCreditChange() {
        this.arcCreditEnable = !this.arcCreditEnable;
    }
    public stateCrediChange(event) {
        this.stateCreditEnable = event.target.value === "choose your item.." ? true : false;
        if (event.target.value === "FL Transitional Lifeline" && (!this.zoneThreeEnable || !this.stateCreditEnable || !this.zoneOneEnable || this.zoneTwoEnable)) {
            this.azCreditsEndDate = new DatePipe("en-US").transform(this.azCreditsStartDate.setMonth(this.azCreditsStartDate.getMonth() + 12), "MM/dd/yyyy");
        } else if (event.target.value !== "FL Transitional Lifeline") {
            this.azCreditsStartDate = new DatePipe("en-US").transform(this.date.toString(), "MM/dd/yyyy");
            return (this.azCreditsEndDate = new DatePipe("en-US").transform(this.defaultDate.toString(), "MM/dd/yyyy"));
        }
        this.selectedRecurringEvent.emit(event);
        this.stateCreditrecurring = true;
    }
    public nonCreditChange(event) {
        this.adjustmentsNonRecurring = true;
        this.nonCreditEnable = event.target.value === "choose your item.." ? true : false;
    }
    public viewSelectedList() {
        this.viewSelectedCarriers = true;
        this.viewAllCarriers = false;
        this.backUpCarrierList = [];
        let value: string = this.searchBox.value.search.toUpperCase();
        if (value && value.trim().length > 0) {
            this.viewCarrier = true;
            if (this.viewAllCarriers) {
                this.listofCarriers && this.listofCarriers.map(carrier => {
                    if (carrier.indexOf(value) !== -1) {
                        this.backUpCarrierList.push(carrier);
                    }
                })
            } else if (this.viewSelectedCarriers) {
                this.selectedListCarriers && this.selectedListCarriers.map(carrier => {
                    if (carrier && carrier.orderAttributeValue && carrier.orderAttributeValue.indexOf(value) !== -1) {
                        this.backUpCarrierList.push(carrier);
                    }
                })
            }
        } else {
            this.viewCarrier = false;
        }
    }
    public selectCarrierList(e: any, value) {
        this.countCarrierCodeList = this.countList++;
        if (e.target.checked === true) {
            if (!this.nonpaySuspendLdRestoreAtive) {
                let carrierList = {
                    orderAttributeName: "carrierNameCode",
                    orderAttributeValue: value
                }
                this.selectedListCarriers.push(carrierList);
            } else {
                let carrierList = {
                    orderAttributeName: value.orderAttributeName,
                    orderAttributeValue: value.orderAttributeValue
                }
                this.selectedListCarriers.push(carrierList);
            }
        } else {
            if (this.selectedListCarriers && this.selectedListCarriers !== undefined && this.selectedListCarriers !== null && this.selectedListCarriers.length > 0) {
                for (let i = 0; i < this.selectedListCarriers.length; i++) {
                    if (value === this.selectedListCarriers[i].orderAttributeValue) {
                        this.selectedListCarriers.splice(i, 1);
                        break;
                    }
                }
            }
        }
        if (this.selectedListCarriers.length > 0) {
            this.lbBLockContinueButtonActive = true;
        } else {
            this.lbBLockContinueButtonActive = false;
        }
    }
    public convert(value) {
        return value.replace("-", ": ");
    }
    public restoreCarrierList(e: any, value) {
        if (e.target.checked === true) {
            let carrierList = {
                orderAttributeName: value.orderAttributeName,
                orderAttributeValue: value.orderAttributeValue
            }
            this.selectedListCarriers.push(carrierList);
        } else {
            if (this.selectedListCarriers && this.selectedListCarriers !== undefined && this.selectedListCarriers !== null && this.selectedListCarriers.length > 0) {
                for (let i = 0; i < this.selectedListCarriers.length; i++) {
                    if (value.orderAttributeValue === this.selectedListCarriers[i].orderAttributeValue) {
                        this.uncheckedCarrierList.push(this.selectedListCarriers[i]);
                        this.selectedListCarriers.splice(i, 1);
                    }
                }
            }
        }
        if (this.selectedListCarriers.length > 0) {
            this.lbBLockContinueButtonActive = true;
        } else {
            this.lbBLockContinueButtonActive = false;
        }
    }
    public uncheckSelectedList(e: any, value) {
        if (e.target.checked === true) {
            let carrierList = {
                orderAttributeName: value.orderAttributeName,
                orderAttributeValue: value.orderAttributeValue
            }
            this.selectedListCarriers.push(carrierList);
        } else {
            if (this.selectedListCarriers && this.selectedListCarriers !== undefined && this.selectedListCarriers !== null && this.selectedListCarriers.length > 0) {
                for (let i = 0; i < this.selectedListCarriers.length; i++) {
                    if (value.orderAttributeValue === this.selectedListCarriers[i].orderAttributeValue) {
                        this.uncheckedCarrierList.push(this.selectedListCarriers[i]);
                    }
                }
            }
        }
        if (this.selectedListCarriers.length === this.uncheckedCarrierList.length) {
            this.lbBLockContinueButtonActive = false;
        } else {
            this.lbBLockContinueButtonActive = true;
        }
    }
    public selectAllRestoreCarriers() {
        this.allRestoreCarriersSelected = true;
        this.lbBLockContinueButtonActive = true;
        this.selectedListCarriers = this.listofRestoreCarriers;
    }
    public deSelectAllRestoreCarriers() {
        this.allRestoreCarriersSelected = false;
        this.lbBLockContinueButtonActive = false;
        this.selectedListCarriers = [];
        this.uncheckedCarrierList = [];
    }
    public viewAllList() {
        this.viewAllCarriers = true;
        this.viewSelectedCarriers = false;
        if (this.uncheckedCarrierList && this.uncheckedCarrierList !== undefined && this.uncheckedCarrierList.length > 0) {
            for (let i = 0; i < this.uncheckedCarrierList.length; i++) {
                for (let j = 0; j < this.selectedListCarriers.length; j++) {
                    if (this.uncheckedCarrierList[i].orderAttributeValue === this.selectedListCarriers[j].orderAttributeValue) {
                        this.selectedListCarriers.splice(j, 1);
                        break;
                    }
                }
            }
        }
        this.uncheckedCarrierList = [];
        this.backUpCarrierList = [];
        let value: string = this.searchBox.value.search.toUpperCase();
        if (value && value.trim().length > 0) {
            this.viewCarrier = true;
            if (this.viewAllCarriers) {
                this.listofCarriers && this.listofCarriers.map(carrier => {
                    if (carrier.indexOf(value) !== -1) {
                        this.backUpCarrierList.push(carrier);
                    }
                })
            } else if (this.viewSelectedCarriers) {
                this.selectedListCarriers && this.selectedListCarriers.map(carrier => {
                    if (carrier && carrier.orderAttributeValue && carrier.orderAttributeValue.indexOf(value) !== -1) {
                        this.backUpCarrierList.push(carrier);
                    }
                })
            }
        } else {
            this.viewCarrier = false;
        }
    }
    public checkSelection(value) {
        let flag = false;
        if (this.selectedListCarriers && this.selectedListCarriers !== undefined && this.selectedListCarriers !== null && this.selectedListCarriers.length > 0) {
            for (let i = 0; i < this.selectedListCarriers.length; i++) {
                if (value === this.selectedListCarriers[i].orderAttributeValue) {
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }
    private findAndReplace(string, target, replacement) {
        var i = 0, length = string.length;
        for (i; i < length; i++) {
            string = string.replace(target, replacement);
        }
        return string;
    }
    public onChangeDTVDisconnectReason(event: string) {
        if (event.endsWith("(Waive Penalty)")) {
            this.isDTVFeeWaived = true;
        } else {
            this.isDTVFeeWaived = false;
        }
        for (let i = 0; i < this.disconnectDTVServce.reasonList.length; i++) {
            if (this.findAndReplace(event.replace("(Waive Penalty)", "").trim(), " - ", "-") ===
                this.findAndReplace(this.disconnectDTVServce.reasonList[i].description.trim(), " - ", "-")) {
                this.dtvSelectedReason = this.disconnectDTVServce.reasonList[i];
                this.updateCartOnSelectChange("DTV Early Termination Fee", !this.isDTVFeeWaived ? +this.disconnectDTVServce.etfInfo.terminationFee : 0);
                break;
            }
        }
    }
    public onChangeInternetDisconnectReason(event: string) {
        if (event.endsWith("(Waive Penalty)")) {
            this.isInternetFeeWaived = true;
        } else {
            this.isInternetFeeWaived = false;
        }
        for (let i = 0; i < this.disconnectHSIService.reasonList.length; i++) {
            if (this.findAndReplace(event.replace("(Waive Penalty)", "").trim(), " - ", "-") === this.findAndReplace(this.disconnectHSIService.reasonList[i].description.trim(), " - ", "-")) {
                this.internetSelectedReason = this.disconnectHSIService.reasonList[i];
                this.updateCartOnSelectChange("Internet Early Termination Fee", !this.isInternetFeeWaived ? +this.disconnectHSIService.etfInfo.terminationFee : 0);
                break;
            }
        }
    }
    public getCreditInformationFn() {
        this.getCreditInformation.emit();
    }
    public toConfigFn() {
        this.toConfig.emit();
        this.close(true);
    }
    public submitLDSuspendProducts() {
        this.updatedAllLdCarriers = true;
        this.countList = 0;
        if (this.selectedListCarriers && this.selectedListCarriers !== undefined && this.selectedListCarriers.length > 0) {
            this.selectedListCarriers.map(data => {
                if (this.fetchRuleCarreirListres && this.fetchRuleCarreirListres !== undefined && this.fetchRuleCarreirListres.outputAttribute && this.fetchRuleCarreirListres.outputAttribute !== undefined) {
                    for (let i = 0; i < this.fetchRuleCarreirListres.outputAttribute.length; i++) {
                        if (data.orderAttributeValue === this.fetchRuleCarreirListres.outputAttribute[i][1] + ": " + this.fetchRuleCarreirListres.outputAttribute[i][0]) {
                            data.orderAttributeValue = this.fetchRuleCarreirListres.outputAttribute[i][1] + "-" + this.fetchRuleCarreirListres.outputAttribute[i][0]
                            break;
                        }
                    }
                }
                this.countCarrierCodeList = this.countList++;
                data.orderAttributeName = "carrierNameCode"
            })
        }
        if (this.uncheckedCarrierList && this.uncheckedCarrierList !== undefined && this.uncheckedCarrierList.length > 0) {
            for (let i = 0; i < this.uncheckedCarrierList.length; i++) {
                for (let j = 0; j < this.selectedListCarriers.length; j++) {
                    if (this.uncheckedCarrierList[i].orderAttributeValue === this.selectedListCarriers[j].orderAttributeValue) {
                        this.selectedListCarriers.splice(j, 1);
                        break;
                    }
                }
            }
        }
        this.saveupdatesSelected.emit(true);
        this.uncheckedCarrierList = [];
        this.store.dispatch({ type: 'NON_PAY_LD_REQUEST', payload: this.selectedListCarriers });
        this.close(true);
    }
    public submitSuspendProducts() {
        let errorResolved = false;
        this.loading = true;
        let req = {
            success: true,
            orderRefNumber: this.exisitngProduct.nonPaySuspendProductsReq.orderRefNumber,
            processInstanceId: this.exisitngProduct.nonPaySuspendProductsReq.processInstanceId,
            taskId: this.exisitngProduct.nonPaySuspendProductsReq.taskId,
            taskName: this.exisitngProduct.nonPaySuspendProductsReq.taskName,
            payload: {
                addlOrderAttributes: this.exisitngProduct.nonPaySuspendProductsReq.payload.addlOrderAttributes,
                cart: this.exisitngProduct.nonPaySuspendProductsReq.payload.cart,
                notes: this.exisitngProduct.nonPaySuspendProductsReq.payload.notes,
                orderEffectiveDate: this.exisitngProduct.nonPaySuspendProductsReq.payload.orderEffectiveDate
            }
        };
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.existingObservable.subscribe((data) => {
            if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress.locationAttributes) {
                this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
            }
        })
        this.logger.log("info", "dialog.component.ts", "submitNonpaySupspendRequest", JSON.stringify(req));
        this.logger.startTime();
        this.bMService.submitNonpaySupspend(req)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "submitNonpaySupspendResponse", error);
                this.logger.log("error", "dialog.component.ts", "submitNonpaySupspendSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "suspendOrder - submitSuspendProducts", "dialog.component.ts", "Dialog", error);
                return Observable.throwError(null);
            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "dialog.component.ts", "submitNonpaySupspendResponse", JSON.stringify(data), this.legacyProvider);
                this.logger.log("info", "dialog.component.ts", "submitNonpaySupspendSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.store.dispatch({ type: "NON-PAY-SUSPEND_RES", payload: data });
                this.router.navigate(["/nonpay-suspend-confirmation"]);
            },
                error => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "dialog.component.ts", "submitNonpaySupspendResponse", error);
                        this.logger.log("error", "dialog.component.ts", "submitNonpaySupspendSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "suspendOrder - submitSuspendProducts", "dialog.component.ts", "Suspend Oder - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "suspendOrder - submitSuspendProducts", "dialog.component.ts", "Suspend Oder - Dialog", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }

    private updateCartOnSelectChange(product: any, price: number) {
        let updated = false;
        if (this.terminationFee !== null && this.terminationFee.length > 0) {
            this.terminationFee.forEach(item => {
                if (item.description === product) {
                    item.price = price;
                    updated = true;
                }
            });
        }
        if (!updated) {
            this.terminationFee.push({ description: product, price: price });
        }
        let cartObj: ShoppingCart = {
            terminationFee: this.terminationFee
        };
        this.store.dispatch({ type: "CREATE_CART", payload: cartObj });
    }
    public onChangePrismDisconnectReason(event: string) {
        if (event.endsWith("(Waive Penalty)")) {
            this.isPRISMFeeWaived = true;
        } else {
            this.isPRISMFeeWaived = false;
        }
        for (let i = 0; i < this.disconnectPRISMService.reasonList.length; i++) {
            if (this.findAndReplace(event.replace("(Waive Penalty)", "").trim(), " - ", "-") ===
                this.findAndReplace(this.disconnectPRISMService.reasonList[i].description.trim(), " - ", "-")) {
                this.prismSelectedReason = this.disconnectPRISMService.reasonList[i];
                this.updateCartOnSelectChange("PRISM Early Termination Fee", !this.isPRISMFeeWaived ? +this.disconnectPRISMService.etfInfo.terminationFee : 0);
                break;
            }
        }
    }

    public onChangeDHPDisconnectReason(event: string) {
        if (event.endsWith("(Waive Penalty)")) {
            this.isDHPFeeWaived = true;
        } else {
            this.isDHPFeeWaived = false;
        }
        for (let i = 0; i < this.disconnectDHPService.reasonList.length; i++) {
            if (this.findAndReplace(event.replace("(Waive Penalty)", "").trim(), " - ", "-") === this.findAndReplace(this.disconnectDHPService.reasonList[i].description.trim(), " - ", "-")) {
                this.dhpSelectedReason = this.disconnectDHPService.reasonList[i];
                this.updateCartOnSelectChange("DHP Early Termination Fee", !this.isDHPFeeWaived ? +this.disconnectDHPService.etfInfo.terminationFee : 0);
                break;
            }
        }
    }
    public continueToMove() {
        this.multimatchMoveComponent.selectedMatch();
        this.loading = true;
        if (this.multimatchMoveComponent.yellowAddress === undefined || !this.multimatchMoveComponent.yellowAddress.streetAddress) {
            this.loading = false;
        } else {
            this.loading = true;
        }
    }
    public continueToBill() {
        this.multimatchBillingComponent.selectedMatch();
        this.loading = true;
        if (this.multimatchBillingComponent.yellowAddress === undefined) {
            this.loading = false;
        } else {
            this.loading = true;
        }
    }
    public onChangePOTSDisconnectReason(event: string) {
        if (event.endsWith("(Waive Penalty)")) {
            this.isPOTSFeeWaived = true;
        } else {
            this.isPOTSFeeWaived = false;
        }
        for (let i = 0; i < this.disconnectPOTSService.reasonList.length; i++) {
            if (this.findAndReplace(event.replace("(Waive Penalty)", "").trim(), " - ", "-") === this.findAndReplace(this.disconnectPOTSService.reasonList[i].description.trim(), " - ", "-")) {
                this.potsSelectedReason = this.disconnectPOTSService.reasonList[i];
                this.updateCartOnSelectChange("POTS Early Termination Fee", !this.isPOTSFeeWaived ? +this.disconnectPOTSService.etfInfo.terminationFee : 0);
                break;
            }
        }
    }
    public retainArray: any = [];
    public setDataForOTC() {
        if (this.invokeCall === "OTC installment") {
            let retainVal = <Observable<any>>this.store.select("retain");
            let retSubscribe = retainVal.subscribe(retVal => {
                if (retVal && retVal.otcinfo && retVal.otcinfo.payload) {
                    this.retainArray = retVal.otcinfo.payload;
                    this.retainArray.map(payload => {
                        this.checkPay(payload.value, payload.otc);
                    });
                }
                if (this.isOtcSelected === "no") {
                    this.retainArray = this.retainArray.map(payload => {
                        payload.value = "1 payment";
                    });
                } else {
                    this.retainArray.map(payload => {
                        this.checkPay(payload.value, payload.otc);
                    });
                }
            });
            retSubscribe.unsubscribe();
        }
    }
    public defaultDate: any;
    public date: any;
    public serviceDate: string;
    public arcCreditsStartDate: string;
    public arcCreditsEndDate: string;
    public azCreditsStartDate: any;
    public azCreditsEndDate: string;
    public assessCharge: any[] = [];
    public selectedAssessCharge: string = '';
    get f() { return this.addAuthUserForm.controls; }

    public ngOnInit() {
        this.user = <Observable<any>>this.store.select("user");
        this.userSubscription = this.user.subscribe(data => {
            if (data.previousUrl === "/schedule-appt-ship" && data.currentUrl === "/customize-services") {
                this.isRentrant = true;
            } else {
                this.isRentrant = false;
                this.isRentrant = data.reEntrant;
            }
            if (data && data.orderDisclosers && data.orderDisclosers.rccGroup && (data.orderDisclosers.rccGroup.length > 0) && data.orderDisclosers.rccGroup[0].rccDetails && (data.orderDisclosers.rccGroup[0].rccDetails.length > 0)) {
                this.orderDisclosuresDetails = data.orderDisclosers.rccGroup[0].rccDetails;
            }
            this.vacationObservable = <Observable<any>>this.store.select('vacation');
            this.vacationSubscription = this.vacationObservable.subscribe((vacadata) => {
                if (vacadata && vacadata !== undefined && vacadata.vacationSuspendInitRes && vacadata.vacationSuspendInitRes !== undefined) {
                    this.vacationopton = vacadata.vacationSuspendInitRes;
                    if (data.currentUrl === '/vacation-schedule-appt-ship') {
                        this.vacationResData = vacadata.vacationscheduleresponse;
                    } else {
                        this.vacationResData = this.accountObservableData;
                    }
                }
            });
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider)
                this.legacy = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
        });
        let lifelineDetainRetain = <Observable<any>>this.store.select("customize");
        let retainCustomizeLifelineData = lifelineDetainRetain.subscribe(data => {
            this.lifelineInternet = data && data.lifelineaddedforinternet !== undefined && data.lifelineaddedforinternet;
            this.lifelineRequestData = data && data.lifelineRequest && data.lifelineRequest !== undefined && data.lifelineRequest.lifeLineProducts;
            this.lifelineConfigData = data.lifelineConfig;
            this.lifelineDiscountsData = data.lifelineDiscounts;
            this.lifelineAdjustmentData = data.lifelineAdjustment;
            this.lifelineConfigPotsData = data.lifelinePotsConfig;
            this.lifelineDiscountsPotsData = data.lifelinePotsDiscounts;
            this.lifelineAdjustmentPotsData = data.lifelinePotsAdjustment;
            if (data.assessCharge) {
                this.assessCharge = data.assessCharge;
            }
        });
        this.orderObservable = <Observable<Order>>this.store.select("order");
        this.orderSubscription = this.orderObservable.subscribe(data => {
            if (data && data.payload && data.payload !== undefined && data.payload.orderSummary && data.payload.orderSummary !== undefined) {
                this.orderSummary = data.payload.orderSummary;
            }
            if (data && data.tnChargeNotReq) {
                this.potsTnChargesUpdatingtoCart(true);
            }
        });
        this.portingAccountTnForm = this.fb.group({
            carrierName: [""],
            accountNo: ["", Validators.required],
            accessPin: [""],
            billNameProvider: [""],
            billingAddress: [""],
            streetNumber: [""],
            streetName: [""],
            city: [""],
            state: [""],
            zipCode: [""],
            search: ""
        });
        this.additionalTnForm = this.fb.group({
            npa: "",
            nxx: "",
            rangeStart: "",
            rangeEnd: "",
            line: ""
        });
        this.addOnAttribForm = this.fb.group({
            title1: this.addonAttributes && this.addonAttributes.title1 ? this.addonAttributes.title1 : "",
            title2: this.addonAttributes && this.addonAttributes.title2 ? this.addonAttributes.title2 : "",
            lineage: this.addonAttributes && this.addonAttributes.lineage ? this.addonAttributes.lineage : "",
            designation: this.addonAttributes && this.addonAttributes.designation ? this.addonAttributes.designation : "",
            Nickname: this.addonAttributes && this.addonAttributes.Nickname ? this.addonAttributes.Nickname : ""
        });
        this.additionalAttribForm = this.fb.group({
            subscriberId: [this.nladData, [Validators.required]],
            serviceDate: new DatePipe("en-US").transform(this.serviceDate, "yyyy-MM-dd")
        });
        this.additionalCreditsForm = this.fb.group({
            llarcCreditInd: this.lifelineRespData && this.lifelineRespData !== null && this.llarcCreditIndRes ? this.llarcCreditIndRes : false,
            discountCode: this.lifelineRespData && this.lifelineRespData !== null && this.lifelineRespData.discounts !== undefined && this.lifelineRespData.discounts.length > 0 ? this.lifelineRespData.discounts[0].discountCode : "",
            recurringStateCreditDesc: this.lifelineRespData && this.lifelineRespData !== null ? this.recurringStateCreditDescRes : "",
            startDate: this.azCreditsStartDate,
            endDate: this.azCreditsEndDate,
            arcstartDate: this.arcCreditsStartDate,
            arcEndDate: this.arcCreditsEndDate,
            arcrecurringStateCredit: this.recurringStateCredit,
            zone1Ind: this.lifelineRespData && this.lifelineRespData !== null && this.lifelineRespData.discounts !== undefined && this.lifelineRespData.discounts.length > 0 ? this.lifelineRespData.discounts[0].zone1Ind : false,
            zone2Ind: this.lifelineRespData && this.lifelineRespData !== null && this.lifelineRespData.discounts !== undefined && this.lifelineRespData.discounts.length > 0 ? this.lifelineRespData.discounts[0].zone2Ind : false,
            WireMaintanaceInd: this.lifelineRespData && this.lifelineRespData !== null && this.lifelineRespData.discounts !== undefined && this.lifelineRespData.discounts.length > 0 ? this.lifelineRespData.discounts[0].wireMaintanaceInd : false,
            adjustmentReason: "",
            nonRecurringStateCreditDesc: this.nonRecurringStateCreditDesc,
            adjustmentAmount: this.adjustmentAmount,
            actionType: this.lifelineRespData && this.lifelineRespData !== null && this.lifelineRespData.discounts !== undefined && this.lifelineRespData.discounts.length > 0 ? this.lifelineRespData.discounts[0].actionType : "ADD"
        });
        this.addAuthUserForm = this.fb.group({
            'firstNameFirst': [this.firstNameFirst],
            'lastNameFirst': [this.lastNameFirst],
            'contactFirst': [this.contactFirst],
            'firstNameSecond': [this.firstNameSecond],
            'lastNameSecond': [this.lastNameSecond],
            'contactSecond': [this.contactSecond]
        });
        if (this.lifelineRespData && this.lifelineRespData !== null) {
            this.lifelineRespData.discounts.map(item => {
                if (item.llarcCreditInd && item.discountCode === "LLARC") {
                    this.llarcCreditIndRes = item.llarcCreditInd;
                    this.arcCreditsStartDateRes = item.startDate;
                    this.arcCreditsEndDateRes = item.endDate;
                }
                if (item.recurringStateCreditDesc && item.recurringStateCreditDesc !== null && !item.llarcCreditInd) {
                    this.recurringStateCreditDescRes = item.recurringStateCreditDesc;
                    this.azCreditsStartDateRes = item.startDate;
                    this.azCreditsEndDateRes = item.endDate;
                }
            });
        }
        if ((this.recurringStateCreditDescRes && this.recurringStateCreditDescRes !== null) || this.llarcCreditIndRes) {
            this.saveButton = true;
        }
        this.defaultDate = "9999-12-31";
        this.date = new Date();
        if (!this.isRentrant) {
            this.arcCreditsStartDate = this.lifelineRespData && this.lifelineRespData !== null && this.arcCreditsStartDateRes ? this.arcCreditsStartDateRes : new DatePipe("en-US").transform(this.date.toString(), "MM/dd/yyyy");
            this.arcCreditsEndDate = this.lifelineRespData && this.lifelineRespData !== null && this.arcCreditsEndDateRes ? this.arcCreditsEndDateRes : new DatePipe("en-US").transform(this.defaultDate, "MM/dd/yyyy");
            this.serviceDate =
                this.lifelineReponseData && this.lifelineReponseData !== null ? new DatePipe("en-US").transform(this.lifelineReponseData.nladData.serviceDate, "MM/dd/yyyy") : this.serviceDate === null ? "" : new DatePipe("en-US").transform(this.date.toString(), "MM/dd/yyyy");
            this.nladData = this.lifelineReponseData && this.lifelineReponseData !== null ? this.lifelineReponseData.nladData.subscriberId : this.nladData;
            this.azCreditsStartDate = this.lifelineRespData && this.lifelineRespData !== null && this.azCreditsStartDateRes ? this.azCreditsStartDateRes : new DatePipe("en-US").transform(this.date.toString(), "MM/dd/yyyy");
            this.azCreditsEndDate = this.lifelineRespData && this.lifelineRespData !== null && this.azCreditsEndDateRes ? this.azCreditsEndDateRes : new DatePipe("en-US").transform(this.defaultDate, "MM/dd/yyyy");
        } else {
            if (!this.lifelineRequestData && this.lifelineRequestData === undefined &&
                ((this.lifelineDiscountsData && this.lifelineDiscountsData.discounts && this.lifelineDiscountsData.discounts !== undefined) ||
                    (this.lifelineConfigData !== undefined && this.lifelineConfigData) ||
                    (this.lifelineAdjustmentData !== undefined && this.lifelineAdjustmentData && this.lifelineAdjustmentData.adjustments !== undefined &&
                        this.lifelineAdjustmentData.adjustments))) {
                this.lifelineDiscountsData &&
                    this.lifelineDiscountsData !== undefined &&
                    this.lifelineDiscountsData.discounts &&
                    this.lifelineDiscountsData.discounts !== undefined &&
                    this.lifelineDiscountsData.discounts.map(data => {
                        if (data.llarcCreditInd && data.recurringStateCreditDesc !== "" && data.discountCode === "LLARC") {
                            this.arcCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                            this.arcCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                            this.additionalCreditsForm
                                .get("llarcCreditInd")
                                .setValue(data.llarcCreditInd);
                            this.arcCreditEnable = false;
                            this.saveButton = true;
                        }
                        if (!data.llarcCreditInd && data.recurringStateCreditDesc !== "") {
                            this.azCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                            this.azCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                            this.additionalCreditsForm
                                .get("recurringStateCreditDesc")
                                .setValue(data.recurringStateCreditDesc);
                            this.stateCreditEnable = false;
                            this.saveButton = true;
                        }
                    });
                this.serviceDate = new DatePipe("en-US").transform(
                    this.lifelineConfigData &&
                    this.lifelineConfigData !== undefined &&
                    this.lifelineConfigData.nladData &&
                    this.lifelineConfigData.nladData !== undefined &&
                    this.lifelineConfigData.nladData.serviceDate !== undefined &&
                    this.lifelineConfigData.nladData.serviceDate, "MM/dd/yyyy");
                this.nladData =
                    this.lifelineConfigData &&
                    this.lifelineConfigData.nladData &&
                    this.lifelineConfigData.nladData !== undefined &&
                    this.lifelineConfigData.nladData.subscriberId !== undefined &&
                    this.lifelineConfigData.nladData.subscriberId;
                this.nonRecurringStateCreditDesc =
                    this.lifelineAdjustmentData &&
                    this.lifelineAdjustmentData.adjustments &&
                    (this.lifelineAdjustmentData.adjustments !== undefined ||
                        this.lifelineAdjustmentData.adjustments !== null) &&
                    this.lifelineAdjustmentData.adjustments[0] !== undefined &&
                    this.lifelineAdjustmentData.adjustments[0] &&
                    this.lifelineAdjustmentData.adjustments[0]
                        .nonRecurringStateCreditDesc;
                if (this.nonRecurringStateCreditDesc && this.nonRecurringStateCreditDesc !== "") {
                    this.nonCreditEnable = false;
                    this.saveButton = true;
                }
                this.adjustmentAmount =
                    this.lifelineAdjustmentData &&
                    this.lifelineAdjustmentData.adjustments &&
                    (this.lifelineAdjustmentData.adjustments !== undefined || this.lifelineAdjustmentData.adjustments !== null) &&
                    this.lifelineAdjustmentData.adjustments[0] !== undefined &&
                    this.lifelineAdjustmentData.adjustments[0] &&
                    this.lifelineAdjustmentData.adjustments[0].adjustmentAmount;
            }
            if (
                !this.lifelineRequestData &&
                this.lifelineRequestData === undefined &&
                ((this.lifelineDiscountsPotsData !== undefined &&
                    this.lifelineDiscountsPotsData.discounts !== undefined &&
                    this.lifelineDiscountsPotsData.discounts) ||
                    (this.lifelineConfigData && this.lifelineConfigData !== undefined) ||
                    (this.lifelineAdjustmentData &&
                        this.lifelineAdjustmentData !== undefined &&
                        this.lifelineAdjustmentData.adjustments &&
                        this.lifelineAdjustmentData.adjustments !== undefined))
            ) {
                this.lifelineDiscountsData &&
                    this.lifelineDiscountsData !== undefined &&
                    this.lifelineDiscountsData.discounts &&
                    this.lifelineDiscountsData.discounts !== undefined &&
                    this.lifelineDiscountsData.discounts.map(data => {
                        if (data.llarcCreditInd && data.recurringStateCreditDesc !== "" && data.discountCode === "LLARC") {
                            this.arcCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                            this.arcCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                            this.additionalCreditsForm
                                .get("llarcCreditInd")
                                .setValue(data.llarcCreditInd);
                            this.arcCreditEnable = false;
                            this.saveButton = true;
                        }
                        if (!data.llarcCreditInd && data.recurringStateCreditDesc !== "") {
                            this.azCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                            this.azCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                            this.additionalCreditsForm
                                .get("recurringStateCreditDesc")
                                .setValue(data.recurringStateCreditDesc);
                            this.stateCreditEnable = false;
                            this.saveButton = true;
                        }
                    });
                this.serviceDate = new DatePipe("en-US").transform(
                    this.lifelineConfigData &&
                    this.lifelineConfigData !== undefined &&
                    this.lifelineConfigData.nladData &&
                    this.lifelineConfigData.nladData !== undefined &&
                    this.lifelineConfigData.nladData.serviceDate !== undefined &&
                    this.lifelineConfigData.nladData.serviceDate, "MM/dd/yyyy"
                );
                this.nladData =
                    this.lifelineConfigData &&
                    this.lifelineConfigData.nladData &&
                    this.lifelineConfigData.nladData !== undefined &&
                    this.lifelineConfigData.nladData.subscriberId !== undefined &&
                    this.lifelineConfigData.nladData.subscriberId;
                this.nonRecurringStateCreditDesc =
                    this.lifelineAdjustmentData &&
                    this.lifelineAdjustmentData.adjustments &&
                    (this.lifelineAdjustmentData.adjustments !== undefined || this.lifelineAdjustmentData.adjustments !== null) &&
                    this.lifelineAdjustmentData.adjustments[0] !== undefined &&
                    this.lifelineAdjustmentData.adjustments[0] &&
                    this.lifelineAdjustmentData.adjustments[0]
                        .nonRecurringStateCreditDesc;
                if (this.nonRecurringStateCreditDesc && this.nonRecurringStateCreditDesc !== "") {
                    this.nonCreditEnable = false;
                    this.saveButton = true;
                }
                this.adjustmentAmount =
                    this.lifelineAdjustmentData &&
                    this.lifelineAdjustmentData.adjustments &&
                    (this.lifelineAdjustmentData.adjustments !== undefined || this.lifelineAdjustmentData.adjustments !== null) &&
                    this.lifelineAdjustmentData.adjustments[0] !== undefined &&
                    this.lifelineAdjustmentData.adjustments[0] &&
                    this.lifelineAdjustmentData.adjustments[0].adjustmentAmount;
            }
            this.lifelineRequestData && this.lifelineRequestData !== undefined && this.lifelineRequestData.map(lifelinedata => {
                if (lifelinedata.productDetails.productType === "INTERNET" && this.lifelineInternetAdded) {
                    this.lifelineDiscountsData && this.lifelineDiscountsData !== undefined && this.lifelineDiscountsData.discounts &&
                        this.lifelineDiscountsData.discounts !== undefined && this.lifelineDiscountsData.discounts.map(data => {
                            if (data.llarcCreditInd && data.recurringStateCreditDesc !== "" && data.discountCode === "LLARC") {
                                this.arcCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                                this.arcCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                                this.additionalCreditsForm
                                    .get("llarcCreditInd")
                                    .setValue(data.llarcCreditInd);
                                this.arcCreditEnable = false;
                                this.saveButton = true;
                            }
                            if (!data.llarcCreditInd && data.recurringStateCreditDesc !== "") {
                                this.azCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                                this.azCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                                this.additionalCreditsForm
                                    .get("recurringStateCreditDesc")
                                    .setValue(data.recurringStateCreditDesc);
                                this.stateCreditEnable = false;
                                this.saveButton = true;
                            }
                        });
                    this.serviceDate = new DatePipe("en-US").transform(
                        this.lifelineConfigData &&
                        this.lifelineConfigData !== undefined &&
                        this.lifelineConfigData.nladData &&
                        this.lifelineConfigData.nladData !== undefined &&
                        this.lifelineConfigData.nladData.serviceDate !== undefined &&
                        this.lifelineConfigData.nladData.serviceDate, "MM/dd/yyyy");
                    this.nladData =
                        this.lifelineConfigData &&
                        this.lifelineConfigData.nladData &&
                        this.lifelineConfigData.nladData !== undefined &&
                        this.lifelineConfigData.nladData.subscriberId !== undefined &&
                        this.lifelineConfigData.nladData.subscriberId;
                    this.nonRecurringStateCreditDesc =
                        this.lifelineAdjustmentData &&
                        this.lifelineAdjustmentData.adjustments &&
                        (this.lifelineAdjustmentData.adjustments !== undefined || this.lifelineAdjustmentData.adjustments !== null) &&
                        this.lifelineAdjustmentData.adjustments[0] !== undefined &&
                        this.lifelineAdjustmentData.adjustments[0] &&
                        this.lifelineAdjustmentData.adjustments[0]
                            .nonRecurringStateCreditDesc;
                    if (this.nonRecurringStateCreditDesc && this.nonRecurringStateCreditDesc !== "") {
                        this.nonCreditEnable = false;
                        this.saveButton = true;
                    }
                    this.adjustmentAmount =
                        this.lifelineAdjustmentData &&
                        this.lifelineAdjustmentData.adjustments &&
                        (this.lifelineAdjustmentData.adjustments !== undefined || this.lifelineAdjustmentData.adjustments !== null) &&
                        this.lifelineAdjustmentData.adjustments[0] !== undefined &&
                        this.lifelineAdjustmentData.adjustments[0] &&
                        this.lifelineAdjustmentData.adjustments[0].adjustmentAmount;
                }
                if ((lifelinedata.productDetails.productType === "VOICE-HP" || lifelinedata.productDetails.productType === "VOICE-DHP") && this.lifelinePotsAdded) {
                    this.lifelineDiscountsPotsData && this.lifelineDiscountsPotsData !== undefined && this.lifelineDiscountsPotsData.discounts &&
                        this.lifelineDiscountsPotsData.discounts !== undefined && this.lifelineDiscountsPotsData.discounts.map(data => {
                            if (data.llarcCreditInd && data.recurringStateCreditDesc !== "" && data.discountCode === "LLARC") {
                                this.arcCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                                this.arcCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                                this.additionalCreditsForm
                                    .get("llarcCreditInd")
                                    .setValue(data.llarcCreditInd);
                                this.arcCreditEnable = false;
                                this.saveButton = true;
                            }
                            if (!data.llarcCreditInd && data.recurringStateCreditDesc !== "") {
                                this.azCreditsStartDate = new DatePipe("en-US").transform(data.startDate, "MM/dd/yyyy");
                                this.azCreditsEndDate = new DatePipe("en-US").transform(data.endDate, "MM/dd/yyyy");
                                this.additionalCreditsForm
                                    .get("recurringStateCreditDesc")
                                    .setValue(data.recurringStateCreditDesc);
                                this.stateCreditEnable = false;
                                this.saveButton = true;
                            }
                        });
                    this.serviceDate = new DatePipe("en-US").transform(
                        this.lifelineConfigPotsData &&
                        this.lifelineConfigPotsData.nladData &&
                        this.lifelineConfigPotsData.nladData !== undefined &&
                        this.lifelineConfigPotsData.nladData.serviceDate !==
                        undefined &&
                        this.lifelineConfigPotsData.nladData.serviceDate, "MM/dd/yyyy");
                    this.nladData =
                        this.lifelineConfigPotsData &&
                        this.lifelineConfigPotsData.nladData &&
                        this.lifelineConfigPotsData.nladData !== undefined &&
                        this.lifelineConfigPotsData.nladData.subscriberId !== undefined &&
                        this.lifelineConfigPotsData.nladData.subscriberId;
                    this.nonRecurringStateCreditDesc =
                        this.lifelineAdjustmentPotsData &&
                        this.lifelineAdjustmentPotsData.adjustments &&
                        (this.lifelineAdjustmentPotsData.adjustments !== undefined || this.lifelineAdjustmentPotsData.adjustments !== null) &&
                        this.lifelineAdjustmentPotsData.adjustments[0] !== undefined &&
                        this.lifelineAdjustmentPotsData.adjustments[0] &&
                        this.lifelineAdjustmentPotsData.adjustments[0]
                            .nonRecurringStateCreditDesc;
                    if (this.nonRecurringStateCreditDesc && this.nonRecurringStateCreditDesc !== "") {
                        this.nonCreditEnable = false;
                        this.saveButton = true;
                    }
                    this.adjustmentAmount =
                        this.lifelineAdjustmentPotsData &&
                        this.lifelineAdjustmentPotsData.adjustments &&
                        (this.lifelineAdjustmentPotsData.adjustments !== undefined || this.lifelineAdjustmentPotsData.adjustments !== null) &&
                        this.lifelineAdjustmentPotsData.adjustments[0] !== undefined &&
                        this.lifelineAdjustmentPotsData.adjustments[0] &&
                        this.lifelineAdjustmentPotsData.adjustments[0].adjustmentAmount;
                }
            });
        }
        this.listedAddressUpdateForm = this.fb.group({
            streetNrFirst: "",
            streetNamePrefix: "",
            streetName: "",
            streetType: "",
            unit: "",
            city: "",
            state: "",
            postCode: ""
        });
        this.additionalTnForm.get("npa").valueChanges.subscribe(val => {
            if (val !== "") {
                this.nxxList = this.npanxxList[val];
            } else {
                this.nxxList = [];
                this.additionalTnForm.get("nxx").setValue("");
            }
        });
        this.listedAddressUpdateForm.get("state").valueChanges.subscribe(val => {
            if (val !== "") {
                this.cityList = [{ city: '' }];
                this.cityList = sortBy(this.statesCityList[val], city => city.city);
            } else {
                this.cityList = [{ city: '' }];
                this.listedAddressUpdateForm.get("city").setValue("");
            }
        });
        retainCustomizeLifelineData.unsubscribe();
        this.searchBox.valueChanges.pipe(debounceTime(750))
            .subscribe((values) => {
                this.backUpCarrierList = cloneDeep(this.listofCarriers);
                this.backUpCarrierList = [];
                let value: string = this.searchBox.value.search.toUpperCase();
                if (value && value.trim().length > 0) {
                    this.viewCarrier = true;
                    if (this.viewAllCarriers) {
                        this.listofCarriers && this.listofCarriers.map(carrier => {
                            if (carrier.indexOf(value) !== -1) {
                                this.backUpCarrierList.push(carrier);
                            }
                        })
                    } else if (this.viewSelectedCarriers) {
                        this.selectedListCarriers && this.selectedListCarriers.map(carrier => {
                            if (carrier && carrier.orderAttributeValue && carrier.orderAttributeValue.indexOf(value) !== -1) {
                                this.backUpCarrierList.push(carrier);
                            }
                        })
                    }
                } else {
                    this.viewCarrier = false;
                }
            })
        if (this.fromExisting !== undefined) {
            this.stackChange = "amendOrder";
        }
    }
    public arcCreditsStartDateUpdated(event) {
        this.arcCreditsStartDate = event;
    }
    public arcCreditsEndDateUpdated(event) {
        this.arcCreditsEndDate = event;
    }
    public azCreditsStartDateUpdated(event) {
        this.azCreditsStartDate = event;
    }
    public azCreditsEndDateUpdated(event) {
        this.azCreditsEndDate = event;
    }
    public customerRequestedDueDateUpdated(event) {
        this.serviceDate = event.substring(0, 23);
    }
    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = H % 12 || 12;
            h = h < 10 ? "0" + h : h;
            let ampm = H < 12 ? " AM" : " PM";
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }
    public saveListedUpdates() {
        let savedUpdates = {
            streetNrFirst: this.listedAddressUpdateForm.get("streetNrFirst").value,
            streetNamePrefix: this.listedAddressUpdateForm.get("streetNamePrefix").value,
            streetName: this.listedAddressUpdateForm.get("streetName").value,
            streetType: this.listedAddressUpdateForm.get("streetType").value,
            unit: this.listedAddressUpdateForm.get("unit").value,
            city: this.listedAddressUpdateForm.get("city").value,
            state: this.listedAddressUpdateForm.get("state").value,
            postCode: this.listedAddressUpdateForm.get("postCode").value
        };
        this.updatedListedAddress.emit(savedUpdates);
        this.close(true);
    }
    public telephoneError(error, error_type) {
        let unexpectedError = false;
        if (this.ctlHelperService.isJson(error)) {
            this.apiResponseError = JSON.parse(error);
            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                this.systemErrorService.logAndeRouteToSystemError("error", error_type, "dialog.component.ts", "Customize Page", this.apiResponseError);
            } else unexpectedError = true;
        } else unexpectedError = true;
        if (unexpectedError) {
            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
            this.systemErrorService.logAndeRouteToSystemError("error", error_type, "dialog.component.ts", "Add-Ons Page", lAPIErrorLists);
        }
    }
    public addAuthUser(frm) {
        const authUsersObj = this.addAuthUserForm.value;
        let authUsers = [];
        this.firstNameFirst = authUsersObj.firstNameFirst;
        this.lastNameFirst = authUsersObj.lastNameFirst;
        this.contactFirst = authUsersObj.contactFirst;
        this.firstNameSecond = authUsersObj.firstNameSecond;
        this.lastNameSecond = authUsersObj.lastNameSecond;
        this.contactSecond = authUsersObj.contactSecond;
        const firstUser = {
            action: 'ADD',
            contactType: 'AUP',
            firstName: authUsersObj.firstNameFirst,
            lastName: authUsersObj.lastNameFirst,
            contactPhone: authUsersObj.contactFirst,
        };
        const secondUser = {
            action: 'ADD',
            contactType: 'AUP',
            firstName: authUsersObj.firstNameSecond,
            lastName: authUsersObj.lastNameSecond,
            contactPhone: authUsersObj.contactSecond
        };
        authUsers = [firstUser, secondUser]
        this.store.dispatch({ type: 'AUTHORIZED_PARTIES', payload: authUsers });
        this.close(true);
    }
    public clearOne() {
        this.addAuthUserForm.controls.firstNameFirst.setValue("");
        this.addAuthUserForm.controls.lastNameFirst.setValue("");
        this.addAuthUserForm.controls.contactFirst.setValue("");
    }
    public clearTwo() {
        this.addAuthUserForm.controls.firstNameSecond.setValue("");
        this.addAuthUserForm.controls.lastNameSecond.setValue("");
        this.addAuthUserForm.controls.contactSecond.setValue("");
    }
    public selectTn() {
        if (!this.isTnInAging) {
            this.reserveTNCall();
        } else {
            this.onTnSelected.emit(this.selectedMoreTN);
            this.store.dispatch({ type: 'TN_RESERVED', payload: true });
            this.potsTnChargesUpdatingtoCart();
            this.close(true);
        }
    }
    public releaseTN() {
        let oldTN = {
            orderReferenceNumber: this.orderReferenceNumber ? this.orderReferenceNumber : "",
            telephoneNumber: this.defaultTN,
            productType: this.productType && this.productType === "dhp" ? "VOICE-DHP" : this.productType && this.productType === "hp" ? "VOICE-HP" : ""
        };
        this.logger.log("info", "dialog.component.ts", "doReleaseTNRequest", JSON.stringify(oldTN));
        this.logger.startTime();
        this.loading = true;
        this.productService
            .doReleaseTN(oldTN)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "doReleaseTNResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "doReleaseTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "doReleaseTNResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "doReleaseTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data && data.released && data.released === true) {
                        this.TNCallHappening = false;
                        this.onTnSelected.emit(this.selectedMoreTN);
                        this.close(true);
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "doReleaseTNResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "doReleaseTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.TNCallHappening = false;
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ReleaseTNCallError", "customize-services.component.ts", "ReleaseTN - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ReleaseTNCallError", "customize-services.component.ts", "ReleaseTN - Dialog", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public potsTnChargesUpdatingtoCart(flag?: boolean) {
        let customize, selectedAssessCharge, customizeSubscription, catalog, cartData, cartObservable, cartSub, tnProduct, findResult;
        customize = <Observable<any>>this.store.select('customize');
        customizeSubscription = customize.subscribe((data) => {
            if (data && data.selectedAssessCharge) {
                selectedAssessCharge = data.selectedAssessCharge;
            }
        });
        if (selectedAssessCharge === 'Custom Number') catalog = this.ctlHelperService.getLocalStorage('custom_number');
        else if (selectedAssessCharge === 'Same Number') catalog = this.ctlHelperService.getLocalStorage('same_number');
        tnProduct = this.ctlHelperService.catalogItemToCustSubItem(catalog, 'ADD');
        cartObservable = <Observable<ShoppingCart>>this.store.select('cart');
        if (catalog) {
            if (selectedAssessCharge && !flag) {
                cartSub = cartObservable.subscribe((data) => {
                    data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems && data.payload.cart.customerOrderItems.map((coi) => {
                        if (coi.productType === 'VOICE-HP' && coi.offerType === 'P4L') {
                            findResult = coi.customerOrderSubItems && coi.customerOrderSubItems.find((cosi) => cosi.productId === tnProduct.productId)
                            if (coi && coi.customerOrderSubItems && !findResult) {
                                coi.customerOrderSubItems.push(tnProduct);
                            }
                        }
                    });
                    cartData = cloneDeep(data);
                });
            } else {
                cartSub = cartObservable.subscribe((data) => {
                    data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems && data.payload.cart.customerOrderItems.map((coi) => {
                        if (coi.productType === 'VOICE-HP' && coi.offerType === 'P4L') {
                            coi.customerOrderSubItems = coi && coi.customerOrderSubItems && coi.customerOrderSubItems.filter((cosi) => cosi.productId !== tnProduct.productId)
                        }
                    });
                    cartData = cloneDeep(data);
                });
            }
        }
        if (cartSub !== undefined) cartSub.unsubscribe();
        this.store.dispatch({ type: 'CREATE_CART', payload: cartData });
        if (customizeSubscription !== undefined) customizeSubscription.unsubscribe();
    }
    public reserveTNCall() {
        this.TNCallHappening = true;
        const newTN = {
            exchangeKey: this.exchangeKeyValue,
            orderReferenceNumber: this.orderReferenceNumber ? this.orderReferenceNumber : "",
            pooledTNIndicator: this.pooledTNIndicatorValue,
            productType: this.productType && this.productType === "dhp" ? "VOICE-DHP" : this.productType && this.productType === "hp" ? "VOICE-HP" : "",
            telephoneNumber: this.selectedMoreTN
        };
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "doReserveTNRequest", JSON.stringify(newTN));
        this.logger.startTime();
        this.newReserveTNObject = newTN;
        this.productService
            .doReserveTN(newTN)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "doReserveTNResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "doReserveTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "doReserveTNResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "doReserveTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.onTnBackSelected.emit(this.newReserveTNObject);
                    if (data && data.reserved === "Y") {
                        if (this.defaultTN && this.savedPhoneTN && this.savedPhoneTN.workingTN && this.savedPhoneTN.workingTN.toLowerCase() === "no") {
                            this.potsTnChargesUpdatingtoCart();
                            this.store.dispatch({ type: 'TN_RESERVED', payload: true });
                            this.releaseTN();
                        } else {
                            this.onTnSelected.emit(this.selectedMoreTN);
                            this.store.dispatch({ type: 'TN_RESERVED', payload: true });
                            this.potsTnChargesUpdatingtoCart();
                            this.close(true);
                        }
                    } else {
                        this.TNCallHappening = false;
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "doReserveTNResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "doReserveTNSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.TNCallHappening = false;
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ReserveTNCallError", "dialog.component.ts", "ReserveTN - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ReserveTNCallError", "dialog.component.ts", "ReserveTN - Dialog", lAPIErrorLists);
                    }
                    this.apiResponseError = JSON.parse(error);
                    window.scroll(0, 0);
                }
            );
    }
    public saveUpdate(event) {
        this.additionalAttribForm
            .get("serviceDate")
            .setValue(new DatePipe("en-US").transform(this.serviceDate, "yyyy-MM-dd"));
        if (this.nladData && this.nladData !== "") {
            this.ppllnlad = true;
            this.close(true);
        } else {
            this.ppllnlad = false;
            this.close(false);
        }
        this.onSaveUpdates.emit(this.additionalAttribForm.value);
        this.submitted = true;
    }
    public saveUpdateAddons() {
        this.onSaveUpdates.emit(this.addOnAttribForm.value);
        this.close(true);
    }
    public saveDiscountsUpdate(event) {
        let lifelineDiscounts = [];
        this.arcstartDateone = {
            llarcCreditInd: false,
            discountCode: "",
            recurringStateCreditDesc: this.additionalCreditsForm.get("recurringStateCreditDesc").value,
            startDate: this.azCreditsStartDate,
            endDate: this.azCreditsEndDate,
            zone1Ind: false,
            zone2Ind: false,
            WireMaintanaceInd: false,
            actionType: "ADD"
        };
        this.arcstartDateTwo = {
            llarcCreditInd: this.additionalCreditsForm.get("llarcCreditInd").value,
            discountCode: "",
            recurringStateCreditDesc: this.recurringStateCredit,
            startDate: this.arcCreditsStartDate,
            endDate: this.arcCreditsEndDate,
            zone1Ind: false,
            zone2Ind: false,
            WireMaintanaceInd: false,
            actionType: "ADD"
        };
        this.arcstartDatethree = {
            llarcCreditInd: false,
            discountCode: "",
            recurringStateCreditDesc: this.additionalCreditsForm.get("recurringStateCreditDesc").value,
            startDate: this.azCreditsStartDate,
            endDate: this.azCreditsEndDate,
            zone1Ind: false,
            zone2Ind: false,
            WireMaintanaceInd: false,
            actionType: "ADD"
        };
        this.arcstartDatefour = {
            llarcCreditInd: false,
            discountCode: "",
            recurringStateCreditDesc: this.lifelineRespData && this.lifelineRespData !== null ? this.recurringStateCreditDescRes : "",
            startDate: this.azCreditsStartDateRes,
            endDate: new DatePipe("en-US").transform(this.date.toString(), "MM/dd/yyyy"),
            zone1Ind: false,
            zone2Ind: false,
            WireMaintanaceInd: false,
            actionType: "REMOVE"
        };

        if (this.lifelineRespData && this.lifelineRespData !== null) {
            this.lifelineRespData.discounts.map(item => {
                if (item.llarcCreditInd && item.discountCode === "LLARC") {
                    this.llarcCreditIndRes = item.llarcCreditInd;
                    this.arcCreditsStartDateRes = item.startDate;
                    this.arcCreditsEndDateRes = item.endDate;
                    this.discountCode = item.discountCode;
                }
                if (item.recurringStateCreditDesc && item.recurringStateCreditDesc !== null && !item.llarcCreditInd) {
                    this.recurringStateCreditDescRes = item.recurringStateCreditDesc;
                    this.azCreditsStartDateRes = item.startDate;
                    this.azCreditsEndDateRes = item.endDate;
                }
            });
        }
        this.llarcCreditInd = this.additionalCreditsForm.get("llarcCreditInd").value;
        if (this.lifelineRespData === undefined || this.lifelineRespData === null) {
            if (this.llarcCreditInd) {
                lifelineDiscounts.push(this.arcstartDateTwo);
            }
        }
        if (this.lifelineRespData && this.lifelineRespData !== null) {
            if (this.llarcCreditInd !== this.llarcCreditIndRes) {
                lifelineDiscounts.push(this.arcstartDateTwo);
                if (!this.llarcCreditInd) {
                    lifelineDiscounts[0].actionType = "REMOVE";
                    lifelineDiscounts[0].llarcCreditInd = false;
                    lifelineDiscounts[0].endDate = new DatePipe("en-US").transform(this.date.toString(), "MM/dd/yyyy");
                }
            } else if (this.llarcCreditInd === this.llarcCreditIndRes) {
                lifelineDiscounts.push(this.arcstartDateTwo);
                lifelineDiscounts[0].actionType = "NOCHANGE";
            }
        }

        this.recurringStateCreditDesc = this.additionalCreditsForm.get("recurringStateCreditDesc").value;
        if (this.lifelineRespData === undefined || this.lifelineRespData === null) {
            if (this.recurringStateCreditDesc && this.recurringStateCreditDesc !== "") {
                lifelineDiscounts.push(this.arcstartDateone);
            }
        }
        if (this.lifelineRespData && this.lifelineRespData !== null) {
            if (this.recurringStateCreditDesc !== this.recurringStateCreditDescRes) {
                lifelineDiscounts.push(this.arcstartDatefour);
                lifelineDiscounts.push(this.arcstartDatethree);
            } else if (this.recurringStateCreditDesc === this.recurringStateCreditDescRes) {
                lifelineDiscounts.push(this.arcstartDateone);
                lifelineDiscounts[1].actionType = "NOCHANGE";
            }
        }
        lifelineDiscounts.forEach(item => {
            item.discountCode = item.recurringStateCreditDesc ? item.recurringStateCreditDesc
                .substring(item.recurringStateCreditDesc.lastIndexOf("("), item.recurringStateCreditDesc.length)
                .replace(/[\(\)]/g, "")
                : null;
            if (this.llarcCreditInd) {
                item.startDate = new DatePipe("en-US").transform(item.startDate, "yyyy-MM-dd");
                item.endDate = new DatePipe("en-US").transform(item.endDate, "yyyy-MM-dd");
            }
            if (!this.llarcCreditInd && this.recurringStateCreditDesc && this.recurringStateCreditDesc !== "") {
                item.startDate = new DatePipe("en-US").transform(item.startDate, "yyyy-MM-dd");
                item.endDate = new DatePipe("en-US").transform(item.endDate, "yyyy-MM-dd");
            }
        });
        this.discountsUpdates = lifelineDiscounts;
        if (this.adjustmentsNonRecurring) {
            this.onSaveUpdates.emit(this.additionalCreditsForm);
        }
        this.saveDiscounts.emit(this.discountsUpdates);
        this.close(true);
    }
    public resetTns() {
        this.additionalTnForm.get("npa").setValue("");
        this.additionalTnForm.get("nxx").setValue("");
        this.additionalTnForm.get("rangeStart").setValue("");
        this.additionalTnForm.get("rangeEnd").setValue("");
        this.additionalTnForm.get("line").setValue("");
        this.retrieveTnFlag = false;
        this.checkTnFlag = false;
        this.phoneSelectedFlag = false;
        this.TNListLoading = false;
        this.avalableTNsList = [];
        this.selectedMoreTN = undefined;
        this.invalidRange = false;
        this.invalidLine = false;
        this.availableNumber = undefined;
        this.notAvailableTN = false;
        this.errorMsg = "";
    }
    public retrieveTn() {
        this.retrieveTnFlag = true;
        this.checkTnFlag = false;
        this.TNListLoading = true;
        this.avalableTNsList = [];
        let orn = this.orderReferenceNumber ? this.orderReferenceNumber : "";
        let productType = this.productType && this.productType === "dhp" ? "VOICE-DHP" : this.productType && this.productType === "hp" ? "VOICE-HP" : "";
        let req: any;
        req = {
            npa: "",
            nxx: "",
            orderReferenceNumber: orn,
            productType: productType,
            quantity: "10",
            startLine: "0000",
            stopLine: "9999",
            vanityPattern: null,
            wordToSpell: null
        };
        if (this.reqTNType !== "PORTED" && this.productType !== "dhp") {
            req.tnType = this.reqTNType
        }
        if (this.TNQuery === "Specific") {
            req.npa = this.additionalTnForm.get("npa").value;
            req.nxx = this.additionalTnForm.get("nxx").value;
        } else if (this.TNQuery === "Number") {
            if (this.additionalTnForm.get("rangeStart").value.length !== 4 || this.additionalTnForm.get("rangeEnd").value.length !== 4) {
                this.invalidRange = true;
                this.retrieveTnFlag = false;
                this.TNListLoading = false;
                return false;
            }
            req.npa = this.additionalTnForm.get("npa").value;
            req.nxx = this.additionalTnForm.get("nxx").value;
            req.startLine = this.additionalTnForm.get("rangeStart").value;
            req.stopLine = this.additionalTnForm.get("rangeEnd").value;
        }
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "getAvailableTNsRequest", JSON.stringify(req));
        this.logger.startTime();
        this.productService
            .getAvailableTNs(req)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getAvailableTNsResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "getAvailableTNsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.invalidRange = false;
                this.TNListLoading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getAvailableTNsResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "getAvailableTNsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.invalidRange = false;
                    this.TNListLoading = false;
                    this.errorMsg = "";
                    this.notAvailableTN = false;
                    this.avalableTNsList = data.availableTelephoneNumbers ? data.availableTelephoneNumbers : "";
                    this.exchangeKeyValue = data.exchangeKey;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getAvailableTNsResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "getAvailableTNsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.invalidRange = false;
                    this.TNListLoading = false;
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let errorArray = JSON.parse(error);
                    this.notAvailableTN = true;
                    this.phoneSelectedFlag = false;
                    this.errorMsg = errorArray.errorResponse[0].message.split('.')[0];
                    window.scroll(0, 0);
                }
            );
    }
    public validateRetrieve() {
        let check = false;
        if (this.TNQuery === "Specific") {
            if (this.additionalTnForm.get("npa").value === "" || this.additionalTnForm.get("nxx").value === "") {
                check = true;
            }
        } else {
            if (this.additionalTnForm.get("rangeStart").value === "" || this.additionalTnForm.get("rangeEnd").value === "" || this.additionalTnForm.get("npa").value === "" || this.additionalTnForm.get("nxx").value === "") {
                check = true;
            }
        }
        return check;
    }
    public validateCheck() {
        let check = false;
        if (this.additionalTnForm.get("npa").value === "" || this.additionalTnForm.get("nxx").value === "" || this.additionalTnForm.get("line").value === "") {
            check = true;
        }
        return check;
    }
    public checkTn() {
        this.retrieveTnFlag = false;
        this.checkTnFlag = true;
        this.phoneSelectedFlag = true;
        this.invalidLine = false;
        this.TNListLoading = true;
        let manualReq: any;
        manualReq = {
            line: "",
            npa: "",
            nxx: "",
            orderReferenceNumber: this.orderReferenceNumber ? this.orderReferenceNumber : "",
            productType: this.productType && this.productType === "dhp" ? "VOICE-DHP" : this.productType && this.productType === "hp" ? "VOICE-HP" : "",
            vanityPattern: null,
            wordToSpell: null
        };
        if (this.reqTNType !== "PORTED" && this.productType !== "VOICE-DHP") {
            manualReq.tnType = this.reqTNType
        }
        if (this.additionalTnForm.get("line").value.length !== 4) {
            this.invalidLine = true;
            this.checkTnFlag = false;
            this.TNListLoading = false;
            return false;
        }
        manualReq.npa = this.additionalTnForm.get("npa").value;
        manualReq.nxx = this.additionalTnForm.get("nxx").value;
        manualReq.line = this.additionalTnForm.get("line").value;
        this.logger.log("info", "dialog.component.ts", "getAvailableNumberRequest", JSON.stringify(manualReq));
        this.logger.startTime();
        this.loading = true
        this.productService
            .getAvailableNumber(manualReq)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getAvailableNumberResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "getAvailableNumberSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.invalidLine = false;
                this.checkTnFlag = false;
                this.TNListLoading = false;
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getAvailableNumberResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "getAvailableNumberSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.invalidLine = false;
                    this.TNListLoading = false;
                    this.errorMsg = "";
                    if (data.available) {
                        this.availableNumber = data.requestedTelephoneNumber ? data.requestedTelephoneNumber : "";
                        this.tnSelectedVal(this.availableNumber);
                        this.notAvailableTN = false;
                    } else if (data.available && data.available !== "Y") {
                        this.notAvailableTN = true;
                        this.phoneSelectedFlag = false;
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getAvailableNumberResponse", error);
                    this.logger.log("error", "dialog.component.ts", "getAvailableNumberResponse", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.invalidLine = false;
                    this.TNListLoading = false;
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let errorArray = JSON.parse(error);
                    this.notAvailableTN = true;
                    this.phoneSelectedFlag = false;
                    this.errorMsg = errorArray.errorResponse[0].message;
                    window.scroll(0, 0);
                }
            );
    }
    public isTnAgingMore: boolean = false;
    public isWorkingTn: boolean = false;
    public isTnAvailable: boolean = false;
    public isTnNotAbleToDetermine: boolean = false;
    public isTnInAging: boolean = false;
    public isTnMayBeAvailable: boolean = false;
    public tn: string;
    public checkPotsTn() {
        this.retrieveTnFlag = false;
        this.checkTnFlag = true;
        this.invalidLine = false;
        this.TNListLoading = true;
        this.isTnAgingMore = false;
        this.isWorkingTn = false;
        this.isTnAvailable = false;
        this.isTnNotAbleToDetermine = false;
        this.isTnInAging = false;
        this.isTnMayBeAvailable = false;
        this.TnOrders = [];
        this.selectedAssessCharge = '';
        let manualReq: manualRequestReq = {
            transactionId: this.orderReferenceNumber,
            tnType: 'VOICE-HP',
            telephoneNumbers: []
        };
        if (this.additionalTnForm.get("line").value.length !== 4) {
            this.invalidLine = true;
            this.checkTnFlag = false;
            this.TNListLoading = false;
            return false;
        }
        let npa = this.additionalTnForm.get("npa").value;
        let nxx = this.additionalTnForm.get("nxx").value;
        let line = this.additionalTnForm.get("line").value;
        let telephoneNumber: telephoneNumber = {
            telephoneNumber: +(npa + '' + nxx + '' + line)
        };
        manualReq.telephoneNumbers.push(telephoneNumber);
        this.logger.log("info", "dialog.component.ts", "getPotsTnAvailabilityRequest", JSON.stringify(manualReq));
        this.logger.startTime();
        this.loading = true;
        this.productService
            .getPotsTnAvailability(manualReq)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getPotsTnAvailabilityResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "getPotsTnAvailabilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.ctlHelperService.setLocalStorage("error", error);
                this.invalidLine = false;
                this.checkTnFlag = false;
                this.TNListLoading = false;
                this.loading = false;
                return Observable.throw(error._body);
            })
            .subscribe(
                (data: checkPotsTnAvailabilityResponse) => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getPotsTnAvailabilityResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "getPotsTnAvailabilitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.invalidLine = false;
                    this.TNListLoading = false;
                    this.errorMsg = "";
                    data && data.tnStatus && data.tnStatus.map((tnStatus: tnStatus) => {
                        if (tnStatus.tn) {
                            this.tn = tnStatus.tn;
                        }
                        if ((tnStatus.isAgingTN === 'true') && (tnStatus.tnAvailabityStatus === 'Unavailable')) {
                            this.isTnAgingMore = true;
                            this.phoneSelectedFlag = false;
                        }
                        if ((tnStatus.isAgingTN === 'false') && (tnStatus.tnAvailabityStatus === 'Unavailable')) {
                            this.isWorkingTn = true;
                            this.phoneSelectedFlag = false;
                        }
                        if ((tnStatus.isAgingTN === 'false') && (tnStatus.tnAvailabityStatus === 'Available')) {
                            this.isTnAvailable = true;
                            this.selectedAssessCharge = 'Waive the charge';
                            this.phoneSelectedFlag = true;
                            this.selectedMoreTN = this.tn.replace(/-/g, "");
                        }
                        if ((tnStatus.isAgingTN === 'true') && (tnStatus.agingDurationinDays <= 60) && (tnStatus.tnAvailabityStatus === 'Available')) {
                            this.isTnInAging = true;
                            this.isTnAvailable = true;
                        }
                        //Option 8 for undetremined
                        if ((tnStatus.tnAvailabityStatus.toUpperCase() === 'UNDETERMINED') && (tnStatus.agingDurationinDays <= 60)) {
                            this.isTnNotAbleToDetermine = true;
                            this.isTnInAging = true;
                        }
                        //option 7 and 6 for unavailable - active cris account and pending account
                        if ((tnStatus.tnAvailabityStatus.toUpperCase() === 'UNAVAILABLE') && (tnStatus.agingDurationinDays <= 60)) {
                            this.isTnMayBeAvailable = true;
                            this.isTnInAging = true;
                            this.pendingTNs = [];
                            this.TnOrders = tnStatus.tnOrderAvailability.tnAvailabilityDetail;
                            for (let i = 0; i < this.TnOrders.length; i++) {
                                if (this.TnOrders[i] && this.TnOrders[i].sourceSystem && this.TnOrders[i].sourceSystem.toUpperCase() === "SIA" && this.TnOrders[i].pendingOrderDetails) {
                                    for (let j = 0; j < this.TnOrders[i].pendingOrderDetails.length; j++) {
                                        if (this.TnOrders[i].pendingOrderDetails && this.TnOrders[i].pendingOrderDetails[0].btn !== null && this.TnOrders[i].pendingOrderDetails[0].btn !== undefined) {
                                            this.crisBTN = this.TnOrders[i].pendingOrderDetails[j].btn;
                                        }
                                    }
                                } else if (this.TnOrders[i] && this.TnOrders[i].sourceSystem && this.TnOrders[i].sourceSystem.toUpperCase() !== "SIA" && this.TnOrders[i].pendingOrderDetails) {
                                    if (this.TnOrders[i].sourceSystem.toUpperCase() === "EDS") {
                                        for (let j = 0; j < this.TnOrders[i].pendingOrderDetails.length; j++) {
                                            if (this.TnOrders[i].pendingOrderDetails[0].mainTelephoneNumber === this.tn) {
                                                this.edsFlag = true;
                                            }
                                        }
                                    }
                                    for (let j = 0; j < this.TnOrders[i].pendingOrderDetails.length; j++) {
                                        if (this.TnOrders[i].pendingOrderDetails &&
                                            (this.TnOrders[i].pendingOrderDetails[0].customerOrderNumber !== null && this.TnOrders[i].pendingOrderDetails[0].customerOrderNumber !== undefined) ||
                                            (this.TnOrders[i].pendingOrderDetails[0].ban !== null && this.TnOrders[i].pendingOrderDetails[0].ban !== undefined) ||
                                            (this.TnOrders[i].pendingOrderDetails[0].btn !== null && this.TnOrders[i].pendingOrderDetails[0].btn !== undefined) ||
                                            (this.TnOrders[i].pendingOrderDetails[0].dueDate !== null && this.TnOrders[i].pendingOrderDetails[0].dueDate !== undefined)
                                        ) {
                                            this.pendingTNs.push(this.TnOrders[i].pendingOrderDetails[0]);
                                        }
                                    }
                                }
                            }
                        }
                    });
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getPotsTnAvailabilityResponse", error);
                    this.logger.log("error", "dialog.component.ts", "getPotsTnAvailabilityResponse", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.invalidLine = false;
                    this.TNListLoading = false;
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let errorArray = JSON.parse(error);
                    this.notAvailableTN = true;
                    this.phoneSelectedFlag = false;
                    this.errorMsg = errorArray.errorResponse[0].message;
                    this.systemErrorService.getAPIResponseError(error, 'INIT', 'dialog.component.ts', 'Customize Services Page');
                    window.scroll(0, 0);
                }
            );
    }
    public onSelectAssessCharge() {
        if (this.selectedAssessCharge === '') {
            this.phoneSelectedFlag = false;
        } else if (this.selectedAssessCharge === 'Waive the charge') {
            this.phoneSelectedFlag = true;
            this.selectedMoreTN = this.tn.replace(/-/g, "");
        } else if ((this.selectedAssessCharge === 'Custom Number') || (this.selectedAssessCharge === 'Same Number')) {
            this.store.dispatch({ type: 'SELECTED_ASSESS_CHARGE', payload: this.selectedAssessCharge })
            this.phoneSelectedFlag = true;
            this.selectedMoreTN = this.tn.replace(/-/g, "");
        }
    }
    public tnSelectedVal(tn) {
        this.phoneSelectedFlag = true;
        this.selectedMoreTN = tn["telephoneNumber"];
        this.pooledTNIndicatorValue = tn["pooledTNIndicator"];
    }
    public numberFormat(phnNo: string) {
        let newNo = phnNo && phnNo.split("-");
        if (newNo) {
            phnNo = newNo[0] + newNo[1] + newNo[2];
        }
        return phnNo;
    }
    public providerSelectedVal(carrier) {
        this.carrierSelectedFlag = true;
        this.selectedCarrier = carrier;
        this.portingAccountTnForm
            .get("carrierName")
            .setValue(carrier.resellerName + ": " + carrier.resellerSPID);
        this.portingAccountTnForm
            .get("billNameProvider")
            .setValue(this.carrierInfo.name);
    }
    public proceedToAccount() {
        this.proceedToAccountInfo = true;
    }
    public backToProviders() {
        this.proceedToAccountInfo = false;
        this.carrierSelectedFlag = false;
        this.selectedCarrier = undefined;
        this.portingAccountTnForm.get("carrierName").setValue("");
    }
    public assignCopy() {
        this.filteredItems = Object.assign([], this.carrierList);
    }
    public filterItem(value) {
        if (!value) this.assignCopy();
        this.filteredItems = Object.assign([], this.carrierList).filter(
            item => item.resellerName.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
    }
    public proceedWithPort() {
        if (this.portingAccountTnForm.valid) {
            this.notValidForm = false;
            if (this.addlOrderAttributesPorting) {
                let addlOrderAttributes: any;
                let groupName = this.addlOrderAttributesPorting[0].orderAttributeGroup[0];
                let orderAttributes = this.addlOrderAttributesPorting[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes;
                if (groupName.orderAttributeGroupName === "tnPortinInfo") {
                    addlOrderAttributes = orderAttributes.map(k => {
                        switch (k.orderAttributeName) {
                            case "telephoneNumber":
                                k.orderAttributeValue = this.telephoneNumber;
                                return k;
                            case "accessPIN":
                                k.orderAttributeValue = this.portingAccountTnForm.get("accessPin").value || "";
                                return k;
                            case "carrierName":
                                k.orderAttributeValue = this.selectedCarrier.resellerName;
                                return k;
                            case "carrierSpid":
                                k.orderAttributeValue = this.selectedCarrier.resellerSPID;
                                return k;
                            case "providerAccountNumber":
                                k.orderAttributeValue = this.portingAccountTnForm.get("accountNo").value || "";
                                return k;
                            case "accountName":
                                k.orderAttributeValue = this.portingAccountTnForm.get("billNameProvider").value || "";
                                return k;
                            case "streetNumber":
                                k.orderAttributeValue = this.portingAccountTnForm.get("streetNumber").value || "";
                                return k;
                            case "streetName":
                                k.orderAttributeValue = this.portingAccountTnForm.get("streetName").value || "";
                                return k;
                            case "city":
                                k.orderAttributeValue = this.portingAccountTnForm.get("city").value || "";
                                return k;
                            case "state":
                                k.orderAttributeValue = this.portingAccountTnForm.get("state").value || "";
                                return k;
                            case "zipCode":
                                k.orderAttributeValue = this.portingAccountTnForm.get("zipCode").value || "";
                                return k;
                        }
                    });
                }
                this.addlOrderAttributesPorting[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes = addlOrderAttributes;
                this.addlOrderAttributes.emit(this.addlOrderAttributesPorting);
            }
            let portingAccountDetails = {
                carrierName: this.portingAccountTnForm.get("carrierName").value,
                accessPin: this.portingAccountTnForm.get("accessPin").value || "",
                accountNumber: this.portingAccountTnForm.get("accountNo").value || "",
                accountName: this.portingAccountTnForm.get("billNameProvider").value || "",
                streetNumber: this.portingAccountTnForm.get("streetNumber").value || "",
                streetName: this.portingAccountTnForm.get("streetName").value || "",
                city: this.portingAccountTnForm.get("city").value || "",
                state: this.portingAccountTnForm.get("state").value || "",
                zipCode: this.portingAccountTnForm.get("zipCode").value || ""
            };
            this.portingAccountDetails.emit(portingAccountDetails);
            this.close(true);
        } else {
            this.notValidForm = true;
        }
    }
    public callRetrieveOffer() {
        this.callRetOffer.emit(this.e911Response);
        this.close(true);
    }
    public paymentCallback(callbackParam) {
        this.paymentCallbackInvoked = true;
        var vars = callbackParam.split("&");
        var session;
        let paymentStatus;
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] === "status") {
                paymentStatus = pair[1];
            }
            if (pair[0] === "PaymentID") {
                session = pair[1];
                this.displayPaySucBtn = null;
            } else if (session === undefined && pair[0] === "ErrorCode") {
                this.displayPaySucBtn = false;
                session = pair[1];
                this.close(true);
            } else if (pair[0] === "success") {
                this.displayPaySucBtn = true;
            }
        }
        this.updateAccount.emit({
            error: paymentStatus,
            sessionId: session,
            isDepositCallback: this.paymentObj.isDepositModal,
            paymentStatus: paymentStatus,
            invokeCall: this.invokeCall
        });
        this.close(true);
    }
    public getURL(url: string) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
    public multiDate(date: any) {
        let muDate: Date;
        muDate = date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
        muDate.setDate(muDate.getDate());
        return muDate;
    }
    //determine which service address dialog or billing records correction dialog
    public multipleChoice() {
        if (this.multiplePending && this.multiplePending > 1) {
            this.invokeCall = "Billing Records Correction";
        }
        this.close(true);
    }
    //when Billing Records Correction dialog selected and moved to service address dialog
    public moveToSeriveAddress() {
        this.title = "Service Address";
        this.invokeCall = 'Service Address';
        this.open();
    }
    public close(flag?: boolean) {
        if (flag) {
            this.otcTotal = 0;
            if (this.invokeCall === "Pay Deposit") {
                window["angularComponentRef"] = {
                    zone: this.zone,
                    componentFn: value => "",
                    component: this
                };
            }
            this.enable = false;
            this.visible = false;
            this.viewAllCarriers = true;
            this.viewSelectedCarriers = false;
            if (!this.updatedAllLdCarriers) {
                this.selectedListCarriers = [];
                this.lbBLockContinueButtonActive = false;
                this.allRestoreCarriersSelected = false;
                this.saveupdatesSelected.emit(false);
            }
            if (!this.paymentCallbackInvoked && this.invokeCall === "Pay Deposit") {
                this.updateAccount.emit({
                    error: "Cancelled",
                    sessionId: "",
                    isDepositCallback: this.paymentObj.isDepositModal,
                    paymentStatus: "Cancelled",
                    invokeCall: this.invokeCall
                });
            }
            this.removeSelectedReason = undefined;
            if (this.fromPOReview === "true") {
                this.router.navigate(["/pending-schedule-appt"]);
            }
        } else {
            this.enable = true;
            this.visible = true;
        }
        if ((this.invokeCall === "Cancel Order Deposit" || this.invokeCall === 'Deposit Address') && this.showDepositPage && this.hideReasonDiv) {
            this.invokeCall = "Cancel Order Deposit";
            this.showDepositPage = false;
            this.hideReasonDiv = false;
        }
        if ((this.invokeCall === 'Continue opus') && this.opusCancelFlag) {
            this.title = "Please Confirm";
            this.invokeCall = "Cancel Order No Reason NI";
            this.cancelBack = "Back to Configuration";
            this.opusCancelFlag = false;
        }
        if (this.invokeCall === 'Order Disclosures') {
            this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: null });
        }
    }

    public amountShownRemove(flag) {
        if (this.removedProduct && this.removedProduct.productType !== undefined && this.depositHistory && this.depositHistory.depositInfo !== null && this.depositHistory.depositInfo !== undefined) {
            for (let i = 0; i < this.depositHistory.depositInfo.length; i++) {
                if (this.removedProduct.productType === this.depositHistory.depositInfo[i].productType) {
                    this.amountShown = this.depositHistory.depositInfo[i].amountPaid;
                }
            }
            if (flag && this.amountShown) {
                return this.amountShown;
            }
        }
    }
    public amountShownRemoveReturn(): any {
        if (this.removedProduct && this.removedProduct.productType !== undefined && this.depositHistory && this.depositHistory.depositInfo !== null && this.depositHistory.depositInfo !== undefined) {
            for (let i = 0; i < this.depositHistory.depositInfo.length; i++) {
                if (this.removedProduct.productType === this.depositHistory.depositInfo[i].productType) {
                    return this.removedProduct.productType;
                }
            }
        }
    }

    public open(orderRefNumber?) {
        this.ngOnInit();
        if (this.invokeCall === "Pay Deposit") {
            window["angularComponentRef"] = {
                zone: this.zone,
                componentFn: value => this.paymentCallback(value),
                component: this
            };
        }
        this.enable = true;
        this.visible = true;
        if (this.invokeCall === "e911 Address Validation") {
            this.loading = true;
            this.getE911Response();
        }
        if (this.invokeCall === "Move Service") {
            this.success = false;
            this.initLoad = true;
            this.addressLineShow = false;
            this.errorMsg = "";
            this.workingService = false;
            if (this.apiResponseError && this.apiResponseError.errorResponse) {
                this.apiResponseError.errorResponse[0].messageDetail = "";
            }
        }
        if (this.invokeCall === "Billing Records Correction") {
            this.success = false;
            this.store.dispatch({ type: "ORDER_FlOW", payload: { flow: "billing" } });
        }
        if (this.invokeCall === "Additional TNs") {
            this.getNpaNxxList();
            this.resetTns();
            this.TNQuery = "Specific";
        }
        if (this.invokeCall === "Cannot cancel the Order") {
            this.title = "Order can no longer be cancelled";
        }
        if (this.invokeCall === "PONR true cancel" || this.invokeCall === "PONR true hold" || this.invokeCall === "PONR true schedule") {
            if (this.portedTNExists) {
                this.title = "Contact Winback team for order changes";
            }
        }
        if (this.invokeCall === 'PONR true submitOrder') {
            if (this.PONRChanged) {
                this.title = "Unable to Submit Order";
            }
        }
        if (this.invokeCall === "OTC installment") {
            this.getOtcRelatedData();
        }
        if (this.invokeCall === "Place on Hold") {
            this.loading = true;
            this.getReasonsForHoldDetails();
        }
        if (this.invokeCall === "Cancel Order No Reason") {
            this.getReasonsForCancelDetails();
        }
        if (this.invokeCall === "Cancel Order Discard Pending" || this.invokeCall === "Cancel Order Discard") {
            this.getReasonsForCancelDetails();
        }
        if (this.invokeCall === "tn_submit_account" && this.carrierList) {
            this.filteredItems = this.carrierList;
            this.backToProviders();
            this.portingAccountTnForm.reset();
        }
        if (this.invokeCall === "Unhold Order") {
            this.getReasonsForUnHoldOrder();
        }
        if (this.invokeCall === "Remove From Hold") {
            this.getReasonsForUnHoldOrder();
        }
        if (this.invokeCall === "Move Service") {
            this.store.dispatch({ type: "ORDER_FlOW", payload: { flow: "Move" } });
        }
        this.errorText = "";
        this.setDataForOTC();
        if (this.invokeCall === "Listed Address") {
            this.cityList = [];
            this.statesList = [];
            this.statesCityList = [];
            this.fetchCommunityRules();
        }
        if (this.invokeCall === "Continue opus") {
            this.getVenderLocations(this.orderReferenceNumber ? this.orderReferenceNumber : orderRefNumber);
        }
        if (this.invokeCall === "SUP On Hold") {
            this.getReasonsForSUPHold();
        }
        if (this.invokeCall === "Review RCCs") {
            if (this.reviewOrder && this.reviewOrder.rccDetails.errorResponse === undefined && this.reviewOrder.rccDetails) {
                if (this.reviewOrder.rccDetails.rccGroup[0].rccGroupName.toUpperCase() === "CALL COMPONENTS") {
                    this.isRccErrorFound = false;
                    this.rccDetails = this.reviewOrder.rccDetails;
                }
            }
            if (this.reviewOrder && this.reviewOrder.rccDetails.errorResponse !== undefined && this.reviewOrder.rccDetails) {
                if (this.reviewOrder.rccDetails.rccGroup[0].rccGroupName.toUpperCase() === "CALL COMPONENTS") {
                    this.isRccErrorFound = true;
                    this.rccErrorMessage = this.reviewOrder.rccDetails.errorResponse[0].messageDetail;
                    this.rccDetails = this.reviewOrder.rccDetails;
                }
            }
        }
        if (this.invokeCall === "LD_Freeze") {
            if (this.inputData) {
                this.setDataForFreeze();
            }
        }
        if (this.invokeCall === "Cancel Order Deposit") {
            if ((this.currUrl === "/account" || this.currUrl === "/review-order") && !this.fromHold) {
                this.loading = true;
                this.logger.log("info", "dialog.component.ts", "retrieveSecurityDepositHistoryRequest", JSON.stringify(this.ban));
                this.logger.startTime();
                this.pendingOrderService.getSecurityDepositHistory(this.ban)
                    .catch((error: any) => {
                        this.logger.endTime()
                        this.logger.log("error", "dialog.component.ts", "retrieveSecurityDepositHistoryResponse", JSON.stringify(error));
                        this.logger.log("error", "dialog.component.ts", "retrieveSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "retrieveSecurityDepositHistoryCall", "dialog.component.ts", "Retrieve deposit popup", error);
                        return Observable.throwError(null);
                    })
                    .subscribe((data) => {
                        this.logger.endTime()
                        this.logger.log("info", "dialog.component.ts", "retrieveSecurityDepositHistoryResponse", JSON.stringify(data));
                        this.logger.log("info", "dialog.component.ts", "retrieveSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        if (data && data.depositInfo && data.depositInfo.length > 0) {
                            this.depositAmount = this.getDepositmount(data.depositInfo, null);
                            this.showDepositPage = true;
                            this.hideReasonDiv = true;
                            this.callCancelBeforeSubmit = true;
                            this.store.dispatch({ type: 'SECURITY_DEPOSIT', payload: { deposit: data } });
                        }
                    },
                        (error) => {
                            this.logger.endTime()
                            this.logger.log("error", "dialog.component.ts", "retrieveSecurityDepositHistoryResponse", JSON.stringify(error));
                            this.logger.log("error", "dialog.component.ts", "retrieveSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.loading = false;
                            if (error === undefined || error === null)
                                return;
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "dialog.component.ts", "Retrieve deposit popup", this.apiResponseError);
                            } else {
                                let errorResponseArray: ErrorResponse[] = [];
                                let localErrorResponse: ErrorResponse = {
                                    orderRefNumber: error.payload.orderReferenceNumber,
                                    statusCode: serverErrorMessages.statusCode,
                                    reasonCode: serverErrorMessages.statusCode,
                                    message: serverErrorMessages.serverDownSchedule01,
                                    messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                                    serverDown: serverErrorMessages.serverDown
                                }
                                errorResponseArray.unshift(localErrorResponse);
                                let lAPIErrorLists: APIErrorLists = {
                                    errorResponse: errorResponseArray
                                };
                                this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "dialog.component.ts", "Retrieve deposit popup", lAPIErrorLists);
                            }
                            window.scroll(0, 0);
                        })
            } else if (this.fromHold) {
                this.cancelOrderSubscription = this.cancelorderObservable.subscribe(pending => {
                    if (pending && pending.orderDocument && pending.orderDocument.creditReview && pending.orderDocument.creditReview.depositInfo &&
                        pending.orderDocument.creditReview.depositInfo.depositRequired) {
                        if(pending.orderDocument.creditReview.paymentInfo[0] && pending.orderDocument.creditReview.paymentInfo[0].paidAmount) { 
                            this.depositAmount = pending.orderDocument.creditReview.paymentInfo[0].paidAmount; 
                        }
                        this.showDepositPage = true;
                        this.hideReasonDiv = true;
                        this.callCancelBeforeSubmit = true;
                    }
                });
            }
        }
        if (this.invokeCall === "Cancel Prepaid Order Deposit") {
            if ((this.currUrl === "/account" || this.currUrl === "/review-order") && !this.fromHold) {
                this.fromNIPrepaid = true;
                this.hideReasonDiv = true;
            }
        }
        if (this.invokeCall === "Waive OTC") {
            if (this.retainWaivedReason) {
                this.waivedReason = this.retainWaivedReason.code;
            } else {
                this.waivedReason = undefined;
            }
            this.adjustableOtcProducts = cloneDeep(this.waivableOTC);
            this.updateOtcSelection();
        }
    }
    public fetchCommunityRules() {
        this.loadingCommunityData = true;
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "communityserviceRequest", JSON.stringify(""));
        this.logger.startTime();
        this.productService
            .getCommunityRules()
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "communityserviceResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "communityServiceSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "SUBMIT_TASK", "dialog.component.ts", "Dialog Component Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "communityserviceResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "communityServiceSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.communityResponse = data;
                    this.streetDirections = [];
                    this.streetSuffixes = [];
                    this.communityStates = [];
                    this.statesList = [];
                    if (this.communityResponse && this.communityResponse.outputAttribute) {
                        this.communityResponse.outputAttribute.map(output => {
                            if (output[0] === "STREET_DIRECTION") {
                                this.streetDirections.push({ display: output[1] + "-" + output[2], code: output[1] });
                            }
                            if (output[0] === "STREET_SUFFIX") {
                                this.streetSuffixes.push({ display: output[3] + "-" + output[4], code: output[3] });
                            }
                            if (output[0] === "STATE_COMMUNITY") {
                                this.communityStates.push({ state: output[5], city: output[6] });
                            }
                        });
                        this.statesCityList = groupBy(this.communityStates, s => s.state);
                        this.statesList = keys(this.statesCityList);
                    }
                    //initializing as per service address
                    if (this.updatedListedAddressInput) {
                        this.listedAdressInitialize(this.updatedListedAddressInput);
                    } else if (this.addressListing) {
                        this.listedAdressInitialize(this.addressListing);
                    }
                    if (this.selectedListedType === "List Community Only") {
                        this.listedAddressUpdateForm.get("streetNrFirst").setValue("");
                        this.listedAddressUpdateForm.get("streetName").setValue("");
                        this.listedAddressUpdateForm.get("streetType").setValue("");
                        this.listedAddressUpdateForm.get("streetNamePrefix").setValue("");
                    }
                    this.loadingCommunityData = false;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "communityserviceResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "communityServiceSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.loadingCommunityData = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "customizeServiceResponseError", "customize-services.component.ts", "CustomizeService Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    private listedAdressInitialize(addressInput) {
        this.listedAddressUpdateForm.get("streetNrFirst").setValue(addressInput.streetNrFirst);
        this.listedAddressUpdateForm.get("streetName").setValue(addressInput.streetName);
        if (addressInput.stateOrProvince) {
            this.listedAddressUpdateForm.get("state").setValue(addressInput.stateOrProvince);
        } else if (addressInput.state) {
            this.listedAddressUpdateForm.get("state").setValue(addressInput.state);
        }
        this.listedAddressUpdateForm.get("city").setValue(addressInput.city.toLowerCase().split(" ").map(w => { return w.replace(w[0], w[0].toUpperCase()); }).join(" "));
        this.listedAddressUpdateForm.get("postCode").setValue(addressInput.postCode);
    }
    public checkPayType() {
        if (this.isOtcSelected === "no") {
            this.setDataForOTC();
            this.getOtcRelatedData();
        } else {
            this.setDataForOTC();
        }
    }
    /**
     * To calculate the otc total and to show on screen
     */
    public getOtcRelatedData() {
        this.otcTotal = 0;
        this.otcCart = [];
        let otcData1: ShoppingCart;
        otcData1 = {
            Otc: []
        };
        this.clonedOtcData = JSON.parse(JSON.stringify(this.otcData));
        this.otcData && this.otcData[0] && this.otcData[0].orderAttributeGroup && this.otcData[0].orderAttributeGroup.map(group => {
            let otcData = group;
            if (otcData.orderAttributeGroupName === "otcInstallmentInfo") {
                this.otcResponse1 = otcData.orderAttributeGroupInfo;
                for (let i = 0; i < this.otcResponse1.length; i++) {
                    let data = this.otcResponse1;
                    let prodName;
                    let totalOtcAmount;
                    let otcCart: OTCcart;
                    otcCart = {
                        name: "",
                        max: "",
                        price: "",
                        selected: "",
                        quantity: ""
                    };
                    for (let j = 0; j < data[i].orderAttributes.length; j++) {
                        let name = data[i].orderAttributes[j].orderAttributeName;
                        let value = data[i].orderAttributes[j].orderAttributeValue;
                        switch (name) {
                            case "productName": {
                                let item = data[i];
                                let isFound = false;
                                for (let k = 0; k < item.orderAttributes.length; k++) {
                                    if (item.orderAttributes[k].orderAttributeName === "productName" && item.orderAttributes[k].orderAttributeValue === value) {
                                        isFound = true;
                                    }
                                    if (isFound) {
                                        if (item.orderAttributes[k].orderAttributeName === "totalOtcAmount") {
                                            totalOtcAmount = +item.orderAttributes[k]
                                                .orderAttributeValue;
                                            break;
                                        }
                                    }
                                }
                                prodName = data[i].orderAttributes[j].orderAttributeValue;
                                otcCart.name = data[i].orderAttributes[j].orderAttributeValue;
                                break;
                            }
                            case "otcAmount": {
                                data[i].orderAttributes[j].orderAttributeValue = totalOtcAmount;
                                otcCart.price = data[i].orderAttributes[j].orderAttributeValue;
                                break;
                            }
                            case "maxNoOfInstallment": {
                                otcCart.max = data[i].orderAttributes[j].orderAttributeValue;
                                break;
                            }
                            case "selectedNoOfInstallment": {
                                let selected = data[i].orderAttributes[j].orderAttributeValue;
                                if (selected === "" || selected !== "") {
                                    otcCart.selected = "1";
                                    data[i].orderAttributes[j].orderAttributeValue = totalOtcAmount.toString();
                                }
                                this.otcTotal += totalOtcAmount;
                                break;
                            }
                            case "quantity": {
                                otcCart.max = data[i].orderAttributes[j].orderAttributeValue;
                                break;
                            }
                        }
                    }
                    this.otcCart.push(otcCart);
                    this.otcResponse1 = data;
                }
            }
        });
    }
    public saveUpdates() {
        this.otcTotal = 0;
        if (this.isOtcSelected === "yes") {
            let _that = this;
            _that.clonedOtcData && _that.clonedOtcData[0] && _that.clonedOtcData[0].orderAttributeGroup && _that.clonedOtcData[0].orderAttributeGroup.map(group => {
                if (group.orderAttributeGroupName === "otcInstallmentInfo") {
                    let data: any[] = group.orderAttributeGroupInfo;
                    for (let i = 0; i < data.length; i++) {
                        for (let j = 0; j < data[i].orderAttributes.length; j++) {
                            let name = data[i].orderAttributes[j].orderAttributeName;
                            switch (name) {
                                case "productName": {
                                    break;
                                }
                                case "otcAmount": {
                                    break;
                                }
                                case "maxNoOfInstallment": {
                                    break;
                                }
                                case "selectedNoOfInstallment": {
                                    let selected =
                                        group.orderAttributeGroupInfo[i].orderAttributes[j].orderAttributeValue;
                                    if (selected === "") {
                                        group.orderAttributeGroupInfo[i].orderAttributes[j].orderAttributeValue = "1";
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            });
            let otcData: ShoppingCart;
            otcData = {
                Otc: this.otcCart
            };
            this.store.dispatch({ type: "CREATE_CART", payload: otcData });
            this.otcDataUpdated.emit(_that.clonedOtcData);
            this.accountService.getOtcData(_that.clonedOtcData);
            this.store.dispatch({ type: 'INSTALL_AVAIL', payload: true });
        } else {
            let otcData: ShoppingCart;
            otcData = {
                Otc: []
            };
            this.store.dispatch({ type: "CREATE_CART", payload: otcData });
            this.store.dispatch({ type: 'INSTALL_AVAIL', payload: false });
        }
        this.enable = false;
        this.visible = false;
    }
    public checkPay(sdata, selectedobj) {
        let payloadArray: any = [];
        let originalPayloadArray: any = [];
        let retainVal = <Observable<any>>this.store.select("retain");
        let retSubscribe = retainVal.subscribe(retVal => {
            if (retVal && retVal.otcinfo && retVal.otcinfo.payload) {
                payloadArray = retVal.otcinfo.payload;
                originalPayloadArray = retVal.otcinfo.payload;
                let exists = false;
                payloadArray.map(payload => {
                    if (payload.otc === selectedobj) {
                        exists = true;
                        payload.value = sdata;
                    }
                });
                if (!exists) {
                    payloadArray.push({ otc: selectedobj, value: sdata });
                }
            } else {
                payloadArray.push({ otc: selectedobj, value: sdata });
            }
        });
        retSubscribe.unsubscribe();
        let pay = sdata.indexOf("payment");
        let max = sdata.substring(0, pay);
        if (max) max = max.trim();
        let selectedProdName;
        let _that = this;
        _that.clonedOtcData && _that.clonedOtcData[0] && _that.clonedOtcData[0].orderAttributeGroup && _that.clonedOtcData[0].orderAttributeGroup.map(group => {
            if (group && group.orderAttributeGroupName === 'otcInstallmentInfo') {
                let data: any[] = group.orderAttributeGroupInfo;
                selectedobj.orderAttributes.map(x => {
                    if (x.orderAttributeName === "productName") {
                        selectedProdName = x.orderAttributeValue;
                        _that.otcCart = _that.otcCart.filter(y => {
                            return y.name !== selectedProdName;
                        });
                    }
                    if (x.orderAttributeName === "otcAmount") {
                        _that.payOtcAmount = +x.orderAttributeValue / +max;
                    } else if (x.orderAttributeName === "selectedNoOfInstallment") {
                        let prodname, name;
                        let otcCart: OTCcart;
                        otcCart = {
                            name: "",
                            max: "",
                            price: "",
                            selected: "",
                            quantity: ""
                        };
                        for (let i = 0; i < data.length; i++) {
                            for (let j = 0; j < data[i].orderAttributes.length; j++) {
                                name = data[i].orderAttributes[j].orderAttributeName;
                                if (name === "productName") {
                                    prodname = data[i].orderAttributes[j].orderAttributeValue;
                                }
                                if (prodname === selectedProdName) {
                                    switch (name) {
                                        case "productName": {
                                            otcCart.name = data[i].orderAttributes[j].orderAttributeValue;
                                            break;
                                        }
                                        case "otcAmount": {
                                            break;
                                        }
                                        case "maxNoOfInstallment": {
                                            otcCart.max = data[i].orderAttributes[j].orderAttributeValue;
                                            break;
                                        }
                                        case "selectedNoOfInstallment": {
                                            otcCart.selected = max.toString();
                                            group.orderAttributeGroupInfo[i].orderAttributes[j].orderAttributeValue = max.toString();
                                            break;
                                        }
                                        case "quantity": {
                                            otcCart.quantity = data[i].orderAttributes[j].orderAttributeValue;
                                            break;
                                        }
                                    }
                                }
                            }
                            let a = x.orderAttributeValue;
                            _that.otcTotal -= +a;
                            x.orderAttributeValue = _that.payOtcAmount.toString();
                            otcCart.price = _that.payOtcAmount;
                            _that.otcTotal += +x.orderAttributeValue;
                        }
                        this.otcCart.push(otcCart);
                    }
                });
            }
        });
        if (originalPayloadArray && payloadArray && JSON.stringify(originalPayloadArray) !== JSON.stringify(payloadArray)) {
            this.store.dispatch({ type: "OTCINFO", payload: payloadArray });
        }
    }
    public noOfPayment(data) {
        let paymentArr: any = [];
        let payment;
        for (let k = 1; k <= +data; k++) {
            if (k === 1) {
                payment = k + " " + "payment";
                paymentArr.push(payment);
            } else if (k > 1) {
                payment = k + " " + "payments";
                paymentArr.push(payment);
            }
        }
        return paymentArr;
    }
    public checkAddrsType(event: any) {
        this.isCheckedStatus = event.target.value;
    }
    public getE911Response() {
        this.logger.log("info", "offer.component.ts", "getE911Request", JSON.stringify(""));
        this.logger.startTime();
        this.loading = true;
        this.productService
            .getE911Response()
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer.component.ts", "getE911Response", JSON.stringify(error));
                this.logger.log("error", "offer.component.ts", "getE911Srvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "offer.component.ts", "getE911Response", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "offer.component.ts", "getE911Srvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.e911Response = data;
                    if (data && data !== undefined && data !== null && data.msagData.length >= 1) {
                        this.e911ValidatedAddress = data.msagData[0];
                        this.loading = false;
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "offer.component.ts", "getE911Response", JSON.stringify(error));
                    this.logger.log("error", "offer.component.ts", "getE911Srvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    let e911RequestAddress = <Observable<any>>this.store.select("user");
                    let e911AddressRequest;
                    e911RequestAddress.subscribe(data => {
                        e911AddressRequest = data.e911AddressRequest;
                    });
                    this.e911Response = {
                        continuationParams: null,
                        msagData: [
                            {
                                streetDirectionPrefix: e911AddressRequest.streetDirectionPrefix,
                                streetAddress: e911AddressRequest.streetAddress,
                                streetNrFirst: e911AddressRequest.streetNrFirst,
                                location: "",
                                city: e911AddressRequest.city,
                                stateOrProvince: e911AddressRequest.stateOrProvince,
                                countyId: "",
                                postCode: e911AddressRequest.postCode,
                                postCodeSuffix: "",
                                streetKey: "",
                                msagRangeList: [
                                    {
                                        lowRange: "0000000100",
                                        highRange: "0000001099",
                                        emergencyServiceNumber: "00105",
                                        specialReactionTeam: "",
                                        oddEvenIndicator: ""
                                    }
                                ]
                            }
                        ],
                        moreRecordsAvailable: false,
                        correlationId: "4a75a2d98d3f46c3a7f2d8f46c7f7f51",
                        message: "Address may have been modified. Please verify."
                    };
                    this.e911ValidatedAddress = this.e911Response.msagData[0];
                }
            );
    }
    public getNpaNxxList() {
        this.npanxxList = [];
        this.npaList = [];
        this.TNCallHappening = true;
        let NPANXXListRequest: any = {};
        if (this.reqTNType !== "PORTED") {
            NPANXXListRequest = {
                orderReferenceNumber: this.orderReferenceNumber ? this.orderReferenceNumber : "",
                productType: this.productType && this.productType === "dhp" ? "VOICE-DHP" : this.productType && this.productType === "hp" ? "VOICE-HP" : "",
                city: this.reqCity,
                state: this.reqState,
                wireCenter: this.wirecenter,
                tnType: this.reqTNType
            };
        } else {
            NPANXXListRequest = {
                orderReferenceNumber: this.orderReferenceNumber ? this.orderReferenceNumber : "",
                productType: this.productType && this.productType === "dhp" ? "VOICE-DHP" : this.productType && this.productType === "hp" ? "VOICE-HP" : ""
            };
        }
        this.loading = true;
        this.logger.log("info", "offer.component.ts", "getNPANXXListRequest", JSON.stringify(NPANXXListRequest));
        this.logger.startTime();
        this.productService
            .getNPANXXList(NPANXXListRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer.component.ts", "getNPANXXListResponse", JSON.stringify(error));
                this.logger.log("error", "offer.component.ts", "getNPANXXListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.invalidRange = false;
                return Observable.throw(error);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "offer.component.ts", "getNPANXXListResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "offer.component.ts", "getNPANXXListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.npanxxList = data.npaNxxList ? data.npaNxxList : "";
                    this.npanxxList = groupBy(this.npanxxList, obj => obj.npa.code);
                    this.npaList = keys(this.npanxxList);
                    this.TNCallHappening = false;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "offer.component.ts", "getNPANXXListResponse", JSON.stringify(error));
                    this.logger.log("error", "offer.component.ts", "getNPANXXListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.TNCallHappening = false;
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (
                            this.apiResponseError !== undefined &&
                            this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0
                        ) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "getNPANXXListCall", "dialog.component.ts", "getNPANXXListCallResponse", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "getNPANXXListCall", "dialog.component.ts", "getNPANXXListCallResponse", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public sendValue(agree: boolean) {
        this.enable = false;
        this.tncValue.emit(agree);
        this.visible = false;
    }
    public enableButton(checked) {
        this.enable = checked;
    }
    public initDisconnect(depositHistory?) {
        this.loading = true;
        if (!this.displayDeposit && depositHistory && depositHistory.depositInfo && depositHistory.depositInfo.length > 0) {
            this.displayDeposit = true;
        } else {
            this.logger.log("info", "offer.component.ts", "initDisconnectRequest", JSON.stringify(this.disconnectReq));
            this.logger.startTime();
            this.displayDeposit = false;
            this.disconnectedHSI = true;
            let req = JSON.parse(this.disconnectReq);
            req.ban = this.ban;
            this.disconnectServiceCall.isSchedulingReEntrant = false;
            this.disconnectServiceCall

                .initDisconnect(req)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer.component.ts", "initDisconnectResponse", error);
                    this.logger.log("error", "offer.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.ctlHelperService.setLocalStorage("error", error);
                    return Observable.throw(error._body);
                })
                .subscribe(
                    data => {
                        this.logger.endTime();
                        this.logger.log("info", "offer.component.ts", "initDisconnectResponse", JSON.stringify(data ? data : ""));
                        this.logger.log("info", "offer.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        this.loading = false;
                        this.disconnectResponseData = data;
                        this.toDisconnectFLow(data);
                    },
                    error => {
                        this.logger.endTime();
                        this.logger.log("error", "offer.component.ts", "initDisconnectResponse", error);
                        this.logger.log("error", "offer.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        this.loading = false;
                        this.disconnectedHSI = false;
                        if (error === undefined || error === null) return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (
                                this.apiResponseError !== undefined &&
                                this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse &&
                                this.apiResponseError.errorResponse.length > 0
                            ) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Init Call - Disconnect", "existing-products.component.ts", "disconnectInitSrvcCallResponse", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Init Call - Disconnect", "existing-products.component.ts", "disconnectInitSrvcCallResponse", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    }
                );
        }
    }
    private getDepositmount(depositInfo, servicestatus) {
        let depositAmt = 0;
        let pendingServices;
        let pendingItems = [];
        if (servicestatus !== null) {
            pendingServices = servicestatus.filter(service => {
                return service.statusInfo[0].isComplete;
            });
            depositInfo.forEach(deposit => {
                if (!pendingServices.some(item => item.productType === deposit.productType)) {
                    pendingItems.push(deposit);
                }
            });
        } else {
            pendingItems = depositInfo;
        }
        pendingItems.forEach(item => {
            depositAmt += item.amountPaid;
        });
        this.pendingOrderService.getDepositAmount(depositAmt);
        return depositAmt;
    }
    public toDisconnectFLow(data) {
        this.disconnectedHSI = true;
        let services = [
            {
                offerCategory: data.payload.disconnectInfo[0].offerCategory,
                reasonType: this.removeSelectedReason && this.removeSelectedReason.rsnType ? this.removeSelectedReason.rsnType : "",
                reasonText: null,
                reasonList: [
                    {
                        code: this.removeSelectedReason && this.removeSelectedReason.rsnCode ? this.removeSelectedReason.rsnCode : "",
                        description: this.removeSelectedReason && this.removeSelectedReason.chgDesc ? this.removeSelectedReason.chgDesc : "",
                        waiverFlag: "No"
                    }
                ],
                etfInfo: {
                    terminationFee: "0",
                    currencyCode: "USD",
                    contractExpiryDate: null
                }
            }
        ];
        let apiRequest = {
            orderRefNumber: data.orderRefNumber,
            processInstanceId: data.processInstanceId,
            taskId: data.taskId,
            taskName: data.taskName,
            payload: {
                disconnectInfo: services
            }
        };
        this.loading = true;
        this.logger.log("info", "offer.component.ts", "submitInformationRequest", JSON.stringify(apiRequest));
        this.logger.startTime();
        this.disconnectServiceCall
            .submitInformation(apiRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer.component.ts", "submitInformationResponse", error);
                this.logger.log("error", "offer.component.ts", "submitInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "offer.component.ts", "submitInformationResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "offer.component.ts", "submitInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.disconnectedHSI = false;
                    let payload: ShoppingCart;
                    payload = {};
                    this.store.dispatch({ type: "FLUSH_CART", payload: payload });
                    let terminationFee = [];
                    terminationFee.push({
                        description: "Internet Early Termination Fee",
                        price: 0
                    });
                    let cartObj: ShoppingCart = {
                        terminationFee: terminationFee
                    };
                    this.store.dispatch({ type: "CREATE_CART", payload: cartObj });
                    this.store.dispatch({ type: "SCHEDULE_SHIPPING", payload: data });
                    this.store.dispatch({ type: "TASK_ID", payload: data.taskId });
                    this.router.navigate(["/disconnect-schedule"]);
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "offer.component.ts", "submitInformationResponse", error);
                    this.logger.log("error", "offer.component.ts", "submitInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.disconnectedHSI = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Disconnect", "dialog.component.ts", "disconnectCallSubmitInfoResponse", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Disconnect", "dialog.component.ts", "disconnectCallSubmitInfoResponse", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public continueWithRemove(remove, removeSelected, removeSubType?, depositHistory?) {
        let byPassforNI = this.displayDeposit;
        this.errorText = "";
        if ((removeSelected === "" || removeSelected === undefined) && !this.displayDeposit) {
            this.errorText = "Please select reason for Removal";
        } else {
            if (!this.displayDeposit && depositHistory && depositHistory.depositInfo && depositHistory.depositInfo.length > 0 && this.amountShownRemove(true)) {
                this.displayDeposit = true;
            } else {
                this.displayDeposit = false;
                if (removeSelected || byPassforNI) {
                    let removeObject = {
                        type: remove,
                        removeReason: removeSelected,
                        subType: removeSubType
                    };
                    this.removeClicked.emit(removeObject);
                    this.removeSelectedReason = undefined;
                    this.close(true);
                } else if (this.isRemoveInternet && this.isRemoveInternet === "Keep Internet") {
                    this.errorText = "";
                    this.close(true);
                } else {
                    this.errorText = "Please select reason for Removal";
                }
            }
        }
    }
    public reasonsRemoveSelected(sel) {
        if (this.reasonsRemove !== undefined && sel !== undefined && sel !== "Choose reason ...") {
            this.reasonsRemove.map(item => {
                if (item.chgDesc.replace(/\s/g, "").toUpperCase() === sel.replace(/\s/g, "").toUpperCase()) {
                    this.removeSelectedReason = item;
                }
            });
        } else {
            this.removeSelectedReason = undefined;
        }
    }
    public isReasonSelected() {
        if (this.removeSelectedReason) {
            return false;
        } else {
            return true;
        }
    }
    public continueClicked(disConDpstHistory?) {
        this.errorText = "";
        if (this.invokeCall === "Disconnect All") {
            let services: any[] = [];
            if (this.disconnectHSIService && this.internetSelectedReason && this.internetSelectedReason !== "Choose reason ...") {
                let service = {
                    offerCategory: this.disconnectHSIService.offerCategory,
                    etfInfo: this.disconnectHSIService.etfInfo,
                    reasonType: this.disconnectHSIService.reasonType,
                    reasonText: this.disconnectHSIService.reasonText,
                    reasonList: [this.internetSelectedReason]
                };
                services.push(service);
            } else if (this.disconnectHSIService && (this.internetSelectedReason === null || this.internetSelectedReason === undefined)) {
                this.errorText = "Please select reason for Internet Disconnection";
                return;
            }
            if (this.disconnectPRISMService && this.prismSelectedReason && this.prismSelectedReason !== "Choose reason ...") {
                let service = {
                    offerCategory: this.disconnectPRISMService.offerCategory,
                    etfInfo: this.disconnectPRISMService.etfInfo,
                    reasonType: this.disconnectPRISMService.reasonType,
                    reasonText: this.disconnectPRISMService.reasonText,
                    reasonList: [this.prismSelectedReason]
                };
                services.push(service);
            } else if (this.disconnectPRISMService && (this.prismSelectedReason === null || this.prismSelectedReason === undefined)) {
                this.errorText = "Please select reason for PRISM Disconnection";
                return;
            }
            if (this.disconnectDHPService && this.dhpSelectedReason && this.dhpSelectedReason !== "Choose reason ...") {
                let service = {
                    offerCategory: this.disconnectDHPService.offerCategory,
                    etfInfo: this.disconnectDHPService.etfInfo,
                    reasonType: this.disconnectDHPService.reasonType,
                    reasonText: this.disconnectDHPService.reasonText,
                    reasonList: [this.dhpSelectedReason]
                };
                services.push(service);
            } else if (this.disconnectDHPService && (this.dhpSelectedReason === null || this.dhpSelectedReason === undefined)) {
                this.errorText = "Please select reason for DHP Disconnection";
                return;
            }
            if (this.disconnectPOTSService && this.potsSelectedReason && this.potsSelectedReason !== "Choose reason ...") {
                let service = {
                    offerCategory: this.disconnectPOTSService.offerCategory,
                    etfInfo: this.disconnectPOTSService.etfInfo,
                    reasonType: this.disconnectPOTSService.reasonType,
                    reasonText: this.disconnectPOTSService.reasonText,
                    reasonList: [this.potsSelectedReason]
                };
                services.push(service);
            } else if (this.disconnectPOTSService && (this.potsSelectedReason === null || this.potsSelectedReason === undefined)) {
                this.errorText = "Please select reason for POTS Disconnection";
                return;
            }
            if (this.disconnectDTVServce && this.dtvSelectedReason && this.dtvSelectedReason !== "Choose reason ...") {
                let service = {
                    offerCategory: this.disconnectDTVServce.offerCategory,
                    etfInfo: this.disconnectDTVServce.etfInfo,
                    reasonType: this.disconnectDTVServce.reasonType,
                    reasonText: this.disconnectDTVServce.reasonText,
                    reasonList: [this.dtvSelectedReason]
                };
                services.push(service);
            } else if (this.disconnectDTVServce && (this.dtvSelectedReason === null || this.dtvSelectedReason === undefined)) {
                this.errorText = "Please select reason for DTV Disconnection";
                return;
            }
            if (!this.displayDepositDisConnect && disConDpstHistory && disConDpstHistory.depositInfo && disConDpstHistory.depositInfo.length > 0) {
                this.displayDepositDisConnect = true;
                return;
            }
            let apiRequest = {
                success: this.disconnectResponse.success,
                orderRefNumber: this.disconnectResponse.orderRefNumber,
                processInstanceId: this.disconnectResponse.processInstanceId,
                taskId: this.disconnectResponse.taskId,
                taskName: this.disconnectResponse.taskName,
                payload: {
                    disconnectInfo: services
                }
            };
            this.loading = true;
            this.logger.log("info", "offer.component.ts", "submitInformationRequest", JSON.stringify(apiRequest));
            this.logger.startTime();
            this.disconnectServiceCall
                .submitInformation(apiRequest)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "offer.component.ts", "submitInformationResponse", error);
                    this.logger.log("error", "offer.component.ts", "submitInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.ctlHelperService.setLocalStorage("error", error);
                    return Observable.throw(error._body);
                })
                .subscribe(
                    data => {
                        this.logger.endTime();
                        this.logger.log("info", "offer.component.ts", "submitInformationResponse", JSON.stringify(data ? data : ""));
                        this.logger.log("info", "offer.component.ts", "submitInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        this.store.dispatch({ type: "SCHEDULE_SHIPPING", payload: data });
                        this.store.dispatch({ type: "RETAINSCHEDULING", payload: data });
                        this.store.dispatch({
                            type: "RETAIN_OFFERS",
                            payload: data.payload.offers
                        });
                        this.continueDisconnect.emit(true);
                        this.continueCancel.emit(true);
                        this.enable = false;
                        this.visible = false;
                        this.store.dispatch({ type: "TASK_ID", payload: data.taskId });
                        if (data && data.payload && data.payload.referralRequired === "yes") {
                            this.isReferralRequired.emit(data);
                            this.store.dispatch({ type: "REENTRANT", payload: false });
                            this.store.dispatch({ type: "CALL_REFERRAL", payload: true });
                            this.router.navigate(["/disconnect-schedule"]);
                        } else {
                            this.store.dispatch({ type: "CALL_REFERRAL", payload: false });
                            this.router.navigate(["/disconnect-schedule"]);
                        }
                    },
                    error => {
                        this.logger.endTime();
                        this.logger.log("error", "offer.component.ts", "submitInformationResponse", error);
                        this.logger.log("error", "offer.component.ts", "submitInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        this.loading = false;
                        if (error === undefined || error === null) return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Disconnect", "dialog.component.ts", "disconnectServiceSubmitInfoResponse", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Disconnect", "dialog.component.ts", "disconnectServiceSubmitInfoResponse", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    }
                );
        } else {
            this.continueDisconnect.emit(true);
            this.continueCancel.emit(true);
            this.enable = false;
            this.visible = false;
        }
    }
    public cancelDisconnectOrder() {
        this.enable = false;
        this.visible = false;
        this.discardSession.emit(true);
    }
    public cancelVacationOrder() {
        this.enable = false;
        this.visible = false;
        this.discardSession.emit(true);
    }
    public cancelMoveOrder() {
        this.enable = false;
        this.visible = false;
        this.discardSession.emit(true);
        this.router.navigate(["/order-cancelled"]);
    }
    public discardViewOrder() {
        this.ctlHelperService.closeSession();
    }
    public discardDisconnectOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardVacationOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardMoveOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardDisconnAccountOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardMoveAccountOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardDisconnReviewOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardSubmitOrder() {
        if (this.NIPendingStackAmend) {
            this.router.navigate(['/pending-order']);
        } else {
            this.router.navigate(["/existing-products"]);
        }
    }
    public submitOrder() {
        this.schedule = true;
        this.store.dispatch({ type: "SCHEDULE", payload: this.schedule });
        this.shipping = true;
        this.store.dispatch({ type: "SHIPPING", payload: this.shipping });
        let retainVal = <Observable<any>>this.store.select("retain");
        retainVal.subscribe(retVal => {
            this.custdata = retVal.scheduling;
            this.user = <Observable<User>>this.store.select("user");
            this.userSubscription = this.user.subscribe(usr => {
                if (this.custdata.taskId !== undefined) {
                    this.custdata.taskId = usr.taskId;
                }
            });
        });
        let isChangeFlow: string = "";
        this.existingObservable = <Observable<any>>(
            this.store.select("existingProducts")
        );
        this.existingSubscription = this.existingObservable.subscribe(data => {
            this.existingData = data;
            if (this.existingData && this.existingData.orderFlow && this.existingData.orderFlow.flow !== undefined && this.existingData.orderFlow.flow === "Change") {
                isChangeFlow = "change";
            }
            if (this.existingData && this.existingData.orderFlow && this.existingData.orderFlow.flow !== undefined && this.existingData.orderFlow.flow === "Move") {
                isChangeFlow = "move";
            }
        });
        this.loading = true;
        this.logger.log("info", "customize-services.component.ts", "getResponseForCheckOutRequest", JSON.stringify(this.custdata));
        this.logger.startTime();
        this.productService
            .getResponseForCheckOut(this.custdata, isChangeFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutResponse", JSON.stringify(error));
                this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "SUBMIT_TASK", "customize-services.component.ts", "CustomizeService Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "customize-services.component.ts", "getResponseForCheckOutResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "customize-services.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.store.dispatch({ type: "TASK_ID", payload: data.taskId });
                    let response = data;
                    if (response) {
                        if (isChangeFlow === "move") {
                            this.store.dispatch({ type: "AVAILABLE_APPOINTMENTS", payload: response });
                            this.router.navigate(["/move-schedule-appt-ship"]);
                        } else {
                            if (response.taskName === "Confirm Scheduling") {
                                // Appointment Scheduling
                                this.store.dispatch({ type: "AVAILABLE_APPOINTMENTS", payload: response });
                                if (response.payload.cart || !response.payload.appointmentInfo) {
                                    this.router.navigate(["/schedule-appt-ship"]);
                                } else {
                                    this.router.navigate(["/schedule-appt"]);
                                }
                            } else if (response.taskName === "Shipping Information") {
                                this.store.dispatch({ type: "SCHEDULE_SHIPPING", payload: response });
                                this.router.navigate(["/schedule-non-appt"]);
                            }
                        }
                        this.store.dispatch({ type: "UPDATE_USER", payload: { oTCustomize: true } });
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutResponse", JSON.stringify(error));
                    this.logger.log("error", "customize-services.component.ts", "getResponseForCheckOutSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", this.custdata.taskName, "customize-services.component.ts", "Add-Ons Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", this.custdata.taskName, "customize-services.component.ts", "Add-Ons Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
        this.router.navigate(["/" + this.schedulingURL]);
    }
    public discardMoveReviewOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardDisconnReviewMenuOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardMoveReviewMenuOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardAccountMenuOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardOrder() {
        this.enable = false;
        this.visible = false;
        this.discardCanceledOrder.emit(true);
    }
    public discardMoveCustomizeOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public discardDisconnMenuOrder() {
        this.router.navigate(["/existing-products"]);
    }
    public cancelOrderNoReason() {
        this.router.navigate(["/order-cancelled"]);
    }
    //Navigating to deposit in cancel flow
    public continueCancelForDeposit() {
        this.showDepositPage = true;
        this.hideReasonDiv = true;
        let existingData = this.exisitngProduct.existingProductsAndServices[0];
        if (existingData.creditReview && existingData.creditReview.paymentInfo && existingData.creditReview.paymentInfo.length) {
            this.prepaidAmount = existingData.creditReview.paymentInfo[0].paidAmount
        }
    }
    public continueCancelForPrepaid() {
        this.hideReasonDiv = true;
        this.prepaidAmount = this.exisitngProduct.pendingOrders[0].orderDocument.creditReview.paymentInfo[0].paidAmount
    }
    public selectedAddressForDeposit() {
        this.multimatchMoveComponent.yellowAddressDeposit();
    }
    public foundYellowAddress(resp) {
        this.invokeCall = "Cancel Order Deposit";
        this.showDepositPage = true;
        this.addressChanged = true;
    }
    public changeDiv() {
        this.invokeCall = "Deposit Address";
        this.addressLineShow = true;
        this.initLoad = true;
        this.ruralNewAddress = false;
        this.asyncSelected = "";
        this.asyncUnitSelected = "";
        this.responseFlag = "";
    }
    public noChange() {
        this.invokeCall = "Cancel Order Deposit";
        this.showDepositPage = true;
        this.hideReasonDiv = true;
    }
    public validateAddressForDeposit() {
        this.loading = true;
        let errorResolved = false;
        let refObj = [];
        this.responseFlag = "";
        this.errorMsg = "";
        let civicOrpostal = "postalAddresses";
        this.inputAddress = {
            addressLine1: this.myForm.value.addressLine,
            addressLine2: this.myForm.value.unitNumber,
            stateOrProvince: this.myForm.value.state,
            city: this.myForm.value.city,
            postCode: this.myForm.value.zipCode,
            singleLine: this.addressLineShow
        };
        if (this.inputAddress.addressLine === "" || this.inputAddress.stateOrProvince === "" || this.inputAddress.city === "" || this.inputAddress.postCode === "") {
            this.errorMsg = "Required field(s) value missing.";
            return false;
        }
        this.logger.log("info", "dialog.component.ts", "validateAddressForDepositRequest", JSON.stringify(this.inputAddress));
        this.logger.startTime();
        this.addressService
            .getGeoesAddress(this.inputAddress, civicOrpostal)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "validateAddressForDepositResponse", error);
                this.logger.log("error", "dialog.component.ts", "validateAddressForDepositSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "validateAddress - validateAddressForDeposit", "dialog.component.ts", "Dialog", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "validateAddressForDepositResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "dialog.component.ts", "validateAddressForDepositSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    let respAddressesArray = [];
                    if (civicOrpostal === "civicAddresses") {
                        respAddressesArray = data.civicAddresses;
                    } else {
                        respAddressesArray = data.postalAddresses;
                    }
                    if (data && data !== undefined && data !== null && data.result === "Green") {
                        refObj = this.formingAddressObjectForDeposit(respAddressesArray)
                        this.addressChanged = true;
                        this.store.dispatch({ type: "CHANGE_ADDRESS_DEPOSIT", payload: refObj[0] });
                        let address = data.postalAddresses[0].streetAddress + "," + data.postalAddresses[0].locality + "," + data.postalAddresses[0].stateOrProvince + "," + data.postalAddresses[0].postCode;
                        let finalAddress = {
                            singleLine: false,
                            addressLine: address
                        };
                        this.store.dispatch({ type: "FINAL_ADDRESS", payload: finalAddress });
                        this.invokeCall = "Cancel Order Deposit";
                    } else if (data && data !== undefined && data !== null && data.result === "Yellow") {
                        this.responseFlag = data.result;
                        this.initLoad = false;
                        let address = data.postalAddresses[0].streetAddress + "," + data.postalAddresses[0].locality + "," + data.postalAddresses[0].stateOrProvince + "," + data.postalAddresses[0].postCode;
                        let finalAddress = {
                            singleLine: false,
                            addressLine: address
                        };
                        this.store.dispatch({ type: "FINAL_ADDRESS", payload: finalAddress });
                        refObj = this.formingAddressObjectForDeposit(respAddressesArray)
                        this.store.dispatch({ type: "ADD_YELLOW", payload: refObj });
                    } else if (data && data !== undefined && data !== null && data.result === "Red") {
                        this.initLoad = false;
                        this.responseFlag = "Red";
                    }
                },
                error => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "dialog.component.ts", "validateAddressForDepositErrorResponse", error);
                        this.logger.log("error", "dialog.component.ts", "validateAddressForDepositSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "suspendOrder - validateAddressForDeposit", "dialog.component.ts", "validate address - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "suspendOrder - validateAddressForDeposit", "dialog.component.ts", "validate address - Dialog", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public formingAddressObjectForDeposit(respAddressesArray: any): any {
        let refObj = [];
        let lunitNumber: string = "";
        for (let i = 0; i < respAddressesArray.length; i++) {
            if (respAddressesArray[i] && respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.designator !== undefined
                && respAddressesArray[i].subAddress.value !== undefined) {
                lunitNumber = respAddressesArray[i].subAddress.designator + ' ' + respAddressesArray[i].subAddress.value;
            }
            else {
                lunitNumber = "";
            }
            let geoesResponseAddress: EnterpriseAddress = {
                isValidated: true,
                streetAddress: respAddressesArray[i] && respAddressesArray[i].streetAddress ? respAddressesArray[i].streetAddress : '',
                streetNrFirst: respAddressesArray[i] && respAddressesArray[i].streetNrFirst ? respAddressesArray[i].streetNrFirst : '',
                streetNrFirstSuffix: '',
                streetNamePrefix: respAddressesArray[i] && respAddressesArray[i].streetNamePrefix ? respAddressesArray[i].streetNamePrefix : '',
                streetName: respAddressesArray[i] && respAddressesArray[i].streetName ? respAddressesArray[i].streetName : '',
                streetType: respAddressesArray[i] && respAddressesArray[i].streetType ? respAddressesArray[i].streetType : '',
                locality: respAddressesArray[i] && respAddressesArray[i].locality ? respAddressesArray[i].locality : '',
                city: respAddressesArray[i] && respAddressesArray[i].locality ? respAddressesArray[i].locality : '',
                stateOrProvince: respAddressesArray[i] && respAddressesArray[i].stateOrProvince ? respAddressesArray[i].stateOrProvince : '',
                postCode: respAddressesArray[i] && respAddressesArray[i].postCode ? respAddressesArray[i].postCode : '',
                postCodeSuffix: respAddressesArray[i] && (respAddressesArray[i].postCodeSuffix !== 'undefined') ? respAddressesArray[i].postCodeSuffix : '',
                source: respAddressesArray[i] && respAddressesArray[i].source ? respAddressesArray[i].source : '',
                country: 'USA',
                subAddress: {
                    sourceId: '',
                    source: respAddressesArray[i] && respAddressesArray[i].source ? respAddressesArray[i].source : '',
                    geoSubAddressId: '',
                    combinedDesignator: lunitNumber,
                    elements: [
                        {
                            designator: respAddressesArray[i] && (respAddressesArray[i].subAddress !== undefined) && (respAddressesArray[i].subAddress.designator !== undefined) ? respAddressesArray[i].subAddress.designator : '',
                            value: respAddressesArray[i] && (respAddressesArray[i].subAddress !== undefined) && (respAddressesArray[i].subAddress.value !== undefined) ? respAddressesArray[i].subAddress.value : ''
                        }
                    ]
                },
                locationAttributes: {
                    isMdu: null,
                    legacyProvider: null,
                    rateCenter: null,
                    npa: null,
                    nxx: null,
                    wirecenter: null,
                    cala: null,
                    tarCode: null,
                    tta: null
                }
            }
            refObj.push(geoesResponseAddress);
        }
        return refObj;
    }
    public cancelOrder() {
        this.loading = true;
        let userData;
        let cancelData;
        let request: any = {
            taskName: "Submit Order",
            payload: {
                reason: [],
                reasonRemark: "",
                addressChangedFlag: this.addressChanged,
                address: {}
            }
        };
        this.continueCancel.emit(true);
        this.enable = false;
        this.logger.startTime();
        this.cancelorderObservable = this.store.select("pending");
        this.cancelOrderSubscription = this.cancelorderObservable.subscribe(
            data => {
                cancelData = data;
                request.orderRefNumber = cancelData.orderRefNumber;
                request.processInstanceId = cancelData.processInstanceId;
                request.taskId = cancelData.taskId;
                request.taskName = cancelData.taskName;
            }
        );
        request.payload.reason = [this.cancelSelectedReason];
        request.payload.reasonRemark = this.reasonRemark;
        if (!this.addressChanged) {
            if (cancelData && cancelData.orderDocument !== undefined && cancelData.orderDocument.serviceAddress !== undefined) {
                let address = this.formingAddressObjectForDeposit([cancelData.orderDocument.serviceAddress]);
                request.payload.address = address[0];
            }
        } else {
            this.user = <Observable<User>>this.store.select("user");
            this.userSubscription = this.user.subscribe(data => {
                userData = data;
            });
            request.payload.address = userData && userData.depositAddress !== undefined && userData.depositAddress;
        }
        this.logger.log("info", "dialog.component.ts", "getCancelOrderSubmissionRequest", JSON.stringify(request));
        this.logger.startTime();
        this.pendingOrderService
            .getCancelOrderSubmissionInformation(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getCancelOrderSubmissionResponse", error);
                this.logger.log("error", "dialog.component.ts", "getCancelOrderSubmissionSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "submitTaskSup1 - getCancelOrderSubmissionInformation", "dialog.component.ts", "Dialog", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getCancelOrderSubmissionResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "dialog.component.ts", "getCancelOrderSubmissionSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.cancelOrder = data;
                    let PONRResponse = data;
                    if (PONRResponse.errorResponse !== null && PONRResponse.errorResponse !== undefined && PONRResponse.errorResponse) {
                        this.loading = false;
                        this.cancelOrderPONR = true;
                    } else if (this.cancelOrder !== undefined) {
                        this.store.dispatch({ type: "CANCELLED_ORDER", payload: data });
                        this.router.navigate(["/cancelled-order"]);
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getCancelOrderSubmissionResponse", error);
                    this.logger.log("error", "dialog.component.ts", "getCancelOrderSubmissionSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "submitTaskSup1 - getCancelOrderSubmission", "dialog.component.ts", "Cancel Order - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "submitTaskSup1 - getCancelOrderSubmission", "dialog.component.ts", "Cancel Order - Dialog", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    // For Pending Order Summary Page
    public cancelOrderForPending() {
        this.loading = true;
        let request: any = {
            taskName: "Submit Order",
            payload: {
                reason: [],
                reasonRemark: ""
            }
        };
        this.continueCancel.emit(true);
        this.enable = false;
        this.logger.startTime();
        this.cancelorderObservable = this.store.select("pending");
        this.cancelOrderSubscription = this.cancelorderObservable.subscribe(
            data => {
                request.customerOrderNumber = data.orderReference.customerOrderNumber;
            }
        );
        request.payload.reason = [this.cancelSelectedReason];
        request.payload.reasonRemark = this.reasonRemark;
        this.logger.log("info", "dialog.component.ts", "getCancelOrderInformationRequest", JSON.stringify(request));
        this.logger.startTime();
        this.pendingOrderService
            .getCancelOrderInformation(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getCancelOrderInformationResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "getCancelOrderInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "submitTaskSup1 - getCancelOrderSubmissionInformation", "dialog.component.ts", "Dialog", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getCancelOrderInformationResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "dialog.component.ts", "getCancelOrderInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.cancelOrder = data;
                    let PONRResponse = data;
                    this.loading = false;
                    if (PONRResponse.errorResponse !== null && PONRResponse.errorResponse !== undefined && PONRResponse.errorResponse) {
                        this.cancelOrderPONR = true;
                    } else if (this.cancelOrder !== undefined) {
                        this.store.dispatch({ type: "CANCELLED_ORDER", payload: data });
                        this.router.navigate(["/cancelled-order"]);
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getCancelOrderInformationResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "getCancelOrderInformationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "submitTaskSup1 - getCancelOrderSubmission", "dialog.component.ts", "Cancel Order - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "submitTaskSup1 - getCancelOrderSubmission", "dialog.component.ts", "Cancel Order - Dialog", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public showOption(maxNoOfInstallment) {
        if (maxNoOfInstallment && maxNoOfInstallment !== null && maxNoOfInstallment > 1) {
            return true;
        } else {
            return false;
        }
    }
    public printreason() { }
    public changeTypeaheadLoading(e: boolean): void {
        this.typeaheadLoading = e;
    }
    public changeTypeaheadNoResults(e: boolean): void {
        this.typeaheadNoResults = e;
    }
    public typeaheadOnSelect(e: TypeaheadMatch): void { }
    public validate() {
        this.moveAddressLine = false;
        this.workingService = true;
    }
    public tryAgain() {
        this.moveAddressLine = true;
    }
    public showAddress(show: boolean) {
        this.addressLineShow = show;
    }
    // called onKeyUp from single line address field
    public singleLineAPI(inputCharacter: any) {
        if (inputCharacter !== null && inputCharacter !== "" && inputCharacter.length >= 3) {
            this.logger.log("info", "address.component.ts", "GeoamsrvclRequest", JSON.stringify(inputCharacter));
            this.logger.startTime();
            this.addressService
                .getGeoamsrvcl(inputCharacter)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "geoamResponse", JSON.stringify(error));
                    this.logger.log("error", "address.component.ts", "geoamSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.ctlHelperService.setLocalStorage("error", error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    data => {
                        this.logger.endTime();
                        this.logger.log("info", "address.component.ts", "geoamResponse", JSON.stringify(data ? data : ""));
                        this.logger.log("info", "address.component.ts", "geoamSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        let response = data;
                        this.addressComplex = response && response.responseData && response.responseData.addresses;
                        if (response.responseCode === 200 && (this.addressComplex && this.addressComplex.length === 0)) {
                            this.typeaheadNoResults = true;
                        } else if (response.responseCode === 200 && (this.addressComplex && this.addressComplex.length !== 0)) {
                            this.typeaheadNoResults = false;
                            this.typeaheadLoading = false;
                        } else if (response.responseCode === 400) {
                            this.typeaheadNoResults = true;
                        }
                    },
                    error => {
                        this.logger.endTime();
                        this.logger.log("error", "address.component.ts", "geoamResponse", JSON.stringify(error));
                        this.logger.log("error", "address.component.ts", "geoamSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        if (error === undefined || error === null) return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "geoamResponseError", "address.component.ts", "Address Page", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                            this.systemErrorService.logAndeRouteToSystemError("error", "geoamResponseError", "address.component.ts", "Address Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    }
                );
        } else {
            this.typeaheadNoResults = false;
        }
    }
    public showAddressLine(show: boolean) {
        this.addressLineShow = show;
        this.asyncSelected = "";
        this.myForm = this.fb.group({
            firstName: [this.myForm.value.firstName, [Validators.required, <any>Validations.nameValidator]],
            lastName: [this.myForm.value.lastName, [Validators.required, <any>Validations.nameValidator]],
            phoneNumber: [this.myForm.value.phoneNumber, Validators.required],
            singleAddressLine: this.addressLineShow ? [""] : ["", [Validators.required, <any>Validations.addressLineValidator]],
            singleUnitNumber: [""],
            addressLine: this.addressLineShow ? ["", [Validators.required, <any>Validations.addressLineValidator]] : [""],
            unitNumber: [""],
            state: this.addressLineShow ? ["", Validators.required] : [""],
            city: this.addressLineShow ? ["", [Validators.required, <any>Validations.nameValidator]] : [""],
            zipCode: this.addressLineShow ? ["", Validations.zipCodeValidator] : [""],
            number: [""],
            accountNumber: [""],
            orderNumber: [""]
        });
    }
    public getAddressesAsObservable(token: string): Observable<any> {
        let query = new RegExp(token, "ig");
        return Observable.of(
            this.addressComplex.filter((addressSet: any) => {
                return query.test(addressSet.fullAddress);
            })
        );
    }
    public WorkingServiceAllowedChk() {
        let allowedFlows = {
            MOVE: true,
            BILLING: false,
            BILLANDREC: false
        };
        if (this.legacyName === 'CENTURYLINK' && this.isWliAvailable) {
            this.isWorkingServiceAllowed = allowedFlows[this.currentFlow.toUpperCase()] && !this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_WLI_LQ);
        } else {
            this.isWorkingServiceAllowed = false;
        }
    }
    public enableContinueBtn(event) {
        this.enabledContinue = event;
    }
    public onWLIContinue() {
        this.movingToServices = true;
        this.moveSuccess();
    }
    public moveSuccess() {
        let callerInfo: ContactInfo;
        if (this.initResp !== undefined && this.initResp !== null) {
            this.checkSpeedDiff(this.initResp);
            callerInfo = {
                firstName: this.initResp.payload.existingLocation.accountInfo.accountName.firstName,
                lastName: this.initResp.payload.existingLocation.accountInfo.accountName.lastName,
                phoneNumber: this.initResp.payload.existingLocation.accountInfo.contact.contactNumber
            };
            this.store.dispatch({ type: "UPDATE_USER", payload: callerInfo });
            if (!this.addressLineShow) {
                this.inputAddress = Object.assign({}, this.inputAddress, {
                    addressLine: this.myForm.value.singleAddressLine
                });
            }
            let internetCheck = false;
            let videoAvail;
            let phoneAvail: boolean = false;
            let phoneType = [];
            let videoType = [];
            if (this.addressService.checkCategoryId("DATA", this.initResp.payload.newLocation.serviceCategory) !== undefined) {
                internetCheck = true;
            }
            if (this.addressService.checkCategoryId("DATA/VIDEO", this.initResp.payload.newLocation.serviceCategory) !== undefined) {
                videoAvail = true;
                videoType.push({
                    name: "DATA/VIDEO",
                    displayName: "PRISM TV",
                    code: "PTV",
                    tabName: "PRISM"
                });
            }
            if (this.addressService.checkCategoryId("VIDEO-DTV", this.initResp.payload.newLocation.serviceCategory) !== undefined) {
                videoAvail = true;
                videoType.push({
                    name: "VIDEO-DTV",
                    displayName: "DIRECTV",
                    code: "DTV",
                    tabName: "DIRECTV"
                });
            }
            if (this.addressService.checkCategoryId("VOICE-DHP", this.initResp.payload.newLocation.serviceCategory) !== undefined) {
                phoneAvail = true;
                phoneType.push({
                    name: "VOICE-DHP",
                    displayName: "Digital(DHP)",
                    code: "DHP",
                    tabName: "DHP"
                });
            }
            if (this.addressService.checkCategoryId("VOICE-HP", this.initResp.payload.newLocation.serviceCategory) !== undefined) {
                phoneAvail = true;
                phoneType.push({
                    name: "VOICE-HP",
                    displayName: "Home Phone",
                    code: "HMP",
                    tabName: "Home Phone"
                });
            }
            let user: User = {
                id: 1,
                internetCheck,
                videoCheck: videoAvail,
                phoneCheck: phoneAvail,
                phoneType: phoneType,
                videoType: videoType,
                enabledServiceList: this.initResp.payload.newLocation.serviceCategory
            };
            this.store.dispatch({ type: "UPDATE_USER", payload: user });
            this.store.dispatch({ type: "FINAL_ADDRESS", payload: this.inputAddress });
            this.store.dispatch({ type: "ADD_ORDER_INIT", payload: this.initResp });
        }
    }
    public onSubmit() {
        let callerInfo: ContactInfo;
        this.responseFlag = "";
        this.errorMsg = "";
        if (this.addressLineShow) {
            this.inputAddress = {
                addressLine: this.myForm.value.addressLine,
                unitNumber: this.myForm.value.unitNumber,
                stateOrProvince: this.myForm.value.state,
                city: this.myForm.value.city,
                postCode: this.myForm.value.zipCode,
                singleLine: this.addressLineShow
            };
            if (this.inputAddress.addressLine === "" || this.inputAddress.stateOrProvince === "" || this.inputAddress.city === "" || this.inputAddress.postCode === "") {
                this.errorMsg = "Required field(s) value missing.";
                return false;
            }
        } else {
            this.inputAddress = {
                addressLine: this.myForm.value.singleAddressLine,
                unitNumber: this.myForm.value.singleUnitNumber,
                singleLine: this.addressLineShow
            };
            if (this.inputAddress.addressLine === "") {
                this.errorMsg = "Address Line value missing.";
                return false;
            }
        }
        this.loading = true;
        this.logger.log("info", "Dialog-address.component.ts", "initRequest", JSON.stringify(this.inputAddress));
        this.logger.startTime();
        this.addressService
            .moveAddress(this.inputAddress, true, this.exisitngProduct)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    let response = data;
                    this.initResp = data;
                    if (response && response.payload && response.payload.workingServiceInfo &&
                        response.payload.workingServiceInfo !== null &&
                        Array.isArray(response.payload.workingServiceInfo) &&
                        response.payload.workingServiceInfo.length > 0) {
                        this.isWliAvailable = true;
                        this.WorkingServiceAllowedChk();
                    } else {
                        this.isWliAvailable = false;
                    }
                    if (response && response.taskName === "Select Product") {
                        if (this.isWliAvailable && this.isWorkingServiceAllowed) {
                            this.workingservinfo = [];
                            response.payload.workingServiceInfo.forEach((wsInfo) => {
                                this.workingservinfo.push(wsInfo);
                            });
                            this.store.dispatch({ type: 'WORKING_SERVICE_INFO', payload: this.workingservinfo });
                            this.movingToServices = false;
                            this.moveSuccess();
                        } else {
                            this.movingToServices = true;
                            this.moveSuccess();
                        }
                    } else {
                        if (response && response.payload && (response.payload.result === "RED - no match")) {
                            this.initLoad = false;
                            this.responseFlag = "red";
                            this.loading = false;
                        } else if (response.taskName === "Select Matching Address") {
                            if (response && response.payload && (response.payload.result === "Found")) {
                                this.responseFlag = "AddressAddConfirmation";
                                this.loading = false;
                                response.InRangeFlag = this.responseFlag;
                                this.orderRefNumber = response.orderRefNumber;
                                this.inRangeResponse = response;
                            } else if (response && response.payload && (response.payload.result === "NotFound")) {
                                this.responseFlag = "AddressNotInRange";
                                this.loading = false;
                                response.InRangeFlag = this.responseFlag;
                                this.inRangeResponse = response;
                                this.orderRefNumber = response.orderRefNumber;
                            } else {
                                this.initLoad = false;
                                let unitNumber = this.myForm.value.singleUnitNumber;
                                if (!unitNumber) {
                                    unitNumber = this.myForm.value.unitNumber;
                                }
                                if (!this.addressLineShow) {
                                    this.inputAddress = Object.assign({}, this.inputAddress, {
                                        addressLine: this.myForm.value.singleAddressLine
                                    });
                                }
                                this.responseFlag = "yellow";
                                let orderDetails: any = {
                                    orderRefNumber: response.orderRefNumber,
                                    processInstanceId: response.processInstanceId,
                                    taskId: response.taskId,
                                    taskName: response.taskName
                                };
                                this.store.dispatch({ type: "UPDATE_USER", payload: callerInfo });
                                this.store.dispatch({ type: "FINAL_ADDRESS", payload: this.inputAddress });
                                this.store.dispatch({ type: "ENTERED_UNIT", payload: unitNumber });
                                this.store.dispatch({ type: "ADD_ORDER_INIT", payload: orderDetails });
                                this.store.dispatch({ type: "ADD_YELLOW", payload: response.payload.nearMatchAddress });
                            }
                        } else if (response.taskName === "Re-Submit Address") {
                            if (response && response.payload && (response.payload.result === "Found")) {
                                this.responseFlag = "AddressAddConfirmation";
                                this.loading = false;
                                this.inRangeResponse = response;
                                this.orderRefNumber = response.orderRefNumber;
                            } else if (response && response.payload && (response.payload.result === "NotFound")) {
                                this.responseFlag = "AddressNotInRange";
                                this.loading = false;
                                response.InRangeFlag = this.responseFlag;
                                this.inRangeResponse = response;
                                this.orderRefNumber = response.orderRefNumber;
                            } else {
                                this.loading = false;
                            }
                        } else {
                            if (response.error !== undefined) {
                                this.errorMsg = response.error.errorMessage;
                            } else {
                                this.errorMsg = serverErrorMessages.serviceDown;
                            }
                            this.loading = false;
                        }
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                    this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.initLoad = false;
                    this.responseFlag = "red";
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    /**
     * For Inrange address flow
     */
    public selectedAddress() {
        let callerInfo: ContactInfo;
        this.inputAddress.inRangeResponse = this.inRangeResponse;
        this.loading = true;
        this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(this.inputAddress));
        this.logger.startTime();
        this.addressService
            .moveAddress(this.inputAddress, true, this.exisitngProduct)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    let response = data;
                    if (response && response.taskName === "Select Product") {
                        this.checkSpeedDiff(response);
                        callerInfo = {
                            firstName: data.payload.existingLocation.accountInfo.accountName.firstName,
                            lastName: data.payload.existingLocation.accountInfo.accountName.lastName,
                            phoneNumber: data.payload.existingLocation.accountInfo.contact.contactNumber
                        };
                        this.store.dispatch({ type: "UPDATE_USER", payload: callerInfo });
                        if (!this.addressLineShow) {
                            this.inputAddress = Object.assign({}, this.inputAddress, {
                                addressLine: this.myForm.value.singleAddressLine
                            });
                        }
                        let internetCheck = false;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (this.addressService.checkCategoryId("DATA", response.payload.newLocation.serviceCategory) !== undefined) {
                            internetCheck = true;
                        }
                        if (this.addressService.checkCategoryId("DATA/VIDEO", response.payload.newLocation.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: "DATA/VIDEO",
                                displayName: "PRISM TV",
                                code: "PTV",
                                tabName: "PRISM"
                            });
                        }
                        if (
                            this.addressService.checkCategoryId("VIDEO-DTV", response.payload.newLocation.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: "VIDEO-DTV",
                                displayName: "DIRECTV",
                                code: "DTV",
                                tabName: "DIRECTV"
                            });
                        }
                        if (
                            this.addressService.checkCategoryId("VOICE-DHP", response.payload.newLocation.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: "VOICE-DHP",
                                displayName: "Digital(DHP)",
                                code: "DHP",
                                tabName: "DHP"
                            });
                        }
                        if (
                            this.addressService.checkCategoryId("VOICE-HP", response.payload.newLocation.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: "VOICE-HP",
                                displayName: "Home Phone",
                                code: "HMP",
                                tabName: "Home Phone"
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: response.payload.newLocation.serviceCategory
                        };
                        this.store.dispatch({ type: "UPDATE_USER", payload: user });
                        this.store.dispatch({ type: "FINAL_ADDRESS", payload: this.inputAddress });
                        this.store.dispatch({ type: "ADD_ORDER_INIT", payload: data });
                    } else {
                        if (response.error !== undefined) {
                            this.errorMsg = response.error.errorMessage;
                        } else {
                            this.errorMsg = serverErrorMessages.serviceDown;
                        }
                        this.loading = false;
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                    this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.initLoad = false;
                    this.responseFlag = "red";
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public onContinue() {
        let callerInfo: ContactInfo;
        this.responseFlag = "";
        this.errorMsg = "";
        let serviceAddrsChanged = this.isCheckedStatus;
        if (serviceAddrsChanged === "Yes") {
            if (this.addressLineShow) {
                this.inputAddress = {
                    addressLine: this.myForm.value.addressLine,
                    streetNrFirst: this.myForm.value.addressLine.split("")[0].trim(),
                    unitNumber: this.myForm.value.unitNumber,
                    stateOrProvince: this.myForm.value.state,
                    city: this.myForm.value.city,
                    postCode: this.myForm.value.zipCode,
                    singleLine: this.addressLineShow
                };
            } else {
                let streetNm = this.myForm.value.singleAddressLine.split(",")[0].split(" ")[0];
                this.inputAddress = {
                    addressLine: this.myForm.value.singleAddressLine,
                    unitNumber: this.myForm.value.singleUnitNumber,
                    singleLine: this.addressLineShow,
                    streetAddress: this.myForm.value.singleAddressLine.split(",")[0],
                    streetNrFirst: this.myForm.value.singleAddressLine.split(",")[0].split(" ")[0],
                    streetName: this.myForm.value.singleAddressLine.split(",")[0].replace(streetNm, "").trim(),
                    city: this.myForm.value.singleAddressLine.split(",")[1].trim(),
                    stateOrProvince: this.myForm.value.singleAddressLine.split(",")[2].length > 5 ? this.myForm.value.singleAddressLine.split(",")[2].split(" ")[0].trim() : this.myForm.value.singleAddressLine.split(",")[2].trim(),
                    postCode: this.myForm.value.singleAddressLine.split(",")[2].length > 5 ? this.myForm.value.singleAddressLine.split(",")[2].split(" ")[1].trim() : this.myForm.value.singleAddressLine.split(",")[3].trim()
                };
            }
        } else {
            if (this.customerOrderType !== "NEWINSTALL") {
                this.inputAddress = {
                    addressLine: this.myForm.value.addressLine,
                    unitNumber: this.myForm.value.singleUnitNumber,
                    streetAddress: this.myForm.value.addressLine,
                    streetNrFirst: this.exisitngProduct.existingProductsAndServices[0].serviceAddress.streetNrFirst,
                    streetName: this.exisitngProduct.existingProductsAndServices[0].serviceAddress.streetName,
                    city: this.exisitngProduct.existingProductsAndServices[0].serviceAddress.city,
                    stateOrProvince: this.exisitngProduct.existingProductsAndServices[0].serviceAddress.stateOrProvince,
                    postCode: this.exisitngProduct.existingProductsAndServices[0].serviceAddress.postCode,
                    singleLine: this.addressLineShow
                };
            } else {
                this.inputAddress = {
                    addressLine: this.myForm.value.addressLine,
                    unitNumber: this.myForm.value.singleUnitNumber,
                    streetAddress: this.myForm.value.addressLine,
                    streetNrFirst: this.serviceAddress.streetNrFirst,
                    streetName: this.serviceAddress.streetName,
                    city: this.serviceAddress.city,
                    stateOrProvince: this.serviceAddress.stateOrProvince,
                    postCode: this.serviceAddress.postCode,
                    singleLine: this.addressLineShow
                };
            }
        }
        this.loading = true;
        this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(this.inputAddress));
        this.logger.startTime();
        if (this.exisitngProduct.orderFlow.flow === "billing" && this.customerOrderStatus === "PENDING" && this.customerOrderType === "NEWINSTALL") {
            this.brcBanObservable = this.store.select("pending");
            this.brcBanSubscription = this.brcBanObservable.subscribe(data => {
                this.banNo = data.orderDocument.accountInfo.ban;
            });
        }
        this.addressService.billingRecordsAddress(this.inputAddress, true, serviceAddrsChanged, this.exisitngProduct, this.banNo ? this.banNo : "")
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "initRequest", "address.component.ts", "billingRecAddressOnSubmit", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    let response = data;
                    if (response && response.taskName === "Select Product") {
                        if (!this.addressLineShow) {
                            this.inputAddress = Object.assign({}, this.inputAddress, {
                                addressLine: this.myForm.value.singleAddressLine
                            });
                        }
                        let internetCheck;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (this.addressService.checkCategoryId("DATA", response.payload.serviceCategory) !== undefined) {
                            internetCheck = true;
                        }
                        if (this.addressService.checkCategoryId("DATA/VIDEO", response.payload.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: "DATA/VIDEO",
                                displayName: "PRISM TV",
                                code: "PTV",
                                tabName: "PRISM"
                            });
                        }
                        if (this.addressService.checkCategoryId("VIDEO-DTV", response.payload.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: "VIDEO-DTV",
                                displayName: "DIRECTV",
                                code: "DTV",
                                tabName: "DIRECTV"
                            });
                        }
                        if (this.addressService.checkCategoryId("VOICE-DHP", response.payload.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: "VOICE-DHP",
                                displayName: "Digital(DHP)",
                                code: "DHP",
                                tabName: "DHP"
                            });
                        }
                        if (this.addressService.checkCategoryId("VOICE-HP", response.payload.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: "VOICE-HP",
                                displayName: "Home Phone",
                                code: "HMP",
                                tabName: "Home Phone"
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: response.payload.serviceCategory
                        };
                        this.store.dispatch({ type: "CHANGE_UPDATE_USER", payload: user });
                        this.store.dispatch({ type: "UPDATE_USER", payload: user });
                        this.store.dispatch({ type: "FINAL_ADDRESS", payload: this.inputAddress });
                        this.store.dispatch({ type: "ADD_ORDER_INIT", payload: data });
                        this.store.dispatch({ type: "INCLUDING_GIFTCARDS", payload: data.payload.giftCardOffers });
                        this.store.dispatch({ type: "INCLUDING_OFFERS", payload: data.payload.offers });
                        if (this.ctlHelperService.checkRuralAddress(response)) {
                            this.ruralNewAddress = true;
                        } else {
                            this.router.navigate(["/billing-product"]);
                        }
                    } else {
                        if (response && response.payload && (response.payload.result === "RED - no match")) {
                            this.initLoad = false;
                            this.responseFlag = "red";
                            this.loading = false;
                        } else if (response.taskName === "Select Matching Address") {
                            if (response && response.payload && (response.payload.result === "Found")) {
                                this.responseFlag = "AddressAddConfirmation";
                                this.loading = false;
                                response.InRangeFlag = this.responseFlag;
                                this.orderRefNumber = response.orderRefNumber;
                                this.inRangeResponse = response;
                            } else if (response && response.payload && (response.payload.result === "NotFound")) {
                                this.responseFlag = "AddressNotInRange";
                                this.loading = false;
                                response.InRangeFlag = this.responseFlag;
                                this.inRangeResponse = response;
                                this.orderRefNumber = response.orderRefNumber;
                            } else {
                                this.initLoad = false;
                                let unitNumber = this.myForm.value.singleUnitNumber;
                                if (!unitNumber) {
                                    unitNumber = this.myForm.value.unitNumber;
                                }
                                if (!this.addressLineShow) {
                                    this.inputAddress = Object.assign({}, this.inputAddress, {
                                        addressLine: this.myForm.value.singleAddressLine
                                    });
                                }
                                this.responseFlag = "yellow";
                                let orderDetails: any = {
                                    orderRefNumber: response.orderRefNumber,
                                    processInstanceId: response.processInstanceId,
                                    taskId: response.taskId,
                                    taskName: response.taskName
                                };
                                this.store.dispatch({ type: "UPDATE_USER", payload: callerInfo });
                                this.store.dispatch({
                                    type: "FINAL_ADDRESS",
                                    payload: this.inputAddress
                                });
                                this.store.dispatch({ type: "ENTERED_UNIT", payload: unitNumber });
                                this.store.dispatch({ type: "ADD_ORDER_INIT", payload: orderDetails });
                                this.store.dispatch({ type: "ADD_YELLOW", payload: response.payload.nearMatchAddress });
                            }
                        } else if (response.taskName === "Re-Submit Address") {
                            if (response && response.payload && (response.payload.result === "Found")) {
                                this.responseFlag = "AddressAddConfirmation";
                                this.loading = false;
                                this.inRangeResponse = response;
                                this.orderRefNumber = response.orderRefNumber;
                            } else if (response && response.payload && (response.payload.result === "NotFound")) {
                                this.responseFlag = "AddressNotInRange";
                                this.loading = false;
                                response.InRangeFlag = this.responseFlag;
                                this.inRangeResponse = response;
                                this.orderRefNumber = response.orderRefNumber;
                            } else {
                                this.loading = false;
                            }
                        } else {
                            if (response.error !== undefined) {
                                this.errorMsg = response.error.errorMessage;
                            } else {
                                this.errorMsg = serverErrorMessages.serviceDown;
                            }
                            this.loading = false;
                        }
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                    this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.initLoad = false;
                    this.responseFlag = "red";
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "initRequest", "address.component.ts", "billingRecAddressOnSubmit", error);
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public billingRecordsSelectedAddress() {
        let serviceAddrsChanged = this.isCheckedStatus;
        this.loading = true;
        this.logger.log("info", "address.component.ts", "initRequest", JSON.stringify(this.inputAddress));
        this.logger.startTime();
        if (this.exisitngProduct.orderFlow.flow === "billing" && this.customerOrderStatus === "PENDING" && this.customerOrderType === "NEWINSTALL") {
            this.brcBanObservable = this.store.select("pending");
            this.brcBanSubscription = this.brcBanObservable.subscribe(data => {
                this.banNo = data.orderDocument.accountInfo.ban;
            });
        }
        this.addressService
            .billingRecordsAddress(
                this.inRangeResponse,
                true,
                serviceAddrsChanged,
                this.exisitngProduct,
                this.banNo ? this.banNo : ""
            )
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "initRequest", "address.component.ts", "billingRecAddressOnSubmit", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "initResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    let response = data;
                    if (response && response.taskName === "Select Product") {
                        let internetCheck;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (this.addressService.checkCategoryId("DATA", response.payload.serviceCategory) !== undefined) {
                            internetCheck = true;
                        }
                        if (this.addressService.checkCategoryId("DATA/VIDEO", response.payload.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: "DATA/VIDEO",
                                displayName: "PRISM TV",
                                code: "PTV",
                                tabName: "PRISM"
                            });
                        }
                        if (this.addressService.checkCategoryId("VIDEO-DTV", response.payload.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: "VIDEO-DTV",
                                displayName: "DIRECTV",
                                code: "DTV",
                                tabName: "DIRECTV"
                            });
                        }
                        if (this.addressService.checkCategoryId("VOICE-DHP", response.payload.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: "VOICE-DHP",
                                displayName: "Digital(DHP)",
                                code: "DHP",
                                tabName: "DHP"
                            });
                        }
                        if (this.addressService.checkCategoryId("VOICE-HP", response.payload.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: "VOICE-HP",
                                displayName: "Home Phone",
                                code: "HMP",
                                tabName: "Home Phone"
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: response.payload.serviceCategory
                        };
                        this.store.dispatch({ type: "CHANGE_UPDATE_USER", payload: user });
                        this.store.dispatch({ type: "UPDATE_USER", payload: user });
                        this.store.dispatch({ type: "FINAL_ADDRESS", payload: this.inputAddress });
                        this.store.dispatch({ type: "ADD_ORDER_INIT", payload: data });
                        this.store.dispatch({ type: "INCLUDING_GIFTCARDS", payload: data.payload.giftCardOffers });
                        this.store.dispatch({ type: "INCLUDING_OFFERS", payload: data.payload.offers });
                        this.router.navigate(["/billing-product"]);
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "initResponse", JSON.stringify(error));
                    this.logger.log("error", "address.component.ts", "initSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.initLoad = false;
                    this.responseFlag = "red";
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "initRequest", "address.component.ts", "billingRecAddressOnSubmit", error
                    );
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "initError", "address.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public multiResponse(resp) {
        if (resp && resp.success && resp.success.payload && resp.success.payload.newLocation) {
            this.newLocation = resp.success.payload.newLocation;
        }

        this.checkSpeedDiff(resp.success);
        this.loading = false;
    }
    public multiMatchResponse(resp) {
        if (resp) {
            this.ruralNewAddress = true;
        }
    }
    public nameCorrection(name) {
        if (name === GenericValues.iData || name === GenericValues.sData) {
            return GenericValues.sData;
        } else {
            return name;
        }
    }
    public getProductName(existingItem): string {
        let prodName: string = "";
        if (existingItem.offerCategory !== "VOICE-HP") {
            this.phoneOnly = false;
        }
        if (existingItem && existingItem.existingServiceSubItems) {
            existingItem.existingServiceSubItems.map(items => {
                if (items.componentType === GenericValues.cPrimary) {
                    prodName = items.productName;
                }
            });
        }
        return prodName;
    }
    public checkSpeedDiff(response) {
        let request: any = {
            rsnType: "DISCONNECT"
        };
        this.loading = true;
        this.logger.log("info", "offer.component.ts", "getResponseForRemoveRequest", JSON.stringify(request));
        this.logger.startTime();
        this.productService
            .getResponseForRemove(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "offer.component.ts", "getResponseForRemoveResponse", JSON.stringify(error));
                this.logger.log("error", "offer.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Disconnect Remove Response - Offers Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                respData => {
                    this.logger.endTime();
                    this.logger.log("info", "offer.component.ts", "getResponseForRemoveResponse", JSON.stringify(respData ? respData : ""));
                    this.logger.log("info", "offer.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.store.dispatch({ type: "DISCON_REASON", payload: respData.bmReasonCodes });
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "offer.component.ts", "getResponseForRemoveResponse", JSON.stringify(error));
                    this.logger.log("error", "offer.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                }
            );
        if (response.payload) {
            this.existingObservable = <Observable<any>>this.store.select('existingProducts');
            this.existingSubscription = this.existingObservable.subscribe((data) => {
                if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress.locationAttributes) {
                    this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
                }
            })
            this.existingSubscription.unsubscribe();
            this.workingService = response.payload.newLocation.workingServices;
            if (response.payload.newLocation && response.payload.newLocation.serviceAddress && response.payload.newLocation.serviceAddress.locationAttributes
                && response.payload.newLocation.serviceAddress.locationAttributes.legacyProvider) {
                this.newLegacyProvider = response.payload.newLocation.serviceAddress.locationAttributes.legacyProvider;
            }

            if (this.newLegacyProvider !== this.legacyProvider && !this.isMoveAllowed) {
                this.responseFlag = "moveNotAllowed";
            }
            this.existingServices = response.payload.existingLocation.existingServices.existingServiceItems;
            let existingSpeed = response.payload.existingLocation.existingServices.existingServiceItems;
            let newServiceCategory: any[] = response.payload.newLocation.serviceCategory;
            for (let i = 0; i < existingSpeed.length; i++) {
                for (let j = 0; j < newServiceCategory.length; j++) {
                    if (this.nameCorrection(existingSpeed[i].offerCategory) === newServiceCategory[j].serviceCategory) {
                        switch (this.nameCorrection(existingSpeed[i].offerCategory)) {
                            case GenericValues.sData: {
                                let newServiceDownValue = +newServiceCategory[j].serviceCharacteristic[0].value >= 1000 ? 1 : +newServiceCategory[j].serviceCharacteristic[0].value;
                                let newServiceUpValue = +newServiceCategory[j].serviceCharacteristic[1].value >= 1000 ? 1 : +newServiceCategory[j].serviceCharacteristic[1].value;
                                let existingServiceDownValue: number;
                                let existingServiceUpValue: number;
                                let exDownUOM: string = "";
                                let exUpUOM: string = "";
                                let newDownUOM: string = "";
                                let newUpUOM: string = "";
                                existingSpeed[i].existingServiceSubItems.map(items => {
                                    if (items.componentType === GenericValues.cPrimary) {
                                        this.downSpeed = items.productName;
                                        for (let k = 0; k < items.productAttributes.length; k++) {
                                            let res: any;
                                            let down: any;
                                            items.productAttributes[k].compositeAttribute.map(
                                                attr => {
                                                    if (attr && attr.attributeName && attr.attributeName.toLowerCase() === "derived downspeed") {
                                                        res = attr.attributeValue.indexOf("-");
                                                        down = attr.attributeValue.substring(res + 1, attr.attributeValue.length);
                                                        exDownUOM = attr.uom;
                                                        existingServiceDownValue = +down.trim();
                                                        newDownUOM = +newServiceCategory[j].serviceCharacteristic[0].value >= 1000 ? this.updateUom(newServiceCategory[j].serviceCharacteristic[0].uom) : newServiceCategory[j].serviceCharacteristic[0].uom;
                                                    } else if (attr && attr.attributeName && attr.attributeName.toLowerCase() === "derived upspeed") {
                                                        res = attr.attributeValue.indexOf("-");
                                                        down = attr.attributeValue.substring(res + 1, attr.attributeValue.length);
                                                        exUpUOM = attr.uom;
                                                        existingServiceUpValue = +down.trim();
                                                        newUpUOM = +newServiceCategory[j].serviceCharacteristic[1].value >= 1000 ? this.updateUom(newServiceCategory[j].serviceCharacteristic[1].uom) : newServiceCategory[j].serviceCharacteristic[1].uom;
                                                    }
                                                }
                                            );
                                        }
                                        this.availabledownSpeed = newServiceDownValue;
                                        this.availableupSpeed = newServiceUpValue;
                                        this.newDownSpeedUOM = newDownUOM;
                                        this.newUpSpeedUOM = newUpUOM;
                                        if (exDownUOM === undefined || exUpUOM === undefined) {
                                            this.speed = true;
                                        }
                                        if ((newDownUOM === "Gbps" && exDownUOM === "Mbps") || (newDownUOM === "Mbps" && exDownUOM === "Kbps")) {
                                            this.faster = true;
                                            this.slower = false;
                                            this.same = false;
                                        } else if ((newDownUOM === "Gbps" && exDownUOM === "Gbps") || ((newDownUOM === "Mbps" && exDownUOM === "Mbps") || (newDownUOM === "Kbps" && exDownUOM === "Kbps"))) {
                                            if (existingServiceDownValue === newServiceDownValue) {
                                                if ((newUpUOM === "Gbps" && exUpUOM === "Gbps") || ((newUpUOM === "Mbps" && exUpUOM === "Mbps") || (newUpUOM === "Kbps" && exUpUOM === "Kbps"))) {
                                                    if (existingServiceUpValue === newServiceUpValue) {
                                                        this.faster = false;
                                                        this.slower = false;
                                                        this.same = true;
                                                    } else if (existingServiceUpValue < newServiceUpValue) {
                                                        this.faster = true;
                                                        this.slower = false;
                                                        this.same = false;
                                                    } else if (existingServiceUpValue > newServiceUpValue) {
                                                        this.faster = false;
                                                        this.slower = true;
                                                        this.same = false;
                                                    }
                                                } else if ((newUpUOM === "Gbps" && exUpUOM === "Mbps") || (newUpUOM === "Mbps" && exUpUOM === "Kbps")) {
                                                    this.faster = true;
                                                    this.slower = false;
                                                    this.same = false;
                                                } else if ((newUpUOM === "Mbps" && exUpUOM === "Gbps") || (newUpUOM === "Kbps" && exUpUOM === "Mbps")) {
                                                    this.faster = false;
                                                    this.slower = true;
                                                    this.same = false;
                                                }
                                            } else if (existingServiceDownValue < newServiceDownValue) {
                                                this.faster = true;
                                                this.slower = false;
                                                this.same = false;
                                            } else if (existingServiceDownValue > newServiceDownValue) {
                                                this.faster = false;
                                                this.slower = true;
                                                this.same = false;
                                            }
                                        } else if ((newDownUOM === "Mbps" && exDownUOM === "Gbps") || (newDownUOM === "Kbps" && exDownUOM === "Mbps")) {
                                            this.faster = false;
                                            this.slower = true;
                                            this.same = false;
                                        }
                                    }
                                });
                                break;
                            }
                            case GenericValues.cHP: {
                                if (newServiceCategory[j].canMoveExistingTN && newServiceCategory[j].canMoveExistingTN !== undefined && newServiceCategory[j].canMoveExistingTN !== null) {
                                    this.canMove = newServiceCategory[j].canMoveExistingTN.toLowerCase() === "no" ? false : true;
                                }
                                break;
                            }
                        }
                    }
                }
            }
            if (this.ctlHelperService.checkRuralAddress(response)) {
                this.ruralNewAddress = true;
                this.success = false;
            } else {
                this.success = true;
            }
            this.initLoad = false;
            this.loading = false;
            if (this.responseFlag !== 'moveNotAllowed')
                this.responseFlag = "";
        }
    }
    public continuetoBillingProdut() {
        this.router.navigate(["/billing-product"]);
    }
    public continueRuralAddress() {
        this.ruralNewAddress = false;
        this.success = true;
    }
    public updateUom(unit) {
        let changedUnit = "";
        switch (unit) {
            case "Kbps":
                changedUnit = "Mbps";
                break;
            case "Mbps":
                changedUnit = "Gbps";
                break;
        }
        return changedUnit;
    }
    public continueWithOrder() {
        this.success = true;
        this.router.navigate(["/move-product"]);
    }
    public backToSingleLine() {
        this.initLoad = true;
        this.ruralNewAddress = false;
        this.asyncSelected = "";
        this.asyncUnitSelected = "";
        this.responseFlag = "";
    }
    public ngOnDestroy() {
        if (this.cartSubscription !== undefined) this.cartSubscription.unsubscribe();
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
        if (this.retainSubscription !== undefined) this.retainSubscription.unsubscribe();
        if (this.cancelOrderSubscription !== undefined) this.cancelOrderSubscription.unsubscribe();
        if (this.holdOrderSubscription !== undefined) this.holdOrderSubscription.unsubscribe();
        if (this.cancelNewOrderSubscription !== undefined) this.cancelNewOrderSubscription.unsubscribe();
        if (this.refreshSessionSubscription !== undefined) this.refreshSessionSubscription.unsubscribe();
        if (this.orderSubscription !== undefined) this.orderSubscription.unsubscribe();
        if (this.billingRecSubscription !== undefined) this.billingRecSubscription.unsubscribe();
        if (this.exisingProdSubscribe !== undefined) this.exisingProdSubscribe.unsubscribe();
        if (this.rmOdrOnHoldObservableSubscrptn !== undefined) this.rmOdrOnHoldObservableSubscrptn.unsubscribe();
        if (this.brcBanSubscription !== undefined) this.brcBanSubscription.unsubscribe();
        if (this.customizeSubscription !== undefined) this.customizeSubscription.unsubscribe();
    }
    /**
     * For getting reasons for Hold
     *
     */
    public getReasonsForHoldDetails() {
        let request: any = {
            rsnType: "HOLD"
        };
        this.loading = true;
        this.logger.log("info", "review-order.component.ts", "ReasonsForHoldRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService
            .getReasonsForHoldCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "review-order.component.ts", "ReasonsForHoldResponse", JSON.stringify(error));
                this.logger.log("error", "review-order.component.ts", "ReasonsForHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                reasonsData => {
                    this.logger.endTime();
                    this.logger.log("info", "review-order.component.ts", "ReasonsForHoldResponse", JSON.stringify(reasonsData ? reasonsData : ""));
                    this.logger.log("info", "review-order.component.ts", "ReasonsForHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.logger.log("info", "hold.component.ts", "orderCompletedHold", '{"TotalTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    this.loading = false;
                    this.holdReasonsList = reasonsData.bmReasonCodes;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "review-order.component.ts", "ReasonsForHoldResponse", JSON.stringify(error));
                    this.logger.log("error", "review-order.component.ts", "ReasonsForHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ReasonsForHoldResponseError", "review-order.component.ts", "Review Order Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ReasonsForHoldResponseError", "review-order.component.ts", "Review Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
        this.loading = false;
    }
    public printHoldReason() {
        this.errorText = "";
        if (this.holdSelectedReason && this.holdSelectedReason !== "Choose reason ..." && this.holdSelectedReason !== "Choose your option..") {
        } else {
            this.errorText = "Please select reason for placing order on Hold";
            return;
        }
    }
    /**
     * On placing order on Hold
     *
     */
    public holdOrder() {
        this.errorText = "";
        if (this.holdSelectedReason && this.holdSelectedReason !== "Choose reason ..." && this.holdSelectedReason !== "Choose your option..") {
            let request: any = {
                success: false,
                orderRefNumber: "",
                processInstanceId: "",
                taskId: "",
                taskName: "Confirm Scheduling",
                payload: {
                    sfdcAccountId: this.sfdcAccountId,
                    salesChannel: "ESHOP-Customer Care",
                    party: {
                        id: this.agentCuid,
                        firstName: this.firstName,
                        lastName: this.lastName,
                        type: "CSR",
                        partyRoles: [
                            {
                                partyRole: env.CSR_NAME,
                                sourceSystem: env.CSR_PROFILE,
                                id: this.agentCuid
                            },
                            {
                                partyRole: env.ENSEMBLEID,
                                sourceSystem: env.ENS_OPERATOR,
                                id: this.ensembleId
                            }
                        ]
                    },
                    interruptAction: "HOLD",
                    reasonType: "HOLD",
                    reasonText: "",
                    reasonList: []
                }
            };
            let reasonRequest: any = {
                code: "",
                description: "",
                waiverFlag: ""
            };
            this.user = <Observable<User>>this.store.select("user");
            let userData;
            let pageIdentifier: string;
            this.userSubscription = this.user.subscribe(data => {
                userData = data;
            });
            if (userData && userData.currentUrl && userData.currentUrl === "/offer-change" || userData.currentUrl === "/vacation-product-offer") {
                pageIdentifier = "existingProducts";
            } else if (userData && userData.currentUrl && userData.currentUrl === "/customize-services") {
                pageIdentifier = "customize";
            } else if (userData && userData.currentUrl && (userData.currentUrl === "/review-order" || userData.currentUrl === "/mo-review-order" || userData.currentUrl === "/co-review-order" || userData.currentUrl === "/vacation-review-order" || userData.currentUrl === "/billing-review-order")) {
                pageIdentifier = "order";
            } else if ((userData && userData.currentUrl && userData.currentUrl === "/pending-order") || userData.currentUrl === "/po-review-order") {
                pageIdentifier = "pending";
            } else if (userData && userData.currentUrl && (userData.currentUrl === "/schedule-appt" || userData.currentUrl === "/schedule-appt-ship" || userData.currentUrl === "/move-schedule-appt-ship" || userData.currentUrl === "/vacation-schedule-appt-ship")) {
                pageIdentifier = "appointment";
            } else if (userData && userData.currentUrl && (userData.currentUrl === "/account" || userData.currentUrl === "/reuse-ban-account" || userData.currentUrl === "/move-account" || userData.currentUrl === "/change-account" || userData.currentUrl === "/vacation-account")) {
                pageIdentifier = "account";
            } else if (userData && userData.currentUrl && userData.currentUrl === "/disconnect-schedule") {
                pageIdentifier = "appointment";
            } else if (userData && userData.currentUrl && userData.currentUrl === "/disconnect-account") {
                pageIdentifier = "account";
            } else if (userData && userData.currentUrl && userData.currentUrl === "/disconnect-review-order") {
                pageIdentifier = "disconnect";
            } else if (userData && userData.currentUrl && userData.currentUrl === "/pending-schedule-appt") {
                pageIdentifier = "pending";
            }
            this.holdorderObservable = this.store.select(pageIdentifier);
            this.holdOrderSubscription = this.holdorderObservable.subscribe(data => {
                if (pageIdentifier === "existingProducts") {
                    request.orderRefNumber = data.orderInit.orderRefNumber;
                    request.processInstanceId = data.orderInit.processInstanceId;
                    request.taskId = data.orderInit.taskId;
                    request.taskName = data.orderInit.taskName;
                } else if (pageIdentifier === "disconnect") {
                    request.orderRefNumber = data.disconnect_review_order.orderRefNumber;
                    request.processInstanceId = data.disconnect_review_order.processInstanceId;
                    request.taskId = data.disconnect_review_order.taskId;
                    request.taskName = data.disconnect_review_order.taskName;
                } else if (pageIdentifier === "pending") {
                    if (data.schedule && data.schedule.orderRefNumber !== undefined) {
                        request.orderRefNumber = data.schedule.orderRefNumber;
                    }
                    if (data.schedule && data.schedule.processInstanceId !== undefined) {
                        request.processInstanceId = data.schedule.processInstanceId;
                    }
                    if (data.schedule && data.schedule.taskId !== undefined) {
                        request.taskId = data.schedule.taskId;
                    }
                    if (data.schedule && data.schedule.taskName !== undefined) {
                        request.taskName = data.schedule.taskName;
                    }
                } else {
                    request.orderRefNumber = data.orderRefNumber;
                    request.processInstanceId = data.processInstanceId;
                    request.taskId = userData.taskId;
                    request.taskName = userData.taskName;
                }
            });
            if (this.holdReasonsList !== null && this.holdReasonsList.length > 0 && this.holdSelectedReason !== undefined) {
                this.holdReasonsList.forEach(item => {
                    if (item.rsnCode === this.holdSelectedReason) {
                        reasonRequest.code = item.rsnCode;
                        reasonRequest.description = item.chgDesc;
                        reasonRequest.waiverFlag = item.ind;
                    }
                });
            }
            request.payload.reasonList = [reasonRequest];
            request.payload.reasonText = this.holdReasonRemark;
            this.logger.log("info", "dialog.component.ts", "getHoldOrderSubmissonRequest", JSON.stringify(request));
            this.logger.startTime();
            this.loading = true;
            this.reviewOrderService.getHoldOrderSubmisson(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.ctlHelperService.setLocalStorage("error", error);
                    return Observable.throw(error._body);
                })
                .subscribe(
                    data => {
                        this.logger.endTime();
                        this.logger.log("info", "dialog.component.ts", "getHoldOrderSubmissonResponse", JSON.stringify(data ? data : ""));
                        this.logger.log("info", "dialog.component.ts", "getHoldOrderSubmissonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        this.holdOrder = data;
                        let PONRResponse = data;
                        this.loading = false;
                        if (PONRResponse.errorResponse !== null && PONRResponse.errorResponse !== undefined && PONRResponse.errorResponse) {
                            this.loading = false;
                            this.holdOrderPONR = true;
                        } else if (this.holdOrder !== undefined) {
                            data = Object.assign({}, data, {
                                reason: reasonRequest.description,
                                additionalNotes: this.holdReasonRemark
                            });
                            if (pageIdentifier === "pending") {
                                this.store.dispatch({ type: "PENDING_SUMMARY", payload: data });
                                this.enable = false;
                                this.visible = false;
                                this.router.navigate(["/po-order-confirmation"]);
                                this.loading = false;
                            } else {
                                this.store.dispatch({ type: "HOLD_ORDER", payload: data });
                                this.enable = false;
                                this.visible = false;
                                this.router.navigate(["/order-confirmation"]);
                                this.loading = false;
                            }
                        }
                        if (this.errModal) {
                            this.errModal.hide();
                        }
                    },
                    error => {
                        this.logger.endTime();
                        this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonResponse", JSON.stringify(error));
                        this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        this.loading = false;
                        if (error === undefined || error === null) return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "orderConfirmationError", "dialog.component.ts", "Hold Order Submission", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                            this.systemErrorService.logAndeRouteToSystemError("error", "orderConfirmationError", "dialog.component.ts", "Hold Order Submission", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    }
                );
        } else {
            this.errorText = "Please select reason for placing order on Hold";
            return;
        }
    }
    public newReferralChange(selectedReferral) {
        if (this.reentrantCallReferral) {
            this.reentrantCallReferral = !this.reentrantCallReferral;
        }
        this.isReferralSelected = selectedReferral;
        if (selectedReferral === "Free Basic Referral" || selectedReferral === "Split Referral") {
            this.latestDays = 90;
        }
        this.referralPopupUpdate();
        if (selectedReferral === "New Number Referral") {
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: selectedReferral,
                price: this.potsPrice
            };
            this.store.dispatch({ type: "CREATE_CART", payload: cartRequest });
        } else if (selectedReferral === "Split Referral") {
            this.potsPrice = 0;
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: selectedReferral,
                price: this.splitRferrralPrice
            };
            this.store.dispatch({ type: "CREATE_CART", payload: cartRequest });
        } else if (selectedReferral === "No referral needed") {
            this.potsPrice = 0;
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: "",
                price: ""
            };
            this.store.dispatch({ type: "CREATE_CART", payload: cartRequest });
        } else if (selectedReferral === "Free Basic Referral") {
            this.potsPrice = 0;
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: "",
                price: ""
            };
            this.store.dispatch({ type: "CREATE_CART", payload: cartRequest });
        }
    }
    public cancelPrepaidOrder() {
        let userData;
        this.loading = true;
        this.userSubscription = this.user.subscribe(data => {
            userData = data;
        });
        this.creditRevObsv = <Observable<CreditCheck>>this.store.select("creditReview");
        this.creditRevObsv.subscribe((data) => {
            this.creditRevObsvData = data;
            if (this.creditRevObsvData.payload &&
                this.creditRevObsvData.payload.currentBillQuote &&
                this.creditRevObsvData.payload.currentBillQuote.accountId && this.prepaid) {
                this.accountID = this.creditRevObsvData.payload.currentBillQuote.accountId;
            }
        });
        let request: any = {
            "accountID": this.accountID,
            "accountStatus": "DISCONNECT",
            "orderReferenceNumber": this.orderReferenceNumber,
            "userDetail": {
                "userId": userData.autoLogin.oamData.agentCuid,
                "userType": userData.profile.loginType
            }
        }
        this.logger.log("info", "dialog.component.ts", "prepaidCancelOrderCodeRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService.prepaidCancelOrderCode(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "prepaidCancelOrderCodeResponse", error);
                this.logger.log("error", "dialog.component.ts", "prepaidCancelOrderCodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "prepaidCancelOrderCode", "dialog.component.ts", "Review Order Page", error);
                return Observable.throwError(null);

            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "prepaidCancelOrderCodeResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "dialog.component.ts", "prepaidCancelOrderCodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.holdOrder = data;
                    this.store.dispatch({ type: "CANCELLED_ORDER", payload: data });
                    this.router.navigate(["/cancelled-order"]);
                },
                (error) => { }
            )
    }
    public cancelOrderBeforeSubmit() {
        let request: any = {
            success: false,
            orderRefNumber: "",
            processInstanceId: "",
            taskId: "",
            taskName: "Confirm Scheduling",
            payload: {
                sfdcAccountId: this.sfdcAccountId,
                salesChannel: "ESHOP-Customer Care",
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
                interruptAction: "TERMINATE",
                reasonType: "CANCELLATION",
                reasonText: "",
                reasonList: [],
                addressChangedFlag: this.addressChanged,
                address: {}
            }
        };
        let reasonRequest: any = {
            code: "",
            description: "",
            waiverFlag: ""
        };
        this.user = <Observable<User>>this.store.select("user");
        let userData;
        let pageIdentifier: string;
        this.userSubscription = this.user.subscribe(data => {
            userData = data;
        });
        // Populate the SFC ID
        if (userData && userData.autoLogin && userData.autoLogin.sfdcID && userData.autoLogin.sfdcBillingAccountID) {
            request.payload.sfdcAccountId = (userData.autoLogin.sfdcBillingAccountID ? userData.autoLogin.sfdcBillingAccountID + ":" : "") + (userData.autoLogin.sfdcID ? userData.autoLogin.sfdcID : "");
        }
        if (userData && userData.currentUrl && userData.currentUrl === "/offer-change") {
            pageIdentifier = "existingProducts";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/change-account") {
            pageIdentifier = "existingProducts";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/amend-account") {
            pageIdentifier = "existingProducts";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/move-account") {
            pageIdentifier = "account";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/customize-services") {
            pageIdentifier = "customize";
        } else if (userData && userData.currentUrl && (userData.currentUrl === "/review-order" || userData.currentUrl === "/mo-review-order" || userData.currentUrl === "/co-review-order" || userData.currentUrl === "/vacation-review-order" || userData.currentUrl === "/billing-review-order")) {
            pageIdentifier = "order";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/product-offer") {
            pageIdentifier = "cart";
        } else if (userData && userData.currentUrl && (userData.currentUrl === "/vacation-schedule-appt-ship" || userData.currentUrl === "/vacation-account")) {
            pageIdentifier = "vacation";
        } else if (userData && userData.currentUrl && (userData.currentUrl === "/schedule-appt" || userData.currentUrl === "/schedule-appt-ship" || userData.currentUrl === "/move-schedule-appt-ship")) {
            pageIdentifier = "appointment";
        } else if (userData && userData.currentUrl && (userData.currentUrl === "/account" || userData.currentUrl === "/move-account" || userData.currentUrl === "/vacation-account")) {
            if (userData.taskName === "Account Information") {
                pageIdentifier = "account";
            } else if (userData.taskName === "Credit Review") {
                pageIdentifier = "creditReview";
            }
        } else if (userData.currentUrl === "/reuse-ban-account") {
            pageIdentifier = "account";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/move-product") {
            pageIdentifier = "cart";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/disconnect-account" || userData.currentUrl === "/vacation-account") {
            pageIdentifier = "account";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/disconnect-review-order") {
            pageIdentifier = "disconnect";
        } else if (userData && userData.currentUrl && (userData.currentUrl === "/disconnect-schedule" || userData.currentUrl === "/billing-schedule-appt-ship")) {
            pageIdentifier = "appointment";
        } else if (userData && userData.currentUrl && (userData.currentUrl === "/pending-order" || userData.currentUrl === "/po-review-order")) {
            pageIdentifier = "pending";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/pending-schedule-appt") {
            pageIdentifier = "pending";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/billing-schedule-appt") {
            pageIdentifier = "existingProducts";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/billing-product") {
            pageIdentifier = "user";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/vacation-option") {
            pageIdentifier = "vacation";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/nonpay-suspend") {
            pageIdentifier = "nonpay-order-flow";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/stack-amend-product") {
            pageIdentifier = "stack-amend-flow";
        } else if (userData && userData.currentUrl && userData.currentUrl === "/change-responsibility") {
            pageIdentifier = "existingProducts";
        }
        this.cancelNewOrderObservable = this.store.select(pageIdentifier);
        this.cancelNewOrderSubscription = this.cancelNewOrderObservable.subscribe(
            data => {
                if (pageIdentifier === "existingProducts" || pageIdentifier === "user") {
                    if (userData.currentUrl === "/change-responsibility") {
                        request.orderRefNumber = data.changeRespInit.orderRefNumber;
                        request.processInstanceId = data.changeRespInit.processInstanceId;
                        request.taskId = data.changeRespInit.taskId;
                        request.taskName = data.changeRespInit.taskName;
                    } else {
                        request.orderRefNumber = data.orderInit.orderRefNumber;
                        request.processInstanceId = data.orderInit.processInstanceId;
                        request.taskId = data.orderInit.taskId;
                        request.taskName = data.orderInit.taskName;
                    }
                } else if (pageIdentifier === "disconnect") {
                    request.orderRefNumber = data.disconnect_review_order.orderRefNumber;
                    request.processInstanceId = data.disconnect_review_order.processInstanceId;
                    request.taskId = data.disconnect_review_order.taskId;
                    request.taskName = data.disconnect_review_order.taskName;
                } else if (pageIdentifier === "pending") {
                    request.orderRefNumber = data.schedule.orderRefNumber;
                    request.processInstanceId = data.schedule.processInstanceId;
                    request.taskId = data.schedule.taskId;
                    request.taskName = data.schedule.taskName;
                } else if (pageIdentifier === 'nonpay-order-flow') {
                    request.orderRefNumber = this.nonpaySuspendRestoreInitData.orderRefNumber;
                    request.processInstanceId = this.nonpaySuspendRestoreInitData.processInstanceId;
                    request.taskId = this.nonpaySuspendRestoreInitData.taskId;
                    request.taskName = this.nonpaySuspendRestoreInitData.taskName;
                } else if (pageIdentifier === 'vacation') {
                    if (this.vacationResData) {
                        request.orderRefNumber = this.vacationResData.orderRefNumber;
                        request.processInstanceId = this.vacationResData.processInstanceId;
                        request.taskId = this.vacationResData.taskId;
                        request.taskName = this.vacationResData.taskName;
                    } else {
                        let storedRequestProcessData = this.ctlHelperService.getLocalStorage('storedRequestProcessData');
                        storedRequestProcessData && storedRequestProcessData.map(data => {
                            if (userData.currentUrl === data.currentUrl) {
                                request.orderRefNumber = data.orderRefNumber;
                                request.processInstanceId = data.processInstanceId;
                                request.taskId = data.taskId;
                                request.taskName = data.taskName;
                            }
                            if (userData.currentUrl === '/vacation-option' && data.requestType === 'init' && data.currentUrl === '/existing-products') {
                                request.orderRefNumber = data.orderRefNumber;
                                request.processInstanceId = data.processInstanceId;
                                request.taskId = data.taskId;
                                request.taskName = data.taskName;
                            }
                        })
                    }
                } else if (pageIdentifier === 'stack-amend-flow') {
                    request.orderRefNumber = this.stackData && this.stackData.orderRefNumber;
                    request.processInstanceId = this.stackData && this.stackData.processInstanceId;
                    request.taskId = this.stackData && this.stackData.taskId;
                    request.taskName = this.stackData && this.stackData.taskName;
                } else {
                    request.orderRefNumber = data.orderRefNumber ? data.orderRefNumber : this.vacationopton.orderRefNumber;
                    request.processInstanceId = data.processInstanceId ? data.processInstanceId : this.vacationopton.processInstanceId;
                    request.taskId = data.taskId ? data.taskId : this.vacationopton.taskId;
                    request.taskName = data.taskName ? data.taskName : this.vacationopton.taskName;
                }
            }
        );
        request.payload.reasonList = [reasonRequest];
        if (!this.addressChanged) {
            if (userData && userData.orderInit && userData.orderInit !== undefined && userData.orderInit.payload !== undefined) {
                let address = this.formingAddressObjectForDeposit([userData.orderInit.payload.serviceAddress]);
                request.payload.address = address[0];
            }
        } else {
            request.payload.address = userData && userData.depositAddress !== undefined && userData.depositAddress;
        }
        request.payload.reasonText = this.cancelReasonRemark;
        this.logger.log("info", "dialog.component.ts", "getHoldOrderSubmissonRequest", JSON.stringify(request));
        this.logger.startTime();
        this.loading = true;
        this.reviewOrderService
            .getHoldOrderSubmisson(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getHoldOrderSubmissonResponse", JSON.stringify(data ? data : ""));
                    this.logger.log("info", "dialog.component.ts", "getHoldOrderSubmissonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.holdOrder = data;
                    if (this.holdOrder !== undefined) {
                        data = Object.assign({}, data, {
                            reason: reasonRequest.description,
                            additionalNotes: this.holdReasonRemark
                        });
                        this.store.dispatch({ type: "HOLD_ORDER", payload: data });
                        this.enable = false;
                        this.visible = false;
                        this.router.navigate(["/order-cancelled"]);
                        this.loading = false;
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "getHoldOrderSubmissonSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "orderConfirmationError", "dialog.component.ts", "Cancel Order Before Submission", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "orderConfirmationError", "dialog.component.ts", "Cancel Order Before Submission", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public getReasonsForCancelDetails() {
        this.loading = true;
        this.logger.log("info", "review-order.component.ts", "ReasonsForHoldRequest", JSON.stringify("CANCELLATION"));
        this.logger.startTime();
        let request: any = {
            rsnType: "CANCELLATION"
        };
        this.reviewOrderService.getReasonsForHoldCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "review-order.component.ts", "ReasonsForHoldResponse", JSON.stringify(error));
                this.logger.log("error", "review-order.component.ts", "ReasonsForHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                return Observable.throw(error._body);
            })
            .subscribe(
                reasonsData => {
                    this.logger.endTime();
                    this.logger.log("info", "review-order.component.ts", "ReasonsForHoldResponse", JSON.stringify(reasonsData ? reasonsData : ""));
                    this.logger.log("info", "review-order.component.ts", "ReasonsForHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.cancelReasonsList = reasonsData.bmReasonCodes;
                    this.loading = false;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "review-order.component.ts", "ReasonsForHoldResponse", JSON.stringify(error));
                    this.logger.log("error", "review-order.component.ts", "ReasonsForHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ReasonsForHoldResponseError", "review-order.component.ts", "Reason For Cancel", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ReasonsForHoldResponseError", "review-order.component.ts", "Reason For Cancel", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
        this.loading = false;
    }
    public printCancelReason() { }
    public backToSummary() {
        this.router.navigate(["/pending-order"]);
    }
    public refreshSession() {
        let customerOrderNumber;
        this.refreshSessionObservable = this.store.select("pending");
        this.refreshSessionSubscription = this.refreshSessionObservable.subscribe(
            data => {
                customerOrderNumber = data.orderReference.customerOrderNumber;
            }
        );
        let request = { customerOrderNumber: customerOrderNumber };
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "getOrderSummaryRequest", JSON.stringify(request));
        this.logger.startTime();
        this.pendingOrderService
            .getOrderSummary(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "getOrderSummaryResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                if (error && error.status === 404) {
                    this.errorMsg = "Account/Order Number/Order Reference Number does not exist!!!";
                    this.existingError = true;
                    this.formShow = false;
                } else {
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "pendingSummary - getOrderSummary", "address.component.ts", "Address Page", error);
                    return Observable.throwError(null);
                }
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "getOrderSummaryResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].existingServices) {
                        let fnm = "", lnm = "", phn = "";
                        if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.accountName) {
                            fnm = data.existingProductsAndServices[0].accountInfo.accountName.firstName;
                            lnm = data.existingProductsAndServices[0].accountInfo.accountName.lastName;
                        }
                        if (data.existingProductsAndServices && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.contact) {
                            phn = data.existingProductsAndServices[0].accountInfo.contact.contactNumber;
                        }
                        let callerInfo: ContactInfo = {
                            firstName: fnm,
                            lastName: lnm,
                            phoneNumber: phn
                        };
                        this.store.dispatch({ type: "UPDATE_USER", payload: callerInfo });
                        this.store.dispatch({ type: "EXISTING_PRODUCTS", payload: data });
                        this.router.navigate(["/existing-products"]);
                    } else if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].pendingOrders && data.existingProductsAndServices[0].pendingOrders.length > 0) {
                        this.logger.endTime();
                        this.logger.log("info", "dialog.component.ts", "retrieveProductsAndServicesResponse", JSON.stringify(data));
                        this.logger.log("info", "dialog.component.ts", "retrieveProductsAndServicesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                        let index = data.existingProductsAndServices[0].pendingOrders.length - 1;
                        data = data.existingProductsAndServices[0].pendingOrders[index];
                        if (data.orderReference.customerOrderStatus === "PENDING") {
                            let fnm = "", lnm = "", phn = "";
                            if (data.orderDocument.createAccount && data.orderDocument.createAccount.accountName) {
                                fnm = data.orderDocument.createAccount.accountName.firstName;
                                lnm = data.orderDocument.createAccount.accountName.lastName;
                            }
                            if (data.orderDocument.createAccount && data.orderDocument.createAccount.contact) {
                                phn = data.orderDocument.createAccount.contact.contactNumber;
                            }
                            let callerInfo: ContactInfo = {
                                firstName: fnm,
                                lastName: lnm,
                                phoneNumber: phn
                            };
                            this.store.dispatch({ type: "UPDATE_USER", payload: callerInfo });
                            this.store.dispatch({ type: "PENDING_SUMMARY", payload: data });
                            this.router.navigate(["/pending-order"]);
                        } else {
                            this.errorMsg = "No Pending Orders found!!!";
                            this.existingError = true;
                            this.formShow = false;
                        }
                    } else {
                        this.errorMsg = "Account/Order/Order Reference Number does not exist!!!";
                        this.existingError = true;
                        this.formShow = false;
                    }
                    this.loading = false;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "getOrderSummaryResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "getCustomerOrderByBANAndCustomerOrderNumberResponseError", "dialog.component.ts", "Address Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "getCustomerOrderByBANAndCustomerOrderNumberResponseError", "dialog.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public popupCenter(url, w, h) {
        var left = screen.width / 2 - w / 2;
        var top = screen.height / 2 - h / 2;
        return window.open(url, "", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=" + w + ", height=" + h + ", top=" + top + ", left=" + left);
    }
    public getReasonsForUnHoldOrder() {
        this.loading = true;
        this.logger.log("info", "review-order.component.ts", "ReasonForUnHoldOrderRequest", JSON.stringify("HOLD"));
        this.logger.startTime();
        let request: any = {
            rsnType: "HOLD"
        };
        this.reviewOrderService.getReasonsForHoldCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "review-order.component.ts", "ReasonForUnHoldOrderResponse", JSON.stringify(error));
                this.logger.log("error", "review-order.component.ts", "ReasonForUnHoldOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "ReasonForUnHoldOrderResponse", "review-order.component.ts", "UnHold Order", error);
                return Observable.throwError(null);
            })
            .subscribe(
                reasonsData => {
                    this.logger.endTime();
                    this.logger.log("info", "review-order.component.ts", "ReasonForUnHoldOrderResponse", JSON.stringify(reasonsData));
                    this.logger.log("info", "review-order.component.ts", "ReasonForUnHoldOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.unHoldReasonList = reasonsData.bmReasonCodes;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "review-order.component.ts", "ReasonForUnHoldOrderResponse", JSON.stringify(error));
                    this.logger.log("error", "review-order.component.ts", "ReasonForUnHoldOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ReasonForUnHoldOrderResponseError", "review-order.component.ts", "UnHold Order", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ReasonForUnHoldOrderResponseError", "review-order.component.ts", "UnHold Order", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
        this.loading = false;
    }
    public removeOrderFromHold() {
        let flow: any;
        let request: any = {
            orderRefNumber: "",
            payload: {
                sfdcAccountId: this.sfdcAccountId,
                salesChannel: "ESHOP-Customer Care",
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
                interruptAction: "UNHOLD",
                reasonType: "HOLD",
                reasonText: "",
                reasonList: []
            }
        };
        let reasonRequest: any = {
            code: "",
            description: "",
            waiverFlag: ""
        };
        this.logger.startTime();
        this.rmOdrOnHoldObservable = <Observable<User>>this.store.select("pending");
        let orderFlow;
        this.rmOdrOnHoldObservableSubscrptn = this.rmOdrOnHoldObservable.subscribe(
            data => {
                flow = data.orderReference.customerOrderType;
                request.orderRefNumber = data.orderReference.orderReferenceNumber;
                let payload = {
                    dueDate: data.orderDocument.schedule.dates,
                    availableAppointment: data.orderDocument.schedule.appointmentInfo,
                    apptNotes: data.orderDocument.schedule.apptNotes,
                    shippingInfo: null,
                    cart: null
                };
                let appointmentObj = {
                    success: true,
                    orderRefNumber: data.orderRefNumber,
                    processInstanceId: data.processInstanceId,
                    taskId: data.taskId,
                    taskName: data.taskName,
                    payload: payload
                };
                this.store.dispatch({
                    type: "AVAILABLE_APPOINTMENTS",
                    payload: appointmentObj
                });
                this.customerOrderItems = {
                    customerOrderItems: data.orderDocument.customerOrderItems
                };
                orderFlow = {
                    flow:
                        data.orderReference.customerOrderType.charAt(0).toUpperCase() +
                        data.orderReference.customerOrderType.slice(1).toLowerCase(),
                    type: "fromHold"
                };
                this.store.dispatch({ type: "ORDER_FlOW", payload: orderFlow });
                this.selected = "";
                for (let i = 0; i < data.orderDocument.customerOrderItems.length; i++) {
                    let offerCategory =
                        data.orderDocument.customerOrderItems[i].offerCategory;
                    if (offerCategory === "INTERNET") {
                        this.selected = "Internet,";
                    } else if (offerCategory === "VOICE-HP") {
                        this.selected += "HMPhone";
                    } else if (offerCategory === "VOICE-DHP") {
                        this.selected += "DHPhone";
                    } else if (offerCategory === "VIDEO-DTV") {
                        this.selected += "TV";
                    }
                }
                let cart: ShoppingCart;
                cart = {
                    selectedService: this.selected
                };
                this.store.dispatch({ type: "CREATE_CART", payload: cart });
            }
        );
        if (this.unHoldReasonList !== null && this.unHoldReasonList.length > 0 && this.unHoldSelectedReason !== undefined) {
            this.unHoldReasonList.forEach(item => {
                if (item.rsnCode === this.unHoldSelectedReason) {
                    reasonRequest.code = item.rsnCode;
                    reasonRequest.description = item.chgDesc;
                    reasonRequest.waiverFlag = item.ind;
                }
            });
        }
        request.payload.reasonList = [reasonRequest];
        request.payload.reasonText = this.unHoldReasonRemark;
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "ReviewHoldOrderConfirmRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService
            .removeOrderFromHold(request, flow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "ReviewHoldOrderConfirmResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "ReviewHoldOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "ReviewHoldOrderConfirmSrvcResponse", "dialog.component.ts", "Hold Order Submit - Dialog", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "ReviewHoldOrderConfirmResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "ReviewHoldOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.removeOrderFromHold = data;
                    let taskNameFromResponse = data.taskName;
                    if (this.removeOrderFromHold !== undefined) {
                        data = Object.assign({}, data, {
                            reason: reasonRequest.description,
                            additionalNotes: this.unHoldReasonRemark
                        });
                        this.store.dispatch({ type: "HOLD_ORDER", payload: data });
                        this.enable = false;
                        if (taskNameFromResponse === "Checkout & Scheduling") {
                            let payload = {
                                cart: {
                                    catalogSpecId: data.payload.cart.catalogSpecId,
                                    customerOrderItems: data.payload.cart.customerOrderItems
                                },
                                customerAddonOfferItems: data.payload.addOnOffers,
                                productConfiguration: data.payload.productConfiguration,
                                addOnOffers: data.payload.addOnOffers,
                                reservedTN: data.payload.reservedTN
                            };
                            this.cartObject = {
                                success: data.success,
                                orderRefNumber: data.orderRefNumber,
                                processInstanceId: data.processInstanceId,
                                taskId: data.taskId,
                                taskName: data.taskName,
                                payload: payload
                            };
                            let custObj = {
                                success: data.success,
                                orderRefNumber: data.orderRefNumber,
                                processInstanceId: data.processInstanceId,
                                taskId: data.taskId,
                                taskName: data.taskName,
                                payload: payload
                            };
                            this.store.dispatch({ type: "CREATE_CUSTOMIZE_ADDONS", payload: custObj });
                            this.store.dispatch({ type: "CREATE_CUSTOMIZE_ADDONS", payload: custObj });
                            this.store.dispatch({ type: "CREATE_CART", payload: this.cartObject });
                            this.store.dispatch({ type: "TASK_ID", payload: data.taskId });
                            this.store.dispatch({ type: "ADD-ONS", payload: this.cartObject });
                            let selectProduct = {
                                taskName: "Select Product"
                            };
                            this.store.dispatch({ type: "SELECT_PRODUCT", payload: selectProduct });
                            if (flow !== "CHANGE") this.visible = false;
                            if (flow === "MOVE") {
                                this.existDataDispatch(data, orderFlow);
                                this.router.navigate(["/move-product"]);
                            } else if (flow === "CHANGE") {
                                this.existDataDispatch(data, orderFlow);
                            } else if (flow === "BILLANDREC") {
                                this.router.navigate(["/billing-product"]);
                            } else {
                                this.router.navigate(["/product-offer"]);
                            }
                        } else if (taskNameFromResponse === "Confirm Scheduling" || taskNameFromResponse === "Schedule Disconnect Date") {
                            data.payload.cart = this.customerOrderItems;
                            let cartObjToDispatch = {
                                payload: {
                                    cart: this.customerOrderItems
                                }
                            };
                            this.store.dispatch({ type: "CREATE_CART", payload: cartObjToDispatch });
                            let scheduleObj = {
                                orderRefNumber: data.orderRefNumber,
                                processInstanceId: data.processInstanceId,
                                taskId: data.taskId,
                                taskName: data.taskName,
                                payload: data.payload
                            };
                            this.store.dispatch({ type: "SCHEDULING", payload: scheduleObj });
                            let cartObj = {
                                orderRefNumber: data.orderRefNumber,
                                processInstanceId: data.processInstanceId,
                                taskId: data.taskId,
                                taskName: data.taskName,
                                payload: data.payload
                            };
                            this.store.dispatch({ type: "ADD-ONS", payload: cartObj });
                            let selectProduct = {
                                taskName: "Select Product"
                            };
                            this.store.dispatch({ type: "SELECT_PRODUCT", payload: selectProduct });
                            let appointmentObj = {
                                success: true,
                                orderRefNumber: data.orderRefNumber,
                                processInstanceId: data.processInstanceId,
                                taskId: data.taskId,
                                taskName: data.taskName,
                                payload: data.payload
                            };
                            this.store.dispatch({ type: "TASK_ID", payload: data.taskId });
                            this.store.dispatch({ type: "AVAILABLE_APPOINTMENTS", payload: appointmentObj });
                            if (flow === "BILLANDREC") {
                                this.router.navigate(["/billing-schedule-appt-ship"]);
                            } else if (flow === "DISCONNECT") {
                                this.router.navigate(["/disconnect-schedule"]);
                            } else {
                                if (flow !== "CHANGE") this.visible = false;
                                if (flow === "MOVE") {
                                    this.existDataDispatch(data, orderFlow);
                                    this.router.navigate(["/move-product"]);
                                } else if (flow === "CHANGE") {
                                    this.existDataDispatch(data, orderFlow);
                                } else if (flow === "BILLANDREC") {
                                    this.router.navigate(["/billing-product"]);
                                } else {
                                    this.router.navigate(["/product-offer"]);
                                }
                            }
                            this.store.dispatch({ type: "UPDATE_USER", payload: { oTCustomize: true } });
                        }
                        if (flow !== "CHANGE") this.loading = false;
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "ReviewHoldOrderConfirmResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "ReviewHoldOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ReviewHoldOrderConfirmSrvcResponseError", "dialog.component.ts", "Hold Order Submit - Dialog", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ReviewHoldOrderConfirmSrvcResponseError", "dialog.component.ts", "Hold Order Submit - Dialog", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public removeFromHoldWhenDueDateZero() {
        if (this.unHoldReasonList !== null && this.unHoldReasonList.length > 0 && this.unHoldSelectedReason !== undefined) {
            this.unHoldReasonList.forEach(item => {
                if (item.rsnCode === this.unHoldSelectedReason) {
                    let reasonRequest = {
                        code: item.rsnCode,
                        description: item.chgDesc,
                        waiverFlag: item.ind,
                        reasonText: this.unHoldReasonRemark
                    };
                    this.store.dispatch({ type: "UNHOLD_REASON_REMARK", payload: { reasonRequest } });
                }
            });
        }
        this.close(true);
    }
    private existDataDispatch(data: any, orderFlow) {
        let existingObject;
        let pendingSubscription;
        this.refreshSessionObservable = this.store.select("pending");
        let sfdcAccountId, sfdcBillingAccountID, agentFullName, agentCuid, firstName, lastName, ensembleId;
        let userSubscribe = this.user.subscribe(data => {
            if (data.autoLogin !== null && data.autoLogin !== undefined) {
                if (data.autoLogin.sfcData && data.autoLogin.sfcData.sfdcID !== null && data.autoLogin.sfcData.sfdcID !== undefined && data.autoLogin.sfcData.sfdcID.length > 0) {
                    sfdcAccountId = data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : "";
                    sfdcBillingAccountID = data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID : "";
                }
                if (data.autoLogin.oamData) {
                    agentCuid = data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : "";
                    firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    agentFullName = data.autoLogin.oamData.agentFullName ? data.autoLogin.oamData.agentFullName : "";
                    ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId;
                }
            }
        });
        if (userSubscribe !== undefined) userSubscribe.unsubscribe();
        pendingSubscription = this.refreshSessionObservable.subscribe(pending => {
            let existingServices = {
                existingServiceItems: pending.orderDocument.existingServices
            };
            existingObject = {
                existingProductsAndServices: [pending && pending.orderDocument]
            };
            existingObject.existingProductsAndServices[0].existingServices = existingServices;
            existingObject.orderFlow = orderFlow;
        });
        if (pendingSubscription !== undefined) pendingSubscription.unsubscribe();
        this.store.dispatch({ type: "EXISTING_PRODUCTS", payload: existingObject });
        if (orderFlow.flow === "Change") {
            this.loading = true;
            let serviceCategories;
            let banRequest = {
                ban: existingObject.existingProductsAndServices[0].accountInfo.ban
            };
            this.loading = true;
            this.logger.log("info", "address.component.ts", "getOrderSummaryRequest", JSON.stringify(banRequest));
            this.logger.startTime();
            this.pendingOrderService
                .getOrderSummary(banRequest)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "address.component.ts", "getOrderSummaryResponse", JSON.stringify(error));
                    this.logger.log("error", "address.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error && error.status === 404) {
                        this.errorMsg = "Account/Order Number does not exist!!!";
                        this.existingError = true;
                        this.formShow = false;
                    } else {
                        this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "pendingSummary - getOrderSummary", "address.component.ts", "Address Page", error);
                        return Observable.throwError(null);
                    }
                })
                .subscribe(data => {
                    this.logger.endTime();
                    this.logger.log("info", "address.component.ts", "getOrderSummaryResponse", JSON.stringify(data));
                    this.logger.log("info", "address.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].telephoneNumber) {
                        this.store.dispatch({ type: "EXISTING_TN", payload: data.existingProductsAndServices[0].telephoneNumber });
                    }
                    serviceCategories = data.existingProductsAndServices[0].serviceCategory;
                    let request;
                    request = {
                        ban: data.existingProductsAndServices[0].accountInfo.ban,
                        customerOrderType: "CHANGE",
                        party: {
                            id: agentCuid,
                            firstName: firstName,
                            lastName: lastName,
                            type: "CSR",
                            partyRoles: [
                                {
                                    partyRole: env.CSR_NAME,
                                    sourceSystem: env.CSR_PROFILE,
                                    id: agentCuid
                                },
                                {
                                    partyRole: env.ENSEMBLEID,
                                    sourceSystem: env.ENS_OPERATOR,
                                    id: ensembleId
                                }
                            ]
                        },
                        salesChannel: "ESHOP-Customer Care",
                        serviceAddress: {
                            city: "",
                            country: "",
                            geoAddressId: "",
                            locality: "",
                            postCode: "",
                            postCodeSuffix: "",
                            source: "",
                            sourceId: "",
                            stateOrProvince: "",
                            streetAddress: "",
                            streetName: "",
                            streetNrFirst: "",
                            streetNrFirstSuffix: "",
                            streetNrLast: "",
                            streetNrLastSuffix: "",
                            streetType: "",
                            subAddress: {
                                combinedDesignator: "",
                                elements: {
                                    designator: "",
                                    value: ""
                                },
                                geoSubAddressId: "",
                                source: "",
                                sourceId: ""
                            }
                        }
                    };
                    if (sfdcBillingAccountID && sfdcAccountId) {
                        request.sfdcAccountId = (sfdcBillingAccountID ? sfdcBillingAccountID + ":" : "") + (sfdcAccountId ? sfdcAccountId : "");
                    }
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0]) {
                        let internetCheck;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (serviceCategories !== undefined) {
                            serviceCategories.map(item => {
                                if (item.serviceCategory === GenericValues.sData) {
                                    internetCheck = true;
                                }
                                if (item.serviceCategory === "DATA/VIDEO") {
                                    videoAvail = true;
                                    videoType.push({
                                        name: "DATA/VIDEO",
                                        displayName: "PRISM TV",
                                        code: "PTV",
                                        tabName: "PRISM"
                                    });
                                }
                                if (item.serviceCategory === "VIDEO-DTV") {
                                    videoAvail = true;
                                    videoType.push({
                                        name: "VIDEO-DTV",
                                        displayName: "DIRECTV",
                                        code: "DTV",
                                        tabName: "DIRECTV"
                                    });
                                }
                                if (item.serviceCategory === "VOICE-DHP") {
                                    phoneAvail = true;
                                    phoneType.push({
                                        name: "VOICE-DHP",
                                        displayName: "Digital(DHP)",
                                        code: "DHP",
                                        tabName: "DHP"
                                    });
                                }
                                if (item.serviceCategory === "VOICE-HP") {
                                    phoneAvail = true;
                                    phoneType.push({
                                        name: "VOICE-HP",
                                        displayName: "Home Phone",
                                        code: "HMP",
                                        tabName: "Home Phone"
                                    });
                                }
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: serviceCategories,
                            ban: data.existingProductsAndServices[0].accountInfo.ban
                        };
                        this.store.dispatch({ type: "CHANGE_UPDATE_USER", payload: user });
                    }
                    this.logger.log("info", "existing-products.component.ts", "getInitChangeCallRequest", JSON.stringify(request));
                    this.logger.startTime();
                    this.loading = true;
                    this.addressService
                        .getInitChangeCall(request)
                        .catch((error: any) => {
                            this.logger.endTime();
                            this.logger.log("error", "existing-products.component.ts", "getInitChangeCallResponse", JSON.stringify(error));
                            this.logger.log("error", "existing-products.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                            this.loading = false;
                            this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                            return Observable.throwError(null);
                        })
                        .subscribe(
                            address => {
                                this.logger.endTime();
                                this.logger.log("info", "existing-products.component.ts", "getInitChangeCallResponse", JSON.stringify(address));
                                this.logger.log("info", "existing-products.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                                data.orderInit = address;
                                this.orderSubscription = this.orderObservable.subscribe(ord => {
                                    address.orderRefNumber = ord.orderRefNumber;
                                    address.processInstanceId = ord.processInstanceId;
                                    address.taskId = ord.taskId;
                                    this.store.dispatch({ type: "CHANGE_ORDER_INIT", payload: address });
                                });
                                if (this.orderSubscription !== undefined)
                                    this.orderSubscription.unsubscribe();
                                this.visible = false;
                                this.router.navigate(["/offer-change"]);
                            },
                            error => {
                                this.logger.endTime();
                                this.logger.log("error", "existing-products.component.ts", "getInitChangeCallResponse", JSON.stringify(error));
                                this.logger.log("error", "existing-products.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                                this.loading = false;
                                if (error === undefined || error === null) return;
                                let unexpectedError = false;
                                if (this.ctlHelperService.isJson(error)) {
                                    this.apiResponseError = JSON.parse(error);
                                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                                    } else unexpectedError = true;
                                } else unexpectedError = true;
                                if (unexpectedError) {
                                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(
                                        null
                                    );
                                    this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", lAPIErrorLists);
                                }
                            }
                        );
                });
        }
    }
    /**
     * CALL REFERRAL
     */
    public referralResponse: any;
    public splitReferralMonthCount: number;
    public splitRferrralPrice: string;
    public referralType: string;
    public newReferralPriceArray: any = [];
    public existingTN: any;
    public NewTN: any;
    public dt: Date;
    private referralSetDate: any;
    private viewDate: any;
    private latestDays: number;
    public earliestDays: any;
    private latestMonth: any;
    public isSelectedOpt: any;
    private exactDueDate: any;
    private reentrant = false;
    public monthSelected: any;
    @Input() public reentrantCallReferral: boolean;
    @Input() public dateChanged;
    @Input() public dateInfo;
    @Input() public lifelineInternetAdded;
    @Input() public lifelinePotsAdded;
    @Input() public currUrl: any;
    @Input() public fromHold: boolean;
    @Input() public internerOffer: any;
    @Input() public selectedSalesExpiresOfferId: any;
    public callCancelBeforeSubmit: boolean = false;
    public ngOnChanges(changes: SimpleChanges) {
        if (changes["dateChanged"]) {
            if (this.dateChanged !== undefined) {
                this.exactDueDate = this.dateInfo;
            }
        }
    }
    @Input() set reentrantData(event: any) {
        if (this.reentrantCallReferral) {
            this.reentrant = true;
            if (event && event.account && event.account.payload && event.account.payload.productConfiguration && event.account.payload.productConfiguration[0] && event.account.payload.productConfiguration[0].configItems && event.account.payload.productConfiguration[0].configItems[0]) {
                let x = event.account.payload.productConfiguration[0].configItems[0];
                this.isReferralSelected = x.productName;
                x.configDetails[0].formItems.map(val => {
                    if (this.isReferralSelected === "Split Referral") {
                        if (val.attributeName === "Name2") {
                            this.splitReferralName2 = val.attributeValue[0].value;
                        } else if (val.attributeName === "Name1") {
                            this.splitReferralName1 = val.attributeValue[0].value;
                        } else if (val.attributeName === "Referral End date") {
                            this.referralSetDate = val.attributeValue[0].value;
                        } else if (val.attributeName === "Referral Number 1") {
                            this.splitReferralNumber1 = val.attributeValue[0].value;
                        } else if (val.attributeName === "Referral Number 2") {
                            this.splitReferralNumber2 = val.attributeValue[0].value.substr(0, 10);
                        }
                    } else if (this.isReferralSelected === "New Number Referral") {
                        if (val.attributeName === "Referral End date") {
                            this.referralSetDate = val.attributeValue[0].value;
                        } else if (val.attributeName === "Referral Number") {
                            this.newReferralNumber = val.attributeValue[0].value;
                        }
                        this.monthSelected = event.monthSelected;
                    } else if (this.isReferralSelected === "Free Basic Referral") {
                        if (val.attributeName === "Referral End date") {
                            this.referralSetDate = val.attributeValue[0].value;
                        }
                    }
                });
            }
        }
    }
    @Input() set referral(event: any) {
        this.referralResponse = event;
        if (this.referralResponse && this.referralResponse.payload && this.referralResponse.payload.existingTn && this.referralResponse.payload.existingTn.length > 0) {
            this.referralResponse.payload.existingTn.map(tn => {
                if (tn.productType === GenericValues.cHP) {
                    this.existingTN = this.ctlHelperService.maskTelephone(tn.requestedTelephoneNumber);
                }
            });
        }
        if (this.referralResponse && this.referralResponse.payload && this.referralResponse.payload.accountName) {
            this.splitReferralName1 = this.referralResponse.payload.accountName.firstName + " " + this.referralResponse.payload.accountName.lastName;
        }
        if (this.orderFlow === "Disconnect") {
            this.newReferralNumber = this.ctlHelperService.maskTelephone(this.newReferralNumber);
            this.splitReferralNumber1 = this.ctlHelperService.maskTelephone(this.splitReferralNumber1);
        } else {
            if (this.referralResponse && this.referralResponse.payload && this.referralResponse.payload.reservedTn && this.referralResponse.payload.reservedTn.length > 0) {
                this.referralResponse.payload.reservedTn.map(newRefTn => {
                    if (newRefTn.productType === GenericValues.cHP) {
                        this.NewTN = this.ctlHelperService.maskTelephone(newRefTn.requestedTelephoneNumber);
                        if (!this.reentrant && this.existingTN !== this.NewTN) {
                            this.newReferralNumber = this.ctlHelperService.maskTelephone(newRefTn.requestedTelephoneNumber);
                            this.splitReferralNumber1 = this.ctlHelperService.maskTelephone(newRefTn.requestedTelephoneNumber);
                        } else if (this.reentrant) {
                            this.newReferralNumber = this.ctlHelperService.maskTelephone(this.newReferralNumber);
                            this.splitReferralNumber1 = this.ctlHelperService.maskTelephone(this.splitReferralNumber1);
                        } else {
                            this.newReferralNumber = "";
                            this.splitReferralNumber1 = "";
                        }
                        if (this.reentrant && this.existingTN !== this.NewTN) {
                            if (this.isReferralSelected === "Split Referral") {
                                this.newReferralNumber = this.ctlHelperService.maskTelephone(newRefTn.requestedTelephoneNumber);
                                this.splitReferralNumber1 = this.ctlHelperService.maskTelephone(this.splitReferralNumber1);
                            } else if (this.isReferralSelected === "New Number Referral") {
                                this.newReferralNumber = this.ctlHelperService.maskTelephone(this.newReferralNumber);
                                this.splitReferralNumber1 = this.ctlHelperService.maskTelephone(newRefTn.requestedTelephoneNumber);
                            }
                        }
                    }
                });
            }
        }
        if (this.referralResponse.payload.offers === undefined) {
            let retainVal = <Observable<any>>this.store.select("retain");
            retainVal.subscribe(retVal => {
                this.referralResponse.payload.offers =
                    retVal && retVal.retainoffers !== undefined && retVal.retainoffers;
            });
        }
        this.referralResponse.payload &&
            this.referralResponse.payload.offers &&
            this.referralResponse.payload.offers.retrievalTypes &&
            this.referralResponse.payload.offers.retrievalTypes.map(retrievalType => {
                retrievalType && retrievalType.offers && retrievalType.offers.map((offer) => {
                    offer.catalogs.map(catalog => {
                        catalog.catalogItems.map(catalogItem => {
                            if (catalogItem.productOffer.offerName === "Call Referral") {
                                catalogItem.productOffer.productComponents.map(product => {
                                    this.referralType = product.product.productName;
                                    if (this.referralType === "Split Referral") {
                                        product.product.productAttributes.map(productAttr => {
                                            if (productAttr.isPriceable) {
                                                productAttr && productAttr.compositeAttribute && productAttr.compositeAttribute.map(compAttr => {
                                                    if (compAttr.attributeName === "Duration") {
                                                        this.splitReferralMonthCount = compAttr.attributeValue;
                                                    }
                                                });
                                                productAttr && productAttr.prices && productAttr.prices.map(price => {
                                                    this.splitRferrralPrice = price.otc;
                                                });
                                            }
                                        });
                                    } else if (this.referralType === "New Number Referral") {
                                        product.product.productAttributes.map(productAttr => {
                                            if (productAttr.isPriceable) {
                                                let monthCount = "";
                                                let priceValue = "";
                                                productAttr.compositeAttribute.map(compAttr => {
                                                    if (compAttr.attributeName === "Duration") {
                                                        monthCount = compAttr.attributeValue;
                                                    }
                                                });
                                                productAttr.prices.map(price => {
                                                    priceValue = price.otc;
                                                    this.newReferralPriceArray.push({
                                                        month: monthCount,
                                                        price: priceValue
                                                    });
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    });
                });
            });
    }
    public getDate(): number {
        return (this.dt && this.dt.getTime()) || new Date().getTime();
    }
    public saveReferral() {
        this.fillDetailsForProductConfigAndCart();
    }
    private diff_months(dt2, dt1) {
        var diff = (new Date(dt2).getTime() - new Date(dt1).getTime()) / 1000;
        diff /= 60 * 60 * 24 * 7 * 4;
        return Math.abs(Math.round(diff));
    }
    private freeReferralEndDate = "";
    private newReferralNumber = "";
    private newReferralEndDateValue = "";
    private newReferralMonthCount = 0;
    private splitReferralName1 = "";
    private splitReferralNumber1 = "";
    private splitReferralName2 = "";
    private splitReferralNumber2 = "";
    private splitReferalEndDateValue = "";
    private splitReferalMonthCount = 0;
    public freebasicDateSelected(event) {
        this.freeReferralEndDate = event.replace(/\//g, "-") + "T00:00:00.000Z";
        this.referralSetDate = this.freeReferralEndDate;
    }
    private updateReferralPrice(months) {
        this.newReferralMonthCount = months;
        this.newReferralPriceArray.map(price => {
            if (price.month === months) {
                this.potsPrice = price.price;
            }
        });
    }
    public newReferralEndDate(event) {
        this.newReferralEndDateValue = event.replace(/\//g, "-") + "T00:00:00.000Z";
        this.referralSetDate = this.newReferralEndDateValue;
        if (this.referralResponse.payload.dueDate.finalDueDate && event) {
            this.newReferralMonthCount = this.diff_months(event, this.referralResponse.payload.dueDate.finalDueDate);
            this.updateReferralPrice(this.newReferralMonthCount);
        }
    }
    public referralPopupUpdate() {
        this.viewDate = new Date(this.exactDueDate.trim().substr(0, 10).replace(/-/g, "/"));
        this.viewDate.setDate(this.viewDate.getDate() + this.latestDays);
        this.dt = new Date(this.viewDate);
        this.referralSetDate = this.ctlHelperService.convertDateFormat(this.getDate()).replace(/\//g, "-") + "T00:00:00.000Z";
    }
    public onChangeReferralMonth(event) {
        if (this.isReferralSelected === "New Number Referral") {
            this.isSelectedOpt = event;
            this.latestMonth = event.charAt(0);
            this.latestDays = this.latestMonth * 30;
            if (event === "1 months ($ 5)") {
                this.earliestDays = 1;
            } else if (event === "2 months ($ 10)") {
                this.earliestDays = 31;
            } else if (event === "3 months ($ 15)") {
                this.earliestDays = 61;
            }
            this.monthSelected = this.latestMonth;
        }
        this.referralPopupUpdate();
        if (event === "na") {
            this.store.dispatch({ type: "MONTHSELECTED", payload: event });
            this.potsPrice = 0;
            this.newReferralChange(this.isReferralSelected);
        }
        if (event !== "na") {
            this.selectedMonth = event.charAt(0);
            this.updateReferralPrice(this.selectedMonth);
            this.newReferralChange(this.isReferralSelected);
            this.store.dispatch({ type: "MONTHSELECTED", payload: this.selectedMonth });
        } else {
            this.potsPrice = 0;
        }
    }
    public splitReferralDate(event) {
        this.splitReferalEndDateValue = event.replace(/\//g, "-") + "T00:00:00.000Z";
        this.referralSetDate = this.splitReferalEndDateValue;
        if (this.referralResponse.payload.dueDate.finalDueDate && event) {
            this.splitReferalMonthCount = this.diff_months(event, this.referralResponse.payload.dueDate.finalDueDate);
            this.updateReferralPrice(this.splitReferalMonthCount);
        }
    }
    private fillDetailsForProductConfigAndCart() {
        let selectedComponent = "";
        let selectedConfig = cloneDeep(
            this.referralResponse.payload.productConfiguration
        );
        this.referralResponse.payload &&
            this.referralResponse.payload.productConfiguration &&
            this.referralResponse.payload.productConfiguration.map(productConfig => {
                if (productConfig.productType === "VOICE-HP") {
                    selectedConfig[0].configItems = [];
                    productConfig.configItems.map(configItem => {
                        if (configItem.productName === "Free Basic Referral" && this.isReferralSelected === "Free Basic Referral") {
                            selectedComponent = configItem.productName;
                            configItem.configDetails.map(configDetail => {
                                configDetail.formItems.map(formItem => {
                                    if (formItem.attributeName === "Referral End date") {
                                        formItem.attributeValue.map(attrValue => {
                                            if (this.freeReferralEndDate === "") {
                                                attrValue.value = this.referralSetDate;
                                            } else {
                                                attrValue.value = this.freeReferralEndDate;
                                            }
                                        });
                                    }
                                });
                            });
                            selectedConfig[0].configItems[0] = configItem;
                        } else if (configItem.productName === "New Number Referral" && this.isReferralSelected === "New Number Referral") {
                            selectedComponent = configItem.productName;
                            configItem.configDetails.map(configDetail => {
                                configDetail.formItems.map(formItem => {
                                    switch (formItem.attributeName) {
                                        case "duration":
                                            formItem.attributeValue.map(attrValue => { attrValue.value = this.newReferralMonthCount; });
                                            break;
                                        case "Referral End date":
                                            formItem.attributeValue.map(attrValue => {
                                                if (this.newReferralEndDateValue === "") {
                                                    attrValue.value = this.referralSetDate;
                                                } else {
                                                    attrValue.value = this.newReferralEndDateValue;
                                                }
                                            });
                                            break;
                                        case "Referral Number":
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.numberFormat(this.newReferralNumber);
                                            });
                                            break;
                                    }
                                });
                            });
                            selectedConfig[0].configItems[0] = configItem;
                        } else if (configItem.productName === "Split Referral" && this.isReferralSelected === "Split Referral") {
                            selectedComponent = configItem.productName;
                            configItem.configDetails.map(configDetail => {
                                configDetail.formItems.map(formItem => {
                                    switch (formItem.attributeName) {
                                        case "duration":
                                            formItem.attributeValue.map(attrValue => { attrValue.value = this.splitReferalMonthCount; });
                                            break;
                                        case "Referral End date":
                                            formItem.attributeValue.map(attrValue => {
                                                if (this.splitReferalEndDateValue === "") {
                                                    attrValue.value = this.referralSetDate;
                                                } else {
                                                    attrValue.value = this.splitReferalEndDateValue;
                                                }
                                            });
                                            break;
                                        case "Name1":
                                            formItem.attributeValue.map(attrValue => { attrValue.value = this.splitReferralName1; });
                                            break;
                                        case "Name2":
                                            formItem.attributeValue.map(attrValue => { attrValue.value = this.splitReferralName2; });
                                            break;
                                        case "Referral Number 1":
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.numberFormat(this.splitReferralNumber1);
                                            });
                                            break;
                                        case "Referral Number 2":
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.numberFormat(this.splitReferralNumber2);
                                                if (attrValue.value.indexOf("undefined") !== -1) {
                                                    attrValue.value = this.numberFormat(this.splitReferralNumber2).substr(0, 10);
                                                }
                                            });
                                            break;
                                    }
                                });
                            });
                            selectedConfig[0].configItems[0] = configItem;
                        }
                    });
                }
            });
        let catalog: Catalogs;
        let offer: ProductOfferings;
        let toCart: CustomerOrderItems;
        if (this.referralResponse && this.referralResponse.payload && this.referralResponse.payload.offers && this.referralResponse.payload.offers.retrievalTypes && this.referralResponse.payload.offers.retrievalTypes.length > 0) {
            this.referralResponse.payload.offers.retrievalTypes.map(retrievalType => {
                if (retrievalType && retrievalType.offers && retrievalType.offers.length > 0) {
                    retrievalType.offers.map((categor) => {
                        if (categor.serviceCategory === GenericValues.cHP && categor.catalogs && categor.catalogs.length > 0 && categor.catalogs[0] && categor.catalogs[0].catalogItems && categor.catalogs[0].catalogItems.length > 0 && categor.catalogs[0].catalogItems[0]) {
                            catalog = categor.catalogs[0];
                            offer = catalog.catalogItems[0];
                            catalog &&
                                catalog.catalogItems[0].productOffer &&
                                catalog.catalogItems[0].productOffer.productComponents.map(component => {
                                    if ((component.product.productName === "Free Basic Referral" || component.product.productName === "Split Referral") && component.product.productName === selectedComponent) {
                                        let subItems: Products[] = [];
                                        subItems.push({
                                            action: "ADD",
                                            productId: component.product.productId,
                                            productName: component.product.productName,
                                            productType: component.product.productType,
                                            componentType: component.componentType,
                                            productAttributes: component.product.productAttributes,
                                            productAssociations: component.product.productAssociations,
                                            productCategory: component.product.productCategory,
                                            quantity: component.product.quantity ? component.product.quantity.minQuantity : 0,
                                            provisioningAction: null
                                        });
                                        toCart = {
                                            action: "ADD",
                                            catalogId: catalog.catalogId,
                                            contractStartDate: offer.productOffer.validFor ? offer.productOffer.validFor.saleEffectiveDate : null,
                                            productOfferingId: offer.productOfferingId,
                                            offerName: offer.productOffer.offerName,
                                            offerType: offer.productOffer.offerType,
                                            offerSubType: offer.productOffer.offerSubType,
                                            offerCategory: offer.productOffer.offerCategory,
                                            quantity: 1,
                                            rc: offer.defaultOfferPrice ? offer.defaultOfferPrice.rc : 0,
                                            discountedRc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedRc : 0,
                                            otc: offer.defaultOfferPrice ? offer.defaultOfferPrice.otc : 0,
                                            discountedOtc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedOtc : 0,
                                            contractTerm: 0,
                                            customerOrderSubItems: subItems
                                        };
                                    } else if (component.product.productName === "New Number Referral" && component.product.productName === selectedComponent) {
                                        let subItems: Products[] = [];
                                        let prodAttr: AttributesCombination[] = [];
                                        component && component.product && component.product.productAttributes.map(pAttr => {
                                            if (!pAttr.isPriceable) {
                                                prodAttr.push(pAttr);
                                            } else {
                                                pAttr && pAttr.compositeAttribute && pAttr.compositeAttribute.map(compAttr => {
                                                    if (compAttr.attributeName === "Duration" && +compAttr.attributeValue === +this.newReferralMonthCount) {
                                                        prodAttr.push(pAttr);
                                                    } else if (compAttr.attributeName === "Duration" && compAttr.attributeValue === "3" && +this.newReferralMonthCount !== 1 && +this.newReferralMonthCount !== 2) {
                                                        prodAttr.push(pAttr);
                                                    }
                                                });
                                            }
                                        });
                                        subItems.push({
                                            action: "ADD",
                                            productId: component.product.productId,
                                            productName: component.product.productName,
                                            productType: component.product.productType,
                                            componentType: component.componentType,
                                            productAttributes: prodAttr,
                                            productAssociations: component.product.productAssociations,
                                            productCategory: component.product.productCategory,
                                            quantity: component.product.quantity ? component.product.quantity.minQuantity : 0,
                                            provisioningAction: null
                                        });
                                        toCart = {
                                            action: "ADD",
                                            catalogId: catalog.catalogId,
                                            contractStartDate: offer.productOffer.validFor ? offer.productOffer.validFor.saleEffectiveDate : null,
                                            productOfferingId: offer.productOfferingId,
                                            offerName: offer.productOffer.offerName,
                                            offerType: offer.productOffer.offerType,
                                            offerSubType: offer.productOffer.offerSubType,
                                            offerCategory: offer.productOffer.offerCategory,
                                            quantity: 1,
                                            rc: offer.defaultOfferPrice ? offer.defaultOfferPrice.rc : 0,
                                            discountedRc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedRc : 0,
                                            otc: offer.defaultOfferPrice ? offer.defaultOfferPrice.otc : 0,
                                            discountedOtc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedOtc : 0,
                                            contractTerm: 0,
                                            customerOrderSubItems: subItems
                                        };
                                    }
                                }
                                );
                        }
                    });
                }
            });
        }
        let request = cloneDeep(this.referralResponse);
        if(toCart) { request.payload.cart.customerOrderItems.push(toCart); }
        request.payload.productConfiguration = selectedConfig;
        delete request.payload.offers;
        this.emitReferral.emit(request);
        this.close(true);
    }
    private getVenderLocations(orderReferenceNumber: string) {
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "dtvInitRequest", JSON.stringify(orderReferenceNumber));
        this.logger.startTime();
        this.directvService.getLocations(orderReferenceNumber)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "dtvInitResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "dtvInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "DTVinit", "dialog.component.ts", "Prequalify DIRECTV order", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "dtvInitResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "dtvInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.dtvForm.reset({
                        directvLocations: "Center",
                        selectedLocation: "",
                        ctlemployee: ""
                    });
                    this.store.dispatch({ type: "DTV_INIT", payload: data });
                    this.vendorLocations = data.payload.locationInfo;
                    this.centerLocations = this.vendorLocations.filter(
                        location => location.locationType === "Center"
                    );
                    this.retailLocations = this.vendorLocations.filter(
                        location => location.locationType === "Retail"
                    );
                    this.loading = false;
                    this.selectedLocType = this.centerLocations;
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "dtvInitResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "dtvInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "DTVinit", "dialog.component.ts", "Prequalify DIRECTV order popup", this.apiResponseError);
                    } else {
                        let errorResponseArray: ErrorResponse[] = [];
                        let localErrorResponse: ErrorResponse = {
                            orderRefNumber: error.payload.orderReferenceNumber,
                            statusCode: serverErrorMessages.statusCode,
                            reasonCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDownSchedule01,
                            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                            serverDown: serverErrorMessages.serverDown
                        };
                        errorResponseArray.unshift(localErrorResponse);
                        let lAPIErrorLists: APIErrorLists = {
                            errorResponse: errorResponseArray
                        };
                        this.systemErrorService.logAndeRouteToSystemError("error", "DTVinit", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public changeLocationList(locationType: string) {
        this.dtvForm.controls["selectedLocation"].setValue("");
        this.selectedLocType = locationType === "Center" ? this.centerLocations : this.retailLocations;
    }
    public removeDTV() {
        this.loading = true;
        var request = {
            orderRefNumber: "",
            processInstanceId: "",
            taskId: "",
            taskName: "",
            payload: {
                creditReviewAction: 'REMOVEDTV',
                action: "REMOVE"
            }
        };
        if (this.orderFlow.toUpperCase() === 'NEWINSTALL') {
            request.orderRefNumber = this.creditRevObsvData.orderRefNumber;
            request.processInstanceId = this.creditRevObsvData.processInstanceId;
            request.taskId = this.reEntrant ? this.userData.taskId : this.creditRevObsvData.taskId;
            request.taskName = this.creditRevObsvData.taskName;
        } else if (this.orderFlow === 'Change' || this.orderFlow === 'Move') {
            request.orderRefNumber = this.accountObservableData.orderRefNumber;
            request.processInstanceId = this.accountObservableData.processInstanceId;
            request.taskId = this.reEntrant ? this.userData.taskId : this.accountObservableData.taskId;
            request.taskName = this.accountObservableData.taskName;
        } else if (this.orderFlow === 'billing') {
            request.orderRefNumber = this.reviewOrder.orderRefNumber;
            request.processInstanceId = this.reviewOrder.processInstanceId;
            request.taskId = this.reviewOrder.taskId;
            request.taskName = this.reviewOrder.taskName;
        }
        this.logger.log("info", "dialog.component.ts", "removeDtvRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.removeDtvProcess(request, this.orderFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "removeDTVResponse", error);
                this.logger.log("error", "dialog.component.ts", "removeDTVSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "RemoveDTV", "dialog.component.ts", "DIRECTV REMOVAL order", error);
                return Observable.throwError(null);
            }).subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "dialog.component.ts", "removeDTVResponse", JSON.stringify(data));
                this.logger.log("info", "dialog.component.ts", "removeDTVSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    data.errorResponse[0]['status'] = "200";
                    this.systemErrorService.logAndRouteUnexpectedError("error", data.errorResponse[0]['orderRefNumber'], "RemoveDTV", "dialog.component.ts", "DIRECTV REMOVAL order", data.errorResponse[0]);
                    return Observable.throwError(null);
                } else {
                    // update the cart with BM cart response
                    if (this.cartObservableData && this.cartObservableData.payload && this.cartObservableData.payload.cart && this.cartObservableData.payload.cart.customerOrderItems) {
                        let dtvRemovedFromStoreCart = this.cartObservableData.payload.cart.customerOrderItems.filter(function (data) { return data.productType !== 'VIDEO-PRISM'; });
                        this.cartObservableData.payload.cart.customerOrderItems = dtvRemovedFromStoreCart;
                        let selectedServicesArr = this.cartObservableData.selectedService.split(',');
                        let selectedServicesFilteredArr = selectedServicesArr.filter(selService => { return selService !== 'TV'; });
                        this.cartObservableData.selectedService = selectedServicesFilteredArr.join(',');
                        this.store.dispatch({ type: 'CREATE_CART', payload: this.cartObservableData });
                    }
                    this.store.dispatch({ type: 'DTV_REMOVED', payload: true });
                    this.close(true);
                    //this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                    //this.store.dispatch({ type: 'CREDIT_REVIEW', payload: data });
                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                    this.store.dispatch({ type: "CAPTURE_DTV_REQUEST", payload: data });
                }
            }, error => { });
    }
    public opusSessionInfoNotFound() {
        if (this.opusSessionNotFoundForm.valid) {
            if (this.creditRevObsvData) {
                var request = {
                    orderRefNumber: this.creditRevObsvData.orderRefNumber,
                    processInstanceId: this.creditRevObsvData.processInstanceId,
                    taskId: this.creditRevObsvData.taskId,
                    taskName: this.creditRevObsvData.taskName,
                    payload: {
                        "orderRefNumber": this.creditRevObsvData.orderRefNumber,
                        "orderType": (this.opusSessionNotFoundForm.controls["dtvCreated"].value === 'Yes') ? true : false,
                        "attAccountNumber": this.opusSessionNotFoundForm.controls["dtv_account_id"].value
                    }
                };
                if (this.dtvSessionInfo) {
                    request.orderRefNumber = this.dtvSessionInfo.payload.orderReferenceNumber;
                    request.processInstanceId = this.dtvSessionInfo.processInstanceId;
                    request.taskId = this.dtvSessionInfo.taskId;
                    request.taskName = 'Submit DTV Order Manually';
                }
            }
            this.logger.log("info", "dialog.component.ts", "enterDTVManuallyRequest", JSON.stringify(request));
            this.logger.startTime();
            this.loading = true;
            this.directvService.enterDTVManually(request).catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "enterDTVManuallyResponse", error);
                this.logger.log("error", "dialog.component.ts", "enterDTVManuallySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "EnterDTVManually", "dialog.component.ts", "Enter DTV Data Manually order", error);
                return Observable.throwError(null);
            }).subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "dialog.component.ts", "enterDTVManuallyResponse", JSON.stringify(data));
                this.logger.log("info", "dialog.component.ts", "enterDTVManuallySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.close(true);
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    data.errorResponse[0]['status'] = "200";
                    this.systemErrorService.logAndRouteUnexpectedError("error", "", "OrderDTVProcess", "dialog.component.ts", "order  DTV Process", data.errorResponse[0]);
                    return Observable.throwError(null);
                } else {
                    this.store.dispatch({ type: "DTV_ACCOUNT_INFO", payload: request });
                }
                this.close(true);
            }, error => { });
            this.opusSessionInfoNotFoundCallback.emit(request);
        }
    }
    public launchOpus() {
        let payload: any;
        this.retainObservable = <Observable<User>>this.store.select("retain");
        this.retainSubscription = this.retainObservable.subscribe(data => {
            payload = {
                orderRefNumber: data.dtvLocations.orderRefNumber,
                processInstanceId: data.dtvLocations.processInstanceId,
                taskId: data.dtvLocations.taskId,
                taskName: data.dtvLocations.taskName,
                payload: {
                    applicationInfo: {
                        srcApplicationId: "ESHOP",
                        inputChannelId: "ESHOP_OPUS"
                    },
                    locationType: this.dtvForm.controls["directvLocations"].value,
                    customerType: this.dtvForm.controls["ctlemployee"].value,
                    locationId: this.dtvForm.controls["selectedLocation"].value,
                    userId: this.ensembleId
                }
            };
        });
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "captureDtvRequest", JSON.stringify(payload));
        this.logger.startTime();
        this.directvService
            .getDtvSessionInfo(payload)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "captureDtvRequestResponse", JSON.stringify(error));
                this.logger.log("error", "dialog.component.ts", "captureDtvRequestSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "DTVinit", "dialog.component.ts", "Prequalify DIRECTV order", error);
                return Observable.throwError(null);
            })
            .subscribe(
                data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "captureDtvRequestResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "captureDtvRequestSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                        data.errorResponse[0]['status'] = "200";
                        this.systemErrorService.logAndRouteUnexpectedError("error", data.errorResponse[0]['orderRefNumber'], "DTVinit", "dialog.component.ts", "Prequalify DIRECTV order", data.errorResponse[0]);
                        return Observable.throwError(null);
                    } else {
                        this.store.dispatch({ type: "CAPTURE_DTV_REQUEST", payload: data });
                        let ensembleId;
                        this.user = <Observable<User>>this.store.select("user");
                        this.userSubscription = this.user.subscribe(data => {
                            if (data && data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.ensembleId) {
                                ensembleId = data.autoLogin.oamData.ensembleId;
                            }
                        });
                        var form = document.createElement("form");
                        form.target = "_blank";
                        form.method = "POST";
                        form.action = data.payload && data.payload.sessionInfo && data.payload.sessionInfo.opusOrderingURL ? data.payload.sessionInfo.opusOrderingURL : "";
                        form.style.display = "none";
                        var input = document.createElement("input");
                        input.type = "hidden";
                        input.name = "clientRequest";
                        input.value = JSON.stringify({
                            applicationId: data.payload && data.payload.sessionInfo && data.payload.sessionInfo.callingApplicationId ? data.payload.sessionInfo.callingApplicationId : "",
                            agentId: ensembleId,
                            uniqueSessionId: data.payload && data.payload.sessionInfo && data.payload.sessionInfo.uniqueSessionId ? data.payload.sessionInfo.uniqueSessionId : "",
                            authenticationToken: data.payload && data.payload.sessionInfo && data.payload.sessionInfo.authenticationToken ? data.payload.sessionInfo.authenticationToken : "",
                            externalOrderId: data.payload && data.payload.sessionInfo && data.payload.sessionInfo.externalOrderId ? data.payload.sessionInfo.externalOrderId : "",
                            socialSecurityNumber: data.payload && data.payload.sessionInfo && data.payload.sessionInfo.socialSecurityNumber ? data.payload.sessionInfo.socialSecurityNumber : "",
                            dateOfBirth: data.payload && data.payload.sessionInfo && data.payload.sessionInfo.dateOfBirth ? data.payload.sessionInfo.dateOfBirth : ""
                        });
                        form.appendChild(input);
                        document.body.appendChild(form);
                        form.submit();
                        document.body.removeChild(form);
                        this.close(true);
                    }
                },
                error => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "captureDtvRequestResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "captureDtvRequestSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", this.apiResponseError);
                    } else {
                        let errorResponseArray: ErrorResponse[] = [];
                        let localErrorResponse: ErrorResponse = {
                            orderRefNumber: error.payload.orderReferenceNumber,
                            statusCode: serverErrorMessages.statusCode,
                            reasonCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDownSchedule01,
                            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                            serverDown: serverErrorMessages.serverDown
                        };
                        errorResponseArray.unshift(localErrorResponse);
                        let lAPIErrorLists: APIErrorLists = {
                            errorResponse: errorResponseArray
                        };
                        this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }
    public dtvManualPriceplanSave() {
        if (this.dtvManualPriceplanEntryForm.valid) {
            this.store.dispatch({ type: "DTV_ACCOUNT_INFO", payload: this.dtvManualPriceplanEntryForm.value });
        }
        this.close(true);
    }
    public getReasonsForSUPHold() {
        if (this.pendingObject && this.pendingObject.orderReference && this.pendingObject.orderReference.customerOrderNumber && !this.heldSUPOrder) {
            this.loading = true;
            let request = {
                customerOrderNumber: this.pendingObject.orderReference.customerOrderNumber,
                salesChannel: "ESHOP-Customer Care",
                orderAction: "HOLD",
                sfdcAccountId: this.sfdcAccountId,
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
                addlOrderAttributes: [
                    {
                        orderAttributeGroup: [
                            {
                                orderAttributeGroupName: "sfcAttrData",
                                orderAttributeGroupInfo: [
                                    {
                                        orderAttributes: [
                                            {
                                                orderAttributeName: "tfn",
                                                orderAttributeValue: "NA"
                                            },
                                            {
                                                orderAttributeName: "ucid",
                                                orderAttributeValue: "NA"
                                            },
                                            {
                                                orderAttributeName: "callStartTime",
                                                orderAttributeValue: "NA"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };
            this.logger.log("info", "dialog.component.ts", "supHoldInitRequest", JSON.stringify(request));
            this.logger.startTime();
            this.pendingOrderService
                .supHoldInit(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "supHoldInitResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "supHoldInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "initSupHold - getReasonsForSUPHold", "dialog.component.ts", "Dialog", error);
                    return Observable.throwError(null);
                })
                .subscribe(data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "supHoldInitResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "supHoldInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.holdReasonsList = [];
                    if (data && data.payload && data.payload.reason && data.payload.reason.length > 0) {
                        this.holdReasonsList = data.payload.reason;
                        if (!this.orderReferenceNumber) {
                            this.orderReferenceNumber = data.orderRefNumber;
                        }
                        this.taskId = data.taskId;
                        this.taskname = data.taskName;
                        this.processInstanceId = data.processInstanceId;
                    }
                    this.loading = false;
                });
        }
    }
    private taskId: string = "";
    private taskname: string = "";
    private processInstanceId: string = "";
    public heldSUPOrder = false;

    public holdSUPOrder() {
        let reason: any[] = [];
        let remark: OrderRemarks = {
            name: 'Order Remarks',
            value: this.holdReasonRemark,
            date: new DatePipe('en-US').transform(new Date(), 'mediumDate'),
            author: this.firstName + ' ' + this.lastName
        }
        if (this.holdSelectedReason && this.holdSelectedReason !== "Choose reason ..." && this.holdSelectedReason !== "Choose your option..") {
            this.errorText = "";
            if (this.holdReasonsList !== null && this.holdReasonsList.length > 0 && this.holdSelectedReason !== undefined) {
                this.holdReasonsList.forEach(item => {
                    if (item.code === this.holdSelectedReason) {
                        reason.push(item);
                    }
                });
            }
            this.loading = true;
            let request = {
                orderRefNumber: this.orderReferenceNumber,
                processInstanceId: this.processInstanceId,
                taskId: this.taskId,
                taskName: this.taskname,
                payload: {
                    reason: reason,
                    reasonRemark: this.holdReasonRemark,
                    orderRemarks: [remark]
                }
            };
            this.logger.log("info", "dialog.component.ts", "supHoldInitRequest", JSON.stringify(request));
            this.logger.startTime();
            this.store.dispatch({ type: "SUPHOLD_REQUEST", payload: request });
            this.pendingOrderService
                .supHoldSubmit(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "supHoldInitResponse", JSON.stringify(error));
                    this.logger.log("error", "dialog.component.ts", "supHoldInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "initSupHold - getReasonsForSUPHold", "dialog.component.ts", "Dialog", error);
                    return Observable.throwError(null);
                })
                .subscribe(data => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "supHoldInitResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "supHoldInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference("Seconds") + '"}');
                    this.store.dispatch({ type: "PENDING_SUMMARY", payload: data });
                    this.enable = false;
                    this.visible = false;
                    this.router.navigate(["/po-order-confirmation"]);
                });
        }
    }
    private isHPSuspendend: boolean = false;
    // tslint:disable-next-line:no-input-rename
    @Input("suspendIneligibilityReason") public suspendIneligibilityReason;
    public isVacationContinueBtnEnabled: boolean = false;
    public onVacationLinkChange() {
        if (this.vacationOptionsLink === "add to all") {
            this.vacationOptionsLink = "restore all";
            this.isVacationContinueBtnEnabled = true;
            this.existingProductItems.forEach((value, index) => {
                this.vacationOptionSelected[index] = value.offerCategory + " " + "Vacation Suspend";
            });
        } else {
            this.vacationOptionsLink = "add to all";
            this.isVacationContinueBtnEnabled = false;
            this.existingProductItems.forEach((value, index) => {
                this.vacationOptionSelected[index] = value.offerCategory + " " + "Not Added (Active)";
            });
        }
    }
    public onVacationOptionSelected(value) {
        if (value.indexOf("VOICE-HP") > -1) {
            this.existingProductItems.forEach((val, index) => {
                if (val.offerCategory === "INTERNET" && value === "VOICE-HP Vacation Suspend") {
                    val.isDisabled = true;
                    this.isHPSuspendend = true;
                    this.isVacationContinueBtnEnabled = true;
                    this.vacationOptionSelected[index] = val.offerCategory + " " + "Vacation Suspend";
                } else if (val.offerCategory === "INTERNET" && value === "VOICE-HP Not Added (Active)") {
                    val.isDisabled = false;
                    this.isVacationContinueBtnEnabled = false;
                    this.vacationOptionSelected[index] = val.offerCategory + " " + "Not Added (Active)";
                }
            });
        } else if (value.indexOf("Vacation Suspend") > -1) {
            this.isVacationContinueBtnEnabled = true;
        } else {
            this.isVacationContinueBtnEnabled = false;
        }
    }
    public vacationSuspendProceed() {
        if (!this.errorScreen) {
            this.errorScreen = true;
        } else {
            let saveVacationService = {
                saveChanges: true
            };
            this.saveVacationSuspend.emit(saveVacationService);
            if (this.isHPSuspendend) {
                let vacationData;
                this.store.dispatch({ type: "VACATION_SUSPEND_DATA", payload: vacationData });
                this.router.navigate(["/vacation-option"]);
            } else {
                this.router.navigate(["/vacation-schedule"]);
            }
            this.close(true);
        }
    }
    public vacationSuspendReturn() {
        if (this.errorScreen) {
            this.errorScreen = false;
        }
    }
    public onChangeAcknowledge(value) {
        this.isAcknowledgeSelected = true;
        this.isrccAcknowledged = value;
    }
    public onAcknowledgeContinue() {
        let rccAcknowledgement = {
            isAcknowledgeSelected: this.isAcknowledgeSelected,
            isrccAcknowledged: this.isrccAcknowledged
        };
        this.isAcknowledgeContinued.emit(rccAcknowledgement);
        this.close(true);
    }
    @Input() public inputData;
    @Input() public exInputData;
    @Input() public freezeData;
    @Input() public isFreezeReEntrant;
    @Input() public retainedFreezeData;
    public setDataForFreeze() {
        this.finalFreezeArray = [];
        this.dataChanged = false;
        this.isFreezePresent = false;
        if (this.inputData && this.inputData.listingData && this.inputData.listingData.configItems) {
            if (this.isFreezeReEntrant && this.retainedFreezeData) {
                this.selectedFreeze = this.retainedFreezeData;
            }
            this.finalFreezeArray.push(this.getFreezeData("access", "freeze"));
            this.finalFreezeArray.push(this.getFreezeData("intralata", "freeze"));
            this.finalFreezeArray.push(this.getFreezeData("interlata", "freeze"));
        }
        if (this.selectedFreeze) {
            for (let i = 0; i < this.selectedFreeze.length; i++) {
                if (this.selectedFreeze[i] && this.selectedFreeze[i].lov && (this.selectedFreeze[i].lov.toLowerCase() === "remove freeze" ||
                    this.selectedFreeze[i].lov.toLowerCase() === "add freeze")) {
                    this.dataChanged = true;
                    this.selectedFreeze[i].lov.toLowerCase() === "add freeze" ? this.isFreezePresent = true : this.isFreezePresent = false;
                }
            }
        }
        this.selectedFreezeCopy = JSON.parse(JSON.stringify(this.selectedFreeze));
    }
    private finalFreezeArray = [];
    private selectedFreeze: any[] = [];
    private selectedFreezeCopy: any[] = [];
    private oneTimeFreezeSelection = false;
    private getFreezeData(prefix, suffix) {
        let freezeList = {
            formName: "",
            attributeName: "",
            lov: [],
            changedOn: "",
            existing: "",
            existingValue: "",
            existingDate: ""
        };
        let selectedFreezeFromOption: any;
        let selectedFreezeValue: any;
        let addedLOV = false;
        this.inputData && this.inputData.listingData && this.inputData.listingData.configItems && this.inputData.listingData.configItems.some(item => {
            item && item.configDetails && item.configDetails.map(confDet => {
                if (!addedLOV && confDet && confDet.formName && confDet.formName.toLowerCase().indexOf(prefix) !== -1 &&
                    confDet.formName.toLowerCase().indexOf(suffix) !== -1) {
                    confDet.formItems && confDet.formItems.map(formItem => {
                        if (formItem && formItem.attributeName && (formItem.attributeName.toLowerCase().indexOf(prefix) !== -1 &&
                            formItem.attributeName.toLowerCase().indexOf(suffix) !== -1)) {
                            freezeList.formName = confDet.formName;
                            freezeList.attributeName = formItem.attributeName;
                            if (prefix === " access" && this.inputData && this.inputData.tnData && this.inputData.tnData.selectedTN) {
                                freezeList.attributeName = formItem.attributeName + this.inputData.tnData.selectedTN;
                            }
                            let value = formItem.attributeValue;
                            this.exInputData && this.exInputData.listingData && this.exInputData.listingData.configItems &&
                                this.exInputData.listingData.configItems.some(item => {
                                    item && item.configDetails && item.configDetails.map(confDet => {
                                        if (!addedLOV && confDet && confDet.formName && confDet.formName.toLowerCase().indexOf(prefix) !== -1 &&
                                            confDet.formName.toLowerCase().indexOf(suffix) !== -1) {
                                            confDet.formItems && confDet.formItems.map(formItem => {
                                                if (formItem && formItem.attributeName && (formItem.attributeName.toLowerCase().indexOf(prefix) !== -1 &&
                                                    formItem.attributeName.toLowerCase().indexOf(suffix) !== -1)) {
                                                    if (!this.isFreezeReEntrant || (this.isFreezeReEntrant && !this.retainedFreezeData)) value = formItem.attributeValue;
                                                    if (value && value[0] && value[0].value === null) value[0].value = "";
                                                } else if (formItem && formItem.attributeName && formItem.attributeName.toLowerCase() === "changed on" &&
                                                    formItem.attributeValue && formItem.attributeValue[0] && formItem.attributeValue[0].value) {
                                                    if (!this.isFreezeReEntrant || (this.isFreezeReEntrant && !this.retainedFreezeData))
                                                        freezeList.changedOn = formItem.attributeValue[0].value;
                                                    freezeList.existingDate = cloneDeep(formItem.attributeValue[0].value);
                                                }
                                            });
                                        }
                                    });
                                });
                            if (this.selectedFreeze && this.selectedFreeze.length > 0) {
                                for (let i = 0; i < this.selectedFreeze.length; i++) {
                                    if (this.selectedFreeze[i].attributeName === freezeList.attributeName) {
                                        value = [{
                                            value: this.selectedFreeze[i].lov
                                        }];
                                    }
                                }
                            }
                            if (this.freezeData && this.freezeData.outputAttribute && this.freezeData.outputAttribute.length > 0) {
                                this.freezeData.outputAttribute.map(data => {
                                    if (data && data[1] && data[3] && data[1].toLowerCase().indexOf(prefix) !== -1 && value && value[0] &&
                                        (((value[0].value === "" || value[0].value.toLowerCase() === "not added" ||
                                            value[0].value.toLowerCase() === "add freeze") && data[3].toLowerCase() === "not added") ||
                                            (value[0].value !== "" && (value[0].value.toLowerCase() === "freeze is active" ||
                                                value[0].value.toLowerCase() === "remove freeze") && data[3].toLowerCase() === "freeze is active"))
                                    ) {
                                        freezeList.lov.push(data);
                                        if (data[4] && data[4] !== null && data[4].toLowerCase() === "yes") {
                                            selectedFreezeFromOption = data[2];
                                            freezeList.existing = data[2];
                                            freezeList.existingValue = data[2];
                                            selectedFreezeValue = data[2];
                                        }
                                    }
                                });
                            }
                        } else if (formItem && formItem.attributeName && formItem.attributeName.toLowerCase() === "changed on" && formItem.attributeValue && formItem.attributeValue[0]) {
                            if (formItem.attributeValue[0].value) freezeList.changedOn = formItem.attributeValue[0].value;
                            if (freezeList.existingDate === "")
                                freezeList.existingDate = cloneDeep(formItem.attributeValue[0].value);
                        }
                        if (this.selectedFreeze && this.selectedFreeze.length > 0) {
                            for (let i = 0; i < this.selectedFreeze.length; i++) {
                                if (this.selectedFreeze[i].attributeName === freezeList.attributeName) {
                                    if (this.selectedFreeze[i]) freezeList.changedOn = this.selectedFreeze[i].changedOn;
                                }
                            }
                        }
                    });
                    addedLOV = true;
                }
            });
        });
        if (!this.oneTimeFreezeSelection && freezeList.attributeName && (!this.isFreezeReEntrant || (this.isFreezeReEntrant && !this.retainedFreezeData))) {
            this.selectedFreeze.push({
                attributeName: cloneDeep(freezeList.attributeName),
                lov: cloneDeep(selectedFreezeFromOption),
                changedOn: cloneDeep(freezeList.changedOn),
                formName: cloneDeep(freezeList.formName),
                value: cloneDeep(selectedFreezeValue)
            });
        }
        if (prefix === "interlata") {
            this.oneTimeFreezeSelection = true;
            if (this.isFreezeReEntrant && this.retainedFreezeData) {
                this.selectedFreeze = this.retainedFreezeData;
                this.submittedFreeze = true;
                this.tpvSelection = this.selectedFreeze && this.selectedFreeze[0] && this.selectedFreeze[0].tpvSelection;
                if (this.selectedFreeze && this.selectedFreeze.length > 0) {
                    for (let i = 0; i < this.selectedFreeze.length; i++) {
                        this.onChangeFreeze(this.selectedFreeze[i].lov, this.selectedFreeze[i].attributeName);
                    }
                }
                this.isFreezeReEntrant = false;
            }
        }
        return freezeList;
    }
    public dataChanged = false;
    public isFreezePresent = false;
    public submittedFreeze = false;
    public tpvSelection = "Proceed with TPV as normal";
    private onChangeFreeze(value, attributeName) {
        this.isFreezePresent = false;
        for (let i = 0; i < this.selectedFreeze.length; i++) {
            if (this.selectedFreeze[i].attributeName === attributeName) {
                this.selectedFreeze[i].lov = value;
            }
        }
        let finalFreezeArray = [...this.finalFreezeArray];
        for (let i = 0; i < finalFreezeArray.length; i++) {
            if (finalFreezeArray[i].attributeName === '' && finalFreezeArray[i].lov.length === 0) {
                finalFreezeArray.splice(i, 1);
            }
        }
        if (!this.submittedFreeze) this.dataChanged = false;
        for (let i = 0; i < finalFreezeArray.length; i++) {
            if (finalFreezeArray[i].existing !== this.selectedFreeze[i].lov)
                this.dataChanged = true;
            finalFreezeArray[i].changedOn = cloneDeep(finalFreezeArray[i].existingDate);
            this.selectedFreeze[i].value = finalFreezeArray[i].existingValue;
            this.selectedFreeze[i].changedOn = cloneDeep(finalFreezeArray[i].existingDate);
            if (this.selectedFreeze[i].lov === "Add Freeze") {
                this.isFreezePresent = true;
                this.selectedFreeze[i].value = this.selectedFreeze[i].lov;
                this.selectedFreeze[i].changedOn = new Date();
                if (this.dataChanged) finalFreezeArray[i].changedOn = new Date();
            } else if (this.selectedFreeze[i].lov === "Remove Freeze") {
                this.selectedFreeze[i].value = this.selectedFreeze[i].lov;
                this.selectedFreeze[i].changedOn = new Date();
                if (this.dataChanged) finalFreezeArray[i].changedOn = new Date();
            }
        }
    }
    public undoFreeze() {
        this.selectedFreeze = JSON.parse(JSON.stringify(this.selectedFreezeCopy));
        this.close(true)
    }
    @Output() public emitLDFreeze: EventEmitter<any> = new EventEmitter<any>();
    public saveFreeze() {
        this.submittedFreeze = true;
        if (this.isFreezePresent) this.selectedFreeze[0].tpvSelection = this.tpvSelection;
        this.emitLDFreeze.emit(this.selectedFreeze);
        this.close(true);
    }
    @Output() public emitStackAmend: EventEmitter<any> = new EventEmitter<any>();
    public stackAmendNotSelected: boolean = false;
    public stackAmendContinue(order) {
        if (this.stackChange) {
            this.emitStackAmend.emit(this.stackChange);
            this.close(true);
        } else if (order === 'stackOrder') {
            this.emitStackAmend.emit(order);
            this.close(true);
        } else {
            this.stackAmendNotSelected = true;
        }
    }
    public validateSalesId(salesId) {
        let request = {
            dealerCode: salesId,
            firstName: null,
            lastName: null
        };
        this.loading = true;
        this.logger.log("info", "dialog.component.ts", "validateDealerCodeRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService.validateDealerCode(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "dialog.component.ts", "validateDealerCodeResponse", error);
                this.logger.log("error", "dialog.component.ts", "validateDealerCodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "validateDealerCode", "dialog.component.ts", "Review Order Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "dialog.component.ts", "validateDealerCodeResponse", JSON.stringify(data));
                    this.logger.log("info", "dialog.component.ts", "validateDealerCodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                        this.hasError = true;
                    } else {
                        this.validatedDC = data;
                        this.isValidDealerCode = true;
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "dialog.component.ts", "validateDealerCodeResponse", error);
                    this.logger.log("error", "dialog.component.ts", "validateDealerCodeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "validateDealerCode", "dialog.component.ts", "Order Summary Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "validateDealerCode", "dialog.component.ts", "Order Summary Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    @Output('dealerCodeSaved') public dealerCodeSaved?: EventEmitter<any> = new EventEmitter<any>();
    public saveDealerCode() {
        let dealerCodeArray = [];
        let multipleDC: boolean;
        this.dealerCodeChanged = true;
        this.productDealerCodeInfo.map(prodInfo => {
            if (prodInfo.changeId) {
                prodInfo.dealerCode = this.validatedDC.dealerCode;
                prodInfo.firstName = this.validatedDC.firstName;
                prodInfo.lastName = this.validatedDC.lastName;
                prodInfo.changed = true;
            }
            dealerCodeArray.push(prodInfo.dealerCode);
        });
        multipleDC = !dealerCodeArray.every(val => (val === dealerCodeArray[0]));
        let payload = {
            productDealerCodeInfo: this.productDealerCodeInfo,
            isMultipleDealerCode: multipleDC,
            dealerCodeChanged: true,
            partnerInfo: this.partnerInfo
        }
        this.store.dispatch({ type: 'PROD_DEALER_ID', payload: payload });
        this.isValidDealerCode = false;
        this.dealerCodeSaved.emit(this.partnerInfo);
        this.close(true);
    }
    public setChangeId(product, ele) {
        if (product.productname.indexOf('EASE') === -1 || product.productType === 'DIRECTV') {
            this.productDealerCodeInfo.map(prodInfo => {
                if (prodInfo.productname.indexOf('EASE') === -1 && product.productType === prodInfo.productType) {
                    prodInfo.changeId = product.changeId;
                }
            });
        }
    }
    public cancelOrderLaunchOpus() {
        this.title = "Prequalify DIRECTV order";
        this.invokeCall = "Continue opus";
        this.cancelBack = "Close";
        this.opusCancelFlag = true;
        this.orderReferenceNumber = this.accountObservableData.orderRefNumber;
        this.open();
    }
    public poDDFormat(date: any) {
        let poDate: Date;
        poDate = date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
        poDate.setDate(poDate.getDate() + 1)
        return poDate;
    }
    public stackTitle(title, replaceValue) {
        return title.replace("Change", replaceValue);
    }
    public offerSelected() {
        this.offerexpired = true;
        this.addOfferExpired.emit(this.offerexpired);
        this.selectedSalesExpiresOfferId = this.selectdExpiredSpeedId;
        this.SalesExpiredOfferSelected.emit(this.selectedSalesExpiresOfferId);
        this.expiredOfferSelected.emit(this.selectdExpiredSpeed);
        this.close(true);
    }
    public updateofferSelected(offer) {
        this.selectdExpiredSpeed = offer;
    }
    public expiredDiscounts(index, product) {
        product.discountDes = [];
        this.autoAttach = false;
        product.product.productAttributes.map(productAttr => {

            if (productAttr.isPriceable) {
                productAttr && productAttr.discounts && productAttr.discounts.map(discount => {
                    if (discount.autoAttachInd === 'Y') {
                        product.discountDes = discount.discountDescription
                        this.autoAttach = true;
                    }
                });
            }

        });
        let discount: any = product.discountDes;
        if (discount && discount.length > 0) {
            return discount;
        }
    }
    public updateWaivedCharge() {
        this.otcWaiverList.reason = this.waivedReasonList.find(item => item.code === this.waivedReason);
        this.otcWaiverList.waivers = [];
        this.adjustableOtcProducts.forEach(otc => {
            if (otc && otc.waived) {
                this.otcWaiverList.waivers.push(otc)
            }
        });
        this.store.dispatch({
            type: 'WAIVED_OTC_INFO', payload: {
                totalWaivedOtc: this.waivedCharge,
                otcWaiverList: cloneDeep(this.otcWaiverList)
            }
        });
        this.waivedOtc.emit({
            totalWaivedOtc: this.waivedCharge,
            otcWaiverList: cloneDeep(this.otcWaiverList)
        });
        this.close(true);
    }

    public updateOtcSelection() {
        this.dataChanged = true;
        this.showReasonList = this.adjustableOtcProducts.some(otc => otc.waived === true);
        this.waivedCharge = 0;
        this.adjustableOtcProducts.forEach(otc => {
            if (otc && otc.waived && otc.otcDetails && otc.otcDetails.discountedOtc) {
                this.waivedCharge += +otc.otcDetails.discountedOtc;
            }
        });
    }
    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacy === 'CENTURYLINK')
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Atrue%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%2216%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22Y5YzQ2MWM0YjIzMTExYmRi%22%2C%22ssid%22%3A%22rI28qh_OTFKTGfGQbOQIFA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
        else
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083512%2C%22eid%22%3A1570086812%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22AzY2QxNDAyNDE2YTdhMGI1%22%2C%22ssid%22%3A%22C-xqYDpuQr692Su1zOt-6Q%22%2C%22lewid%22%3A1570246912%2C%22skill%22%3A%22credit-service-cris%22%7D%7D';
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }
    public tnAssignment() {
        if (this.isCenturyLink && this.orderFlow === "NEWINSTALL")
            this.tnAssUrl = 'http://rmodkit.corp.intranet/chat/ensHandbook.html';
        else
            this.tnAssUrl = 'http://rmodkit.corp.intranet/clicktochat/EinsteinPage.html';
    }

    @ViewChild("rccTable", { static: false, }) rccTable: ElementRef;
    public copyClipBord() {
        let node = this.rccTable.nativeElement;
        let range = document.createRange();
        range.selectNodeContents(node)
        let select = window.getSelection()
        select.removeAllRanges()
        select.addRange(range)
        document.execCommand('copy')
    }
}