// tslint:disable-next-line:no-unused-variable
import { Component, Input, Output, EventEmitter, ViewChild, OnDestroy, OnChanges, SimpleChanges, OnInit } from '@angular/core';;
import { DatePipe } from '@angular/common';
import { DueDateExceptionDays } from '../models/schedule-shipping.model';
import { cloneDeep } from 'lodash';
import { ProductService } from 'app/common/service/product.service';
import { Observable } from 'rxjs/Observable';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ErrorResponse, serverErrorMessages, APIErrorLists } from 'app/common/models/common.model';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { Subscription } from 'rxjs';
import { User } from '../models/user.model';
import { CTLHelperService } from '../service/ctlHelperService';
import { Logger } from '../../common/logging/default-log.service';
import "rxjs/add/operator/catch";

@Component({
    templateUrl: './datepicker-endate.component.html',
    selector: 'endDate-datepicker',
    styleUrls: ['../datepicker/datepicker.component.scss']
})

export class EndDatePickerComponent implements OnInit, OnDestroy, OnChanges {
    public isPortingDone: string ="No";
    public retainSchedulingData: any;
    public totalOverrideDates: number;
    public addOverride: number;
    public date_limit: any = '';
    public allowed_month: Observable<any>;
    private enableDropDown = false;
    public dt: Date;
    public accRecurring: boolean = true;
    public originalDate: Date;
    public minDate: Date;
    public maxDate: Date;
    public events: any[];
    public tomorrow: Date;
    public afterTomorrow: Date;
    public apiResponseError: APIErrorLists;
    public dateDisabled: Array<{ date: Date, mode: string }>;
    public selectedDay: string = '';
    public selectedDayLifeLine: string = '';
    public isOverrideClicked: boolean = false;
    private numberOfDays: number;
    private numberOfDay: Date;
    public loading: boolean = false;
    public overrideReasons: any;
    public mgrInitials: string = '';
    public overrideReasonModel: string = 'Choose reason ...';
    private additionalAttr: any = [
        {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "overrideInfo",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "overrideReasonCode",
                                    "orderAttributeValue": "DIE"
                                },
                                {
                                    "orderAttributeName": "overrideReasonDescr",
                                    "orderAttributeValue": "Disconnected In Error"
                                },
                                {
                                    "orderAttributeName": "mgrInitials",
                                    "orderAttributeValue": "abc"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ];

    @ViewChild('pop', { static: false, }) public popup: any;
    private displayError: boolean = false;
    public errorMessage: string = '';
    @Input() public isEditable: boolean;
    @Input() public popupTitle: string;
    @Input() public positiveButton: string;
    @Input() public negativeButton: string;
    @Output() public dateUpdated = new EventEmitter();
    @Output() public additionalInfo = new EventEmitter();
    @Input() public isLifeline: boolean;
    @Input() public isAccRecurring: boolean;
    @Input() public isLifelinenlad: boolean;
    @Input() public isEnableOverride: boolean;
    @Input() public placementTop: boolean;
    @Input() public noCalendar: string;
    public monthSubscription: Subscription;
    public user: Observable<User>;
    private userData: any;
    public _date: string;
    public formats: string[] = ['DD-MM-YYYY', 'YYYY/MM/DD', 'DD.MM.YYYY', 'shortDate'];
    public format: string = this.formats[0];
    public dateOptions: any = {
        formatYear: 'YY',
        startingDay: 1,
    };
    public opened: boolean = false;
    private exceptionDueDays: DueDateExceptionDays[];
    private calculatedDate: any;
    @Input()
    set CalculatedDueDate(date: any) {
        this.minDate = date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
        this.calculatedDate = cloneDeep(date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date());
    }

    @Input()
    set MaxDueDate(date: any) {
        if (date !== undefined) {
            this.minDate = new Date();
            this.maxDate = new Date();
            this.maxDate.setMonth(this.maxDate.getMonth() + Number(date));
        }
    }
    @Input()
    set MaxDueDateException(date: any) {
        if (date !== undefined) {
            this.maxDate = new Date();
            if (date) this.maxDate = new Date(date.trim().substr(0, 10).replace(/-/g, '\/'));
        }
    }
    @Input()
    set CallRefMaxDueDate(date: any) {
        if (date !== undefined) {
            this.minDate = date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
            this.minDate.setDate(this.minDate.getDate() + 1)
            this.calculatedDate = cloneDeep(this.minDate);
            this.maxDate = date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
            this.maxDate.setMonth(this.maxDate.getMonth() + 3);
        }
    }
    private newRefSelectedDay: any;
    private newRefmaxMonth: any;
    @Input()
    set earliestdays(days: any) {
        if (days !== undefined) {
            this.newRefSelectedDay = days;
        }
    }
    @Input()
    set maxMonth(month: any) {
        if (month !== undefined) {
            this.newRefmaxMonth = month;
        }
    }
    @Input() public optChanged;
    @Input() public newRefMaxDueDate;
    public ngOnChanges(changes: SimpleChanges) {
        if (changes['optChanged']) {
            if (this.optChanged !== undefined &&
                (this.optChanged === "1 months ($ 5)" ||
                    this.optChanged === "2 months ($ 10)" ||
                    this.optChanged === "3 months ($ 15)")) {
                this.minDate = this.newRefMaxDueDate ? new Date(this.newRefMaxDueDate.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
                if (this.newRefSelectedDay) {
                    this.minDate.setDate(this.minDate.getDate() + this.newRefSelectedDay);
                } else {
                    this.minDate.setDate(this.minDate.getDate() + 1);
                }
                this.calculatedDate = cloneDeep(this.minDate);
                this.maxDate = this.newRefMaxDueDate ? new Date(this.newRefMaxDueDate.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
                if (this.newRefmaxMonth) {
                    this.maxDate.setMonth(this.maxDate.getMonth() + this.newRefmaxMonth);
                }
            }
        }
    }
    @Input()
    set DisabledDates(disabledDates: DueDateExceptionDays[]) {
        this.addOverride = 0;
        this.dateToBeDisabled(disabledDates);
    }
    public lifeLineDateSet: boolean = false;
    private dateToBeDisabled(disabledDates: DueDateExceptionDays[]) {
        this.exceptionDueDays = disabledDates;
        this.dateDisabled = [];
        if (this.exceptionDueDays) {
            for (let i = 0; i < this.exceptionDueDays.length; i++) {
                if (this.exceptionDueDays[i].exceptionDate) {
                    let date = this.exceptionDueDays[i].exceptionDate.trim().substr(0, 10).replace(/-/g, '\/');
                    let dateFmt: Date = new Date(date);
                    let modeFmt: string = 'day';
                    this.dateDisabled.push({ date: dateFmt, mode: modeFmt });
                    this.addOverride++;
                }
            }
        }
    }
    @Input() set startDate(date: any) {
        this.maxDate = date ? new Date(date.trim().substr(0, 10).replace(/-/g, '\/')) : new Date();
        if (date && date !== null && date !== undefined) {
            if (this.isLifeline || this.isLifelinenlad) {
                this.selectedDayLifeLine = new DatePipe('en-US').transform(date, 'shortDate');
            }
            this._date = date.trim().substr(0, 10).replace(/-/g, '\/');
            if (this.myOldDate !== undefined) {
                if (new Date(this._date) < this.myOldDate) {
                    this.dt = new Date(this._date);
                }
            }
        } else {
            this.dt = new Date();
        }
        this.originalDate = this.dt;
        this.tempDt = this.dt;
        this.selectedDay = new DatePipe('en-US').transform(this.get_Date(), 'shortDate');
        if (!this.lifeLineDateSet) {
            this.lifeLineDateSet = true;
            this.selectedDayLifeLine = cloneDeep(this.selectedDay);
        }
        (this.tomorrow = new Date()).setDate(this.tomorrow.getDate() + 1);
        (this.afterTomorrow = new Date()).setDate(this.tomorrow.getDate() + 2);
        this.events = [
            { date: this.tomorrow, status: 'full' },
            { date: this.afterTomorrow, status: 'partially' }
        ];
    }
    private myOldDate: any;
    @Input()
    set Date(date: string) {
        if (date && date !== null && date !== undefined) {
            if (this.isLifeline || this.isLifelinenlad) {
                this.selectedDayLifeLine = new DatePipe('en-US').transform(date, 'shortDate');
            }
            this._date = date.trim().substr(0, 10).replace(/-/g, '\/');
            this.dt = new Date(this._date);
            this.myOldDate = this.dt;
        } else {
            this.dt = new Date();
        }
        this.originalDate = this.dt;
        this.tempDt = this.dt;
        this.selectedDay = new DatePipe('en-US').transform(this.get_Date(), 'shortDate');
        if (!this.lifeLineDateSet) {
            this.lifeLineDateSet = true;
            this.selectedDayLifeLine = cloneDeep(this.selectedDay);
        }
        (this.tomorrow = new Date()).setDate(this.tomorrow.getDate() + 1);
        (this.afterTomorrow = new Date()).setDate(this.tomorrow.getDate() + 2);
        this.events = [
            { date: this.tomorrow, status: 'full' },
            { date: this.afterTomorrow, status: 'partially' }
        ];
    }
    public existingProductsData: any;
    public pendingProductsData: any;
    public reservedAppointmentData: any;
    public constructor(
        private logger: Logger,
        private productService: ProductService,
        private systemErrorService: SystemErrorService,
        public store: Store<AppStore>,
        private ctlHelperService: CTLHelperService) {
        this.minDate = new Date();
        this.maxDate = new Date();
        this.allowed_month = <Observable<any>>this.store.select('cart');
        this.user = <Observable<User>>this.store.select('user');
        let userSubscription = this.user.subscribe(data => { this.userData = data; });
        if (userSubscription !== undefined) userSubscription.unsubscribe();
        this.monthSubscription = this.allowed_month.subscribe(data => this.date_limit = data.Allowed_date);
        if (this.date_limit && this.date_limit !== undefined && this.date_limit !== null && this.date_limit !== "") {
            this.maxDate.setMonth(this.maxDate.getMonth() + this.date_limit);
        } else {
            this.maxDate.setMonth(this.maxDate.getMonth() + 1);
        }
        this.dt = new Date();
        this.originalDate = new Date();
        this.tempDt = this.dt;
        this.selectedDay = new DatePipe('en-US').transform(this.get_Date(), 'shortDate');
        (this.tomorrow = new Date()).setDate(this.tomorrow.getDate() + 1);
        (this.afterTomorrow = new Date()).setDate(this.tomorrow.getDate() + 2);
        this.events = [
            { date: this.tomorrow, status: 'full' },
            { date: this.afterTomorrow, status: 'partially' }
        ];
        let existingProducts = <Observable<any>>this.store.select('existingProducts');
        let existingProductsSubscription = existingProducts.subscribe(data => this.existingProductsData = data);
        if (existingProductsSubscription !== undefined) existingProductsSubscription.unsubscribe();
        let pendingProducts = <Observable<any>>this.store.select('pending');
        let pendingProductsSubscription = pendingProducts.subscribe(data => this.pendingProductsData = data);
        if (pendingProductsSubscription !== undefined) pendingProductsSubscription.unsubscribe();
        let exxistingRetainData = <Observable<any>>this.store.select('retain');
        exxistingRetainData.subscribe(retdata => {
            if (retdata && retdata.retainscheduling && retdata.retainscheduling !== undefined) {
                this.retainSchedulingData = retdata.retainscheduling;
            }
            this.reservedAppointmentData = retdata.selectedappointment;
            if (this.reservedAppointmentData && this.reservedAppointmentData.commitmentDateTime) {
                this.maxDate = new Date(this.reservedAppointmentData.commitmentDateTime.trim().substr(0, 10).replace(/-/g, '\/'));
            }
        })
    }

    public ngOnInit() {
        this.getOverrideReasons();
        this.accRecurring = this.isAccRecurring;
        let customizeData = <Observable<any>>this.store.select('customize');
        customizeData.subscribe((data) => {
            if(data && data.simpleportcheck && data.simpleportcheck !== undefined && data.simpleportcheck.portCheckResponse && data.simpleportcheck.portCheckResponse !== undefined && data.simpleportcheck.portCheckResponse.length > 0 && data.payload.reservedTN && data.payload.reservedTN[0].requestedTelephoneNumber){
                if(data.payload.reservedTN[0].requestedTelephoneNumber === data.simpleportcheck.portCheckResponse[0].telephoneNumber){
                    this.isPortingDone = data.simpleportcheck.portCheckResponse[0].portable === "YES" ? "Yes" : "No";                                    
                }
            }
        });
    }

    public ngOnDestroy(): void {
        this.store.dispatch({ type: 'DATE_PICKER_ALLOWED_MONTH', payload: "" });
    }

    public get_Date(): number { //NOSONAR
        return this.dt && this.dt.getTime() || new Date().getTime();
    }
    public onSearchChange(event: any, searchValue: string) {
        event.stopPropagation();
        if (searchValue.trim().length === 0) {
            searchValue = null;
        }
        if (this.isLifeline || this.isLifelinenlad) {
            this.dateUpdated.emit(searchValue);
        }
    }
    public cancelClick() {
        this.popup.hide();
        this.dt = this.originalDate;
    }

    public setAppointment() {
        var mrgletterNumber = /^[0-9a-zA-Z]+$/;
        if (this.enableDropDown && this.isOverrideClicked) {
            if (this.isSelectedOption) {
                this.displayError = false;
            }
            else {
                this.displayError = true;
                this.errorMessage = 'Please select a valid reason';
                return;
            }
            if (this.mgrInitials.trim().length === 3 && this.mgrInitials.match(mrgletterNumber)) {
                this.displayError = false;
                this.additionalAttr.map(addlAttr => {
                    addlAttr.orderAttributeGroup.map(attrGrp => {
                        attrGrp.orderAttributeGroupInfo.map(attrGrpInfo => {
                            attrGrpInfo.orderAttributes.map(orderAttr => {
                                if (orderAttr.orderAttributeName === 'mgrInitials') {
                                    orderAttr.orderAttributeValue = this.mgrInitials;
                                }

                            });
                        });
                    });
                });
            }
            else {
                this.displayError = true;
                this.errorMessage = 'Please enter valid mgr initials';
                return;
            }
        }
        if (!this.displayError && this.isOverrideClicked) {
            this.additionalInfo.emit(this.additionalAttr);
        }
        this.popup.hide();
        let convertedDate = this.ctlHelperService.convertDateFormat(this.get_Date());
        this.selectedDay = new DatePipe('en-US').transform(convertedDate, 'shortDate');
        this.selectedDayLifeLine = cloneDeep(this.selectedDay);
        let lSelectedDay = new Date(this.selectedDay);
        let lyear = lSelectedDay.getFullYear();
        let lmonth: any = lSelectedDay.getMonth() + 1;
        let ldt: any = lSelectedDay.getDate();
        if (ldt < 10) { ldt = '0' + ldt; }
        if (lmonth < 10) { lmonth = '0' + lmonth; }
        convertedDate = lyear + '-' + lmonth + '-' + ldt + 'T00:00:00.000Z';
        this.myOldDate = new Date(convertedDate.trim().substr(0, 10).replace(/-/g, '\/'));
        this.dateUpdated.emit(convertedDate);
        this.originalDate = this.dt;
        this.tempDt = this.dt;
    }

    public getDayClass(date: any, mode: string): string {
        if (mode === 'day') {
            let dayToCheck = new Date(date).setHours(0, 0, 0, 0);
            for (let event of this.events) {
                let currentDay = new Date(event.date).setHours(0, 0, 0, 0);
                if (dayToCheck === currentDay) {
                    return event.status;
                }
            }
        }
        return '';
    }

    public getOverrideReasons() {
        let request: any = {
            "rsnType": "OVERRIDE"
        }
        this.logger.log("info", "datepicker-endate.component.ts", "getResponseForRemoveRequest", JSON.stringify(request));
        this.logger.startTime();
        this.loading = true;
        this.productService.getResponseForRemove(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker-endate.component.ts", "getResponseForRemoveResponse", error);
                this.logger.log("error", "datepicker-endate.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "Submit Task", "offer.component.ts",
                    "Disconnect Remove Response - Offers Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "datepicker-endate.component.ts", "getResponseForRemoveResponse", JSON.stringify(respData));
                    this.logger.log("info", "datepicker-endate.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.overrideReasons = respData.bmReasonCodes;
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "datepicker-endate.component.ts", "getResponseForRemoveResponse", error);
                    this.logger.log("error", "datepicker-endate.component.ts", "getResponseForRemoveSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.component.ts", "Offers Page", this.apiResponseError);
                    } else {
                        let errorResponseArray: ErrorResponse[] = [];
                        let localErrorResponse: ErrorResponse = {
                            orderRefNumber: error.payload.orderReferenceNumber,
                            statusCode: serverErrorMessages.statusCode,
                            reasonCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDownAddons,
                            messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                            serverDown: serverErrorMessages.serverDown
                        }
                        errorResponseArray.unshift(localErrorResponse);
                        let lAPIErrorLists: APIErrorLists = {
                            errorResponse: errorResponseArray
                        };
                        this.systemErrorService.logAndeRouteToSystemError("error", "selectProductError ", "offer.component.ts", "Offers Page", lAPIErrorLists);
                    }
                });
    }

    public disabled(date: Date, mode: string): boolean {
        return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
    }

    public open(): void {
        this.opened = !this.opened;
    }

    public clear(): void {
        this.dt = void 0;
        this.dateDisabled = undefined;
    }

    public toggleMin(): void {
        this.dt = new Date(this.minDate.valueOf());
    }

    public isSelectedOption: boolean = false;
    public onChangeDueDateReason(event) {
        if (event === 'Choose reason ...') {
            this.isSelectedOption = false;
        }
        else {
            this.isSelectedOption = true;
        }
        this.overrideReasons.map(reason => {
            if (event === reason.chgDesc) {
                this.additionalAttr.map(addlAttr => {
                    addlAttr.orderAttributeGroup.map(attrGrp => {
                        attrGrp.orderAttributeGroupInfo.map(attrGrpInfo => {
                            attrGrpInfo.orderAttributes.map(orderAttr => {
                                if (orderAttr.orderAttributeName === 'overrideReasonCode') {
                                    orderAttr.orderAttributeValue = reason.rsnCode;
                                }
                                else if (orderAttr.orderAttributeName === 'overrideReasonDescr') {
                                    orderAttr.orderAttributeValue = reason.chgDesc;
                                }
                            });
                        });
                    });
                });
            }
        });
    }

    public getOverrideReasonsDisplay() {
        this.maxDate = cloneDeep(this.minDate);
        this.totalOverrideDates = this.addOverride + 30;
        this.maxDate.setDate(this.maxDate.getDate() + this.totalOverrideDates);
        this.isOverrideClicked = true;
        this.numberOfDay = new Date();
        this.numberOfDays = this.minDate.getDate() - this.numberOfDay.getDate();
        this.minDate.setDate(this.minDate.getDate() - this.numberOfDays);
        this.dt = new Date(this.minDate.valueOf());
        this.tempDt = this.dt;
    }

    public onChange(event) {
        if (this.noCalendar && this.noCalendar === "MOVE") {
            this.cancelClick();
        }

        if (this.calculatedDate && (event.setHours(0, 0, 0, 0) > this.calculatedDate.setHours(0, 0, 0, 0) || this.isOverrideClicked)) {
            this.enableDropDown = true;
        }
        else {
            this.enableDropDown = false;
        }
    }

    public onLeftNavClick(event) {
        let ld = new Date(new DatePipe('en-US').transform(event, 'shortDate')), nextMonth: Date;
        if (ld.getMonth() === 11) {
            nextMonth = new Date(ld.getFullYear() + 1, 0, 1);
        } else {
            nextMonth = new Date(ld.getFullYear(), ld.getMonth() + 1, 1);
        }
        let y = nextMonth.getFullYear(), m = nextMonth.getMonth();
        let firstDay = new Date(y, m, 1), lastDay = new Date(y, m + 1, 0);
        let request: any = {};
        if (this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "Change") {
            request = {
                "orderRefNumber": this.existingProductsData.orderInit && this.existingProductsData.orderInit.orderRefNumber,
                "geography": {
                    "wirecenter": this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locationAttributes
                        && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locationAttributes.wirecenter,
                    "city": this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locality,
                    "state": this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else if (this.existingProductsData && this.existingProductsData.orderFlow && (this.existingProductsData.orderFlow.flow === "Disconnect" || this.existingProductsData.orderFlow.flow === "Existing")) {
            request = {
                "orderRefNumber": this.existingProductsData.orderFlow.flow === "Disconnect" ? this.retainSchedulingData && this.retainSchedulingData.orderRefNumber : this.existingProductsData,
                "geography": {
                    "wirecenter": this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locationAttributes
                        && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locationAttributes.wirecenter,
                    "city": this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locality,
                    "state": this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else if (this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "Move") {
            request = {
                "orderRefNumber": this.userData && this.userData.orderInit && this.userData.orderInit.orderRefNumber,
                "geography": {
                    "wirecenter": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.newLocation.serviceAddress && this.userData.orderInit.payload.newLocation.serviceAddress.locationAttributes
                        && this.userData.orderInit.payload.newLocation.serviceAddress.locationAttributes.wirecenter,
                    "city": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.newLocation.serviceAddress &&
                        this.userData.orderInit.payload.newLocation.serviceAddress.locality,
                    "state": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.newLocation.serviceAddress &&
                        this.userData.orderInit.payload.newLocation.serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(this.minDate, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(this.maxDate, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else if (this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "EXISTING" && this.pendingProductsData && this.pendingProductsData.orderReference.customerOrderStatus === "PENDING") {
            request = {
                "orderRefNumber": this.pendingProductsData.schedule && this.pendingProductsData.schedule.orderRefNumber,
                "geography": {
                    "wirecenter": this.pendingProductsData.orderDocument.serviceAddress && this.pendingProductsData.orderDocument.serviceAddress.locationAttributes
                        && this.pendingProductsData.orderDocument.serviceAddress.locationAttributes.wirecenter,
                    "city": this.pendingProductsData.orderDocument.serviceAddress && this.pendingProductsData.orderDocument.serviceAddress.locality,
                    "state": this.pendingProductsData.orderDocument.serviceAddress && this.pendingProductsData.orderDocument.serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else if (this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "EXISTING") {
            request = {
                "orderRefNumber": this.userData && this.userData.orderInit && this.userData.orderInit.orderRefNumber,
                "geography": {
                    "wirecenter": this.existingProductsData.existingProductsAndServices && this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locationAttributes
                        && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locationAttributes.wirecenter,
                    "city": this.existingProductsData.existingProductsAndServices && this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.locality,
                    "state": this.existingProductsData.existingProductsAndServices && this.existingProductsData.existingProductsAndServices[0].serviceAddress && this.existingProductsData.existingProductsAndServices[0].serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else if ((this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "NEWINSTALL" && this.pendingProductsData && this.pendingProductsData.orderReference !== undefined && this.pendingProductsData.orderReference.customerOrderStatus !== undefined && this.pendingProductsData.orderReference.customerOrderStatus === "PENDING") || (this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "NEWINSTALL" && this.userData.previousUrl === '/pending-order')) {
            request = {
                "orderRefNumber": this.pendingProductsData.orderReference && this.pendingProductsData.orderReference.orderReferenceNumber,
                "geography": {
                    "wirecenter": this.pendingProductsData && this.pendingProductsData.orderDocument && this.pendingProductsData.orderDocument.serviceAddress && this.pendingProductsData.orderDocument.serviceAddress.locationAttributes
                        && this.pendingProductsData.orderDocument.serviceAddress.locationAttributes.wirecenter,
                    "city": this.pendingProductsData && this.pendingProductsData.orderDocument
                        && this.pendingProductsData.orderDocument.serviceAddress.locality,
                    "state": this.pendingProductsData && this.pendingProductsData.orderDocument
                        && this.pendingProductsData.orderDocument.serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else if (this.existingProductsData && this.existingProductsData.orderFlow && this.existingProductsData.orderFlow.flow === "NEWINSTALL" && this.userData.previousUrl !== '/pending-order') {
            request = {
                "orderRefNumber": this.userData && this.userData.orderInit && this.userData.orderInit.orderRefNumber ? this.userData.orderInit.orderRefNumber : this.pendingProductsData.orderReference &&
                    this.pendingProductsData.orderReference.orderReferenceNumber,
                "geography": {
                    "wirecenter": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.serviceAddress && this.userData.orderInit.payload.serviceAddress.locationAttributes
                        && this.userData.orderInit.payload.serviceAddress.locationAttributes.wirecenter,
                    "city": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.serviceAddress &&
                        this.userData.orderInit.payload.serviceAddress.locality,
                    "state": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.serviceAddress &&
                        this.userData.orderInit.payload.serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        } else {
            request = {
                "orderRefNumber": this.userData && this.userData.orderInit && this.userData.orderInit.orderRefNumber,
                "geography": {
                    "wirecenter": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.serviceAddress && this.userData.orderInit.payload.serviceAddress.locationAttributes
                        && this.userData.orderInit.payload.serviceAddress.locationAttributes.wirecenter,
                    "city": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.serviceAddress &&
                        this.userData.orderInit.payload.serviceAddress.locality,
                    "state": this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.serviceAddress &&
                        this.userData.orderInit.payload.serviceAddress.stateOrProvince
                },
                "submarketCode": null,
                "portTN":this.isPortingDone,
                "durationStartDate": new DatePipe('en-US').transform(firstDay, 'yyyy-MM-ddTHH:mm:ss'),
                "durationEndDate": new DatePipe('en-US').transform(lastDay, 'yyyy-MM-ddTHH:mm:ss')
            }
        }
        this.logger.log("info", "datepicker-endate.component.ts", "getHolidaysDateRequest", JSON.stringify(request));
        this.logger.startTime();
        this.loading = true;
        this.productService.getHolidaysDate(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "datepicker-endate.component.ts", "getHolidaysDateResponse", error);
                this.logger.log("error", "datepicker-endate.component.ts", "getHolidaysDateSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "Submit Task", "offer.component.ts", "Disconnect Remove Response - Offers Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                this.logger.endTime();
                this.logger.log("info", "datepicker-endate.component.ts", "getHolidaysDateResponse", JSON.stringify(respData));
                this.logger.log("info", "datepicker-endate.component.ts", "getHolidaysDateSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                    if (respData && respData.exceptionDaysInfo && respData.exceptionDaysInfo.dueDateExceptionDays)
                        this.dateToBeDisabled(respData.exceptionDaysInfo.dueDateExceptionDays);
                })
    }
    public tempDt: Date;
    public onRightNavClick(event) {
        this.dt = this.tempDt;
    }
}
