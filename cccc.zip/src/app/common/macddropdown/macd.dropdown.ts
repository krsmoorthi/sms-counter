import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'eshop-macd-dropdown',
    templateUrl: './macd.dropdown.html',
    styleUrls: ['./macd.dropdown.scss']
})

export class MACDDropdown {
    @Input() public dropdownTitle: string;
    @Input() public stackAmend: any;
    @Input() public isHoldEnable: boolean;
    @Output() public backClicked = new EventEmitter();
    @Output() public discardClicked = new EventEmitter();
    @Output() public cancelClicked = new EventEmitter();
    @Output() public onHoldClicked = new EventEmitter();


    public constructor() { }
    
    public cancelOrder() {
        this.cancelClicked.emit();
    }

    public goBackToExistingProducts() {
        this.backClicked.emit();
    }

    public discardChanges () {
        this.discardClicked.emit();
    }
    
    public orderOnHold() {
        this.onHoldClicked.emit();
    }
}
