import { Component, Output, EventEmitter, OnInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, FormBuilder } from '@angular/forms';
import { Country } from '../models/country.model';
import { State } from '../models/state.model';
import { EnterpriseAddress } from '../models/cart.model';
import { AppStore } from '../models/appstore.model';
import { AddressService } from '../service/address.service';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../service/app-state.service';
import { Logger } from '../logging/default-log.service';
import { GenericValues, serverErrorMessages, APIErrorLists } from '../models/common.model';
import { SystemErrorService } from '../service/system-error.service';
import { CTLHelperService } from '../service/ctlHelperService';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'workingServiceMove',
    styleUrls: ['./workingservice-move.component.scss'],
    templateUrl: './workingservice-move.component.html'
})

export class WorkingServiceMoveComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public myForm: FormGroup;
    public phoneMask: any;
    public finalAddress: EnterpriseAddress;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public legacyTxt: any;
    public ban: any;
    public custName: any;
    public wsinfoList: any = [];
    public prodAvail: any = [];
    public invalidLocation: boolean = false;
    public enableContinue: boolean = false;
    @Output() public enableBtn: EventEmitter<any> = new EventEmitter<any>();

    constructor(
        private fb: FormBuilder,
        private addressService: AddressService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private logger: Logger,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService
    ) {
        this.appStateService.setLocationURLs();
        this.user = <Observable<User>>store.select('user');
        this.myForm = this.fb.group({
            locationChk: ['', []]
        });
    }

    public ngOnInit() {
        this.userSubscription = this.user.subscribe((data) => {
            if (data) {
                this.finalAddress = data.finalAddress;
                if (data.workingServiceInfo) {
                    data.workingServiceInfo.forEach((wsi) => {
                        this.prodAvail = [];
                        let obj = Object.assign({}, wsi);
                        wsi.serviceCategory.map((p) => {
                            if (p === "VOICE-HP") {
                                this.prodAvail.push("Home Phone");
                            } else if (p === "DATA") {
                                this.prodAvail.push("Internet");
                            } else if (p === "DTV") {
                                this.prodAvail.push("DIRECTV");
                            } else if (p === "VOICE-DHP") {
                                this.prodAvail.push("Digital Home Phone");
                            }
                        });
                        obj.productAvailable = this.prodAvail.join(', ');
                        if (wsi.ban) {
                            this.ban = wsi.ban;
                        }
                        if (wsi.customerName) {
                            this.custName = wsi.customerName;
                        }
                        this.wsinfoList.push(obj);
                    });
                }
                this.legacyTxt = data && data.orderInit && data.orderInit.payload && data.orderInit.payload.newLocation && data.orderInit.payload.newLocation.serviceAddress && data.orderInit.payload.newLocation.serviceAddress.locationAttributes && data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider;
            }
        });
        this.userSubscription.unsubscribe();
    }
    /**
     * To mask phone number as pe USA format (xxx-xx-xxxx)
     * @param data as response
     */
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }
    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacyTxt === 'CENTURYLINK') {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22YxNjUxODM0MjdkNDFjOTRl%22%2C%22ssid%22%3A%224wov0lTbRPux_0a7EPmLRA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
        } else {
            url = '';
        }
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }
    public onSelected(value: any) {
        this.enableContinue = true;
        this.enableBtn.emit(this.enableContinue);
        if (value === "No") {
            this.invalidLocation = true;
        } else {
            this.invalidLocation = false;
        }
        this.store.dispatch({ type: 'LOCATION_AVAILABLE', payload: value });
    }
}
