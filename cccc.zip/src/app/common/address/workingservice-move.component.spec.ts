/* tslint:disable */
import { } from 'jasmine';
import { TestBed, ComponentFixture, async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { Router, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileService } from 'app/common/service/profile.service';
import {
    MockSystemErrorService,
    MockAppStateService,
    MockAddressService,
    MockLogger,
    MockCountryStateService,
    MockRouter,
    MockTextMaskService,
    MockPropertiesHelperService,
    MockProductService,
    MockBlueMarbleService,
    MockHelperService,
    MockProfileService
} from 'app/common/service/mockServices.test';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { WorkingServiceMoveComponent } from './workingservice-move.component';
import { TextMaskModule } from 'angular2-text-mask';
import { TypeaheadModule } from 'ngx-bootstrap';
import { Logger } from '../logging/default-log.service';

const routes: Routes = [
    {
        path: '', component: WorkingServiceMoveComponent
    }
];

describe('workingService Component', () => {
    let component: WorkingServiceMoveComponent;
    let fixture: ComponentFixture<WorkingServiceMoveComponent>;
    let mockServer = new MockServer();

    const mockRedux: any = {
        dispatch(obj) { return obj },
        configureStore() { },
        select(reducer) {
            return Observable.of(
                mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    };

    const p1 = FormBuilder;
    const p2 = CTLHelperService;
    const p3 = { provide: Router, useClass: MockRouter };
    const p4 = { provide: Logger, useClass: MockLogger };
    const p5 = { provide: Store, useValue: mockRedux };
    const p6 = { provide: AddressService, useClass: MockAddressService };
    const p7 = { provide: AppStateService, useClass: MockAppStateService };
    const p8 = { provide: CountryStateService, useClass: MockCountryStateService };
    const p9 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p10 = { provide: TextMaskService, useClass: MockTextMaskService };
    const p11 = { provide: ProductService, useClass: MockProductService };
    const p12 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
    const p13 = { provide: HelperService, useClass: MockHelperService };
    const p14 = { provide: ProfileService, useClass: MockProfileService };
    const p15 = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };


    let baseConfig = {
        imports: [
            FormsModule,
            ReactiveFormsModule,
            SharedCommonModule,
            TextMaskModule,
            TypeaheadModule,
            RouterTestingModule
        ],
        declarations: [WorkingServiceMoveComponent],
        providers: [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15]
    }
    beforeEach(async(() => {
        TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(WorkingServiceMoveComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create WorkingService component', () => {
        expect(component).toBeTruthy;
    });
    it('should call ngOnInit()', () => {
        const data = mockServer.getMockStore('user');
        expect(component.myForm).toBeDefined();
        component.ngOnInit();
    });
    it('should call maskPhone() method...', () => {
        let phone = "4056782398";
        expect(component.maskPhone).toBeDefined();
        component.maskPhone(phone);
    });
    it('should call actPopup() method...', () => {
        let width = 400;
        let height = 400;
        expect(component.actPopup).toBeDefined();
        component.actPopup(width, height);
    });
    it("should check invalid scenario of radio buttons when value is undefined ", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.value == undefined;
        expect(radioBtn.invalid).toBeFalsy();
    });
    it("should check invalid scenario of radio buttons when value is empty.", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.setValue("");
        expect(radioBtn.invalid).toBeFalsy();
    });
    it("should check valid scenario of radio buttons when value is 'Yes'...", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.setValue('Yes');
        expect(radioBtn.valid).toBeTruthy();
    });
    it("should check valid scenario of radio buttons when value is 'No'...", () => {
        const radioBtn = component.myForm.get("locationChk");
        radioBtn.setValue('No');
        expect(radioBtn.valid).toBeTruthy();
    });
    it("should call onSelected() function when Radio Button Value 'Yes'...", () => {
        let val = "Yes";
        component.onSelected(val);
    });
    it("should call onSelected() function when Radio Button Value 'No'...", () => {
        let val = "No";
        component.onSelected(val);
    });
});