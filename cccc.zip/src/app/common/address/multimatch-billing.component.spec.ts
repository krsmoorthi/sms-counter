import { TestBed, ComponentFixture, inject, async } from "@angular/core/testing";
import { Observable, throwError } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockLogger, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { MultimatchBillingComponent } from './multimatch-billing.component';
import { TextMaskModule } from 'angular2-text-mask';
import { TypeaheadModule } from 'ngx-bootstrap';
import { TrimDirectiveModule } from '../trim/trim-directive.module';
import { Logger } from '../logging/default-log.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';


describe('Billing Order Multimatch Component', () => {
  let component: MultimatchBillingComponent;
  let fixture: ComponentFixture<MultimatchBillingComponent>;
  let mockServer = new MockServer();

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedCommonModule,
    TextMaskModule,
    TypeaheadModule,
    TrimDirectiveModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ];

  const mockRedux: any = {
    dispatch() { },
    configureStore() { },
    select(reducer) {
      return Observable.of(mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]);
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  }

  const p1 = { provide: AppStateService, useClass: MockAppStateService }
  const p2 = { provide: Store, useValue: mockRedux };
  const p3 = { provide: AddressService, useClass: MockAddressService };
  const p4 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const p5 = CTLHelperService;
  const p6 = { provide: Logger, useClass: MockLogger }

  let dp1 = { provide: PendingOrderService, useClass: MockPendingOrderService };
  let dp2 = { provide: AccountService, useClass: MockAccountService };
  let dp3 = { provide: CountryStateService, useClass: MockCountryStateService };
  let dp4 = { provide: DirectvService, useClass: MockDirectvService };
  let dp5 = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
  let dp6 = { provide: DisconnectService, useClass: MockDisconnectService };

  const providers =  [p1, p2, p3, p4, p5, p6, dp1, dp2, dp3, dp4, dp5, dp6];


  describe('Billing Order Multimatch Component Success', () => {  

    const baseConfig = {
      imports: imports,
      declarations: [MultimatchBillingComponent],
      providers: providers
    };
  
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
        .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(MultimatchBillingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  
    it('should call setFinalAddress', () => {
      component.setFinalAddress(null);
      expect(component.finalAddress).toBe(null);
    });
  
    it('should call ngOnInit', () => {
      component.ngOnInit();
      expect(component.searchFlag).toBe(false);
    });
  
    it('should call onClickYellowAddress', () => {
     
      component.onClickYellowAddress(null);
      expect(component.yellowAddress).toBe(null);
    });
  
    it('should check checkBillingRecAddress response without yellow address', () => {
      
      component.selectedMatch();
      expect(component.loading).toBe(false);
    });
  
    xit('should check checkBillingRecAddress response with yellow address', () => {
      component.yellowAddress = {
        'streetAddress': '1616 SHOUP ST',
        'addressLine': '1616 SHOUP ST,SALMON,ID,83467,USA',
        'stateOrProvince': 'ID',
        'city': 'SALMON'
      };
      let mockRouter = TestBed.get(Router);
              spyOn(mockRouter, 'navigate');
      component.selectedMatch();
      expect(component.loading).toBe(false);
      expect((component as any).router.navigate).toHaveBeenCalledWith(['/billing-product']);
    });
  
    it('should check checkBillingRecAddress response without ordernumber', () => {
      component.orderDetails = ""
      component.selectedMatch();
      expect(component.loading).toBe(false);
    });
    
  



  })


  describe('Billing Order Multimatch Component Error', () => {  
    class MockAddressService {
      checkBillingRecAddress() {
        return throwError({error:{errorResponse: []}})
     }
    }
    const p3 = { provide: AddressService, useClass: MockAddressService };

    const _provides = [...providers, { provide: AddressService, useClass: MockAddressService }];
    const baseConfig = {
      imports: imports,
      declarations: [MultimatchBillingComponent],
      providers: _provides
    };
  
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
        .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(MultimatchBillingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
    it('should check checkBillingRecAddress response without ordernumber', () => {
      component.orderDetails = ""
      component.selectedMatch();
      expect(component.loading).toBe(false);
    });

  })

  
});


