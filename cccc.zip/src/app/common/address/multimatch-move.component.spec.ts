import { TestBed, ComponentFixture, inject, async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockLogger } from 'app/common/service/mockServices.test';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { MultimatchMoveComponent } from './multimatch-move.component';
import { TextMaskModule } from 'angular2-text-mask';
import { TypeaheadModule } from 'ngx-bootstrap';
import { TrimDirectiveModule } from '../trim/trim-directive.module';
import { Logger } from '../logging/default-log.service';

describe('Move Order Review Order Component', () => {
  let component: MultimatchMoveComponent;
  let fixture: ComponentFixture<MultimatchMoveComponent>;
  let mockServer = new MockServer();

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedCommonModule,
    TextMaskModule,
    TypeaheadModule,
    TrimDirectiveModule
  ];
  
  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]);
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }
  
  const p1 = { provide: AppStateService, useClass: MockAppStateService }
  const p2 = { provide: Store, useValue: mockRedux };
  const p3 = {provide: AddressService, useClass: MockAddressService};
  const p4 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const p5 = CTLHelperService;
  const p6 = { provide: Logger, useClass: MockLogger}
  
  let dp1 = {provide: PendingOrderService, useClass: MockPendingOrderService};
  let dp2 = {provide: AccountService, useClass: MockAccountService};
  let dp3 = {provide: CountryStateService, useClass: MockCountryStateService};
  let dp4 = {provide: DirectvService, useClass: MockDirectvService};
  let dp5 = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  let dp6 = {provide: DisconnectService, useClass: MockDisconnectService};

  const baseConfig = {
    imports: imports,
    declarations: [MultimatchMoveComponent],
    providers: [p1, p2, p3, p4, p5, p6, dp1, dp2, dp3, dp4, dp5, dp6]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultimatchMoveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should call setFinalAddress', () => {
    component.setFinalAddress(null);
    expect(component.finalAddress).toBe(null);
  });
  
  it('should call ngOnInit', () => {
    component.ngOnInit();
    expect(component.searchFlag).toBe(false);
  });
  
  xit('should check checkBillingRecAddress response without yellow address', () => {
    
    component.selectedMatch();
    expect(component.searchFlag).toBe(false);
  });
  
  xit('should call selectedMatch', () => {
    component.yellowAddress = {
        'streetAddress': '1616 SHOUP ST',
        'addressLine': '1616 SHOUP ST,SALMON,ID,83467,USA',
        'stateOrProvince': 'ID',
        'city': 'SALMON'
    };
    component.selectedMatch();
    expect(component.loading ).toBe(false);
  });
  
    it('should call onClickYellowAddress', () => {
        component.onClickYellowAddress(null);
        expect(component.yellowAddress).toBe(null);
    });
  
    it('should call yellowAddressDeposit', () => {
        let temp = component.yellowAddressDeposit();
        expect(temp).toBe(undefined);
    });
    
});