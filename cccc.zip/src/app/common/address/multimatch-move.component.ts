import { Component, Output, EventEmitter, OnInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, FormBuilder } from '@angular/forms';
import { Country } from '../models/country.model';
import { State } from '../models/state.model';
import { EnterpriseAddress } from '../models/cart.model';
import { AppStore } from '../models/appstore.model';
import { AddressService } from '../service/address.service';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../service/app-state.service';
import { Logger } from '../logging/default-log.service';
import { GenericValues, serverErrorMessages, APIErrorLists } from '../models/common.model';
import { SystemErrorService } from '../service/system-error.service';
import { CTLHelperService } from '../service/ctlHelperService';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'multipleMatchMoveAddress',
    styleUrls: ['./multimatch-move.component.scss'],
    templateUrl: './multimatch-move.component.html'
})

export class MultimatchMoveComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public myForm: FormGroup;
    public countries: Country[];
    public states: State[];
    public phoneMask: any;
    public yellowAddresses: EnterpriseAddress[] = [];
    public searchAddresses: EnterpriseAddress[] = [];
    public yellowAddress: EnterpriseAddress;
    public finalAddress: EnterpriseAddress;
    public searchFlag: boolean;
    public orderDetails: any;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public workingService: boolean = false;
    public slower: boolean;
    public availabledownSpeed: number;
    public downSpeed: number;
    public upSpeed: number;
    public faster: boolean;
    public availableupSpeed: number;
    public same: boolean;
    @Output() public multiMatchResp: EventEmitter<object> = new EventEmitter<object>();
    @Output() public multiMatchDeposit: EventEmitter<object> = new EventEmitter<object>();

    constructor(
        private fb: FormBuilder,
        private addressService: AddressService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private logger: Logger,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService
    ) {
        this.searchFlag = false;
        this.appStateService.setLocationURLs();
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe(
            (data) => {
                this.yellowAddresses = data.yellowAddress;
                this.finalAddress = data.finalAddress;
                this.orderDetails = data.orderInit;
            });
        this.myForm = this.fb.group({
            search: ['', []]
        });
    }

    public setFinalAddress(address) {
        this.finalAddress = address;
    }

    public ngOnInit() {
        window.scroll(0, 0);
        this.myForm.valueChanges.debounceTime(750)
            .subscribe((values) => {
                this.yellowAddress = {
                    streetAddress: '',
                    addressLine: '',
                    stateOrProvince: '',
                    city: ''
                };
                let value: string = this.myForm.value.search;
                if (value && value.trim().length > 0) {
                    this.searchAddresses = [];
                    this.searchFlag = true;
                    this.yellowAddresses.forEach((item) => {
                        if (item.streetAddress.indexOf(value) !== -1
                            || item.city.indexOf(value) !== -1
                            || item.stateOrProvince.indexOf(value) !== -1
                            || item.postCode.indexOf(value) !== -1
                            || item.country.indexOf(value) !== -1) {
                            this.searchAddresses.push(item);
                        }
                    });
                } else {
                    this.searchFlag = false;
                }
            });
    }

    public selectedMatch() {
        this.loading = true;
        if (this.yellowAddress === undefined || !this.yellowAddress.streetAddress) {
            this.errorMsg = serverErrorMessages.selectNearMatch;
            this.loading = false;
            window.scroll(0, 0);
            return false;
        }
        this.logger.log("info", "multimatch-move.component.ts", "checkAddressRequest", JSON.stringify(Object));
        this.logger.startTime();
        let errorResolved = false;
        this.addressService.checkAddress(Object.assign(this.yellowAddress, this.orderDetails, true),
            false, true)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "multimatch-move.component.ts", "checkAddressResponse", error);
                this.logger.log("error", "multimatch-move.component.ts", "checkAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "Multi Match MOVE", "multimatch-move.component.ts", "Multimatch MOVE Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "multimatch-move.component.ts", "checkAddressResponse", JSON.stringify(data));
                    this.logger.log("info", "multimatch-move.component.ts", "checkAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let response = data;
                    this.logger.log("info", "multimatch-move.component.ts", "Multi match MOVE response", JSON.stringify(data ? data : ''));
                    if (response && response.taskName === 'Select Product') {
                        if (response.payload) {
                            this.multiMatchResp.emit({ success: response });
                            this.loading = false;
                        }
                        this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                        if (this.finalAddress !== null) {
                            this.yellowAddress = Object.assign({},
                                this.yellowAddress, {
                                singleLine: this.finalAddress.singleLine
                            });
                        }
                        this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.yellowAddress });
                        let internetCheck;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (this.addressService.checkCategoryId(GenericValues.sData,
                            response.payload.newLocation.serviceCategory) !== undefined) {
                            internetCheck = true;
                        }
                        if (this.addressService.checkCategoryId('DATA/VIDEO',
                            response.payload.newLocation.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: 'DATA/VIDEO',
                                displayName: 'PRISM TV',
                                code: 'PTV',
                                tabName: 'PRISM'
                            });
                        }
                        if (this.addressService.checkCategoryId('VIDEO-DTV',
                            response.payload.newLocation.serviceCategory) !== undefined) {
                            videoAvail = true;
                            videoType.push({
                                name: 'VIDEO-DTV',
                                displayName: 'DIRECTV',
                                code: 'DTV',
                                tabName: 'DIRECTV'
                            });
                        }
                        if (this.addressService.checkCategoryId('VOICE-DHP',
                            response.payload.newLocation.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: 'VOICE-DHP',
                                displayName: 'Digital(DHP)',
                                code: 'DHP',
                                tabName: 'DHP'
                            });
                        }
                        if (this.addressService.checkCategoryId('VOICE-HP',
                            response.payload.newLocation.serviceCategory) !== undefined) {
                            phoneAvail = true;
                            phoneType.push({
                                name: 'VOICE-HP',
                                displayName: 'Home Phone',
                                code: 'HMP',
                                tabName: 'Home Phone'
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: response.payload.newLocation.serviceCategory
                        };
                        this.store.dispatch({ type: 'UPDATE_USER', payload: user });
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "multimatch-move.component.ts", "checkAddressResponse", error);
                        this.logger.log("error", "multimatch-move.component.ts", "checkAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "multimatch-move", "multimatch-move.component.ts", "Multi Match Move Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "multimatch-move", "multimatch-move.component.ts", "Multi Match Move Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public onClickYellowAddress(value: EnterpriseAddress) {
        this.yellowAddress = value;
    }

    public yellowAddressDeposit() {
        this.store.dispatch({ type: "CHANGE_ADDRESS_DEPOSIT", payload: this.yellowAddress });
        this.multiMatchDeposit.emit(this.yellowAddress);
    }
}
