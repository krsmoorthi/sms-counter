import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, FormBuilder } from '@angular/forms';
import { Country } from '../models/country.model';
import { State } from '../models/state.model';
import { EnterpriseAddress } from '../models/cart.model';
import { AppStore } from '../models/appstore.model';
import { AddressService } from '../service/address.service';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../service/app-state.service';
import { SystemErrorService } from "app/common/service/system-error.service";
import { Logger } from '../logging/default-log.service';
import {
    GenericValues, serverErrorMessages, APIErrorLists,
    ErrorResponse
} from '../models/common.model';
import { CTLHelperService } from '../service/ctlHelperService';
import "rxjs/add/operator/catch";

@Component({
    selector: 'multipleMatchBillingAddress',
    styleUrls: ['./multimatch-billing.component.scss'],
    templateUrl: './multimatch-billing.component.html'
})

export class MultimatchBillingComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public myForm: FormGroup;
    public countries: Country[];
    public states: State[];
    public phoneMask: any;
    public yellowAddresses: EnterpriseAddress[] = [];
    public searchAddresses: EnterpriseAddress[] = [];
    public yellowAddress: EnterpriseAddress;
    public finalAddress: EnterpriseAddress;
    public searchFlag: boolean;
    public orderDetails: any;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public workingService:boolean = false;
    @Output() public multiMatchResp: EventEmitter<object> = new EventEmitter<object>();

    constructor(
        private router: Router,
        private fb: FormBuilder,
        private addressService: AddressService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private logger: Logger,
        private ctlHelperService: CTLHelperService) {
            this.searchFlag = false;
            this.appStateService.setLocationURLs();
            this.user = <Observable<User>> store.select('user');
            this.userSubscription = this.user.subscribe(
                (data) => {
                    this.yellowAddresses = data.yellowAddress;
                    this.finalAddress = data.finalAddress;
                    this.orderDetails = data.orderInit;
                });
            this.myForm = this.fb.group({
                search: ['', []]
            });
        }
    public setFinalAddress(address) {
        this.finalAddress = address;
    }
    public ngOnInit() {}

    public selectedMatch() {
        this.loading = true;
        if (this.yellowAddress === undefined) {
            this.errorMsg = serverErrorMessages.selectNearMatch;
            this.loading = false;
            window.scroll(0, 0);
            return false;
        }
        this.logger.log("info", "multimatch-billing.component.ts", "checkBillingRecAddressRequest", JSON.stringify(this.yellowAddress, this.orderDetails));  
        this.logger.startTime();
        let errorResolved = false;
        this.addressService.checkBillingRecAddress(Object.assign(this.yellowAddress, this.orderDetails, true),
            false,true)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "multimatch-billing.component.ts", "checkBilingRecAddressResponse", JSON.stringify(error));
                this.logger.log("error", "multimatch-billing.component.ts", "checkBillingRecAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable', 
                    "Submit task", 
                    "multimatch-billing.component.ts", "Multi match Billing response", 
                  error);
                return Observable.throwError(null);
            })
            .subscribe(
            (data) => {
                this.logger.endTime();
		        this.logger.log("info", "multimatch-billing.component.ts", "checkBilingRecAddressResponse", JSON.stringify(data));
                this.logger.log("info", "multimatch-billing.component.ts", "checkBillingRecAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                let response = data;
                this.logger.log("info", "multimatch-billing.component.ts", "Multi match Billing response", JSON.stringify(data ? data : ''));
                if (response && response.taskName === 'Select Product') {
                    if ( response.payload ) {
                        this.loading = false;
                     }
                    this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                    if (this.finalAddress !== null) {
                        this.yellowAddress = Object.assign({},
                            this.yellowAddress, {
                                singleLine: this.finalAddress.singleLine // true
                            });
                    }
                    this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.yellowAddress });
                    let internetCheck;
                    let videoAvail;
                    let phoneAvail: boolean = false;
                    let phoneType=[];
                    let videoType = [];
                    if (this.addressService.checkCategoryId(GenericValues.sData,
                        response.payload.serviceCategory) !== undefined) {
                        internetCheck = true;
                    }
                    if (this.addressService.checkCategoryId('DATA/VIDEO',
                        response.payload.serviceCategory) !== undefined) {
                        videoAvail = true;
                        videoType.push({
                            name:'DATA/VIDEO',
                            displayName:'PRISM TV',
                            code: 'PTV',
                            tabName:'PRISM'
                        });
                    }
                    if (this.addressService.checkCategoryId('VIDEO-DTV',
                    response.payload.serviceCategory) !== undefined) {
                    videoAvail = true;
                    videoType.push({
                        name:'VIDEO-DTV',
                        displayName:'DIRECTV',
                        code: 'DTV',
                        tabName:'DIRECTV'
                    });
                    }
                    if (this.addressService.checkCategoryId('VOICE-DHP',
                        response.payload.serviceCategory) !== undefined) {
                        phoneAvail = true;
                        phoneType.push({
                            name:'VOICE-DHP',
                            displayName:'Digital(DHP)',
                            code: 'DHP',
                            tabName:'DHP'
                        });
                    }
                    if (this.addressService.checkCategoryId('VOICE-HP',
                    response.payload.serviceCategory) !== undefined) {
                        phoneAvail = true;
                        phoneType.push({
                            name:'VOICE-HP',
                            displayName:'Home Phone',
                            code: 'HMP',
                            tabName:'Home Phone'
                        });
                }
                    let user: User = {
                        id: 1,
                        internetCheck,
                        videoCheck: videoAvail,
                        phoneCheck: phoneAvail,
                        phoneType: phoneType,
                        videoType: videoType,
                        enabledServiceList : response.payload.serviceCategory
                    };
                    this.store.dispatch({ type: 'UPDATE_USER', payload: user });
                    if(this.ctlHelperService.checkRuralAddress(response)){
                        this.multiMatchResp.emit({ success: response });
                    } else {
                        this.router.navigate(['/billing-product']);
                    }
                }
            },
            (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "multimatch-billing.component.ts", "checkBilingRecAddressResponse", error);
                    this.logger.log("error", "multimatch-billing.component.ts", "checkBillingRecAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                  }
                  this.loading = false;
                  if (error === undefined || error === null)
                    return;
                let unExpectedError = false;
                if(this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                        this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.logger.log('error', 'multimatch.component.ts', 'Multi match error',
                        this.apiResponseError.errorResponse[0].message);
                    } else unExpectedError = true;
                } else unExpectedError = true;
                if(unExpectedError) {
                    let errorResponseCustom: ErrorResponse = {
                        statusCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDown
                    };
                    if(this.apiResponseError && this.apiResponseError.errorResponse) {
                        this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                        this.logger.log('error', 'multimatch.component.ts', 'Multi match error',
                        this.apiResponseError.errorResponse[0].message);
                    }
                }
                window.scroll(0, 0);
            });
    }
    public onClickYellowAddress(value: EnterpriseAddress) {
        this.yellowAddress = value;
    }
}