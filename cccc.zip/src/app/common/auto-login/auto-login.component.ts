import { cloneDeep } from 'lodash';
import { Component, OnInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../logging/default-log.service';
import { AppStore } from '../models/appstore.model';
import { OAMData, SFCData, OrderActivity } from '../models/auto-login.model';
import { APIErrorLists, ErrorResponse, SystemError } from '../models/common.model';
import { User } from '../models/user.model';
import { AppStateService } from '../service/app-state.service';
import { AutoLoginService } from '../service/auto-login.service';
import { CTLHelperService } from '../service/ctlHelperService';
import { HelperService } from '../service/helper.service';
import { SystemErrorService } from '../service/system-error.service';
import "rxjs/add/operator/catch";

@Component({
    selector: 'auto-login',
    templateUrl: './auto-login.component.html'
})

export class AutoLoginComponent implements OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public systemError: SystemError;
    public fingerPrint: string;
    public oamData = {} as OAMData;

    constructor(
        private router: Router,
        public store: Store<AppStore>,
        private autoLoginService: AutoLoginService,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private route: ActivatedRoute,
        private logger: Logger,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
    ) {
    }

    public ngOnInit() {
        let token: '';
        this.loading = true;
        //var recommendedItems : Object;
        this.helperService.startNewOrderWithoutRouting("auto-login");

        var currentUser = {} as User;
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            currentUser = data;
        });
        this.userSubscription.unsubscribe();

        this.appStateService.setLocationURLs();

        this.route.queryParams.subscribe((params: Params) => {
            token = params['token'];
        });

        this.logger.log("info", "auto-login.component.ts", "token", JSON.stringify(token));
        if (token !== undefined && token.length > 0) {
            this.logger.log("info", "auto-login.component.ts", "autoLoginRequest", JSON.stringify(token));
            this.logger.startTime();
            let payload = token;
            let errorProcessed = false;
            this.autoLoginService.getAutoLoginData(payload)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "auto-login.component.ts", "autoLoginResponse", JSON.stringify(error));
                    this.logger.log("error", "auto-login.component.ts", "autoLoginSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorProcessed = true;
                    this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "INIT", "auto-login.component.ts", "Auto Login Page", error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "auto-login.component.ts", "autoLoginResponse", JSON.stringify(data ? data : ''));
                        this.logger.log("info", "auto-login.component.ts", "autoLoginSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        if (data.status && data.status === "Success") {
                            let returnData = data.data;
                            let sfcData = {} as SFCData;
                            sfcData.accountBAN = returnData.accountNumber;
                            sfcData.accountNumber = returnData.accountNumber;
                            sfcData.token = returnData.launchToken;
                            sfcData.callerFirstName = returnData.firstName;
                            sfcData.callerLastName = returnData.lastName;
                            sfcData.callerMiddleName = returnData.middleName;
                            sfcData.contactNumber = returnData.primaryPhone;
                            sfcData.contactNumberSecond = returnData.secondaryPhone;
                            sfcData.emailID = returnData.customerEmail;
                            sfcData.serviceAddress = returnData.geoFormatAddress;
                            sfcData.serviceAddressUnit = returnData.serviceStreet2;
                            sfcData.sfdcBillingAccountID = returnData.accountId;
                            sfcData.sfdcID = returnData.serviceAddressId;
                            sfcData.geoAddressId = returnData.geoAddressId;
                            sfcData.geoSubAddressId = returnData.geoSubAddressId;
                            sfcData.orderReferenceNumber = returnData.orderNumber;
                            sfcData.orderStatus = returnData.orderStatus;
                            sfcData.orderActivityType = returnData.orderActivityType;
                            sfcData.isPrimaryPhoneSms = returnData.isPrimaryPhoneSms;
                            sfcData.emailDeclined = returnData.emailDeclined;
                            sfcData.type = returnData.type;
                            if(returnData.recommendedItems){
                                //recommendedItems = returnData.recommendedItems;
                                sfcData.recommendedItems = cloneDeep(returnData.recommendedItems);
                                if(sfcData.recommendedItems && sfcData.recommendedItems[0].recommendedSubitems && sfcData.recommendedItems[0].recommendedSubitems.length > 0) {
                                    sfcData.recommendedItems[0].recommendedSubitems.forEach(recommendSubItems => {
                                        if(recommendSubItems.hasOwnProperty('recommendVacationOffer') && recommendSubItems.recommendVacationOffer === "true") {
                                            sfcData.recommendVacationOffer = true;
                                        }
                                        
                                    });
                                }
                            }

                            // Adding Order Activity Information
                            var orderActivity = {} as OrderActivity;
                            orderActivity.callStartTime = returnData.callStartDate ? returnData.callStartDate : 'NA';
                            orderActivity.ucid = returnData.UCID ? returnData.UCID : 'NA';
                            orderActivity.tfn = returnData.TFN ? returnData.TFN : 'NA';
                            sfcData.orderActivity = orderActivity;
                            currentUser.autoLogin.sfcData = sfcData;
                            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                            this.router.navigate(['/home']);
                            
                        }
                        else {
                            let unexpectedError = false;
                            if (this.ctlHelperService.isJson(data)) {
                                this.apiResponseError = JSON.parse(data);
                                if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", "autoLogin", "auto-login.component.ts", "Auto Login Page", this.apiResponseError);
                                } else unexpectedError = true;
                            } else unexpectedError = true;
                            if (unexpectedError) {
                                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                                this.systemErrorService.logAndeRouteToSystemError("error", "autoLogin", "auto-login.component.ts", "Auto Login Page", lAPIErrorLists);
                            }
                        }
                    },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "auto-login.component.ts", "autoLoginResponse", JSON.stringify(error));
                        this.logger.log("error", "auto-login.component.ts", "autoLoginSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        let unexpectedError = false;
                        if (!errorProcessed) {
                            this.logger.endTime();
                            if (this.ctlHelperService.isJson(error)) {
                                this.apiResponseError = JSON.parse(error);
                                if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                    this.systemErrorService.logAndeRouteToSystemError("error", "autoLogin", "auto-login.component.ts", "Auto Login Page", this.apiResponseError);
                                } else unexpectedError = true;
                            } else unexpectedError = true;
                            if (unexpectedError) {
                                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                                this.systemErrorService.logAndeRouteToSystemError("error", "autoLogin", "auto-login.component.ts", "Auto Login Page", lAPIErrorLists);
                            }
                        }
                    });
        }
        else {
            this.loading = false;
            let errorResponseArray: ErrorResponse[] = [];
            let localErrorResponse: ErrorResponse = {
                statusCode: '500',
                reasonCode: '500',
                message: 'No Auto Login Number provided',
                messageDetail: 'No Auto Login Number was passed into the auto-login url.  Contact SalesForce.'
            }
            errorResponseArray.unshift(localErrorResponse);
            let lAPIErrorLists: APIErrorLists = {
                errorResponse: errorResponseArray
            };
            this.systemErrorService.logAndeRouteToSystemError("error", "autoLogin", "auto-login.component.ts", "Auto Login Page", lAPIErrorLists);
        }

    }
    public sleep(milliseconds) {
        var start = new Date().getTime();
        for (var i = 0; i < 1e7; i++) {
            if ((new Date().getTime() - start) > milliseconds) {
                break;
            }
        }
    }
}
