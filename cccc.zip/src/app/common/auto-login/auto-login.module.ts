import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AutoLoginComponent } from './auto-login.component';
import { SharedModule } from '../../shared/shared.module';
import { AutoLoginService } from '../service/auto-login.service';
import { SharedCommonModule } from 'app/shared/shared-common.module';

const routes: Routes = [
    {
        path: '',
        component: AutoLoginComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule,
        SharedCommonModule,
        RouterModule,
        SharedModule
    ],
    exports: [AutoLoginComponent, RouterModule],
    declarations: [AutoLoginComponent],
    providers: [AutoLoginService]
})
export class AutoLoginModule { }
