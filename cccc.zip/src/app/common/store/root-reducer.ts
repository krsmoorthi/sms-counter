import { userReducer } from '../reducers/user.reducer';
import { cartReducer } from '../reducers/cart.reducer';
import { customizeServicesReducer } from '../reducers/customize-services.reducer';
import { orderReducer } from '../reducers/order.reducer';
import { appointmentReducer } from '../reducers/appointment.reducer';
import { accountReducer } from '../reducers/account.reducer';
import { securityErrorReducer } from '../reducers/securityError.reducer';
import { systemErrorReducer } from '../reducers/systemError.reducer';
import { creditCheckReducer } from '../reducers/credit-check.reducer';
import { disconnectOrderReducer } from '../reducers/disconnect-order.reducer';
import { existingProductsReducer } from '../reducers/existing-products.reducer';
import { pendingReducer } from '../reducers/pending.reducer';
import { retainReducer } from '../reducers/retain.reducer';
import { moveReducer } from '../reducers/move.reducer';
import { componentErrorReducer } from '../reducers/component-error.reducer';
import { vacationReducer } from '../reducers/vacation.reducer';

export const rootReducer = {
    user: userReducer,
    cart: cartReducer,
    customize: customizeServicesReducer,
    order: orderReducer,
    appointment: appointmentReducer,
    account: accountReducer,
    securityErrorReducer: securityErrorReducer,
    systemErrorReducer: systemErrorReducer,
    creditReview: creditCheckReducer,
    disconnect: disconnectOrderReducer,
    existingProducts: existingProductsReducer,
    pending: pendingReducer,
    retain: retainReducer,
    move: moveReducer,
    componentError: componentErrorReducer,
    vacation: vacationReducer
}