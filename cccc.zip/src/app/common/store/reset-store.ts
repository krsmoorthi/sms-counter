export function resetStore(reducer) {
    return function(state, action) {
        if(action.type === 'RESET_STORE') {
            state = undefined;
        }
        return reducer(state, action);
    }
}