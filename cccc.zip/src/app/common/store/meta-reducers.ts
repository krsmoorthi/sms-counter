import { resetStore } from "./reset-store";
import { localStorageSyncReducer } from './local-storage-sync-reducer';

export const metaReducers = [ localStorageSyncReducer, resetStore ];
