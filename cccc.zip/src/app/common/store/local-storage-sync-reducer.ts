import { localStorageSync } from 'ngrx-store-localstorage';

export function localStorageSyncReducer(reducer) {
    return localStorageSync(['user'], true)(reducer);
}