import { Component } from '@angular/core';
import { AppStore } from '../models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { User } from '../models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../service/app-state.service';
import { SecurityError } from '../models/common.model';

@Component({
    selector: 'security-error',
    styleUrls: ['./security-error.component.css'],
    templateUrl: './security-error.component.html',
})

export class SecurityErrorComponent {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public securityError: SecurityError;
    public fingerPrint: string;

    constructor(
        public store: Store<AppStore>,
        private appStateService: AppStateService
    ) {
        this.appStateService.setLocationURLs();

        let securityErrorStore = <Observable<any>>this.store.select('securityErrorReducer');
        let securityErrorSubscription: Subscription = securityErrorStore.subscribe(
            (data) => {
                if (data && data.securityError) {
                    this.securityError = data.securityError
                }
            }
        )
        if(securityErrorSubscription) securityErrorSubscription.unsubscribe();
    }

    public ngOnInit() {
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
    }

}
