import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavBarComponent } from './navbar/navbar.component';
import { CartSummaryComponent } from './cart/cart.component';
import { throwIfAlreadyLoaded } from './module-import-guard';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService } from './service/auth.service';
import { AppStateService } from './service/app-state.service';
import { UnsavedGuard } from './service/unsaved.guard';
import { AddressService } from './service/address.service';
import { ProductService } from './service/product.service';
import { BlueMarbleService } from './service/bm.service';
import { SchedulingService } from './service/scheduling.service';
import { DisconnectService } from './service/disconnect.service';
import { VacationService } from './service/vacation.service';
import { SystemErrorService } from './service/system-error.service';
import { AccountService } from './service/account.service';
import { CountryStateService } from './service/country-state.service';
import { PendingOrderService } from './service/pending-order.service';
import { CityService } from './service/city.service';
import { creditService } from './service/credit-check.service';
import { ReviewOrderService } from './service/review-order.service';
import { TextMaskService } from './service/text-mask.service';
import { HelperService } from './service/helper.service';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { CTLHelperService } from './service/ctlHelperService';
import { OfferHelperService } from './service/offerHelper.service';
import { DirectvService } from './service/directv.services';
@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        ReactiveFormsModule,
        RouterModule,
        SharedCommonModule
    ],
    exports: [
        NavBarComponent,
        CartSummaryComponent,
    ],
    declarations: [
        NavBarComponent,
        CartSummaryComponent,
    ],
    providers: [
        AppStateService,
        AuthService,
        UnsavedGuard,
        AddressService,
        BlueMarbleService,
        ProductService,
        SchedulingService,
        DisconnectService,
        VacationService,
        SystemErrorService,
        AccountService,
        CountryStateService,
        PendingOrderService,
        CityService,
        creditService,
        ReviewOrderService,
        TextMaskService,
        HelperService,
        CTLHelperService,
        OfferHelperService,       
        DirectvService
    ],
})

export class CoreModule {
    constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
        throwIfAlreadyLoaded(parentModule, 'CoreModule');
    }
}
