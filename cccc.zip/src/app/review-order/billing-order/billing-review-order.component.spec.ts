import { TestBed, ComponentFixture, inject, async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { BillingReviewOrderComponent } from "./billing-review-order.component";
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { SharedCommonModule } from 'app/shared/shared-common.module'; 
import { RouterTestingModule } from '@angular/router/testing';
import { MockReviewOrderService, MockHelperService, MockReviewOrderHelperService, MockLogger, MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockProductService, MockBlueMarbleService } from 'app/common/service/mockServices.test';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { HelperService } from 'app/common/service/helper.service';
import { Store } from '@ngrx/store';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ExistingProductsComponent } from 'app/existing-products/existing-products.component';

describe('Biliing Order Review Order Component', () => {
    let component: BillingReviewOrderComponent;
    let fixture: ComponentFixture<BillingReviewOrderComponent>;
    let mockServer = new MockServer();
    let reviewOrderService: ReviewOrderService;
    let active = 'active';

    RouterTestingModule.withRoutes([
        { path: 'br-order-confirmation', component: BillingReviewOrderComponent },
        { path: 'existing-products', component: ExistingProductsComponent }

    ])

    const imports = [
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        SharedModule,
        SharedCommonModule,
        AccordionModule.forRoot()
    ];
    
    const mockRedux: any = {
        dispatch() { },
        configureStore() { },
        select(reducer) {
            return Observable.of(mockServer.getBillingMockStore("BILLING_HSI_TILL_ORDER_COFIRMATION")[reducer]);
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    }

    const p1 = { provide: AppStateService, useClass: MockAppStateService }
    const p2 = { provide: ReviewOrderService, useClass: MockReviewOrderService }
    const p3 = { provide: HelperService, useClass: MockHelperService };
    const p4 = { provide: Store, useValue: mockRedux };
    const p5 = ReviewOrderHelperService;
    const p6 = { provide: Logger, useClass: MockLogger };
    const p7 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p8 = CTLHelperService;
    const p9 = { provide: ProductService, useClass: MockProductService };
    const p10 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };

    let dp2 = { provide: PendingOrderService, useClass: MockPendingOrderService };
    let dp3 = { provide: AccountService, useClass: MockAccountService };
    let dp4 = { provide: AddressService, useClass: MockAddressService };
    let dp6 = { provide: CountryStateService, useClass: MockCountryStateService };
    let dp7 = { provide: DirectvService, useClass: MockDirectvService };
    let dp8 = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
    let dp9 = { provide: DisconnectService, useClass: MockDisconnectService };
    let providers_ = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, dp2, dp3, dp4, dp6, dp7, dp8, dp9]
    const baseConfig = {
        imports: imports,
        declarations: [BillingReviewOrderComponent],
        providers: providers_
    };

    describe('HSI Biliing Order Review Order Component', () => {

        beforeEach(async(() => {
            TestBed.configureTestingModule(baseConfig)
                .compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(BillingReviewOrderComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it('should create', () => {
            expect(component).toBeTruthy();
        });
        it('should call ngOnDestroy() method ', () => {
            component.ngOnDestroy();
            expect(component.userSubscription.closed).toBe(true);
        });
        it('should call checkNotification() method ', () => {
            component.checkNotification();
            expect(component.checkNotificationlink).toBe(false);
            expect(component.checkNotificationCheckbox).toBe(true);
        });

        it('should call checkOrder() method ', () => {
            component.reviewOrderVariables.rccDone = false
            component.checkOrder();
            expect(component.reviewOrderVariables.checkOrderConfirmation).toBe(true);
        });
        it('should call submit order() method ', () => {
            component.reviewOrderVariables.rccDone = true
            //let temp = (component as any).reviewOrderService.putSubmitTaskService(active);
            component.checkOrder();
            expect(component.confirmOrder).toBeDefined();
        });
        it('should call maskPhone() method and able mask telephone', () => {
            let temp = component.maskPhone('9876543210')
            expect(temp).toBe('987-654-3210');
        });
        it('should call tConv24() method and check payment', () => {
            let temp = component.tConv24('23:15');
            expect(temp).toBe('11:15 PM');
        });
        it('should call ngOnDestroy() method ', () => {
            component.ngOnDestroy();
            expect(component.userSubscription.closed).toBe(true);
        });
        it('should call checkNotification() method ', () => {
            component.checkNotification();
            expect(component.checkNotificationlink).toBe(false);
            expect(component.checkNotificationCheckbox).toBe(true);
        });

        it('should call checkOrder() method ', () => {
            component.checkOrder();
            expect(component.reviewOrderVariables.checkOrderConfirmation).toBe(true);
        });
        it('should call submit order() method  with addl coverage', () => {
            component.reviewOrderVariables.rccDone = true
            component.isUnholdFlow = true;
            //let temp = (component as any).reviewOrderService.putSubmitTaskService(active);
            component.checkOrder();
            expect(component.reviewOrderVariables.checkOrderConfirmation).toBeUndefined()
        });
        it('should call maskPhone() method and able mask telephone', () => {
            let temp = component.maskPhone('9876543210')
            expect(temp).toBe('987-654-3210');
        });
        it('should call tConv24() method and check payment', () => {
            let temp = component.tConv24('23:15');
            expect(temp).toBe('11:15 PM');
        });
        it('should call changeSalesIdDialog() method and check payment', () => {
            let temp = component.changeSalesIdDialog();
            expect(temp).toBe(undefined);
        });
        it('should call handleBackToExistingProducts() method and check payment', () => {
            let temp = component.handleBackToExistingProducts({});
            expect(temp).toBe(undefined);
        });
        it('should call handleCancelClick() method and check payment', () => {
            let temp = component.handleCancelClick({});
            expect(temp).toBe(undefined);
        });

        it('should call getTabSummaryTotal() method and check payment', () => {
            let temp = component.getTabSummaryTotal([{
                summary: {
                    totalBillAmount: 24,
                    totalDiscount: 10,
                    totalTaxes: 4
                }
            }]);
            expect(temp).toBe(18);
        });
        it('should call isAcknowledged() method and check payment', () => {
            component.isAcknowledged({
                "isrccAcknowledged": "Yes"
            });
            expect(component.reviewOrderVariables.rccDone).toBe(false);
        });
        it('should call isAcknowledged() method and check payment', () => {
            component.isAcknowledged({});
            expect(component.reviewOrderVariables.rccDone).toBe(true);
        });

        it('should get OTC total', () => {
            const returnVal = component.getOTCTotal(null);
            expect(returnVal).toBe(0);
        });
        it('should SetActiveTab', () => {
            let data = {
                "monthId": "1",
                "charges": [
                    {
                        "chargeType": "RC",
                        "prorated": true,
                        "summary": {
                            "totalBillAmount": 204.96,
                            "totalDiscount": 0,
                            "totalTaxes": 16.6
                        },
                        "details":[]
                    }]
            }
            const returnVal = component.setActive(null,data);
            expect(component.summaryTotal).toBeDefined();
        });  
      
   
    })

    describe('POTS Biliing Order Review Order Component', ()  =>{
        const mockRedux: any = {
            dispatch() { },
            configureStore() { },
            select(reducer) {
                return Observable.of(mockServer.getBillingMockStore("BILLING_POTS_TILL_REVIEW_ORDER")[reducer]);
            },
            take<T>(this: Observable<T>, count: number) {
                return Observable.of(null);
            }
        }
        const p4 = { provide: Store, useValue: mockRedux };
        providers_ =[...providers_,p4]
        const baseConfig = {
            imports: imports,
            declarations: [BillingReviewOrderComponent],
            providers: providers_
        };
        beforeEach(async(() => {
            TestBed.configureTestingModule(baseConfig)
                .compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(BillingReviewOrderComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });
        it('should create move account component for POTS standalone flow', () => {
            expect(component).toBeTruthy();
        });

    })
});


