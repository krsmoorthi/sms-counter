import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DialogComponent } from '../../common/popup/dialog.component';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { EnterpriseAddress } from './../../common/models/cart.model';
import { Payment, BillEstimate, Month, OrderRq, OrderNotes, ReviewProductInformation, AdditionalInfo, OrderRemarks } from './../../common/models/order.model';
import { AccountInfo } from '../../common/models/account.model';
import { AppStore } from '../../common/models/appstore.model';
import { Store } from '@ngrx/store';
import { AppStateService } from './../../common/service/app-state.service';
import { SystemErrorService } from '../../common/service/system-error.service';
import { User } from '../../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../../common/logging/default-log.service';
import { GenericValues, APIErrorLists } from '../../common/models/common.model';
import { AppointmentShipping } from '../../common/models/schedule-shipping.model';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import "rxjs/add/operator/catch";
import {ReviewOrderVariables} from './../../common/models/review.order.model';


@Component({
    selector: 'billing-review-order',
    styleUrls: ['../review-order-component/review-order.component.scss'],
    templateUrl: './billing-review-order.component.html'
})

export class BillingReviewOrderComponent implements OnInit, OnDestroy {
    public legacyProvider: any;
    public accountnumber: any;
    public ban: any;
    public paymentDone: boolean = false;
    public orderDetails: any;                        // store
    public user: Observable<User>;
    public accountInfo: AccountInfo;                 // AccountInfo Object
    public payment: Payment;                         // Payment Object
    public billEstimate: BillEstimate;               // BillEstimate Object
    public shippingAddress: EnterpriseAddress;       // ShippingAddress Object
    public billingAddress: EnterpriseAddress;        // billingAddress object
    public apiResponseError: APIErrorLists;
    public billingOptions: string[] = [];
    public marketingPreferences: string[] = [];
    public emailNotifications: any;
    public smsNotifications: any;
    public emailNotExist: boolean = false;
    public premisesInfo: string[] = [];
    public returnPrice: number;
    public disableNotification: boolean = false;
    public additioanalNotes: any = {
        text: ''
    };
    public billMonths: any[] = [];
    public billCharges: any[] = [];
    public currentMonthNo: string;
    public RCBillSummary: any;
    public OTCBillSummary: any;
    public isRCProrated: boolean;
    public isOTCProrated: boolean;
    public confirmOrder: any;
    public userSubscription: Subscription;
    public currentPath: string;
    public submitOrderObservable: any;
    public submitOrderSubscription: Subscription;
    public orderSubscription: Subscription;
    public summaryTotal: number;
    public accountDetailsCollapsed: boolean = false;
    public currentTab: string = 'tab0';
    public contactNumber = '';
    public dtvOrderingInfo: any;
    public dtvOptIn: boolean = false;
    public productInformation: ReviewProductInformation = {
        terms: '',
        offerName: '',
        isAutopay: false,
        internetExpiry: '',
        prismExpiry: '',
        autopayRate: -1,
        etf: 0
    };
    public isPrepaid: boolean;
    public prepaidData: any;
    public totalcharges: any;
    public reviewOrderVariables: ReviewOrderVariables;
    public orderRefNumber: string;
    public processInstanceId: string;
    public taskId: string;
    public taskName: string;
    public checkNotificationlink: boolean = true;
    public checkNotificationCheckbox: boolean = false;
    public billTask = {
        taskName: 'billEstimate'
    };
    public errorMsg: string;
    public loading: boolean = false;
    public cartObservable: any;
    public cartSubscription: Subscription;
    public cartDetails: any;
    public servicesChanged = {
        internet: {
            isAdded: false,
            isChanged: false,
            productRemoved: false,
            changed: [],
            added: [],
            removed: []
        },
        dhp: {
            isAdded: false,
            isChanged: false,
            productRemoved: false,
            changed: [],
            added: [],
            removed: []
        },
        pots: {
            isAdded: false,
            isChanged: false,
            productRemoved: false,
            changed: [],
            added: [],
            removed: []
        },
        dtv: {
            isAdded: false,
            productRemoved: false,
        }
    };
    public savedQuoteId: any;
    public isDHPAvailable: boolean = false;
    public isdepositCollected: boolean = true;
    public schedulingURL: string = '';
    private appointment: Observable<AppointmentShipping>;
    private appointmentSubscription: Subscription;
    public existingObservable: Observable<any>;
    public isPendingFlow = false;
    public emailAdd: string;
    public isDtvOpus: boolean;
    public isDTV: boolean;
    public isRCCacknowledged: any;
    public rccDone = false;
    public dealerId: string;
    public dealerName: string;
    public isMultipleDealerCode: boolean;
    public eshopChannel: any;
    public productDealerCodeInfo: any[] = [];
    public prodDealerCodeResponse: any;
    @ViewChild('changeSalesId', { static: false,}) public changeSalesId: DialogComponent;
    public dealerCodeChanged = false;
    public firstTimeLoad: boolean;
    public isUnholdFlow: boolean;
    public agentLastName: string;
    public agentFirstName: string;

    constructor(
        private logger: Logger,
        private reviewOrderService: ReviewOrderService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private router: Router,
        public helperService: HelperService,
        public ctlHelperService: CTLHelperService,
        public reviewOrderHelperService: ReviewOrderHelperService
    ) {
        this.reviewOrderVariables = this.reviewOrderHelperService.setReviewOrderVablesDefault(this.reviewOrderVariables);
        this.appStateService.setLocationURLs();
        this.appointment = this.store.select('appointment');
        this.appointmentSubscription = this.appointment.subscribe((data) => {
            if (data && data.reservedCbr && data.reservedCbr !== null && data.reservedCbr !== undefined) {
                this.contactNumber = data.reservedCbr
            }
        });
        this.appointmentSubscription.unsubscribe();
        this.existingObservable = <Observable<any>>store.select('existingProducts');
        this.existingObservable.subscribe((data) => {
            if(data && data.orderFlow && data.orderFlow.flow)this.reviewOrderVariables.currentFlow = data.orderFlow.flow;     
            if (data && data.orderFlow && data.orderFlow.type === 'pending') {
                this.isPendingFlow = true;
                this.ban = data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.ban;
            }
            if((data.pendingOrders && data.pendingOrders.length > 0) && 
                (data.pendingOrders[0].orderReference && data.pendingOrders[0].orderReference.reason && data.pendingOrders[0].orderReference.reason.length > 0) &&
                (data.pendingOrders[0].orderReference.reason[0].description !== undefined && data.pendingOrders[0].orderReference.reason[0].description !== null )) {
                this.isUnholdFlow = true;
            }
        })
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.accountnumber = data.ban;
            this.isPrepaid = data.prepaidFlag && data.prepaidFlag === 'PREPAID' ? true : false;
            if (data.currentUrl !== null && data.currentUrl !== undefined) {
                this.currentPath = data.currentUrl;
            }
            if(data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.agentFirstName && data.autoLogin.oamData.agentLastName)
            {
                this.agentFirstName = data.autoLogin.oamData.agentFirstName;
                this.agentLastName = data.autoLogin.oamData.agentLastName;
            }
            this.isDtvOpus = data.isDtvOpus;
            if (Array.isArray(data.currentSelected)) {
                data.currentSelected.forEach((val: any) => {
                    if (val.selected === GenericValues.cDTV) {
                        this.isDTV = true;
                    }
                });

            }
        });

        if (this.currentPath === '/br-order-confirmation') {
            this.submitOrderObservable = <Observable<any>>store.select('order');
            this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
                this.confirmOrder = data;
                this.accountDetailsCollapsed = true;
                if (data.payload && data.payload.billEstimate
                    && data.payload.billEstimate.quote && data.payload.billEstimate.quote.length>0) {
                    this.savedQuoteId = data.payload.billEstimate.quote[0].quoteId;
                    this.reviewOrderHelperService.getOrderDetails(data, this.reviewOrderVariables);
                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
                } else if(data && data.payload && data.payload.orderSummary && data.payload.orderSummary.serviceAddress) {
                    this.reviewOrderVariables.serviceAddress = data.payload.orderSummary.serviceAddress;
                }
                if(this.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                    this.prepaidData = data.payload.currentBillQuote;
                }

            });
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data && data.payload && data.payload.accountInfo && data.payload.accountInfo.contact && data.payload.accountInfo.contact.emailAddress) {
                    this.emailAdd = data.payload.accountInfo.contact.emailAddress;
                }
                if(this.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                    this.prepaidData = data.payload.currentBillQuote;
                    if(data.payload.currentBillQuote && data.payload.currentBillQuote.firstMonthList
                        && data.payload.currentBillQuote.firstMonthList.totalCharges
                        ){
                        this.totalcharges = data.payload.currentBillQuote.firstMonthList.totalCharges;
                    }
                }
            });
        } else {
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data.payload && data.payload.billEstimate
                    && data.payload.billEstimate.quote && data.payload.billEstimate.quote.length>0) {
                    this.savedQuoteId = data.payload.billEstimate.quote[0].quoteId;                     }
                    this.reviewOrderHelperService.getOrderDetails(data, this.reviewOrderVariables);
                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
               
                if(this.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                    this.prepaidData = data.payload.currentBillQuote;
                }
            });
        }
        
        if (this.currentPath === '/billing-order-confirmation' || this.currentPath === '/billing-review-order') {
            this.firstTimeLoad = true;
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                this.dtvOrderingInfo = data.payload.hasOwnProperty('dtvOrderingInfo') ? data.payload.dtvOrderingInfo : {};
                if (this.dtvOrderingInfo && this.dtvOrderingInfo.dtvInstallDueDate) {
                    this.dtvOptIn = true;
                }
                if (data && data.payload && data.payload.accountInfo && data.payload.accountInfo.contact && data.payload.accountInfo.contact.emailAddress) {
                    this.emailAdd = data.payload.accountInfo.contact.emailAddress;
                }
                this.orderRefNumber = data.orderRefNumber;
                if (data.productSalesIdInfo === undefined) {
                    this.getProductDealerCodeInfo(false);
                } else {
                    this.productDealerCodeInfo = data.productSalesIdInfo.productDealerCodeInfo;
                    this.isMultipleDealerCode = data.productSalesIdInfo.isMultipleDealerCode;
                    this.dealerCodeChanged = data.productSalesIdInfo.dealerCodeChanged;
                    if (!this.isMultipleDealerCode && this.productDealerCodeInfo && this.productDealerCodeInfo.length>0) {
                        this.dealerId = this.productDealerCodeInfo[0].dealerCode;
                        this.dealerName = this.productDealerCodeInfo[0].firstName + ' ' + this.productDealerCodeInfo[0].lastName;
                    }
                    if (this.firstTimeLoad) {
                        this.getProductDealerCodeInfo(false);
                    }
                }

            });
        }

        this.cartObservable = <Observable<any>>store.select('customize');
        this.cartSubscription = this.cartObservable.subscribe((data) => {
            if (data && data.payload && data.payload.cart !== null && data.payload.cart !== undefined && data.payload.cart.customerOrderItems !== undefined) {
                this.cartDetails = data.payload.cart.customerOrderItems;
                data.payload.cart.customerOrderItems.length >0 &&
                data.payload.cart.customerOrderItems.map(item => {
                    if (item.offerCategory === GenericValues.sData ||
                        item.offerCategory === GenericValues.iData) {
                        if (item.action && (item.action === 'CHANGE')) {
                            this.servicesChanged.internet.isChanged = true;
                            if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
                                item.customerOrderSubItems.map(subitem => {
                                    if (subitem.action) {
                                        if (subitem.action === 'CHANGE') {
                                            this.servicesChanged.internet.changed.push(subitem.productName);
                                        }
                                        if (subitem.action === 'ADD') {
                                            this.servicesChanged.internet.added.push(subitem.productName);
                                        }
                                        if (subitem.action === 'REMOVE') {
                                            this.servicesChanged.internet.removed.push(subitem.productName);
                                        }
                                    }
                                });
                            }
                        }

                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.internet.isAdded = true;
                        }
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.internet.productRemoved = true;
                        }
                    }
                    if (item.offerCategory === GenericValues.cDHP) {
                        if (item.action && (item.action === 'CHANGE')) {
                            this.servicesChanged.dhp.isChanged = true;
                            if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
                                item.customerOrderSubItems.map(subitem => {
                                    if (subitem.action) {
                                        if (subitem.action === 'CHANGE') {
                                            this.servicesChanged.dhp.changed.push(subitem.productName);
                                        }
                                        if (subitem.action === 'ADD') {
                                            this.servicesChanged.dhp.added.push(subitem.productName);
                                        }
                                        if (subitem.action === 'REMOVE') {
                                            this.servicesChanged.dhp.removed.push(subitem.productName);
                                        }
                                    }
                                });
                            }
                        }
                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.dhp.isAdded = true;
                        }
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.dhp.productRemoved = true;
                        }

                    }
                    if (item.offerCategory === GenericValues.cHP) {
                        if (item.action && item.action === 'CHANGE') {
                            this.servicesChanged.pots.isChanged = true;
                            if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
                                item.customerOrderSubItems.map(subitem => {
                                    if (subitem.action) {
                                        if (subitem.action === 'CHANGE') {
                                            this.servicesChanged.pots.changed.push(subitem.productName);
                                        }
                                        if (subitem.action === 'ADD') {
                                            this.servicesChanged.pots.added.push(subitem.productName);
                                        }
                                        if (subitem.action === 'REMOVE') {
                                            this.servicesChanged.pots.removed.push(subitem.productName);
                                        }
                                    }
                                });
                            }
                        }
                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.pots.isAdded = true;
                        }
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.pots.productRemoved = true;
                        }

                    }
                    if (item.offerCategory === GenericValues.cDTV) {
                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.dtv.isAdded = true;
                        }
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.dtv.productRemoved = true;
                        }
                    }
                })
            }
        });
    }
    
    public ngOnInit() {
        let pageName;
        if (this.currentPath === '/br-order-confirmation') {
            pageName = 'OrderConfirmationBillingReviewOrderPage';
        }
        else {
            pageName = 'ReviewOrderBillingReviewOrderPage';
        }
        this.logger.metrics(pageName);
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.submitOrderSubscription !== undefined) {
            this.submitOrderSubscription.unsubscribe();
        }
    }

    /**
     * To set the clicked pricing Tab active & update respective tab summary amount
     * @param tab as string
     * @param month which describe prices for particular month
     */
    public setActive(tab: string, month: Month) {
        this.currentTab = tab;
        this.billCharges = month.charges;
        this.currentMonthNo = month.monthId;
        this.RCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };
        this.OTCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };

        for (let k in this.billCharges) {
            if (this.billCharges[k].chargeType === 'RC') {
                this.RCBillSummary = this.billCharges[k].summary;
                break;
            }
        }
        for (let k in this.billCharges) {
            if (this.billCharges[k].chargeType === 'OTC') {
                this.OTCBillSummary = this.billCharges[k].summary;
                break;
            }
        }

        this.summaryTotal =
            (this.RCBillSummary.totalBillAmount +
                this.OTCBillSummary.totalBillAmount +
                this.RCBillSummary.totalTaxes +
                this.OTCBillSummary.totalTaxes) -
            (this.RCBillSummary.totalDiscount +
                this.OTCBillSummary.totalDiscount);
    }

    /**
     * To check/set the diable notification checkbox boolean
     */
    public checkNotification() {
        this.checkNotificationlink = false;
        this.checkNotificationCheckbox = true;
    }

    /**
     * To validate pricing details checked & deposits if required taken
     */
    public checkOrder() {      
        if (this.reviewOrderVariables.rccDone) {
            this.submitOrder(this.isRCCacknowledged,
                this.additioanalNotes.text, this.disableNotification, this.reviewOrderVariables.orderObject);
        } else {
            this.reviewOrderVariables.checkOrderConfirmation = true;
        }
    }


    public isAcknowledged(event) {
        this.reviewOrderVariables.isRCCacknowledged = event.isrccAcknowledged;
        if (this.reviewOrderVariables.isRCCacknowledged === "Yes") {
            this.reviewOrderVariables.rccDone = false;
        } else {
            this.reviewOrderVariables.rccDone = true;
        }
    }

    /**
     * To scroll upto the Pricing block if not acknowledged
     * @param element as clicked pricing check dom element
     */
    public checkPricingAck(element) {
       window.scrollTo(0, document.getElementById(element).offsetTop - 140);
    }

    /**
     * To summary of bill for a month
     * @param charges for a month
     */
    public getTabSummaryTotal(charges) {
        let totalBill = 0;
        let totalDiscounts = 0;
        let totalTaxes = 0;
        charges &&
        charges.length >0 &&
        charges.map((charge) => {
            if (Object.keys(charge.summary).length > 0) {
                totalBill += charge.summary['totalBillAmount'];
                totalDiscounts += charge.summary['totalDiscount'];
                totalTaxes += charge.summary['totalTaxes'];
            }
        });
        return totalBill + totalTaxes - totalDiscounts;
    }

    /**
     * To get higher level product totalfrom individual amounts from API
     * @param product
     */
    public getProductTotal(product): number {
        let primaryProductAmount: number = 0;
        let additionalSevicesAmount: number = 0;
        let totalDiscounts: number = 0;
        let totalTaxes: number = 0;

        let primaryService = product.primaryService;
        primaryService && primaryService.length>0   &&
        primaryService.map((k) => {
            if (k.billAmount && k.billAmount > 0) {
                primaryProductAmount += k.billAmount;
            }
            if (k.discountAmount) {
                totalDiscounts += k.discountAmount;
            }
            if (k.taxes && Object.keys(k.taxes).length > 0) {
                totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
            }
        });

        let additionalService = product.additionalServices;
        additionalService && additionalService.length>0 &&
        additionalService.map((k) => {
            if (k.billAmount && k.billAmount > 0) {
                additionalSevicesAmount += k.billAmount;
            }
        });

        return primaryProductAmount + additionalSevicesAmount + totalTaxes - totalDiscounts;
    }

    /**
     * To get higher level product OTC totalfrom individual amounts from API
     * @param product
     */
    public getOTCTotal(product) {
        let primaryProductAmount: number = 0;
        let additionalSevicesAmount: number = 0;
        let totalDiscounts: number = 0;
        let totalTaxes: number = 0;
        product && product.length >0 &&
        product.map((p) => {
            let primaryService = p.primaryService;
            primaryService && primaryService.length >0 &&
            primaryService.map((k) => {
                if (k.billAmount && k.billAmount > 0) {
                    primaryProductAmount += k.billAmount;
                }
                if (k.discountAmount) {
                    totalDiscounts += k.discountAmount;
                }
                if (k.taxes && Object.keys(k.taxes).length > 0) {
                    totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
                }
            });
            let additionalService = p.additionalServices;
            additionalService && additionalService.length >0 &&
            additionalService.map((k) => {
                if (k.billAmount && k.billAmount > 0) {
                    additionalSevicesAmount += k.billAmount;
                }
                if (k.discountAmount) {
                    totalDiscounts += k.discountAmount;
                }
                if (k.taxes && Object.keys(k.taxes).length > 0) {
                    totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
                }
            });
        });

        return primaryProductAmount + additionalSevicesAmount + totalTaxes - totalDiscounts;
    }

    /**
     * To mask phone number as pe USA format (xxx-xx-xxxx)
     * @param data as response
     */
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }

    /**
     * submit request from order summary page
     * @param pricingConfirmation as pricing ack
     * @param additionalNotes entered notes
     * @param disableNotifications checkbox checked or not
     * @param order fetching refnumber, taskId
     */
    public submitOrder(pricingConfirmation: string, additionalNotes: string,
        disableNotifications: boolean, order) {
        this.loading = true;
        let chargeSummaryAck: boolean;
        chargeSummaryAck = pricingConfirmation && pricingConfirmation === 'Yes' ? true : false;

        let additionalInfo: AdditionalInfo = {
            chargeSummaryAck,
            disableOrderNotification: disableNotifications
        }
        let remark: OrderRemarks = {
            name: 'Order Remarks',
            value: additionalNotes,
            date: new DatePipe('en-US').transform(new Date(), 'mediumDate'),
            author: this.agentFirstName + ' ' + this.agentLastName
        }
        let dealerCodeChangeInfo = [];
        this.productDealerCodeInfo &&
        this.productDealerCodeInfo.length >0 &&
        this.productDealerCodeInfo.forEach(prod => {
            if (prod.changed) {
                let prodInfo = {
                    offerCategory: prod.offerCategory,
                    productType: prod.productType,
                    productname: prod.productname,
                    dealerCode: prod.dealerCode,
                    firstName: prod.firstName,
                    lastName: prod.lastName
                }
                dealerCodeChangeInfo.push(prodInfo);
            }
        });
        let payload: OrderNotes = {
            additionalInfo: additionalInfo,
            orderRemarks: [remark],
            dealerCodeChangeInfo: dealerCodeChangeInfo
        }

        let request: OrderRq = {
            orderRefNumber: order.orderRefNumber,
            processInstanceId: order.processInstanceId,
            taskId: order.taskId,
            taskName: order.taskName,
            payload
        };
        if(request.payload && request.payload.orderRemarks.length>0 && request.payload.orderRemarks[0].value === '')
        {
               delete request.payload.orderRemarks;
            
        }
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.existingObservable.subscribe((data) => {
            if(data && data.orderFlow && data.orderFlow.flow)this.reviewOrderVariables.currentFlow = data.orderFlow.flow;
            if(data && data.existingProductsAndServices &&data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress.locationAttributes){
                this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;               
            }         
        })
        this.store.dispatch({ type: 'CONFIRM_ORDER', payload: payload });
        this.logger.log("info", "billing-review-order.component.ts", "postSubmitOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        let errorResolved = false;
        this.reviewOrderService.putSubmitTaskService(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "billing-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                this.logger.log("error", "billing-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "submitTask - postSubmitOrder", "billing-review-order.component.ts",
                    "Billing Review Order Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();                    
                    if (this.isUnholdFlow) {
                        this.logger.log("info", "billing-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data),this.legacyProvider);
                        this.logger.log("info", "billing-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "billing-unhold.component.ts", "orderCompletedUnholdBilling", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');   
                    } else {
                        this.logger.log("info", "billing-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data),this.legacyProvider);
                        this.logger.log("info", "billing-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "billing-review-order.component.ts", "orderCompletedBilling", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    }                    
                    if (data.payload && data.payload.paymentDetails && data.payload.paymentDetails.finalBillPaymentStatus && data.payload.paymentDetails.finalBillPaymentStatus.depositPaymentStatus === "UNPAID") {
                        this.paymentDone = true;
                    }
                    this.loading = true;
                    this.confirmOrder = data;
                    let submitData = Object.assign({}, order, this.confirmOrder.payload);
                    this.store.dispatch({ type: 'SUBMITTED_ORDER', payload: submitData });
                    this.router.navigate(['/br-order-confirmation']);
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "billing-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                        this.logger.log("error", "billing-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task -  Review Order", "billing-review-order.component.ts", "Review Order Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Review Order Page", "billing-review-order.component.ts", "Review Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public handleBackToExistingProducts(event) {
        this.isPendingFlow ? this.router.navigate(['/pending-order']) : this.router.navigate(['/existing-products']);
    }

    public handleCancelClick(event) {
        this.isPendingFlow ? this.router.navigate(['/pending-order']) : this.router.navigate(['/existing-products']);
    }


    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }

    public changeSalesIdDialog() {
        if (this.productDealerCodeInfo === undefined || this.productDealerCodeInfo.length === 0) {
            this.getProductDealerCodeInfo(true);
        } else {
            this.productDealerCodeInfo &&
            this.productDealerCodeInfo.length >0 &&
            this.productDealerCodeInfo.map(prod => prod.changeId = prod.chnageAllowed);
            this.changeSalesId.open();
        }
    }

    private getProductDealerCodeInfo(openDialog: boolean) {
        let request = {
            orderReferenceNumber: this.orderRefNumber,
            salesChannel: 'ESHOp-Customer Care'
        }
        this.loading = true;
        this.logger.log("info", "billing-review-order.component.ts", "productDealerCodeInfoRequest", JSON.stringify(request));
        this.logger.startTime();
        let errorResolved = false;
        this.reviewOrderService.retrieveProductDealerCodeInfo(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "billing-review-order.component.ts", "productDealerCodeInfoResponse", error);
                this.logger.log("error", "billing-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "retrieveProductDealerCodeInfo", "billing-review-order.component.ts",
                    "Billing Review Order Page",
                error);
                return Observable.throwError(null);

            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
		            this.logger.log("info", "billing-review-order.component.ts", "productDealerCodeInfoResponse", JSON.stringify(data));
                    this.logger.log("info", "billing-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;                    
                    this.prodDealerCodeResponse = data;
                    const prodNameMap = {
                        'INTERNET': {
                            'name': 'Internet',
                            'imgUrl': './assets/img/internet_sm.png',
                            'dealerInfo': ''
                        },
                        'VOICE-HP': {
                            'name': 'Home Phone',
                            'imgUrl': './assets/img/phone_sm.png',
                            'dealerInfo': ''
                        },
                        'VIDEO-DTV': {
                            'name': 'DIRECTV',
                            'imgUrl': './assets/img/tv_sm.png',
                            'dealerInfo': ''
                        },
                        'CENTURYLINK @ EASE': {
                            'dealerInfo': ''
                        }
                    };
                    let previousProdDealerCodeInfo = this.productDealerCodeInfo;
                    /* Retaining previously saved dealer code for reentrant scenario */
                    if (previousProdDealerCodeInfo.length > 0) {
                        previousProdDealerCodeInfo.forEach(prodInfo => {
                            if (prodInfo.changed) {
                                if ((prodInfo.productname).indexOf('EASE') !== -1) {
                                    prodNameMap[prodInfo.productname].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                } else {
                                    prodNameMap[prodInfo.productType].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                }
                            }
                        });
                    }
                    this.productDealerCodeInfo = [];
                    let dealerCodeArray = [];
                    let displayInternet = false;
                    let displayVoice = false;
                    this.prodDealerCodeResponse &&
                    this.prodDealerCodeResponse.productDealerCodeInfo &&
                    this.prodDealerCodeResponse.productDealerCodeInfo.length > 0 &&
                    this.prodDealerCodeResponse.productDealerCodeInfo.map(prodInfo => {
                        if (prodInfo.isDisplay.toUpperCase() === 'YES') {
                            let isEase = ((prodInfo.productname).indexOf('EASE') !== -1);
                            let prodInfoObject = {
                                prodName: isEase ? prodInfo.productname : prodNameMap[prodInfo.productType],
                                firstName: prodInfo.firstName,
                                lastName: prodInfo.lastName,
                                dealerCode: prodInfo.dealerCode,
                                chnageAllowed: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                changeId: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                offerCategory: prodInfo.offerCategory,
                                productType: prodInfo.productType,
                                productname: prodInfo.productname,
                            }
                            if (isEase || prodInfo.productType === 'VIDEO-DTV') {
                                prodInfoObject['display'] = true;
                            }
                            if (!displayInternet && !isEase && prodInfo.productType === 'INTERNET') {
                                prodInfoObject['display'] = true;
                                displayInternet = true;
                            }
                            if (!displayVoice && prodInfo.productType === 'VOICE-HP') {
                                prodInfoObject['display'] = true;
                                displayVoice = true;
                            }
                            if (previousProdDealerCodeInfo.length > 0) {
                                let priviouslySavedValue = isEase ? prodNameMap[prodInfo.productname].dealerInfo : prodNameMap[prodInfo.productType].dealerInfo;
                                if (priviouslySavedValue !== '') {
                                    prodInfoObject.dealerCode = priviouslySavedValue.dealerCode;
                                    prodInfoObject.firstName = priviouslySavedValue.firstName;
                                    prodInfoObject.lastName = priviouslySavedValue.lastName;
                                    prodInfoObject['changed'] = true;
                                }
                            }
                            dealerCodeArray.push(prodInfoObject.dealerCode);
                            this.productDealerCodeInfo.push(prodInfoObject);
                        }
                    });
                    if (this.firstTimeLoad) {
                        this.isMultipleDealerCode = dealerCodeArray && !dealerCodeArray.every(val => (val === dealerCodeArray[0]));
                    }
                    this.firstTimeLoad = false;
                    if( this.productDealerCodeInfo && this.productDealerCodeInfo.length === 0) {
                        this.isMultipleDealerCode = this.prodDealerCodeResponse &&
                                                    this.prodDealerCodeResponse.productDealerCodeInfo &&
                                                    !this.prodDealerCodeResponse.productDealerCodeInfo.every(val => (val.dealerCode === this.prodDealerCodeResponse.productDealerCodeInfo[0].dealerCode));
                         this.dealerId =   this.prodDealerCodeResponse && this.prodDealerCodeResponse.productDealerCodeInfo && this.prodDealerCodeResponse.productDealerCodeInfo.length>0 && this.prodDealerCodeResponse.productDealerCodeInfo[0].dealerCode;
                         this.dealerName = this.prodDealerCodeResponse && this.prodDealerCodeResponse.productDealerCodeInfo && this.prodDealerCodeResponse.productDealerCodeInfo.length>0?this.prodDealerCodeResponse.productDealerCodeInfo[0].firstName + ' ' + this.prodDealerCodeResponse.productDealerCodeInfo[0].lastName:'';
                    }
                    let payLoad = {
                        productDealerCodeInfo: this.productDealerCodeInfo,
                        isMultipleDealerCode: this.isMultipleDealerCode,
                        dealerCodeChanged: this.dealerCodeChanged
                    }
                    this.store.dispatch({ type: 'PROD_DEALER_ID', payload: payLoad });
                    if (openDialog)
                        this.changeSalesId.open();
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
		                this.logger.log("info", "billing-review-order.component.ts", "productDealerCodeInfoResponse", error);
                        this.logger.log("info", "billing-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (error === undefined || error === null)
                        return;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "billing-review-order.component.ts", "Order Summary Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "billing-review-order.component.ts", "Order Summary Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

}


