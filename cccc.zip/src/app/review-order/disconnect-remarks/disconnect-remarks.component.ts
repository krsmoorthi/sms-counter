import { Component, OnInit, OnDestroy,Input } from '@angular/core';
import { Logger } from '../../common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { Subscription } from 'rxjs';
import { ExistingProducts } from 'app/common/models/existing-products.model';
import { Observable } from 'rxjs/Observable';
import { AppointmentShipping } from '../../common/models/schedule-shipping.model';
@Component({
    selector: 'ctl-disconnect-remarks',
    styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
    templateUrl: './disconnect-remarks.component.html'
})

export class DisconnectRemarksComponent implements OnInit, OnDestroy {
    @Input() public remarksData;
    @Input() public reviewFormData;
    @Input() public actionType= 'disconnect-review';
    @Input() public prepaidChk:any;
    public existingProductsSubscription: Subscription;
    private existingProductsResponse: ExistingProducts;
    public appointmentSubscription: Subscription;
    private existingProducts: Observable<ExistingProducts>;
    public serviceAddress;
    public contactNumber ='';
    private appointment: Observable<AppointmentShipping>;
        
    constructor(private logger: Logger, private store: Store<AppStore>) {

     }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderDisconnectRemarksPage');
        this.appointment = this.store.select('appointment');
        this.appointmentSubscription = this.appointment.subscribe((data) => {
            if(data && data.reservedCbr && data.reservedCbr !== null && data.reservedCbr !== undefined)
            {
            this.contactNumber= data.reservedCbr
            }
        });
        this.appointmentSubscription.unsubscribe();
        
        this.existingProducts = <Observable<ExistingProducts>>this.store.select('existingProducts');
        
                this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
                    if (data !== null && data !== undefined) {
                        this.existingProductsResponse = data;
                        if(this.existingProductsResponse) {
                            if(this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length>0){
                                this.serviceAddress = this.existingProductsResponse.existingProductsAndServices[0].serviceAddress;
                            }
                        }
        
                    }
                });
    }

    public ngOnDestroy() {

    }

}
