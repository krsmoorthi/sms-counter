import { TestBed, ComponentFixture, inject, async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { MoReviewOrderComponent } from './mo-review-order.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { RouterTestingModule } from '@angular/router/testing';
import { MockReviewOrderService, MockHelperService, MockReviewOrderHelperService, MockLogger, MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockProductService, MockBlueMarbleService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { HelperService } from 'app/common/service/helper.service';
import { Store } from '@ngrx/store';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';

describe('Move Order Review Order Component', () => {
  let component: MoReviewOrderComponent;
  let fixture: ComponentFixture<MoReviewOrderComponent>;
  let mockServer = new MockServer();

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    RouterTestingModule.withRoutes(MOCK_ROUTES),
    SharedModule,
    SharedCommonModule,
    AccordionModule.forRoot()
  ];
  
  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]);
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }
  
  const p1 = { provide: AppStateService, useClass: MockAppStateService }
  const p2 = { provide: ReviewOrderService, useClass: MockReviewOrderService }
  const p3 = { provide: HelperService, useClass: MockHelperService };
  const p4 = { provide: Store, useValue: mockRedux };
  const p5 = ReviewOrderHelperService;
  const p6 = { provide: Logger, useClass: MockLogger };
  const p7 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const p8 = CTLHelperService;
  const p9 = { provide: ProductService, useClass: MockProductService };
  const p10 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  
  let dp2 = {provide: PendingOrderService, useClass: MockPendingOrderService};
  let dp3 = {provide: AccountService, useClass: MockAccountService};
  let dp4 = {provide: AddressService, useClass: MockAddressService};
  let dp6 = {provide: CountryStateService, useClass: MockCountryStateService};
  let dp7 = {provide: DirectvService, useClass: MockDirectvService};
  let dp8 = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  let dp9 = {provide: DisconnectService, useClass: MockDisconnectService};

  const baseConfig = {
    imports: imports,
    declarations: [MoReviewOrderComponent],
    providers: [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, dp2, dp3, dp4, dp6, dp7, dp8, dp9]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoReviewOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display leased equipment return label message with email', () => {
    expect(component.emailAdd).toBe('test@test.com');
  });

  it('should call maskTelephone() method and able mask telephone', () => {
    let temp = component.maskTelephone('9876543210')
    expect(temp).toBe('987-654-3210');
  });

  it('should call ngOnInit() method and check payment', () => {
    component.ngOnInit();
    expect(component.reviewOrderVariables.paymentDone).toBe(true);
  });

  it('should call ngOnDestroy() method and check payment', () => {
    component.ngOnDestroy();
    expect(component.userSubscription.closed).toBe(true);
  });

  it('should call checkNotification() method and check payment', () => {
    component.checkNotification();
    expect(component.checkNotificationlink).toBe(false);
    expect(component.checkNotificationCheckbox).toBe(true);
  });

  it('should call checkOrder() method and check payment', () => {
    component.checkOrder();
    expect(component.reviewOrderVariables.checkOrderConfirmation).toBe(true);
  });

  it('should call isAcknowledged() method and check payment', () => {
    component.isAcknowledged({
      "isrccAcknowledged" : "Yes"
    });
    expect(component.reviewOrderVariables.rccDone).toBe(false);
  });

  it('should call getTabSummaryTotal() method and check payment', () => {
    let temp = component.getTabSummaryTotal([{
      summary : {
        totalBillAmount : 24,
        totalDiscount : 10,
        totalTaxes : 4
      }
    }]);
    expect(temp).toBe(18);
  });
  
  it('should call checkOrder() method and check payment', () => {
    let temp = component.handleBackToExistingProducts({});
    expect(temp).toBe(undefined);
  });
  
  it('should call checkOrder() method and check payment', () => {
    let temp = component.handleCancelClick({});
    expect(temp).toBe(undefined);
  });
  
  it('should call checkOrder() method and check payment', () => {
    let temp = component.changeSalesIdDialog();
    expect(temp).toBe(undefined);
  });
  
  it('should call checkOrder() method and check payment', () => {
    let temp = component.tConv24('23:15');
    expect(temp).toBe('11:15 PM');
  });
  
  it('should call checkOrder() method and check payment', () => {
    let temp = (component as any).getProductDealerCodeInfo(true);
    expect(temp).toBe(undefined);
  });
});