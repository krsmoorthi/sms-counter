import { Input } from '@angular/core';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
    selector: 'ctl-info-box',
    styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
    templateUrl: './info-box.component.html'
})

export class InfoBoxComponent implements OnInit, OnDestroy {
    @Input() public boxType: string = 'warning';
    constructor() { }

    public ngOnInit() { }

    public ngOnDestroy() { }

}
