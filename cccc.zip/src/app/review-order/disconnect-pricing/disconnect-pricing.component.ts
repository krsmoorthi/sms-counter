import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Logger } from '../../common/logging/default-log.service';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { AppStore } from '../../common/models/appstore.model';

@Component({
    selector: 'ctl-disconnect-pricing',
    styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
    templateUrl: './disconnect-pricing.component.html'
})

export class DisconnectPricingComponent implements OnInit, OnDestroy {
    @Input() public pricingData;
    @Input() public actionType;
    public depositInfo;
    public depositSubscription: Subscription;
    public deposit: boolean = false;
    constructor(private logger: Logger,
        public store: Store<AppStore>, ) {
        this.depositInfo = <Observable<any>>store.select('existingProducts');
        this.depositSubscription = this.depositInfo.subscribe((data) => {
            if (data && data.depositInfo && data.depositInfo.depositInfo.length > 0) {
                this.deposit = true;
            }
        })
    }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderDisconnectPricingPage');
    }

    public ngOnDestroy() {

    }

}
