import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ReviewOrderComponent } from './review-order-component/review-order.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { ReviewOrderHelperService } from './services/reviewOrderHelper.service';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild([
            {
                path: '',
                component: ReviewOrderComponent
            }
        ]),
        SharedModule,
        SharedCommonModule,
        // ModalModule,
        AccordionModule.forRoot(),
    ],
    exports: [
        ReviewOrderComponent,   
    ],
    declarations: [
        ReviewOrderComponent,
    ],
    providers: [
        ReviewOrderHelperService
    ]  
})
export class ReviewOrderModule { }
