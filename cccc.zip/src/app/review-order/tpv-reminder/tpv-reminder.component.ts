import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { AppStateService } from 'app/common/service/app-state.service';
import { env } from '../../../environments/environment';
import { Logger } from '../../common/logging/default-log.service';

@Component({
    selector: 'tpv-reminder',
    styleUrls: ['../review-order-component/review-order.component.scss'],
    templateUrl: './tpv-reminder.component.html'
})

export class TPVReminderComponent implements OnInit, OnDestroy {
    @Input() public page: string;
    @Input() public recordLocator: string;
    @Input() public tnObject: any;
    public observableCustomize: Observable<any>;
    public custSubscription: Subscription;
    public telephoneType: any;
    public tpvEnglishNumber: string = env.TPV_ENGLISH_NUMBER;
    public tpvSpanishNumber: string = env.TPV_SPANISH_NUMBER;
    isFreezeTPV: boolean = false;
    constructor(private logger: Logger, private appStateService: AppStateService) {
        let currentStore = this.appStateService.getState();
        if(currentStore && currentStore.retain && currentStore.retain.retainedFreezeData && currentStore.retain.retainedFreezeData[0] &&
            currentStore.retain.retainedFreezeData[0].tpvSelection === 'Proceed with TPV as normal') {
                this.isFreezeTPV = true;
            }
        }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderTPVReminderPage');
        if(this.tnObject) {
            this.telephoneType = this.tnObject.tnType;            
        }
    }

    public ngOnDestroy() {}
}