import { Component, OnInit, OnDestroy, Input, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Logger } from '../../common/logging/default-log.service';
import { Subscription } from 'rxjs';
import { ExistingProducts } from 'app/common/models/existing-products.model';
import { Observable } from 'rxjs/Observable';
import { Appointment } from 'app/common/models/appointment.model';
import { AppStore } from 'app/common/models/appstore.model';
import { Store } from '@ngrx/store';
import { User } from 'app/common/models/user.model';
import { GenericValues } from 'app/common/models/common.model';
import { HelperService } from '../../common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';

@Component({
    selector: 'ctl-order-summary',
    styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
    templateUrl: './order-summary.component.html'
})

export class OrderSummaryComponent implements OnInit, OnDestroy {
    public currentPath: any;
    public userSubscription: Subscription;
    public user: Observable<any>;
    @Input() public summaryData;
    @Input() public actionType = 'disconnect-review';
    @Input() public isPrepaidChk:boolean;
    @Input() public finalPayment:any;
    public withCallReferral: boolean = false;
    public potsExists: boolean = false;
    public existingProductsSubscription: Subscription;
    public referralEndDate: any;
    public referralNumber1: any;
    public referralNumber2: any;
    public name1: any;
    public name2: any;
    private appointment: Observable<Appointment>;
    private existingProductsResponse: ExistingProducts;
    private existingProducts: Observable<ExistingProducts>;
    public serviceAddress;
    public retainVal: Observable<any>;
    private productSelected: Subscription;
    @Output() public onStartOrder = new EventEmitter();
    @Output() public onViewOrder = new EventEmitter();
    public referralNumber: any;
    public referralEndDate1: any;
    constructor(
        private router: Router,
        private logger: Logger,
        public store: Store<AppStore>,
        public helperService: HelperService,
        public ctlHelperService: CTLHelperService
    ) {
        this.existingProducts = <Observable<ExistingProducts>>store.select('existingProducts');
        this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
            if (data !== null && data !== undefined) {
                this.existingProductsResponse = data;
                if (this.existingProductsResponse) {
                    if (this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0) {
                        this.serviceAddress = this.existingProductsResponse.existingProductsAndServices[0].serviceAddress;
                    }
                }

            }
        });
        this.retainVal = <Observable<any>>store.select('retain')
        this.retainVal.subscribe((val) => {
            if (val && val.account && val.account.payload && val.account.payload !== undefined && val.account.payload.productConfiguration && val.account.payload.productConfiguration !== undefined && val.account.payload.productConfiguration.length > 0  && val.account.payload.productConfiguration[0].configItems !== undefined && val.account.payload.productConfiguration[0].configItems.length > 0) {

                this.productSelected = val.account.payload.productConfiguration[0].configItems[0].productName;
            }
        });
        this.appointment = store.select('appointment');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointment.subscribe((data) => {
                if (data && data.payload && data.payload.referralRequired && data.payload.referralRequired === 'yes') {
                    if (data && data.payload && data.payload.productConfiguration) {
                        data.payload.productConfiguration.map((configDetails) => {
                            if (configDetails.productType === GenericValues.cHP) {
                                this.potsExists = true;
                                configDetails && configDetails.configItems && configDetails.configItems.map((configItems) => {
                                    configItems && configItems.configDetails && configItems.configDetails.map((conf) => {
                                        if (conf && conf.formName && conf.formName === 'Referral form') {
                                            this.withCallReferral = true;
                                            conf.formItems && conf.formItems.map((formItems) => {
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral End date') {
                                                    this.referralEndDate = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral Number') {
                                                    this.referralNumber = this.maskTelephone(formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value);
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral End date') {
                                                    this.referralEndDate1 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral Number 1') {
                                                    this.referralNumber1 = this.maskTelephone(formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value);
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral Number 2') {
                                                    this.referralNumber2 = this.maskTelephone(formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value);
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Name1') {
                                                    this.name1 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Name2') {
                                                    this.name2 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                            })
                                        }
                                    })
                                })
                            }
                        })
                    }
                }
            })
        }

    }
    public maskTelephone(number: string) {
        if (number && number.indexOf('-') === -1) {
            return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
        }
        else if (number) {
            return number;
        }
    }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderOrderSummaryPage');
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe(
            (data) => {
                this.currentPath = data.currentUrl;
            });
    }

    public viewAccountDetails() {
        this.onViewOrder.emit();
    }

    public ngOnDestroy() {

    }

    public handleCancelClick() {
        this.router.navigate(['/existing-products']);
    }

    public handleBackToExistingProducts() {
        this.router.navigate(['/existing-products']);
    }
}
