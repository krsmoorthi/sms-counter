import { ReviewOrderService } from './../../common/service/review-order.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { CoReviewOrderComponent } from './co-review-order.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: CoReviewOrderComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        // ModalModule,
        AccordionModule.forRoot(),
    ],
    exports: [
        CoReviewOrderComponent,
    ],
    declarations: [
        CoReviewOrderComponent,
    ],
    providers: [
        ReviewOrderService,
        ReviewOrderHelperService
    ]  
})
export class ChangeReviewOrderModule { }
