import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoReviewOrderComponent } from './co-review-order.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { AccordionModule } from 'ngx-bootstrap';
import { Observable, throwError } from 'rxjs';
import { MockServer } from 'app/MockServer.test';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger, MockRouter, MockReviewOrderService, MockAppStateService, MockSystemErrorService, MockCTLHelperService, MockhelperService, MockReviewOrderHelperService, MockPendingOrderService, MockAccountService, MockDisconnectService, MockProductService, MockAddressService, MockBlueMarbleService, MockCountryStateService, MockTextMaskService, MockDirectvService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { Store } from '@ngrx/store';
import "rxjs/add/observable/of";
import { Router } from '@angular/router';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { AuthService } from 'app/common/service/auth.service';


describe('CoReviewOrderComponent', () => {
  let component: CoReviewOrderComponent;
  let fixture: ComponentFixture<CoReviewOrderComponent>;
  const mockServer = new MockServer();

  const mockRedux: any = {
    dispatch(obj) {return obj},
    configureStore() {},
    select(reducer) {
        return Observable.of(
          mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
    return Observable.of(null);
    }
  };
  
  const  logger= { provide: Logger, useClass: MockLogger};
  const  store= { provide: Store, useValue: mockRedux};
  const  router= { provide: Router, useClass: MockRouter};
  const  reviewOrderService= { provide: ReviewOrderService, useClass: MockReviewOrderService};
  const  appStateService= { provide: AppStateService, useClass: MockAppStateService};
  const  systemErrorService= { provide: SystemErrorService, useClass: MockSystemErrorService};
  const  ctlHelperService= CTLHelperService;
  const  helperService= HelperService;
  const  authService= AuthService;
  const  reviewOrderHelperService= ReviewOrderHelperService;
  // dialog providers
  const  pendingOrderService= { provide: PendingOrderService, useClass: MockPendingOrderService};
  const  accountService= { provide: AccountService, useClass: MockAccountService};
  const  disconnectServiceCall= { provide: DisconnectService, useClass: MockDisconnectService};
  const  productService= { provide: ProductService, useClass: MockProductService};
  const  addressService= { provide: AddressService, useClass: MockAddressService};
  const  bMService= { provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const  countryStateService= { provide: CountryStateService, useClass: MockCountryStateService};
  const  textMask= { provide: TextMaskService, useClass: MockTextMaskService};
  const  directvService= { provide: DirectvService, useClass: MockDirectvService};
  const propertiesHelperService = PropertiesHelperService;

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    RouterTestingModule.withRoutes(MOCK_ROUTES),
    SharedModule,
    SharedCommonModule,
    AccordionModule.forRoot(),
  ];

  const providers = [
    logger,store,router,reviewOrderService,appStateService,systemErrorService,ctlHelperService,
    helperService,reviewOrderHelperService,pendingOrderService,accountService,disconnectServiceCall,
    productService,addressService,bMService,countryStateService,textMask,directvService,
    propertiesHelperService, authService
  ];

  describe('When API returns success response', () => {
    const baseConfig = {
      imports: imports,
      declarations: [CoReviewOrderComponent],
      providers: providers
    };
  
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(CoReviewOrderComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  
    it('should allow to submit the order', () => {
      component.submitOrder(null, null, null, {});
      expect(component.loading).toBeTruthy();
    });
  
    it('should acknowledge', () => {
      component.isAcknowledged({isrccAcknowledged: 'Yes'});
      expect(component.reviewOrderVariables.rccDone).toBeFalsy();
      component.isAcknowledged({isrccAcknowledged: 'No'});
      expect(component.reviewOrderVariables.rccDone).toBeTruthy();
    });
  
    it('should get tab summary total', () => {
      const returnVal = component.getTabSummaryTotal(null);
      expect(returnVal).toBeDefined();
    });
  
    it('should get OTC total', () => {
      const returnVal = component.getOTCTotal(null);
      expect(returnVal).toBeDefined();
    });
  
    xit('should mask phone no', () => {
      const returnVal = component.maskPhone('1234567890');
      expect(returnVal).toBe('123-456-7890');
    });
  
    it('should call handleBackToExistingProducts and handleCancelClick', () => {
      component.handleCancelClick(null);
      const returnVal = component.handleBackToExistingProducts(null);
      expect(returnVal).toBeUndefined();
    });
  
    it('should call getProductDealerCodeInfo', () => {
      (component as any).getProductDealerCodeInfo(true);
      expect(component.loading).toBe(false);
    });
  });

  describe('When API return error response', () => {
    class MockReviewOrderService {
      postSubmitTaskService() {
        return throwError({});
      }
      fetchPrimaryProductName() {
        return null;
      }
      returnOptions() {
        return null;
      }
      getBillQuoteDetails() {
        return throwError({});
      }
      checkExist() {
        return null;
      }
      retrieveProductDealerCodeInfo(){
        return throwError({});
      }
    }

    const  reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService};

    const _providers = [...providers, reviewOrderService];

    const baseConfig = {
      imports: imports,
      declarations: [CoReviewOrderComponent],
      providers: _providers
    };
  
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule(baseConfig)
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(CoReviewOrderComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  
    it('should allow to submit the order', () => {
      component.submitOrder(null, null, null, {});
      expect(component.loading).toBe(false);
    });
  
    it('should call getProductDealerCodeInfo', () => {
      (component as any).getProductDealerCodeInfo(true);
      expect(component.loading).toBe(false);
    });
  });
 
});
