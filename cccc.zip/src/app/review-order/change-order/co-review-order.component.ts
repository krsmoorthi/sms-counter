import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DialogComponent } from '../../common/popup/dialog.component';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { cloneDeep } from 'lodash';
import { EnterpriseAddress } from './../../common/models/cart.model';
import { Order, OrderSummary, Payment, BillEstimate, Month, OrderRq, OrderNotes, ReviewProductInformation, AdditionalInfo, OrderRemarks} from './../../common/models/order.model';
import { AppStore } from '../../common/models/appstore.model';
import { Store } from '@ngrx/store';
import { AppStateService } from './../../common/service/app-state.service';
import { SystemErrorService } from '../../common/service/system-error.service';
import { User } from '../../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { CreditCheck } from '../../common/models/credit-check.model';
import { Logger } from '../../common/logging/default-log.service';
import { GenericValues, APIErrorLists } from '../../common/models/common.model';
import { AppointmentShipping } from '../../common/models/schedule-shipping.model';
import { Validations } from '../../common/validations/validations';
import { HelperService } from '../../common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { ReviewOrderVariables } from 'app/common/models/review.order.model';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import "rxjs/add/operator/catch";

@Component({
    selector: 'co-review-order',
    styleUrls: ['../review-order-component/review-order.component.scss'],
    templateUrl: './co-review-order.component.html'
})

export class CoReviewOrderComponent implements OnInit, OnDestroy {
    public legacyProvider: any;
    public submitOrderResponse: any;
    public allday: any;
    public selfInstallSel: boolean;
    public directvEnableed: boolean = false;
    public lifelineDhpAdded: boolean = false;
    public lifelinePotsAdded: boolean = false;
    public lifelineInternetAdded: boolean = false;
    public internetAddedLifeLine: boolean = false;
    public internetLifeline: any;
    public PaymentErrMsg: boolean;
    public creditCheckObj: any;
    public orderDetails: any;
    public user: Observable<User>;                  // Parent Object
    public billEstimate: BillEstimate;               // BillEstimate Object
    public apiResponseError: APIErrorLists;
    public contactNumber = '';
    public returnPrice: number;
    public paymentDone: boolean = false;
    public shippingName: string;
    public additioanalNotes: any = {
        text: ''
    };
    public billMonths: any[] = [];
    public billCharges: any[] = [];
    public currentMonthNo: string;
    public RCBillSummary: any;
    public OTCBillSummary: any;
    public isRCProrated: boolean;
    public isOTCProrated: boolean;
    public confirmOrder: any;
    public userSubscription: Subscription;
    public retainVal: Observable<any>;
    private productSelected: Subscription;
    public currentPath: string;
    public submitOrderObservable: any;
    public submitOrderSubscription: Subscription;
    public orderSubscription: Subscription;
    public summaryTotal: number;
    public accountDetailsCollapsed: boolean = false;
    public currentTab: string = 'tab0';
    public productInformation: ReviewProductInformation = {
        terms: '',
        offerName: '',
        isAutopay: false,
        internetExpiry: '',
        prismExpiry: '',
        autopayRate: -1,
        etf: 0
    };
    public isPrepaid: boolean = false;
    public prepaidData: any;
    public totalcharges: any;

    public isDtvOpus: boolean;
    public orderRefNumber: string;
    public processInstanceId: string;
    public taskId: string;
    public taskName: string;
    public checkNotificationlink: boolean = true;
    public checkNotificationCheckbox: boolean = false;
    public billTask = {
        taskName: 'billEstimate'
    };
    public errorMsg: string;
    public loading: boolean = false;
    public cartObservable: any;
    public cartSubscription: Subscription;
    public apptObservable: any;
    public apptSubscription: Subscription;
    public cartDetails: any;
    public prodConf;
    public existingDTVAccountId;
    public servicesChanged = {
        internet: {
            isAdded: false,
            isChanged: false,
            productRemoved: false,
            changed: [],
            added: [],
            removed: []
        },
        dhp: {
            isAdded: false,
            isChanged: false,
            productRemoved: false,
            changed: [],
            added: [],
            removed: []
        },
        pots: {
            isAdded: false,
            isChanged: false,
            productRemoved: false,
            changed: [],
            added: [],
            removed: []
        },
        dtv: {
            isAdded: false,
            productRemoved: false,
        }
    };
    public savedQuoteId: any;
    public schedulingURL: string = '';
    private appointment: Observable<AppointmentShipping>;
    private appointmentSubscription: Subscription;
    public productNameFromCart: any;
    public emailPlaceHolder: string = 'Not provided';
    public emailAddress: string;
    public isEmailValid: boolean;
    public isValidMail: any;
    public potsExists: boolean = false;
    public withCallReferral: boolean = false;
    public referralEndDate: any;
    public referralNumber1: any;
    public referralNumber2: any;
    public name1: any;
    public name2: any;
    public referralNumber: any;
    public referralEndDate1: any;
    public dtvOrderingInfo: any;
    public dtvInstallDueDate: any;
    public dtvOptIn: boolean = false;
    @ViewChild('simplePort', { static: false,}) public simplePortDialog: DialogComponent;
    @ViewChild('ponrTrueSubmitOrder', { static: false,}) public ponrTrueSubmitOrder: DialogComponent;
    public emailAdd: string;
    public isRCCacknowledged: any;
    public rccDone: boolean = false;
    public dealerId: string;
    public dealerName: string;
    public isMultipleDealerCode: boolean;
    public productDealerCodeInfo: any[] = [];
    public prodDealerCodeResponse: any;
    @ViewChild('changeSalesId', { static: false,}) public changeSalesId: DialogComponent;
    public dealerCodeChanged = false;
    public isAmend: boolean = false;
    public isStack: boolean = false;
    public isPONRChanged: boolean = false;
    public NIPendingStackAmend: boolean = false;
    public firstTimeLoad: boolean;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public pendingObservable: Observable<any>;
    public stackAmendDropDownTitle: string = '';
    public existingData: any;
    public isCORFlow: boolean = false;
    public dtvFlag: boolean = false;
    public orderFlow: string;
    public isLifelineRemoved: string = '';
    public creditCheckflag: boolean = true;
    public cartCORObservable: any;
    public cartCORSubscription: Subscription;
    public dtvForm:object = { taskName: '', accNo: '' };
    public isCORSTeam: boolean = false;
    public retrieveProducts: Observable<any>;
    public retrieveSubscribe: Subscription;
    public isUnholdFlow: boolean;
    public creditRevObsv: Observable<CreditCheck>;
    public creditRevSubscription: Subscription;
    public reviewOrderVariables:ReviewOrderVariables
    public agentFirstName: any;
    public agentLastName: any;
    public isAppointmentTime: boolean;
    constructor(
        private logger: Logger,
        private reviewOrderService: ReviewOrderService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private router: Router,
        public ctlHelperService: CTLHelperService,
        public helperService: HelperService,
        public reviewOrderHelperService: ReviewOrderHelperService
    ) {
        this.reviewOrderVariables = this.reviewOrderHelperService.setReviewOrderVablesDefault(this.reviewOrderVariables);
        this.appStateService.setLocationURLs();
        this.isCORSTeam = this.helperService.isAuthorized(ProfileEnums.ALLOW_CURRENT_DUE_DATE);
        this.user = <Observable<User>>store.select('user');
        this.pendingObservable = <Observable<any>>store.select('pending');
        this.pendingObservable.subscribe(pending => {
            if (pending && pending !== undefined && pending.orderReference && pending.orderReference !== undefined && pending.orderReference.pointOfNoReturn) {
                this.isPONRChanged = pending.orderReference.pointOfNoReturn;
            }
        });
        this.retrieveProducts = this.store.select('existingProducts');
        this.retrieveSubscribe = this.retrieveProducts.subscribe((data) => {            
            if(data && data.orderFlow && data.orderFlow.flow)
                this.reviewOrderVariables.currentFlow = data.orderFlow.flow;
            if(data && data.pendingOrders && 
                data.pendingOrders[0].orderReference && 
                data.pendingOrders[0].orderReference.reason && 
                data.pendingOrders[0].orderReference.reason[0].description && 
                data.pendingOrders[0].orderReference.reason[0].description !== undefined &&
                data.pendingOrders[0].orderReference.reason[0].description !== null ) {
                this.isUnholdFlow = true;
            }           
        })
        this.retainVal = <Observable<any>>store.select('retain')
        this.retainVal.subscribe((val) => {
            if (val && val.account && val.account.payload && val.account.payload !== undefined
                && val.account.payload.productConfiguration
                && val.account.payload.productConfiguration !== undefined
                && val.account.payload.productConfiguration.length > 0
                && val.account.payload.productConfiguration[0].configItems
                && val.account.payload.productConfiguration[0].configItems !== undefined
                && val.account.payload.productConfiguration[0].configItems.length !== 0) {
                this.productSelected = val.account.payload.productConfiguration[0].configItems[0].productName
            }
        });
        this.appointment = store.select('appointment');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointmentSubscription = this.appointment.subscribe((data) => {
                if (data && data.appointmentInfoNoValue){
                    this.isAppointmentTime = true;
                }
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    if (data.payload.cart || !data.payload.appointmentInfo) {
                        this.schedulingURL = '/schedule-appt-ship';
                    }
                    else {
                        this.schedulingURL = '/schedule-appt';
                    }
                }
                if (data && data.reservedCbr && data.reservedCbr !== null && data.reservedCbr !== undefined) {
                    this.contactNumber = data.reservedCbr
                }
                if (data && data.payload && data.payload.referralRequired && data.payload.referralRequired === "Yes") {
                    if (data && data.payload && data.payload.productConfiguration) {
                        data.payload.productConfiguration.map((configDetails) => {
                            if (configDetails.productType === GenericValues.cHP) {
                                this.potsExists = true;
                                configDetails && configDetails.configItems && configDetails.configItems.map((configItems) => {
                                    configItems && configItems.configDetails && configItems.configDetails.map((conf) => {
                                        if (conf && conf.formName && conf.formName === 'Referral form') {
                                            this.withCallReferral = true;
                                            conf.formItems && conf.formItems.map((formItems) => {
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral End date') {
                                                    this.referralEndDate = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral Number') {
                                                    this.referralNumber = this.maskTelephone(formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value);
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral End date') {
                                                    this.referralEndDate1 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral Number 1') {
                                                    this.referralNumber1 = this.maskTelephone(formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value);
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Referral Number 2') {
                                                    this.referralNumber2 = this.maskTelephone(formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value);
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Name1') {
                                                    this.name1 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                                if (configItems && configItems.productName && configItems.productName === this.productSelected && formItems.attributeName === 'Name2') {
                                                    this.name2 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                }
                                            })
                                        }
                                    })
                                })
                            }
                        })
                    }
                }
            });
            this.appointmentSubscription.unsubscribe();
        }
        this.isEmailValid = true;

        //Fetching speed for HSI product
        this.productNameFromCart = this.reviewOrderService.fetchPrimaryProductName();

        this.userSubscription = this.user.subscribe((data) => {
            this.shippingName = data.shippingName;
            this.isPrepaid = (data.prepaidFlag && data.prepaidFlag === 'PREPAID') ? true : false;
            if (data.currentUrl !== null && data.currentUrl !== undefined) {
                this.currentPath = data.currentUrl;
            }
            if(data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.agentFirstName && data.autoLogin.oamData.agentLastName)
            {
                this.agentFirstName = data.autoLogin.oamData.agentFirstName;
                this.agentLastName = data.autoLogin.oamData.agentLastName;
            }
        });

        this.creditRevObsv = store.select('creditReview');
        this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
            this.creditCheckObj = creditData;
            if(creditData.payload && creditData.payload.creditInfo && creditData.payload.creditInfo.creditApplicationRefNumber === "00000000000000")
            {
                this.creditCheckflag = false;
            
            }
         
        });
        this.submitOrderObservable = <Observable<any>>store.select('order');
        this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
            this.submitOrderResponse = data;
        });
        if (this.currentPath === '/co-order-confirmation') {
            this.submitOrderObservable = <Observable<any>>store.select('order');
            this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
                this.confirmOrder = data;
                this.accountDetailsCollapsed = true;
                if (data && data.payload && data.payload.billEstimate) {
                    if (data.payload.billEstimate && data.payload.billEstimate.quote && data.payload.billEstimate.quote[0] 
                        && data.payload.billEstimate.quote[0].quoteId) {
                        this.savedQuoteId = data.payload.billEstimate.quote[0].quoteId;
                    }
                }

                this.reviewOrderHelperService.getOrderDetails(data, this.reviewOrderVariables);

                let x = data.offerSummary;
                let y = data.offers;
                let combinedObj = {
                    offerSummary: x,
                    offers: y
                };
                this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
            });
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data && data.payload && data.payload.accountInfo && data.payload.accountInfo.contact && data.payload.accountInfo.contact.emailAddress) {
                    this.emailAdd = data.payload.accountInfo.contact.emailAddress;
                }
                if(this.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                    this.prepaidData = data.payload.currentBillQuote;
                    if(data.payload.currentBillQuote && data.payload.currentBillQuote.firstMonthList
                        && data.payload.currentBillQuote.firstMonthList.totalCharges
                        ){
                        this.totalcharges = data.payload.currentBillQuote.firstMonthList.totalCharges;
                    }
                }
            });
        } else {
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data && data.payload && data.payload !== undefined) {
                    this.dtvOrderingInfo = data.payload.hasOwnProperty('dtvOrderingInfo') ? data.payload.dtvOrderingInfo : {};
                    if (this.dtvOrderingInfo && this.dtvOrderingInfo.dtvInstallDueDate) {
                        this.dtvInstallDueDate = this.dtvOrderingInfo.dtvInstallDueDate;
                        this.dtvOptIn = true;
                    }
                    if (data && data.payload && data.payload.billEstimate) {
                        if (data.payload.billEstimate && data.payload.billEstimate.quote && data.payload.billEstimate.quote[0] 
                            && data.payload.billEstimate.quote[0].quoteId) {
                            this.savedQuoteId = data.payload.billEstimate.quote[0].quoteId;
                        }
                    }
    
                    this.reviewOrderHelperService.getOrderDetails(data, this.reviewOrderVariables);

                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
                }

                if(this.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                    this.prepaidData = data.payload.currentBillQuote;
                }

            });
        }
        if (this.currentPath === '/co-order-confirmation' || this.currentPath === '/co-review-order') {
            this.firstTimeLoad = true;
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data && data.payload && data.payload.accountInfo && data.payload.accountInfo.contact && data.payload.accountInfo.contact.emailAddress) {
                    this.emailAdd = data.payload.accountInfo.contact.emailAddress;
                }
                this.orderRefNumber = data.orderRefNumber;
                if (data.productSalesIdInfo === undefined && this.currentPath === '/co-review-order') {
                    this.getProductDealerCodeInfo(false);
                } else if (this.currentPath === '/co-review-order') {
                    this.productDealerCodeInfo = data.productSalesIdInfo.productDealerCodeInfo;
                    this.isMultipleDealerCode = data.productSalesIdInfo.isMultipleDealerCode;
                    this.dealerCodeChanged = data.productSalesIdInfo.dealerCodeChanged;
                    if (!this.isMultipleDealerCode && this.productDealerCodeInfo && this.productDealerCodeInfo[0]) {
                        this.dealerId = this.productDealerCodeInfo[0].dealerCode;
                        this.dealerName = this.productDealerCodeInfo[0].firstName + ' ' + this.productDealerCodeInfo[0].lastName;
                    }
                    if (this.firstTimeLoad) {
                        this.getProductDealerCodeInfo(false);
                    }
                }
            });
        }

        //placeholder for getting updated cart
        this.cartObservable = <Observable<any>>store.select('customize');
        this.cartSubscription = this.cartObservable.subscribe((data) => {
            if (data && data.payload && data.payload.cart !== null && data.payload.cart !== undefined && data.payload.cart.customerOrderItems !== undefined) {
                this.cartDetails = data.payload.cart.customerOrderItems;

                this.prodConf = data.payload.existingProductConfiguration;

                if (this.prodConf && this.prodConf.length > 0) {
                    this.prodConf.map(struct => {
                        if (struct.productType === GenericValues.cDTV) {
                            struct.configItems.map(confItem => {
                                confItem.configDetails.map(confDet => {
                                    confDet.formItems.map(formItem => {
                                        if (formItem.attributeName === 'DIRECTV Account ID') {
                                            this.existingDTVAccountId = formItem.attributeValue[0].value;
                                        }
                                    })
                                });
                            });
                        }
                    });
                }

                data.payload.cart.customerOrderItems.map(item => {
                    if (item.productType === 'INTERNET' || item.offerCategory === 'INTERNET') {
                        this.lifelineInternetAdded = false;
                    }
                    if ((item.offerCategory === GenericValues.sData ||
                        item.offerCategory === GenericValues.iData) && item.offerType !== 'SUBOFFER') {
                        if (item.action && (item.action === 'CHANGE')) {
                            if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
                                item.customerOrderSubItems.map(subitem => {
                                    if (subitem.action) {
                                        if (subitem.action === 'CHANGE') {
                                            this.servicesChanged.internet.isChanged = true;
                                            if (subitem.componentType === "PRIMARY") {
                                                this.servicesChanged.internet.changed.push(subitem.productName);
                                            } else {
                                                this.servicesChanged.internet.changed.push(subitem.productAttributes[0].compositeAttribute[0].attributeValue);
                                            }
                                        }
                                        if (subitem.action === 'ADD') {
                                            if (subitem.productName.toLowerCase() === 'jack and wire') {
                                                subitem.productAttributes && subitem.productAttributes.map((productAttributes) => {
                                                    productAttributes.compositeAttribute.map((item) => {
                                                        if (item.attributeValue.toLowerCase() !== 'no work is needed') {
                                                            this.servicesChanged.internet.added.push(subitem.productName);
                                                        }
                                                    })
                                                })
                                            } else {
                                                this.servicesChanged.internet.added.push(subitem.productAttributes[0].compositeAttribute[0].attributeValue);
                                            }
                                        }
                                        if (subitem.action === 'REMOVE') {
                                            this.servicesChanged.internet.removed.push(subitem.productAttributes[0].compositeAttribute[0].attributeValue);
                                        }
                                    }
                                });
                            }
                        }

                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.internet.isAdded = true;
                        }
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.internet.productRemoved = true;
                        }
                    }
                    if (item.offerCategory === GenericValues.cDHP && item.offerType !== 'SUBOFFER') {
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.dhp.productRemoved = true;
                        }
                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.dhp.isAdded = true;
                        }
                        if (item.action && (item.action === 'CHANGE')) {
                            this.servicesChanged.dhp.isChanged = true;
                            if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
                                item.customerOrderSubItems.map(subitem => {
                                    if (subitem.action) {
                                        if (subitem.action === 'CHANGE') {
                                            this.servicesChanged.dhp.changed.push(subitem.productName);
                                        }
                                        if (subitem.action === 'ADD') {
                                            this.servicesChanged.dhp.added.push(subitem.productName);
                                        }
                                        if (subitem.action === 'REMOVE') {
                                            this.servicesChanged.dhp.removed.push(subitem.productName);
                                        }
                                    }
                                });
                            }
                        }


                    }
                    if (item.offerCategory === GenericValues.cDTV) {
                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.dtv.isAdded = true;
                        }
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.dtv.productRemoved = true;
                        }
                    }
                })
            }
        });

        this.apptObservable = <Observable<any>>store.select('appointment');
        this.apptSubscription = this.apptObservable.subscribe((data) => {
            if (data && data.payload && data.payload.cart !== null && data.payload.cart !== undefined && data.payload.cart.customerOrderItems !== undefined) {
                data.payload.cart.customerOrderItems && data.payload.cart.customerOrderItems.map(item => {
                    if (item.offerCategory === GenericValues.cHP && item.offerType !== 'SUBOFFER') {
                        if (item.action && item.action === 'REMOVE') {
                            this.servicesChanged.pots.productRemoved = true;
                        }
                        if (item.action && item.action === 'ADD') {
                            this.servicesChanged.pots.isAdded = true;
                        }
                        if (item.action && item.action === 'CHANGE') {
                            this.servicesChanged.pots.isChanged = true;
                            if (item.customerOrderSubItems && item.customerOrderSubItems.length > 0) {
                                item.customerOrderSubItems.map(subitem => {
                                    if (subitem.action) {
                                        if (subitem.action === 'CHANGE') {
                                            this.servicesChanged.pots.changed.push(subitem.productName);
                                        }
                                        if (subitem.action === 'ADD') {
                                            if (subitem.productName.toLowerCase() === 'jack and wire') {
                                                subitem.productAttributes.map((productAttributes) => {
                                                    productAttributes.compositeAttribute.map((item) => {
                                                        if (item.attributeValue.toLowerCase() !== 'no work is needed') {
                                                            this.servicesChanged.pots.added.push(subitem.productName);
                                                        }
                                                    })
                                                })
                                            } else {
                                                this.servicesChanged.pots.added.push(subitem.productName);
                                            }
                                        }
                                        if (subitem.action === 'REMOVE') {
                                            this.servicesChanged.pots.removed.push(subitem.productName);
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
            }
        });
        let allDayRetainDat = <Observable<any>>this.store.select('retain');
        let allDatRetainData = allDayRetainDat.subscribe((respData) => {
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.startDateTime && respData.selectedappointment.timeSlot.startDateTime !== undefined) {
                this.allday = respData.selectedappointment.allDayAppt;
            }

        });
        allDatRetainData.unsubscribe();
        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            this.existingData = data;
            if(data && data.orderFlow && data.orderFlow.flow)this.reviewOrderVariables.currentFlow = data.orderFlow.flow;
            this.orderFlow = this.existingData && this.existingData.orderFlow && this.existingData.orderFlow.flow;
            if (this.orderFlow === "COR") {
                this.isCORFlow = true;
                if (data && data.existingProductsAndServices) {
                    data.existingProductsAndServices.map(k => { k.productConfiguration.map(i => { if(i && i.productType === "VIDEO-DTV") { this.dtvFlag = true; } }) });
                }
                this.isLifelineRemoved = this.existingData && this.existingData.changeRespInit && this.existingData.changeRespInit.payload && this.existingData.changeRespInit.payload.isLifelineRemoved;
            }
            if (data && data.stackamend && data.stackamend.stackAmendFlag === 'stackOrder') {
                this.isStack = true;
                this.stackAmendDropDownTitle = 'Stack Order';
            } else if (data && data.stackamend && data.stackamend.stackAmendFlag === 'amendOrder') {
                this.isAmend = true;
                this.stackAmendDropDownTitle = 'Amend Order';
            }
            if (data && data.NIPendingStackAmend){
                this.NIPendingStackAmend = data.NIPendingStackAmend;
            }
        });
        this.existingSubscription.unsubscribe();
        if (this.orderFlow === "COR") {
            this.cartCORObservable = <Observable<any>>store.select('retain');
            this.cartCORSubscription = this.cartCORObservable.subscribe((data) => {
                let CORprodConf = data && data.scheduling && data.scheduling.payload && data.scheduling.payload.productConfiguration;
                if (CORprodConf && CORprodConf.length > 0) {
                    CORprodConf.map(struct => {
                        if (struct.productType === GenericValues.cDHP) {
                            this.servicesChanged.dhp.isChanged = true;
                            struct.configItems.map(confItem => {
                                confItem.configDetails.map(confDet => {
                                    confDet.formItems.map(formItem => {
                                        if (formItem.attributeName === 'Listing Type') {
                                            this.servicesChanged.dhp.changed.push(formItem.attributeValue[0].value);
                                        }
                                    })
                                });
                            });
                        }
                        if (struct.productType === GenericValues.cHP) {
                            this.servicesChanged.pots.isChanged = true;
                            struct.configItems.map(confItem => {
                                confItem.configDetails.map(confDet => {
                                    confDet.formItems.map(formItem => {
                                        if (formItem.attributeName === 'Listing Type') {
                                            this.servicesChanged.pots.changed.push(formItem.attributeValue[0].value);
                                        }
                                    })
                                });
                            });
                        }                            
                        
                    });
                }
            });
            this.cartCORSubscription.unsubscribe();
        }
    }

    public maskTelephone(number: string) {
        if (number && number.indexOf('-') === -1) {
            return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
        }
        else if (number) {
            return number;
        }
    }

    public ngOnInit() {
        let pageName;
        if (this.currentPath === '/co-order-confirmation') {
            pageName = 'OrderConfirmationChangeOrderPage';
        }
        else {
            pageName = 'ReviewOrderChangeOrderPage';
        }
        this.logger.metrics(pageName);
        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((userdata) => {
            this.isDtvOpus = userdata.isDtvOpus;
            if (userdata && userdata.selfinstallselected !== undefined && userdata.selfinstallselected === true) {
                this.selfInstallSel = userdata.selfinstallselected;
            } else {
                this.selfInstallSel = false;
            }
        });
        this.submitOrderObservable = <Observable<any>>this.store.select('order');
        this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
            if (data.payload.lifelineInfo !== null && data.payload.lifelineInfo !== '' && data.payload.lifelineInfo !== undefined) {
                this.internetLifeline = data.payload.lifelineInfo.lifelineInfo;
                this.internetLifeline.map((item) => {
                    if (item.lifelineProductType === "INTERNET") {
                        this.lifelineInternetAdded = true;
                    }
                    if (item.lifelineProductType === "VOICE-HP") {
                        this.lifelinePotsAdded = true;
                    }
                    if (item.lifelineProductType === "VOICE-DHP") {
                        this.lifelineDhpAdded = true;
                    }
                })
            }
        });
        this.paymentDone = true;
        this.reviewOrderVariables.reviewed = true;
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.submitOrderSubscription !== undefined) {
            this.submitOrderSubscription.unsubscribe();
        }
        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }
        if (this.apptSubscription !== undefined) {
            this.apptSubscription.unsubscribe();
        }

    }

    /**
     * To set the clicked pricing Tab active & update respective tab summary amount
     * @param tab as string
     * @param month which describe prices for particular month
     */
    public setActive(tab: string, month: Month) {
        this.currentTab = tab;
        this.billCharges = month.charges;
        this.currentMonthNo = month.monthId;
        this.RCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };
        this.OTCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };

        for (let k in this.billCharges) {
            if (this.billCharges[k].chargeType === 'RC') {
                this.RCBillSummary = this.billCharges[k].summary;
                break;
            }
        }
        for (let k in this.billCharges) {
            if (this.billCharges[k].chargeType === 'OTC') {
                this.OTCBillSummary = this.billCharges[k].summary;
                break;
            }
        }

        this.summaryTotal =
            (this.RCBillSummary.totalBillAmount +
                this.OTCBillSummary.totalBillAmount +
                this.RCBillSummary.totalTaxes +
                this.OTCBillSummary.totalTaxes) -
            (this.RCBillSummary.totalDiscount +
                this.OTCBillSummary.totalDiscount);
    }

    /**
     * To check/set the diable notification checkbox boolean
     */
    public checkNotification() {
        this.checkNotificationlink = false;
        this.checkNotificationCheckbox = true;
    }

    /**
     * To validate pricing details checked & deposits if required taken
     */
    public checkOrder() {
        if ((this.submitOrderResponse && this.submitOrderResponse.paymentdepositdata && this.submitOrderResponse.paymentdepositdata !== undefined && this.submitOrderResponse.paymentdepositdata.depositPaymentStatus === "PAID") || this.creditCheckObj.paymentStatus) {
            this.paymentDone = true;
        } else if (this.submitOrderResponse && this.submitOrderResponse.paymentdepositdata && this.submitOrderResponse.paymentdepositdata !== undefined && this.submitOrderResponse.paymentdepositdata.depositPaymentStatus === "UNPAID") {
            this.paymentDone = false;
        }
        if (this.paymentDone) {
            this.PaymentErrMsg = this.paymentDone;
        }
        
        if ((this.reviewOrderVariables.rccDone) && this.paymentDone) {
            this.submitOrder(this.isRCCacknowledged, this.additioanalNotes.text, this.reviewOrderVariables.disableNotification, this.reviewOrderVariables.orderObject);
        } else {
            this.paymentDone = false;
            this.reviewOrderVariables.checkOrderConfirmation = true;
        }
    }

    /* public AcknowledgeRCCs() {
        this.rccDone = true;
        if (this.rccDone) {
            this.isRCCacknowledged = "Yes";
        } else {
            this.isRCCacknowledged = "No";
        }
    } */

    public isAcknowledged(event) {
        this.isRCCacknowledged = event.isrccAcknowledged;
        if (this.isRCCacknowledged === "Yes") {
            this.reviewOrderVariables.rccDone = false;
            this.paymentDone = true;
        } else {
            this.reviewOrderVariables.rccDone = true;
        }
    }

    /**
     * To scroll upto the Pricing block if not acknowledged
     * @param element as clicked pricing check dom element
     */
    public checkPricingAck(element) {
        window.scrollTo(0, document.getElementById(element).offsetTop - 140);
    }

    /**
     * To summary of bill for a month
     * @param charges for a month
     */
    public getTabSummaryTotal(charges) {
        let totalBill = 0;
        let totalDiscounts = 0;
        let totalTaxes = 0;
        charges && charges.map((charge) => {
            if (Object.keys(charge.summary).length > 0) {
                totalBill += charge.summary['totalBillAmount'];
                totalDiscounts += charge.summary['totalDiscount'];
                totalTaxes += charge.summary['totalTaxes'];
            }
        });
        return totalBill + totalTaxes - totalDiscounts;
    }

    /**
     * To get higher level product totalfrom individual amounts from API
     * @param product
     */
    public getProductTotal(product): number {
        let primaryProductAmount: number = 0;
        let additionalSevicesAmount: number = 0;
        let totalDiscounts: number = 0;
        let totalTaxes: number = 0;

        let primaryService = product.primaryService;
        primaryService.map((k) => {
            if (k.billAmount && k.billAmount > 0) {
                primaryProductAmount += k.billAmount;
            }
            if (k.discountAmount) {
                totalDiscounts += k.discountAmount;
            }
            if (k.taxes && Object.keys(k.taxes).length > 0) {
                totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
            }
        });

        let additionalService = product.additionalServices;
        additionalService.map((k) => {
            if (k.billAmount && k.billAmount > 0) {
                additionalSevicesAmount += k.billAmount;
            }
        });

        return primaryProductAmount + additionalSevicesAmount + totalTaxes - totalDiscounts;
    }

    /**
     * To get higher level product OTC totalfrom individual amounts from API
     * @param product
     */
    public getOTCTotal(product) {
        let primaryProductAmount: number = 0;
        let additionalSevicesAmount: number = 0;
        let totalDiscounts: number = 0;
        let totalTaxes: number = 0;
        product && product.map((p) => {
            let primaryService = p.primaryService;
            primaryService.map((k) => {
                if (k.billAmount && k.billAmount > 0) {
                    primaryProductAmount += k.billAmount;
                }
                if (k.discountAmount) {
                    totalDiscounts += k.discountAmount;
                }
                if (k.taxes && Object.keys(k.taxes).length > 0) {
                    totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
                }
            });
            let additionalService = p.additionalServices;
            additionalService.map((k) => {
                if (k.billAmount && k.billAmount > 0) {
                    additionalSevicesAmount += k.billAmount;
                }
                if (k.discountAmount) {
                    totalDiscounts += k.discountAmount;
                }
                if (k.taxes && Object.keys(k.taxes).length > 0) {
                    totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
                }
            });
        });

        return primaryProductAmount + additionalSevicesAmount + totalTaxes - totalDiscounts;
    }

    /**
     * To get Bill Cycle in format xth of each month
     * @param day
     */
    /* public getBillCycleDay(day) {
        let suffixes = ['th', 'st', 'nd', 'rd'];
        let relevantDigits = (day < 30) ? day % 20 : day % 30;
        let suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
        return day + suffix;
    } */

    /**
     * To mask phone number as pe USA format (xxx-xx-xxxx)
     * @param data as response
     */
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }

    /**
     * submit request from order summary page
     * @param pricingConfirmation as pricing ack
     * @param additionalNotes entered notes
     * @param disableNotifications checkbox checked or not
     * @param order fetching refnumber, taskId
     */
    public submitOrder(pricingConfirmation: string, additionalNotes: string,
        disableNotifications: boolean, order) {
        this.loading = true;
        let chargeSummaryAck: boolean;
        let remark: OrderRemarks;
        chargeSummaryAck = (pricingConfirmation === 'Yes') ? true : false;
        remark = {
            name: 'Order Remarks',
            value: additionalNotes,
            date: new DatePipe('en-US').transform(new Date(), 'mediumDate'),
            author: this.agentFirstName + ' ' + this.agentLastName
        
        };

        let additionalInfo: AdditionalInfo = {
            chargeSummaryAck,
            disableOrderNotification: disableNotifications
        };
        this.retrieveProducts = this.store.select('existingProducts');
        this.retrieveSubscribe = this.retrieveProducts.subscribe((data) => {
            if(data && data.orderFlow && data.orderFlow.flow)this.reviewOrderVariables.currentFlow = data.orderFlow.flow;
            if(data && data.existingProductsAndServices &&data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress.locationAttributes){
                this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;                
            }
        })

        let dealerCodeChangeInfo = [];
        this.productDealerCodeInfo && this.productDealerCodeInfo.map(prod => {
            if (prod.changed) {
                let prodInfo = {
                    offerCategory: prod.offerCategory,
                    productType: prod.productType,
                    productname: prod.productname,
                    dealerCode: prod.dealerCode,
                    firstName: prod.firstName,
                    lastName: prod.lastName
                }
                dealerCodeChangeInfo.push(prodInfo);
            }
        });

        let payload: OrderNotes = {
            additionalInfo: additionalInfo,
            orderRemarks: [remark],
            dealerCodeChangeInfo: dealerCodeChangeInfo
        }

        let request: OrderRq = {
            orderRefNumber: order.orderRefNumber,
            processInstanceId: order.processInstanceId,
            taskId: order.taskId,
            taskName: order.taskName,
            payload
        };

        this.store.dispatch({ type: 'CONFIRM_ORDER', payload: payload });
        let newRequest= cloneDeep(request);
        if(!this.creditCheckflag)
        {
               newRequest.payload.orderRemarks[0].value= newRequest.payload.orderRemarks[0].value.length>1? newRequest.payload.orderRemarks[0].value+ ' Credit Check Failed!':  newRequest.payload.orderRemarks[0].value+ 'Credit Check Failed!'
        }
        if(newRequest.payload.orderRemarks[0].value === '')
        {
               delete newRequest.payload.orderRemarks;
            
        }
        let errorResolved = false;
        this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService.postSubmitTaskService(newRequest, this.orderFlow)
            .catch((error: any) => {
                this.logger.endTime();
                if(this.isCORFlow) {
                    this.logger.log("error", "cor-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                    this.logger.log("error", "cor-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                } else {
                    this.logger.log("error", "co-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                    this.logger.log("error", "co-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "submitTask - postSubmitOrder", "co-review-order.component.ts",
                    "Review Order Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    if(this.isCORFlow) {
                        this.logger.log("info", "cor-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data ? data : ''),this.legacyProvider);
                        this.logger.log("info", "cor-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "cor-review-order.component.ts", "orderCompletedCOR", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    } else if (this.isUnholdFlow) {
                        this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data ? data : ''),this.legacyProvider);
                        this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "co-unhold.component.ts", "orderCompletedUnholdChange", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    } else {
                        this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data ? data : ''),this.legacyProvider);
                        this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "co-review-order.component.ts", "orderCompletedChange", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    }
                    if (data && data.errorResponse && data.errorResponse[0] !== undefined && data.errorResponse[0].reasonCode && data.errorResponse[0].reasonCode !== undefined && (data.errorResponse[0].reasonCode === 'SIMPLE_PORT_FAILURE' || data.errorResponse[0].reasonCode === 'SIMPLE_PORT_SCHEDULING_FAILURE')) {
                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                        this.loading = false;
                        this.simplePortDialog.open();
                    } else if (data && data.errorResponse && data.errorResponse[0] !== undefined && data.errorResponse[0].reasonCode && data.errorResponse[0].reasonCode !== undefined && data.errorResponse[0].reasonCode === "PONR_FAILURE" && this.isAmend) {
                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                        this.store.dispatch({ type: 'UPDATE_AMEND_ALLOWED', payload: 'false' });
                        this.loading = false;
                        this.isPONRChanged = true;
                        this.ponrTrueSubmitOrder.open();
                    }
                    else {
                        if (data.payload && data.payload.paymentDetails && data.payload.paymentDetails.finalBillPaymentStatus && data.payload.paymentDetails.finalBillPaymentStatus.depositPaymentStatus === "UNPAID") {
                            this.paymentDone = true;
                        }
                        this.loading = true;
                        this.confirmOrder = data;
                        if(order.payload) order.payload.orderRemarks = remark;
                        let submitData = Object.assign({}, order, this.confirmOrder.payload);
                        this.store.dispatch({ type: 'SUBMITTED_ORDER', payload: submitData });
                        this.router.navigate(['/co-order-confirmation']);
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        if (this.isCORFlow) {
                            this.logger.log("info", "cor-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                            this.logger.log("info", "cor-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        } else {
                            this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                            this.logger.log("info", "co-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task -  Review Order", "co-review-order.component.ts", "Review Order Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Review Order Page", "co-review-order.component.ts", "Review Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    public handleCancelClick(event) {
        this.router.navigate(['/existing-products']);
    }

    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }

    public notificationValidation() {
        if (this.reviewOrderVariables.emailNotExist) {
            this.emailAddress = '';
            this.emailPlaceHolder = 'Not provided';
        }
        else {
            this.emailPlaceHolder = '';
        }
        this.emailAddress ? this.isValidMail = Validations.emailValidator({ value: this.emailAddress }) : this.isValidMail = null;

        this.isValidMail === null ? this.isEmailValid = true : this.isEmailValid = false;
        this.emailAddress && this.isValidMail === null ? this.reviewOrderVariables.emailValidChecked = false : this.reviewOrderVariables.emailValidChecked = true;

    }
    public changeSalesIdDialog() {
        if (this.productDealerCodeInfo === undefined || this.productDealerCodeInfo.length === 0) {
            this.getProductDealerCodeInfo(true);
        } else {
            this.productDealerCodeInfo.forEach(prod => prod.changeId = prod.chnageAllowed);
            this.changeSalesId.open();
        }
    }

    private getProductDealerCodeInfo(openDialog: boolean) {
        let request = {
            orderReferenceNumber: this.orderRefNumber,
            salesChannel: 'ESHOp-Customer Care'
        }
        this.loading = true;
        this.logger.log("info", "co-review-order.component.ts", "productDealerCodeInfoRequest", JSON.stringify(request));
        this.logger.startTime();
        let errorResolved = false;
        this.reviewOrderService.retrieveProductDealerCodeInfo(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "co-review-order.component.ts", "productDealerCodeInfoResponse", error);
                this.logger.log("error", "co-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "retrieveProductDealerCodeInfo", "co-review-order.component.ts",
                    "Review Order Page",
                    error);
                return Observable.throwError(null);

            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "co-review-order.component.ts", "productDealerCodeInfoResponse", JSON.stringify(data));
                    this.logger.log("info", "co-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.prodDealerCodeResponse = data;
                    const prodNameMap = {
                        'INTERNET': {
                            'name': 'Internet',
                            'imgUrl': './assets/img/internet_sm.png',
                            'dealerInfo': ''
                        },
                        'VOICE-HP': {
                            'name': 'Home Phone',
                            'imgUrl': './assets/img/phone_sm.png',
                            'dealerInfo': ''
                        },
                        'VIDEO-DTV': {
                            'name': 'DIRECTV',
                            'imgUrl': './assets/img/tv_sm.png',
                            'dealerInfo': ''
                        },
                        'CENTURYLINK @ EASE': {
                            'dealerInfo': ''
                        }
                    };
                    let previousProdDealerCodeInfo = this.productDealerCodeInfo;
                    /* Retaining previously saved dealer code for reentrant scenario */
                    if (previousProdDealerCodeInfo.length > 0) {
                        previousProdDealerCodeInfo.forEach(prodInfo => {
                            if (prodInfo.changed) {
                                if ((prodInfo.productname).indexOf('EASE') !== -1) {
                                    prodNameMap[prodInfo.productname].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                } else {
                                    prodNameMap[prodInfo.productType].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                }
                            }
                        });
                    }
                    this.productDealerCodeInfo = [];
                    let dealerCodeArray = [];
                    let displayInternet = false;
                    let displayVoice = false;
                    this.prodDealerCodeResponse && this.prodDealerCodeResponse.productDealerCodeInfo && this.prodDealerCodeResponse.productDealerCodeInfo.map(prodInfo => {
                        if (prodInfo.isDisplay.toUpperCase() === 'YES') {
                            let isEase = ((prodInfo.productname).indexOf('EASE') !== -1);
                            let prodInfoObject = {
                                prodName: isEase ? prodInfo.productname : prodNameMap[prodInfo.productType],
                                firstName: prodInfo.firstName,
                                lastName: prodInfo.lastName,
                                dealerCode: prodInfo.dealerCode,
                                chnageAllowed: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                changeId: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                offerCategory: prodInfo.offerCategory,
                                productType: prodInfo.productType,
                                productname: prodInfo.productname,
                            }
                            if (isEase || prodInfo.productType === 'VIDEO-DTV') {
                                prodInfoObject['display'] = true;
                            }
                            if (!displayInternet && !isEase && prodInfo.productType === 'INTERNET') {
                                prodInfoObject['display'] = true;
                                displayInternet = true;
                            }
                            if (!displayVoice && prodInfo.productType === 'VOICE-HP') {
                                prodInfoObject['display'] = true;
                                displayVoice = true;
                            }
                            if (previousProdDealerCodeInfo.length > 0) {
                                let priviouslySavedValue = isEase ? prodNameMap[prodInfo.productname].dealerInfo : prodNameMap[prodInfo.productType].dealerInfo;
                                if (priviouslySavedValue !== '') {
                                    prodInfoObject.dealerCode = priviouslySavedValue.dealerCode;
                                    prodInfoObject.firstName = priviouslySavedValue.firstName;
                                    prodInfoObject.lastName = priviouslySavedValue.lastName;
                                    prodInfoObject['changed'] = true;
                                }
                            }
                            dealerCodeArray.push(prodInfoObject.dealerCode);
                            this.productDealerCodeInfo.push(prodInfoObject);
                        }
                    });

                    if (this.firstTimeLoad && dealerCodeArray) {
                        this.isMultipleDealerCode = !dealerCodeArray.every(val => (val === dealerCodeArray[0]));
                    }
                    this.firstTimeLoad = false;
                    if (this.productDealerCodeInfo.length === 0 && this.prodDealerCodeResponse && this.prodDealerCodeResponse.productDealerCodeInfo) {
                        this.isMultipleDealerCode = !this.prodDealerCodeResponse.productDealerCodeInfo.every(val => (val.dealerCode === this.prodDealerCodeResponse.productDealerCodeInfo[0].dealerCode));
                        this.dealerId = this.prodDealerCodeResponse && this.prodDealerCodeResponse.productDealerCodeInfo && this.prodDealerCodeResponse.productDealerCodeInfo[0] && this.prodDealerCodeResponse.productDealerCodeInfo[0].dealerCode;
                        this.dealerName = this.prodDealerCodeResponse.productDealerCodeInfo[0].firstName + ' ' + this.prodDealerCodeResponse.productDealerCodeInfo[0].lastName;
                    }
                    let payLoad = {
                        productDealerCodeInfo: this.productDealerCodeInfo,
                        isMultipleDealerCode: this.isMultipleDealerCode,
                        dealerCodeChanged: this.dealerCodeChanged
                    }
                    this.store.dispatch({ type: 'PROD_DEALER_ID', payload: payLoad });
                    if (openDialog)
                        this.changeSalesId.open();
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "co-review-order.component.ts", "productDealerCodeInfoResponse", error);
                        this.logger.log("error", "co-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (error === undefined || error === null)
                        return;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "co-review-order.component.ts", "Order Summary Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "co-review-order.component.ts", "Order Summary Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
}