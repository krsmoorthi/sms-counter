import {
  Component,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter
} from '@angular/core';
import { Logger } from '../../common/logging/default-log.service';

@Component({
  selector: 'ctl-submit-panel',
  styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
  templateUrl: './submit-panel.component.html'
})
export class SubmitPanelComponent implements OnInit, OnDestroy {
  @Output() public onSubmitOrder = new EventEmitter();
  @Output() public onPlaceOnHold = new EventEmitter();
  @Output() public onCancel = new EventEmitter();
  public loading;
  constructor(private logger: Logger
  ) {}

  public ngOnInit() {
    this.logger.metrics('ReviewOrderSubmitPanelPage');
  }

  public submitOrder() {
    this.onSubmitOrder.emit();
  }
  public placeOnHold() {
    this.onPlaceOnHold.emit();
  }
  public cancelOrder() {
    this.onCancel.emit();
  }

  public ngOnDestroy() {}
}
