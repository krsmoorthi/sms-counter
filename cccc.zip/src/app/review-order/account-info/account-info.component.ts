import { Component, OnInit, OnDestroy,Input } from '@angular/core';
import { Logger } from '../../common/logging/default-log.service';

@Component({
    selector: 'ctl-account-info',
    styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
    templateUrl: './account-info.component.html'
})
 
export class AccountInfoComponent implements OnInit, OnDestroy {
    @Input() public accountInfoData;
    @Input() public actionType='disconnect-review';
    constructor(private logger: Logger) {

     }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderAccountInfoPage');
    }

    public ngOnDestroy() {

    }

}
