import { DisconnectReviewOrderModel, DisconnectStore } from './../../common/models/disconnect.model';
import { Logger } from './../../common/logging/default-log.service';
import { DisconnectService } from './../../common/service/disconnect.service';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { AppStore } from './../../common/models/appstore.model';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppStateService } from '../../common/service/app-state.service';
import { SystemErrorService } from '../../common/service/system-error.service';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { APIErrorLists } from '../../common/models/common.model';
import { ExistingProducts } from 'app/common/models/existing-products.model';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { ReviewOrderVariables } from 'app/common/models/review.order.model';
import "rxjs/add/operator/catch";

@Component({
  selector: 'disconnect-review-order',
  styleUrls: ['./disconnect-review-order.component.scss'],
  templateUrl: './disconnect-review-order.component.html'
})

export class DisconnectReviewOrderComponent implements OnInit, OnDestroy {
  public legacyProvider: any;
  public currentPage: string = "disconnect-review"
  public showDisableNotificationFlag = false;
  public accountForm: FormGroup;
  public disconnectSubscription: Subscription;
  public disconnect$;
  public isDisconnectReviewSelected: true;
  public isDisconnectandReviewSelected: false;
  public isShowDisconnectFlowAccountButtons: false;
  public mainData: DisconnectReviewOrderModel;
  private existingProductsResponse: ExistingProducts;
  private existingProducts: Observable<any>;
  public existingProductsSubscription: Subscription;
  public loading = false;
  public isDtv = false;
  public formSubmited = false;
  public apiResponseError: APIErrorLists;
  public lease_modem_price;
  private accountInfo;
  public additioanalNotes: any = {
    text: ''
  };
  public savedQuoteId: string;
  public emailAddress: string;
  public rccDone: boolean = false;
  public billingType: string = '';
  public cusEmailAdd: string = '';
  public finalDisconnectDate: string = '';
  public user: Observable<any>;
  public userSubscription: Subscription;
  public currentPath: any;
  public isRCCacknowledged: string;
  public reviewOrderVariables: ReviewOrderVariables
  public agentFirstName: any;
  public agentLastName: any;

  constructor(
    private router: Router,
    private logger: Logger,
    private appStateService: AppStateService,
    private systemErrorService: SystemErrorService,
    private fb: FormBuilder,
    public store: Store<AppStore>,
    private disconnectService: DisconnectService,
    private ctlHelperService: CTLHelperService,
    public reviewOrderHelperService: ReviewOrderHelperService
  ) {
    this.reviewOrderVariables = this.reviewOrderHelperService.setReviewOrderVablesDefault(this.reviewOrderVariables);
    this.appStateService.setLocationURLs();
    this.disconnect$ = <Observable<any>>store.select('disconnect');
    this.disconnectSubscription =  this.disconnect$ && this.disconnect$.subscribe((respData: DisconnectStore) => {
      this.mainData = respData.disconnect_review_order;
      if (respData.disconnect_review_order && respData.disconnect_review_order.payload !== undefined) {
        this.savedQuoteId = respData.disconnect_review_order.payload.billEstimate && respData.disconnect_review_order.payload.billEstimate.quote &&
          respData.disconnect_review_order.payload.billEstimate.quote[0] && respData.disconnect_review_order.payload.billEstimate.quote[0].quoteId;
        if (respData.disconnect_review_order && respData.disconnect_review_order.payload.returnEquipments && respData.disconnect_review_order.payload.returnEquipments.length > 0) {
          if (respData.disconnect_review_order.payload.returnEquipments[0].productType === 'MODEM' && respData.disconnect_review_order.payload.returnEquipments[0].purchasePrice) {
            this.lease_modem_price = respData.disconnect_review_order.payload.returnEquipments[0].purchasePrice.otc;
          }
        }
        this.finalDisconnectDate = respData.disconnect_review_order.payload.finalPaymentDate;
      }
    });
    this.existingProducts = <Observable<any>>this.store.select('existingProducts');
    this.existingProductsSubscription =this.existingProducts && this.existingProducts.subscribe((data) => {
      if (data !== null && data !== undefined) {
        this.existingProductsResponse = data;
        if (data && data.orderFlow && data.orderFlow.flow === 'Disconnect' && data.orderFlow.type === 'fromHold') {
          let pendingSummaryObservable = <Observable<any>>store.select('pending');
          let pendingSummarySubscription =pendingSummaryObservable && pendingSummaryObservable.subscribe((pendingData) => {
            if (pendingData && pendingData.orderDocument && pendingData.orderDocument.customerOrderItems && pendingData.orderDocument.customerOrderItems.length > 0) {
              pendingData.orderDocument.customerOrderItems.map(item => {
                if (item.offerCategory === 'VIDEO-DTV') {
                  this.isDtv = true;
                  this.store.dispatch({ type: 'DISCONNECT_REVIEW_ORDER_SUBMIT', payload: { dtvExists: this.isDtv } });
                }
              })
            }
          })
          if (pendingSummarySubscription !== undefined) pendingSummarySubscription.unsubscribe();
        } else if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0) {
          let data1: any[] = this.existingProductsResponse.existingProductsAndServices[0].existingServices.existingServiceItems;
          for (let i = 0; i < data1.length; i++) {
            if (this.existingProductsResponse.existingProductsAndServices[0].existingServices.existingServiceItems[i].offerCategory === 'VIDEO-DTV') {
              this.isDtv = true;
              this.store.dispatch({ type: 'DISCONNECT_REVIEW_ORDER_SUBMIT', payload: { dtvExists: this.isDtv } });
            }
          }
          if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0]
            && this.existingProductsResponse.existingProductsAndServices[0].accountInfo) {
            if (this.existingProductsResponse.existingProductsAndServices[0].accountInfo.billingType === 'PREPAID') this.billingType = 'PREPAID';
            this.cusEmailAdd = this.existingProductsResponse.existingProductsAndServices[0].accountInfo.contact.emailAddress;
          }
        }
      }
      this.user = <Observable<any>>this.store.select('user');
      this.userSubscription =this.user && this.user.subscribe(
        (data) => {
          this.currentPath = data.currentUrl;
          if(data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.agentFirstName && data.autoLogin.oamData.agentLastName)
          {
              this.agentFirstName = data.autoLogin.oamData.agentFirstName;
              this.agentLastName = data.autoLogin.oamData.agentLastName;
          } 
        });
      if (this.currentPath === '/disconnect-order-confirmation' || this.currentPath === '/disconnect-review-order') {
        if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0) {
          if (data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.emailAddress && data.existingProductsAndServices[0].accountInfo.contact.emailAddress !== '') {
            this.emailAddress = data.existingProductsAndServices[0].accountInfo.contact.emailAddress;
          }
        }
      }
      if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0) {
        if (data.existingProductsAndServices[0].accountInfo) {
          this.accountInfo = data.existingProductsAndServices[0].accountInfo;
        }
      }

    });
  }


  public checkPricingAck(element) {
    window.scrollTo(0, document.getElementById(element).offsetTop - 140);
  }

  public ngOnInit() {
  let pageName;
    if (this.currentPath === '/disconnect-order-confirmation') {
      pageName = 'OrderConfirmationDisconnectOrderPage';
    }
    else {
      pageName = 'ReviewOrderDisconnectReviewOrderPage';
    }
    this.logger.metrics(pageName);

    window.scroll(0, 0);
    this.accountForm = this.fb.group({
      pricingCheck: ['', [Validators.required]],
      remarks: [''],
      disableNotification: ['']
    });
  }

  public ngOnDestroy() {
    this.existingProductsSubscription.unsubscribe();
  }

  private cancelOrder() {
    this.isDisconnectReviewSelected = true;
    this.isDisconnectandReviewSelected = false;
  }
  public discardDisconnReview(event) {
    this.cancelOrder();
    this.isShowDisconnectFlowAccountButtons = false;
  }
  public submitOrder() {
    if (this.rccDone || this.billingType === 'PREPAID') {
      this.formSubmited = true;
      let chargeSummaryAck: boolean;
      chargeSummaryAck = this.reviewOrderVariables.isRCCacknowledged && this.reviewOrderVariables.isRCCacknowledged === 'Yes' ? true : false;
      if (this.accountForm.valid || this.rccDone || this.billingType === 'PREPAID') {
        let request: any = {
          orderRefNumber: this.mainData.orderRefNumber,
          processInstanceId: this.mainData.processInstanceId,
          taskId: this.mainData.taskId,
          taskName: this.mainData.taskName,
          payload: {
            additionalNotes: {
              chargeSummaryAck,
              disableOrderNotification: false
            },
            orderRemarks: [
              {
                name: "Order Remarks",
                value: this.additioanalNotes.text,
                date: new DatePipe('en-US').transform(new Date(), 'mediumDate'),
                author: this.agentFirstName + this.agentLastName
              }
            ]
          }
        };
        if(request.payload.orderRemarks && request.payload.orderRemarks[0] && request.payload.orderRemarks[0].value === '')
        {
               delete request.payload.orderRemarks;
            
        }

        let existingObservable = <Observable<any>>this.store.select('existingProducts');
        existingObservable && existingObservable.subscribe((data) => {
          if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress.locationAttributes) {
            this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
          }
        })
        this.loading = true;
        this.logger.log("info", "disconnect-review-order.component.ts", "disconnectSubmitOrderInfoRequest", JSON.stringify(request));
        this.logger.startTime();
        this.disconnectService.submitInformation(request)
          .catch((error: any) => {
            this.logger.endTime();
            this.logger.log('error', 'disconnect-review-order.component.ts', 'disconnectSubmitOrderInfoResponse', JSON.stringify(error));
            this.logger.log("error", "disconnect-review-order.component.ts", "disconnectSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;
            this.systemErrorService.logAndRouteUnexpectedError(
              "error", "Not Applicable",
              "Submit Task", "disconnect-review-order.component.ts",
              "Disconnect Review Order",
              error);
            return Observable.throwError(null);
          })
          .subscribe(
            (data) => {
              this.logger.endTime();
              this.logger.log("info", "disconnect-review-order.component.ts", "disconnectSubmitOrderInfoResponse", JSON.stringify(data), this.legacyProvider);
              this.logger.log("info", "disconnect-review-order.component.ts", "disconnectSubmitOrderInfoResponse", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
              this.logger.log("info", "disconnect-review-order.component.ts", "orderCompletedDisconnect", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
              let response = data;
              if (response) {
                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                this.store.dispatch({ type: 'DISCONNECT_REVIEW_ORDER_SUBMIT', payload: { disconnect_review_order_submit: { disconnectSubmitresponse: response, formData: this.accountForm.value } } });
                this.router.navigate(['/disconnect-confirmation']);
              }
            },
            (error) => {
              this.logger.endTime();
              this.logger.log("error", "disconnect-review-order.component.component.ts", "disconnectSubmitOrderInfoResponse", error);
              this.logger.log("error", "disconnect-review-order.component.component.ts", "disconnectSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
              this.loading = false;
              if (error === undefined || error === null)
                return;
              let unexpectedError = false;
              if (this.ctlHelperService.isJson(error)) {
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                  this.apiResponseError.errorResponse.length > 0) {
                  this.systemErrorService.logAndeRouteToSystemError("error", "disconnectReviewOrderError", "disconnect-review-order.component.ts", "Disconnect Review Order Page", this.apiResponseError);
                } else unexpectedError = true;
              } else unexpectedError = true;
              if (unexpectedError) {
                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                this.systemErrorService.logAndeRouteToSystemError("error", "disconnectReviewOrderError", "disconnect-review-order.component.ts", "Disconnect Review Order Page", lAPIErrorLists);
              }
              window.scroll(0, 0);
            });
      }
    }
  }
  public AcknowledgeRCCs() {
    this.rccDone = true;
    this.isRCCacknowledged = "Yes";
}

  public showCheckBox() {
    this.showDisableNotificationFlag = true;
  }
  
}