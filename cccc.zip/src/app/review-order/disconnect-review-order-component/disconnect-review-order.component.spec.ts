import { TestBed, ComponentFixture, inject, async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { RouterTestingModule } from '@angular/router/testing';
import { MockReviewOrderService, MockHelperService, MockReviewOrderHelperService, MockLogger, MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockProductService, MockBlueMarbleService } from 'app/common/service/mockServices.test';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { HelperService } from 'app/common/service/helper.service';
import { Store } from '@ngrx/store';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ExistingProductsComponent } from 'app/existing-products/existing-products.component';
import { DisconnectReviewOrderComponent } from "./disconnect-review-order.component";

describe('Disconnect Order Review Order Component', () => {
    let component: DisconnectReviewOrderComponent;
    let fixture: ComponentFixture<DisconnectReviewOrderComponent>;
    let mockServer = new MockServer();
    let reviewOrderService: ReviewOrderService;
    let active = 'active';

    const imports = [
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        SharedModule,
        SharedCommonModule,
        AccordionModule.forRoot()
    ];
    RouterTestingModule.withRoutes([
        { path: 'br-order-confirmation', component: DisconnectReviewOrderComponent },
        { path: 'existing-products', component: ExistingProductsComponent }

    ])
   
    const mockRedux: any = {
        dispatch() { },
        configureStore() { },
        select(reducer) {
            return Observable.of(mockServer.getDisconnectStore("HSI_POTS_DISCONNECT_TILL_REVIEWORDER")[reducer]);
        },
        take<T>(this: Observable<T>, count: number) {
            return Observable.of(null);
        }
    }
  

    const p1 = { provide: AppStateService, useClass: MockAppStateService }
    const p2 = { provide: ReviewOrderService, useClass: MockReviewOrderService }
    const p3 = { provide: HelperService, useClass: MockHelperService };
    const p4 = { provide: Store, useValue: mockRedux };
    const p5 = ReviewOrderHelperService;
    const p6 = { provide: Logger, useClass: MockLogger };
    const p7 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p8 = CTLHelperService;
    const p9 = { provide: ProductService, useClass: MockProductService };
    const p10 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };

    let dp2 = { provide: PendingOrderService, useClass: MockPendingOrderService };
    let dp3 = { provide: AccountService, useClass: MockAccountService };
    let dp4 = { provide: AddressService, useClass: MockAddressService };
    let dp6 = { provide: CountryStateService, useClass: MockCountryStateService };
    let dp7 = { provide: DirectvService, useClass: MockDirectvService };
    let dp8 = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
    let dp9 = { provide: DisconnectService, useClass: MockDisconnectService };
    let providers_ = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, dp2, dp3, dp4, dp6, dp7, dp8, dp9]
    const baseConfig = {
        imports: imports,
        declarations: [DisconnectReviewOrderComponent],
        providers: providers_
    };

    describe('disconnect Order Review Order Component', () => {

        beforeEach(async(() => {
            TestBed.configureTestingModule(baseConfig)
                .compileComponents();
        }));

        beforeEach(() => {
            fixture = TestBed.createComponent(DisconnectReviewOrderComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it('should create disconnect component for hsi standalone flow', () => {
            expect(component).toBeTruthy();
        });
         it('should call multiple methods ', () => {
            component.ngOnDestroy();
            component.discardDisconnReview(null)
            component.AcknowledgeRCCs();
            expect(component.isShowDisconnectFlowAccountButtons).toBe(false);            
            expect(component.isDisconnectReviewSelected ).toBe(true);
        });
        it('should call submitOrder() method ', () => {
            component.rccDone = true;
            component.submitOrder();            
            expect(component.formSubmited).toBe(true);
        });
        it('should call showCheckBox() method ', () => {
            component.showCheckBox();            
            expect(component.showDisableNotificationFlag  ).toBe(true);
        });
        
    })
});
