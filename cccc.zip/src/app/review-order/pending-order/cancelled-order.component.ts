import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { User } from '../../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStore } from '../../common/models/appstore.model';
import { AppStateService } from '../../common/service/app-state.service';
import { Observable } from 'rxjs/Observable';
import { Logger } from '../../common/logging/default-log.service';
import { PendingOrderService } from '../../common/service/pending-order.service';
import { HelperService } from '../../common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
@Component({
    selector: 'cancelled-order',
    styleUrls: ['../review-order-component/review-order.component.scss'],
    templateUrl: './cancelled-order.component.html'
})

export class CancelledOrderComponent implements OnInit, OnDestroy {
    public hideEqp: boolean = false;
    public user;
    public userSubscription: Subscription;
    public currentPath: string;
    public cancelorderObservable: Observable<any>;
    public cancelOrderSubscription: Subscription;
    public depositSubscription: Subscription;
    private existingProducts: Observable<any>;
    public customerOrderTypePendingDisconnect: boolean = false;
    public existingProductsSubscription: Subscription;
    public returnDate: any;
    public depositAmount: any;
    public exisitngProduct: any;
    public showDeposit: boolean = false;
    public addressCity: string;
    public addressStreet: string = '';
    public serviceAddress: any;
    public isPrepaid: boolean = false;
    public prepaidAmount: any;
    constructor(
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private pendingOrderService: PendingOrderService,
        private logger: Logger,
        public helperService: HelperService,
        public ctlHelperService: CTLHelperService
    ) {
        this.appStateService.setLocationURLs();
        this.existingProducts = <Observable<any>>store.select('existingProducts');
        this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
            this.exisitngProduct = data;
            if (data && data.existingProductsAndServices) {
                data.existingProductsAndServices.map((existingItems) => {
                    existingItems.pendingOrders && existingItems.pendingOrders.map((pendingOrders) => {
                        if (pendingOrders && pendingOrders.orderReference.customerOrderStatus === 'PENDING') {
                            if (pendingOrders.orderReference.customerOrderType === 'DISCONNECT') {
                                this.customerOrderTypePendingDisconnect = true;
                            }
                        }
                    })
                })
            }
        });
        this.user = <Observable<User>>store.select('user');

        this.userSubscription = this.user.subscribe((data) => {
            if (data.currentUrl !== null && data.currentUrl !== undefined) {
                this.currentPath = data.currentUrl;
                if (data && data.finalAddress && data.finalAddress.addressLine) {
                    this.addressCity = data.finalAddress.addressLine;
                }
            }
            if (data && data.depositAddress) {
                this.serviceAddress = data.depositAddress;
                if (this.serviceAddress) {
                    if (this.serviceAddress.streetAddress && this.serviceAddress.streetAddress !== '') {
                        this.addressCity = this.serviceAddress.streetAddress;
                    } else {
                        this.addressCity = this.serviceAddress.streetNrFirst + ' ' + this.serviceAddress.streetName;
                    }
                    if (this.serviceAddress.locality && this.serviceAddress.locality !== '') {
                        this.addressStreet = this.serviceAddress.locality;
                    } else {
                        this.addressStreet = this.serviceAddress.city ? this.serviceAddress.city : this.addressStreet;
                    }
                    if (this.serviceAddress.stateOrProvince && this.serviceAddress.stateOrProvince !== '') {
                        this.addressStreet = this.addressStreet + ',' + this.serviceAddress.stateOrProvince;
                    }
                    if (this.serviceAddress.postCode && this.serviceAddress.postCode !== '') {
                        this.addressStreet = this.addressStreet + ',' + this.serviceAddress.postCode;
                    }
                }
            }
        });

        this.cancelorderObservable = this.store.select('pending');
        this.cancelOrderSubscription = this.cancelorderObservable.subscribe((data) => {
            
            if (data.payload && data.payload.equipmentReturn && data.payload.equipmentReturn[0]) {
                this.returnDate = data.payload.equipmentReturn[0].equipmentReturnDate;
            }
            if (data && data.orderDocument && data.orderDocument !== undefined && data.orderDocument.productConfiguration && data.orderDocument.productConfiguration !== undefined && data.orderDocument.productConfiguration.length > 0 && data.orderDocument.productConfiguration[0].productType === "VOICE-HP" && data.orderDocument.productConfiguration.length === 1) {
                this.hideEqp = true;
            } else {
                this.hideEqp = false;
            }

            if (data.deposit) {
                this.depositSubscription = this.pendingOrderService.depositRelated$.subscribe((data) => {
                    this.depositAmount = data;
                });
                this.showDeposit = true;
            }
            data && data.orderDocument && data.orderDocument.accountInfo && data.orderDocument.accountInfo.billingType && data.orderDocument.accountInfo.billingType === 'PREPAID'? this.isPrepaid = true : this.isPrepaid = false;
            if(this.isPrepaid){
                this.prepaidAmount = data.orderDocument.creditReview.paymentInfo[0].paidAmount;
            }
        });
    }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderCancelledOrderPage');
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
    }

}
