import { ReviewOrderService } from './../../common/service/review-order.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { PoReviewOrderComponent } from './po-review-order.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { ReviewOrderHelperService } from 'app/review-order/services/reviewOrderHelper.service';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: PoReviewOrderComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        // ModalModule,
        AccordionModule.forRoot(),
    ],
    exports: [
        PoReviewOrderComponent,
    ],
    declarations: [
        PoReviewOrderComponent,
    ],
    providers: [ReviewOrderService, ReviewOrderHelperService], //, DisconnectService
})
export class POReviewOrderModule { }
