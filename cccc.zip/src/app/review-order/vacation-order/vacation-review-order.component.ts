import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DialogComponent } from '../../common/popup/dialog.component';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { EnterpriseAddress } from './../../common/models/cart.model';
import {
    Order, OrderSummary,
    Payment, BillEstimate, Month,
    OrderRq, OrderNotes, ReviewProductInformation, AdditionalInfo, OrderRemarks
} from './../../common/models/order.model';
import { AccountInfo } from '../../common/models/account.model';
import { AppStore } from '../../common/models/appstore.model';
import { Store } from '@ngrx/store';
import { AppStateService } from './../../common/service/app-state.service';
import { SystemErrorService } from '../../common/service/system-error.service';
import { User } from '../../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../../common/logging/default-log.service';
import { GenericValues, APIErrorLists } from '../../common/models/common.model';
import { AppointmentShipping } from '../../common/models/schedule-shipping.model';
import { Validations } from '../../common/validations/validations';
import { HelperService } from '../../common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { ReviewOrderVariables } from 'app/common/models/review.order.model';
import { VacationEnums } from 'app/common/enums/vacationEnums';
import "rxjs/add/operator/catch";

@Component({
    selector: 'vacation-review-order',
    styleUrls: ['../review-order-component/review-order.component.scss'],
    templateUrl: './vacation-review-order.component.html'
})

export class VacationReviewOrderComponent implements OnInit, OnDestroy {
    public legacyProvider: any;
    public allday: any;
    public selfInstallSel: boolean;
    public directvEnableed: boolean = false;
    public lifelineDhpAdded: boolean = false;
    public lifelinePotsAdded: boolean = false;
    public lifelineInternetAdded: boolean = false;
    public internetAddedLifeLine: boolean = false;
    public internetLifeline: any;
    public reviewed: boolean;
    public directv: boolean = false;
    public PaymentErrMsg: boolean; //Submit button restriction
    public creditCheckObj: any; //Submit button restriction
    public paymentDone: boolean = false;             //  US239840
    public orderDetails: any;                            // store
    public user: Observable<User>;
    public orderObject: Order;                       // Parent Object
    public orderSummary: OrderSummary;               // OrderSummary Object
    public accountInfo: AccountInfo;                 // AccountInfo Object
    public payment: Payment; 
    public contactNumber ='';                        // Payment Object
    public billEstimate: BillEstimate;               // BillEstimate Object
    public shippingAddress: EnterpriseAddress;       // ShippingAddress Object
    public serviceAddress: EnterpriseAddress;        // serviceAddress Object
    public billingAddress: EnterpriseAddress;        // billingAddress object
    public apiResponseError: APIErrorLists;
    public additionalInfo: AdditionalInfo;
    public billingOptions: string[] = [];
    public marketingPreferences: string[] = [];
    public emailNotifications: any;
    public smsNotifications: any;
    public productType: any;
    public vacationrestoreObservable: Observable<any>;
    public emailNotExist: boolean = false;
    public premisesInfo: string[] = [];
    public returnPrice: number;
    public disableNotification: boolean;
    public shippingName: string;
    public additioanalNotes: any = {
        text: ''
    };
    public pricingConfirmation: string = '';
    public billMonths: any[] = [];
    public billCharges: any[] = [];
    public currentMonthNo: string;
    public RCBillSummary: any;
    public OTCBillSummary: any;
    public isRCProrated: boolean;
    public isOTCProrated: boolean;
    public confirmOrder: any;
    public userSubscription: Subscription;
    public retainVal: Observable<any>;
    public productSelected: Subscription;
    public currentPath: string;
    public submitOrderObservable: any;
    public submitOrderSubscription: Subscription;
    private appointment: Observable<AppointmentShipping>;
    public orderSubscription: Subscription;
    public summaryTotal: number;
    public accountDetailsCollapsed: boolean = false;
    public currentTab: string = 'tab0';
    public isDTV: boolean = false;
    public productInformation: ReviewProductInformation = {
        terms: '',
        offerName: '',
        isAutopay: false,
        internetExpiry: '',
        prismExpiry: '',
        autopayRate: -1,
        etf: 0
    };
    public orderRefNumber: string;
    public processInstanceId: string;
    public taskId: string;
    public taskName: string;
    public checkNotificationlink: boolean = true;
    public checkNotificationCheckbox: boolean = false;
    public checkOrderConfirmation: boolean;
    public billTask = {
        taskName: 'billEstimate'
    };
    public errorMsg: string;
    public loading: boolean = false;
    public returnDate: any;
    public returnEquipmentData: any;
    public removedPrismPrice: number;
    public cartObservable: any;
    public cartSubscription: Subscription;
    public apptObservable: any;
    public apptSubscription: Subscription;
    public cartDetails: any;
    public prodConf;
    public existingDTVAccountId;
    public finalVACCart: any;
    public vacationObservable: Observable<any>;
    public vacationSubscription: Subscription;
    public servicesSuspended = {
        internet: {
            IsHSIVacationAdded: false,
            suspended: []
        },
        pots: {
            IsPOTS419AQAdded: false,
            IsPOTSSuspended: false,
            suspended: []
        },
        dtv: {
            isDTV: false
        }
    };
    public servicesRestored = {
        internet: {
            IsHSIRestoreAdded: false,
            restored: []
        },
        pots: {
            IsPOTS419AQAdded: false,
            IsPOTSRestored: false,
            restored: []
        },
        dtv: {
            isDTV: false
        }
    };
    public savedQuoteId: any;
    public quote: any;
    public requestedTN: any;
    public requestedTelephoneNumber: any;
    public schedulingURL: string = '';
    public productNameFromCart: any;
    public emailPlaceHolder: string = 'Not provided';
    public emailAddress: string;
    public isEmailValid: boolean;
    public isValidMail: any;
    public emailValidChecked: boolean;
    public phoneReservedObject: any;
    public potsExists: boolean = false;
    public isRCCacknowledged: any;
    public rccDone: boolean = false;

    @ViewChild('simplePort', { static: false,}) public simplePortDialog: DialogComponent;
    public emailAdd: string;
    public vacationrevieworderresponse: any;
    public vacRevOrderRefNumber: any;
    public vacRevTaskId: any;
    public vacRevTaskName: any;
    public vacRevProcessInstanceId: any;
    public hideRcc: boolean = false;
    public dtvproduct: any;
    public dtvpresent: boolean;
    public dealerId: string;
    public dealerName: string;
    public isMultipleDealerCode: boolean;
    public productDealerCodeInfo: any[] = [];
    public prodDealerCodeResponse: any;
    @ViewChild('changeSalesId', { static: false,}) public changeSalesId: DialogComponent;
    public dealerCodeChanged = false;
    public firstTimeLoad: boolean; 
    private accountObservable: Observable<any>;
    public emailValidAddress: any;
    public isVacRes: boolean;
    public isVacSus: boolean;
    public reviewOrderVariables: ReviewOrderVariables;
    public agentFirstName: string;
    public agentLastName: string;
    constructor(
        private logger: Logger,
        private reviewOrderService: ReviewOrderService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private router: Router,
        public ctlHelperService: CTLHelperService,
        public helperService: HelperService,
        public reviewOrderHelperService: ReviewOrderHelperService
    ) {
        this.reviewOrderVariables = this.reviewOrderHelperService.setReviewOrderVablesDefault(this.reviewOrderVariables);
        this.appStateService.setLocationURLs();
        this.accountObservable = <Observable<any>>store.select('account');
        this.accountObservable.subscribe((respData) => {
            if(respData && respData !== undefined && respData.payload && respData.payload !== undefined && respData.payload.paperlessInfo && respData.payload.paperlessInfo !== undefined && respData.payload.paperlessInfo.paperlessBilling && respData.payload.paperlessInfo.paperlessBilling !== undefined){
                this.emailValidAddress = respData.payload.paperlessInfo.paperlessBilling;
            }
        });
        this.user = <Observable<User>>store.select('user');
        this.retainVal = <Observable<any>>store.select('retain')
        this.retainVal.subscribe((val) => {
            if (val && val.account && val.account.payload && val.account.payload !== undefined && val.account.payload.productConfiguration && val.account.payload.productConfiguration !== undefined && val.account.payload.productConfiguration[0].configItems !== undefined && val.account.payload.productConfiguration[0].configItems.length !== 0) {
                this.productSelected = val.account.payload.productConfiguration[0].configItems[0].productName
            }
            
        });
      
        this.vacationObservable = <Observable<any>>store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            data && data.finalVACCart && data.finalVACCart.customerOrderItems && data.finalVACCart.customerOrderItems.map(item => {
                if (item && item.offerName && item.offerName.toUpperCase() === VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase()) {
                    this.servicesSuspended.internet.IsHSIVacationAdded = true;
                }
                if (item && item.offerCategory && item.offerCategory.toUpperCase() === 'VOICE-HP' && item.action === 'VACSUS-REMOVE') {
                    this.servicesSuspended.pots.IsPOTSSuspended = true;
                }
            });
            if (data && data.vacReferralNumber) {
                this.requestedTelephoneNumber = data.vacReferralNumber;
            }
            if(data && data.reservedCbr && data.reservedCbr !== null && data.reservedCbr !== undefined) {
                this.contactNumber= data.reservedCbr
            }
            data && data.vacResCart && data.vacResCart.payload && data.vacResCart.payload.cart && data.vacResCart.payload.cart.customerOrderItems && data.vacResCart.payload.cart.customerOrderItems.map(item => {
                if (item && item.offerName && item.offerName.toUpperCase() === VacationEnums.HSI_VAC_SUS_OFFER_NAME.toUpperCase() && item.action === 'VACRES-REMOVE') {
                    this.servicesRestored.internet.IsHSIRestoreAdded = true;
                }
                if (item && item.offerCategory && item.offerCategory.toUpperCase() === 'VOICE-HP' && item.action === 'VACRES-REMOVE') {
                    this.servicesRestored.pots.IsPOTSRestored = true;
                }
            });
            if (data && data.vacReferralNumber) {
                this.requestedTelephoneNumber = data.vacReferralNumber;
            }
        });
        this.appointment = this.store.select('appointment');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointment.subscribe((data) => {
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    if (data.reservedCbr && data.reservedCbr !== null && data.reservedCbr !== undefined) {
                        this.contactNumber = data.reservedCbr
                    }
                }
            });
        }
        this.isEmailValid = true;
        this.productNameFromCart = this.reviewOrderService.fetchPrimaryProductName();
        this.userSubscription = this.user.subscribe((data) => {
            this.shippingName = data.shippingName;
            if (data.currentUrl !== null && data.currentUrl !== undefined) {
                this.currentPath = data.currentUrl;
            }
        });
        this.user = <Observable<User>>store.select('creditReview');
        this.userSubscription = this.user.subscribe((data) => {
            this.creditCheckObj = data;
        });

        if (this.currentPath === '/vacation-order-confirmation') {
            this.hideRcc = true;
            this.submitOrderObservable = <Observable<any>>store.select('order');
            this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
                this.confirmOrder = data;
                this.accountDetailsCollapsed = true;
                if (data && data.payload) {
                    this.savedQuoteId = data.payload.billEstimate.quote && data.payload.billEstimate.quote.length > 0 ? data.payload.billEstimate.quote[0].quoteId : '';
                    this.getOrderDetails(data);
                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
                }
            });
        } else {
            this.firstTimeLoad = true;
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data.payload.billEstimate) {
                    this.savedQuoteId = data.payload.billEstimate.quote && data.payload.billEstimate.quote.length > 0 ? data.payload.billEstimate.quote[0].quoteId : '';
                    this.getOrderDetails(data);
                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
                }
                this.orderRefNumber = data.orderRefNumber;
                if(data.productSalesIdInfo === undefined) {
                    this.getProductDealerCodeInfo(false);
                } else {
                    if(data && data !== undefined && data.productSalesIdInfo && data.productSalesIdInfo !== undefined && data.productSalesIdInfo.productDealerCodeInfo &&  data.productSalesIdInfo.productDealerCodeInfo !== undefined){
                        this.productDealerCodeInfo = data.productSalesIdInfo.productDealerCodeInfo;
                    }
                    if(data && data !== undefined && data.productSalesIdInfo && data.productSalesIdInfo !== undefined && data.productSalesIdInfo.isMultipleDealerCode &&  data.productSalesIdInfo.isMultipleDealerCode !== undefined){
                        this.isMultipleDealerCode = data.productSalesIdInfo.isMultipleDealerCode;
                    }
                    if(data && data !== undefined && data.productSalesIdInfo && data.productSalesIdInfo !== undefined && data.productSalesIdInfo.dealerCodeChanged &&  data.productSalesIdInfo.dealerCodeChanged !== undefined){
                        this.dealerCodeChanged = data.productSalesIdInfo.dealerCodeChanged;
                    }
                    if(!this.isMultipleDealerCode && this.productDealerCodeInfo && this.productDealerCodeInfo[0]) {
                        if(this.productDealerCodeInfo[0] && this.productDealerCodeInfo[0] !== undefined && this.productDealerCodeInfo[0].dealerCode && this.productDealerCodeInfo[0].dealerCode !== undefined){
                            this.dealerId = this.productDealerCodeInfo[0].dealerCode;
                        }
                        if(this.productDealerCodeInfo[0] && this.productDealerCodeInfo[0] !== undefined){
                            this.dealerName = this.productDealerCodeInfo[0].firstName + ' ' + this.productDealerCodeInfo[0].lastName; 
                        }
                    }
                    if(this.firstTimeLoad) {
                        this.getProductDealerCodeInfo(false);
                    }
                }
            });
        }
        if (this.currentPath === '/vacation-order-confirmation' || this.currentPath === '/vacation-reiew-order') {
            this.orderDetails = <Observable<any>>store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                if (data && data.payload && data.payload.accountInfo && data.payload.accountInfo.contact && data.payload.accountInfo.contact.emailAddress) {
                    this.emailAdd = data.payload.accountInfo.contact.emailAddress;
                }
            });
        }
        this.cartObservable = <Observable<any>>store.select('customize');
        this.cartSubscription = this.cartObservable.subscribe((data) => {
            if (data && data.payload && data.payload.cart !== null && data.payload.cart !== undefined && data.payload.cart.customerOrderItems !== undefined) {
                this.cartDetails = data.payload.cart.customerOrderItems;
                this.prodConf = data.payload.existingProductConfiguration;
                if (this.prodConf && this.prodConf.length > 0) {
                    this.prodConf.map(struct => {
                        if (struct.productType === GenericValues.cDTV) {
                            struct.configItems.map(confItem => {
                                confItem.configDetails.map(confDet => {
                                    confDet.formItems.map(formItem => {
                                        if (formItem.attributeName === 'DIRECTV Account ID') {
                                            this.existingDTVAccountId = formItem.attributeValue[0].value;
                                        }
                                    })
                                });
                            });
                        }
                    });
                }


            }
        });
        this.productNameFromCart = this.reviewOrderService.fetchPrimaryProductName();
        this.cartObservable = <Observable<any>>store.select('customize');
        this.cartSubscription = this.cartObservable.subscribe((data) => {
            if (data && data.payload && data.payload.cart !== null && data.payload.cart !== undefined && data.payload.cart.customerOrderItems !== undefined) {
                data.payload.cart.customerOrderItems.map(orderItem => {
                    if (orderItem.offerCategory === GenericValues.cDTV) {
                        this.directv = true;
                    }
                })

            }
        });

        let allDayRetainDat = <Observable<any>>this.store.select('retain');
        allDayRetainDat.subscribe((respData) => {
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.startDateTime && respData.selectedappointment.timeSlot.startDateTime !== undefined) {
                this.allday = respData.selectedappointment.allDayAppt;
            }

        });
    }

    public maskTelephone(number: string) {
        if (number && number.indexOf('-') === -1) {
            return number.substr(0, 3) + '-' + number.substr(3, 3) + '-' + number.substr(6);
        }
        else if (number) {
            return number;
        }
    }

    public ngOnInit() {
        let pageName;
        if (this.currentPath === '/vacation-order-confirmation') {
            pageName = 'OrderConfirmationVacationSuspendOrderPage';
        }
        else {
            pageName = 'ReviewOrderVacationSuspendReviewOrderPage';
        }
        this.logger.metrics(pageName);

        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            if (data && data.vacFlowName) {
                if (data.vacFlowName.isVacResFlow) this.isVacRes= true;
                else this.isVacRes= false;
                if(data.vacFlowName.isVacSusFlow) this.isVacSus = true;
                else this.isVacSus = false;
            }
            if(data && data !== undefined && data.existsProducts && data.existsProducts[1] !== undefined){
                this.dtvproduct = data.existsProducts[1];
                }
                if(this.dtvproduct === "VIDEO-DTV"){
                    this.dtvpresent = true;
                }
            this.vacationrevieworderresponse = data.vacationrevieworderresponse;
            if (data && data.vacationrevieworderresponse && data.vacationrevieworderresponse.orderRefNumber) {
                this.vacRevOrderRefNumber = data.vacationrevieworderresponse.orderRefNumber;
            }
            if (data && data.vacationrevieworderresponse && data.vacationrevieworderresponse.taskId) {
                this.vacRevTaskId = data.vacationrevieworderresponse.taskId;
            }
            if (data && data.vacationrevieworderresponse && data.vacationrevieworderresponse.taskName) {
                this.vacRevTaskName = data.vacationrevieworderresponse.taskName;
            }
            if (data && data.vacationrevieworderresponse && data.vacationrevieworderresponse.processInstanceId) {
                this.vacRevProcessInstanceId = data.vacationrevieworderresponse.processInstanceId;
            }
        });

        this.user = <Observable<User>>this.store.select('user');
        this.userSubscription = this.user.subscribe((userdata) => {
            if (userdata && userdata.selfinstallselected !== undefined && userdata.selfinstallselected === true) {
                this.selfInstallSel = userdata.selfinstallselected;
            } else {
                this.selfInstallSel = false;
            }
            if(userdata.autoLogin && userdata.autoLogin.oamData && userdata.autoLogin.oamData.agentFirstName && userdata.autoLogin.oamData.agentLastName)
            {
                this.agentFirstName = userdata.autoLogin.oamData.agentFirstName;
                this.agentLastName = userdata.autoLogin.oamData.agentLastName;
            }
        });
        this.submitOrderObservable = <Observable<any>>this.store.select('order');
        this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
        });
        this.paymentDone = true;
        this.reviewed = true;
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.submitOrderSubscription !== undefined) {
            this.submitOrderSubscription.unsubscribe();
        }
        if (this.cartSubscription !== undefined) {
            this.cartSubscription.unsubscribe();
        }
        if (this.apptSubscription !== undefined) {
            this.apptSubscription.unsubscribe();
        }
        if (this.vacationSubscription !== undefined) {
            this.vacationSubscription.unsubscribe();
        }
    }

    /**
     * To set the clicked pricing Tab active & update respective tab summary amount
     * @param tab as string
     * @param month which describe prices for particular month
     */
    public setActive(tab: string, month: Month) {
        this.currentTab = tab;
        this.billCharges = month.charges;
        this.currentMonthNo = month.monthId;
        this.RCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };

        this.OTCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };

        for (let k in this.billCharges) {
            if (this.billCharges[k].chargeType === 'RC') {
                this.RCBillSummary = this.billCharges[k].summary;
                break;
            }
        }
        for (let k in this.billCharges) {
            if (this.billCharges[k].chargeType === 'OTC') {
                this.OTCBillSummary = this.billCharges[k].summary;
                break;
            }
        }

        this.summaryTotal =
            (this.RCBillSummary.totalBillAmount +
                this.OTCBillSummary.totalBillAmount +
                this.RCBillSummary.totalTaxes +
                this.OTCBillSummary.totalTaxes) -
            (this.RCBillSummary.totalDiscount +
                this.OTCBillSummary.totalDiscount);
    }

    /**
     * To check/set the diable notification checkbox boolean
     */
    public checkNotification() {
        this.checkNotificationlink = false;
        this.checkNotificationCheckbox = true;
    }

    /**
     * To validate pricing details checked & deposits if required taken
     */
    public checkOrder() {
        if (this.reviewOrderVariables.rccDone) {
            this.submitOrder(this.isRCCacknowledged,
                this.additioanalNotes.text, this.disableNotification, this.orderObject);
        } else {
            this.checkOrderConfirmation = true;
        }
    }

    /* public AcknowledgeRCCs() {
        this.rccDone = true;
        if (this.rccDone) {
            this.isRCCacknowledged = "Yes";
        } else {
            this.isRCCacknowledged = "No";
        }
    } */

    /**
     * To scroll upto the Pricing block if not acknowledged
     * @param element as clicked pricing check dom element
     */
    public checkPricingAck(element) {
        window.scrollTo(0, document.getElementById(element).offsetTop - 140);
    }

    /**
     * To summary of bill for a month
     * @param charges for a month
     */
    public getTabSummaryTotal(charges) {
        let totalBill = 0;
        let totalDiscounts = 0;
        let totalTaxes = 0;
        charges.map((charge) => {
            if (Object.keys(charge.summary).length > 0) {
                totalBill += charge.summary['totalBillAmount'];
                totalDiscounts += charge.summary['totalDiscount'];
                totalTaxes += charge.summary['totalTaxes'];
            }
        });
        return totalBill + totalTaxes - totalDiscounts;
    }

    /**
     * To get higher level product totalfrom individual amounts from API
     * @param product
     */
    public getProductTotal(product): number {
        let primaryProductAmount: number = 0;
        let additionalSevicesAmount: number = 0;
        let totalDiscounts: number = 0;
        let totalTaxes: number = 0;

        let primaryService = product.primaryService;
        primaryService.map((k) => {
            if (k.billAmount && k.billAmount > 0) {
                primaryProductAmount += k.billAmount;
            }
            if (k.discountAmount) {
                totalDiscounts += k.discountAmount;
            }
            if (k.taxes && Object.keys(k.taxes).length > 0) {
                totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
            }
        });

        let additionalService = product.additionalServices;
        additionalService.map((k) => {
            if (k.billAmount && k.billAmount > 0) {
                additionalSevicesAmount += k.billAmount;
            }
        });

        return primaryProductAmount + additionalSevicesAmount + totalTaxes - totalDiscounts;
    }

    /**
     * To get higher level product OTC totalfrom individual amounts from API
     * @param product
     */
    public getOTCTotal(product) {
        let primaryProductAmount: number = 0;
        let additionalSevicesAmount: number = 0;
        let totalDiscounts: number = 0;
        let totalTaxes: number = 0;
        product.map((p) => {
            let primaryService = p.primaryService;
            primaryService.map((k) => {
                if (k.billAmount && k.billAmount > 0) {
                    primaryProductAmount += k.billAmount;
                }
                if (k.discountAmount) {
                    totalDiscounts += k.discountAmount;
                }
                if (k.taxes && Object.keys(k.taxes).length > 0) {
                    totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
                }
            });
            let additionalService = p.additionalServices;
            additionalService.map((k) => {
                if (k.billAmount && k.billAmount > 0) {
                    additionalSevicesAmount += k.billAmount;
                }
                if (k.discountAmount) {
                    totalDiscounts += k.discountAmount;
                }
                if (k.taxes && Object.keys(k.taxes).length > 0) {
                    totalTaxes += this.reviewOrderService.computedTaxes(k.taxes);
                }
            });
        });

        return primaryProductAmount + additionalSevicesAmount + totalTaxes - totalDiscounts;
    }

    /**
     * To mask phone number as pe USA format (xxx-xx-xxxx)
     * @param data as response
     */
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }

    /**
     * To get order summary response & mapping in UI
     * @param data as response
     */
    public getOrderDetails(data) {

        if (data && data.length === undefined && data !== null && data.payload.orderSummary) {
            this.orderObject = data;
            this.orderSummary = this.orderObject.payload.orderSummary;
            this.accountInfo = this.orderObject.payload.accountInfo;
            this.additionalInfo = this.orderObject.payload.additionalInfo;

            this.serviceAddress = this.orderSummary.serviceAddress;
            this.billingAddress = this.accountInfo.billingAddress;

            let billingReference = this.accountInfo.accountPreferences;
            let billingObject = {
                'Paperless Billing': billingReference && billingReference !== undefined && billingReference.paperlessBilling,
                'Spanish Bill Print': billingReference && billingReference !== undefined && billingReference.spanishBillPrint,
                'Large Print': billingReference && billingReference !== undefined && billingReference.largePrint,
                'Braille': billingReference && billingReference !== undefined && billingReference.braille
            };
            this.billingOptions = billingReference ?
                this.reviewOrderService.returnOptions(billingObject) : [];

            let marketingObject = {
                'No Telemarketing': billingReference && billingReference !== undefined && billingReference.noTeleMarketing,
                'No Direct Mail': billingReference && billingReference !== undefined && billingReference.noDirectMail,
                'No Email': billingReference && billingReference !== undefined && billingReference.noEmail
            };
            this.marketingPreferences = billingReference ?
                this.reviewOrderService.returnOptions(marketingObject) : [];

            let emailReference = this.accountInfo.accountPreferences.emailNotification;
            let emailNotifyObject = {
                'Billing Events': emailReference && emailReference !== undefined && emailReference.billingNotification,
                'Ordering Events': emailReference && emailReference !== undefined && emailReference.orderingNotification,
                'Repair Events': emailReference && emailReference !== undefined && emailReference.repairNotification
            };

            if (emailReference) {

                if (this.reviewOrderService.checkExist(emailNotifyObject, true)) {
                    this.emailNotifications = 'All';
                } else if (this.reviewOrderService.checkExist(emailNotifyObject, false)) {
                    this.emailNotifications = 'None';
                } else {
                    this.emailNotifications =
                        this.reviewOrderService.returnOptions(emailNotifyObject);
                }
            }

            let smsReference = this.accountInfo.accountPreferences.textNotification;
            let smsNotifyObject = {
                'Billing Events': smsReference && smsReference !== undefined && smsReference.billingNotification,
                'Ordering Events': smsReference && smsReference !== undefined && smsReference.orderingNotification,
                'Repair Events': smsReference && smsReference !== undefined && smsReference.repairNotification
            };

            if (smsReference) {
                if (this.reviewOrderService.checkExist(smsNotifyObject, true)) {
                    this.smsNotifications = 'All';
                } else if (this.reviewOrderService.checkExist(smsNotifyObject, false)) {
                    this.smsNotifications = 'None';
                } else {
                    this.smsNotifications = this.reviewOrderService.returnOptions(smsNotifyObject);
                }
            }

            let premiseInfo = this.orderSummary.apptNotes;
            let premiseInfoObject = {
                'Animals Present': premiseInfo && premiseInfo !== undefined && premiseInfo.animalsPresent,
                'Electric Fence': premiseInfo && premiseInfo !== undefined && premiseInfo.electricFence,
                'Locked Gate': premiseInfo && premiseInfo !== undefined && premiseInfo.lockedGate
            };
            this.premisesInfo = premiseInfo ?
                this.reviewOrderService.returnOptions(premiseInfoObject) : [];

            this.disableNotification = this.additionalInfo && this.additionalInfo !== undefined && this.additionalInfo.disableOrderNotification;
        }

    }

    /**
     * submit request from order summary page
     * @param pricingConfirmation as pricing ack
     * @param additionalNotes entered notes
     * @param disableNotifications checkbox checked or not
     * @param order fetching refnumber, taskId
     */
    public submitOrder(pricingConfirmation: string, additionalNotes: string,
        disableNotifications: boolean, order) {
        this.loading = true;
        let chargeSummaryAck: boolean;
        let remark: OrderRemarks;
        chargeSummaryAck = pricingConfirmation && pricingConfirmation === 'Yes' ? true : false;
        let additionalInfo: AdditionalInfo = {
            chargeSummaryAck: chargeSummaryAck,
            disableOrderNotification: false
        }
        remark = {
            name: 'Order Remarks',
            value: additionalNotes,
            date: new DatePipe('en-US').transform(new Date(), 'mediumDate'),
            author: this.agentFirstName + ' ' + this.agentLastName
        }
        let dealerCodeChangeInfo = [];
        this.productDealerCodeInfo.forEach(prod => {
            if(prod.changed) {
                let prodInfo = {
                    offerCategory: prod.offerCategory,
                    productType: prod.productType,
                    productname: prod.productname,
                    dealerCode: prod.dealerCode,
                    firstName: prod.firstName,
                    lastName: prod.lastName
                }
                dealerCodeChangeInfo.push(prodInfo);
            }
        });

        let payload: OrderNotes = {
            additionalInfo: additionalInfo,
            orderRemarks: [remark],
            dealerCodeChangeInfo: dealerCodeChangeInfo
        }

        let request: OrderRq = {
            orderRefNumber: this.vacRevOrderRefNumber,
            processInstanceId: this.vacRevProcessInstanceId,
            taskId: this.vacRevTaskId,
            taskName: this.vacRevTaskName,
            payload
        };
        if(request.payload.orderRemarks[0].value === '')
        {
               delete request.payload.orderRemarks;
            
        }
        let existingObservable = <Observable<any>>this.store.select('existingProducts');
        existingObservable.subscribe((data) => {
            if(data && data.existingProductsAndServices &&data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].serviceAddress.locationAttributes){
                this.legacyProvider = data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;               
            }
     });
        this.store.dispatch({ type: 'CONFIRM_ORDER', payload: payload });
        this.logger.startTime();
        this.logger.log("info", "vacation-review-order.component.ts", "postSubmitOrderRequest", JSON.stringify(request));  
        let errorResolved = false;
        this.reviewOrderService.postVacationSubmitTaskService(request)
            .catch((error: any) => {
                this.logger.endTime();
                if (this.isVacRes) {
                    this.logger.log("info", "vacationRestore-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                    this.logger.log("info", "vacationRestore-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                } else {
                    this.logger.log("info", "vacationSuspend-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                    this.logger.log("info", "vacationSuspend-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "submitTask - postSubmitOrder", "vacation-review-order.component.ts",
                    "Review Order Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.endTotalTime();                    
                    if (this.isVacRes) {
                        this.logger.log("info", "vacationRestore-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data), this.legacyProvider);
                        this.logger.log("info", "vacationRestore-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "vacationRestore-review-order.component.ts", "orderCompletedVacRes", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    } else {
                        this.logger.log("info", "vacationSuspend-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(data),this.legacyProvider);
                        this.logger.log("info", "vacationSuspend-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "vacationSuspend-review-order.component.ts", "orderCompletedVacSus", '{"elapsedTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    }
                    if (data && data.errorResponse && data.errorResponse[0] !== undefined && data.errorResponse[0].reasonCode && data.errorResponse[0].reasonCode !== undefined && (data.errorResponse[0].reasonCode === 'SIMPLE_PORT_FAILURE' || data.errorResponse[0].reasonCode === 'SIMPLE_PORT_SCHEDULING_FAILURE')) {
                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                        this.loading = false;
                        this.simplePortDialog.open();
                    }
                    else {
                        if (data.payload && data.payload.paymentDetails && data.payload.paymentDetails.finalBillPaymentStatus && data.payload.paymentDetails.finalBillPaymentStatus.depositPaymentStatus === "UNPAID") {
                            this.paymentDone = true;
                        }
                        this.confirmOrder = data;
                        if (order && order !== undefined && order.payload && order.payload !== undefined && order.payload.orderRemarks && order.payload.orderRemarks !== undefined) {
                            order.payload.orderRemarks = remark;
                        }
                        let submitData = Object.assign({}, order, this.confirmOrder.payload);
                        this.store.dispatch({ type: 'SUBMITTED_ORDER', payload: submitData });
                        this.router.navigate(['/vacation-order-confirmation']);
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        if (this.isVacRes) {
                            this.logger.log("info", "vacationRestore-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                            this.logger.log("info", "vacationRestore-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        } else {
                            this.logger.log("info", "vacationSuspend-review-order.component.ts", "postSubmitOrderResponse", JSON.stringify(error));
                            this.logger.log("info", "vacationSuspend-review-order.component.ts", "postSubmitOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }

                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task -  Review Order", "vacation-review-order.component.ts", "Review Order Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Review Order Page", "vacation-review-order.component.ts", "Review Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });

    }

    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    public handleCancelClick(event) {
        this.router.navigate(['/existing-products']);
    }


    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }

    public notificationValidation() {
        if (this.emailNotExist) {
            this.emailAddress = '';
            this.emailPlaceHolder = 'Not provided';
        }
        else {
            this.emailPlaceHolder = '';
        }
        this.emailAddress ? this.isValidMail = Validations.emailValidator({ value: this.emailAddress }) : this.isValidMail = null;
        this.isValidMail === null ? this.isEmailValid = true : this.isEmailValid = false;
        this.emailAddress && this.isValidMail === null ? this.emailValidChecked = false : this.emailValidChecked = true;

    }

    public changeSalesIdDialog() {
        if(this.productDealerCodeInfo === undefined || this.productDealerCodeInfo.length === 0) {
            this.getProductDealerCodeInfo(true);
        } else {
            this.productDealerCodeInfo.forEach(prod => prod.changeId = prod.chnageAllowed);
            this.changeSalesId.open();
        }
    }

    private getProductDealerCodeInfo(openDialog: boolean) {
        let request = {
            orderReferenceNumber: this.orderRefNumber,
            salesChannel: 'ESHOp-Customer Care'
        }
        this.loading = true;
        this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoRequest", JSON.stringify(request));
        this.logger.startTime();
        let errorResolved = false;
        this.reviewOrderService.retrieveProductDealerCodeInfo(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoResponse", error);
                this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "retrieveProductDealerCodeInfo", "vacation-review-order.component.ts",
                    "Review Order Page",
                error);
                return Observable.throwError(null);

            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
		            this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoResponse", JSON.stringify(data));
                    this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.prodDealerCodeResponse = data;
                    const prodNameMap = {
                        'INTERNET': {
                            'name':'Internet',
                            'imgUrl': './assets/img/internet_sm.png',
                            'dealerInfo': ''
                        },
                        'VOICE-HP': {
                            'name':'Home Phone',
                            'imgUrl': './assets/img/phone_sm.png',
                            'dealerInfo': ''
                        },
                        'VIDEO-DTV': {
                            'name':'DIRECTV',
                            'imgUrl': './assets/img/tv_sm.png',
                            'dealerInfo': ''
                        },
                        'CENTURYLINK @ EASE': {
                            'dealerInfo': ''
                        }
                    };
                    let previousProdDealerCodeInfo = this.productDealerCodeInfo;
                    /* Retaining previously saved dealer code for reentrant scenario */ 
                    if(previousProdDealerCodeInfo.length > 0) {
                        previousProdDealerCodeInfo.forEach(prodInfo => {
                            if(prodInfo.changed) {
                                if((prodInfo.productname).indexOf('EASE') !== -1) {
                                    prodNameMap[prodInfo.productname].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                } else {
                                    prodNameMap[prodInfo.productType].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                }
                            }
                        });
                    }
                    this.productDealerCodeInfo = [];
                    let dealerCodeArray = [];
                    let displayInternet = false;
                    let displayVoice = false;
                    this.prodDealerCodeResponse.productDealerCodeInfo.map(prodInfo => {
                        if(prodInfo.isDisplay.toUpperCase() === 'YES') {
                            let isEase = ((prodInfo.productname).indexOf('EASE') !== -1);
                            let prodInfoObject = {
                                prodName: isEase ? prodInfo.productname : prodNameMap[prodInfo.productType],
                                firstName: prodInfo.firstName,
                                lastName: prodInfo.lastName,
                                dealerCode: prodInfo.dealerCode,
                                chnageAllowed: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                changeId: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                offerCategory: prodInfo.offerCategory,
                                productType: prodInfo.productType,
                                productname: prodInfo.productname,
                            }
                            if(isEase || prodInfo.productType === 'VIDEO-DTV') {
                                prodInfoObject['display'] = true;
                            }
                            if(!displayInternet && !isEase && prodInfo.productType === 'INTERNET') {
                                prodInfoObject['display'] = true;
                                displayInternet = true;
                            }
                            if(!displayVoice && prodInfo.productType === 'VOICE-HP') {
                                prodInfoObject['display'] = true;
                                displayVoice = true;
                            }
                            if(previousProdDealerCodeInfo.length > 0) { 
                                let priviouslySavedValue = isEase ? prodNameMap[prodInfo.productname].dealerInfo : prodNameMap[prodInfo.productType].dealerInfo;
                                if(priviouslySavedValue !== '') {
                                    prodInfoObject.dealerCode = priviouslySavedValue.dealerCode;
                                    prodInfoObject.firstName = priviouslySavedValue.firstName;
                                    prodInfoObject.lastName = priviouslySavedValue.lastName;
                                    prodInfoObject['changed'] = true;
                                }
                            }
                            dealerCodeArray.push(prodInfoObject.dealerCode);
                            this.productDealerCodeInfo.push(prodInfoObject);
                        }
                    });

                    if(this.firstTimeLoad) {
                        this.isMultipleDealerCode = !dealerCodeArray.every(val => (val === dealerCodeArray[0]));
                    }
                    this.firstTimeLoad = false;
                    if(this.productDealerCodeInfo.length === 0) {
                        this.isMultipleDealerCode = !this.prodDealerCodeResponse.productDealerCodeInfo.every(val => (val.dealerCode === this.prodDealerCodeResponse.productDealerCodeInfo[0].dealerCode));
                        this.dealerId = this.prodDealerCodeResponse.productDealerCodeInfo[0].dealerCode;
                        this.dealerName = this.prodDealerCodeResponse.productDealerCodeInfo[0].firstName + ' ' + this.prodDealerCodeResponse.productDealerCodeInfo[0].lastName;
                    }
                    let payLoad = {
                        productDealerCodeInfo: this.productDealerCodeInfo,
                        isMultipleDealerCode: this.isMultipleDealerCode,
                        dealerCodeChanged: this.dealerCodeChanged
                    }
                    this.store.dispatch({ type: 'PROD_DEALER_ID', payload: payLoad });
                    if(openDialog)
                        this.changeSalesId.open();
                },
                (error) => {
                    let unexpectedError = false;
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "vacation-review-order.component.ts", "productDealerCodeInfoResponse", error);
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "vacation-review-order.component.ts", "Order Summary Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "vacation-review-order.component.ts", "Order Summary Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
            });
    }
}
