import { ReviewOrderService } from './../../common/service/review-order.service';
import { Component, OnInit, OnDestroy, Input, ViewChild, EventEmitter, Output } from '@angular/core';
import { APIErrorLists } from '../../common/models/common.model';
import { Observable } from 'rxjs/Observable';
import { Logger } from '../../common/logging/default-log.service';
import { SystemErrorService } from "app/common/service/system-error.service";
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStore } from 'app/common/models/appstore.model';
import { Store } from '@ngrx/store';
import { User } from 'app/common/models/user.model';
import "rxjs/add/operator/catch";
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';

interface billQuoteResponce {
    genericResponse: { href: string, code: string, responseMessage: string },
    href: string,
    quoteArr: [any]
}

@Component({
    selector: 'bill-estimate',
    styleUrls: ['../review-order-component/review-order.component.scss'],
    templateUrl: './bill-estimate.component.html'
})

export class BillEstimateComponent implements OnInit, OnDestroy {
    public isPaperlessBillingNotApplied: boolean = false;
    public accountSubscription: any;
    public accountObservable: Observable<any>;
    public billEstimate;
    public billMonths: any;
    public errorMsg: string;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public proRatedTotal: number;
    public proRatedTaxesTotal: number;
    public billQuote: any;
    public monthlyChargesTotal: number;
    public monthlyChargeTaxesTotal: number;
    public oneTimeChargesTotal: number;
    public otherChargesCredits: number;
    public otherCharges: boolean = false;
    public finalBillAmount: boolean = false;
    public feesSurchargesTaxesTotal: number;
    public oneTimeChargeTaxesTotal: number;
    public otherChargesCreditsTaxTotal: number;
    public discountTaxesTotal: number;
    public discountExpiryTaxesTotal: number;
    public nextBill: any;
    public discountsTotal: number;
    public discountsProTotal: number;
    public totalProFeesSurchargesAmt: number;
    public discountsExpiring: number;
    public additionalMonthlyChargesTotal: number;
    public monthlyRecurringCharges: any;
    public oneTimeCharges: any;
    public otherTaxesAmount: number;
    public currentTab: string;
    public prepaidCurrentTab:any = "Initial Payment"
    public apiResponseBillError: boolean;
    public apiResponseBillEmpty: boolean;
    public prepaidBillResponseEmpty:boolean = false;
    public finalBillAmt: number;
    public displayText: string;
    public monthBills = {
        currentTabBill: [],
    };
    public prepaidMonthBills = {
        currentTabBillDetails:[],
    };
    public monthBillsAll: any;
    public savedQuoteId: any;
    public counter: number = 1;
    @Input() public billInput;
    @Input() public isDTV: boolean;
    @Input() public dtvFormData;
    @Input() public productinfo: any;
    @Input() public productNameFromCart: string;
    @Input() public fromDisconnect: boolean;
    @Input() public isPrepaid:boolean;
    @Input() public isAmend:boolean;
    @Input() public prepaidData:any;
    public productDetailHeader: any;
    public terms: any = null;
    public etf: any;
    public autopayRate: any;
    public isAutopay: boolean;
    @ViewChild('reviewRccs', { static: false,}) public reviewRccsDialog: DialogComponent;
    public isAcknowledgeContinueClicked: boolean = false;
    public isStillNeedToCompleteRCC: boolean = false;
    private userObservable: any;
    public orderObservable: any;
    private userSubscription: any;
    public orderSubscription: any;
    private orderRefNumber: any;
    public rccDetails: any;
    public monthlyChargeHsiCategory = [];
    public monthlyChargePhoneCategory = [];
    public monthlyChargeDhpCategory = [];
    public monthlyChargeDtvCategory = [];
    public internetCategory = [];
    public cvoipCategory = [];
    public phoneCategory = [];
    public dtvCategory = [];
    public broadbandItem = [];
    public otherhpItem = [];
    public otherdhpItem = [];
    public otherdtvItem = [];
    public proBroadbandItem = [];
    public proVoiceHpItem = [];
    public proVoiceDhpItem = [];
    public proDtvItem = [];
    public proFeesnSurcharges = [];
    public proDiscounts = [];
    public hsiRecurringDiscounts = [];
    public hpRecurringDiscounts = [];
    public dhpRecurringDiscounts = [];
    public dtvRecurringDiscounts = [];
    public hsiRecurringFees = [];
    public hpRecurringFees = [];
    public dhpRecurringFees = [];
    public dtvRecurringFees = [];
    public otcDiscounts = [];
    public ocDiscounts = [];
    public otcFeesSurcharges = [];
    public ocFeesSurcharges = []
    public proBroadbandServc: boolean = false;
    public proVoiceHpServc: boolean = false;
    public proVoiceDhpServc: boolean = false;
    public proDtvServc: boolean = false;
    public broadbandServc: boolean = false;
    public homephoneServc: boolean = false;
    public voicedhpServc: boolean = false;
    public dtvServc: boolean = false;
    public isHsi: boolean = false;
    public isPhone: boolean = false;
    public isCvoip: boolean = false;
    public isDtv: boolean = false;
    public isMonthlyHsi: boolean = false;
    public ismonthlyPhone: boolean = false;
    public ismonthlyDhp: boolean = false;
    public ismonthlyDtv: boolean = false;
    public internetProdId: any;
    public phoneProdId: any;
    public cvoipProdId: any;
    public dtvProdId: any;
    public hsiProdId: any;
    public hpProdId: any;
    public dhpProdId: any;
    public hsiProRatedTotal: number = 0;
    public phoneProRatedTotal: number = 0;
    public cvoipProRatedTotal: number = 0;
    public dtvProRatedTotal: number = 0;
    public internetleadItem: any;
    public internetleadItemAmt: any;
    public cvoipleadItem: any;
    public cvoipleadItemAmt: any;
    public phoneleadItem: any;
    public phoneleadItemAmt: any;
    public dtvleadItem: any;
    public dtvleadItemAmt: any;
    public broadbandTotalAmt: number = 0;
    public voiceServcTotalAmt: number = 0;
    public cvoipTotalAmt: number = 0;
    public dtvTotalAmt: number = 0;
    public monthlyPackBroadbandTotalAmt: number = 0;
    public monthlyPackPhoneTotalAmt: number = 0;
    public monthlyPackDhpTotalAmt: number = 0;
    public monthlyPackDtvTotalAmt: number = 0;
    public proratedTotalTax: number = 0;
    public monthlyChargeHsiTotalTax:number = 0;
    public monthlyChargeHpTotalTax:number = 0;
    public monthlyChargeDhpTotalTax:number = 0;
    public monthlyChargeDtvTotalTax:number = 0;
    public proFederalTax:number = 0;
    public proStateTax:number = 0;
    public proCountyTax:number = 0;
    public proSalesUtilityTax:number = 0;
    public proUsfTax:number = 0;
   
    public mcHsiFederalTax:number = 0;
    public mcHsiStateTax:number = 0;
    public mcHsiCountyTax:number = 0;
    public mcHsiSalesUtilityTax:number = 0;
    public mcHsiUsfTax:number = 0;
    public mcHpFederalTax:number = 0;
    public mcHpStateTax:number = 0;
    public mcHpCountyTax:number = 0;
    public mcHpSalesUtilityTax:number = 0;
    public mcHpUsfTax:number = 0;
    public mcDhpFederalTax:number = 0;
    public mcDhpStateTax:number = 0;
    public mcDhpCountyTax:number = 0;
    public mcDhpSalesUtilityTax:number = 0;
    public mcDhpUsfTax:number = 0;
    public mcDtvFederalTax:number = 0;
    public mcDtvStateTax:number = 0;
    public mcDtvCountyTax:number = 0;
    public mcDtvSalesUtilityTax:number = 0;
    public mcDtvUsfTax:number = 0;
    


    public otcTotalTax:number = 0;
    public otcFederalTax:number = 0;
    public otcStateTax:number = 0;
    public otcCountyTax:number = 0;
    public otcSalesUtilityTax:number = 0;
    public otcUsfTax:number = 0;
    public ocTotalTax:number = 0;
    public ocFederalTax:number = 0;
    public ocStateTax:number = 0;
    public ocCountyTax:number = 0;
    public ocSalesUtilityTax:number = 0;
    public ocUsfTax:number = 0;
    public monthlyChargeHsiLeadItem : any;
    public monthlyChargeHsiLeadItemAmt : number = 0;
    public monthlyChargePhoneLeadItem : any;
    public monthlyChargeDhpLeadItem:any;
    public monthlyChargeDtvLeadItem:any;
    public monthlyChargePhoneLeadItemAmt : number = 0;
    public hsiMonthlyChargeTotal:number = 0;
    public PhoneMonthlyChargeTotal:number = 0;
    public monthlyChargeDhpLeadItemAmt:number = 0;
    public monthlyChargeDtvLeadItemAmt:number = 0;
    public dhpMonthlyChargeTotal:number = 0;
    public dtvMonthlyChargeTotal:number = 0;
    public totalHsiRecurringDiscounts:number = 0;
    public totalHpRecurringDiscounts:number = 0;
    public totalDhpRecurringDiscounts:number = 0;
    public totalDtvRecurringDiscounts:number = 0;
    public totalProratedDiscounts:number = 0;
    public totalOtcDiscounts:number = 0;
    public totalOCDiscounts:number = 0;
    public totalHsiRecurringFeesAmt:number = 0;
    public totalHpRecurringFeesAmt:number = 0;
    public totalDhpRecurringFeesAmt:number = 0;
    public totalDtvRecurringFeesAmt:number = 0;
    public totalProFeesAmt:number = 0;
    public totalOtcFeesAmt:number = 0;
    public totalOCFeesAmt:number = 0;
    public prepaidMonthlyTotalCharge: number = 0;
    public prepaidOtcTotalCharge: number = 0;
    public prepaidDiscountCharge:number = 0;
    public prepaidTaxAmt:number = 0; 
    public prepaidFirstBillAmt:number = 0;
    public prepaidSecondBillAmt:number = 0;
    public taxList:any = [];
    public BillList:any = [];
    public finalPaymentDate;
    private propertyBillQuoteMaxRetries;

    @Output() public isAcknowledged: EventEmitter<any> = new EventEmitter<any>();
    public rccErrorMessage: any;
    public isMACD: boolean = false;
    public firstMonthPrepaidTax: number = 0;
    public firstMonthOTCTax: number = 0;
    constructor(private logger: Logger,
        private reviewOrderService: ReviewOrderService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private store: Store<AppStore>,
        private propertiesHelperService: PropertiesHelperService) {

    }

    public getBillDetails(quoteId) {
        this.loading = true;
            this.logger.log("info", "bill-estimate.component.ts", "getBillQuoteDetailsRequest", JSON.stringify(quoteId));
            this.logger.startTime();
            this.reviewOrderService.getBillQuoteDetails(quoteId)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "bill-estimate.component.ts", "getBillQuoteDetailsErrorResponse", error);
                    this.logger.log("error", "bill-estimate.component.ts", "getBillQuoteDetailsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", 'Not Applicable',
                        "GET BILL QUOTE - getBillQuoteDetails", "bill-estimate.component.ts",
                        "Bill Quote",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (billData) => {
                        this.logger.endTime();
                        this.logger.log("info", "bill-estimate.component.ts", "getBillQuoteDetailsResponse", JSON.stringify(billData));
                        this.logger.log("info", "bill-estimate.component.ts", "getBillQuoteDetailsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.billQuote = billData;
                        this.billSummary(this.billQuote,quoteId);
                        this.apiResponseBillError = false;
                        this.loading = false;
                        this.apiResponseBillEmpty = false;
                        this.billQuote && this.billQuote.quoteArr && this.billQuote.quoteArr[0] &&
                        this.billQuote.quoteArr[0].quoteItemArr.forEach(element => {
                            if ((String(element.blockHeader).search("Monthly Recurring Charges")) !== -1) {
                                if (String(element.blockTitle).search("Package:") !== -1) {
                                    let header: any = element.blockTitle.split(":");
                                    this.productDetailHeader = header[1];
                                }
                            }
                        });
                        let obj: any;
                        this.productinfo ? obj = JSON.parse(this.productinfo) : obj = '';
                        this.etf = obj.etf;
                        this.autopayRate = obj.autopayRate;
                        this.terms = obj.terms;
                        this.isAutopay = obj.isAutopay;
                    },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", "bill-details.component.ts", "getBillQuoteDetailsErrorResponse", error);
                        this.logger.log("error", "bill-details.component.ts", "getBillQuoteDetailsSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        this.apiResponseBillError = true;
                        if (this.ctlHelperService.isJson(error)) {
                            this.logger.log('error', 'review-order.ts', 'BillQuoteResponseError', JSON.parse(error));
                        }
                        window.scroll(0, 0);
                    })
    }

    public setTabActivate(prepaiTabNm) {
        this.prepaidCurrentTab = prepaiTabNm;
        this.prepaidMonthlyTotalCharge = 0;
        this.prepaidOtcTotalCharge = 0;
        this.prepaidDiscountCharge = 0;
        this.prepaidTaxAmt = 0;
        this.firstMonthPrepaidTax = 0;
        this.firstMonthOTCTax = 0;
        this.BillList = [];
        this.taxList = [];
        this.getPrepaidBillAmt(prepaiTabNm);
        this.prepaidMonthBills.currentTabBillDetails = prepaiTabNm;
    }


    public setActivate(tabName: string) {
        this.currentTab = tabName;
        this.apiResponseBillEmpty = false;
        this.proRatedTotal = 0;
        this.proRatedTaxesTotal = 0;
        this.monthlyChargesTotal = 0;
        this.monthlyChargeTaxesTotal = 0;
        this.oneTimeChargesTotal = 0;
        this.oneTimeChargeTaxesTotal = 0;
        this.discountTaxesTotal = 0;
        this.discountExpiryTaxesTotal = 0;
        this.feesSurchargesTaxesTotal = 0;
        this.discountsTotal = 0;
        this.discountsProTotal = 0;
        this.discountsExpiring = 0;
        this.additionalMonthlyChargesTotal = 0;
        this.otherTaxesAmount = 0;
        this.otherChargesCredits = 0;
        this.otherChargesCreditsTaxTotal = 0;
        let amountsDetails = this.getBillAmount(tabName);
        this.proRatedTotal = amountsDetails.proRatedTotal;
        this.proRatedTaxesTotal = amountsDetails.proRatedTaxesTotal;
        this.monthlyChargesTotal = amountsDetails.monthlyChargesTotal;
        this.monthlyChargeTaxesTotal = amountsDetails.monthlyChargeTaxesTotal;
        this.oneTimeChargesTotal = amountsDetails.oneTimeChargesTotal;
        this.feesSurchargesTaxesTotal = amountsDetails.feesSurchargesTotal;
        this.oneTimeChargeTaxesTotal = amountsDetails.oneTimeChargeTaxesTotal;
        this.discountTaxesTotal = amountsDetails.discountTaxesTotal;
        this.discountExpiryTaxesTotal = amountsDetails.discountExpiryTaxesTotal;
        this.discountsTotal = amountsDetails.discountsTotal;
        this.discountsProTotal = amountsDetails.discountsProTotal;
        this.totalProFeesSurchargesAmt = amountsDetails.totalProFeesSurchargesAmt;
        this.discountsExpiring = amountsDetails.discountsExpiring;
        this.additionalMonthlyChargesTotal = amountsDetails.additionalMonthlyChargesTotal;
        this.otherTaxesAmount = amountsDetails.otherTaxesAmount;
        this.otherChargesCredits = amountsDetails.otherChargesCredits;
        this.otherChargesCreditsTaxTotal = amountsDetails.otherChargesCreditsTaxTotal;
        this.monthBills.currentTabBill = this.monthBillsAll[tabName];
        this.getEachProdBillDetails(tabName);
    }

    public getEachProdBillDetails(tabName: string) {
        if (tabName) {
            this.monthlyChargeHsiCategory = [];
            this.monthlyChargePhoneCategory = [];
            this.monthlyChargeDhpCategory = [];
            this.monthlyChargeDtvCategory = [];
            this.broadbandItem = [];
            this.otherhpItem = [];
            this.otherdhpItem = [];
            this.otherdtvItem = [];
            this.proBroadbandItem = [];
            this.proVoiceHpItem = [];
            this.proVoiceDhpItem = [];
            this.proDtvItem = [];
            this.internetCategory = [];
            this.phoneCategory = [];
            this.cvoipCategory = [];
            this.dtvCategory = [];
            this.proFeesnSurcharges = [];
            this.proDiscounts = [];
            this.hsiRecurringDiscounts = [];
            this.hpRecurringDiscounts = [];
            this.dhpRecurringDiscounts = [];
            this.dtvRecurringDiscounts = [];
            this.hsiRecurringFees = [];
            this.hpRecurringFees = [];
            this.dhpRecurringFees = [];
            this.dtvRecurringFees = []
            this.otcDiscounts = [];
            this.ocDiscounts = [];
            this.otcFeesSurcharges = [];
            this.ocFeesSurcharges = [];
            this.monthlyChargeHsiLeadItemAmt = 0;
            this.monthlyChargePhoneLeadItemAmt = 0;
            this.monthlyChargeDhpLeadItemAmt = 0;
            this.monthlyChargeDtvLeadItemAmt = 0;
            this.monthlyPackBroadbandTotalAmt = 0;
            this.monthlyPackPhoneTotalAmt = 0;
            this.monthlyPackDhpTotalAmt = 0;
            this.monthlyPackDtvTotalAmt = 0;
            this.hsiMonthlyChargeTotal = 0;
            this.PhoneMonthlyChargeTotal = 0;
            this.dhpMonthlyChargeTotal = 0;
            this.dtvMonthlyChargeTotal = 0;
            this.mcHsiFederalTax = 0;
            this.mcHsiStateTax = 0;
            this.mcHsiCountyTax = 0;
            this.mcHsiSalesUtilityTax = 0;
            this.mcHsiUsfTax = 0;
            this.mcHpFederalTax = 0;
            this.mcHpStateTax = 0;
            this.mcHpCountyTax = 0;
            this.mcHpSalesUtilityTax = 0;
            this.mcHpUsfTax = 0;
            this.mcDhpFederalTax = 0;
            this.mcDhpStateTax = 0;
            this.mcDhpCountyTax = 0;
            this.mcDhpSalesUtilityTax = 0;
            this.mcDhpUsfTax = 0;
            this.mcDtvFederalTax = 0;
            this.mcDtvStateTax = 0;
            this.mcDtvCountyTax = 0;
            this.mcDtvSalesUtilityTax = 0;
            this.mcDtvUsfTax = 0;
            this.monthlyChargeHsiTotalTax = 0;
            this.monthlyChargeHpTotalTax = 0;
            this.monthlyChargeDhpTotalTax = 0;
            this.monthlyChargeDtvTotalTax = 0;

            this.internetleadItemAmt = 0;
            this.phoneleadItemAmt = 0;
            this.cvoipleadItemAmt = 0;
            this.dtvleadItemAmt = 0;
            this.hsiProRatedTotal = 0;
            this.phoneProRatedTotal = 0;
            this.cvoipProRatedTotal = 0;
            this.dtvProRatedTotal = 0;
            this.proFederalTax = 0;
            this.proStateTax = 0;
            this.proCountyTax = 0;
            this.proSalesUtilityTax = 0;
            this.proUsfTax = 0;
            this.proratedTotalTax = 0
            this.otcTotalTax = 0;
            this.otcFederalTax = 0;
            this.otcStateTax = 0;
            this.otcCountyTax = 0;
            this.otcSalesUtilityTax = 0;
            this.otcUsfTax = 0;
            this.ocTotalTax = 0;
            this.ocFederalTax = 0;
            this.ocStateTax = 0;
            this.ocCountyTax = 0;
            this.ocSalesUtilityTax = 0;
            this.ocUsfTax = 0;
            this.broadbandTotalAmt = 0;
            this.voiceServcTotalAmt = 0;
            this.cvoipTotalAmt = 0;
            this.dtvTotalAmt = 0;
            this.totalHsiRecurringDiscounts = 0;
            this.totalHpRecurringDiscounts = 0;
            this.totalDhpRecurringDiscounts = 0;
            this.totalDtvRecurringDiscounts = 0;
            this.totalProratedDiscounts = 0;
            this.totalOtcDiscounts = 0;
            this.totalOCDiscounts = 0;
            this.totalHsiRecurringFeesAmt = 0;
            this.totalHpRecurringFeesAmt = 0;
            this.totalDhpRecurringFeesAmt = 0;
            this.totalDtvRecurringFeesAmt = 0;
            this.totalProFeesAmt = 0;
            this.totalOtcFeesAmt = 0;
            this.totalOCFeesAmt = 0;
        }
        this.monthBillsAll[tabName].map((P) => {
            if (P.blockHeader !== null && P.blockHeader.indexOf('Monthly Recurring Charges for Services Ordered') !== -1) {
                if (P.productType !== null &&  ((P.productType.indexOf('QW') !== -1) || (P.productType.indexOf('WA') !== -1))) {
                    this.isMonthlyHsi = true;
                    if (P.blockTitle !== "Broadband" && P.amount !== 0) {
                        this.monthlyChargeHsiCategory.push(P);
                        this.monthlyChargeHsiLeadItem = this.monthlyChargeHsiCategory[0].blockTitle;
                        this.monthlyChargeHsiLeadItemAmt += P.amount;
                    } else {
                        if (P.blockTitle === "Broadband" && P.amount !== 0) {
                            this.broadbandServc = true;
                            this.broadbandItem.push(P);
                        }
                    }
                    this.hsiProdId = (P.productId).trim();
                    this.hsiMonthlyChargeTotal += P.amount;
                    this.mcHsiFederalTax += P.federalTax;
                    this.mcHsiStateTax += P.stateTax;
                    this.mcHsiCountyTax += P.countyTax;
                    this.mcHsiSalesUtilityTax += P.salesUtilityTax;
                    this.mcHsiUsfTax += P.usfTax;
                    if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.monthlyChargeHsiTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.productType !== null  && ((P.productType.indexOf('QL') !== -1)||(P.productType.indexOf('IL') !== -1 ))) {
                    this.ismonthlyPhone = true;
                    if (P.blockTitle !== "Voice" && P.amount !== 0) {
                        if(P.displayText.indexOf('Subscriber Line & Access Recovery Charge') === -1) {
                            this.monthlyChargePhoneCategory.push(P);
                        }
                        this.monthlyChargePhoneLeadItem = this.monthlyChargePhoneCategory[0].blockTitle;
                        this.monthlyChargePhoneLeadItemAmt += P.amount;
                    } else {
                        if ((P.blockTitle === "Voice" || P.blockTitle === "Inside Wire Maintenance") && P.amount !== 0) {
                            this.homephoneServc = true;
                            this.otherhpItem.push(P);
                        }
                    }
                    this.hpProdId = (P.productId).trim();
                    this.PhoneMonthlyChargeTotal += P.amount;
                    this.mcHpFederalTax += P.federalTax;
                    this.mcHpStateTax += P.stateTax;
                    this.mcHpCountyTax += P.countyTax;
                    this.mcHpSalesUtilityTax += P.salesUtilityTax;
                    this.mcHpUsfTax += P.usfTax;
                    if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.monthlyChargeHpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.productType !== null && P.productType.indexOf('VP') !== -1) {
                    this.ismonthlyDhp = true;
                    if (P.blockTitle !== "Voice" && P.amount !== 0) {
                        this.monthlyChargeDhpCategory.push(P);
                        this.monthlyChargeDhpLeadItem = this.monthlyChargeDhpCategory[0].blockTitle;
                        this.monthlyChargeDhpLeadItemAmt += P.amount;
                    } else {
                        if (P.blockTitle === "Voice" && P.amount !== 0) {
                            this.voicedhpServc = true;
                            this.otherdhpItem.push(P);
                        }
                    }
                    this.dhpProdId = (P.productId).trim();
                    this.dhpMonthlyChargeTotal += P.amount;
                    this.mcDhpFederalTax += P.federalTax;
                    this.mcDhpStateTax += P.stateTax;
                    this.mcDhpCountyTax += P.countyTax;
                    this.mcDhpSalesUtilityTax += P.salesUtilityTax;
                    this.mcDhpUsfTax += P.usfTax;
                    if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.monthlyChargeDhpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.productType !== null && P.productType.indexOf('DT') !== -1) {
                    this.ismonthlyDtv = true;
                    if (P.blockTitle !== "Dtv" && P.amount !== 0) {
                        this.monthlyChargeDtvCategory.push(P);
                        this.monthlyChargeDtvLeadItem = this.monthlyChargeDtvCategory[0].blockTitle;
                        this.monthlyChargeDtvLeadItemAmt += P.amount;
                    } else {
                        if (P.blockTitle === "Dtv" && P.amount !== 0) {
                            this.dtvServc = true;
                            this.otherdtvItem.push(P);
                        }
                    }
                    this.dtvProdId = (P.productId).trim();
                    this.dtvMonthlyChargeTotal += P.amount;
                    this.mcDtvFederalTax += P.federalTax;
                    this.mcDtvStateTax += P.stateTax;
                    this.mcDtvCountyTax += P.countyTax;
                    this.mcDtvSalesUtilityTax += P.salesUtilityTax;
                    this.mcDtvUsfTax += P.usfTax;
                    if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.monthlyChargeDtvTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                }
            } else if (P.blockHeader !== null && P.blockHeader.indexOf('First Bill Prorated Charges') !== -1) {
                if (P.productType !== null && ((P.productType.indexOf('QW') !== -1) || (P.productType.indexOf('WA') !== -1)) ) {
                    this.isHsi = true;
                    if (P.blockTitle !== "Broadband" && P.amount !== 0) {
                        this.internetCategory.push(P);
                        this.internetleadItem = this.internetCategory[0].blockTitle;
                        this.internetleadItemAmt += P.amount;
                    } else {
                        if (P.blockTitle === "Broadband" && P.amount !== 0) {
                            this.proBroadbandServc = true;
                            this.proBroadbandItem.push(P);
                        }
                    }
                    this.internetProdId = (P.productId).trim();
                    this.hsiProRatedTotal += P.amount;
                    this.proFederalTax += P.federalTax;
                    this.proStateTax += P.stateTax;
                    this.proCountyTax += P.countyTax;
                    this.proSalesUtilityTax += P.salesUtilityTax;
                    this.proUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.proratedTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.productType !== null && ((P.productType.indexOf('QL') !== -1)||(P.productType.indexOf('IL') !== -1))) {
                    this.isPhone = true;
                    if (P.blockTitle !== "Voice" && P.amount !== 0) {
                        if (P.displayText.indexOf('Subscriber Line & Access Recovery Charge') === -1) {
                            this.phoneCategory.push(P);
                        }
                        this.phoneCategory.forEach(pi => { this.phoneleadItem = pi.blockTitle });
                        this.phoneleadItemAmt += P.amount;
                    } else {
                        if ((P.blockTitle === "Voice" || P.blockTitle === "Inside Wire Maintenance") && P.amount !== 0) {
                            this.proVoiceHpItem.push(P);
                            this.proVoiceHpServc = true;
                        }
                    }
                    this.phoneProdId = (P.productId).trim();
                    this.phoneProRatedTotal += P.amount;
                    this.proFederalTax += P.federalTax;
                    this.proStateTax += P.stateTax;
                    this.proCountyTax += P.countyTax;
                    this.proSalesUtilityTax += P.salesUtilityTax;
                    this.proUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.proratedTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.productType !== null && P.productType.indexOf('VP') !== -1) {
                    this.isCvoip = true;
                    if (P.blockTitle !== "Voice" && P.amount !== 0) {
                        this.cvoipCategory.push(P);
                        this.cvoipleadItem = this.cvoipCategory[0].blockTitle;
                        this.cvoipleadItemAmt += P.amount;
                    } else {
                        if (P.blockTitle === "Voice" && P.amount !== 0) {
                            this.proVoiceDhpServc = true;
                            this.proVoiceDhpItem.push(P);
                        }
                    }
                    this.cvoipProdId = (P.productId).trim();
                    this.cvoipProRatedTotal += P.amount;
                    this.proFederalTax += P.federalTax;
                    this.proStateTax += P.stateTax;
                    this.proCountyTax += P.countyTax;
                    this.proSalesUtilityTax += P.salesUtilityTax;
                    this.proUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.proratedTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.productType !== null && P.productType.indexOf('DT') !== -1) {
                    this.isDtv = true;
                    if (P.blockTitle !== "Dtv" && P.amount !== 0) {
                        this.dtvCategory.push(P);
                        this.dtvleadItem = this.dtvCategory[0].blockTitle;
                        this.dtvleadItemAmt += P.amount;
                    } else {
                        if (P.blockTitle === "Dtv" && P.amount !== 0) {
                            this.proDtvServc = true;
                            this.proDtvItem.push(P);
                        }
                    }
                    this.dtvProdId = (P.productId).trim();
                    this.dtvProRatedTotal += P.amount;
                    this.proFederalTax += P.federalTax;
                    this.proStateTax += P.stateTax;
                    this.proCountyTax += P.countyTax;
                    this.proSalesUtilityTax += P.salesUtilityTax;
                    this.proUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.proratedTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                }
            } else if((P.blockHeader !== null && P.blockHeader.indexOf('Fees and Surcharges') !== -1)) {
                if(P.chargeType !== null && P.chargeType.indexOf('Monthly') !== -1) {
                    if(P.productType === 'QW'|| P.productType === 'WA') {
                        this.hsiRecurringFees.push(P);
                        this.totalHsiRecurringFeesAmt += P.amount;
                        this.mcHsiFederalTax += P.federalTax;
                        this.mcHsiStateTax += P.stateTax;
                        this.mcHsiCountyTax += P.countyTax;
                        this.mcHsiSalesUtilityTax += P.salesUtilityTax;
                        this.mcHsiUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeHsiTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } else if (P.productType === 'QL' || P.productType === 'D' || P.productType === 'IL' ) {
                        this.hpRecurringFees.push(P);
                        this.totalHpRecurringFeesAmt += P.amount;
                        this.mcHpFederalTax += P.federalTax;
                        this.mcHpStateTax += P.stateTax;
                        this.mcHpCountyTax += P.countyTax;
                        this.mcHpSalesUtilityTax += P.salesUtilityTax;
                        this.mcHpUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeHpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } else if(P.productType === 'VP' || P.productType === 'D') {
                        this.dhpRecurringFees.push(P);
                        this.totalDhpRecurringFeesAmt += P.amount;
                        this.mcDhpFederalTax += P.federalTax;
                        this.mcDhpStateTax += P.stateTax;
                        this.mcDhpCountyTax += P.countyTax;
                        this.mcDhpSalesUtilityTax += P.salesUtilityTax;
                        this.mcDhpUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeDhpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } else if(P.productType === 'DT') {
                        this.dtvRecurringFees.push(P);
                        this.totalDtvRecurringFeesAmt += P.amount;
                        this.mcDtvFederalTax += P.federalTax;
                        this.mcDtvStateTax += P.stateTax;
                        this.mcDtvCountyTax += P.countyTax;
                        this.mcDtvSalesUtilityTax += P.salesUtilityTax;
                        this.mcDtvUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeDtvTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } 
                } else if (P.chargeType !== null && P.chargeType.indexOf('Prorated') !== -1) {
                    this.proFeesnSurcharges.push(P);
                    this.totalProFeesAmt += P.amount;
                    this.proFederalTax += P.federalTax;
                    this.proStateTax += P.stateTax;
                    this.proCountyTax += P.countyTax;
                    this.proSalesUtilityTax += P.salesUtilityTax;
                    this.proUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.proratedTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.chargeType !== null && P.chargeType.indexOf('One-time') !== -1) {
                    this.otcFeesSurcharges.push(P);
                    this.totalOtcFeesAmt += P.amount;
                    this.otcFederalTax += P.federalTax;
                    this.otcStateTax += P.stateTax;
                    this.otcCountyTax += P.countyTax;
                    this.otcSalesUtilityTax += P.salesUtilityTax;
                    this.otcUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.otcTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.chargeType !== null && P.chargeType.indexOf('Other Charges & Credits') !== -1) {
                    this.ocFeesSurcharges.push(P);
                    this.totalOCFeesAmt += P.amount;
                    this.ocFederalTax += P.federalTax;
                    this.ocStateTax += P.stateTax;
                    this.ocCountyTax += P.countyTax;
                    this.ocSalesUtilityTax += P.salesUtilityTax;
                    this.ocUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.ocTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                }
            } else if((P.blockHeader !== null && P.blockHeader.indexOf('Promotional Discounts') !== -1))  {
                if(P.chargeType !== null && P.chargeType.indexOf('Monthly') !== -1) { 
                    if(P.productType === 'QW' || P.productType === 'WA') {
                        this.hsiRecurringDiscounts.push(P);
                        this.totalHsiRecurringDiscounts += P.amount;
                        this.mcHsiFederalTax += P.federalTax;
                        this.mcHsiStateTax += P.stateTax;
                        this.mcHsiCountyTax += P.countyTax;
                        this.mcHsiSalesUtilityTax += P.salesUtilityTax;
                        this.mcHsiUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeHsiTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } else if(P.productType === 'QL' || P.productType === 'D' || P.productType === 'IL') {
                        this.hpRecurringDiscounts.push(P);
                        this.totalHpRecurringDiscounts += P.amount;
                        this.mcHpFederalTax += P.federalTax;
                        this.mcHpStateTax += P.stateTax;
                        this.mcHpCountyTax += P.countyTax;
                        this.mcHpSalesUtilityTax += P.salesUtilityTax;
                        this.mcHpUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeHpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } else if(P.productType === 'VP' || P.productType === 'D') {
                        this.dhpRecurringDiscounts.push(P);
                        this.totalDhpRecurringDiscounts += P.amount;
                        this.mcDhpFederalTax += P.federalTax;
                        this.mcDhpStateTax += P.stateTax;
                        this.mcDhpCountyTax += P.countyTax;
                        this.mcDhpSalesUtilityTax += P.salesUtilityTax;
                        this.mcDhpUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeDhpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } else if(P.productType === 'DT') {
                        this.hpRecurringDiscounts.push(P);
                        this.totalDtvRecurringDiscounts += P.amount;
                        this.mcHpFederalTax += P.federalTax;
                        this.mcHpStateTax += P.stateTax;
                        this.mcHpCountyTax += P.countyTax;
                        this.mcHpSalesUtilityTax += P.salesUtilityTax;
                        this.mcHpUsfTax += P.usfTax;
                        if((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                            this.monthlyChargeHpTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                        }
                    } 
                } else if (P.chargeType !== null && P.chargeType.indexOf('Prorated') !== -1) {
                    this.proDiscounts.push(P);
                    this.totalProratedDiscounts += P.amount;
                    this.proFederalTax += P.federalTax;
                    this.proStateTax += P.stateTax;
                    this.proCountyTax += P.countyTax;
                    this.proSalesUtilityTax += P.salesUtilityTax;
                    this.proUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.proratedTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.chargeType !== null && P.chargeType.indexOf('One-time') !== -1) {
                    this.otcDiscounts.push(P);
                    this.totalOtcDiscounts += P.amount;
                    this.otcFederalTax += P.federalTax;
                    this.otcStateTax += P.stateTax;
                    this.otcCountyTax += P.countyTax;
                    this.otcSalesUtilityTax += P.salesUtilityTax;
                    this.otcUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.otcTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                } else if (P.chargeType !== null && P.chargeType.indexOf('Other Charges & Credits') !== -1) {
                    this.ocDiscounts.push(P);
                    this.totalOCDiscounts += P.amount;
                    this.ocFederalTax += P.federalTax;
                    this.ocStateTax += P.stateTax;
                    this.ocCountyTax += P.countyTax;
                    this.ocSalesUtilityTax += P.salesUtilityTax;
                    this.ocUsfTax += P.usfTax;
                    if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                        this.ocTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                    }
                }
            } else if (P.blockHeader !== null && P.blockHeader.indexOf('One Time Charges') !== -1) {
                this.otcFederalTax += P.federalTax;
                this.otcStateTax += P.stateTax;
                this.otcCountyTax += P.countyTax;
                this.otcSalesUtilityTax += P.salesUtilityTax;
                this.otcUsfTax += P.usfTax;
                if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                    this.otcTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                }
            } else if (P.blockHeader !== null && P.blockHeader.indexOf('Other Charges and Credits') !== -1 && !this.fromDisconnect) {
                this.ocFederalTax += P.federalTax;
                this.ocStateTax += P.stateTax;
                this.ocCountyTax += P.countyTax;
                this.ocSalesUtilityTax += P.salesUtilityTax;
                this.ocUsfTax += P.usfTax;
                if ((P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax) !== 0) {
                    this.ocTotalTax += P.federalTax + P.stateTax + P.countyTax + P.salesUtilityTax + P.usfTax;
                }
            }
        })
        for (let i = 0; i < this.proBroadbandItem.length; i++) {
            this.broadbandTotalAmt += this.proBroadbandItem[i].amount;
        }
        for (let i = 0; i < this.proVoiceHpItem.length; i++) {
            this.voiceServcTotalAmt += this.proVoiceHpItem[i].amount;
        }
        for (let i = 0; i < this.proVoiceDhpItem.length; i++) {
            this.cvoipTotalAmt += this.proVoiceDhpItem[i].amount;
        }
        for (let i = 0; i < this.proDtvItem.length; i++) {
            this.dtvTotalAmt += this.proDtvItem[i].amount;
        }
        for (let i = 0; i < this.broadbandItem.length; i++) {
            this.monthlyPackBroadbandTotalAmt += this.broadbandItem[i].amount;
        }
        for (let i = 0; i < this.otherhpItem.length; i++) {
            this.monthlyPackPhoneTotalAmt += this.otherhpItem[i].amount;
        }
        for (let i = 0; i < this.otherdhpItem.length; i++) {
            this.monthlyPackDhpTotalAmt += this.otherdhpItem[i].amount;
        }
        for (let i = 0; i < this.otherdtvItem.length; i++) {
            this.monthlyPackDtvTotalAmt += this.otherdtvItem[i].amount;
        }
    }

    public getPrepaidBillAmt (prepaiTabNm) {
        let prepaidAmtDetails = {
            prepaidMonthlyTotalCharge:0,
            prepaidOtcTotalCharge:0,
            prepaidDiscountCharge:0,
            prepaidTaxAmt:0
        } 
        if(prepaiTabNm === 'Initial Payment') {
            /* if(this.isPrepaid && !this.isAmend) {
                this.prepaidFirstBillAmt = this.prepaidData && this.prepaidData.firstMonthList && this.prepaidData.firstMonthList.totalCharges;
            } */
            this.prepaidData && this.prepaidData.firstMonthList && this.prepaidData.firstMonthList.offerDetails.map((b) => {
                this.BillList.push(b);
                if (b.isBasePackage === 'Y' && b.otc === false) {
                    this.prepaidMonthlyTotalCharge += b.offerPrice;
                    this.prepaidTaxAmt += b.tax;
                    this.firstMonthPrepaidTax += b.tax;
                    if(b.taxTypesList !== null){
                        b.taxTypesList.map((t) => {
                            this.taxList.push(t);
                        });
                    } 
                } else {
                    this.prepaidOtcTotalCharge += b.offerPrice;
                    if (b.otc === false) this.firstMonthPrepaidTax += b.tax; else this.firstMonthOTCTax += b.tax;
                    this.prepaidTaxAmt += b.tax;
                    if(b.taxTypesList !== null){
                        b.taxTypesList.map((t) => {
                            this.taxList.push(t);
                        });
                    }
                }
                if(b.specialDiscountAmount) {                    
                    if (b.otc === false || this.isMACD)this.prepaidDiscountCharge -= b.specialDiscountAmount;                   
                }
            });
            // if(this.isPrepaid && !this.isAmend) {
            if(this.isPrepaid) {
                !this.isMACD ? this.prepaidFirstBillAmt = this.prepaidMonthlyTotalCharge +  this.firstMonthPrepaidTax + this.prepaidDiscountCharge :
                this.prepaidFirstBillAmt = this.prepaidData && this.prepaidData.firstMonthList && this.prepaidData.firstMonthList.totalCharges;
            }
        } else {
            this.prepaidSecondBillAmt = this.prepaidData && this.prepaidData.secondMonthList && this.prepaidData.secondMonthList.totalCharges;
            this.prepaidData && this.prepaidData.secondMonthList && this.prepaidData.secondMonthList.offerDetails.map((b) => {
                this.BillList.push(b);
                if (b.isBasePackage === 'Y' && b.otc === false) {
                    this.prepaidMonthlyTotalCharge += b.offerPrice;
                    this.prepaidTaxAmt += b.tax;
                    if(b.taxTypesList !== null){
                        b.taxTypesList.map((t) => {
                            this.taxList.push(t);
                        });
                    }
                } else {
                    this.prepaidOtcTotalCharge += b.offerPrice;
                    this.prepaidTaxAmt += b.tax;
                    if(b.taxTypesList !== null){
                        b.taxTypesList.map((t) => {
                            this.taxList.push(t);
                        });
                    }
                }
                if(b.specialDiscountAmount)
                {                    
                    this.prepaidDiscountCharge -= b.specialDiscountAmount;              
                }
            });
        }  
        return prepaidAmtDetails;
    }

    public getBillAmount(tabName: string) {
        let amountsDetails = {
            proRatedTotal: 0,
            proRatedTaxesTotal: 0,
            monthlyChargesTotal: 0,
            monthlyChargeTaxesTotal: 0,
            oneTimeChargesTotal: 0,
            oneTimeChargeTaxesTotal: 0,
            discountTaxesTotal: 0,
            discountExpiryTaxesTotal: 0,
            feesSurchargesTotal: 0,
            discountsTotal: 0,
            discountsProTotal: 0,
            discountsExpiring: 0,
            additionalMonthlyChargesTotal: 0,
            otherTaxesAmount: 0,
            totalProFeesSurchargesAmt: 0,
            otherChargesCredits: 0,
            otherChargesCreditsTaxTotal: 0
        }
        this.monthBillsAll[tabName].map((k) => {
            if (k.blockHeader !== null && (k.blockHeader.indexOf('First Bill Prorated Charges') !== -1) || (k.blockHeader.indexOf('Prorated Charges') !== -1)) {
                amountsDetails.proRatedTotal += k.amount;
                amountsDetails.proRatedTaxesTotal +=
                    (k.federalTax + k.stateTax + k.salesUtilityTax + k.usfTax + k.countyTax);
            }
            if (k.blockHeader !== null && k.blockHeader.indexOf('Monthly Recurring Charges') !== -1) {
                amountsDetails.monthlyChargesTotal += k.amount;
                amountsDetails.monthlyChargeTaxesTotal += (k.federalTax + k.stateTax +
                    k.salesUtilityTax + k.usfTax + k.countyTax);
            }
            if (k.blockHeader !== null && k.blockHeader.indexOf('One Time Charges') !== -1) {
                amountsDetails.oneTimeChargesTotal += k.amount;
                amountsDetails.oneTimeChargeTaxesTotal +=
                    (k.federalTax + k.stateTax +
                        k.salesUtilityTax + k.usfTax + k.countyTax);
            }
            if (k.blockHeader !== null && (k.blockHeader.indexOf('Promotional Discounts') !== -1 && k.chargeType.indexOf('Other Charges & Credits') === -1) || k.blockHeader.indexOf('Discount Expiring') !== -1) {
                if ((k.blockHeader === "Promotional Discounts") && (k.chargeType.indexOf('Prorated') !== -1)) {
                    amountsDetails.discountsProTotal += k.amount;
                    amountsDetails.proRatedTaxesTotal +=
                        (k.federalTax + k.stateTax +
                            k.salesUtilityTax + k.usfTax + k.countyTax);
                } else {
                    amountsDetails.discountsTotal += k.amount;
                    amountsDetails.discountTaxesTotal +=
                        (k.federalTax + k.stateTax +
                            k.salesUtilityTax + k.usfTax + k.countyTax);
                }
            }
            if (k.blockHeader !== null && k.blockHeader.indexOf('Discount Expiring') !== -1) {
                amountsDetails.discountsExpiring += k.amount;
                amountsDetails.discountExpiryTaxesTotal +=
                    (k.federalTax + k.stateTax +
                        k.salesUtilityTax + k.usfTax + k.countyTax);
            }
            if (k.blockHeader !== null && k.blockHeader.indexOf('Fees and Surcharges') !== -1 && k.chargeType.indexOf('Other Charges & Credits') === -1 ) {
                if (k.chargeType.indexOf('Prorated') !== -1) {
                    amountsDetails.totalProFeesSurchargesAmt += k.amount;
                    amountsDetails.proRatedTaxesTotal += (k.federalTax + k.stateTax + k.salesUtilityTax + k.usfTax + k.countyTax);
                } else {
                    amountsDetails.otherTaxesAmount += k.amount;
                    amountsDetails.feesSurchargesTotal += (k.federalTax + k.stateTax + k.salesUtilityTax + k.usfTax + k.countyTax);
                }

            }
            if ((k.blockHeader !== null && (k.blockHeader.indexOf('Other Charges and Credits') !== -1 )||( k.chargeType !== null && k.chargeType.indexOf('Other Charges & Credits') !== -1)))
            {
                if(this.fromDisconnect) {
                    this.otherCharges = true;
                }
                amountsDetails.otherChargesCredits += k.amount;
                if(k.blockHeader.indexOf('Other Charges and Credits') !== -1 || k.chargeType.indexOf('Other Charges & Credits') !== -1  ) {
                    amountsDetails.otherChargesCreditsTaxTotal +=
                        (k.federalTax + k.stateTax + k.salesUtilityTax + k.usfTax + k.countyTax);
                }
            }
            if (k.blockHeader !== null && k.blockHeader.indexOf('Final Bill Amount') !== -1 && this.fromDisconnect) {
                this.finalBillAmount = true;
                this.finalBillAmt = k.amount;
                this.displayText = k.displayText;
            }
        });
        return amountsDetails;
    }

    public billSummary(billEstimate:billQuoteResponce, billInput) {
        this.propertyBillQuoteMaxRetries = this.propertiesHelperService.getPropertyValueAsNumber(PropertyEnums.BILL_QUOTE_MAX_RETRIES,5);
        this.billMonths = [];
        this.monthBillsAll = {};
        if (billEstimate && billEstimate.quoteArr && billEstimate.quoteArr.length > 0 && billEstimate.quoteArr[0].quoteItemArr.length > 0) {
            this.billEstimate = billEstimate;
            this.apiResponseBillEmpty= this.checkStatusToRetry(billEstimate);
            if (this.billEstimate.quoteArr[0].quoteItemArr.length > 0) {

                this.billEstimate.quoteArr[0].quoteItemArr.map((val) => {
                    var index = val.tag;
                    if (this.monthBillsAll.hasOwnProperty(index)) {
                        this.monthBillsAll[index].push(val)
                    }
                    else {
                        this.monthBillsAll[index] = [];
                        this.monthBillsAll[index].push(val);
                    }
                });

                let counter = 0;
                for (let i in this.monthBillsAll) {
                    let amount = 0;

                    let amountObject = this.getBillAmount(i);
                    for (let key in amountObject) {
                        if (key !== 'discountsExpiring' && key !== 'discountExpiryTaxesTotal') {
                            amount = amount + amountObject[key];
                        }
                    }
                    let tabTitle = '';
                    if (i === 'NextBill') {
                        tabTitle = 'First Bill';
                    } else if (i === 'SecondBill') {
                        tabTitle = 'Month 2';
                    } else if (i !== undefined && i !== '') {
                        tabTitle = i;
                    }
                    this.billMonths.push({ name: i, monthId: tabTitle, amount: amount });
                    counter++;
                }
                this.setActivate(Object.keys(this.monthBillsAll)[0]);
                this.monthBills.currentTabBill = this.monthBillsAll[Object.keys(this.monthBillsAll)[0]];
                this.currentTab = Object.keys(this.monthBillsAll)[0];
            }
        }
        else if (this.counter <= this.propertyBillQuoteMaxRetries) {
            this.counter++;
            this.getBillDetails(billInput);
        }
        else if (this.counter > this.propertyBillQuoteMaxRetries) {
            this.apiResponseBillEmpty = true;
        }
    }

    public checkStatusToRetry= (billEstimate:billQuoteResponce)=> {
        if(billEstimate.genericResponse.code==='300'){
            return true;
        }
        if(billEstimate.genericResponse.code==='200'){
            return false;
        }
        if(billEstimate.genericResponse.code==='404'){
            return false;
        }
        if(billEstimate.genericResponse.code==='500'){
            return true;
        }
        return true;
    }

    public viewRccs() {
        // this  defaultBillEffectiveDate is only for disconnect flow 
        let defaultBillEffectiveDate;
        let schedule = this.store.select('appointment');
        let scheduleSubscription = schedule.subscribe((data) => {
            if (data && data.payload && data.payload.defaultBillEffectiveDate){
                defaultBillEffectiveDate= data.payload.defaultBillEffectiveDate;
            }
         });
         scheduleSubscription.unsubscribe();
        let request = {
            orderRefNumber: this.orderRefNumber,
            rccId: "",
            salesChannel: "ESHOP - Customer Care",
            versionNumber: "",
            billeffectiveDateInfo:defaultBillEffectiveDate
        }
        this.loading = true;
        this.logger.log("info", "bill-estimate.component.ts", "retrieveRccRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService.retrieveRcc(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "bill-estimate.component.ts", "retrieveRccErrorResponse", error);
                this.logger.log("error", "bill-estimate.component.ts", "retrieveRccSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "Get RCC Details", "bill-estimate.component.ts",
                    "RCC Details",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "bill-estimate.component.ts", "retrieveRccResponse", JSON.stringify(data));
                    this.logger.log("info", "bill-estimate.component.ts", "retrieveRccSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data && data.errorResponse === undefined && data.rccGroup) {
                        this.rccDetails = data.rccGroup[0].rccDetails;
                        this.store.dispatch({ type: 'RCC_DETAILS', payload: data });
                        this.reviewRccsDialog.open();
                    }
                    if (data && data.errorResponse !== undefined && data.rccGroup) {
                        this.rccErrorMessage = data.errorResponse.messageDetail;
                        this.rccDetails = data.rccGroup[0].rccDetails;
                        this.store.dispatch({ type: 'RCC_DETAILS', payload: data });
                        this.reviewRccsDialog.open();
                    }
                    this.loading = false;
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "bill-estimate.component.ts", "retrieveRccErrorResponse", error);
                    this.logger.log("error", "bill-estimate.component.ts", "retrieveRccSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "getOrderSummaryError", "bill-estimate.component.ts", "Review Order Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                        this.systemErrorService.logAndeRouteToSystemError("error", "getOrderSummaryError", "bill-estimate.component.ts", "Review Order Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                })
    }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderBillEstimatePage');
        if(this.isPrepaid){
            this.prepaidFirstBillAmt = this.prepaidData && this.prepaidData.firstMonthList && this.prepaidData.firstMonthList.totalCharges;
            this.prepaidSecondBillAmt = this.prepaidData && this.prepaidData.secondMonthList && this.prepaidData.secondMonthList.totalCharges;
            /* if(this.isPrepaid && this.isAmend) {
                this.setTabActivate("Next Payment");
            } else {
                this.setTabActivate(this.prepaidCurrentTab);
            } */
            this.setTabActivate(this.prepaidCurrentTab);
        }else{
            if (this.billInput && this.billInput !== '-1') {
                this.apiResponseBillEmpty = false;
                this.getBillDetails(this.billInput);
            }
            else {
                this.apiResponseBillEmpty = true;
            }
        }
        this.accountObservable = <Observable<any>>this.store.select('account');
        this.accountSubscription = this.accountObservable.subscribe((data) =>{
            if(data && data.payload && data.payload.accountPreferences && data.payload.accountPreferences.paperlessBilling === 'false'){
                this.isPaperlessBillingNotApplied = true;
            }
            if(data && data.payload && data.payload.finalPaymentDate)
            {
                this.finalPaymentDate=data.payload.finalPaymentDate
            }
        });
        this.orderObservable = <Observable<any>>this.store.select('order');
        let retainDisconnectData = <Observable<any>>this.store.select('retain');
        this.userObservable = <Observable<User>>this.store.select('user');
        let usrData: User;
        this.userSubscription = this.userObservable.subscribe((userData) => {
            usrData = userData;
            if(usrData.currentUrl === '/review-order' || usrData.currentUrl === '/order-confirmation' || this.isAmend || usrData.currentUrl === '/po-review-order' || usrData.currentUrl === '/po-order-confirmation'){
                this.isMACD = false;
           }else{
               this.isMACD = true;
           }
        })
        if(this.isPrepaid && this.isMACD) {
            this.prepaidFirstBillAmt = this.prepaidData && this.prepaidData.firstMonthList && this.prepaidData.firstMonthList.totalCharges;
        }
        this.orderSubscription = this.orderObservable.subscribe((data) => {
            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            } else {
                if (usrData && usrData.orderRefNumber) {
                    this.orderRefNumber = usrData.orderRefNumber;
                } else {
                    retainDisconnectData.subscribe(retainData => {
                        if (retainData && retainData !== undefined && retainData.review && retainData.review !== undefined && retainData.review.orderRefNumber && retainData.review.orderRefNumber !== undefined) {
                            this.orderRefNumber = retainData.review.orderRefNumber;
                        }
                    })
                }
            }

            if(data && data.payload && data.payload.finalPaymentDate)
            {
                this.finalPaymentDate=data.payload.finalPaymentDate;
            }
        })
    }
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }
    public isAcknowledgeContinued(event) {
        if (!event) {
            this.isStillNeedToCompleteRCC = true;
        }
        this.isAcknowledgeContinueClicked = true;
        this.isAcknowledged.emit(event);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) { this.userSubscription.unsubscribe(); }
        if (this.orderSubscription !== undefined) { this.orderSubscription.unsubscribe(); }
    }

    public getTotalTax(tax:any){
        let sum = 0;
        tax.map((d)=>{
            sum = sum+parseFloat(d.taxAmount)
            });
            return sum
        }
    public getMonthlyBill(){
        let monthly=0;
        this.prepaidData.offerDetailsList.offerDetails.forEach((a)=>{monthly = monthly+a.tax
        });
        return monthly
    }
    public getTaxAmount(){
        let total =0;
        this.prepaidData.offerDetailsList.offerDetails.forEach(off=>{
            off.taxTypesList.forEach(taxes=>{total=total+taxes.taxAmount});           
        });
        return total;
    }


}
