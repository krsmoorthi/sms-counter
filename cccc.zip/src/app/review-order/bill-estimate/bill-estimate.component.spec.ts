import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BillEstimateComponent } from './bill-estimate.component';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { Observable } from 'rxjs';
import { Logger } from 'app/common/logging/default-log.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Store } from '@ngrx/store';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { Router } from '@angular/router';
import { AccountService } from 'app/common/service/account.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import "rxjs/add/observable/of";
import { AppStateService } from 'app/common/service/app-state.service';
import { MockServer } from 'app/MockServer.test';
import {
   MockReviewOrderService,
   MockAccountService,
   MockSystemErrorService,
   MockDirectvService,
   MockRouter,
   MockCTLHelperService,
   MockLogger,
   MockPendingOrderService,
   MockBlueMarbleService,
   MockCountryStateService,
   MockDisconnectService,
   MockProductService,
   MockAddressService,
   MockTextMaskService,
   MockAppStateService,
   MOCK_ROUTES,
 } from 'app/common/service/mockServices.test';
import { RouterTestingModule } from '@angular/router/testing';
import { AccordionModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';

describe('BillEstimateComponent', () => {
  let component: BillEstimateComponent;
  let fixture: ComponentFixture<BillEstimateComponent>;
  const mockServer = new MockServer();
  
  const mockRedux: any = {
    dispatch(obj) {return obj},
    configureStore() {},
    select(reducer) {
        return Observable.of(
          mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  };
  
  const logger = { provide: Logger, useClass: MockLogger}
  const router = { provide: Router, useClass: MockRouter };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService}
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };
  const cTLHelperService = { provide: CTLHelperService, useClass: MockCTLHelperService };
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const productService = {provide: ProductService, useClass: MockProductService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const  textMaskService = {provide: TextMaskService, useClass: MockTextMaskService};
  const propertiesHelperService = PropertiesHelperService;
  
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    AccordionModule.forRoot(),
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ];

  const providers = [
      logger, router,store,appStateService, reviewOrderService, accountService,
      systemErrorService, directvService, cTLHelperService, pendingOrderService,
      blueMarbleService, countryStateService, disconnectService, productService, addressService,textMaskService,
      propertiesHelperService
  ];

  const baseConfig = {
    imports: imports,
    providers: providers
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillEstimateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.billInput = 99023080;
    expect(component).toBeTruthy();
  });

  it('should check Mask Phone', () => {
    let phone = '9898989898'
    component.maskPhone(phone)
    expect(component).toBeTruthy();
  });

  it('should call isAcknowledgeContinued', () => {
    let actual = component.isAcknowledgeContinued(event);
    expect(actual).toBeUndefined();
  });    

  it('should call getBillDetails', () => {
    component.getBillDetails(354);
    expect(component.loading).toBe(false);
  });

  it('should call ngOnInit()', () => {
    component.ngOnInit();
  });

  it('should call setTabActivate', () => {
      let actual = component.setTabActivate({});
      expect(actual).toBeUndefined();
    });

});