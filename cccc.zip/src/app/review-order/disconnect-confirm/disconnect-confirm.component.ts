import { DisconnectStore, DisconnectReviewOrderModel, DisconnectReviewOrderForm, DisconnectConfirmModel } from './../../common/models/disconnect.model';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppStateService } from '../../common/service/app-state.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { AppStore } from './../../common/models/appstore.model';
import { Logger } from '../../common/logging/default-log.service';
import { ExistingProducts } from 'app/common/models/existing-products.model';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';

@Component({
    selector: 'disconnect-confirm',
    styleUrls: ['../disconnect-review-order-component/disconnect-review-order.component.scss'],
    templateUrl: './disconnect-confirm.component.html'
})

export class DisconnectConfirmComponent implements OnInit, OnDestroy {
    public currentPage = "disconnect-confirm";
    public disconnectSubscription: Subscription;
    public disconnect$;
    public mainData: DisconnectReviewOrderModel;
    public reviewOrderFormData: DisconnectReviewOrderForm;
    public submitReviewResonse: DisconnectConfirmModel;
    public savedQuoteId: string;
    public isDtv = false;
    public existingProductsSubscription;
    public existingProducts;
    public user;
    public userSubscription;
    public currentPath;
    public emailAddress;
    public billingType:string = '';
    constructor(
        private appStateService: AppStateService,
        private logger: Logger,
        public store: Store<AppStore>,
        public ReviewOrderHelperService: ReviewOrderHelperService
    ) {
        this.appStateService.setLocationURLs();
        this.disconnect$ = <Observable<any>>store.select('disconnect');
        this.disconnectSubscription = this.disconnect$.subscribe((respData: DisconnectStore) => {
            if(respData) {
                if(respData.disconnect_review_order) {
                this.mainData = respData.disconnect_review_order;
                this.savedQuoteId = respData.disconnect_review_order.payload.billEstimate? respData.disconnect_review_order.payload.billEstimate.quote[0].quoteId : '';
                }
                if(respData.disconnect_review_order_submit) {
                    this.reviewOrderFormData = respData.disconnect_review_order_submit.formData;
                    this.submitReviewResonse = respData.disconnect_review_order_submit.disconnectSubmitresponse;
                }
            }
            this.isDtv = respData.dtvExists;
        });
        if(this.disconnectSubscription) this.disconnectSubscription.unsubscribe();
    }



    public ngOnInit() {
        this.logger.metrics('ReviewOrderDisconnectConfirmPage');
        this.existingProducts = <Observable<ExistingProducts>>this.store.select('existingProducts');
        this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
            this.user = <Observable<any>>this.store.select('user');
            this.userSubscription = this.user.subscribe(
                (user) => {
                    this.currentPath = user.currentUrl;
                });
            if (this.currentPath === '/disconnect-confirmation') {
                if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0) {
                    if (data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.emailAddress && data.existingProductsAndServices[0].accountInfo.contact.emailAddress !== '') {
                        this.emailAddress = data.existingProductsAndServices[0].accountInfo.contact.emailAddress;
                    }
                    if(data.existingProductsAndServices[0].accountInfo && data.existingProductsAndServices[0].accountInfo.billingType === 'PREPAID') {
                        this.billingType = 'PREPAID';
                    }
                }
            }
        });
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        this.existingProductsSubscription.unsubscribe();
    }




}
