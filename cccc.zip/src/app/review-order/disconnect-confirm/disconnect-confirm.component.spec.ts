import { TestBed, ComponentFixture, inject, async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { MockLogger, MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockReviewOrderService, MockProductService, MockBlueMarbleService, MockReviewOrderHelperService, MockHelperService, MockCTLHelperService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { Store } from '@ngrx/store';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStateService } from 'app/common/service/app-state.service';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { AccordionModule } from 'ngx-bootstrap';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { DisconnectConfirmComponent } from './disconnect-confirm.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HelperService } from 'app/common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { CustomDatePickerComponent } from 'app/common/datepicker/datepicker.component';
import { SystemErrorService } from 'app/common/service/system-error.service';

describe('Disconnect Confirm Component', () => {
  let component: DisconnectConfirmComponent;
  let fixture: ComponentFixture<DisconnectConfirmComponent>;
  let mockServer = new MockServer();

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    SharedModule,
    SharedCommonModule,
    AccordionModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ];
  
  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]);
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }
  
  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const reviewOrderHelper = { provide: ReviewOrderHelperService, useClass: MockReviewOrderHelperService};
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService};
  //Dialog Component services
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const countryStateService = { provide: CountryStateService, useClass: MockCountryStateService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };
  const propertiesHelperService = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
  const ctlHelperService = { provide: CTLHelperService, useClass: MockCTLHelperService };
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };

  const baseConfig = {
    imports: imports,
    declarations: [DisconnectConfirmComponent],
    providers: [logger, store, appStateService, reviewOrderHelper, helperService, blueMarbleService,
        pendingOrderService, accountService, addressService, countryStateService, directvService,
        propertiesHelperService, ctlHelperService, reviewOrderService, disconnectService, productService, systemErrorService]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisconnectConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should call ngOnInit', () => {
    let temp = component.ngOnInit()
    expect(temp).toBe(undefined);
  });
  
  it('should call ngOnDestroy', () => {
    component.ngOnDestroy();
    expect(component.existingProductsSubscription.isStopped).toBe(true);
  });
});