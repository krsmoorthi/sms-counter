import { DisconnectService } from '../../common/service/disconnect.service';
import { DisconnectConfirmComponent } from './disconnect-confirm.component';
import { ReviewOrderService } from './../../common/service/review-order.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: DisconnectConfirmComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        // ModalModule,
        AccordionModule.forRoot(),
    ],
    exports: [
        DisconnectConfirmComponent,
    ],
    declarations: [
        DisconnectConfirmComponent,
    ],
    providers: [
        ReviewOrderService,
        DisconnectService,
        ReviewOrderHelperService
    ]
})
export class DisconnectConfirmOrderModule { }
