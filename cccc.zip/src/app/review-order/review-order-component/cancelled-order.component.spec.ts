import { TestBed, ComponentFixture, async } from "@angular/core/testing";
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import "rxjs/add/observable/of";
import "rxjs/add/observable/throw";
import { AccordionModule } from 'ngx-bootstrap';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { RouterModule, Routes, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { MockServer } from "../../MockServer.test";
import { OrderCancelComponent } from './cancelled-order.component';
import { AppStateService } from '../../common/service/app-state.service';
import { MockAppStateService, MockPendingOrderService, MockLogger, MockHelperService, MockCTLHelperService, MockReviewOrderService, MockRouter, MockAccountService, MockDisconnectService, MockProductService, MockBlueMarbleService, MockAddressService, MockSystemErrorService, MockCountryStateService, MockTextMaskService, MockDirectvService, MockPropertiesHelperService } from '../../common/service/mockServices.test';
import { SharedCommonModule } from '../../shared/shared-common.module';
import { SharedModule } from '../../shared/shared.module';
import { PendingOrderService } from '../../common/service/pending-order.service';
import { Logger } from '../../common/logging/default-log.service';
import { HelperService } from '../../common/service/helper.service';
import { CTLHelperService } from '../../common/service/ctlHelperService';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { AccountService } from '../../common/service/account.service';
import { DisconnectService } from '../../common/service/disconnect.service';
import { ProductService } from '../../common/service/product.service';
import { BlueMarbleService } from '../../common/service/bm.service';
import { AddressService } from '../../common/service/address.service';
import { SystemErrorService } from '../../common/service/system-error.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import { DirectvService } from '../../common/service/directv.services';
import { PropertiesHelperService } from '../../common/service/propertiesHelper.service';
import { compileNgModule } from '@angular/compiler';

describe('cancelled order component Test cases', () => {
    let component: OrderCancelComponent;
    let fixture: ComponentFixture<OrderCancelComponent>;
    const mockServer = new MockServer();
    let pendingOrderService: PendingOrderService;
    const routes: Routes = [
        { path: "", component: OrderCancelComponent }
    ];    

    const p2 = { provide: AppStateService, useClass: MockAppStateService };
    const p3 = PendingOrderService;
    const p4 = { provide: Logger, useClass: MockLogger };
    const p5 = { provide: HelperService, useClass: MockHelperService };
    const p6 = { provide: CTLHelperService, useClass: MockCTLHelperService };

    //Dialog component dependencies
    const p8 = { provide: Router, useClass: MockRouter };
    const p7 = { provide: ReviewOrderService, useClass: MockReviewOrderService };
    const p9 = DomSanitizer;
    const p10 = { provide: AccountService , useClass: MockAccountService};
    const p11 = { provide: DisconnectService , useClass: MockDisconnectService};
    const p12 = { provide: ProductService , useClass: MockProductService};
    const p13 = { provide: AddressService , useClass: MockAddressService};
    const p14 = { provide: BlueMarbleService , useClass: MockBlueMarbleService};
    const p15 = FormBuilder;
    const p16 = { provide: SystemErrorService , useClass: MockSystemErrorService};
    const p17 = { provide: CountryStateService , useClass: MockCountryStateService};
    const p18 = { provide: TextMaskService , useClass: MockTextMaskService};
    const p19 = { provide: DirectvService , useClass: MockDirectvService};
    const p20 = { provide: PropertiesHelperService , useClass: MockPropertiesHelperService};

    describe("Testing If block", () => {
        const mockRedux: any = {
            dispatch(obj) {return obj},
            configureStore() {},
            select(reducer) {
                return Observable.of(
                  mockServer.getMockStore("onload-cancelled-order")[reducer]
                );
            },
            take<T>(this: Observable<T>, count: number) {
              return Observable.of(null);
            }
        };
        const p1 = { provide: Store, useValue: mockRedux };
        const baseConfig = {
            imports: [
                FormsModule,
                ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
                RouterModule.forChild(routes),
                SharedModule,
                SharedCommonModule,
                AccordionModule.forRoot()
            ],
            declarations: [ OrderCancelComponent ],
            providers: [ p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20]
        };
        
        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule(baseConfig).compileComponents();
        }));
        
        beforeEach(() => {
            fixture = TestBed.createComponent(OrderCancelComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it("should create CancelledOrderComponent", () => {
            expect(component).toBeDefined();
        });

        it("should set addressCity to 'test street'", () => {
            expect(component.addressCity).toBe('test street');
        });

        it("should return deposit amount 100", () => {
            let depositAmt = component.calculateDepositAmount([{"amountPaid": 50},{"amountPaid": 50}]);
            expect(depositAmt).toBe(100);
        });

        it("should call logger.metrics", () => {
            let logger = TestBed.get(Logger);
            const spy = spyOn(logger, 'metrics').and.callFake(() => []);
            component.ngOnInit();
            expect(spy).toBeDefined();
        });

        it("should unsubscribe user, pending & existingProducts store", ()=> {
            component.ngOnDestroy();
            expect(component.userSubscription.closed).toBeTruthy();
            expect(component.cancelOrderSubscription.closed).toBeTruthy();
            expect(component.existingSubscription.closed).toBeTruthy();
        });

        it("should call window.open", () => {
            spyOn(window, 'open' ).and.callFake(() => {
                return window;
            });
            spyOn(window, 'close' ).and.callFake(() => {
                return window;
            });
            component.closeSession();
            expect(window.open).toHaveBeenCalled();
            expect(window.close).toHaveBeenCalled();
        });
    });

    describe("Testing Else block", () => {
        const mockRedux: any = {
            dispatch(obj) {return obj},
            configureStore() {},
            select(reducer) {
                return Observable.of(
                  mockServer.getMockStore("onload-cancelled-order-else")[reducer]
                );
            },
            take<T>(this: Observable<T>, count: number) {
              return Observable.of(null);
            }
        };
        const p1 = { provide: Store, useValue: mockRedux };
        const baseConfig = {
            imports: [
                FormsModule,
                ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
                RouterModule.forChild(routes),
                SharedModule,
                SharedCommonModule,
                AccordionModule.forRoot()
            ],
            declarations: [ OrderCancelComponent ],
            providers: [ p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20]
        };
        
        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule(baseConfig).compileComponents();
        }));
        
        beforeEach(() => {
            fixture = TestBed.createComponent(OrderCancelComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });       
        
        it("should set depositAmount to 50", () => {
            expect(component.depositAmount).toBe(50);
        });

        it("should set showDeposit to false", () => {
            expect(component.showDeposit).toBeFalsy();
        });

        it("should set addressCity to 'test1 test2'", () => {
            expect(component.addressCity).toBe('test1 test2');
        });

        it("should not unsubscribe store as it is already unsubscirbed", () => {
            component.userSubscription = undefined;
            component.cancelOrderSubscription = undefined;
            component.existingSubscription = undefined;
            component.ngOnDestroy();
            expect(component.userSubscription).toBeUndefined();
            expect(component.cancelOrderSubscription).toBeUndefined();
            expect(component.existingSubscription).toBeUndefined();
        });
    });

    describe("Testing with serviceAddress under orderInit payload", () => {
        const mockRedux: any = {
            dispatch(obj) {return obj},
            configureStore() {},
            select(reducer) {
                return Observable.of(
                  mockServer.getMockStore("onload-cancelled-order-orderInit")[reducer]
                );
            },
            take<T>(this: Observable<T>, count: number) {
              return Observable.of(null);
            }
        };
        const p1 = { provide: Store, useValue: mockRedux };
        const baseConfig = {
            imports: [
                FormsModule,
                ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
                RouterModule.forChild(routes),
                SharedModule,
                SharedCommonModule,
                AccordionModule.forRoot()
            ],
            declarations: [ OrderCancelComponent ],
            providers: [ p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20]
        };
        
        beforeEach(async(() => {
            TestBed.resetTestingModule();
            TestBed.configureTestingModule(baseConfig).compileComponents();
        }));
        
        beforeEach(() => {
            fixture = TestBed.createComponent(OrderCancelComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
        });

        it("should set addressCity to 'test1 test2'", () => {
            expect(component.addressCity).toBe('test1 test2');
        });
    });

});