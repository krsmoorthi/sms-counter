import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { User } from '../../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStore } from '../../common/models/appstore.model';
import { AppStateService } from '../../common/service/app-state.service';
import { Observable } from 'rxjs/Observable';
import { Logger } from '../../common/logging/default-log.service';
import { HelperService } from '../../common/service/helper.service';
import { PendingOrderService } from '../../common/service/pending-order.service';

@Component({
    selector: 'order-cancelled',
    styleUrls: ['./review-order.component.scss'],
    templateUrl: './cancelled-order.component.html'
})

export class OrderCancelComponent implements OnInit, OnDestroy {
  
    public user;
    public userSubscription: Subscription;
    public currentPath: string;
    public cancelorderObservable: Observable<any>;
    public cancelOrderSubscription: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public fromHold: boolean = false;
    public showDeposit: boolean = false;
    public depositAmount: any;
    public addressCity: string;
    public serviceAddress: any;
    public addressStreet: string = '';

    constructor(
        public store: Store<AppStore>,
        private logger: Logger,
        private appStateService: AppStateService,
        public helperService: HelperService,
        private pendingOrderService: PendingOrderService
    ) {
        this.appStateService.setLocationURLs();
        this.user = <Observable<User>> store.select('user');

        this.userSubscription = this.user.subscribe((data) => {
            if (data.currentUrl !== null && data.currentUrl !== undefined) {
                this.currentPath = data.currentUrl;
                if (data && data.finalAddress && data.finalAddress.addressLine) {
                    this.addressCity = data.finalAddress.addressLine;
                }
            }
            if (data && data.depositAddress) {
                this.serviceAddress = data.depositAddress;
                this.mappingAddress();
            }else if(data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress){
                this.serviceAddress = data.orderInit.payload.serviceAddress;
                this.mappingAddress();
            }
        });
        this.existingObservable = this.store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe(exist => {
            if (exist && exist.orderFlow && exist.orderFlow.type === 'fromHold') {
                this.fromHold = true;
            }
            this.cancelorderObservable = this.store.select('pending');
            this.cancelOrderSubscription = this.cancelorderObservable.subscribe((data) => {
                if (this.fromHold && data.deposit && data.deposit.depositInfo) {
                    this.depositAmount = this.calculateDepositAmount(data.deposit.depositInfo)
                    this.showDeposit = true;
                }else{
                    data && data.orderDocument && data.orderDocument.creditReview && data.orderDocument.creditReview.paymentInfo[0] && data.orderDocument.creditReview.paymentInfo[0].paidAmount?
                    this.depositAmount = data.orderDocument.creditReview.paymentInfo[0].paidAmount : this.depositAmount = 0;
                    this.showDeposit = false;
                }
            })
        });
    }

    public calculateDepositAmount(depositInfo){
        let depositAmt = 0;
        depositInfo.forEach(element => {
            depositAmt += element.amountPaid;
        });
        this.pendingOrderService.getDepositAmount(depositAmt);
        return depositAmt;
    }

    private mappingAddress(){
        if (this.serviceAddress) {
            if (this.serviceAddress.streetAddress && this.serviceAddress.streetAddress !== '') {
                this.addressCity = this.serviceAddress.streetAddress;
            } else {
                this.addressCity = this.serviceAddress.streetNrFirst + ' ' + this.serviceAddress.streetName;
            }
            if (this.serviceAddress.locality && this.serviceAddress.locality !== '') {
                this.addressStreet = this.serviceAddress.locality;
            } else {
                this.addressStreet = this.serviceAddress.city ? this.serviceAddress.city : this.addressStreet;
            }
            if (this.serviceAddress.stateOrProvince && this.serviceAddress.stateOrProvince !== '') {
                this.addressStreet = this.addressStreet + ',' + this.serviceAddress.stateOrProvince;
            }
            if (this.serviceAddress.postCode && this.serviceAddress.postCode !== '') {
                this.addressStreet = this.addressStreet + ',' + this.serviceAddress.postCode;
            }
        }
    }
    
    public closeSession() {
        window.open("about:blank",'_self','');
        window.close();
    }

    public ngOnInit() {
        this.logger.metrics('ReviewOrderCancelledOrderPage');
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if(this.cancelOrderSubscription !== undefined){
            this.cancelOrderSubscription.unsubscribe()
        }
        if(this.existingSubscription !== undefined){
            this.existingSubscription.unsubscribe()
        }
    }

}
