import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DialogComponent } from '../../common/popup/dialog.component';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';
import { EnterpriseAddress } from './../../common/models/cart.model';
import { cloneDeep } from 'lodash';
import {
    Order, OrderSummary,
    Payment, Month,
    OrderRq, OrderNotes, ReviewProductInformation, AdditionalInfo, OrderRemarks
} from './../../common/models/order.model';
import { AccountInfo, AccountInfomation } from '../../common/models/account.model';
import { CreditCheck } from '../../common/models/credit-check.model';
import { AppStore } from '../../common/models/appstore.model';
import { Store } from '@ngrx/store';
import { AppStateService } from './../../common/service/app-state.service';
import { User } from '../../common/models/user.model';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../../common/logging/default-log.service';
import { GenericValues, APIErrorLists } from '../../common/models/common.model';
import { SystemErrorService } from '../../common/service/system-error.service';
import { AppointmentShipping } from '../../common/models/schedule-shipping.model';
import { HelperService } from '../../common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import "rxjs/add/operator/catch";
import { ReviewOrderHelperService } from '../services/reviewOrderHelper.service';
import { ReviewOrderVariables } from 'app/common/models/review.order.model';
import { AppConstant } from 'app/app.constant';

@Component({
    selector: 'review-order',
    styleUrls: ['./review-order.component.scss'],
    templateUrl: './review-order.component.html'
})

export class ReviewOrderComponent implements OnInit, OnDestroy {
    public userSubscription$: Subscription;
    public userdata: Observable<User>;
    public orderDetails: Observable<any>;
    public user: Observable<User>;
    public authUsers: any = [];
    public accountObservable: Observable<AccountInfomation>;
    public userSubscription: Subscription;
    public submitOrderObservable: Observable<any>;
    public submitOrderSubscription: Subscription;
    public orderSubscription: Subscription;
    public accountDetailsCollapsed = false;
    public currentTab = 'tab0';
    public productInformation: ReviewProductInformation = {
        terms: '',
        offerName: '',
        isAutopay: false,
        internetExpiry: '',
        prismExpiry: '',
        dhpExpiry: '',
        autopayRate: -1,
        etf: 0
    };
    public orderRefNumber: string;
    public processInstanceId: string;
    public taskId: string;
    public taskName: string;
    public creditRevObsv: Observable<CreditCheck>;
    public creditRevSubscription: Subscription;
    public billTask = {
        taskName: 'billQuote'
    };
    public errorMsg: string;
    public loading = false;
    public apiResponseError: APIErrorLists;
    public proRatedTotal: number;
    public proRatedTaxesTotal: number;
    public billQuote: any;
    public monthlyChargesTotal: number;
    public monthlyChargeTaxesTotal: number;
    public oneTimeChargesTotal: number;
    public oneTimeChargeTaxesTotal: number;
    public nextBill: any;
    public discountsTotal: number;
    public additionalMonthlyChargesTotal: number;
    public monthlyRecurringCharges: any;
    public oneTimeCharges: any;
    public otherTaxesAmount: number;
    public MonthlySet = {
        packageTotal: 0,
        voiceTotal: 0,
        broadbandTotal: 0
    };
    public oneTimeSet = {
        packageTotal: 0,
        voiceTotal: 0,
        broadbandTotal: 0
    };
    public proratedSet = {
        packageTotal: 0,
        voiceTotal: 0,
        broadbandTotal: 0
    };
    public surgchargesSet = {
        packageTotal: 0,
        voiceTotal: 0,
        broadbandTotal: 0
    };
    public discountsSet = {
        packageTotal: 0,
        voiceTotal: 0,
        broadbandTotal: 0
    };
    public apiResponseBillError: boolean;
    public apiResponseBillEmpty: boolean;
    
    public isDTV = false;
    public dtvForm = { taskName: '', accNo: '' };
    public dtvOrderingInfo: any;
    public dtvOptIn = false;
    public savedQuoteId: any;
    public isDHPAvailable = false;
    @ViewChild('simplePort', { static: false,}) public simplePortDialog: DialogComponent;
    public allday: any;
    public isDtvOpus: boolean;
    public isRCCacknowledged: any;
    public rccDone = false;
    public respData: any;
    public paidSecurityDeposit = false;
    public dealerId: string;
    public dealerName: string;
    public isMultipleDealerCode: boolean;
    public productDealerCodeInfo: any[] = [];
    public prodDealerCodeResponse: any;
    @ViewChild('changeSalesId', { static: false,}) public changeSalesId: DialogComponent;
    public dealerCodeChanged = false;
    public firstTimeLoad: boolean;
    public isDepositBypassed = false;
    public creditSubscription$: any;
    public creditData: Observable<any>;  
    public loginDetails:any ;
    public prepaidData:any;   
    public comments:any=[];
    public prepaidPayment = false;
    public showRefundBanner = false;
    public depositAmount: any;
    private reuseBan = false;
    public accountPin: any;
    private appointment: Observable<AppointmentShipping>;
    private retainObservable: Observable<any>;
    public isPaymentDone = false;
    public contactNumber = '';
    public schedulingURL = '';
    public productNameFromCart: any;
    public totalPrepaidCharge: any;
    public addressCity:string;
    public addressLine1:string;
    public addressLine2:string;
    public creditCheckflag = true;
    public reviewOrderVariables: ReviewOrderVariables;
    public agentFirstName: any;
    public agentLastName: any;
    public isAppointmentTime = false;
    public partnerInfo: any;
    public onholdRestrictedMsg = AppConstant.CANNOT_HOLD_PREPAID_AFTER_PAYMENT;

    constructor(
        private logger: Logger,
        private reviewOrderService: ReviewOrderService,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private router: Router,
        private systemErrorService: SystemErrorService,
        public helperService: HelperService,
        public ctlHelperService: CTLHelperService,
        public reviewOrderHelperService: ReviewOrderHelperService
    ) {
        this.reviewOrderVariables = this.reviewOrderHelperService.setReviewOrderVablesDefault(this.reviewOrderVariables);
        this.appStateService.setLocationURLs();
        this.retainObservable = this.store.select('retain');
        this.retainObservable.subscribe((respData) => {
            this.respData = respData;
            if (respData && respData !== undefined && respData.selectedappointment && respData.selectedappointment !== undefined && respData.selectedappointment.timeSlot && respData.selectedappointment.timeSlot !== undefined && respData.selectedappointment.timeSlot.startDateTime && respData.selectedappointment.timeSlot.startDateTime !== undefined) {
                this.allday = respData.selectedappointment.allDayAppt;
            }

        });
        this.user = this.store.select('user');
        let retrieveProducts = this.store.select('existingProducts');
        retrieveProducts.subscribe((data) => {
            if(data && data.orderFlow && data.orderFlow.flow)this.reviewOrderVariables.currentFlow = data.orderFlow.flow;
            if(data && data.pendingOrders && (data.pendingOrders.length > 0) && data.pendingOrders[0].orderReference
                && data.pendingOrders[0].orderReference.reason && (data.pendingOrders[0].orderReference.reason.length > 0)
                && data.pendingOrders[0].orderReference.reason[0].description) {
                this.reviewOrderVariables.isUnholdFlow = true;
            }
            if(data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.agentFirstName && data.autoLogin.oamData.agentLastName)
            {
                this.agentFirstName = data.autoLogin.oamData.agentFirstName;
                this.agentLastName = data.autoLogin.oamData.agentLastName;
            }    
        })
        this.appointment = this.store.select('appointment');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointment.subscribe((data) => {
                if (data && data.appointmentInfoNoValue){
                    this.isAppointmentTime = true;
                }
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    if (data.payload.cart || !data.payload.appointmentInfo) {
                        this.schedulingURL = '/schedule-appt-ship';
                    }
                    else {
                        this.schedulingURL = '/schedule-appt';
                    }
                    if (data.reservedCbr && data.reservedCbr !== null && data.reservedCbr !== undefined) {
                        this.contactNumber = data.reservedCbr
                    }

                }
            });
        }

        //Fetching speed for HSI product
        this.productNameFromCart = this.reviewOrderService.fetchPrimaryProductName();

        this.userSubscription = this.user.subscribe((data) => {
            if(data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes !== undefined){
                this.reviewOrderVariables.legacyProvider = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
            this.reviewOrderVariables.isPrepaid = data.prepaidFlag === 'PREPAID'?true:false;
            this.showRefundBanner = data.showRefundBanner && data.showRefundBanner.showBanner?true:false;
            this.depositAmount = data.showRefundBanner && data.showRefundBanner.amount? data.showRefundBanner.amount : '';    
            this.reviewOrderVariables.shippingName = data.shippingName;
            if (data.currentUrl !== null && data.currentUrl !== undefined) {
                this.reviewOrderVariables.currentPath = data.currentUrl;
            }
            if (data && data.finalAddress && data.finalAddress.addressLine) {
                this.addressCity = data.finalAddress.addressLine;
                this.addressLine1 = this.addressCity .split(",").slice(0,1).join();
                this.addressLine2 = this.addressCity .split(",").slice(1).join(); 
            } 
            this.isDtvOpus = data.isDtvOpus;
            if (Array.isArray(data.currentSelected)) {
                data.currentSelected.forEach((val: any) => {
                    if (val.selected === GenericValues.cDTV) {
                        this.isDTV = true;
                    }
                });

            }
            if(data.autoLogin.sfcData && data.autoLogin.sfcData.type && data.autoLogin.sfcData.type !== undefined) {
                this.reuseBan = (data.autoLogin.sfcData.type === 'ReopenBAN');
            }
        });

        this.accountObservable = this.store.select('account');
        this.accountObservable.subscribe((respData) => {
            if(respData.isAuthorizedParties !== undefined && respData.isAuthorizedParties !== null ) {
                this.authUsers= respData.isAuthorizedParties;
                this.reviewOrderVariables.authorizedParties = false; 
                this.reviewOrderVariables.oneAuthorzedParty = false; 
                if (this.authUsers[0].firstName !== "" || this.authUsers[1].firstName !== ""){
                    this.reviewOrderVariables.authorizedParties = true;
                }
                if (this.authUsers[0].firstName === "" || this.authUsers[1].firstName === ""){
                    this.reviewOrderVariables.oneAuthorzedParty = true; 
                }         
            }
        });

        if (this.reviewOrderVariables.currentPath === '/order-confirmation') {
            this.submitOrderObservable = this.store.select('order');
            this.submitOrderSubscription = this.submitOrderObservable.subscribe((data) => {
                this.loginDetails = data.loginDetails ? data.loginDetails :'';
                this.reviewOrderVariables.confirmOrder = data;
                this.accountDetailsCollapsed = true;
                this.reviewOrderVariables.ban = data && data.payload && data.payload.accountInfo && data.payload.accountInfo.ban;
                if (data && data.payload && data.payload.billEstimate) {
                    this.savedQuoteId = data.payload.billEstimate.quote && data.payload.billEstimate.quote.length > 0 ? data.payload.billEstimate.quote[0].quoteId : '';
                }
                    this.reviewOrderHelperService.getOrderDetails(data, this.reviewOrderVariables);

                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
                    if(this.reviewOrderVariables.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                        this.prepaidData = data.payload.currentBillQuote;
                        if(data.payload.currentBillQuote.firstMonthList
                            && data.payload.currentBillQuote.firstMonthList.totalCharges) {
                                this.totalPrepaidCharge = data.payload.currentBillQuote.firstMonthList.totalCharges;
                            }
                    }
                
            });
        } else if (this.reviewOrderVariables.currentPath === '/review-order') {
            this.firstTimeLoad = true;
            this.orderDetails = this.store.select('order');
            this.orderSubscription = this.orderDetails.subscribe((data) => {
                this.reviewOrderVariables.ban = data && data.payload && data.payload.accountInfo && data.payload.accountInfo.ban;
                this.loginDetails = data.loginDetails ? data.loginDetails :'';
                this.accountPin = data.Accountpasswordpin;
                this.accountDetailsCollapsed = true;
                this.dtvOrderingInfo = data.payload.hasOwnProperty('dtvOrderingInfo') ? data.payload.dtvOrderingInfo : {};
                if (this.dtvOrderingInfo && this.dtvOrderingInfo.dtvInstallDueDate) {
                    this.dtvOptIn = true;
                }
                this.orderRefNumber = data.orderRefNumber;
                if (data.productSalesIdInfo === undefined) {
                    this.getProductDealerCodeInfo(false);
                } else {
                    this.productDealerCodeInfo = data.productSalesIdInfo.productDealerCodeInfo;
                    this.isMultipleDealerCode = data.productSalesIdInfo.isMultipleDealerCode;
                    this.dealerCodeChanged = data.productSalesIdInfo.dealerCodeChanged;
                    if (!this.isMultipleDealerCode) {
                        this.dealerId = this.productDealerCodeInfo[0].dealerCode;
                        this.dealerName = this.productDealerCodeInfo[0].firstName + ' ' + this.productDealerCodeInfo[0].lastName;
                    }
                    if (this.firstTimeLoad) {
                        this.getProductDealerCodeInfo(false);
                    }
                }
                if (data && data.payload && data.payload.billEstimate) {
                    let bypassflag: boolean= false;
                    this.savedQuoteId = data.payload.billEstimate.quote && data.payload.billEstimate.quote.length > 0 ? data.payload.billEstimate.quote[0].quoteId : '';
                    this.reviewOrderVariables.actualAmount = 0;
                    this.reviewOrderVariables.paidAmount = 0;
                    let _that = this;
                    this.creditRevObsv = this.store.select('creditReview');
                    this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                        if (creditData && creditData.payload && creditData.payload !== undefined && creditData.payload.paymentDetails && creditData.payload.paymentDetails !== undefined && creditData.payload.paymentDetails.depositPaymentStatus === "PAID") {
                            this.reviewOrderVariables.allPaymentDone = true;
                            this.paidSecurityDeposit = true;
                        }
                        creditData.payload.addlOrderAttributes.map((data) => {
                            data && data.orderAttributeGroup && data.orderAttributeGroup.map((depositData) => {
                                if (depositData && depositData.orderAttributeGroupName === "depositData") {
                                    depositData.orderAttributeGroupInfo.map((data) => {
                                        data && data.orderAttributes.map((paymentData) => {
                                            if (paymentData && paymentData.orderAttributeName === "refundReqd" && paymentData.orderAttributeValue === "true") {
                                                this.reviewOrderVariables.isrefundAvail = true;
                                            }
                                        
                                        })
                                    })
                                }
                                if (depositData && depositData.orderAttributeGroupName === "bypassCreditCheck") {
                                    depositData.orderAttributeGroupInfo.map((data) => {
                                        data && data.orderAttributes.map((paymentData) => {
                                         
                                            if (paymentData && paymentData.orderAttributeName === "creditCheckBypassed" && paymentData.orderAttributeValue === "true") {
                                                bypassflag = true;
                                            }
                                        })
                                    })
                                }
                            })
                        })
                       
                        if(creditData.payload.creditInfo.creditApplicationRefNumber === "00000000000000" && !bypassflag)
                        {
                            this.creditCheckflag = false;
                        
                        }
                        if (!this.reviewOrderVariables.isPrepaid && (creditData.payload.depositInfo.depositRequired || (creditData && creditData.payload && creditData.payload.creditInfo && creditData.payload.creditInfo.finalBillInfo && creditData.payload.creditInfo.finalBillInfo.length))) {
                            if (creditData && creditData.payload && creditData.payload.depositInfo && creditData.payload.depositInfo.products && (creditData.payload.depositInfo.products.length > 0)) {
                                for (let i = 0; i < creditData.payload.depositInfo.products.length; i++) {
                                    _that.reviewOrderVariables.actualAmount += creditData.payload.depositInfo.products[i].depositAmount.amount;
                                }
                            }
                            if (creditData && creditData.payload && creditData.payload.creditInfo && creditData.payload.creditInfo.finalBillInfo && (creditData.payload.creditInfo.finalBillInfo.length > 0)) {
                                for (let j = 0; j < creditData.payload.creditInfo.finalBillInfo.length; j++) {
                                    _that.reviewOrderVariables.actualAmount += creditData.payload.creditInfo.finalBillInfo[j].finalBillAmt.amount;
                                }
                            }
                            if (data && data.payload && data.payload.paymentInfo && (data.payload.paymentInfo.length > 0)) {
                                for (let j = 0; j < data.payload.paymentInfo.length; j++) {
                                    if(data.payload.paymentInfo[j].billingAccountId === this.reviewOrderVariables.ban){
                                        _that.reviewOrderVariables.paidAmount += data.payload.paymentInfo[j].paidAmount;
                                    }
                                }
                            }
                            if (_that.reviewOrderVariables.actualAmount === _that.reviewOrderVariables.paidAmount) {
                                this.isPaymentDone = true;
                            } else {
                                this.isPaymentDone = false;
                            }
                            if(creditData && creditData.payload && creditData.payload.creditInfo && creditData.payload.creditInfo.finalBillInfo && creditData.payload.creditInfo.finalBillInfo.length > 0 
                                && creditData.payload.depositInfo && creditData.payload.depositInfo.depositRequired){
                                creditData && creditData.payload && creditData.payload.paymentDetails && creditData.payload.paymentDetails.finalBillPaymentStatus === 'PAID'
                                    && creditData.payload.paymentDetails.depositPaymentStatus === 'PAID' ? this.isPaymentDone = true : this.isPaymentDone = false;
                            }
                        }else if(this.reviewOrderVariables.isPrepaid){
                            this.isPaymentDone = true;
                        } else {
                            this.isPaymentDone = true; 
                        }
                        if (this.reviewOrderVariables.isrefundAvail && this.reviewOrderVariables.allPaymentDone) {
                            this.isPaymentDone = true;
                        }
                        if(creditData && creditData.credit_detail && creditData.credit_detail.prepaidPaymentStatus ){
                            this.prepaidPayment = true
                          }
                    });
                    this.creditRevSubscription.unsubscribe();
                    
                    this.reviewOrderHelperService.getOrderDetails(data, this.reviewOrderVariables);

                    let x = data.offerSummary;
                    let y = data.offers;
                    let combinedObj = {
                        offerSummary: x,
                        offers: y
                    };
                    this.reviewOrderHelperService.getProductDetails(combinedObj, this.reviewOrderVariables);
                }
                if(this.reviewOrderVariables.isPrepaid && data && data.payload && data.payload.currentBillQuote){
                    this.prepaidData = data.payload.currentBillQuote
                }
            });
        }
    }    

    public ngOnInit() {
        let pageName;
        if (this.reviewOrderVariables.currentPath === '/order-confirmation') {
            pageName = 'OrderConfirmationPage';
        }
        else {
            pageName = 'ReviewOrderPage';
        }
        this.logger.metrics(pageName);
        this.userdata = this.store.select('user');
        this.userSubscription$ = this.userdata.subscribe(
            (userdata) => {
                if (userdata && userdata.selfinstallselected !== undefined && userdata.selfinstallselected) {
                    this.reviewOrderVariables.selfInstallSel = userdata.selfinstallselected;
                } else {
                    this.reviewOrderVariables.selfInstallSel = false;
                }
            });
        this.creditData = this.store.select('creditReview');
        if(!this.reviewOrderVariables.isPrepaid) { 
            this.creditSubscription$ = this.creditData.subscribe((data)=>{
                if(data && data.payload && data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.length > 0 && data.payload.addlOrderAttributes[1] &&  data.payload.addlOrderAttributes[1].orderAttributeGroup && data.payload.addlOrderAttributes[1].orderAttributeGroup.length > 0 &&data.payload.addlOrderAttributes[1].orderAttributeGroup 
                    && data.payload.addlOrderAttributes[1].orderAttributeGroup[0].orderAttributeGroupInfo  && data.payload.addlOrderAttributes[1].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes 
                    && data.payload.addlOrderAttributes[1].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue){
                    this.isDepositBypassed = true;
                }
            });
        }
        //this.creditSubscription$.unsubscribe();
        window.scroll(0, 0);
    }

    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.submitOrderSubscription !== undefined) {
            this.submitOrderSubscription.unsubscribe();
        }
    }

    /**
     * To set the clicked pricing Tab active & update respective tab summary amount
     * @param tab as string
     * @param month which describe prices for particular month
     */
    public setActive(tab: string, month: Month) {
        this.currentTab = tab;
        this.reviewOrderVariables.billCharges = month.charges;
        this.reviewOrderVariables.currentMonthNo = month.monthId;
        this.reviewOrderVariables.RCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };
        this.reviewOrderVariables.OTCBillSummary = {
            totalBillAmount: 0,
            totalDiscount: 0,
            totalTaxes: 0
        };

        for (let k in this.reviewOrderVariables.billCharges) {
            if (this.reviewOrderVariables.billCharges[k].chargeType === 'RC') {
                this.reviewOrderVariables.RCBillSummary = this.reviewOrderVariables.billCharges[k].summary;
                break;
            }
        }
        for (let k in this.reviewOrderVariables.billCharges) {
            if (this.reviewOrderVariables.billCharges[k].chargeType === 'OTC') {
                this.reviewOrderVariables.OTCBillSummary = this.reviewOrderVariables.billCharges[k].summary;
                break;
            }
        }

        this.reviewOrderVariables.summaryTotal =
            (this.reviewOrderVariables.RCBillSummary.totalBillAmount +
                this.reviewOrderVariables.OTCBillSummary.totalBillAmount +
                this.reviewOrderVariables.RCBillSummary.totalTaxes +
                this.reviewOrderVariables.OTCBillSummary.totalTaxes) -
            (this.reviewOrderVariables.RCBillSummary.totalDiscount +
                this.reviewOrderVariables.OTCBillSummary.totalDiscount);
    }

    /**
     * To check/set the diable notification checkbox boolean
     */
    /* public checkNotification() {
        this.checkNotificationlink = false;
        this.checkNotificationCheckbox = true;
    } */

    /**
     * To validate pricing details checked & deposits if required taken
     */
    public checkOrder() {
        if ((this.reviewOrderVariables.rccDone) && (this.isPaymentDone || this.isDepositBypassed)) {
            this.submitOrder(this.reviewOrderVariables.isRCCacknowledged,
                this.reviewOrderVariables.additioanalNotes.text, this.reviewOrderVariables.disableNotification, this.reviewOrderVariables.orderObject);
        } else {
            this.reviewOrderVariables.checkOrderConfirmation = true;
        }
    }
    /* public AcknowledgeRCCs() {
        this.rccDone = true;
        if (this.rccDone) {
            this.isRCCacknowledged = "Yes";
        } else {
            this.isRCCacknowledged = "No";
        }
    } */
    public takeUserToAccountPage() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.submitOrderSubscription !== undefined) {
            this.submitOrderSubscription.unsubscribe();
        }
        this.submitOrder(this.reviewOrderVariables.pricingConfirmation,
            this.reviewOrderVariables.additioanalNotes.text, this.reviewOrderVariables.disableNotification, this.reviewOrderVariables.orderObject);
    }

    public isAcknowledged(event) {
        this.reviewOrderVariables.isRCCacknowledged = event.isrccAcknowledged;
        if (this.reviewOrderVariables.isRCCacknowledged === "Yes") {
            this.reviewOrderVariables.rccDone = false;
        } else {
            this.reviewOrderVariables.rccDone = true;
        }
    }


    /**
     * To scroll upto the Pricing block if not acknowledged
     * @param element as clicked pricing check dom element
     */
    public checkPricingAck(element) {
        window.scrollTo(0, document.getElementById(element).offsetTop - 140);
    }

    /**
     * To summary of bill for a month
     * @param charges for a month
     */
    public getTabSummaryTotal(charges) {
        let totalBill = 0;
        let totalDiscounts = 0;
        let totalTaxes = 0;
        charges.map((charge) => {
            if (Object.keys(charge.summary) && (Object.keys(charge.summary).length > 0)) {
                totalBill += charge.summary['totalBillAmount'];
                totalDiscounts += charge.summary['totalDiscount'];
                totalTaxes += charge.summary['totalTaxes'];
            }
        });
        return totalBill + totalTaxes - totalDiscounts;
    }

    /**
     * To get Bill Cycle in format xth of each month
     * @param day
     */
    /* public getBillCycleDay(day) {
        let suffixes = ['th', 'st', 'nd', 'rd'];
        let relevantDigits = (day < 30) ? day % 20 : day % 30;
        let suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
        return day + suffix;
    } */

    /**
     * To mask phone number as pe USA format (xxx-xx-xxxx)
     * @param data as response
     */
    public maskPhone(phone: string) {
        if (phone) {
            return phone.substr(0, 3) + '-' + phone.substr(3, 3) + '-' + phone.substr(6);
        }
    }

    /**
     * submit request from order summary page
     * @param pricingConfirmation as pricing ack
     * @param additionalNotes entered notes
     * @param disableNotifications checkbox checked or not
     * @param order fetching refnumber, taskId
     */
    public submitOrder(pricingConfirmation: string, additionalNotes: string,
        disableNotifications: boolean, order) {
        this.loading = true;
        let chargeSummaryAck: boolean;
        chargeSummaryAck = pricingConfirmation && pricingConfirmation === 'Yes' ? true : false;
        let additionalInfo: AdditionalInfo = {
            chargeSummaryAck,
            disableOrderNotification: disableNotifications
        }
        
        
        let remark: OrderRemarks = {
            name: 'Order Remarks',
            value: additionalNotes,
            date: new DatePipe('en-US').transform(new Date(), 'mediumDate'),
            author: this.agentFirstName + ' ' + this.agentLastName
        }
       
        let dealerCodeChangeInfo = [];
        this.productDealerCodeInfo.forEach((prod) => {
            if (prod.changed) {
                let prodInfo = {
                    offerCategory: prod.offerCategory,
                    productType: prod.productType,
                    productname: prod.productname,
                    dealerCode: prod.dealerCode,
                    firstName: prod.firstName,
                    lastName: prod.lastName
                }
                dealerCodeChangeInfo.push(prodInfo);
            }
        });
        
        let payload: OrderNotes = {
            additionalInfo: additionalInfo,
            orderRemarks: [remark],
            dealerCodeChangeInfo: dealerCodeChangeInfo,
            partnerInfo: this.partnerInfo
        };
        
      

        let request: OrderRq = {
            orderRefNumber: order.orderRefNumber,
            processInstanceId: order.processInstanceId,
            taskId: order.taskId,
            taskName: order.taskName,
            payload
        };
        
      
        this.store.dispatch({ type: 'CONFIRM_ORDER', payload: payload });
        let newRequest= cloneDeep(request);
        if(this.creditCheckflag === false)
        {
               newRequest.payload.orderRemarks[0].value= newRequest.payload.orderRemarks[0].value.length>1? newRequest.payload.orderRemarks[0].value+ ' Credit Check Failed!':  newRequest.payload.orderRemarks[0].value+ 'Credit Check Failed!'
            
        }
        if(newRequest.payload.orderRemarks[0].value === '')
        {
               delete newRequest.payload.orderRemarks;
            
        }
        let errorResolved = false;
        this.loading = true;
        this.logger.log("info", "review-order.component.ts", "postSubmitTaskServiceRequest", JSON.stringify(newRequest));
        this.logger.startTime();
        this.reviewOrderService.postSubmitTaskService(newRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "review-order.component.ts", "postSubmitTaskServiceResponse", error);
                this.logger.log("error", "review-order.component.ts", "postSubmitTaskServiceSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "submitTask - postSubmitTaskService", "review-order.component.ts",
                    "Review Order Page",
                    error);
                return Observable.throwError(null);

            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    if (this.reviewOrderVariables.isUnholdFlow) {
                        this.logger.log("info", "review-order.component.ts", "postSubmitTaskServiceResponse", JSON.stringify(data),this.reviewOrderVariables.legacyProvider);
                        this.logger.log("info", "review-order.component.ts", "postSubmitTaskServiceSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "unhold.component.ts", "orderCompletedUnholdNI", '{"TotalTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');    
                    } else {
                        this.logger.log("info", "review-order.component.ts", "postSubmitTaskServiceResponse", JSON.stringify(data),this.reviewOrderVariables.legacyProvider);
                        this.logger.log("info", "review-order.component.ts", "postSubmitTaskServiceSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.logger.log("info", "review-order.component.ts", "orderCompletedNI", '{"TotalTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    }  
                    if (data && data.errorResponse && data.errorResponse[0] !== undefined && data.errorResponse[0].reasonCode && data.errorResponse[0].reasonCode !== undefined && (data.errorResponse[0].reasonCode === 'SIMPLE_PORT_FAILURE' || data.errorResponse[0].reasonCode === 'SIMPLE_PORT_SCHEDULING_FAILURE')) {
                        if (data.taskId) this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                        this.loading = false;
                        this.simplePortDialog.open();
                    }
                    else {
                        this.reviewOrderVariables.confirmOrder = data;
                        if (data.taskName === 'Credit Review') {
                            this.store.dispatch({ type: 'CREDIT_REVIEW', payload: data });
                            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            if(this.reuseBan) {
                                this.router.navigate(['/reuse-ban-account']);
                            } else {
                                this.router.navigate(['/account']);
                            }
                            
                        } else if (order.payload.orderSummary !== undefined) {
                            let submitData = Object.assign({}, order, this.reviewOrderVariables.confirmOrder.payload);
                            this.router.navigate(['/order-confirmation']);
                            this.store.dispatch({ type: 'CONFIRM_ORDER', payload: submitData });
                        }

                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "review-order.component.ts", "postSubmitTaskServiceResponse", JSON.stringify(error));
                        this.logger.log("error", "review-order.component.ts", "postSubmitTaskServiceSrvc", '{"TotalTime" : "' + this.logger.calculateTotalDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", order.taskName, "review-order.component.ts", "Order Summary Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", order.taskName, "review-order.component.ts", "Order Summary Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }
    public changeSalesIdDialog() {
        if (this.productDealerCodeInfo === undefined || this.productDealerCodeInfo.length === 0) {
            this.getProductDealerCodeInfo(true);
        } else {
            this.productDealerCodeInfo.forEach((prod) => prod.changeId = prod.chnageAllowed);
            this.changeSalesId.open();
        }
    }

    private getProductDealerCodeInfo(openDialog: boolean) {
        let request = {
            orderReferenceNumber: this.orderRefNumber,
            salesChannel: 'ESHOp-Customer Care'
        }
        let errorResolved = false;
        this.loading = true;
        this.logger.log("info", "review-order.component.ts", "productDealerCodeInfoRequest", JSON.stringify(request));
        this.logger.startTime();
        this.reviewOrderService.retrieveProductDealerCodeInfo(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "review-order.component.ts", "productDealerCodeInfoErrorResponse", error);
                this.logger.log("error", "review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "retrieveProductDealerCodeInfo", "review-order.component.ts",
                    "Review Order Page",
                    error);
                return Observable.throwError(null);

            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "review-order.component.ts", "productDealerCodeInfoResponse", JSON.stringify(data));
                    this.logger.log("info", "review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.prodDealerCodeResponse = data;
                    const prodNameMap = {
                        'INTERNET': {
                            'name': 'Internet',
                            'imgUrl': './assets/img/internet_sm.png',
                            'dealerInfo': ''
                        },
                        'VOICE-HP': {
                            'name': 'Home Phone',
                            'imgUrl': './assets/img/phone_sm.png',
                            'dealerInfo': ''
                        },
                        'VIDEO-DTV': {
                            'name': 'DIRECTV',
                            'imgUrl': './assets/img/tv_sm.png',
                            'dealerInfo': ''
                        },
                        'CENTURYLINK @ EASE': {
                            'dealerInfo': ''
                        }
                    };
                    let previousProdDealerCodeInfo = this.productDealerCodeInfo;
                    /* Retaining previously saved dealer code for reentrant scenario */
                    if (previousProdDealerCodeInfo && (previousProdDealerCodeInfo.length > 0)) {
                        previousProdDealerCodeInfo.forEach((prodInfo) => {
                            if (prodInfo.changed) {
                                if ((prodInfo.productname).indexOf('EASE') !== -1) {
                                    prodNameMap[prodInfo.productname].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                } else {
                                    prodNameMap[prodInfo.productType].dealerInfo = {
                                        dealerCode: prodInfo.dealerCode,
                                        firstName: prodInfo.firstName,
                                        lastName: prodInfo.lastName
                                    }
                                }
                            }
                        });
                    }
                    this.productDealerCodeInfo = [];
                    let dealerCodeArray = [];
                    let displayInternet = false;
                    let displayVoice = false;
                    this.prodDealerCodeResponse && this.prodDealerCodeResponse.productDealerCodeInfo.map((prodInfo) => {
                        if (prodInfo.isDisplay.toUpperCase() === 'YES') {
                            let isEase = ((prodInfo.productname).indexOf('EASE') !== -1);
                            let prodInfoObject = {
                                prodName: isEase ? prodInfo.productname : prodNameMap[prodInfo.productType],
                                firstName: prodInfo.firstName,
                                lastName: prodInfo.lastName,
                                dealerCode: prodInfo.dealerCode,
                                chnageAllowed: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                changeId: (prodInfo.dealerCodeChangeAllowed.toUpperCase() === 'YES'),
                                offerCategory: prodInfo.offerCategory,
                                productType: prodInfo.productType,
                                productname: prodInfo.productname,
                            }
                            if (isEase || prodInfo.productType === 'VIDEO-DTV') {
                                prodInfoObject['display'] = true;
                            }
                            if (!displayInternet && !isEase && prodInfo.productType === 'INTERNET') {
                                prodInfoObject['display'] = true;
                                displayInternet = true;
                            }
                            if (!displayVoice && prodInfo.productType === 'VOICE-HP') {
                                prodInfoObject['display'] = true;
                                displayVoice = true;
                            }
                            if (previousProdDealerCodeInfo && (previousProdDealerCodeInfo.length > 0)) {
                                let priviouslySavedValue = isEase ? prodNameMap[prodInfo.productname].dealerInfo : prodNameMap[prodInfo.productType].dealerInfo;
                                if (priviouslySavedValue !== '') {
                                    prodInfoObject.dealerCode = priviouslySavedValue.dealerCode;
                                    prodInfoObject.firstName = priviouslySavedValue.firstName;
                                    prodInfoObject.lastName = priviouslySavedValue.lastName;
                                    prodInfoObject['changed'] = true;
                                }
                            }
                            dealerCodeArray.push(prodInfoObject.dealerCode);
                            this.productDealerCodeInfo.push(prodInfoObject);
                        }
                    });

                    if (this.firstTimeLoad) {
                        this.isMultipleDealerCode = !dealerCodeArray.every((val) => (val === dealerCodeArray[0]));
                    }
                    this.firstTimeLoad = false;
                    let payLoad = {
                        productDealerCodeInfo: this.productDealerCodeInfo,
                        isMultipleDealerCode: this.isMultipleDealerCode,
                        dealerCodeChanged: this.dealerCodeChanged
                    }
                    this.store.dispatch({ type: 'PROD_DEALER_ID', payload: payLoad });
                    if (openDialog)
                        this.changeSalesId.open();
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
		                this.logger.log("error", "review-order.component.ts", "productDealerCodeInfoErrorResponse", error);
                        this.logger.log("error", "review-order.component.ts", "productDealerCodeInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (error === undefined || error === null)
                        return;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "review-order.component.ts", "Order Summary Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveProductDealerCodeInfo", "review-order.component.ts", "Order Summary Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    public updateSaleID(event) {
        this.partnerInfo = event;
    }
}