import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Router } from '@angular/router';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { GenericValues, APIErrorLists } from '../../common/models/common.model';
import { Logger } from 'app/common/logging/default-log.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { ReviewOrderVariables } from 'app/common/models/review.order.model';

@Injectable()
export class ReviewOrderHelperService {
    constructor(private logger: Logger, public store: Store<any>, private router: Router, private ctlHelperService: CTLHelperService, private systemErrorService: SystemErrorService, private reviewOrderService: ReviewOrderService) {        
    }

    public fetchPrice(device) {
        if (device && device.purchasePrice) {
            if (device.purchasePrice.discountedRc > 0) {
                return device.purchasePrice.discountedRc;
            }
            if (device.purchasePrice.rc > 0) {
                return device.purchasePrice.rc;
            }
            if (device.purchasePrice.discountedOtc > 0) {
                return device.purchasePrice.discountedOtc;
            }
            if (device.purchasePrice.otc > 0) {
                return device.purchasePrice.otc;
            }
        }
    }

    protected checkNotification(reviewOrderVariables: ReviewOrderVariables) {
        reviewOrderVariables.checkNotificationlink = false;
        reviewOrderVariables.checkNotificationCheckbox = true;
    }

    public setReviewOrderVablesDefault(reviewOrderVariables: ReviewOrderVariables){
        reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables.checkNotificationlink = true;
        reviewOrderVariables.checkNotificationCheckbox = false;
        reviewOrderVariables.isUnholdFlow = false;
        reviewOrderVariables.allPaymentDone = false;
        reviewOrderVariables.isrefundAvail = false;
        reviewOrderVariables.selfInstallSel = false;
        reviewOrderVariables.selfInstall = false;
        reviewOrderVariables.actualAmount = 0;
        reviewOrderVariables.paidAmount = 0;
        reviewOrderVariables.billingOptions = [];
        reviewOrderVariables.marketingPreferences = [];
        reviewOrderVariables.premisesInfo = [];
        reviewOrderVariables.techRemarks = false;
        reviewOrderVariables.additioanalNotes = {  text: '' };
        reviewOrderVariables.authorizedParties = false;
        reviewOrderVariables.oneAuthorzedParty = true;
        reviewOrderVariables.authUsers = [];
        reviewOrderVariables.pricingConfirmation = '';
        reviewOrderVariables.billCharges = [];
        reviewOrderVariables.accountDetailsCollapsed = false;
        reviewOrderVariables.currentTab = 'tab0';
        reviewOrderVariables.productInformation = {
            terms: '',
            offerName: '',
            isAutopay: false,
            internetExpiry: '',
            prismExpiry: '',
            dhpExpiry: '',
            autopayRate: -1,
            etf: 0
        };
        reviewOrderVariables.loading = false;
        reviewOrderVariables.MonthlySet = {
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        };
        reviewOrderVariables.oneTimeSet = {
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        };
        reviewOrderVariables.proratedSet = {
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        };
        reviewOrderVariables.surgchargesSet = {
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        };
        reviewOrderVariables.discountsSet = {
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        };
        reviewOrderVariables.isDTV= false;
        reviewOrderVariables.dtvForm= { taskName: '', accNo: '' };
        reviewOrderVariables.dtvOptIn = false;
        reviewOrderVariables.isdepositCollected = true;
        reviewOrderVariables.isDHPAvailable = false;
        reviewOrderVariables.rccDone = false;
        reviewOrderVariables.paidSecurityDeposit = false;
        reviewOrderVariables.productDealerCodeInfo = [];
        reviewOrderVariables.dealerCodeChanged = false;
        reviewOrderVariables.isDepositBypassed = false;  
        reviewOrderVariables.isPrepaid = false;  
        reviewOrderVariables.comments = [];
        reviewOrderVariables.prepaidPayment = false;
        reviewOrderVariables.showRefundBanner = false;
        reviewOrderVariables.reuseBan =  false;
        reviewOrderVariables.isPaymentDone = false ;
        reviewOrderVariables.contactNumber = '';
        reviewOrderVariables.schedulingURL = '';
        reviewOrderVariables.creditCheckflag = true;
        reviewOrderVariables.paymentDone = false;
        reviewOrderVariables.emailNotExist = false;
        return reviewOrderVariables;
    }
    
    private emailCheck(reviewOrderVariables, flowName) {
        if(flowName !== 'billing') {
            if(reviewOrderVariables.accountInfo && reviewOrderVariables.accountInfo.contact) reviewOrderVariables.emailNotExist = reviewOrderVariables.accountInfo.contact.emailAddrDeclined;
            if(flowName === 'Change') {
                if (reviewOrderVariables.isDHPAvailable) {
                    reviewOrderVariables.emailNotExist ? reviewOrderVariables.emailValidChecked = false : reviewOrderVariables.emailValidChecked = true;
                } else {
                    reviewOrderVariables.emailValidChecked = true;
                }
            }
        }
    }
    private prismDetails(reviewOrderVariables) {
        if (reviewOrderVariables.orderObject && reviewOrderVariables.orderObject.payload && reviewOrderVariables.orderObject.payload.returnEquipments && reviewOrderVariables.orderObject.payload.returnEquipments.length > 0) {
            reviewOrderVariables.returnEquipmentData = reviewOrderVariables.orderObject.payload.returnEquipments;
            reviewOrderVariables.returnEquipmentData.map((item) => {
                if (item.offerCategory === 'VIDEO-PRISM') reviewOrderVariables.removedPrismPrice = item.purchasePrice.discountedOtc;
            });
            if (reviewOrderVariables.orderObject.payload.returnDateOfEquipment) {
                reviewOrderVariables.returnDate = reviewOrderVariables.orderObject.payload.returnDateOfEquipment;
            }
        }
    }
    private updateTechRemark (premiseInfo, reviewOrderVariables) {
        premiseInfo.notes.map((tech) => {
            if(tech.value !== "" && tech.value !== null){
                reviewOrderVariables.techRemarks = true;
            }
        });
    }

    private splitDueDateEligibleCheck(reviewOrderVariables: ReviewOrderVariables, addlOrderAttributes) {
        if (addlOrderAttributes && addlOrderAttributes[0].orderAttributeGroup.length > 0) {
            addlOrderAttributes[0].orderAttributeGroup.map((chkDueDate) => {
                if (chkDueDate.orderAttributeGroupName === "splitDueDateInfo") {
                    chkDueDate.orderAttributeGroupInfo.map((groupInfo => {
                        groupInfo.orderAttributes.map(odrAttributes => {
                            if (odrAttributes.orderAttributeName === "fromFinalDueDate") {
                                reviewOrderVariables.oldLocationDueDate = odrAttributes.orderAttributeValue;
                            }
                        })
                    }))
                }
            })
        }
    }

    /**
     * To get Bill Cycle in format xth of each month
     * @param day
     */
    public getBillCycleDay(day) {
        let suffixes = ['th', 'st', 'nd', 'rd'];
        let relevantDigits = (day < 30) ? day % 20 : day % 30;
        let suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
        return day + suffix;
    }
    public AcknowledgeRCCs(reviewOrderVariables:ReviewOrderVariables) {
        reviewOrderVariables.rccDone = true;        
        reviewOrderVariables.isRCCacknowledged = "Yes";        
    }

    public getProductDetails(data: any, reviewOrderVariables:ReviewOrderVariables) {
        if (data.offers && data.offers[0] && data.offers[0].catalogs[0] && data.offers[0].catalogs[0].catalogItems[0] && data.offers[0].catalogs[0].catalogItems.length>0) {
            if (reviewOrderVariables.productInformation && reviewOrderVariables.productInformation.terms
                && data.offers[0].catalogs[0].catalogItems[0].productOffer && data.offers[0].catalogs[0].catalogItems[0].productOffer.contract && data.offers[0].catalogs[0].catalogItems[0].productOffer.contract.contractTerm) {
                reviewOrderVariables.productInformation.terms =
                    data.offers[0].catalogs[0].catalogItems[0].productOffer.contract.contractTerm;
            }
            if (reviewOrderVariables.productInformation && reviewOrderVariables.productInformation.etf
                && data.offers[0].catalogs[0].catalogItems[0].productOffer && data.offers[0].catalogs[0].catalogItems[0].productOffer.contract && data.offers[0].catalogs[0].catalogItems[0].productOffer.contract.etf) {
                reviewOrderVariables.productInformation.etf =
                    data.offers[0].catalogs[0].catalogItems[0].productOffer.contract.etf;
            }

            if (data.offers[0].serviceCategory === 'Internet,') {
                if (reviewOrderVariables.productInformation && reviewOrderVariables.productInformation.offerName
                    && data.offers[0].catalogs[0].catalogItems[0].productOffer && data.offers[0].catalogs[0].catalogItems[0].productOffer.offerName) {
                    reviewOrderVariables.productInformation.offerName =
                        data.offers[0].catalogs[0].catalogItems[0].productOffer.offerName;
                }
            } else if (data.offers[0].serviceCategory === 'Internet,TV' || data.offers[0].serviceCategory === 'Internet,Phone' || data.offers[0].serviceCategory === 'Internet,DHPhone' || data.offers[0].serviceCategory === 'Internet,HMPhone') {
                let items = data.offers[0].catalogs;
                let nameArray = [];
                if (items !== undefined) {
                    items.map((item) => {
                        if (item.catalogItems[0] !== undefined) {
                            if (item.catalogItems[0].productOffer && item.catalogItems[0].productOffer.offerName) {
                                nameArray.push(item.catalogItems[0].productOffer.offerName);
                            }
                        }
                    });
                }
                reviewOrderVariables.productInformation.offerName = nameArray.join(' + ');

            }
            if (data.offers[0].catalogs[0].catalogItems[0].productOffer && data.offers[0].catalogs[0].catalogItems[0].productOffer.offerAttributes) {
                let offerAttributes = data.offers[0].catalogs[0].catalogItems[0].productOffer.offerAttributes;
                if (offerAttributes !== undefined) {
                    offerAttributes.map((attr) => {
                        reviewOrderVariables.productInformation.isAutopay =
                            (attr.name === 'autoPay' && attr.value === 'YES') ? true : false;
                    });
                }
            }

            if (data.offers[0].serviceCategory === 'Internet,' && data.offers[0].catalogs[0].catalogItems[0].productOffer &&
                data.offers[0].catalogs[0].catalogItems[0].productOffer.validFor) {
                    reviewOrderVariables.productInformation.internetExpiry =
                    data.offers[0].catalogs[0].catalogItems[0].
                        productOffer.validFor.saleExpirationDate;
            } else if (data.offers[0].serviceCategory === 'Internet,TV' && data.offers[0].catalogs[0].catalogItems[0].productOffer &&
            data.offers[0].catalogs[0].catalogItems[0].productOffer.validFor) {
                data.offers[0].catalogs.map((catalog) => {
                    if ((catalog.offerCategory === GenericValues.sData ||
                        catalog.offerCategory === GenericValues.iData) &&
                        catalog.catalogItems[0].productOffer.validFor) {
                            reviewOrderVariables.productInformation.internetExpiry =
                            catalog.catalogItems[0].productOffer.validFor.saleExpirationDate;
                    } else if (catalog.offerCategory === 'VIDEO' &&
                        catalog.catalogItems[0]  !== undefined && data.offers[0].catalogs[0].catalogItems[0].productOffer &&
                        data.offers[0].catalogs[0].catalogItems[0].productOffer.validFor) {
                            if (catalog.catalogItems[0].productOffer.validFor) {
                                reviewOrderVariables.productInformation.prismExpiry =
                                catalog.catalogItems[0].productOffer.validFor.saleExpirationDate;
                            }
                        }
                });
            } else if (data.offers[0].serviceCategory === 'Internet,DHPhone' && data.offers[0].catalogs[0].catalogItems[0].productOffer &&
            data.offers[0].catalogs[0].catalogItems[0].productOffer.validFor) {
                data.offers[0].catalogs.map((catalog) => {
                    if ((catalog.offerCategory === GenericValues.sData ||
                        catalog.offerCategory === GenericValues.iData) &&
                        catalog.catalogItems[0].productOffer.validFor) {
                            reviewOrderVariables.productInformation.internetExpiry =
                            catalog.catalogItems[0].productOffer.validFor.saleExpirationDate;
                    } else if (catalog.offerCategory === 'VOICE-DHP' &&
                        catalog.catalogItems[0].productOffer.validFor) {
                            reviewOrderVariables.isDHPAvailable = true;
                        reviewOrderVariables.productInformation.dhpExpiry =
                            catalog.catalogItems[0].productOffer.validFor.saleExpirationDate;
                    }
                });
            }
            let discountCheck = data.offers && data.offers[0] && data.offers[0].catalogs && data.offers[0].catalogs[0].productOfferings &&
                                data.offers[0].catalogs[0].productOfferings[0] && data.offers[0].catalogs[0].productOfferings[0].productOffer &&
                                data.offers[0].catalogs[0].productOfferings[0].productOffer.offerProductComponents &&
                                data.offers[0].catalogs[0].productOfferings[0].productOffer.offerProductComponents[0] && 
                                data.offers[0].catalogs[0].productOfferings[0].productOffer.offerProductComponents[0].product.prices &&
                                data.offers[0].catalogs[0].productOfferings[0].productOffer.offerProductComponents[0].product.prices[0] && 
                                data.offers[0].catalogs[0].productOfferings[0].productOffer.offerProductComponents[0].product.prices[0].discounts;
            if (discountCheck) {
                discountCheck.map((discount) => {
                    if (discount.discountDescription === 'NIC AutoPay Promotion') {
                        reviewOrderVariables.productInformation.autopayRate = discount.discountRate;
                    }
                });
            }
        }
    }

    public getOrderDetails(data, reviewOrderVariables) {
        if (data && data.length === undefined && data !== null) {
            let premiseInfo: any;
            if (data.payload && data.payload.orderSummary && reviewOrderVariables.previousUrl !== '/pending-order') {
                reviewOrderVariables.orderObject = data;
                reviewOrderVariables.orderSummary = reviewOrderVariables.orderObject.payload.orderSummary;
                reviewOrderVariables.additionalInfo = reviewOrderVariables.orderObject.payload.additionalInfo;
                reviewOrderVariables.requestedTN = reviewOrderVariables.orderObject.payload.orderSummary.reservedTN;
                if (reviewOrderVariables.currentFlow !== 'billing') {
                    reviewOrderVariables.accountInfo = reviewOrderVariables.orderObject.payload.accountInfo;
                }
                premiseInfo = reviewOrderVariables.orderSummary.apptNotes;
            } else if (reviewOrderVariables.previousUrl === '/pending-order' && data.schedule) {
                reviewOrderVariables.orderSummary = data.schedule;
                reviewOrderVariables.accountInfo = data.accountInfo;
                reviewOrderVariables.additionalInfo = data.additionalInfo;
                reviewOrderVariables.requestedTN = data.reservedTN;
                if (data.addlOrderAttributes) this.splitDueDateEligibleCheck(reviewOrderVariables, data.addlOrderAttributes);
                premiseInfo = data.schedule.apptNotes;
            }
            if (reviewOrderVariables.requestedTN !== undefined) {
                reviewOrderVariables.requestedTN.map((tn) => {
                    if (tn.productType === 'VOICE-DHP' || tn.productType === 'VOICE-HP') {
                        reviewOrderVariables.phoneReservedObject = tn;
                    }
                });
                reviewOrderVariables.requestedTN.filter((x) => {
                    if (x.productType === 'VOICE-DHP' || x.productType === 'VOICE-HP' ||
                        (x.productType === GenericValues.sData || x.productType === GenericValues.iData)) {
                        reviewOrderVariables.productType = x.productType;
                        reviewOrderVariables.requestedTelephoneNumber = x.requestedTelephoneNumber;
                    }
                })
            }
            if (reviewOrderVariables.orderSummary) {
                if (reviewOrderVariables.orderSummary.shippingInfo && reviewOrderVariables.orderSummary.shippingInfo.shippingAddress && reviewOrderVariables.currentFlow !== 'billing') {
                    reviewOrderVariables.shippingAddress = reviewOrderVariables.orderSummary.shippingInfo.shippingAddress;
                }
                reviewOrderVariables.serviceAddress = reviewOrderVariables.orderSummary.serviceAddress;
            }
            if (reviewOrderVariables.currentFlow === 'Change' || reviewOrderVariables.currentFlow === 'Move' || reviewOrderVariables.currentFlow === 'billing') {
                this.emailCheck(reviewOrderVariables, reviewOrderVariables.currentFlow);
                this.prismDetails(reviewOrderVariables);
            }
            if (reviewOrderVariables.orderSummary) {
                if (reviewOrderVariables.currentFlow !== 'billing') {
                    if(reviewOrderVariables.orderSummary.appointmentInfo && reviewOrderVariables.orderSummary.appointmentInfo.timeSlot) {
                        reviewOrderVariables.starttime = reviewOrderVariables.orderSummary.appointmentInfo.timeSlot.startDateTime;
                    }
                    if (reviewOrderVariables.currentFlow === 'NEWINSTALL') {
                        if(!reviewOrderVariables.isPrepaid) { reviewOrderVariables.ban = reviewOrderVariables.orderObject.payload.accountInfo.ban; }
                    } else if (reviewOrderVariables.currentFlow === 'Move') {
                        this.splitDueDateEligibleCheck(reviewOrderVariables, reviewOrderVariables.orderObject.payload.addlOrderAttributes);
                        reviewOrderVariables.accountInfo.isBillAddrSameAsServiceAddress = false;
                    }
                    if (reviewOrderVariables.orderObject && reviewOrderVariables.orderObject.payload && reviewOrderVariables.orderObject.payload !== undefined && reviewOrderVariables.orderObject.payload.paymentInfo !== undefined && reviewOrderVariables.orderObject.payload.paymentInfo.length > 0) {
                        reviewOrderVariables.payment = reviewOrderVariables.orderObject.payload.paymentInfo[0];
                    } else {
                        if (reviewOrderVariables.currentFlow !== 'Move') reviewOrderVariables.isdepositCollected = false;
                    }
                    if (reviewOrderVariables.accountInfo !== undefined) {
                        reviewOrderVariables.billingAddress = reviewOrderVariables.accountInfo.billingAddress;
                        let billingReference = reviewOrderVariables.accountInfo.accountPreferences;
                        let billingObject = {
                            'Paperless Billing': billingReference.paperlessBilling,
                            'Spanish Bill Print': billingReference.spanishBillPrint,
                            'Large Print': billingReference.largePrint,
                            'Braille': billingReference.braille
                        };
                        reviewOrderVariables.billingOptions = billingReference ? this.reviewOrderService.returnOptions(billingObject) : [];
                        let marketingObject = {
                            'No Telemarketing': billingReference.noTeleMarketing,
                            'No Direct Mail': billingReference.noDirectMail,
                            'No Email': billingReference.noEmail
                        };
                        reviewOrderVariables.marketingPreferences = billingReference ? this.reviewOrderService.returnOptions(marketingObject) : [];
                        let emailReference = reviewOrderVariables.accountInfo.accountPreferences.emailNotification;
                        let emailNotifyObject = {
                            'Billing Events': emailReference.billingNotification,
                            'Ordering Events': emailReference.orderingNotification,
                            'Repair Events': emailReference.repairNotification
                        };
                        if (emailReference) {
                            if (this.reviewOrderService.checkExist(emailNotifyObject, true)) {
                                reviewOrderVariables.emailNotifications = 'All';
                            } else if (this.reviewOrderService.checkExist(emailNotifyObject, false)) {
                                reviewOrderVariables.emailNotifications = 'None';
                            } else {
                                reviewOrderVariables.emailNotifications = this.reviewOrderService.returnOptions(emailNotifyObject);
                            }
                        }
                        let smsReference = reviewOrderVariables.accountInfo.accountPreferences.textNotification;
                        let smsNotifyObject = {
                            'Billing Events': smsReference.billingNotification,
                            'Ordering Events': smsReference.orderingNotification,
                            'Repair Events': smsReference.repairNotification
                        };
                        if (smsReference) {
                            if (this.reviewOrderService.checkExist(smsNotifyObject, true)) {
                                reviewOrderVariables.smsNotifications = 'All';
                            } else if (this.reviewOrderService.checkExist(smsNotifyObject, false)) {
                                reviewOrderVariables.smsNotifications = 'None';
                            } else {
                                reviewOrderVariables.smsNotifications = this.reviewOrderService.returnOptions(smsNotifyObject);
                            }
                        }
                    }
                }
                let premiseInfoObject = {
                    'Animals Present': premiseInfo && premiseInfo.animalsPresent ? premiseInfo.animalsPresent : '',
                    'Electric Fence': premiseInfo && premiseInfo.electricFence ? premiseInfo.electricFence : '',
                    'Locked Gate': premiseInfo && premiseInfo.lockedGate ? premiseInfo.lockedGate : ''
                };
                reviewOrderVariables.premisesInfo = premiseInfo ? this.reviewOrderService.returnOptions(premiseInfoObject) : [];
                if (reviewOrderVariables.currentFlow === 'NEWINSTALL') {
                    this.updateTechRemark(premiseInfo, reviewOrderVariables);
                }
                reviewOrderVariables.disableNotification = reviewOrderVariables.additionalInfo.disableOrderNotification;
            }
        }
    }
}