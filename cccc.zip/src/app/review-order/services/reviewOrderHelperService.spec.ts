import { TestBed, inject, async } from "@angular/core/testing";
import { ReviewOrderHelperService } from "./reviewOrderHelper.service"
import { MockCTLHelperService, MockSystemErrorService, MockReviewOrderService, MockLogger, MockRouter } from 'app/common/service/mockServices.test';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Logger } from 'app/common/logging/default-log.service';
import { Router } from '@angular/router';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { MockServer } from 'app/MockServer.test';
import { ReviewOrderVariables } from 'app/common/models/review.order.model';
import "rxjs/add/observable/of";

describe('Review order helper service NI', () => {
    let reviewOrderHelperService; 
    const mockServer = new MockServer();
    let orderData;
    const device = {
        "offerCategory": null,
        "productType": "INTERNET",
        "productId": null,
        "productName": "MODEM",
        "isLeasedEquipment": true,
        "purchasePrice": {
            "attributesCombination": null,
            "priceType": null,
            "rc": 0,
            "otc": 0,
            "discountedRc": 99.99,
            "discountedOtc": 0,
            "currencyCode": "USD"
        }
    };
    const mockRedux: any = {
        dispatch(obj) {return obj},
        configureStore() {},
        select(reducer) {
            return Observable.of(
              mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
        }
      };
      
    // Default Provides
    const p1 = { provide: Store, useValue: mockRedux };
    const p2 = { provide: Logger, useClass: MockLogger };
    const p3 = { provide: Router, useClass: MockRouter };
    const p4 = { provide: CTLHelperService, useClass: CTLHelperService };
    const p5 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p6 = { provide: ReviewOrderService, useClass: MockReviewOrderService };
    const p7 = { provide: ReviewOrderHelperService, useClass : ReviewOrderHelperService};

    beforeEach(async(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            providers: [
                p1,p2,p3,p4,p5,p6,p7
            ]
        });
    }));

    beforeEach(() => {
        reviewOrderHelperService = TestBed.get(ReviewOrderHelperService);
        
        let Observable = <Observable<any>>mockRedux.select('order');
        let Subscription = Observable.subscribe((data) => {
            orderData = data;
        });   
        if(Subscription){
            Subscription.unsubscribe();
        }
    });

    it("should create review order helper service", () => {
        expect(reviewOrderHelperService).toBeDefined();
    });

    it("should fetch the price from fetchPrice method", () => {
        expect(reviewOrderHelperService.fetchPrice(device)).toBe(99.99);
        device.purchasePrice.discountedRc = 0.00;
        device.purchasePrice.rc  = 30.00;
        expect(reviewOrderHelperService.fetchPrice(device)).toBe(30.00);
        device.purchasePrice.rc = 0.00;
        device.purchasePrice.discountedOtc  = 45.00;
        expect(reviewOrderHelperService.fetchPrice(device)).toBe(45.00);
        device.purchasePrice.discountedOtc = 0.00;
        device.purchasePrice.otc  = 60.00;
        expect(reviewOrderHelperService.fetchPrice(device)).toBe(60.00);
        device.purchasePrice.otc  = 0.00;
        expect(reviewOrderHelperService.fetchPrice(device)).toBe(undefined);
        device.purchasePrice = null;
        expect(reviewOrderHelperService.fetchPrice(device)).toBe(undefined);
    })
    
    it("should set default revieworder variable when setReviewOrderVablesDefault is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        expect(reviewOrderVariables.checkNotificationlink).toBe(true);
        expect(reviewOrderVariables.checkNotificationCheckbox).toBe(false);
        expect(reviewOrderVariables.isUnholdFlow).toBe(false);
        expect(reviewOrderVariables.allPaymentDone).toBe(false);
        expect(reviewOrderVariables.isrefundAvail).toBe(false);
        expect(reviewOrderVariables.selfInstallSel).toBe(false);
        expect(reviewOrderVariables.selfInstall).toBe(false);
        expect(reviewOrderVariables.actualAmount).toEqual(0);
        expect(reviewOrderVariables.paidAmount).toEqual(0);
        expect(reviewOrderVariables.billingOptions).toEqual([]);
        expect(reviewOrderVariables.marketingPreferences).toEqual([]);
        expect(reviewOrderVariables.premisesInfo).toEqual([]);
        expect(reviewOrderVariables.techRemarks).toBe(false);
        expect(reviewOrderVariables.additioanalNotes).toEqual({  text: '' });
        //
        expect(reviewOrderVariables.authorizedParties).toBe(false);
        expect(reviewOrderVariables.oneAuthorzedParty).toBe(true);
        expect(reviewOrderVariables.authUsers).toEqual([]);
        expect(reviewOrderVariables.pricingConfirmation).toBe('');
        expect(reviewOrderVariables.billCharges).toEqual([]);
        expect(reviewOrderVariables.accountDetailsCollapsed).toBe(false);
        expect(reviewOrderVariables.currentTab).toEqual('tab0');
        expect(reviewOrderVariables.productInformation).toEqual({
            terms: '',
            offerName: '',
            isAutopay: false,
            internetExpiry: '',
            prismExpiry: '',
            dhpExpiry: '',
            autopayRate: -1,
            etf: 0
        });
        expect(reviewOrderVariables.loading).toBe(false);
        expect(reviewOrderVariables.MonthlySet).toEqual({
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        });
        expect(reviewOrderVariables.oneTimeSet).toEqual({
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        });
        expect(reviewOrderVariables.proratedSet).toEqual({
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        });
        expect(reviewOrderVariables.surgchargesSet).toEqual({
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        });
        expect(reviewOrderVariables.discountsSet).toEqual({
            packageTotal: 0,
            voiceTotal: 0,
            broadbandTotal: 0
        });
        expect(reviewOrderVariables.isDTV).toBe(false);
        expect(reviewOrderVariables.dtvForm).toEqual({ taskName: '', accNo: '' });
        expect(reviewOrderVariables.dtvOptIn).toBe(false);
        expect(reviewOrderVariables.isdepositCollected).toBe(true);
        expect(reviewOrderVariables.isDHPAvailable).toBe(false);
        expect(reviewOrderVariables.rccDone).toBe(false);
        expect(reviewOrderVariables.paidSecurityDeposit).toBe(false);
        expect(reviewOrderVariables.productDealerCodeInfo).toEqual([]);
        expect(reviewOrderVariables.dealerCodeChanged).toBe(false);
        expect(reviewOrderVariables.isDepositBypassed).toBe(false);
        expect(reviewOrderVariables.isPrepaid).toBe(false);
        expect(reviewOrderVariables.comments).toEqual([]);
        expect(reviewOrderVariables.prepaidPayment).toBe(false);
        expect(reviewOrderVariables.showRefundBanner).toBe(false);
        expect(reviewOrderVariables.reuseBan).toBe(false);
        expect(reviewOrderVariables.isPaymentDone).toBe(false);
        expect(reviewOrderVariables.contactNumber).toEqual('');
        expect(reviewOrderVariables.schedulingURL).toEqual('');
        expect(reviewOrderVariables.creditCheckflag).toBe(true);
        expect(reviewOrderVariables.paymentDone).toBe(false);
        expect(reviewOrderVariables.emailNotExist).toBe(false);
    });

    it("should set Notification values when checkNotification",()=>{
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderHelperService.checkNotification(reviewOrderVariables);
        expect(reviewOrderVariables.checkNotificationlink).toBe(false);
        expect(reviewOrderVariables.checkNotificationCheckbox).toBe(true);
    });

    it("should not set emailValidCheck as true when emailCheck is called in billing flow",()=>{
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderHelperService.emailCheck(reviewOrderVariables,"billing");
        expect(reviewOrderVariables.emailValidChecked).toBe(undefined);
    });

    it("should set emailValidCheck as true when emailCheck is called in change flow",()=>{
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderHelperService.emailCheck(reviewOrderVariables,"Change");
        expect(reviewOrderVariables.emailValidChecked).toBe(true);
    });

    it("should set emailNotExist as emailAddrDeclined",()=>{
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.accountInfo={
            contact: {
                emailAddrDeclined : true
            }
        }
        reviewOrderHelperService.emailCheck(reviewOrderVariables,"Move");
        expect(reviewOrderVariables.emailNotExist).toBe(true);
    });

    it("should set emailNotExist for DHPAvailable",()=>{
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.isDHPAvailable = true;
        reviewOrderVariables.emailNotExist = true;
        reviewOrderHelperService.emailCheck(reviewOrderVariables,"Change");
        expect(reviewOrderVariables.emailValidChecked).toBe(false);
    })

    it("should not set returnEquipmentData if there is no returnEquipments",()=>{
        let reviewOrderVariables = {} as any;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderHelperService.prismDetails(reviewOrderVariables);
        expect(reviewOrderVariables.returnEquipmentData).toBeUndefined;
    })
    
    it("should set returnEquipmentData if there is  returnEquipments",()=>{
        let reviewOrderVariables = {} as any;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.orderObject = orderData;
        reviewOrderVariables.orderObject.payload.returnDateOfEquipment = "12021889"
        reviewOrderVariables.orderObject.payload.returnEquipments = [
            {
                offerCategory : "VIDEO-PRISM",
                purchasePrice : {
                    discountedOtc : 90.00
                }
            }
        ]
        reviewOrderHelperService.prismDetails(reviewOrderVariables);
        expect(reviewOrderVariables.returnEquipmentData).toEqual(reviewOrderVariables.orderObject.payload.returnEquipments);
        expect(reviewOrderVariables.removedPrismPrice).toEqual(90.00);
        expect(reviewOrderVariables.returnDate).toEqual("12021889");
    });

    it("should update reviewOrderVairables when getOrderDetails is called in NI", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.currentFlow = "NEWINSTALL";
        reviewOrderHelperService.getOrderDetails(orderData, reviewOrderVariables); 
        expect(reviewOrderVariables.orderObject).toEqual(orderData);
        expect(reviewOrderVariables.orderSummary).toEqual(orderData.payload.orderSummary);
        expect(reviewOrderVariables.additionalInfo).toEqual(orderData.payload.additionalInfo);
        expect(reviewOrderVariables.requestedTN).toEqual(orderData.payload.orderSummary.reservedTN);
        expect(reviewOrderVariables.accountInfo).toEqual(orderData.payload.accountInfo);
        expect(reviewOrderVariables.serviceAddress).toEqual(orderData.payload.orderSummary.serviceAddress);
        expect(reviewOrderVariables.starttime).toEqual(orderData.payload.orderSummary.appointmentInfo.timeSlot.startDateTime);
        expect(reviewOrderVariables.ban).toEqual(reviewOrderVariables.orderObject.payload.accountInfo.ban);
    });

    it("should update techRemarks when updateTechRemark is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        let premiseInfo = {
            notes: [{
                value: "somevalue"
            }]
        };
        reviewOrderHelperService.updateTechRemark(premiseInfo, reviewOrderVariables);
    });

    it("should return day when getBillCycleDay is called", () => {
        let day = reviewOrderHelperService.getBillCycleDay(29);
        expect(day).toEqual("29th");
    });

    it("should update rcc flags when AcknowledgeRCCs is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderHelperService.AcknowledgeRCCs(reviewOrderVariables);
        expect(reviewOrderVariables.rccDone).toBe(true);
        expect(reviewOrderVariables.isRCCacknowledged ).toEqual("Yes");
    });




    it("should update reviewOrderVairables when getProductDetails is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.currentFlow = "NEWINSTALL";
        let combinedObj = {
                        offerSummary: orderData.offerSummary,
                        offers: orderData.offers
                    };      
        reviewOrderHelperService.getProductDetails(combinedObj, reviewOrderVariables); 
        expect(reviewOrderVariables.productInformation.offerName).toEqual('HSI Upto 100 Mbps/10 Mbps + PFL Internet and Unlimited Home Phone');
    });
})

describe('Review order helper service MACD order', () => {
    let reviewOrderHelperService,reviewOrderService; 
    const mockServer = new MockServer();
    let orderData;
    
    const mockRedux: any = {
        dispatch(obj) {return obj},
        configureStore() {},
        select(reducer) {
            return Observable.of(
                mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
            );
        },
        take<T>(this: Observable<T>, count: number) {
          return Observable.of(null);
        }
      };
      
    // Default Provides
    const p1 = { provide: Store, useValue: mockRedux };
    const p2 = { provide: Logger, useClass: MockLogger };
    const p3 = { provide: Router, useClass: MockRouter };
    const p4 = { provide: CTLHelperService, useClass: CTLHelperService };
    const p5 = { provide: SystemErrorService, useClass: MockSystemErrorService };
    const p6 = { provide: ReviewOrderService, useClass: MockReviewOrderService };
    const p7 = { provide: ReviewOrderHelperService, useClass : ReviewOrderHelperService}
    beforeEach(async(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            providers: [
                p1,p2,p3,p4,p5,p6,p7
            ]
        });
        let Observable = <Observable<any>>mockRedux.select('order');
        let Subscription = Observable.subscribe((data) => {
            orderData = data;
        });   
        if(Subscription){
            Subscription.unsubscribe();
        }
    }));

    beforeEach(() => {
        reviewOrderHelperService = TestBed.get(ReviewOrderHelperService);
        reviewOrderService = TestBed.get(ReviewOrderService);
    });

    it("should update reviewOrderVairables when getOrderDetails is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.currentFlow = "Change";
        spyOn(reviewOrderHelperService, 'emailCheck');
        spyOn(reviewOrderHelperService, 'prismDetails');
        reviewOrderHelperService.getOrderDetails(orderData, reviewOrderVariables); 
        expect(reviewOrderVariables.orderObject).toEqual(orderData);
        expect(reviewOrderVariables.orderSummary).toEqual(orderData.payload.orderSummary);
        expect(reviewOrderVariables.additionalInfo).toEqual(orderData.payload.additionalInfo);
        expect(reviewOrderVariables.requestedTN).toEqual(orderData.payload.orderSummary.reservedTN);
        expect(reviewOrderVariables.accountInfo).toEqual(orderData.payload.accountInfo);
        expect(reviewOrderVariables.serviceAddress).toEqual(orderData.payload.orderSummary.serviceAddress);
        expect(reviewOrderVariables.starttime).toEqual(orderData.payload.orderSummary.appointmentInfo.timeSlot.startDateTime);
        expect(reviewOrderHelperService.emailCheck).toHaveBeenCalled();
        expect(reviewOrderHelperService.prismDetails).toHaveBeenCalled();
    });

    

    it("should old Location due date when splitDueDateEligibleCheck is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        let addlOrderAttributes = [{
            orderAttributeGroup: [
              {
                orderAttributeGroupName: "splitDueDateInfo",
                orderAttributeGroupInfo: [
                  {
                    orderAttributes: [
                      {
                        orderAttributeName: "fromFinalDueDate",
                        orderAttributeValue: "12081892"
                      }
                    ]
                  }
                ]
              }]
        }]
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderHelperService.splitDueDateEligibleCheck(reviewOrderVariables, addlOrderAttributes);
        expect(reviewOrderVariables.oldLocationDueDate).toBe("12081892");
    });

    it("should update reviewOrderVairables when getProductDetails is called", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.currentFlow = "Change";
        let combinedObj = {
                        offerSummary: orderData.offerSummary,
                        offers: orderData.offers
                    };           
        reviewOrderHelperService.getProductDetails(combinedObj, reviewOrderVariables); 
        expect(reviewOrderVariables.productInformation.offerName).toEqual('');
    });

    it("should set emailNotifications as all when  checkexist with true argument", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.currentFlow = "Change";
        spyOn(reviewOrderService, 'checkExist').and.returnValues(true,true);
        reviewOrderHelperService.getOrderDetails(orderData, reviewOrderVariables); 
        expect(reviewOrderVariables.emailNotifications).toEqual('All');
        expect(reviewOrderVariables.smsNotifications).toEqual('All')

    });

    it("should set emailNotifications as all when  checkexist with false argument", () => {
        let reviewOrderVariables = {} as ReviewOrderVariables;
        reviewOrderVariables = reviewOrderHelperService.setReviewOrderVablesDefault(reviewOrderVariables);
        reviewOrderVariables.currentFlow = "Change";
        spyOn(reviewOrderService, 'checkExist').and.returnValues(false,true,false,true);
        reviewOrderHelperService.getOrderDetails(orderData, reviewOrderVariables); 
        expect(reviewOrderVariables.emailNotifications).toEqual('None');
        expect(reviewOrderVariables.smsNotifications).toEqual('None')

    });
});

