import { ComponentErrorModal } from "./ComponentErrorModal";
import { ComponentFixture, async, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger, MockAppStateService } from 'app/common/service/mockServices.test';
import { AppStateService } from 'app/common/service/app-state.service';
import { ModalModule } from 'ngx-bootstrap';
import { By } from '@angular/platform-browser';
import { PropertyEnums } from 'app/common/enums/propertyEnums';
import { User } from 'app/common/models/user.model';
import { ShoppingCart } from 'app/common/models/cart.model';
import { Product } from 'app/common/models/product.model';
import { Order } from 'app/common/models/order.model';


    describe("Component Error Modal scenario", () => {
        let component: ComponentErrorModal;
        let fixture: ComponentFixture<ComponentErrorModal>;
        let debugElement: DebugElement;
        let ctlHelperService: CTLHelperService;
        let appStateService : AppStateService;
      
        const imports = [
            ModalModule.forRoot()
        ];
       // Default Provides
       const p1 = { provide: Logger, useClass: MockLogger}
       const p2 = CTLHelperService;
       const p3 = { provide: AppStateService, useClass: MockAppStateService };

       const baseConfig = {
        imports: imports,
        declarations: [ComponentErrorModal],
        providers: [p1,p2,p3]
      };
      let user : User;
      let shoppingCart : ShoppingCart;
      let product : Product;
      let order: Order;
      let mockStore = {
        "user" : user,
        "cart": shoppingCart,
        "product" : product,   
          "order": order,
        "existingProducts": [],
          "retain": [],
        "customize": [],
        "creditReview": [],
        "pending": []
      }

      beforeEach(async(() => {
        TestBed.resetTestingModule();
        TestBed.configureTestingModule(baseConfig).compileComponents();
      }));


      beforeEach(() => {
        fixture = TestBed.createComponent(ComponentErrorModal);
        component = fixture.componentInstance;
        debugElement = fixture.debugElement;
        fixture.detectChanges();
        ctlHelperService = TestBed.get(CTLHelperService);
        appStateService = TestBed.get(AppStateService);
      });


      it("should create component error modal", () => {
        expect(component).toBeTruthy();
      });

      it("should call hide method when close is called", ()=> {
        spyOn(component.componentErrorModal, 'hide');
        component.close();
        expect(component.componentErrorModal.hide).toHaveBeenCalled();
      });

      it("should show modal when error message ", ()=> {
          spyOn(component.componentErrorModal, 'show');
          ctlHelperService.setErrorHandler("BM_SERVER_ERROR");
          expect(component.errorMessage).toEqual("BM_SERVER_ERROR");
          expect(component.componentErrorModal.show).toHaveBeenCalled();
      });

      it("shouldnt show modal when no error message", ()=> {
        spyOn(component.componentErrorModal, 'show');
        ctlHelperService.setErrorHandler(null);
        expect(component.errorMessage).toBeUndefined;
        expect(component.componentErrorModal.show).toHaveBeenCalledTimes(0);
      })

      it("should show orderRefNumber fingerprint and error message in the modal", ()=>{
        component.orderRefNumber = "ORN-123131";
        component.fingerPrint = "ashakdjh278193";
        component.errorMessage = "BM_SERVER_ERROR";
        fixture.detectChanges();
        const modalBody = debugElement.query(By.css('.modal-body')).nativeElement;
        expect(modalBody.innerHTML).toContain('ORN-123131');
        expect(modalBody.innerHTML).toContain('ashakdjh278193');
        expect(modalBody.innerHTML).toContain('BM_SERVER_ERROR');
      });

      it("should show orderRefNumber as not applicable if no orderRefNumber", ()=>{
        component.orderRefNumber = null;
        fixture.detectChanges();
        const modalBody = debugElement.query(By.css('.modal-body')).nativeElement;
        expect(modalBody.innerHTML).toContain('Not Applicable');
      });


      it("should not show modal when global error handler is not enabled", ()=> {
        
        mockStore.user = {
          id: 1213,
          properties : {
            properties : [{
              name: PropertyEnums.ENABLE_GLOBAL_ERROR_HANDLER,
              value:['false']
            }]
          }
        }
        spyOn(appStateService, 'getState').and.returnValue(mockStore);
        spyOn(component.componentErrorModal, 'show');
        ctlHelperService.setErrorHandler("BM_SERVER_ERROR");
        expect(component.componentErrorModal.show).toHaveBeenCalledTimes(0);
      })


    });
