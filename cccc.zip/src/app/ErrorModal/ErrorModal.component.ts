// tslint:disable-next-line:no-unused-variable
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { User } from 'app/common/models/user.model';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { ModalDirective } from 'ngx-bootstrap/modal';
// tslint:disable-next-line:no-unused-variable
import { BsModalRef } from 'ngx-bootstrap/modal';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Subscription } from 'rxjs/Subscription';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import "rxjs/add/observable/of";


@Component({
    selector: 'ErrorModal',
    templateUrl: './ErrorModal.html',
    providers: [SystemErrorService]
})

export class ErrorModal implements OnInit {
    public currentURL: string;
    public loading: boolean;
    public userData: User;
    public previousURLData: Subscription;
    public previousURL: string;
    public user: Observable<User>;
    public modalRef: BsModalRef;
    public templeteRef: TemplateRef<any>;
    public orderRefNumber: any;
    public sourcePage: any;
    public showHold: boolean = true;
    public taskName: any;
    public fingerPrint: any;
    public statusCode: any;
    public reasonCode: any;
    public message: any;
    public messageDetail: any;
    public apiCall: string;
    @ViewChild('staticModal', { static: false, }) public errModal: ModalDirective;

    public config = {
        backdrop: true,
        ignoreBackdropClick: false
    };

    constructor(private store: Store<AppStore>,
        private ctlHelperService: CTLHelperService
    ) {
        this.user = <Observable<User>>this.store.select('user');
        this.previousURLData = this.user.subscribe((data) => {
            if (data && (data.currentUrl === '/product-offer' || data.currentUrl === '/home')) {
                this.showHold = false;
            } else {
                this.showHold = true;
            }
            if(data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
            this.userData = data;
        });
    }

    public ngOnInit(): void {
        this.fingerPrint = this.userData && this.userData.fingerPrint;
        this.previousURL = this.userData.previousUrl;
        this.currentURL = this.userData.currentUrl;
        let systemError = <Observable<any>>this.store.select('systemErrorReducer');
        systemError.subscribe(
            (data) => {
                let error = this.ctlHelperService.getLocalStorage('error');
                if (data && data.systemError) {
                    this.orderRefNumber = this.orderRefNumber ? this.orderRefNumber : 'Not Applicable';
                    this.sourcePage = data.systemError.sourcePage;
                    this.taskName = data.systemError.taskName;
                    this.statusCode = data.systemError.statusCode ? data.systemError.statusCode : (error && error.status);
                    this.reasonCode = data.systemError.reasonCode;
                    this.message = data.systemError.message;
                    this.messageDetail = data.systemError.messageDetail;
                    this.apiCall = error && error.url ? error.url : '';
                    if (this.statusCode !== undefined && this.statusCode !== null) {
                        this.errModal.show();
                    }
                }
            }
        );

    }

    public close(): void {
        this.ctlHelperService.removeLocalStorage('error');
        this.errModal.hide();
    }

}
