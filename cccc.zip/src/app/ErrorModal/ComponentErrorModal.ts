import { Component, ViewChild } from '@angular/core';
import { Logger } from 'app/common/logging/default-log.service';
import { User } from 'app/common/models/user.model';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Observable } from 'rxjs/Observable';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums';

@Component({
    selector: 'ComponentErrorModal',
    templateUrl: './ComponentErrorModal.html',
    providers: [SystemErrorService]
})

export class ComponentErrorModal {
    public errorMessage: string;
    public user: Observable<User>;
    public userData;
    public fingerPrint;
    public orderRefNumber;
    @ViewChild('componentErrorModal', { static: false, }) public componentErrorModal: ModalDirective;
    private currentUrl: string;
    private previousUrl: string;
    private ban: string;

    public config = {
        backdrop: true,
        ignoreBackdropClick: false
    };

    constructor(
        private logger: Logger,
        ctlHelperService: CTLHelperService,
        private appStateService: AppStateService
    ) {
        if(ctlHelperService && ctlHelperService.errorHandler) {
            ctlHelperService.errorHandler.subscribe(
                (errorMsg: string) => {
                    if (errorMsg) {
                        const store = this.appStateService.getState();
                        let enableGlobalErrorHandler = true;
                        if(store && store.user) {
                            this.fingerPrint = store.user.fingerPrint;
                            this.orderRefNumber = store.user.orderRefNumber;
                            this.currentUrl = store.user.currentUrl;
                            this.previousUrl = store.user.previousUrl;
                            this.ban = store.user.ban;
                            if(store.user.properties && store.user.properties.properties) {
                                for (let entry of store.user.properties.properties) {
                                    if (entry && entry.name && (entry.name === PropertyEnums.ENABLE_GLOBAL_ERROR_HANDLER)) {
                                        if (entry.value && (entry.value.length > 0) && entry.value[0] && (entry.value[0] === "false")) {
                                            enableGlobalErrorHandler = false;
                                        }
                                    }
                                }
                            }
                        }    
                        this.errorMessage = errorMsg;
                        const loggingData = {
                            errorMessage: this.errorMessage,
                            currentUrl: this.currentUrl ? this.currentUrl : '',
                            previousUrl: this.previousUrl ? this.previousUrl : '',
                            orderRefNumber: this.orderRefNumber ? this.orderRefNumber : '',
                            ban: this.ban ? this.ban : ''
                        };
                        if (this.errorMessage) {
                            this.logger.log(
                                "error",
                                "ComponentErrorModal.component.ts",
                                "ngOnInit", 
                                JSON.stringify(loggingData)
                            );
                            if(enableGlobalErrorHandler) { this.componentErrorModal.show(); }
                        }
                    }
            });
        }
    }

    public close(): void {
        this.componentErrorModal.hide();
    }

}
