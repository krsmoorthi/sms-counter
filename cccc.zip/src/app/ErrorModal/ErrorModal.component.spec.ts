import { SystemErrorService } from "app/common/service/system-error.service";
import { MockSystemErrorService, MockLogger, MockRouter, MockReviewOrderService, MockPendingOrderService, MockAccountService, MockDisconnectService, MockProductService, MockAddressService, MockBlueMarbleService, MockDirectvService } from 'app/common/service/mockServices.test';
import { ErrorModal } from './ErrorModal.component';
import { ComponentFixture, async, TestBed } from '@angular/core/testing';
import { MockServer } from 'app/MockServer.test';
import { ModalModule, TabsModule, AccordionModule, TypeaheadModule, ModalDirective } from 'ngx-bootstrap';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Routes, Router, RouterModule } from '@angular/router';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DomSanitizer, By } from '@angular/platform-browser';
import { AccountService } from 'app/common/service/account.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CountryStateService } from 'app/common/service/country-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { DebugElement } from '@angular/core';

const routes: Routes = [
    {
      path: "",
      component: ErrorModal
    }
];
  
  describe("ErrorModal Component", () => {
    let component: ErrorModal;
    let fixture: ComponentFixture<ErrorModal>;
    let ctlHelperService : CTLHelperService;
    let debugElement: DebugElement;
    const mockServer = new MockServer();
    let error = {
      url : "/product"
    }
    const imports = [
        ModalModule.forRoot(),
        FormsModule,
        ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        SharedModule,
        SharedCommonModule,
        TextMaskModule,
        TypeaheadModule,
        RouterModule.forChild(routes)
    ];
  
    const mockRedux: any = {
      dispatch(obj) {return obj},
      configureStore() {},
      select(reducer) {
          return Observable.of(
            mockServer.getMockStore("error-display")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
  
       // Default Provides
       let p1 = { provide: Store, useValue: mockRedux}
       const p2 = CTLHelperService;
       const p3 = { provide: SystemErrorService, useClass: MockSystemErrorService };
       const p4 = { provide: Logger, useClass: MockLogger}
       const p5 = { provide: Router, useClass: MockRouter };
       const p6 =  AppStateService ;
       const p7 = { provide: ReviewOrderService, useClass: MockReviewOrderService }
       const p8 = { provide: PendingOrderService, useClass: MockPendingOrderService };
       const p9 = {
        provide: DomSanitizer,
        useValue: {
          sanitize: (ctx, val) => val,
          bypassSecurityTrustResourceUrl: val => val,
        },
      };
       const p10 = { provide: AccountService , useClass: MockAccountService};
       const p11 = { provide: DisconnectService , useClass: MockDisconnectService};
       const p12 = { provide: ProductService , useClass: MockProductService};
       const p13 = { provide: AddressService , useClass: MockAddressService};
       const p14 = { provide: BlueMarbleService , useClass: MockBlueMarbleService};
       const p15 = FormBuilder;
       const p16 = CountryStateService;
       const p17 = TextMaskService;
       const p18 = { provide: DirectvService , useClass: MockDirectvService};
       const p19 = PropertiesHelperService;

    
      const baseConfig = {
        imports: imports,
        declarations: [ErrorModal],
        providers: [p1,p2,p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19]
      };
    
      
        beforeEach(() => {
          
          TestBed.configureTestingModule(baseConfig).compileComponents();
          ctlHelperService = TestBed.get(CTLHelperService);
          ctlHelperService.setLocalStorage('error',error);
          fixture = TestBed.createComponent(ErrorModal);
          debugElement = fixture.debugElement;
          component = fixture.componentInstance;
          fixture.detectChanges();
        });


        it("should create Error Modal Component", () => {
          expect(component).toBeTruthy();
        });
  
  
        it("should hide errModal when close is called", ()=>{
          spyOn(component.errModal, 'hide');
          component.close();
          expect(component.errModal.hide).toHaveBeenCalled();
        })

        it("should show the error details in the browser", ()=>{
          component.orderRefNumber = "ORN-123113";
          component.fingerPrint = "ayiuryw3";
          component.statusCode = "503";
          component.reasonCode = "502";
          component.message = "BM_BACKEND_SERVER_ISSUE";
          fixture.detectChanges();
          const errorModalHtml = debugElement.query(By.css('.modal-body')).nativeElement;
          expect(errorModalHtml.innerHTML).toContain('ORN-123113');
          expect(errorModalHtml.innerHTML).toContain('ayiuryw3');
          expect(errorModalHtml.innerHTML).toContain('503');
          expect(errorModalHtml.innerHTML).toContain('502');
          expect(errorModalHtml.innerHTML).toContain('BM_BACKEND_SERVER_ISSUE');
        });

  
});