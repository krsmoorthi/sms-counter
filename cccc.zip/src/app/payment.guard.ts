import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AppStateService } from './common/service/app-state.service';

@Injectable()
export class PaymentGuard implements CanActivate {

    constructor(
        private router: Router,
        private appStateService: AppStateService) {}

    public canActivate() {
        let currentStore = this.appStateService.getState();
        if((currentStore.user.currentUrl === '/account' || currentStore.user.currentUrl === '/order-confirmation' || currentStore.user.currentUrl === '/home'
        || currentStore.user.currentUrl === '/') && (currentStore.user.freezePage && !currentStore.user.paymentDone && !currentStore.user.paymentStatusChk)){
            this.router.navigate([currentStore.user.currentUrl]);
            return true;
        }
        if((currentStore.user.currentUrl === '/order-confirmation' || currentStore.user.currentUrl === '/home'
            || currentStore.user.currentUrl === '/') && (currentStore.user.freezePage && currentStore.user.paymentDone)){
                this.router.navigate([currentStore.user.currentUrl]);
                return true;
        }
        return true;
    }
}
