export class AppConstant {
    public static CHAT_SOS_URL: string = "https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22secureSessionCookie%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%221%22%2C%22cid%22%3A1570084212%2C%22eid%22%3A1570085712%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22EyODFjNTVmYzliYmZmM2Q1%22%2C%22ssid%22%3A%22HoJooQPTRIGRXgne4msIaA%22%2C%22lewid%22%3A1570246512%2C%22skill%22%3A%22csc-nohd-cris%22%7D%7D";
    public static AMEND_MESSAGE: string = "Updates not allowed with pending order change";
    public static AMEND_DISABLE_PORTING: string = "Ported TN not allowed when amending this order";    
    public static TNPORTING_DISABLE_NON_METRO_AND_EAS: string = "Ported TN not allowed with Metro calling plan";
    public static TNPORTING_DISABLE_MOVE_LC: string ='Ported TN not allowed for this order at this location';
    public static CANNOT_HOLD_PREPAID_AFTER_PAYMENT = "Cannot place prepaid order on hold after payment.";
}
export const RE_ENTRANT_OFFERVARIABLE = 'RE_ENTRANT_OFFERVARIABLE';