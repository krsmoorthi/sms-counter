import { Component, HostListener, OnDestroy, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ProfileEnums } from './common/enums/profileEnums';
import { Logger } from './common/logging/default-log.service';
import { AppStore } from './common/models/appstore.model';
import { AutoLogin, OAMData } from './common/models/auto-login.model';
import { Profile, SecurityElement } from './common/models/profile.model';
import { User } from './common/models/user.model';
import { AppStateService } from './common/service/app-state.service';
import { AuthService } from './common/service/auth.service';
import { HelperService } from './common/service/helper.service';
import { ProfileService } from './common/service/profile.service';
import { PropertiesService } from './common/service/properties.service';
import { SystemErrorService } from './common/service/system-error.service';
import { env } from '../environments/environment';
import "rxjs/add/operator/catch";
import { PropertyEnums } from './common/enums/propertyEnums';
import { Properties } from './common/models/properties.model';

/**
 * App Component
 * Top Level Component
 */
@Component({
    selector: 'app',
    encapsulation: ViewEncapsulation.None,
    styleUrls: [
        './app.component.scss'
    ],
    templateUrl: './app.component.html'
})
export class AppComponent implements OnDestroy, OnInit {
    public user: Observable<User>;
    public userSubscription: Subscription;
    public loading: boolean = false;
    public isDevMode: boolean = false;
    public propertiesProcessed: boolean = false;

    @HostListener('window:beforeunload', ['$event'])
    public beforeunloadHandler(event) {
        this.user = <Observable<User>>this.store.select('user');
        let userData;
        this.userSubscription = this.user.subscribe((data) => { userData = data; });
        if (userData && userData.currentUrl && userData.currentUrl === '/home') {
            var formDirtyChk = event.target.forms[0].className.indexOf("ng-dirty")
            if (formDirtyChk !== -1) {
                event.returnValue = "Changes you made may not be saved.";
            }
        } else {
            event.returnValue = "Changes you made may not be saved.";
        }
    }
    // Simple notifications configuration
    public notificationsOptions = {
        timeOut: 3000,
        showProgressBar: false,
        pauseOnHover: false,
        clickToClose: false
    };

    constructor(
        public authService: AuthService,
        public appStateService: AppStateService,
        public store: Store<AppStore>,
        private router: Router,
        private systemErrorService: SystemErrorService,
        private profileService: ProfileService,
        private helperService: HelperService,
        private logger: Logger,
        public propertiesService: PropertiesService) {

        this.user = <Observable<User>>this.store.select('user');
        this.store.dispatch({ type: 'DELETE_USER', payload: '' });
    }

    public ngOnInit() {
        let currentUrl = window.location.href;

        // Allow debugging - except for production
        // TEST1, TEST2, E2E & TRAIN are set to production on purpose - avoid black screen at startup
        (env.production || env.aot) ? this.isDevMode = false: this.isDevMode = true;

        // get JWT token for APIs
        this.authService.clearTokens();
        this.authService.getJWTToken(true);
        this.initState();

        // Get OAM Information/Profile Information and add it to the store
        var currentUser = {} as User;
        var autoLogin = {} as AutoLogin;
        var profile = {} as Profile;
        // Read the cookie to get OAM data
        autoLogin = this.retrieveEshopOamData(autoLogin);     
        currentUser.autoLogin = autoLogin;
        this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });

        // Test environments ONLY
        // Taking too long for users to get ensemble ids
        if (autoLogin && autoLogin.oamData && autoLogin.oamData.ensembleId && autoLogin.oamData.ensembleId === "(null)"
            && window.location.hostname.indexOf("eshop.foss.corp.intranet") === -1) {
                autoLogin.oamData.ensembleId = "1108402";
        }

        if (autoLogin && autoLogin.oamData && autoLogin.oamData.ensembleId && autoLogin.oamData.ensembleId !== "(null)") {
            let errorResolved = false;
            this.loading = true;
            this.logger.log("info", "app.component.ts", "getProfileRequest", JSON.stringify(currentUser.autoLogin));
            this.logger.startTime();
            this.profileService.getProfile()
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "app.component.ts", "getProfileResponse", error);
                    this.logger.log("error", "app.component.ts", "getProfileSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    errorResolved = true;
                    this.loading = false;
                    profile.validEshopProfile = false;
                    currentUser.profile = profile;
                    this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                    return Observable.throw(
                        this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError-ServiceError", "app.component.ts", "Login"));
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "app.component.ts", "getProfileResponse", JSON.stringify(data));
                        this.logger.log("info", "app.component.ts", "getProfileSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.loading = false;
                        if (data.errorResponse) {
                            profile.validEshopProfile = false;
                            currentUser.profile = profile;
                            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                            this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError", "app.component.ts", "Login");
                        }
                        else {
                            this.retrieveProperties();

                            currentUser.profile = this.processProfileData(data);
                            currentUser.profile.validEshopProfile = true;
                            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });

                            if (currentUrl.indexOf('auto-login') > -1) {
                                if (this.helperService.isAuthorized(ProfileEnums.ESHOP_SFC)) {
                                    currentUser.profile.validEshopProfile = true;
                                    this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                                    let allParams = currentUrl.split('?');
                                    let justQueryParams = allParams[1].split('/');
                                    this.loading = true;
                                    this.router.navigate(['/auto-login'], { queryParams: { token: justQueryParams[2] }, skipLocationChange: true });
                                }
                                else {
                                    profile.validEshopProfile = false;
                                    currentUser.profile = profile;
                                    this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                                    this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError-SFC", "app.component.ts", "Login");
                                }
                            }
                            else {
                                if (this.helperService.isAuthorized(ProfileEnums.ESHOP_STD)) {
                                    currentUser.profile.validEshopProfile = true;
                                    this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                                    this.router.navigate(['/home']);
                                }
                                else {
                                    profile.validEshopProfile = false;
                                    currentUser.profile = profile;
                                    this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                                    this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError-STD", "app.component.ts", "Login");
                                }
                            }

                        }
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "app.component.ts", "getProfileResponse", error);
                            this.logger.log("error", "app.component.ts", "getProfileSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        profile.validEshopProfile = false;
                        currentUser.profile = profile;
                        this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
                    }
                );
        }
        else {
            /*this.user = <Observable<User>>this.store.select('user');
            this.userSubscription = this.user.subscribe((data) => {
                currentUser = data;
                profile.validEshopProfile = false;
                currentUser.profile = profile;
            });
            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
            this.userSubscription.unsubscribe();
            this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError-EnsembleId", "app.component.ts", "Login");
            */
            //TODO START - TEMPORARY CODE TILL WHILTE-LISTING RESOLVED
            autoLogin = this.getAutoLoginDataForTesting();
            currentUser.autoLogin = autoLogin;
            profile.validEshopProfile = true;
            currentUser.profile = this.processProfileData(this.getProfileDataForTesting());
            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
            this.checkAuthorization(currentUrl, currentUser, profile);
        }

    }

    /**
     * Initialize application state
     * Cart, User state, Browser Finger Print,
     * Restore cart contents from the user state
     * Load Products and Pricing
     */
    public initState() {
        this.authService.init();
        // This code is used for Fingerprint control
        this.helperService.startNewOrderWithoutRouting("app");
    }

    /**
     * Clear existing Subscription
     */
    public ngOnDestroy() { }

    public isValidUser() {
        this.user = <Observable<User>>this.store.select('user');
        let userData;
        this.userSubscription = this.user.subscribe((data) => {
            userData = data;
        });
        this.userSubscription.unsubscribe();

        if (userData && userData.profile && userData.profile.validEshopProfile && userData.profile.validEshopProfile === true) {
            return true;
        }
        else {
            return false;
        }
    }

    public sleep(milliseconds) {
        var start = new Date().getTime();
        for (var i = 0; i < 1e7; i++) {
            if ((new Date().getTime() - start) > milliseconds) {
                break;
            }
        }
    }

    public retrieveEshopOamData(autoLogin: AutoLogin): AutoLogin {
        var eshopCookieValue;
        let keepProcessing: boolean = true;
        var maxRetries = 5;
        var retries = 0;

        var oamData = {} as OAMData;
        while (keepProcessing && retries <= maxRetries) {
            eshopCookieValue = this.helperService.getCookie("eshop_oam");
            if (eshopCookieValue !== null && eshopCookieValue.length > 0) {
                var cookieValues = eshopCookieValue.split("&");
                if (cookieValues !== null && cookieValues.length > 0) {
                    cookieValues.forEach(element => {
                        if (element.length > 0) {
                            var cookieElement = element.split("=");
                            switch (cookieElement[0]) {
                                case "agentCsrId":
                                    oamData.agentCuid = cookieElement[1];
                                    break;
                                case "agentFirstName":
                                    oamData.agentFirstName = cookieElement[1];
                                    break;
                                case "agentLastName":
                                    oamData.agentLastName = cookieElement[1];
                                    break;
                                case "ensembleId":
                                    oamData.ensembleId = cookieElement[1];
                                    break;
                                case "emailAddress":
                                    oamData.agentEmailId = cookieElement[1];
                                    break;
                                case "workstationId":
                                    oamData.workstationId = cookieElement[1];
                                    break;
                                case "roomNumber":
                                    oamData.roomNumber = cookieElement[1];
                                    break;
                                }
                        }
                    });
                }
            }

            autoLogin.oamData = oamData;
            this.logger.log("info", "app.component.ts", "retrieveEshopOamData-eshopCookieValue", JSON.stringify(eshopCookieValue));

            if (autoLogin.oamData.agentFirstName && autoLogin.oamData.agentFirstName !== "(null)") {
                keepProcessing = false;
                return autoLogin;
            }
            else {
                this.sleep(500);
                retries++;
            }
        }

        // You have exceeded the number of retries and the ensembleId is empty
        retries--;

        return autoLogin;
    }

    private retrieveProperties(): void {
        this.logger.log("info", "app.component.ts", "retrievePropertiesRequest", JSON.stringify(""));
        this.logger.startTime();

        this.propertiesService.getProperties()
        .catch((error: any) => {
            this.logger.endTime();
            this.logger.log("error", "app.component.ts", "retrievePropertiesResponse", error);
            this.logger.log("error", "app.component.ts", "retrievePropertiesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            return Observable.throw(
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", 'Not Applicable',
                    "properties - getProperties", "app.component.ts",
                    "Home Page",
                    error));
        })
        .subscribe(
            (data) => {
                this.logger.endTime();
                this.logger.log("info", "app.component.ts", "retrievePropertiesResponse", JSON.stringify(data ? data : ""));
                this.logger.log("info", "app.component.ts", "retrievePropertiesSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');

                var currentUser = {} as User;
                var properties = {} as Properties;
                this.user = <Observable<User>>this.store.select('user');
                let lUserSubscription = this.user.subscribe((userData) => {
                    if (!this.propertiesProcessed) {
                        properties = data;
                        if (properties && properties.properties && properties.properties.length > 0) {
                            for (let entry of properties.properties) {
                                if (entry.name === PropertyEnums.ALLOW_CLICKTALE) {
                                    if (entry.value[0] === "true") {
                                        const script = document.createElement('script');
                                        script.innerHTML = `if(!window.clickTaleTagInjected){!function(d,t,u){clickTaleTagInjected = true;function injectTag(){var ns=d.createElementNS;var a=ns?ns.call(d,"http://www.w3.org/1999/xhtml",t):d.createElement(t),s=d.getElementsByTagName(t)[0];a.async=true;a.crossOrigin="anonymous";a.type="text/javascript";a.src=u;s.parentNode.insertBefore(a,s);} if(d.readyState!='loading'){injectTag();} else{d.addEventListener('DOMContentLoaded',function(){setTimeout(injectTag,0)});}}(document,'script','https://cdnssl.clicktale.net/www29/ptc/b9ebf428-51fa-4a94-9a6d-135365440390.js');}`;
                                        document.body.appendChild(script);
                                        this.propertiesProcessed = true;
                                    }
                                }
                                else if (entry.name === PropertyEnums.ALLOW_APP_DYNAMICS) {
                                    if (entry.value[0] === "true") {
                                        const script = document.createElement('script');
                                        script.innerHTML = `window['adrum-start-time'] = new Date().getTime();
                                            (function(config){
                                                config.appKey = 'AD-AAB-AAU-UPW';
                                                config.adrumExtUrlHttp = 'http://cdn.appdynamics.com';
                                                config.adrumExtUrlHttps = 'https://cdn.appdynamics.com';
                                                config.beaconUrlHttp = 'http://pdx-col.eum-appdynamics.com';
                                                config.beaconUrlHttps = 'https://pdx-col.eum-appdynamics.com';
                                                config.xd = {enable : true};
                                                config.fetch = false;
                                                config.spa = { spa2: true };
                                            })(window['adrum-config'] || (window['adrum-config'] = {}));`;
                                        document.body.appendChild(script);
                                        const script2 = document.createElement('script');
                                        script2.src = `https://cdn.appdynamics.com/adrum/adrum-4.5.17.2890.js`;
                                        document.body.appendChild(script2);
                                        this.propertiesProcessed = true;
                                    }
                                }
                            }
                        }
                    }
                    currentUser = userData;
                    currentUser.properties = data;
                });
                this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });

            },
            (error) => {
                window.scroll(0, 0);
            }
        );
    }

    public processProfileData(profileData: any): Profile {
        let profile = {} as Profile;
        if (profileData.errorResponse) {
            return profile;
        }
        else {
            profile.profileId = profileData.profileId;
            profile.loginType = profileData.loginType;
            let securityElementsArray = new Array() as SecurityElement[];
            for (let entry of profileData.securityElements) {
                let securityElement = {} as SecurityElement;
                securityElement.securityElementName = new String(entry.securityElementName).toUpperCase();
                securityElement.securityElementFlag = entry.securityElementFlag;
                securityElementsArray.push(securityElement);
            }
            profile.securityElements = securityElementsArray;
            return profile;
        }
    }
    /*
    * TODO Temporary
    * checkAuthorization()
    * getAutoLoginDataForTesting()
    * getProfileDataForTesting()
    * getCookie() 
    */
   private checkAuthorization(currentUrl: string, currentUser: User, profile: Profile) {
    if (currentUrl.indexOf('auto-login') > -1) {
        if (this.helperService.isAuthorized(ProfileEnums.ESHOP_SFC)) {
            currentUser.profile.validEshopProfile = true;
            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
            let allParams = currentUrl.split('?');
            let justQueryParams = allParams[1].split('/');
            this.loading = true;
            this.router.navigate(['/auto-login'], { queryParams: { token: justQueryParams[2] }, skipLocationChange: true });
        }
        else {
            profile.validEshopProfile = false;
            currentUser.profile = profile;
            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
            this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError-SFC", "app.component.ts", "Login");
        }
    }
    else {
        if (this.helperService.isAuthorized(ProfileEnums.ESHOP_STD)) {
            currentUser.profile.validEshopProfile = true;
            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
            this.router.navigate(['/home']);
        }
        else {
            profile.validEshopProfile = false;
            currentUser.profile = profile;
            this.store.dispatch({ type: 'UPDATE_USER', payload: currentUser });
            this.systemErrorService.logAndeRouteToSecurityError("error", "authenticationError", "app.component.ts", "Login");
        }
    }
}

public getAutoLoginDataForTesting() {
    let autoLogin = {} as AutoLogin;
    let oamData = {} as OAMData;
    oamData.agentCuid = "AB75644";
    oamData.agentFirstName = "Krishna";
    oamData.agentLastName = "Moorthi";
    oamData.ensembleId = "7960382";
    oamData.agentEmailId = "krishna.moorthi@centurylink.com";
    oamData.workstationId = "AB75644";
    autoLogin.oamData = oamData;
    return autoLogin;
}

public getProfileDataForTesting() {
    let profile =
    {
        ensembleId: "7960382",
        profileId: "INQR",
        shortName: "Krishna Moorthi",
        fullName: "Krishna Moorthi",
        loginType: "1",
        orderReferenceNumber: null,
        salesChannel: "ESHOP-Customer Care",
        securityElements: [{
            securityElementName: "Allow_Retention_Offers",
            securityElementFlag: "true"
        }, {
            securityElementName: "Billing_Effective_Date",
            securityElementFlag: "true"
        }, {
            securityElementName: "Bypass_Credit_Check",
            securityElementFlag: "true"
        }, {
            securityElementName: "Bypass_Deposit",
            securityElementFlag: "true"
        }, {
            securityElementName: "Bypass_HSI_Speeds",
            securityElementFlag: "true"
        }, {
            securityElementName: "Bypass_Loop_Qual",
            securityElementFlag: "true"
        }, {
            securityElementName: "Bypass_Modem_Check",
            securityElementFlag: "true"
        }, {
            securityElementName: "Bypass_Security_Deposit",
            securityElementFlag: "true"
        }, {
            securityElementName: "Eshop_Sfc",
            securityElementFlag: "true"
        }, {
            securityElementName: "Eshop_Std",
            securityElementFlag: "true"
        }, {
            securityElementName: "NonPay_Suspend_Restore",
            securityElementFlag: "true"
        }, {
            securityElementName: "Override_Order_Type",
            securityElementFlag: "true"
        }, {
            securityElementName: "ALLOW_CURRENT_DUE_DATE",
            securityElementFlag: "true"
        }
        ]
    }
    return profile;
}

public getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
}