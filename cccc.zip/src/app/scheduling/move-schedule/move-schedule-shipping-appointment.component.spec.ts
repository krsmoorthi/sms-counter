import {TestBed, async, ComponentFixture} from '@angular/core/testing';
import { Router } from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import { MoveScheduleShippingAppointmentComponent } from './move-schedule-shipping-appointment.component';
import { MockServer } from 'app/MockServer.test';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import {AppStateService } from 'app/common/service/app-state.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import { SchedulingService } from 'app/common/service/scheduling.service';
import { MockAppStateService, MockSystemErrorService, MockHelperService, MockLogger, MockRouter, 
  MockBlueMarbleService, MockProductService, MockAddressService, MockCountryStateService, MockTextMaskService, MockPropertiesHelperService, MockReviewOrderService, MockDisclosuresService, MockDisconnectService, MockPendingOrderService, MockAccountService, MockDirectvService, MOCK_ROUTES} from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { AccountService } from 'app/common/service/account.service';
import { DirectvService } from 'app/common/service/directv.services';
import { TextMaskModule } from 'angular2-text-mask';

// disabling this file for now, since chrome is unable to open this component
xdescribe('Move schedule Shipping Appointment Component', () => {
  let component: MoveScheduleShippingAppointmentComponent;
  let fixture: ComponentFixture<MoveScheduleShippingAppointmentComponent>;
  let mockServer= new MockServer();

  const mockRedux : any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
      return Observable.of(
        mockServer.getMockStore("onload-move-scheduling")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  }

  let p1 = { provide: Logger, useClass: MockLogger};
  let p2 = { provide: Router, useClass: MockRouter };
  let p3 = { provide: Store, useValue: mockRedux};
  let p4 = SchedulingHelperService; 
  let p5 = { provide: AppStateService, useClass: MockAppStateService}; 
  let p6 = { provide: CountryStateService, useClass: MockCountryStateService };
  let p7 = { provide: TextMaskService, useClass:MockTextMaskService};
  let p8 = { provide: HelperService, useClass:MockHelperService};
  let p9 = { provide: PropertiesHelperService, useClass:MockPropertiesHelperService};
  let p10 = SchedulingService;
  let p11 = CTLHelperService
  
  // dialog component providers list
  let dp1 = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  let dp2 = { provide: DisclosuresService, useClass: MockDisclosuresService };
  let dp3 = { provide: AddressService, useClass: MockAddressService };
  let dp4 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  let dp5 = { provide: DisconnectService, useClass: MockDisconnectService };
  let dp6 = { provide: SystemErrorService, useClass: MockSystemErrorService }
  let dp7 = {provide: PendingOrderService, useClass: MockPendingOrderService };
  let dp8 = { provide: AccountService, useClass: MockAccountService };
  let dp9 = { provide: ProductService, useClass: MockProductService };
  let dp10 = {provide: DirectvService, useClass: MockDirectvService };
 
  let baseConfig = {
    imports:[
      FormsModule, 
      ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}), 
      TextMaskModule,
      SharedModule,
      SharedCommonModule,
      RouterTestingModule.withRoutes(MOCK_ROUTES)
    ],
    declarations:[MoveScheduleShippingAppointmentComponent],
    providers:[p1,p2,p3, p4, p5, p6, p7,p8, p9, p10, p11, dp1, dp2, dp3, dp4, dp5, dp6, dp7, dp8, dp9, dp10]
  }
  beforeEach(async(() => {
    TestBed.resetTestingModule()
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoveScheduleShippingAppointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  
  it('should create schedulling shipping appointment component', () => {
    expect(component).toBeTruthy;
  });

  xit('cancelClick should have been called...', () => {
    let router = TestBed.get(Router);
    const navigateSpy = spyOn(router, 'navigate');
    component.cancelClick();
    expect(navigateSpy).toHaveBeenCalledWith(['/home']);
  });

  it('ngOninit() should have been called...', () => {
    component.ngOnInit();
    expect(component.ngOnInit()).toBeDefined;
    expect(component.ngOnInit()).toHaveBeenCalled;
  });

  it('ngOnDestroy() should have been called...', () => {
    component.ngOnDestroy();
    expect(component.ngOnDestroy()).toBeDefined;
    expect(component.ngOnDestroy()).toHaveBeenCalled;
  });
  
  xit('customerRequestedDueDateUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.customerRequestedDueDateUpdated('2018-02-14', schedulevar);
    expect(schedulevar.appointmentResponse.payload.dueDate.requestedDueDate).toBe('2018-02-14T00:00:00.000Z');
  });

  xit('effectiveBillDateUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.effectiveBillDateUpdated('2018-02-14', schedulevar);
    expect(schedulevar.appointmentResponse.payload.dueDate.effectiveBillDate).toBe('2018-02-14T00:00:00.000Z', );
  });

  xit('dueDateUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.dueDateUpdated('2018-02-14', schedulevar);
    expect(schedulevar.appointmentResponse.payload.dueDate.finalDueDate).toBe('2018-02-14T00:00:00.000Z');
  });

  xit('reserveAppointment() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.reserveAppointment(schedulevar);
    expect(schedulevar.showReserveItButton).toBe(false);
  })

  xit('revertShippingAddress() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.revertShippingAddress(schedulevar);
    expect(schedulevar.yellowAddresses.length).toBe(0);
  });

  xit('changeShippingAddr() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    schedulevar.showShippingAddress = false;
    component.changeShippingAddr();
    expect(schedulevar.showShippingAddress).toBe(true);
  });

  xit('useSericeAddress() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    schedulevar.shippingAddressObject = schedulevar.appointmentResponse.payload.shippingInfo.shippingAddress
    schedulevar.showShippingAddress = false;
    component.schedulingHelperService.useServiceAddress(schedulevar);
    expect(schedulevar.isRedAddressReturned).toBe(false);
  });

  xit('handleAppointmentUpdated() should have been called...', () => {
    let event = {
      appointmentId: "ZKLV0GFQ",
      timeSlot: {
        startDateTime: "2018-03-05T08:00:00.000Z",
        endDateTime: "2018-03-05T17:00:00.000Z"
      }
    };
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.handleAppointmentUpdated(event, schedulevar);
    expect(schedulevar.reservedAppointment).toBe(event as any);
  });

  xit('checking Schedule Appointment Service Call...', () => {
    let req = {
      taskName : 'Appointment Scheduling'
    };
    let service = TestBed.get(Store);
    let schedulevar = component && component.schedulingVariables;
    let data = mockServer.getResponseForRequest('submitTask',req);
    spyOn(service, 'scheduleAppointment').and.callFake(() => {
      return Observable.of(data);
    })
    component.schedulingHelperService.continueClick(schedulevar);
    expect(mockRedux.scheduleAppointment).toHaveBeenCalled();
    expect(MockRouter).toHaveBeenCalledWith(['/move-account']);
  });

  it('isWaiveOtcAllowed should be as true', () => { 
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement;
    schedulevar.isWaiveOtcAllowed = true;
    schedulevar.eligibleCharges = 215;
    expect(schedulevar.isWaiveOtcAllowed).toBeTruthy;
    expect(component.billingType).not.toBe('PREPAID');
    expect(schedulevar.eligibleCharges).toBeDefined;
    expect(schedulevar.eligibleCharges).toBeGreaterThan(0);
    expect(element.querySelector('.waiveOtcBlock')).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock b a')).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock b a')).toBeDefined('Waive one-time charges');
    const eligibleCharges = schedulevar.eligibleCharges + " eligible charges";
    expect(element.querySelector('.waiveOtcBlock div')).toBeDefined(eligibleCharges);
  });

  it('When totalWaivedOtc value is 0', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.waivedOtcInfo.totalWaivedOtc = 0;
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeDefined();
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toEqual(0);
    expect(element.querySelector('.waiveOtcBlock div.nonWaivedCharge')).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock div.nonWaivedCharge')).toBeDefined('None waived');
  })

  it('When totalWaivedOtc value is greater than 0', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.waivedOtcInfo.totalWaivedOtc = 50;
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeDefined();
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toEqual(50);
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeGreaterThan(0);
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock div.waivedCharges')).toBeTruthy;
  })

  it('should hide contents if isWaiveOtcAllowed is false', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.isWaiveOtcAllowed = false;
    expect(schedulevar.isWaiveOtcAllowed).toBeFalsy;
    expect(component.billingType).not.toBe('PREPAID');
  });

  it("waive OTC link should be clickable", () => {
    const element = fixture.debugElement.nativeElement;
    fixture.detectChanges();
    expect(element.querySelector('a').click()).toBeTruthy;
  });
});
