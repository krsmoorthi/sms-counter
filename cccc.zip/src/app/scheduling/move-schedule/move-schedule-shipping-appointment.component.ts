import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentNotes, AvailableAppointment } from '../../common/models/appointment.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { AppointmentShipping } from 'app/common/models/schedule-shipping.model';
import { Subscription } from 'rxjs/Subscription';
import { DatePipe } from '@angular/common';
import { AppStateService } from '../../common/service/app-state.service';
import { SchedulingVariables } from '../../common/models/schedule.shipping.model';
import { Logger } from '../../common/logging/default-log.service';
import { APIErrorLists } from '../../common/models/common.model';
import { ShippingAddres } from '../../common/models/move.schedule';
import { Validators, FormBuilder } from '@angular/forms';
import { Validations } from '../../common/validations/validations';
import { User } from '../../common/models/user.model';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { TextMaskService } from '../../common/service/text-mask.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import "rxjs/add/operator/catch";
import * as _ from 'lodash';

@Component({
    selector: 'move-schedule-appt-ship',
    styleUrls: ['../schedule-component/schedule.component.scss'],
    templateUrl: './move-schedule-shipping-appointment.component.html'
})

export class MoveScheduleShippingAppointmentComponent implements OnInit, OnDestroy, AfterViewInit {
    public apiRequest: any;
    public apiResponseError: APIErrorLists;
    public customerRequestedDueDateNotAvailableCheckBox: boolean = false;
    public availableAppointment: AvailableAppointment[];
    private appointment: Observable<AppointmentShipping>;
    private appointmentSubscription: Subscription;
    public offerBillingType: boolean = false;
    public orderRefNumber: string;
    public isRTDChk: boolean = false;
    private appointmentNotes: AppointmentNotes;
    public dtvYes: boolean = false;
    private shippingAddressObject: ShippingAddres;
    public taskId: string;
    public scheduleRe: any;
    public retain: any;
    public currentPath: boolean = false;
    public customizeSubscription: Subscription;
    public existingProdSubscription: Subscription;
    private existingData: any;
    public currentTN: any;
    private existingTN: any;
    public contactNumberExists = false;
    public contactNumber2: any
    private isPots: boolean = false;
    private isTnChanged = false;
    public pots: boolean;
    public isTechInstallSelected: boolean = false;
    public firstName: string;
    public lastName: string;
    private retainReservedAppointment;
    private previousUrl;
    public selectedappointment;
    public isinternet: boolean;
    public ishomephone: boolean;
    public phoneMask: any;
    public isChecked = false;
    private isReentrantAdditionalnumberChecked = false;
    private isadditionalNumberChecked = false;
    public billeffectmindate: string;
    public billeffectmaxdate: string;
    public isBillEffectiveDate: boolean = false;
    private contactNumber = '';
    public states: any;
    public user: Observable<User>;
    public userSubscription: Subscription;
    public customizedSubscription: Subscription;
    public cartObservable: Observable<any>;
    public cart1Subscription: Subscription;
    public reentrantnumber: any;
    public rccDisclosureDetails: any;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    public rccDisclosureErrorMessage: any;
    public userData: any;
    public addressStreet: string;
    public disableCalRef: boolean = false;
    public schedulingVariables: SchedulingVariables;
    public errorMsg: any;
    public finalPaymentDate: string;
    public waiveOtc: any[] = [{
        charge: 'Intial Jack charge',
        amount: 99,
        waived: false
    }, {
        charge: 'Phone activation charge',
        amount: 50,
        waived: false
    }];
   public eligibleCharges = 0;
    public waivedOtc = 0;
    public billingType:any;

    constructor(
        private logger: Logger,
        private router: Router,
        public schedulingHelperService: SchedulingHelperService,
        private store: Store<AppStore>,
        private fb: FormBuilder,
        private appStateService: AppStateService,
        private ctlHelperService: CTLHelperService,
        private textMask: TextMaskService,
        private countryStateService: CountryStateService
    ) {
        this.appStateService.setLocationURLs();
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.states = this.countryStateService.getStates();
        this.appointment = store.select('appointment');
        this.waiveOtc.forEach(otc => {
            this.eligibleCharges += otc.amount;
        });
        this.user = <Observable<User>>this.store.select('user');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointmentSubscription = this.appointment.subscribe((data) => {
                if (data && data.payload && data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.minBedDate) {
                    this.billeffectmindate = data.payload.billeffectiveDateInfo.minBedDate;
                    this.isBillEffectiveDate = true;
                }
                if (data && data.payload && data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.maxBedDate) {
                    this.billeffectmaxdate = data.payload.billeffectiveDateInfo.maxBedDate;
                    this.isBillEffectiveDate = true;
                }
                let user = <Observable<User>>store.select('user');
                let userSubscription = user.subscribe(
                    (usr) => {
                        this.userData = usr;
                        if (Array.isArray(usr.currentSelected)) {
                            usr.currentSelected.forEach((val: any) => {
                                if (val.selected === "DATA") {
                                    this.isinternet = true;
                                }
                            });
                            usr.currentSelected.forEach((val: any) => {
                                if (val.selected === "VOICE-HP") {
                                    this.ishomephone = true;
                                }
                            });

                        }
                        if (usr.autoLogin && usr.autoLogin.oamData && usr.autoLogin.oamData.agentFirstName && usr.autoLogin.oamData.agentLastName) {
                            this.schedulingVariables.agentFirstName = usr.autoLogin.oamData.agentFirstName;
                            this.schedulingVariables.agentLastName = usr.autoLogin.oamData.agentLastName;
                        }
                        this.previousUrl = usr.previousUrl;
                        this.schedulingVariables.currentUrl = usr.currentUrl;
                        if (usr.currentUrl === '/move-schedule-appt-ship') {
                            this.currentPath = true;
                            this.schedulingVariables.currentComponet = "move-schedule-shipping-appointment.component.ts";
                        }
                        if (usr.previousUrl === "/mo-review-order" && usr.currentUrl === "/move-schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (usr.previousUrl !== '/customize-services' && usr.previousUrl === '/move-account') {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (usr.previousUrl === '/move-account' && (usr.currentUrl === '/move-schedule-appt-ship' || usr.currentUrl === '/move-schedule-appt')) {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        let retainVal = <Observable<any>>store.select('retain');
                        retainVal.subscribe(
                            (retVal => {
                                this.schedulingVariables.retainedSchedulingData = retVal;
                                if (retVal && retVal !== undefined && retVal.prodConfig && retVal.prodConfig !== undefined && retVal.prodConfig.prodConfig[0]
                                    && retVal.prodConfig.prodConfig[0] !== undefined && retVal.prodConfig.prodConfig[0].productType && retVal.prodConfig.prodConfig[0].productType !== undefined) {
                                    if (retVal.prodConfig.prodConfig[0].productType === "VOICE-HP") {
                                        this.pots = true;
                                    }
                                }
                                this.schedulingVariables.potsRemoved = retVal.potsRemoved;
                                if (retVal.tnChanged !== (null || undefined)) {
                                    this.isTnChanged = retVal.tnChanged;
                                }
                                if (retVal && retVal.retainReservedAppointment) {
                                    this.retainReservedAppointment = retVal.retainReservedAppointment;
                                }
                                if (retVal && retVal.selectedappointment) {
                                    this.selectedappointment = retVal.selectedappointment;
                                }
                            })
                        )
                        if (usr.previousUrl !== '/order-unhold' && usr.previousUrl === '/mo-review-order' || usr.previousUrl === '/move-account' || (usr.previousUrl !== '/customize-services' && usr.previousUrl !== '/order-unhold')) {
                            this.schedulingVariables.isReEntrant = true;
                            this.schedulingVariables.earliestAvailableAppt = 'Appointment is reserved';
                            this.schedulingVariables.showReserveItButton = false;
                        }
                        if (usr.previousUrl !== '/customize-services') {
                            this.schedulingVariables.isReEntrant = true;
                            this.taskId = usr.taskId;
                            this.schedulingVariables.showReserveItButton = false;
                            let retainVal = <Observable<any>>store.select('retain');
                            retainVal.subscribe(
                                (retVal => {
                                    this.schedulingVariables.potsRemoved = retVal.potsRemoved;
                                    this.scheduleRe = retVal.account;
                                    this.retain = retVal;
                                    if (retVal.account && retVal.account.payload && retVal.account.payload.appointmentInfo !== undefined) {
                                        this.schedulingHelperService.getTechRemarks(retVal.account.payload.appointmentInfo.apptNotes, this.schedulingVariables);
                                    }
                                    this.schedulingHelperService.splitDueDateEligibleCheck(retVal.account.payload.addlOrderAttributes, this.schedulingVariables);
                                    let moveOrderObservable = <Observable<any>>store.select('move');
                                    let moveOrderSubscribe = moveOrderObservable.subscribe((data) => {
                                        this.schedulingVariables.changeEffectiveBillAddress = data.splitDueDateClicked ? true : false;
                                    });
                                    moveOrderSubscribe.unsubscribe();
                                })
                            )
                        }
                        if (usr.isDtvOpus) {
                            if (usr && usr.dtvOpus && usr.dtvOpus.taskName === 'yes') {
                                this.dtvYes = true;
                            }
                        } else {
                            if (usr && usr.dtvQuestionForm && usr.dtvQuestionForm.taskName === 'yes') {
                                this.dtvYes = true;
                            }
                        }
                        if (usr.phoneNumber !== undefined && usr.phoneNumber !== '') {
                            this.contactNumber = usr.phoneNumber;
                        }
                        if (usr && usr.orderRefNumber) {
                            this.orderRefNumber = usr.orderRefNumber;
                        }
                        if (usr.techInstallSelected) {
                            this.isTechInstallSelected = usr.techInstallSelected;
                        }
                    });
                userSubscription.unsubscribe();
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    this.schedulingVariables.appointmentResponse = data;
                    if (this.schedulingVariables.appointmentResponse.payload.accountName !== undefined && this.schedulingVariables.appointmentResponse.payload.accountName !== '') {
                        this.firstName = this.schedulingVariables.appointmentResponse.payload.accountName.firstName ? this.schedulingVariables.appointmentResponse.payload.accountName.firstName : '';
                        this.lastName = this.schedulingVariables.appointmentResponse.payload.accountName.lastName ? this.schedulingVariables.appointmentResponse.payload.accountName.lastName : '';
                    } else {
                        this.firstName = this.userData.firstName;
                        this.lastName = this.userData.lastName
                    }
                    this.schedulingVariables.finalDateInfo = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
                    this.schedulingVariables.calculatedDueDate = this.schedulingVariables.appointmentResponse.payload.dueDate.calculatedDueDate;
                    this.schedulingVariables.isdateChanged = this.schedulingVariables.finalDateInfo;
                    data && data.payload && data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.map(i => { if (i && i.orderAttributeGroup) { i.orderAttributeGroup.map(k => { if (k.orderAttributeGroupName === "interceptlOptionInd") { var ls = k.orderAttributeGroupInfo; ls.map(j => { if (j) { j.orderAttributes.map(l => { if (l.orderAttributeValue) { this.disableCalRef = true } }) } }) } }) } });
                    // if(this.schedulingVariables.isReEntrant && item.orderAttributeName=="storeAsAccountLevelCBR2")
                    if (data && data.payload && data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.length > 0) {
                        let additionalAttributes = data.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes;
                        if (this.schedulingVariables.isReEntrant && additionalAttributes.length > 0 && additionalAttributes[0].orderAttributeName === "orderLevelCBRNumber") {
                            this.schedulingVariables.formattedNumber = additionalAttributes[0].orderAttributeValue;
                            this.reentrantnumber = this.schedulingVariables.formattedNumber;
                        }
                        if (this.schedulingVariables.isReEntrant && additionalAttributes.length > 1 && additionalAttributes[1].orderAttributeName === "storeAsAccountLevelCBR2") {
                            this.isChecked = true;
                            this.schedulingHelperService.cbrMethod(data.reservedCbr, this.schedulingHelperService);
                            this.isReentrantAdditionalnumberChecked = true;
                            this.isadditionalNumberChecked = additionalAttributes[1].orderAttributeValue === "true" ? true : false;
                            this.schedulingVariables.cbrForm.controls.additionalNumber.reset();
                            this.schedulingVariables.cbrForm.controls.additionalNumber.setValue(true);
                        }
                    }
                    if (data !== undefined && data !== null && data.reservedCbr) {
                        this.contactNumber = data.reservedCbr;
                    } else if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes
                        && Array.isArray(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
                        this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                            if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                                item.orderAttributeGroup.forEach((item: any) => {
                                    if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                        item.orderAttributeGroupInfo.forEach((item: any) => {
                                            if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                item.orderAttributes.forEach((item: any) => {
                                                    if (item.orderAttributeName === "orderLevelCBRNumber") {
                                                        this.contactNumber = item.orderAttributeValue;
                                                        this.schedulingVariables.isCbr = true;
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                    if (this.isChecked) {
                        this.schedulingVariables.cbrForm.controls.additionalNumber.updateValueAndValidity();
                    }
                    if (this.schedulingVariables.appointmentResponse.payload.appointmentInfo) {
                        this.appointmentNotes = this.schedulingVariables.appointmentResponse.payload.apptNotes;
                    } else {
                        this.schedulingVariables.showReserveItButton = false;
                    }
                    this.schedulingHelperService.splitDueDateEligibleCheck(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes, this.schedulingVariables);
                    let dateInString: string;
                    if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment && this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0]
                        && this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0].commitmentDateTime) {
                        dateInString = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0].commitmentDateTime.trim().substr(0, 10).replace(/-/g, '\/');
                        this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                    } else if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.dueDate &&
                        this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate) {
                        dateInString = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                        this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                    }
                    if (this.appointmentNotes !== undefined) {
                        this.schedulingVariables.animalsPresentCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.animalsPresentCheckBox : this.appointmentNotes.animalsPresent ?
                            this.appointmentNotes.animalsPresent : false;
                        this.schedulingVariables.electricFenceCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.electricFenceCheckBox : this.appointmentNotes.electricFence ?
                            this.appointmentNotes.electricFence : false;
                        this.schedulingVariables.lockedGateCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.lockedGateCheckBox : this.appointmentNotes.lockedGate ?
                            this.appointmentNotes.lockedGate : false;
                    }
                    this.schedulingVariables.drivingDirections = this.schedulingVariables.isReEntrant ? this.schedulingVariables.drivingDirections : '';
                    this.schedulingVariables.additionalComments = this.schedulingVariables.isReEntrant ? this.schedulingVariables.additionalComments : '';
                    /* ------------ RTD Chk ------------ */
                    this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment.map((slot) => {
                            if (slot.timeSlotType === 'SI-RTD' || slot.timeSlotType === 'OTH-BTAP' || slot.timeSlotType === 'TI-RTD' || slot.timeSlotType === 'TI-NORTD' || slot.timeSlotType === 'NOAPPT' || slot.timeSlotType === 'HSI-FCD') {
                                this.isRTDChk = true;
                            }
                        });
                    /* ------------ RTD Chk End------------ */
                    if (this.schedulingVariables.appointmentResponse.payload.appointmentInfo !== null
                        && this.schedulingVariables.appointmentResponse.payload.appointmentInfo !== undefined) {
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment.forEach((x) => {
                            if (x.timeSlotType === 'SI-RTD' || x.timeSlotType === 'OTH-BTAP' ) {
                                this.schedulingVariables.isRTD = true;
                                this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.
                                    availableAppointment.filter((y) => {
                                        return y.timeSlotType === 'SI-RTD' || y.timeSlotType === 'OTH-BTAP';
                                    });
                            } else {
                                this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment;
                                this.schedulingVariables.isRTD = false;
                            }
                        });
                    }
                    if (this.schedulingVariables.appointmentResponse.payload.shippingInfo !== null && this.schedulingVariables.appointmentResponse.payload.shippingInfo !== undefined) {
                        this.shippingAddressObject = this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress;
                        this.schedulingVariables.shippingAddress = this.shippingAddressObject.streetAddress + ',' +
                            this.shippingAddressObject.city + ',' +
                            this.shippingAddressObject.stateOrProvince + ',' +
                            this.shippingAddressObject.postCode;
                        this.schedulingVariables.myForm = this.fb.group({
                            name: [this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingName ? this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingName : this.firstName + ' ' + this.lastName,
                            [Validators.required, <any>Validations.nameValidator]],
                            addressLine: this.shippingAddressObject.streetAddress ? [this.shippingAddressObject.streetAddress, Validators.required] : ['', Validators.required],
                            unitNumber: [this.shippingAddressObject.streetNrFirst ? this.shippingAddressObject.streetNrFirst : ''],
                            info: [this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddlInfo ? this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddlInfo : ''],
                            state: [this.shippingAddressObject.stateOrProvince, Validators.required],
                            city: [this.shippingAddressObject.city ? this.shippingAddressObject.city : '', [Validators.required, <any>Validations.nameValidator]],
                            zipCode: [this.shippingAddressObject.postCode ? this.shippingAddressObject.postCode : '', Validations.zipCodeValidator]
                        });
                    }
                    this.schedulingHelperService.cbrMethod(this.contactNumber.trim(), this.schedulingVariables);
                }
                if (this.shippingAddressObject !== null && this.shippingAddressObject !== undefined && this.shippingAddressObject.isValidated !== undefined && !this.shippingAddressObject.isValidated && !this.schedulingVariables.isReEntrant) {
                    this.schedulingVariables.postalAddressValidated = false;
                }
            });
            this.appointmentSubscription.unsubscribe();
        }
        let customize = <Observable<any>>this.store.select('customize');
        this.customizeSubscription = customize.subscribe((data) => {
            if (data && data.payload && data.payload.reservedTN) {
                this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
            }
        })
        let existingProd = <Observable<any>>this.store.select('existingProducts');
        this.existingProdSubscription = existingProd.subscribe((data) => {
            this.existingData = data;
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                    this.contactNumberExists = true;
                }
            }
            if (this.existingData && this.existingData.existingTN) {
                this.existingTN = this.existingData.existingTN;
            }
            if (this.existingData && this.existingData !== null && this.existingData.orderFlow !== null && this.existingData.orderFlow.flow === 'Move') {
                this.schedulingVariables.orderFlow = this.existingData.orderFlow.flow;
                if (this.existingData && this.existingData !== null
                    && this.existingData.existingProductsAndServices[0] && this.existingData.existingProductsAndServices[0] !== null
                    && this.existingData.existingProductsAndServices[0].existingServices && this.existingData.existingProductsAndServices[0].existingServices !== null
                    && this.existingData.existingProductsAndServices[0].existingServices.existingServiceItems && this.existingData.existingProductsAndServices[0].existingServices.existingServiceItems !== null) {
                    this.existingData.existingProductsAndServices[0].existingServices.existingServiceItems.map((item) => {
                        if (item.offerCategory === "VOICE-HP") {
                            this.isPots = true;
                        } else {
                            this.isPots = false;
                        }
                    });
                }
            }
            if (this.existingData && this.existingData !== null && this.existingData.orderFlow !== null && this.existingData.orderFlow.flow !== undefined &&
                this.existingData.orderFlow.type === 'fromHold' && !this.existingData.orderFlow.schedulingCalled) {
                let pendingObservable = <Observable<any>>this.store.select('pending');
                let pendingSubscription = pendingObservable.subscribe(pending => {
                    if (pending && pending.orderDocument && pending.orderDocument.schedule && pending.orderDocument.schedule.apptNotes) {
                        this.schedulingVariables.animalsPresentCheckBox = pending.orderDocument.schedule.apptNotes.animalsPresent;
                        this.schedulingVariables.electricFenceCheckBox = pending.orderDocument.schedule.apptNotes.electricFence;
                        this.schedulingVariables.lockedGateCheckBox = pending.orderDocument.schedule.apptNotes.lockedGate;
                        this.schedulingHelperService.splitDueDateEligibleCheck(pending.orderDocument.addlOrderAttributes, this.schedulingVariables);
                        this.schedulingVariables.changeEffectiveBillAddress = true;
                        pending.orderDocument.schedule.apptNotes.notes.map((x) => {
                            if (x.name === 'Driving Directions') {
                                this.schedulingVariables.drivingDirections = x.value;
                            } else if (x.name === 'Additional Comments') {
                                this.schedulingVariables.additionalComments = x.value;
                            }
                        });
                    }
                    this.existingTN = pending && pending.orderDocument && pending.orderDocument.existingTN && pending.orderDocument.existingTN[0] && pending.orderDocument.existingTN[0].requestedTelephoneNumber;
                    this.currentTN = pending && pending.orderDocument && pending.orderDocument.reservedTN && pending.orderDocument.reservedTN[0] && pending.orderDocument.reservedTN[0].requestedTelephoneNumber;
                })
                if (pendingSubscription !== undefined) pendingSubscription.unsubscribe();
                if (this.existingData && this.existingData !== null
                    && this.existingData.existingProductsAndServices[0] && this.existingData.existingProductsAndServices[0] !== null
                    && this.existingData.existingProductsAndServices[0].existingServices && this.existingData.existingProductsAndServices[0].existingServices !== null && this.existingData.existingProductsAndServices[0].existingServices.length > 0) {
                    this.existingData.existingProductsAndServices[0].existingServices.map((item) => {
                        if (item.offerCategory === "VOICE-HP") {
                            this.isPots = true;
                        } else {
                            this.isPots = false;
                        }
                    });
                }
            }
        })
        if ((this.isTnChanged !== (null || undefined) && this.isTnChanged) || (this.currentTN !== (null || undefined) && this.currentTN !== this.existingTN) && this.isPots) {
            this.schedulingVariables.phonenoChanged = 'yes';
        } else {
            this.schedulingVariables.phonenoChanged = 'no';
        }
        this.finalPaymentDate = this.schedulingHelperService.fetchAddlOrderAttributes(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes, 'finalPaymentDate')
        this.schedulingHelperService.initializeAdjustableOtcInfo(this.schedulingVariables);
        this.schedulingHelperService.waiveOtcAllowedCheck(this.schedulingVariables);
        this.schedulingVariables.adjustableOtcProducts.forEach(otc => {
            if(otc && otc.otcDetails && otc.otcDetails.discountedOtc){
                this.schedulingVariables.eligibleCharges += +otc.otcDetails.discountedOtc;
            }
        });
    }
    public ngAfterViewInit() {
        this.schedulingVariables.orderDisclosures = this.orderDisclosures;
        if (this.previousUrl === '/move-account' || this.previousUrl === '/customize-services') {
            if (this.retainReservedAppointment) {
                this.schedulingVariables.reservedAppointment = this.retainReservedAppointment;
            }
        }
    }
    public ngOnInit() {
        this.logger.metrics('SchedulingMoveScheduleShippingAppointmentPage');
        this.cartObservable = <Observable<any>>this.store.select('cart');
        this.cart1Subscription = this.cartObservable.subscribe((cartdata) => {
            if(cartdata && cartdata.waivedOtcInfo ){
                this.schedulingVariables.waivedOtcInfo = cartdata.waivedOtcInfo;
                if(this.schedulingVariables.waivedOtcInfo) {
                    this.schedulingHelperService.retainWaivedOtc(this.schedulingVariables);
                }
            } 
        });
        window.scroll(0, 0);
        let existingProd = <Observable<any>>this.store.select('existingProducts');
        this.existingProdSubscription = existingProd.subscribe((data) => {
            this.existingData = data;
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                    this.contactNumberExists = true;
                }
            }
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber && data.existingProductsAndServices[0].accountInfo.contact.contactNumber !== '') {
                    this.contactNumber2 = data.existingProductsAndServices[0].accountInfo.contact.contactNumber;
                }
            }
        })
        let userDate = <Observable<any>>this.store.select('user')
        userDate.subscribe((data) => {
            if (data && data.prepaidFlag && data.prepaidFlag === "PREPAID") {
                this.schedulingVariables.isPrepaid = true;
                this.offerBillingType = true;
                this.billingType = data.prepaidFlag
            } else {
                this.offerBillingType = false;
                this.billingType = data.prepaidFlag
            }
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.newLocation
                && data.orderInit.payload.newLocation.serviceAddress && data.orderInit.payload.newLocation.serviceAddress.locationAttributes
                && data.orderInit.payload.newLocation.serviceAddress.locationAttributes.legacyProvider === 'CENTURYLINK') {
                this.schedulingVariables.isCenturyLink = true;
            }
        });
        this.schedulingVariables.cbrForm.controls.contactNumber.valueChanges.subscribe(value => {
            if (!this.schedulingVariables.isReEntrant) {
                this.isadditionalNumberChecked = false;
                this.schedulingVariables.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                this.schedulingVariables.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                if (this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber) {
                    if (this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                        this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                    }
                }
            } else {
                if (this.reentrantnumber === value.toString().replace(/[^A-Z0-9]/ig, "")) {
                    this.isChecked = this.isReentrantAdditionalnumberChecked;
                    if (this.isReentrantAdditionalnumberChecked) {
                        this.schedulingVariables.formattedNumber = '';
                    }
                    this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(this.isadditionalNumberChecked);
                } else {
                    this.isadditionalNumberChecked = false;
                    this.isChecked = true;
                    this.schedulingVariables.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                    this.schedulingVariables.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                    if (this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber) {
                        if (this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                            this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                        }
                    }
                }
            }
        });
        let customize = <Observable<any>>this.store.select('customize');
        
        this.customizedSubscription = customize.subscribe((data) => {
            if (data && data.payload && data.payload !== undefined && data.payload.reservedTN !== undefined && data.payload.reservedTN.length !== 0) {
                this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
            }
        });
    }
    public ngOnDestroy() {
        if (this.userSubscription) this.userSubscription.unsubscribe();
        if (this.cartSubscription) this.cartSubscription.unsubscribe();
    }
    public effectiveBillDateUpdated(event) {
        this.schedulingVariables.selectedDueDate = event.trim().substr(0, 10);
        this.schedulingHelperService.showRefundTextMessage(this.schedulingVariables.selectedDueDate, this.schedulingVariables.selectedAppointmentDate);
        this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = this.ctlHelperService.convertDateFormat(event);
        this.schedulingHelperService.splitDueDateEligibleCheck(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes, this.schedulingVariables, event);
    }
    public changeShippingAddr() {
        this.schedulingVariables.showShippingAddress = !this.schedulingVariables.showShippingAddress;
        this.schedulingVariables.changeShippingAddressSelected = true;
    }
    public cartSubscription: Subscription;
    public cancelClick() {
        this.router.navigate(['/home']);
    }
    public referralResp(event) {
        this.schedulingVariables.errorMsg = '';
        this.schedulingVariables.referralRequest = event;
    }
    
}