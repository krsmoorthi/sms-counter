import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { User } from '../../common/models/user.model';
import { AppStore } from '../../common/models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { VacationService } from '../../common/service/vacation.service';
import { SchedulingVariables } from '../../common/models/schedule.shipping.model';
import { AppStateService } from '../../common/service/app-state.service';
import { Logger } from '../../common/logging/default-log.service';
import { GenericValues } from '../../common/models/common.model';
import { TextMaskService } from '../../common/service/text-mask.service';
import { DialogComponent } from '../../common/popup/dialog.component';
import "rxjs/add/operator/catch";
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
@Component({
    selector: 'vacation-schedule-appt-ship',
    templateUrl: './vacation-schedule.component.html',
    styleUrls: ['../schedule-component/schedule.component.scss']
})
export class VacationScheduleComponent implements OnInit, OnDestroy, AfterViewInit {
    private scheduleSubscription: Subscription;
    private schedule: Observable<any>;
    public dueDate: string;
    private effectiveBillDate: string;
    private taskId: string;
    private scheduleRe: any;
    public retain: any;
    private userSubscription: any;
    public isReferralRequired: any;
    public appointmentResponse: any;
    public checkBoxChecked = false;
    public finalDateInfo: any;
    public isdateChanged: any;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    public orderRefNumber: string;
    private vacationObservable: Observable<any>;
    private vacationSubscription: Subscription;
    public isChecked = false;
    private isReentrantAdditionalnumberChecked = false;
    private isadditionalNumberChecked = false;
    public contactNumberExists = false;
    public phoneMask: any;
    private contactNumber = '';
    public calculatedDueDate: any;
    public changeEffectiveBillAddress: boolean = false;
    public billeffectmindate: string;
    public billeffectmaxdate: string;
    public isBillEffectiveDate: boolean = false;
    public customizedSubscription: Subscription;
    public currentTN: any;
    public reentrantnumber: any;
    public showReserveItButton: any;
    public cartSubscription: Subscription;
    public reservedAppointment: any;
    public schedulingVariables: SchedulingVariables;
    public errorMsg: any;
    public referralRequest: any;

    constructor(private logger: Logger,
        public schedulingHelperService: SchedulingHelperService,
        private appStateService: AppStateService,
        private vacationService: VacationService,
        private store: Store<AppStore>,
        private textMask: TextMaskService) {
        this.appStateService.setLocationURLs();
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.schedule = store.select('appointment');
        if (this.schedule && this.schedule !== null && this.schedule !== undefined) {
            this.scheduleSubscription = this.schedule.subscribe((data) => {
                this.appointmentResponse = data;
                if (data !== undefined && data !== null && data.reservedCbr) {
                    this.contactNumber = data.reservedCbr;
                }
                if (data && data.payload && data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.minBedDate) {
                    this.billeffectmindate = data.payload.billeffectiveDateInfo.minBedDate;
                    this.isBillEffectiveDate = true;
                }
                if (data && data.payload && data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.maxBedDate) {
                    this.billeffectmaxdate = data.payload.billeffectiveDateInfo.maxBedDate;
                    this.isBillEffectiveDate = true;
                }
                let user = <Observable<User>>store.select('user');
                this.userSubscription = user.subscribe(
                    (usr) => {
                        if (usr.currentUrl === "/vacation-schedule-appt-ship") {
                            this.schedulingVariables.currentComponet = "vacation-schedule.component.ts";
                            this.schedulingVariables.isVacationFlow = true;
                        }
                        if (usr.previousUrl !== '/existing-products' && usr.previousUrl !== '/vacation-option' && usr.previousUrl !== '/customize-services') {
                            this.schedulingVariables.isReEntrant = true;
                            this.taskId = usr.taskId;
                            let retainVal = <Observable<any>>store.select('retain');
                            let retSubscribe = retainVal.subscribe(
                                retVal => {
                                    this.retain = retVal;
                                    this.scheduleRe = retVal.account;
                                    if (retVal && retVal.retainscheduling && retVal.retainscheduling !== undefined && retVal.retainscheduling && retVal.retainscheduling.payload && retVal.retainscheduling.payload !== undefined) {
                                        this.isReferralRequired = retVal.retainscheduling.payload.referralRequired;
                                    } else {
                                        this.fromHold(store);
                                    }
                                    if (this.scheduleRe) {
                                        data = this.scheduleRe;
                                    }
                                }
                            )
                            if (retSubscribe !== undefined) retSubscribe.unsubscribe();
                        } else {
                            let reentrant = this.vacationService.isSchedulingReEntrant;
                            if (reentrant) {
                                this.schedulingVariables.isReEntrant = true;
                                this.taskId = usr.taskId;
                            } else {
                                this.schedulingVariables.isReEntrant = false;
                            }
                            this.fromHold(store);
                            let retain: any = this.store.select('retain');
                            retain.subscribe((data) => {
                                if (data && data.retainscheduling) {
                                    this.schedulingVariables.isReEntrant = data.reentrantscheduling;
                                    if(this.schedulingVariables.isReEntrant) { this.taskId = usr.taskId; }
                                    if (data.retainscheduling.payload &&
                                        data.retainscheduling.payload.referralRequired) {
                                        this.isReferralRequired = data.retainscheduling.payload.referralRequired;
                                    }
                                }
                            })
                        }
                        if (usr && usr.taskId && this.schedulingVariables.isReEntrant) {
                            this.schedulingVariables.vacScheTaskId = usr.taskId;
                        }
                        if (usr.phoneNumber !== undefined && usr.phoneNumber !== '') {
                            this.contactNumber = usr.phoneNumber;
                        }
                        if (usr && usr.orderRefNumber) {
                            this.orderRefNumber = usr.orderRefNumber;
                        }
                    });
                this.userSubscription.unsubscribe();
            });
            this.scheduleSubscription.unsubscribe();
        }
    }
    private fromHold(store: Store<AppStore>) {
        let existingProducts = <Observable<any>>store.select('existingProducts');
        let existingProductsSubscription = existingProducts.subscribe((data) => {
            if (data && data.orderFlow && data.orderFlow.flow === 'EXISTING' && data.orderFlow.type === 'fromHold') {
                this.schedulingVariables.isReEntrant = true;
                let pendingSummaryObservable = <Observable<any>>store.select('pending');
                let pendingSummarySubscription = pendingSummaryObservable.subscribe((pendingData) => {
                    if (pendingData && pendingData.orderDocument && pendingData.orderDocument.customerOrderItems && pendingData.orderDocument.customerOrderItems.length > 0) {
                        pendingData.orderDocument.customerOrderItems.map(item => {
                            if (item.offerCategory === GenericValues.cHP && item.offerType === 'VAS_INTERCEPT') {
                                this.isReferralRequired = 'yes';
                                this.referralRequest = {
                                    payload: {
                                        cart: pendingData.orderDocument.customerOrderItems
                                    }
                                };
                                this.retain = {
                                    account: {
                                        payload: {
                                            productConfiguration: pendingData.orderDocument.productConfiguration
                                        }
                                    }
                                };
                            }
                        });
                    }
                });
                if (pendingSummarySubscription !== undefined)
                    pendingSummarySubscription.unsubscribe();
            }
        });
        if (existingProductsSubscription !== undefined)
            existingProductsSubscription.unsubscribe();
    }
    public ngAfterViewInit() {
        this.schedulingVariables.orderDisclosures = this.orderDisclosures;
    }
    public ngOnInit() {
        this.logger.metrics('SchedulingVacationSchedulePage');
        this.vacationObservable = <Observable<any>>this.store.select('vacation');
        this.vacationSubscription = this.vacationObservable.subscribe((data) => {
            this.schedulingVariables.appointmentResponse = data.vacationscheduleresponse;
            if (data && data.vacationscheduleresponse && data.vacationscheduleresponse.orderRefNumber) {
                this.schedulingVariables.vacScheOrderRefNumber = data.vacationscheduleresponse.orderRefNumber;
            }
            if (data && data.vacationscheduleresponse && data.vacationscheduleresponse.payload && data.vacationscheduleresponse.payload.addlOrderAttributes && data.vacationscheduleresponse.payload.addlOrderAttributes.length > 0) {
                data.vacationscheduleresponse.payload.addlOrderAttributes.map(i => {
                    if (i && i.orderAttributeGroup) {
                        i.orderAttributeGroup.map(k => {
                            if (k.orderAttributeGroupName === "orderLevelCBRInfo") {
                                var ls = k.orderAttributeGroupInfo; ls.map(j => {
                                    if (j) {
                                        j.orderAttributes.map(l => {
                                            if (this.schedulingVariables.isReEntrant && l.orderAttributeName === "orderLevelCBRNumber") {
                                                this.schedulingVariables.formattedNumber = l.orderAttributeValue;
                                                this.reentrantnumber = this.schedulingVariables.formattedNumber;
                                                this.schedulingHelperService.cbrMethod(l.orderAttributeValue, this.schedulingVariables);
                                            }
                                            if (this.schedulingVariables.isReEntrant && l.orderAttributeName === "storeAsAccountLevelCBR2") {
                                                this.isChecked = true;
                                                this.isReentrantAdditionalnumberChecked = true;
                                                this.isadditionalNumberChecked = l.orderAttributeValue === true ? true : false;
                                                this.schedulingVariables.cbrForm.controls.additionalNumber.setValue(this.isadditionalNumberChecked);
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }
                });
            } else if (this.appointmentResponse && this.appointmentResponse.payload && this.appointmentResponse.payload.addlOrderAttributes
                && Array.isArray(this.appointmentResponse.payload.addlOrderAttributes) && this.appointmentResponse.payload.addlOrderAttributes.length > 0) {
                this.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                    if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                        item.orderAttributeGroup.forEach((item: any) => {
                            if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                item.orderAttributeGroupInfo.forEach((item: any) => {
                                    if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                        item.orderAttributes.forEach((item: any) => {
                                            if (item.orderAttributeName === "orderLevelCBRNumber") {
                                                this.contactNumber = item.orderAttributeValue;
                                                this.schedulingVariables.isCbr = true;
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
            if (data && data.vacationscheduleresponse && data.vacationscheduleresponse.taskId && !this.schedulingVariables.isReEntrant) {
                this.schedulingVariables.vacScheTaskId = data.vacationscheduleresponse.taskId;
            }
            if (data && data.vacationscheduleresponse && data.vacationscheduleresponse.taskName) {
                this.schedulingVariables.vacScheTaskName = data.vacationscheduleresponse.taskName;
            }
            if (data && data.vacationscheduleresponse && data.vacationscheduleresponse.processInstanceId) {
                this.schedulingVariables.vacScheProcessInstanceId = data.vacationscheduleresponse.processInstanceId;
            }
            if (data && data.vacationscheduleresponse && data.vacationscheduleresponse.payload && data.vacationscheduleresponse.payload.dueDate) {
                let dueDate = data.vacationscheduleresponse.payload.dueDate;
                if (dueDate.finalDueDate) {
                    this.dueDate = dueDate.finalDueDate.substring(0, 23);
                };
                if (dueDate.effectiveBillDate) {
                    this.effectiveBillDate = dueDate.effectiveBillDate.substring(0, 23);
                    this.changeEffectiveBillAddress = true;
                };
                if (dueDate.calculatedDueDate) {
                    this.calculatedDueDate = dueDate.calculatedDueDate.substring(0, 23);
                };
                this.schedulingHelperService.cbrMethod(this.contactNumber.trim(), this.schedulingVariables);
                let existingProd = <Observable<any>>this.store.select('existingProducts');
                existingProd.subscribe((data) => {
                    if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                        && data.existingProductsAndServices[0].accountInfo) {
                        if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                            this.contactNumberExists = true;
                        }
                    }
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].serviceAddress && data.existingProductsAndServices[0].serviceAddress.locationAttributes
                        && data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider === 'CENTURYLINK') {
                        this.schedulingVariables.isCenturyLink = true;
                    }
                })
            }
        });
        window.scroll(0, 0);
        this.schedulingVariables.cbrForm && this.schedulingVariables.cbrForm.controls && 
        this.schedulingVariables.cbrForm.controls.contactNumber.valueChanges.subscribe(value => {
            if (!this.schedulingVariables.isReEntrant) {
                this.isadditionalNumberChecked = false;
                this.schedulingVariables.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                this.schedulingVariables.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                if (this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber) {
                    if (this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                        this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                    }
                }
            } else {
                if (this.reentrantnumber === value.toString().replace(/[^A-Z0-9]/ig, "")) {
                    this.isChecked = this.isReentrantAdditionalnumberChecked;
                    if (this.isReentrantAdditionalnumberChecked) {
                        this.schedulingVariables.formattedNumber = '';
                    }
                    this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(this.isadditionalNumberChecked);
                } else {
                    this.isadditionalNumberChecked = false;
                    this.isChecked = true;
                    this.schedulingVariables.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                    this.schedulingVariables.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                    if (this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber) {
                        if (this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                            this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                        }
                    }
                }
            }
        });
        let customize = <Observable<any>>this.store.select('customize');
        this.customizedSubscription = customize.subscribe((data) => {
            if (data && data.payload && data.payload !== undefined && data.payload.reservedTN !== undefined && data.payload.reservedTN.length !== 0) {
                this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
            }
        });
    }
    public ngOnDestroy() {
        this.userSubscription.unsubscribe();
        this.scheduleSubscription.unsubscribe();
        this.vacationSubscription.unsubscribe();
    }
    public handleDueDateUpdated(event) {
        this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = event;
        this.dueDate = event.substring(0, 23);
        this.isdateChanged = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        this.finalDateInfo = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
    }
    public handleEffectiveBillDateUpdated(event) {
        this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = event;
        this.effectiveBillDate = event.substring(0, 23);
    }
    public addBillDate() {
        this.changeEffectiveBillAddress = !this.changeEffectiveBillAddress;
        if (!this.effectiveBillDate) {
            this.effectiveBillDate = this.calculatedDueDate
        }
    }
    public referralResp(event) {
        this.referralRequest = event;
    }
    public additionalNumberChange(data) {
        this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(data.currentTarget.checked);
        this.checkBoxChecked = data.currentTarget.checked;
    }
}