import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VacationScheduleComponent } from './vacation-schedule.component';
import { MockServer } from 'app/MockServer.test';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Observable } from 'rxjs';
import { SchedulingHelperService } from '../service/scheduleHelper.service';
import { MockLogger, MockVacationService, MockReviewOrderService, MockPendingOrderService, MockAccountService, MockAddressService, MockCountryStateService, MockDirectvService, MockPropertiesHelperService, MockDisconnectService, MockSystemErrorService, MockSchedulingService, MockDisclosuresService, MockHelperService, MockProductService, MockBlueMarbleService } from 'app/common/service/mockServices.test';
import { AppStateService } from 'app/common/service/app-state.service';
import { Logger } from 'app/common/logging/default-log.service';
import { VacationService } from 'app/common/service/vacation.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { Store } from '@ngrx/store';
import { TabsModule, AccordionModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { SchedulingService } from 'app/common/service/scheduling.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { HelperService } from 'app/common/service/helper.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';

describe('VacationScheduleComponent', () => {
  let component: VacationScheduleComponent;
  let fixture: ComponentFixture<VacationScheduleComponent>;
  const mockServer = new MockServer();

  const imports = [
    RouterTestingModule,
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    TextMaskModule,
    SharedModule,
    SharedCommonModule,
    FormsModule,
    ReactiveFormsModule
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }
  class MockAppStateService{
    setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('VS_HSI_POTS_STATE_TILL_CONFIRMATION_PAGE');
    }
  }

  const store = { provide: Store, useValue: mockRedux };
  const vacationService = { provide: VacationService, useClass: MockVacationService };
  const logger = { provide: Logger, useClass: MockLogger };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const textMaskService = TextMaskService;
  const schedulingHelperService = SchedulingHelperService;
  const reviewOrderService = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService};
  const accountService = {provide: AccountService, useClass: MockAccountService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const directvService = {provide: DirectvService, useClass: MockDirectvService};
  const propertiesHelperService = {provide: PropertiesHelperService, useClass: MockPropertiesHelperService};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const systemErrorService = {provide: SystemErrorService, useClass: MockSystemErrorService};
  const schedulingService = {provide: SchedulingService, useClass: MockSchedulingService};
  const disclosuresService = {provide: DisclosuresService, useClass: MockDisclosuresService};
  const helperService = {provide: HelperService, useClass: MockHelperService};
  const productService = {provide: ProductService, useClass: MockProductService};
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
 
  const providers = [
    store, systemErrorService, logger, appStateService, textMaskService, schedulingHelperService,
    reviewOrderService, pendingOrderService, accountService, addressService, countryStateService,
    directvService, propertiesHelperService, disconnectService, CTLHelperService, vacationService,
    schedulingService, disclosuresService, helperService, productService, blueMarbleService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [ VacationScheduleComponent ],
    providers: providers
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VacationScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create vacation schedule component', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnDestroy', () => {
    const returnVal = component.ngOnDestroy();
    expect(returnVal).toEqual(undefined);
  });
  
  it('should call handleDueDateUpdated', () => {
    const e = '2020-04-28T08:55:43.055Z';
    component.handleDueDateUpdated(e);
    expect(component.dueDate).toEqual(e.substring(0, 23));
  });

  it('should call handleEffectiveBillDateUpdated', () => {
    const e = '2020-04-28T08:55:43.055Z';
    component.handleEffectiveBillDateUpdated(e);
    expect((component as any).effectiveBillDate).toEqual(e.substring(0, 23));
  });

});
