import { NgModule } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { VacationScheduleComponent } from './vacation-schedule.component';
import { SharedModule } from 'app/shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { FirstCustomizePipe } from 'app/common/pipes/firstcapcustom.pipe';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: VacationScheduleComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(COMPONENT_ROUTER),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,
        SharedModule,
        SharedCommonModule,
        FormsModule,
        ReactiveFormsModule
    ],
    exports: [VacationScheduleComponent],
    declarations: [VacationScheduleComponent],
    providers: [
        TextMaskService,
        FirstCustomizePipe,
        SchedulingHelperService
    ]
})
export class VacationScheduleModule { }
