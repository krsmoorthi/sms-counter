import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentNotes, AvailableAppointment } from '../common/models/appointment.model';
import { User } from '../common/models/user.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStore } from '../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { DatePipe } from '@angular/common';
import { AppStateService } from '../common/service/app-state.service';
import { SchedulingVariables } from 'app/common/models/schedule.shipping.model';
import { Logger } from '../common/logging/default-log.service';
import { APIErrorLists } from '../common/models/common.model';
import { AppointmentShipping, ShippingAddres } from '../common/models/schedule-shipping.model';
import { Validators, FormBuilder } from '@angular/forms';
import { Validations } from '../common/validations/validations';
import { CountryStateService } from '../common/service/country-state.service';
import { TextMaskService } from '../common/service/text-mask.service';
import { cloneDeep, filter } from 'lodash';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';
import { AppConstant } from 'app/app.constant';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'schedule-appt-ship',
    styleUrls: ['./schedule-component/schedule.component.scss'],
    templateUrl: './schedule-shipping-appointment.component.html'
})

export class ScheduleShippingAppointmentComponent implements OnInit, OnDestroy, AfterViewInit {
    public userSubscription: Subscription;
    public user: Observable<User>;
    public apptSubscription: Subscription;
    public apptObservable: Observable<any>;        
    public apiResponseError: APIErrorLists;
    public customerRequestedDueDateNotAvailableCheckBox: boolean = false;
    public changeEffectiveBillAddress: boolean = false;        
    private availableAppointment: AvailableAppointment[];
    public availableAppointments: AvailableAppointment[];
    private appointment: Observable<AppointmentShipping>;
    private appointmentSubscription: Subscription;
    public schedulingVariables: SchedulingVariables;
    private appointmentNotes: AppointmentNotes;
    public phoneMask: any;    
    public yellowMatch: boolean = false;         
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public cartSubscription: Subscription;
    public existingData: any;
    public fromHold: boolean = false;
    public reqDeposit: boolean = false;
    public customizeData: any;
    public isRTD: boolean = false;        
    private states: any;
    public selectedState;
    public taskId: string = '';              
    private contactNumber = '';     
    public retain: any;
    public pendingObservable: Observable<any>;
    public customizeSubscription: Subscription;
    public existingProdSubscription: Subscription;
    private currentTN: any;
    private existingTN: any;
    public contactNumberExists = false;
    public contactNumber2: any    
    private isPots: boolean = false;        
    private isTnChanged = false;    
    private previousUrl;
    private isChecked = false;
    private isReentrantAdditionalnumberChecked = false;
    private isadditionalNumberChecked = false;
    private finalDueDate;    
    private retainReservedAppointment;    
    public customerOrderNum: any;
    public stackDuedate: any;
    public stackDueDateShow: boolean = false;
    public isStack: boolean = false;
    public isinternet: boolean;
    public ishomephone: boolean;
    public billeffectmindate: string;
    public billeffectmaxdate: string;
    public isBillEffectiveDate: boolean = false; 
    public calculatedDueDate: any; 
    public customizedSubscription: Subscription;    
    public reentrantnumber: any;    
    @ViewChild('orderDisclosures', { static: false }) public orderDisclosures: DialogComponent;
    public stackAmendDropDownTitle: string = '';
    public cartObservable: Observable<any>;
    public apptDropdown: boolean;
    public cart1Subscription: Subscription;
    public isApptUpdated: boolean;    
    public disableCalRef: boolean = false;
    public billingType: string = '';         
    public existingMRCtoCart: any = [];
    public offerDisplayName: any;
    public isCORSTeam: boolean = false;   
    public allowTechDropModems: boolean;
    public ban: any;
    public prepaidPaymentDone: boolean = false;
    public onholdRestrictedMsg = AppConstant.CANNOT_HOLD_PREPAID_AFTER_PAYMENT;
    public ngOnDestroy$ = new Subject();

    constructor(
        private logger: Logger,
        private router: Router,
        private store: Store<AppStore>,
        public schedulingHelperService: SchedulingHelperService,
        private fb: FormBuilder,
        private appStateService: AppStateService, 
        private countryStateService: CountryStateService,
        private textMask: TextMaskService,
        private helperService: HelperService,
        private propertiesHelperService: PropertiesHelperService,
        private changeDetector: ChangeDetectorRef
        ) {
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);
        this.appStateService.setLocationURLs();
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.appointment = this.store.select('appointment');
        this.isCORSTeam = this.helperService.isAuthorized(ProfileEnums.ALLOW_CURRENT_DUE_DATE);
        this.allowTechDropModems = this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_TECH_DROP_MODEMS);
        let shippingObject: any;
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointmentSubscription = this.appointment
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                let apoitmentData = cloneDeep(data);
                if (apoitmentData && apoitmentData.payload && apoitmentData.payload.billeffectiveDateInfo && apoitmentData.payload.billeffectiveDateInfo.minBedDate) {
                    this.billeffectmindate = apoitmentData.payload.billeffectiveDateInfo.minBedDate;
                    this.isBillEffectiveDate = true;
                }
                if (apoitmentData && apoitmentData.payload && apoitmentData.payload.billeffectiveDateInfo && apoitmentData.payload.billeffectiveDateInfo.maxBedDate) {
                    this.billeffectmaxdate = apoitmentData.payload.billeffectiveDateInfo.maxBedDate;
                    this.isBillEffectiveDate = true;
                }
                this.changeEffectiveBillAddress = apoitmentData.effectiveBillDateChange;
                let user = <Observable<User>>this.store.select('user');
                this.pendingObservable = <Observable<any>>this.store.select('pending');
                let pendingSub = this.pendingObservable
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe(p => {
                    if (p && p.orderDocument && p.orderDocument.schedule && p.orderDocument.schedule.dates && p.orderDocument.schedule.dates.finalDueDate) {
                        this.schedulingVariables.prevDate = new DatePipe('en-US').transform(new Date(p.orderDocument.schedule.dates.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/')), 'mediumDate');
                    }
                    // if(p && p.orderReference && p.orderReference.pointOfNoReturn) this.ponr = p.orderReference.pointOfNoReturn;
                });
                pendingSub.unsubscribe();
                let userSubscription = user
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe(
                    (usr) => {
                        this.billingType = usr.prepaidFlag;
                        if(this.billingType === 'PREPAID') {
                            this.prepaidPaymentDone = usr.paymentStatusChk;
                        }
                        if (Array.isArray(usr.currentSelected)) {
                            usr.currentSelected.forEach((val: any) => {
                                if (val.selected === "DATA") {
                                    this.isinternet = true;
                                }
                            });
                            usr.currentSelected.forEach((val: any) => {
                                if (val.selected === "VOICE-HP") {
                                    this.ishomephone = true;
                                }
                            });
                        }
                        this.schedulingVariables.currentUrl = usr.currentUrl;
                        if(this.schedulingVariables.currentUrl === "/schedule-appt-ship"){
                            this.schedulingVariables.schedulingShippingPage = true;
                            this.schedulingVariables.currentComponet = "schedule-shipping-appointment.component.ts";
                        }
                        if (usr.autoLogin && usr.autoLogin.sfcData && usr.autoLogin.sfcData.type && usr.autoLogin.sfcData.type !== undefined) {
                            this.schedulingVariables.isChange = true;
                            this.schedulingVariables.reuseBan = true;
                        }
                        if (usr.autoLogin && usr.autoLogin.sfcData && usr.autoLogin.sfcData.type && usr.autoLogin.sfcData.type === 'ReopenBAN') {
                            this.schedulingVariables.isChange = false;
                            this.schedulingVariables.reuseBan = true;
                            
                        }

                        if(usr.autoLogin && usr.autoLogin.oamData && usr.autoLogin.oamData.agentFirstName && usr.autoLogin.oamData.agentLastName)
                        {
                            this.schedulingVariables.agentFirstName = usr.autoLogin.oamData.agentFirstName;
                            this.schedulingVariables.agentLastName = usr.autoLogin.oamData.agentLastName;
                        }
                        this.previousUrl = usr && usr.previousUrl;
                        if (usr.previousUrl === '/change-account' && usr.currentUrl === '/schedule-appt-ship') {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if ((this.previousUrl === "/review-order" || this.previousUrl === "/co-review-order") && usr.currentUrl === "/schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (this.previousUrl === "/account" && usr.currentUrl === "/schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (this.previousUrl !== '/customize-services' && this.previousUrl === '/account') {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if ((this.previousUrl === '/account' || this.previousUrl === '/reuse-ban-account') && (usr.currentUrl === '/schedule-appt-ship' || usr.currentUrl === '/schedule-appt')) {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        let usrData = '';
                        if (usr.firstName) {
                            usrData = usrData + usr.firstName;
                        }
                        if (usr.lastName) {
                            usrData = usrData + ' ' + usr.lastName;
                        }
                        if (usr.isDtvOpus) {
                            if (usr.dtvOpus.taskName === 'yes') {
                                this.schedulingVariables.dtvYes = true;
                            }
                        } else {
                            if (usr.dtvQuestionForm.taskName === 'yes') {
                                this.schedulingVariables.dtvYes = true;
                            }
                        }
                        this.schedulingVariables.shippingName = usrData.trim();
                        if (usr.phoneNumber !== undefined && usr.phoneNumber !== '') {
                            this.contactNumber = usr.phoneNumber;
                        }
                        let retainVal = <Observable<any>>this.store.select('retain');
                        retainVal
                        .pipe(takeUntil(this.ngOnDestroy$))
                        .subscribe(
                            (retVal) => {
                                this.retain = retVal;
                                this.schedulingVariables.potsRemoved = retVal.potsRemoved;
                                if (retVal.tnChanged !== (null || undefined)) {
                                    this.isTnChanged = retVal.tnChanged;
                                }
                                if (usr.previousUrl === '/co-review-order' || usr.previousUrl === '/change-account' || usr.previousUrl !== '/customize-services') {
                                    if (usr.previousUrl !== '/existing-products') {
                                        this.schedulingVariables.isReEntrant = true;
                                       if(usr.taskId !== null && usr.taskId !== undefined && this.schedulingVariables.appointmentResponse) {
                                        this.schedulingVariables.appointmentResponse.taskId =  usr.taskId;
                                       }
                                        shippingObject = retVal.account;
                                        if (shippingObject && shippingObject.payload && shippingObject.payload.apptNotes) {
                                            this.schedulingHelperService.getTechRemarks(shippingObject.payload.apptNotes, this.schedulingVariables);
                                        }
                                    }
                                }
                                this.finalDueDate = retVal && retVal.account && retVal.account.payload && retVal.account.payload.dueDate && retVal.account.payload.dueDate.finalDueDate;
                                if (retVal && retVal.retainReservedAppointment) {
                                    this.retainReservedAppointment = retVal.retainReservedAppointment;
                                }
                            });
                        if (usr && usr.orderRefNumber) {
                            this.schedulingVariables.orderRefNumber = usr.orderRefNumber;
                        }
                        if (usr && usr.offerDisplayName && usr.offerDisplayName !== undefined && usr.offerDisplayName.outputAttribute && usr.offerDisplayName.outputAttribute !== undefined) {
                            if (usr.offerDisplayName.outputAttribute.length === 1) {
                                if (usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" || usr.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                                    this.offerDisplayName = usr.offerDisplayName.outputAttribute[0][2];
                                }
                            } else if (usr.offerDisplayName.outputAttribute.length > 1) {
                                if ((usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (usr.offerDisplayName.outputAttribute[1][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") || (usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[1][3] === "INTERNET")) {
                                    if ((usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (usr.offerDisplayName.outputAttribute[1][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") || (usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[1][3] === "INTERNET")) {
                                        this.offerDisplayName = usr.offerDisplayName.outputAttribute[0][2];
                                    } else if (usr.offerDisplayName.outputAttribute[1][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                                        this.offerDisplayName = usr.offerDisplayName.outputAttribute[1][2];
                                    }
                                } else if ((usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" || (usr.offerDisplayName.outputAttribute[0][3] === "VOICE-DHP" || usr.offerDisplayName.outputAttribute[0][3] === "VIDEO-DTV")) && (usr.offerDisplayName.outputAttribute[1][3] === "INTERNET" || (usr.offerDisplayName.outputAttribute[1][3] === "VOICE-DHP" || usr.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV")) && (usr.offerDisplayName.outputAttribute[0][2] !== null && usr.offerDisplayName.outputAttribute[1][2] !== null)) {
                                    this.offerDisplayName = ((usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV") || (usr.offerDisplayName.outputAttribute[0][3] === "INTERNET" && usr.offerDisplayName.outputAttribute[1][3] === "VIDEO-DHP")) ? usr.offerDisplayName.outputAttribute[0][2] + ' ' + usr.offerDisplayName.outputAttribute[1][2] : usr.offerDisplayName.outputAttribute[1][2] + ' ' + usr.offerDisplayName.outputAttribute[0][2];
                                }
                            }
                        }
                    });
                userSubscription.unsubscribe();
                this.existingObservable = <Observable<any>>this.store.select('existingProducts');
                this.existingSubscription = this.existingObservable
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe((data) => {
                    this.existingData = data;
                    this.schedulingVariables.orderFlow = this.existingData.orderFlow && this.existingData.orderFlow.flow;
                    if (this.schedulingVariables.orderFlow === 'Change') {
                        this.schedulingVariables.isChangeFlow = true;
                        this.schedulingVariables.isChange = true;
                    }
                    if (this.existingData && this.existingData.stackamend && this.existingData.stackamend.stackAmendFlag) {
                        if (this.existingData.stackamend.stackAmendFlag === "amendOrder") {
                            this.schedulingVariables.isAmend = true;
                            this.stackAmendDropDownTitle = 'Amend Order';
                        } else if (this.existingData.stackamend.stackAmendFlag === "stackOrder") {
                            this.schedulingVariables.isStack = true;
                            this.isStack = true;
                            this.stackAmendDropDownTitle = ' Stack Order';
                        }
                    }
                });
                this.existingSubscription.unsubscribe();
                if (data && data !== null && data !== undefined && data.payload && data.payload !== null && data.payload !== undefined) {
                    this.schedulingVariables.appointmentResponse = data;
                    this.schedulingVariables.finalDateInfo = data.payload.dueDate.finalDueDate;
                    this.schedulingVariables.isdateChanged = this.schedulingVariables.finalDateInfo;
                    data && data.payload && data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.map(i => { if (i && i.orderAttributeGroup) { i.orderAttributeGroup.map(k => { if (k.orderAttributeGroupName === "interceptlOptionInd") { var ls = k.orderAttributeGroupInfo; ls.map(j => { if (j) { j.orderAttributes.map(l => { if (l.orderAttributeValue) { this.disableCalRef = true } }) } }) } }) } });
                    // if(this.schedulingVariables.isReEntrant && item.orderAttributeName=="storeAsAccountLevelCBR2")                   
                    if (data && data.payload && data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.length > 0) {
                        let additionalAttributes = data.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes;
                        if (this.schedulingVariables.isReEntrant && additionalAttributes.length > 0 && additionalAttributes[0].orderAttributeName === "orderLevelCBRNumber") {
                            this.schedulingVariables.formattedNumber = additionalAttributes[0].orderAttributeValue;
                            this.reentrantnumber = this.schedulingVariables.formattedNumber;
                        }
                        if (this.schedulingVariables.isReEntrant && additionalAttributes.length > 1 && additionalAttributes[1].orderAttributeName === "storeAsAccountLevelCBR2") {
                            this.isChecked = true;
                            this.schedulingHelperService.cbrMethod(data.reservedCbr,this.schedulingVariables);
                            this.isReentrantAdditionalnumberChecked = true;
                            this.isadditionalNumberChecked = additionalAttributes[1].orderAttributeValue === "true" ? true : false;
                            if(this.schedulingVariables.cbrForm) {
                                this.schedulingVariables.cbrForm.controls.additionalNumber.reset();
                                this.schedulingVariables.cbrForm.controls.additionalNumber.setValue(true);
                            }
                        }
                    }
                    if (data !== undefined && data !== null && data.reservedCbr) {
                        this.contactNumber = data.reservedCbr;
                    } else if (this.schedulingVariables.isChange && this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes
                        && Array.isArray(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
                        this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                            if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                                item.orderAttributeGroup.forEach((item: any) => {
                                    if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                        item.orderAttributeGroupInfo.forEach((item: any) => {
                                            if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                item.orderAttributes.forEach((item: any) => {
                                                    if (item.orderAttributeName === "orderLevelCBRNumber" && item.orderAttributeValue !== null && item.orderAttributeValue !== undefined) {
                                                        this.contactNumber = item.orderAttributeValue;
                                                        this.schedulingVariables.isCbr = true;
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                    this.schedulingHelperService.cbrMethod(this.contactNumber.trim(),this.schedulingVariables);
                    /* --------- Re-entrant Scheduling-Amend Flow ------------*/
                    if (this.schedulingVariables.isAmend) {
                        this.schedulingVariables.finalDateInfo = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
                        this.calculatedDueDate = this.schedulingVariables.appointmentResponse.payload.dueDate.calculatedDueDate;
                        if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo) {
                            this.appointmentNotes = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.apptNotes;
                            this.availableAppointments = this.availableAppointment;
                        }
                        if (this.schedulingVariables.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.reason && shippingObject.payload.reason.length > 0) {
                            this.schedulingVariables.requestReason = shippingObject.payload.reason[0];
                            this.schedulingVariables.selectedResonSchedule = this.schedulingVariables.requestReason && this.schedulingVariables.requestReason.reasonText ? this.schedulingVariables.requestReason.reasonText : 'Choose your option..';
                            if (this.schedulingVariables.requestReason && this.schedulingVariables.requestReason.reasonText) {
                                this.schedulingVariables.showChangeApptReasons = true;
                                this.schedulingVariables.isDueDateUpdated = true;
                            }
                        }
                        if (this.schedulingVariables.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.dueDate && shippingObject.payload.dueDate.effectiveBillDate) {
                            this.schedulingVariables.effectiveBillDate = shippingObject.payload.dueDate.effectiveBillDate;
                        }
                    }
                    if (this.isChecked && this.schedulingVariables.cbrForm) {
                        this.schedulingVariables.cbrForm.controls.additionalNumber.updateValueAndValidity();
                    }
                    /*----------- End ----------*/
                    if (this.schedulingVariables.appointmentResponse.payload.appointmentInfo && !this.schedulingVariables.isReEntrant) {
                        this.appointmentNotes = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.apptNotes;
                        this.schedulingVariables.remarkObj = this.appointmentNotes && this.appointmentNotes.notes;
                    } else if (this.schedulingVariables.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.apptNotes) {
                        this.appointmentNotes = shippingObject.payload.apptNotes;
                        this.schedulingVariables.remarkObj = this.appointmentNotes && this.appointmentNotes.notes;
                        this.schedulingVariables.showReserveItButton = false;
                        //this.schedulingVariables.showChangeApptReasons = true;
                        this.schedulingVariables.appointmentResponse.payload.dueDate = shippingObject.payload.dueDate;
                        this.schedulingVariables.postalAddressValidated = true;
                    } else {
                        this.schedulingVariables.showReserveItButton = false;
                    }
                    let dateInString: string;
                    if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment && this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0]
                        && this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0].commitmentDateTime) {
                        let defaultappointment = filter(this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment, { defaultTimeSlot: true });
                        dateInString = defaultappointment[0].commitmentDateTime.trim().substr(0, 10).replace(/-/g, '\/');
                        this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                    } 
                    if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.dueDate &&
                        this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate) {
                        dateInString = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                        this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                    }
                    if (this.appointmentNotes !== undefined) {
                        this.schedulingVariables.animalsPresentCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.animalsPresentCheckBox : this.appointmentNotes.animalsPresent ?
                            this.appointmentNotes.animalsPresent : false;
                        this.schedulingVariables.electricFenceCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.electricFenceCheckBox : this.appointmentNotes.electricFence ?
                            this.appointmentNotes.electricFence : false;
                        this.schedulingVariables.lockedGateCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.lockedGateCheckBox : this.appointmentNotes.lockedGate ?
                            this.appointmentNotes.lockedGate : false;
                    }
                    this.schedulingVariables.drivingDirections = this.schedulingVariables.isReEntrant ? this.schedulingVariables.drivingDirections : '';
                    this.schedulingVariables.additionalComments = this.schedulingVariables.isReEntrant ? this.schedulingVariables.additionalComments : '';
                    this.schedulingVariables.reasonReschedule = this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.reason ? this.schedulingVariables.appointmentResponse.payload.reason : [];
                    this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment.map((slot) => {
                            if (slot.timeSlotType === 'SI-RTD' || slot.timeSlotType === 'OTH-BTAP' || slot.timeSlotType === 'TI-RTD' || slot.timeSlotType === 'TI-NORTD' || slot.timeSlotType === 'NOAPPT' || slot.timeSlotType === 'HSI-FCD' || slot.timeSlotType === 'POTS-FCD') {
                                this.schedulingVariables.isRTDChk = true;
                            }
                        });
                    if (this.schedulingVariables.appointmentResponse.payload.appointmentInfo !== null
                        && this.schedulingVariables.appointmentResponse.payload.appointmentInfo !== undefined) {
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment.forEach((x) => {
                            if (x.timeSlotType === 'SI-RTD' || x.timeSlotType === 'OTH-BTAP' || x.timeSlotType === 'POTS-FCD') {
                                this.isRTD = true;
                                this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.
                                    availableAppointment.filter((y) => {
                                        return y.timeSlotType === 'SI-RTD' || y.timeSlotType === 'OTH-BTAP' || y.timeSlotType === 'POTS-FCD';
                                    });
                            } else {
                                this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment;
                                this.isRTD = false;
                            }
                        });
                        this.availableAppointments = this.availableAppointment;
                    }
                    if (this.schedulingVariables.appointmentResponse.payload.shippingInfo !== null && this.schedulingVariables.appointmentResponse.payload.shippingInfo !== undefined && this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress !== undefined
                        && !this.schedulingVariables.isReEntrant) {
                        this.schedulingVariables.shippingAddressObject = this.schedulingVariables.appointmentResponse.payload.shippingInfo && this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress;
                        this.shippingMethod(this.schedulingVariables.shippingAddressObject, this.schedulingVariables.appointmentResponse.payload.shippingInfo);
                    } else if (this.schedulingVariables.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.shippingInfo !== null
                        && shippingObject.payload.shippingInfo !== undefined) {
                        this.schedulingVariables.shippingAddressObject = shippingObject.payload.shippingInfo.shippingAddress;
                        this.shippingMethod(this.schedulingVariables.shippingAddressObject, shippingObject.payload.shippingInfo);
                        this.schedulingVariables.postalAddressValidated = true;
                    }
                    if (this.schedulingVariables.appointmentResponse.payload.shippingInfo !== undefined && this.schedulingVariables.appointmentResponse.payload.shippingInfo !== null && this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress !== null && this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress !== undefined && !this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress.isValidated && !this.schedulingVariables.isReEntrant) {
                        this.schedulingVariables.postalAddressValidated = false;
                    }                    
                }
            });
            this.appointmentSubscription.unsubscribe();
            this.existingObservable = <Observable<any>>this.store.select('existingProducts');
            this.existingSubscription = this.existingObservable
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                this.existingData = data;
                this.schedulingVariables.orderFlow = this.existingData.orderFlow && this.existingData.orderFlow.flow;
                if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                    && data.existingProductsAndServices[0].accountInfo) {
                    if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                        this.contactNumberExists = true;
                    }
                }
                if (this.schedulingVariables.orderFlow === 'Change') {
                    this.schedulingVariables.isChangeFlow = true;
                    this.schedulingVariables.isChange = true;
                }
                if (this.existingData && this.existingData.existingTN) {
                    this.existingTN = this.existingData.existingTN;
                }
                if (this.existingData && this.existingData.orderFlow && this.existingData.orderFlow.flow && this.existingData.orderFlow.flow === 'Change') {
                    this.existingData.existingProductsAndServices && this.existingData.existingProductsAndServices[0] && this.existingData.existingProductsAndServices[0].existingServices && this.existingData.existingProductsAndServices[0].existingServices.existingServiceItems && this.existingData.existingProductsAndServices[0].existingServices.existingServiceItems.map((item) => {
                        if (item.offerCategory === "VOICE-HP") {
                            this.isPots = true;
                            if(this.existingData.existingProductsAndServices[0]
                                && this.existingData.existingProductsAndServices[0].serviceAddress && this.existingData.existingProductsAndServices[0].serviceAddress.locationAttributes
                                && this.existingData.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider === 'CENTURYLINK') {
                                    this.schedulingVariables.isCenturyLink = true;
                            }
                        } else {
                            this.isPots = false;
                        }
                    });
                }
                if (this.schedulingVariables.orderFlow === 'COR') {
                    this.schedulingVariables.isCORFlow = true;
                    if (this.previousUrl !== '/change-responsibility') {
                        this.fetchListingCatalog(this.schedulingVariables.appointmentResponse.payload.offers[0], 'data');
                        this.existingProductMRCtoCart(this.schedulingVariables.appointmentResponse.payload.cart);
                    }
                    this.store.dispatch({ type: 'FINAL_ADDRESS', payload: this.existingData.existingProductsAndServices[0].serviceAddress });
                }
                if (this.existingData && this.existingData.orderFlow && this.existingData.orderFlow.flow && this.existingData.orderFlow.type &&
                    this.existingData.orderFlow.type === 'fromHold' && !this.existingData.orderFlow.schedulingCalled) {
                    this.fromHold = true;
                    let pendingSubscription = this.pendingObservable
                    .pipe(takeUntil(this.ngOnDestroy$))
                    .subscribe(pending => {
                        if (pending && pending.orderDocument && pending.orderDocument.schedule && pending.orderDocument.schedule.apptNotes &&
                            shippingObject && shippingObject.payload && shippingObject.payload.apptNotes)
                            this.schedulingHelperService.getTechRemarks(shippingObject.payload.apptNotes, this.schedulingVariables);
                        pending && pending.orderDocument && pending.orderDocument.creditReview && pending.orderDocument.creditReview.depositInfo &&
                            pending.orderDocument.creditReview.depositInfo.depositRequired ? this.reqDeposit = true : this.reqDeposit = false;
                    })
                    if (pendingSubscription !== undefined) pendingSubscription.unsubscribe();
                }
                if (this.existingData && this.existingData.stackamend && this.existingData.stackamend.stackAmendFlag && this.existingData.stackamend.stackAmendFlag === "stackOrder") {
                    if (this.existingData && this.existingData.existingProductsAndServices[0] && this.existingData.existingProductsAndServices[0].pendingOrders
                        && this.existingData.existingProductsAndServices[0].pendingOrders[0]) {
                        let pndOrdr = this.existingData.existingProductsAndServices[0].pendingOrders[0];
                        if (pndOrdr.orderReference.customerOrderStatus === "PENDING") {
                            this.stackDueDateShow = true;
                            this.customerOrderNum = pndOrdr.orderReference.customerOrderNumber;
                            let dateInString = pndOrdr.orderDocument.schedule.dates.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                            this.stackDuedate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                        }
                    } else {
                        let pendingSubscriptionl = this.pendingObservable
                        .pipe(takeUntil(this.ngOnDestroy$))
                        .subscribe(pendingData => {
                            let lpendingData = pendingData;
                            if (lpendingData.orderReference.customerOrderStatus === "PENDING") {
                                this.stackDueDateShow = true;
                                this.customerOrderNum = lpendingData.orderReference.customerOrderNumber;
                                let dateInString = lpendingData.orderDocument.schedule.dates.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                                this.stackDuedate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                            }
                        })
                        if (pendingSubscriptionl !== undefined) pendingSubscriptionl.unsubscribe();
                    }
                }
            });
            let customize = <Observable<any>>this.store.select('customize');
            this.customizeSubscription = customize
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                if (data && data.payload && data.payload !== undefined && data.payload.reservedTN !== undefined && data.payload.reservedTN.length !== 0) {
                    this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
                }
                this.customizeData = data;
            });
            if ((this.isTnChanged !== (null || undefined) && this.isTnChanged) || (this.currentTN !== (null || undefined) && this.currentTN !== this.existingTN) && this.isPots) {
                if (this.currentTN !== (null || undefined) && this.currentTN !== this.existingTN) {
                    this.schedulingVariables.phonenoChanged = 'yes';
                }
            } else {
                this.schedulingVariables.phonenoChanged = 'no';
            }

        }
        this.schedulingHelperService.initializeAdjustableOtcInfo(this.schedulingVariables);
        this.schedulingHelperService.waiveOtcAllowedCheck(this.schedulingVariables);
        this.schedulingVariables.adjustableOtcProducts && this.schedulingVariables.adjustableOtcProducts.forEach(otc => {
            if(otc && otc.otcDetails && otc.otcDetails.discountedOtc){
                this.schedulingVariables.eligibleCharges += +otc.otcDetails.discountedOtc;
            }
        });     
    }

    public ngAfterViewInit() {
        this.schedulingVariables.orderDisclosures = this.orderDisclosures;        
        if (this.previousUrl === '/account' || this.previousUrl === '/customize-services') {
            if (this.finalDueDate) {
                let dateInString = this.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
            }
        }        
        if (this.retainReservedAppointment) {
            this.schedulingVariables.reservedAppointment = this.retainReservedAppointment;
        }
        // Fix: ExpressionChangedAfterItHasBeenCheckedError
        this.changeDetector.detectChanges();
    }

    public shippingMethod(object: ShippingAddres, shippingInfo) {
        this.schedulingVariables.shippingAddressObject = object;
        this.schedulingVariables.shippingAddress = this.schedulingVariables.shippingAddressObject;
        this.getStates(this.schedulingVariables.shippingAddressObject.stateOrProvince);
        this.schedulingVariables.myForm = this.fb.group({
            name: [this.schedulingVariables.shippingName ? this.schedulingVariables.shippingName : '', [Validators.required, <any>Validations.nameValidator]],
            addressLine: this.schedulingVariables.shippingAddressObject.streetAddress ? [this.schedulingVariables.shippingAddressObject.streetAddress, Validators.required] : ['', Validators.required],
            unitNumber: [''],
            info: [shippingInfo.shippingAddlInfo ? shippingInfo.shippingAddlInfo : ''],
            state: [this.schedulingVariables.shippingAddressObject.stateOrProvince, Validators.required],
            city: [this.schedulingVariables.shippingAddressObject.city ? this.schedulingVariables.shippingAddressObject.city : '', [Validators.required, <any>Validations.nameValidator]],
            zipCode: [this.schedulingVariables.shippingAddressObject.postCode ? this.schedulingVariables.shippingAddressObject.postCode : '', Validations.zipCodeValidator]
        });
    }

    public ngOnInit() {
        this.logger.metrics('SchedulingShippingAppointmentPage');
        this.cartObservable = <Observable<any>>this.store.select('cart');
        this.cart1Subscription = this.cartObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((cartdata) => {
            if (cartdata && cartdata.payload && cartdata.payload.customerAddonOfferItems && (cartdata.payload.customerAddonOfferItems.length > 0) &&
                cartdata.payload.customerAddonOfferItems[0] &&
                cartdata.payload.customerAddonOfferItems[0].offerName === 'Technician Charges') {
                this.apptDropdown = true;
            }
            if(cartdata && cartdata.waivedOtcInfo && cartdata.waivedOtcInfo){
                this.schedulingVariables.waivedOtcInfo = cartdata.waivedOtcInfo;
                if(this.schedulingVariables.waivedOtcInfo) {
                    this.schedulingHelperService.retainWaivedOtc(this.schedulingVariables);
                }
            } 
        });
        window.scroll(0, 0);
        let existingProd = <Observable<any>>this.store.select('existingProducts');
        this.existingProdSubscription = existingProd
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            this.existingData = data;
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                    this.contactNumberExists = true;
                }
            }
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber && data.existingProductsAndServices[0].accountInfo.contact.contactNumber !== '') {
                    this.contactNumber2 = data.existingProductsAndServices[0].accountInfo.contact.contactNumber;
                }
            }
        })
        this.schedulingVariables.cbrForm && this.schedulingVariables.cbrForm.controls.contactNumber.valueChanges.subscribe(value => {
            if (!this.schedulingVariables.isReEntrant) {
                this.isadditionalNumberChecked = false;
                this.schedulingVariables.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                this.schedulingVariables.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                if (this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber) {
                    if (this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                        this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                    }
                }
            } else {
                if (this.reentrantnumber === value.toString().replace(/[^A-Z0-9]/ig, "")) {
                    this.isChecked = this.isReentrantAdditionalnumberChecked;
                    if (this.isReentrantAdditionalnumberChecked) {
                        this.schedulingVariables.formattedNumber = '';
                    }
                    this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(this.isadditionalNumberChecked);
                } else {
                    this.isadditionalNumberChecked = false;
                    this.isChecked = true;
                    this.schedulingVariables.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                    this.schedulingVariables.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                    if (this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber) {
                        if (this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                            this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                        }
                    }
                }
            }
        });
        let customize = <Observable<any>>this.store.select('customize');
        this.customizedSubscription = customize
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            if (data && data.payload && data.payload !== undefined && data.payload.reservedTN !== undefined && data.payload.reservedTN.length !== 0) {
                this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
            }
        });
    }

    public additionalAttrData(event) {
        this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes = event;
    }
       
    private getStates(stateValue) {
        this.states = this.countryStateService.getStates();
        this.states.splice(0, 0, { stateName: 'Select State', stateCode: '' });
        let stateObj = this.states.find((obj) => obj.stateCode === stateValue);
        stateObj ? this.selectedState = stateObj : this.selectedState = { stateName: 'Select State', stateCode: '' };
    }        
   
    public revertShippingAddress() {
        this.schedulingVariables.showShippingAddress = !this.schedulingVariables.showShippingAddress;
        this.schedulingVariables.shippingValidateAddress = false;
        this.schedulingVariables.validatedAddress = false;
        this.schedulingVariables.yellowAddresses = [];
        this.schedulingVariables.selectedAddress = this.schedulingVariables.shippingAddress;
    }

    public selectedYellow() {
        this.schedulingVariables.yellowNewAddresses = false;
        this.yellowMatch = true;
    }

    public changeShippingAddr() {
        this.schedulingVariables.showShippingAddress = !this.schedulingVariables.showShippingAddress;
        this.schedulingVariables.shippingValidateAddress = true;
        this.schedulingVariables.validatedAddress = false;
        this.schedulingVariables.postalAddressValidated = false;
        this.schedulingVariables.yellowNewAddresses = false;
        this.yellowMatch = false;
        this.schedulingVariables.myForm.get('addressLine').setValue(this.schedulingVariables.shippingAddress.streetAddress);
        if (this.schedulingVariables.shippingAddress.locality) {
            this.schedulingVariables.myForm.get('city').setValue(this.schedulingVariables.shippingAddress.locality);
        } else {
            this.schedulingVariables.myForm.get('city').setValue(this.schedulingVariables.inputAddress.city);
        }
        this.schedulingVariables.myForm.get('state').setValue(this.schedulingVariables.shippingAddress.stateOrProvince);
        this.schedulingVariables.myForm.get('zipCode').setValue(this.schedulingVariables.shippingAddress.postCode);
        if (this.schedulingVariables.shippingAddress.subAddress) {
            this.schedulingVariables.myForm.get('unitNumber').setValue(this.schedulingVariables.shippingAddress.subAddress.combinedDesignator);
        }
    }
    
    public ApptChanged(e) {
        this.isApptUpdated = e;
    } 

    public handleCancelClick(event) {
        this.router.navigate(['/existing-products']);
    }

    public cancelClick() {
        this.router.navigate(['/home']);
    }

    public referralResp(event) {
        this.schedulingVariables.errorMsg = '';
        this.schedulingVariables.referralRequest = event;
    } 

    private fetchListingCatalog(addonOffers, product) {
        addonOffers.catalogs[0].catalogItems.map(item => {
            if (item && item.productOffer && item.productOffer.productComponents && item.productOffer.offerName === "Transfer of Responsibility") {
                item.productOffer.productComponents.map(prodComp => {
                    let qtty = prodComp.product.quantity && prodComp.product.quantity.defaultQuantity ? prodComp.product.quantity.defaultQuantity :
                        prodComp.product.quantity && prodComp.product.quantity.minQuantity && prodComp.product.quantity.minQuantity;
                    prodComp.product.quantity = qtty;
                    prodComp.product.action = 'ADD';
                    prodComp.product.componentType = 'COMPONENT';
                    delete prodComp.product.productDisplayName;
                    delete prodComp.product.isRegulated;
                    delete prodComp.product.productCategoryDisplayName;
                    this.schedulingVariables.mandatorySubOffers.push({
                        "catalogId": addonOffers.catalogs[0].catalogId,
                        "contractTerm": item.productOffer.contract.contractTerm,
                        "productOfferingId": item.productOfferingId,
                        "offerType": item.productOffer.offerType,
                        "offerSubType": item.productOffer.offerSubType,
                        "offerCategory": item.productOffer.offerCategory,
                        "quantity": qtty,
                        "rc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.rc : 0,
                        "otc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.otc : 0,
                        "discountedRc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedRc : 0,
                        "discountedOtc": item.defaultOfferPrice !== null ? item.defaultOfferPrice.discountedOtc : 0,
                        "customerOrderSubItems": [prodComp.product],
                        action: 'ADD',
                        offerName: item.productOffer.offerName
                    })
                })
            }
        })
    }

    public existingProductMRCtoCart(cart) {
        let lcart = cloneDeep(cart);
        lcart.customerOrderItems.map(items => {
            if (items.offerType !== "SUBOFFER") {
                items.offerDisplayName = this.offerDisplayName;
                this.existingMRCtoCart.push(items);
            }
        });
        if (this.schedulingVariables.mandatorySubOffers && this.schedulingVariables.mandatorySubOffers.length > 0) {
            this.existingMRCtoCart.push(this.schedulingVariables.mandatorySubOffers[0]);
        }
        let CORcartRequest: any = {
            orderRefNumber: this.schedulingVariables.appointmentResponse.orderRefNumber,
            processInstanceId: this.schedulingVariables.appointmentResponse.processInstanceId,
            taskId: this.schedulingVariables.appointmentResponse.taskId,
            taskName: this.schedulingVariables.appointmentResponse.taskName,
            payload: {
                cart: {
                    customerOrderItems: this.existingMRCtoCart
                }
            }
        };
        this.store.dispatch({ type: 'CREATE_CART', payload: CORcartRequest });
    }
    
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.customizedSubscription !== undefined) {
            this.customizedSubscription.unsubscribe();
        }
        this.ngOnDestroy$.next();
    }

}