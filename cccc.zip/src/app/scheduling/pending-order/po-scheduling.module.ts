import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { PoScheduleAppointmentComponent } from './po-schedule-appointment.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: PoScheduleAppointmentComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        TextMaskModule
    ],
    declarations: [
        PoScheduleAppointmentComponent
    ],
    exports: [
        PoScheduleAppointmentComponent,
    ],
    providers: [       
        SchedulingHelperService              
    ],
})

/**
 * Shared Module - Used to import reusable component's for different modules
 * eg. BreadcrumbComponent and ControlMessagesComponent
 * import shared module in corresponding module and use the component
 */
export class POSchedulingModule { }
