import { Component, OnInit, OnDestroy } from '@angular/core';
import {} from 'jasmine';
import { Router } from '@angular/router';
import { SchedulingService } from '../../common/service/scheduling.service';
import { BlueMarbleService } from '../../common/service/bm.service';
import { AuthService } from '../../common/service/auth.service';
import {
  Appointment, AppointmentPayload,
  AppointmentNotes, AvailableAppointment
} from '../../common/models/appointment.model';
import { userReducer } from '../../common/reducers/user.reducer';
import { User } from '../../common/models/user.model';
import { Observable } from 'rxjs/Observable';
import { Store, StoreModule } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { DatePipe, Location } from '@angular/common';
import { AppStateService } from '../../common/service/app-state.service';
import { ScheduleShippingConfirmation } from '../../common/models/schedule.shipping.model';
import { Logger } from '../../common/logging/default-log.service';
import { ContactInfo, EnterpriseAddress } from '../../common/models/cart.model';
import {
  GenericValues, serverErrorMessages, APIErrorLists, ErrorResponse
} from '../../common/models/common.model';
import { AppointmentShipping, ShippingAddres } from '../../common/models/schedule-shipping.model';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { TextMaskService } from '../../common/service/text-mask.service';
import { Validations } from '../../common/validations/validations';
import { SystemErrorService } from '../../common/service/system-error.service';
import { AddressService } from '../../common/service/address.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { State } from '../../common/models/state.model';
import { MockServer } from '../../MockServer.test';
import { Http, BaseRequestOptions, ConnectionBackend, RequestOptions } from '@angular/http';
import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { Response, ResponseOptions, RequestMethod } from '@angular/http';
import { AppConfig } from '../../common/service/app-config.service';
import { PoScheduleAppointmentComponent } from './po-schedule-appointment.component';
import 'intl';
import 'intl/locale-data/jsonp/en';
import 'rxjs/add/operator/retry';
import { CTLHelperService } from '../../common/service/ctlHelperService';
import { SchedulingHelperService } from '../../scheduling/service/scheduleHelper.service';
import { HttpClient } from '@angular/common/http';
import { DisconnectService } from '../../common/service/disconnect.service';
import { DisclosuresService } from '../../common/service/disclosures.service';
xdescribe('Pending Scheduling Shipping Appointment Component', () => {
  let mockRouter: any = {
    navigate: jasmine.createSpy('navigate')
  };

  const mockRedux: any = { // explicitly saying any here is important
    dispatch(action) { },
    configureStore() { },
    select(reducer) {
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  }
  class mockAuthService {
    public getJWTToken() {
    }
    public setRequestOptions() {
    }
  }
  let defaultOptions, authService, component, service, mockServer,addressService, ctlHelperService;
  beforeEach(() => {
    let location: Location;
    ctlHelperService = new CTLHelperService();
    mockServer = new MockServer();
    defaultOptions = new BaseRequestOptions();
    let backend = new MockBackend();
    let httpHandler;
    let http = new HttpClient(httpHandler);
    authService = new mockAuthService();
    let appConfig = new AppConfig(http);
    let props: any;
    let bm = new BlueMarbleService(http, authService, props);
    let fb = new FormBuilder();
    service = new SchedulingService(bm, mockRedux);
    let appstr = new AppStateService(mockRedux, mockRouter);
    let logger = new Logger();
    
    let textMask= new TextMaskService();
    let countryStateService = new CountryStateService();
    addressService  = new AddressService(bm, countryStateService,mockRedux);
    let systemErrorService = new SystemErrorService(logger, mockRedux, this.router, ctlHelperService);
    let disclosuresService = new DisclosuresService(bm);
    let disconnectService = new DisconnectService(mockRedux, bm);
    let scheduleHelperService = new SchedulingHelperService(logger, mockRedux, this.router, ctlHelperService,
      systemErrorService, service, fb, disclosuresService,
       addressService, disconnectService, appstr, null, null);
 
    component = new PoScheduleAppointmentComponent(logger,
      mockRouter, scheduleHelperService,
      mockRedux, service,appstr,systemErrorService, ctlHelperService,fb,textMask);


    TestBed.configureTestingModule({

      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { AuthService }
        },
        {
          provide: HttpClient,
          useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
            return new HttpClient(httpHandler);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          useValue: mockRouter
        },

        AuthService, SchedulingService, BlueMarbleService, AppStateService, Logger, PoScheduleAppointmentComponent, StoreModule.forRoot({ user: userReducer })
      ]
    })
  });

  xit('cancelClick should have been called...', () => {
    component.cancelClick();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/home']);
  });

  xit('ngOninit() should have been called...', () => {
    expect(component.ngOnInit()).toHaveBeenCalled;
  });

  xit('ngOnDestroy() should have been called...', () => {
    expect(component.ngOnDestroy()).toHaveBeenCalled;
  });

  xit('reserveAppointment() should have been called...', () => {
    component.reservedAppointment =  {
      appointmentId: "ZKLV0GFQ",
      timeSlot: {
        startDateTime: "2018-03-05T08:00:00.000Z",
        endDateTime: "2018-03-05T17:00:00.000Z"
      }
    };
    component.reserveAppointment();
    expect(component.showReserveItButton).toBe(false);
  });

  xit('handleAppointmentUpdated() should have been called...', () => {
    let event = {
      appointmentId: "ZKLV0GFQ",
      timeSlot: {
        startDateTime: "2018-03-05T08:00:00.000Z",
        endDateTime: "2018-03-05T17:00:00.000Z"
      }
    };
    component.handleAppointmentUpdated(event);
    expect(component.reservedAppointment).toBe(event);
  });

  xit('checking Schedule Appointment Service Call...', () => {
    let req = {
      taskName : 'Appointment Scheduling'
    };
    let data = mockServer.getResponseForRequest('submitTask',req);
    let spy = spyOn(service, 'pendingConfirmReschedule').and.callFake(() => {
      return Observable.of(data);
    })
    component.continueClick();
    expect(spy).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/po-review-order']);
  });

});
