import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SchedulingService } from '../../common/service/scheduling.service';
import { AppointmentPayload, AppointmentNotes, AvailableAppointment, Reason } from '../../common/models/appointment.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { DatePipe } from '@angular/common';
import { AppStateService } from '../../common/service/app-state.service';
import { ScheduleShippingConfirmation, SchedulingVariables } from '../../common/models/schedule.shipping.model';
import { Logger } from '../../common/logging/default-log.service';
import { APIErrorLists } from '../../common/models/common.model';
import { PendingOrderScheduling } from '../../common/models/pending-order-scheduling';
import { SystemErrorService } from "app/common/service/system-error.service";
import { User } from '../../common/models/user.model';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { TextMaskService } from '../../common/service/text-mask.service';
import { Validations } from '../../common/validations/validations';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import "rxjs/add/operator/catch";

@Component({
    selector: 'pending-schedule-appt',
    styleUrls: ['../schedule-component/schedule.component.scss'],
    templateUrl: './po-schedule-appointment.component.html'
})

export class PoScheduleAppointmentComponent implements OnInit, OnDestroy {
    public errorMsg: string;
    public test: string;        
    public loading: boolean = false;
    public changeEffectiveBillAddress: boolean = false;    
    public apiResponseError: APIErrorLists;    
    public customerOrderNum: any;
    public effectiveBillDate: string;
    public drivingDirections: string;
    public additionalComments: string;
    private requestReason: any;    
    public cbrForm: FormGroup;
    public phoneMask: any;
    private contactNumber = '';
    private isCbr: boolean = false;
    public firstPendingFlag: boolean = false;
    public multiplePendingflag: boolean = false;
    public FirstPendingDuedate: string = '';
    public secondPendingDuedate: string = '';
    public secondPendingEnddate: string = '';
    private availableAppointment: AvailableAppointment[];
    public availableAppointments: AvailableAppointment[];
    private appointmentConfirmation: ScheduleShippingConfirmation;
    private appointment: Observable<PendingOrderScheduling>;
    private appointmentSubscription: Subscription;
    public appointmentPayload: AppointmentPayload;
    public reasonReschedule: Reason[];
    public appointmentNotes: AppointmentNotes;            
    public showShippingAddress: boolean = false;    
    public shippingAddress: string;    
    public isReEntrant: boolean = false;
    private taskId: string = '';
    @ViewChild('ponrTrueScheduling', { static: false, }) public schedulingPONRDialog: DialogComponent;
    public shippingInfo;
    public isFinalDueDateisZero: boolean = false;
    public reasonRequest;
    private orderRefNumber: string;          
    public finalDateInfo: any;
    public isPendingMoveFlow: boolean = false;
    public reservationId: string = null;    
    public existingPendingOrderData: any;
    public schedulingVariables: SchedulingVariables;
    constructor(private logger: Logger, private router: Router,private schedulingHelperService: SchedulingHelperService, private store: Store<AppStore>,
        private schedulingService: SchedulingService,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private fb: FormBuilder,
        private textMask: TextMaskService,
    ) {
        this.appStateService.setLocationURLs();
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);
        this.schedulingVariables.isPendingFlow = true;
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.appointment = store.select('pending');
        let shippingObject: any;
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointmentSubscription = this.appointment.subscribe((data: any) => {
                if (data && data.orderDocument && data.orderDocument.schedule) {
                    if (data.orderDocument.schedule.shippingInfo) {
                        this.shippingInfo = data.orderDocument.schedule.shippingInfo;
                    }
                    if (data.orderDocument.schedule.dates && data.orderDocument.schedule.dates.finalDueDate && data.orderDocument.schedule.dates.finalDueDate === '0000-00-00') {
                        this.isFinalDueDateisZero = true;
                    }
                    if (data && data.reasonRequest) {
                        this.reasonRequest = data.reasonRequest;
                        this.isFinalDueDateisZero = false;
                    }
                    if (data.orderReference && data.orderReference.customerOrderStatus === "PENDING" && data.orderReference.customerOrderType === "MOVE") {
                        this.isPendingMoveFlow = true;
                        this.changeEffectiveBillAddress = true;
                    }
                };
                let user = <Observable<User>>store.select('user');
                let userSubscription = user.subscribe(
                    (usr) => {
                        if (usr.previousUrl !== '/pending-order') {
                            this.isReEntrant = true;
                            this.schedulingVariables.showReserveItButton = false;
                            let retainVal = <Observable<any>>store.select('retain');
                            let retSubscribe = retainVal.subscribe(
                                (retVal => {
                                    shippingObject = retVal.account;
                                    if (retVal && retVal.account && retVal.account.payload && retVal.account.payload.addlOrderAttributes) {
                                        this.schedulingHelperService.splitDueDateEligibleCheck(retVal.account.payload.addlOrderAttributes, this.schedulingVariables);
                                    }
                                })
                            )
                            retSubscribe.unsubscribe();
                        }
                        if (usr.phoneNumber !== undefined && usr.phoneNumber !== '') {
                            this.contactNumber = usr.phoneNumber;
                        }
                        if (usr && usr.orderRefNumber) {
                            this.orderRefNumber = usr.orderRefNumber;
                        }
                        if(usr.autoLogin && usr.autoLogin.oamData && usr.autoLogin.oamData.agentFirstName && usr.autoLogin.oamData.agentLastName)
                        {
                            this.schedulingVariables.agentFirstName =usr.autoLogin.oamData.agentFirstName;
                            this.schedulingVariables.agentLastName = usr.autoLogin.oamData.agentLastName;
                        }
                        this.taskId = usr && usr.taskId;
                    });
                userSubscription.unsubscribe();
                if (data && data !== null && data !== undefined && data.schedule &&
                    data.schedule.payload && data.schedule.payload !== null && data.schedule.payload !== undefined) {
                    this.schedulingVariables.appointmentResponse = data.schedule;
                    this.appointmentPayload = this.schedulingVariables.appointmentResponse.payload;
                    if (data.reservedCbr !== undefined && data.reservedCbr !== null) {
                        this.contactNumber = data.reservedCbr;
                    } else if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes
                        && Array.isArray(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
                        this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                            if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                                item.orderAttributeGroup.forEach((item: any) => {
                                    if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                        item.orderAttributeGroupInfo.forEach((item: any) => {
                                            if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                item.orderAttributes.forEach((item: any) => {
                                                    if (item.orderAttributeName === "orderLevelCBRNumber") {
                                                        this.contactNumber = item.orderAttributeValue;
                                                        this.isCbr = true;
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                    this.cbrMethod(this.contactNumber.trim());
                    this.finalDateInfo = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
                    this.schedulingVariables.calculatedDueDate = this.schedulingVariables.appointmentResponse.payload.dueDate.calculatedDueDate;
                    this.taskId = this.taskId === undefined || this.taskId === '' ? this.schedulingVariables.appointmentResponse.taskId : this.taskId;
                    if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo) {
                        this.appointmentNotes = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.apptNotes;
                        if (this.appointmentPayload && this.appointmentPayload !== undefined && this.appointmentPayload.appointmentInfo
                            && this.appointmentPayload.appointmentInfo !== undefined && this.appointmentPayload.appointmentInfo.availableAppointment && this.appointmentPayload.appointmentInfo.availableAppointment !== undefined) {
                            this.availableAppointment = this.appointmentPayload.appointmentInfo.availableAppointment;
                        }
                        if (this.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.availableAppointment) {
                            let reservedDate = shippingObject.payload.availableAppointment;
                            const index = this.availableAppointment.indexOf(reservedDate);
                            this.availableAppointment.splice(index, 1);
                            this.availableAppointment.unshift(reservedDate);
                            this.schedulingVariables.remarkObj = shippingObject.payload.apptNotes.notes;
                            if (shippingObject.payload.reason && shippingObject.payload.reason.length > 0) {
                                this.requestReason = shippingObject.payload.reason[0];
                                this.schedulingVariables.selectedResonSchedule = this.requestReason.reasonText;
                                this.schedulingVariables.showChangeApptReasons = true;
                            }
                            this.appointmentPayload.dueDate.finalDueDate = shippingObject.payload.dueDate.finalDueDate;
                        } else {
                            if (this.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.dueDate.finalDueDate) {
                                this.changeDueDate(shippingObject.payload.dueDate.finalDueDate);
                                if (shippingObject.payload.reason && shippingObject.payload.reason.length > 0) {
                                    this.requestReason = shippingObject.payload.reason[0];
                                    this.schedulingVariables.selectedResonSchedule = this.requestReason && this.requestReason.reasonText;
                                    this.schedulingVariables.showChangeApptReasons = true;
                                }
                            }
                        }
                        this.availableAppointments = this.availableAppointment;
                    }
                    if (this.appointmentPayload! && this.appointmentPayload!.dueDate && this.appointmentPayload!.dueDate.finalDueDate) {
                        let dateInString = this.appointmentPayload!.dueDate.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                        this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                    }
                    if (this.isPendingMoveFlow && !this.isReEntrant) {
                        let existingProductsServices = <Observable<any>>store.select('existingProducts');
                        existingProductsServices.subscribe(
                            (existsPrdData: any) => {
                                if (existsPrdData && existsPrdData.existingProductsAndServices[0] && existsPrdData.existingProductsAndServices[0].pendingOrders && existsPrdData.existingProductsAndServices[0].pendingOrders.length > 0) {
                                    this.schedulingVariables.showSplitDueDateLink = true;
                                    if (!this.schedulingVariables.isDueDateUpdated) {
                                        this.appointmentPayload.dueDate.finalDueDate = existsPrdData.existingProductsAndServices[0].pendingOrders[0].orderDocument.schedule.dates.finalDueDate;
                                    }
                                    this.schedulingHelperService.splitDueDateEligibleCheck(existsPrdData.existingProductsAndServices[0].pendingOrders[0].orderDocument.addlOrderAttributes, this.schedulingVariables, 'noDate');
                                    this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = this.ctlHelperService.convertDateFormat(this.schedulingVariables.calculatedDueDate);
                                    this.schedulingHelperService.splitDueDateEligibleCheck(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes, this.schedulingVariables, this.schedulingVariables.calculatedDueDate);
                                }
                            }
                        );
                    }
                    this.drivingDirections = '';
                    this.additionalComments = '';
                    this.reasonReschedule = this.schedulingVariables.appointmentResponse.payload.reason;
                    if (!this.isReEntrant && this.appointmentPayload.shippingInfo && this.appointmentPayload.shippingInfo.shippingAddress) {
                        this.shippingAddress = this.appointmentPayload.shippingInfo.shippingAddress.streetAddress + ',' +
                            this.appointmentPayload.shippingInfo.shippingAddress.city + ',' +
                            this.appointmentPayload.shippingInfo.shippingAddress.stateOrProvince + ',' +
                            this.appointmentPayload.shippingInfo.shippingAddress.postCode;
                        this.showShippingAddress = true;
                    } else {
                        if (this.isReEntrant && shippingObject && shippingObject.payload && shippingObject.payload.shippingInfo && shippingObject.payload.shippingInfo.shippingAddress) {
                            this.shippingAddress = shippingObject.payload.shippingInfo.shippingAddress.streetAddress + ',' +
                                shippingObject.payload.shippingInfo.shippingAddress.city + ',' +
                                shippingObject.payload.shippingInfo.shippingAddress.stateOrProvince + ',' +
                                shippingObject.payload.shippingInfo.shippingAddress.postCode;
                            this.showShippingAddress = true;
                        }
                    }
                }
            });
        }
        let existingObservable = <Observable<any>>store.select('existingProducts');
        let existingSubscription = existingObservable.subscribe(
            (ext) => {
                this.firstPendingFlag = false;
                let pendingObservable = <Observable<any>>store.select('pending');
                let pendingSubscription = pendingObservable.subscribe(
                    (pending) => {
                        if (pending.orderReference) {
                            this.orderRefNumber = pending.orderReference.orderReferenceNumber;
                        }
                        if (ext.pendingOrders.length > 1) {
                            this.multiplePendingflag = true;
                            if (ext.pendingOrders && ext.pendingOrders[0] && ext.pendingOrders[0].orderReference
                                && ext.pendingOrders[0].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber
                                && ext.pendingOrders[0].orderReference.customerOrderNumber < ext.pendingOrders[1].orderReference.customerOrderNumber) {
                                this.firstPendingFlag = true;
                            } else if (ext.pendingOrders && ext.pendingOrders[1] && ext.pendingOrders[1].orderReference
                                && ext.pendingOrders[1].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber
                                && ext.pendingOrders[1].orderReference.customerOrderNumber < ext.pendingOrders[0].orderReference.customerOrderNumber) {
                                this.firstPendingFlag = true;
                            }
                            if (ext.pendingOrders && ext.pendingOrders[0] && ext.pendingOrders[0].orderReference
                                && ext.pendingOrders[0].orderReference.customerOrderNumber === pending.orderReference.customerOrderNumber)
                                this.customerOrderNum = ext.pendingOrders[1].orderReference.customerOrderNumber
                            else
                                this.customerOrderNum = ext.pendingOrders[0].orderReference.customerOrderNumber

                            if (ext.pendingOrders[0] && ext.pendingOrders[0].orderDocument && ext.pendingOrders[0].orderDocument.schedule &&
                                ext.pendingOrders[0].orderDocument.schedule.dates && ext.pendingOrders[0].orderDocument.schedule.dates.finalDueDate
                                && ext.pendingOrders[0].orderReference.customerOrderNumber < ext.pendingOrders[1].orderReference.customerOrderNumber) {
                                this.FirstPendingDuedate = ext.pendingOrders[0].orderDocument.schedule.dates.finalDueDate;
                                this.secondPendingDuedate = ext.pendingOrders[1].orderDocument.schedule.dates.finalDueDate;
                            }
                            if (ext.pendingOrders && ext.pendingOrders[1] && ext.pendingOrders[1].orderDocument && ext.pendingOrders[1].orderDocument.schedule && ext.pendingOrders[1].orderDocument.schedule.dates && ext.pendingOrders[1].orderDocument.schedule.dates.finalDueDate
                                && ext.pendingOrders[0].orderReference.customerOrderNumber > ext.pendingOrders[1].orderReference.customerOrderNumber) {
                                this.FirstPendingDuedate = ext.pendingOrders[1].orderDocument.schedule.dates.finalDueDate;
                                this.secondPendingDuedate = ext.pendingOrders[0].orderDocument.schedule.dates.finalDueDate;
                                this.secondPendingEnddate = this.secondPendingDuedate;
                            }
                        }
                    });
                pendingSubscription.unsubscribe();
            });
        existingSubscription.unsubscribe();
    }
    public cbrMethod(contactNum) {
        this.cbrForm = this.fb.group({
            contactNumber: [contactNum ? contactNum : '', [Validators.required, Validations.cbrphoneValidator]],
        });
    }
    public ngOnInit() {
        this.logger.metrics('SchedulingPendingScheduleShippingAppointmentPage');
        window.scroll(0, 0);
    }
    public ngOnDestroy() {
        if (this.appointmentSubscription) this.appointmentSubscription.unsubscribe();
    }
    public changeEffectiveBillDate(event) {
        this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = this.ctlHelperService.convertDateFormat(event);
        this.schedulingHelperService.splitDueDateEligibleCheck(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes, this.schedulingVariables, event);
    }
    public changeDueDate(event) {
        this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = this.ctlHelperService.convertDateFormat(event);
        this.schedulingVariables.isDueDateUpdated = true;
        this.finalDateInfo = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        if (this.finalDateInfo < this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate) {
            this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = this.finalDateInfo;
            this.schedulingHelperService.splitDueDateEligibleCheck(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes, this.schedulingVariables, event);
        }
    }   
  
    public continueClick() {
        this.store.dispatch({ type: 'PENDING_RESERVED_CBR', payload: this.cbrForm.value.contactNumber });
        if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes
            && Array.isArray(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
            this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                    item.orderAttributeGroup.forEach((item: any) => {
                        if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                            item.orderAttributeGroupInfo.forEach((item: any) => {
                                if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                    item.orderAttributes.forEach((item: any) => {
                                        if (item.orderAttributeName === "orderLevelCBRNumber") {
                                            item.orderAttributeValue = this.cbrForm.value.contactNumber;
                                            this.isCbr = true;
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
        if (!this.isCbr) {
            let additionalAttr =
            {
                "orderAttributeGroup": [{
                    "orderAttributeGroupName": "orderLevelCBRInfo",
                    "orderAttributeGroupInfo": [{
                        "orderAttributes": [{
                            "orderAttributeName": "orderLevelCBRNumber",
                            "orderAttributeValue": this.cbrForm.value.contactNumber,
                        }]
                    }]
                }]
            };
            if (this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup) {
                this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup.push(additionalAttr.orderAttributeGroup[0]);
            } else {
                this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes = [];
                this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.push(additionalAttr);
            }
        }
        if (this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate) {
            this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.replace(/\//g, '-');
            if (this.isPendingMoveFlow) {
                this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
            }
        }
        if (this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate && !this.isPendingMoveFlow) {
            this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = this.schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate.replace(/\//g, '-');
        }
        if (this.schedulingVariables.fromFinalDueDate) {
            this.schedulingVariables.fromFinalDueDate = this.schedulingVariables.fromFinalDueDate.replace(/\//g, '-');
        }
        if (this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate < this.schedulingVariables.fromFinalDueDate && !this.isPendingMoveFlow) {
            this.errorMsg = 'Service Start date should be greater than End date.';
            return
        }
        for (let i in this.reasonReschedule) {
            if (this.reasonReschedule[i].reasonText === this.schedulingVariables.selectedResonSchedule) {
                this.requestReason = this.reasonReschedule[i];
                break;
            }
        }
        if (!this.requestReason && this.schedulingVariables.isDueDateUpdated) {
            return this.schedulingVariables.showErrorReason = true;
        }
        this.loading = true;
        if (this.reasonRequest) {
            this.requestReason.code = this.reasonRequest.code;
            this.requestReason.description = this.reasonRequest.description;
            this.requestReason.waiverFlag = this.reasonRequest.waiverFlag;
            this.requestReason.reasonText = this.reasonRequest.reasonText;
        }
        let requestPayload: any = {}
        if (this.isPendingMoveFlow) {
            requestPayload = {
                dueDate: this.schedulingVariables.appointmentResponse.payload.dueDate,
                availableAppointment: this.schedulingVariables.reservedAppointment,
                apptNotes: {
                    notes: this.schedulingVariables.remarkObj
                },
                shippingInfo: this.schedulingVariables.appointmentResponse.payload.shippingInfo,
                cart: this.schedulingVariables.appointmentResponse.payload.cart,
                reason: [
                    this.requestReason
                ],
                addlOrderAttributes: this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes,
                reservationId: this.reservationId
            }
        } else {
            requestPayload = {
                dueDate: this.schedulingVariables.appointmentResponse.payload.dueDate,
                availableAppointment: this.schedulingVariables.reservedAppointment,
                apptNotes: {
                    notes: this.schedulingVariables.remarkObj
                },
                shippingInfo: this.schedulingVariables.appointmentResponse.payload.shippingInfo,
                cart: this.schedulingVariables.appointmentResponse.payload.cart,
                reason: [
                    this.requestReason
                ],
                addlOrderAttributes: this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes
            }
        }
        if(requestPayload && requestPayload.availableAppointment && (requestPayload.availableAppointment.commitmentDateTime === null || requestPayload.availableAppointment.commitmentDateTime === undefined)){
            delete requestPayload.availableAppointment;
        }
        this.taskId = this.taskId === undefined || this.taskId === '' ? this.schedulingVariables.appointmentResponse.taskId : this.taskId;
        let apiRequest = {
            orderRefNumber: this.schedulingVariables.appointmentResponse.orderRefNumber,
            processInstanceId: this.schedulingVariables.appointmentResponse.processInstanceId,
            taskId: this.taskId,
            taskName: this.schedulingVariables.appointmentResponse.taskName,
            schedulingAction: "SHOWACCOUNTPAGE",
            payload: requestPayload

        };
        this.loading = true;
        this.logger.log("info", "po-schedule-appointment.component.ts", "pendingConfirmRescheduleRequest", JSON.stringify(apiRequest));
        this.logger.startTime();
        let errorResolved = false;
        this.schedulingService.pendingConfirmReschedule(apiRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log('error', 'po-schedule-appointment.component.ts', 'pendingSchduleAppoConfirmResponse', JSON.stringify(error));
                this.logger.log("error", "po-schedule-appointment.component.ts", "pendingConfirmRescheduleSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "submitTaskSup2 - pendingConfirmReschedule", "po-schedule-appointment.component.ts", "PO Schedule Appointment", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "po-schedule-appointment.component.ts", 'pendingConfirmRescheduleResponse', JSON.stringify(data ? data : ''));
                    this.logger.log("info", "po-schedule-appointment.component.ts", "pendingConfirmRescheduleSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let response = data;
                    let PONRResponse = data;
                    if (PONRResponse.errorResponse !== null && PONRResponse.errorResponse !== undefined && PONRResponse.errorResponse) {
                        this.loading = false;
                        if(PONRResponse.errorResponse[0] && PONRResponse.errorResponse[0].reasonCode === 'ARN_NOT_APPROVED') {
                            this.errorMsg = PONRResponse.errorResponse[0].messageDetail;
                        } else {
                            this.schedulingPONRDialog.open();
                        }
                    } else {
                        this.appointmentConfirmation = response;
                        this.store.dispatch({ type: 'REVIEW_ORDER', payload: { schedule: this.schedulingVariables.appointmentResponse, review: this.appointmentConfirmation } });
                        this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                        if (!this.schedulingVariables.showErrorReason && this.schedulingVariables.selectedResonSchedule !== undefined) {
                            this.router.navigate(['/po-review-order']);
                        }
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "po-schedule-appointment.component.ts", "pendingConfirmRescheduleResponse", error);
                        this.logger.log("error", "po-schedule-appointment.component.ts", "pendingConfirmRescheduleSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "pendingSchduleAppoConfirmError", "po-schedule-appointment.component.ts", "PO Schedule Appointment Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "pendingSchduleAppoConfirmError", "po-schedule-appointment.component.ts", "PO Schedule Appointment Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    public cancelClick() {
        this.router.navigate(['/home']);
    }
    public backToSummary() {
        this.router.navigate(['/pending-order']);
    }

    public getReservationId(event) {
        this.reservationId = event;
    }
}
