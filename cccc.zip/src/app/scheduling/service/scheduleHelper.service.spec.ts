import { TestBed, async } from "@angular/core/testing";
import { Observable } from 'rxjs/Rx';
import { Store } from '@ngrx/store';
import { Router } from "@angular/router";
import { FormBuilder } from '@angular/forms';
import { MockServer } from '../../MockServer.test';
import { SchedulingHelperService } from './scheduleHelper.service';
import { Logger } from "../../common/logging/default-log.service";
import { MockLogger,
  MockRouter,
  MockSystemErrorService,
  MockHelperService,
  MockAddressService,
  MockDisconnectService,
  MockAppStateService,
  MockPropertiesHelperService } from "../../common/service/mockServices.test";
import { CTLHelperService } from "../../common/service/ctlHelperService";
import { SystemErrorService } from "../../common/service/system-error.service";
import { SchedulingService } from '../../common/service/scheduling.service';
import { HelperService } from '../../common/service/helper.service';
import { DisconnectService } from '../../common/service/disconnect.service';
import { AddressService } from '../../common/service/address.service';
import { DisclosuresService } from '../../common/service/disclosures.service';
import { AppStateService } from '../../common/service/app-state.service';
import { PropertiesHelperService } from '../../common/service/propertiesHelper.service';
import { SchedulingVariables } from '../../common/models/schedule.shipping.model';
import { AppointmentPayload } from '../../common/models/appointment.model';
import { throwError } from 'rxjs';

describe('ScheduleHelperService', () => {
  let mockServer = new MockServer();
  let scheduleHelperService: SchedulingHelperService;
  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }
  class MockDisclosuresService {
    viewRccsDisclosure() {
      return Observable.of(mockServer.getResponseForRequest('schedulingDisclosure'))
    }
  }
  class MockSchedulingService {
    scheduleAppointment() {
      return Observable.of(mockServer.getResponseForRequest('onContinueFromNiScheduling'))
    }
  }

  const mockStore = { provide: Store, useValue: mockRedux };
  const mockLogger = { provide: Logger, useClass: MockLogger };
  const mockRouter = { provide: Router, useClass: MockRouter };
  const mockSystemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const mockHelperService = { provide: HelperService, useClass: MockHelperService };
  const mockDisclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
  const mockSchedulingService = { provide: SchedulingService, useClass: MockSchedulingService };
  const mockAddressService = { provide: AddressService, useClass: MockAddressService };
  const mockDisconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const mockAppStateService = { provide: AppStateService, useClass: MockAppStateService };
  const mockPropertiesHelperService = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };

  const providers = [
    SchedulingHelperService,
    mockLogger,
    mockStore,
    mockRouter,
    CTLHelperService,
    mockSystemErrorService,
    mockSchedulingService,
    FormBuilder,
    mockDisclosuresService,
    mockAddressService,
    mockDisconnectService,
    mockAppStateService,
    mockHelperService,
    mockPropertiesHelperService
  ]
  let schedulingVariables;
  
  describe('', () => {
    beforeEach(async(() => {
      TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            providers: providers
        });
    }));

    beforeEach(() => {
        scheduleHelperService = TestBed.get(SchedulingHelperService);
        schedulingVariables = mockServer.getVariables("scheduleVariableFor_reserveAppointment")
    });

    it("should create scheduleHelper.service", () => {
        expect(scheduleHelperService).toBeDefined();
    });

    it("should set isWaiveOtcAllowed to true", () => {
        let schedulingVariables = {
            orderFlow: 'NEWINSTALL',
            isWaiveOtcAllowed: false,
            adjustableOtcProducts: [{
                mockdata: 'mockdata'
            }]
        }
        scheduleHelperService.waiveOtcAllowedCheck(schedulingVariables);
        expect(schedulingVariables.isWaiveOtcAllowed).toBeTruthy();
    });

    it("should set isWaiveOtcAllowed to false", () => {
        let schedulingVariables = {
            orderFlow: 'new',
            isWaiveOtcAllowed: false,
            adjustableOtcProducts: [{
                mockdata: 'mockdata'
            }]
        }
        scheduleHelperService.waiveOtcAllowedCheck(schedulingVariables);
        expect(schedulingVariables.isWaiveOtcAllowed).toBeFalsy();
    });

    it("should set isWaiveOtcAllowed to false", () => {
        let schedulingVariables = {
            orderFlow: 'NEWINSTALL',
            isWaiveOtcAllowed: false
        }
        scheduleHelperService.waiveOtcAllowedCheck(schedulingVariables);
        expect(schedulingVariables.isWaiveOtcAllowed).toBeFalsy();
    });

    it("should set adjustableOtcProducts to productOfferDetails from appointment store", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        scheduleHelperService.initializeAdjustableOtcInfo(schedulingVariables);
        expect(schedulingVariables.adjustableOtcProducts).toBeTruthy();
        // expect(schedulingVariables.adjustableOtcProducts.length).toBeGreaterThan(0);
    });

    it("should set waivedReasonList to adjustableOtcInfo.reason from appointment store", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        scheduleHelperService.initializeAdjustableOtcInfo(schedulingVariables);
        expect(schedulingVariables.waivedReasonList).toBeTruthy();
        // expect(schedulingVariables.waivedReasonList.length).toBeGreaterThan(0);
    });

    it("should set waived flag to true in adjustableOtcProducts for the product found in waivedOtcInfo", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.waivedOtcInfo['otcWaiverList'] = {};
        schedulingVariables.waivedOtcInfo.otcWaiverList['waivers'] = [{
            "productName": "MODEM",
            "productType": "INTERNET",
            "productDisplayName": "MODEM",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: true
        }];
        schedulingVariables.adjustableOtcProducts = [{
            "productName": "MODEM",
            "productType": "INTERNET",
            "productDisplayName": "MODEM",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: false
        }];
        scheduleHelperService.retainWaivedOtc(schedulingVariables);
        expect(schedulingVariables.adjustableOtcProducts).toEqual(schedulingVariables.waivedOtcInfo.otcWaiverList.waivers);
    });

    it("should not set waived flag to true in adjustableOtcProducts", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.waivedOtcInfo['otcWaiverList'] = {};
        schedulingVariables.waivedOtcInfo.otcWaiverList['waivers'] = [{
            "productName": "TECH INSTALL",
            "productType": "INTERNET",
            "productDisplayName": "TECH INSTALL",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: true
        }];
        schedulingVariables.adjustableOtcProducts = [{
            "productName": "MODEM",
            "productType": "INTERNET",
            "productDisplayName": "MODEM",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: false
        }];
        let unModifiedAdjustableOtcProducts = [{
            "productName": "MODEM",
            "productType": "INTERNET",
            "productDisplayName": "MODEM",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: false
        }];
        scheduleHelperService.retainWaivedOtc(schedulingVariables);
        expect(schedulingVariables.adjustableOtcProducts).toEqual(unModifiedAdjustableOtcProducts);
    });

    it("should not set waived flag to true in adjustableOtcProducts", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.waivedOtcInfo['otcWaiverList'] = {};
        schedulingVariables.adjustableOtcProducts = [{
            "productName": "MODEM",
            "productType": "INTERNET",
            "productDisplayName": "MODEM",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: false
        }];
        let unModifiedAdjustableOtcProducts = [{
            "productName": "MODEM",
            "productType": "INTERNET",
            "productDisplayName": "MODEM",
            "otcDetails": {
              "otc": 150,
              "discountedOtc": 150,
              "adjustableOTC": "YES"
            },
            waived: false
        }];
        scheduleHelperService.retainWaivedOtc(schedulingVariables);
        expect(schedulingVariables.adjustableOtcProducts).toEqual(unModifiedAdjustableOtcProducts);
    });

    it("should check if adjustableOtcProducts length remains zero", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.adjustableOtcProducts = [];
        scheduleHelperService.retainWaivedOtc(schedulingVariables);
        expect(schedulingVariables.adjustableOtcProducts.length).toEqual(0);
    });

    it("should push OTC addlOrderAttributes to addlOrderAttributes of appointmentResponse", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.appointmentResponse.payload = {} as AppointmentPayload;
        schedulingVariables.appointmentResponse['payload']['addlOrderAttributes'] = [
            {
              "orderAttributeGroup": [
                {
                  "orderAttributeGroupName": "orderLevelCBRInfo",
                  "orderAttributeGroupInfo": [
                    {
                      "orderAttributes": [
                        {
                          "orderAttributeName": "orderLevelCBRNumber",
                          "orderAttributeValue": "3453453453"
                        }
                      ]
                    }
                  ]
                },
                {
                    "orderAttributeGroupName": "otcAdjustmentInfo",
                    "orderAttributeGroupInfo": [
                      {
                        "orderAttributes": [
                          {
                            "orderAttributeName": "productName",
                            "orderAttributeValue": "MODEM"
                          },
                          {
                            "orderAttributeName": "reasonCode",
                            "orderAttributeValue": "AJ0400"
                          },
                          {
                            "orderAttributeName": "reasonDescription",
                            "orderAttributeValue": "Missed Due Date Credit"
                          }
                        ]
                      }
                    ]
                }
              ]
            }
        ]
        let addlAttr = {
              "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "otcAdjustmentInfo",
                    "orderAttributeGroupInfo": [
                      {
                        "orderAttributes": [
                          {
                            "orderAttributeName": "productName",
                            "orderAttributeValue": "MODEM"
                          },
                          {
                            "orderAttributeName": "reasonCode",
                            "orderAttributeValue": "AJ0400"
                          },
                          {
                            "orderAttributeName": "reasonDescription",
                            "orderAttributeValue": "Missed Due Date Credit"
                          }
                        ]
                      }
                    ]
                }
              ]
        };
        scheduleHelperService.addAddlOrderAttribute(addlAttr, schedulingVariables);
        let waivedOtcAddlAttr = schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup.find(group => group.orderAttributeGroupName === "otcAdjustmentInfo");
        expect(waivedOtcAddlAttr).toBeTruthy();
    });

    it("should update OTC addlOrderAttributes in addlOrderAttributes of appointmentResponse", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.appointmentResponse.payload = {} as AppointmentPayload;
        schedulingVariables.appointmentResponse['payload']['addlOrderAttributes'] = [
            {
              "orderAttributeGroup": [
                {
                  "orderAttributeGroupName": "orderLevelCBRInfo",
                  "orderAttributeGroupInfo": [
                    {
                      "orderAttributes": [
                        {
                          "orderAttributeName": "orderLevelCBRNumber",
                          "orderAttributeValue": "3453453453"
                        }
                      ]
                    }
                  ]
                }
              ]
            }
        ]
        let addlAttr = {
              "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "otcAdjustmentInfo",
                    "orderAttributeGroupInfo": [
                      {
                        "orderAttributes": [
                          {
                            "orderAttributeName": "productName",
                            "orderAttributeValue": "TECH INSTALL"
                          },
                          {
                            "orderAttributeName": "reasonCode",
                            "orderAttributeValue": "AJ0400"
                          },
                          {
                            "orderAttributeName": "reasonDescription",
                            "orderAttributeValue": "Missed Due Date Credit"
                          }
                        ]
                      }
                    ]
                }
              ]
        };
        scheduleHelperService.addAddlOrderAttribute(addlAttr, schedulingVariables);
        let waivedOtcAddlAttr = schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup.find(group => group.orderAttributeGroupName === "otcAdjustmentInfo");
        expect(waivedOtcAddlAttr).toEqual(addlAttr.orderAttributeGroup[0]);
    });

    it("should create addlOrderAttributes in appointmentResponse & push OTC addlOrderAttributes", () => {
        let schedulingVariables: SchedulingVariables;
        schedulingVariables = scheduleHelperService.setDefaultsVariables(schedulingVariables);
        schedulingVariables.appointmentResponse.payload = {} as AppointmentPayload;
        let addlAttr = {
              "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "otcAdjustmentInfo",
                    "orderAttributeGroupInfo": [
                      {
                        "orderAttributes": [
                          {
                            "orderAttributeName": "productName",
                            "orderAttributeValue": "MODEM"
                          },
                          {
                            "orderAttributeName": "reasonCode",
                            "orderAttributeValue": "AJ0400"
                          },
                          {
                            "orderAttributeName": "reasonDescription",
                            "orderAttributeValue": "Missed Due Date Credit"
                          }
                        ]
                      }
                    ]
                }
              ]
        };
        scheduleHelperService.addAddlOrderAttribute(addlAttr, schedulingVariables);
        let waivedOtcAddlAttr = schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup.find(group => group.orderAttributeGroupName === "otcAdjustmentInfo");
        expect(waivedOtcAddlAttr).toBeTruthy();
    });

    it("should create additionalAttr with the passed parameters", () => {
        let addlAttr;
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('productName', 'MODEM', 'otcAdjustmentInfo', addlAttr);
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('reasonCode', 'AJ0400', 'otcAdjustmentInfo', addlAttr);
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('reasonDescription', 'Missed Due Date Credit', 'otcAdjustmentInfo', addlAttr);
        let addAttrGroup = { "orderAttributeGroup" : [{
                "orderAttributeGroupName": "otcAdjustmentInfo",
                "orderAttributeGroupInfo": [
                  {
                    "orderAttributes": [
                      {
                        "orderAttributeName": "productName",
                        "orderAttributeValue": "MODEM"
                      },
                      {
                        "orderAttributeName": "reasonCode",
                        "orderAttributeValue": "AJ0400"
                      },
                      {
                        "orderAttributeName": "reasonDescription",
                        "orderAttributeValue": "Missed Due Date Credit"
                      }
                    ]
                  }
                ]
        }]};
        expect(addlAttr).toEqual(addAttrGroup);
    });

    it("should not push new NameAndValue when different group name is passed", () => {
        let addlAttr;
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('productName', 'MODEM', 'otcAdjustmentInfo', addlAttr);
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('reasonCode', 'AJ0400', 'oct1', addlAttr);
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('reasonDescription', 'Missed Due Date Credit', 'otc2', addlAttr);
        let addAttrGroup = { "orderAttributeGroup" : [{
                "orderAttributeGroupName": "otcAdjustmentInfo",
                "orderAttributeGroupInfo": [
                  {
                    "orderAttributes": [
                      {
                        "orderAttributeName": "productName",
                        "orderAttributeValue": "MODEM"
                      },
                      {
                        "orderAttributeName": "reasonCode",
                        "orderAttributeValue": "AJ0400"
                      },
                      {
                        "orderAttributeName": "reasonDescription",
                        "orderAttributeValue": "Missed Due Date Credit"
                      }
                    ]
                  }
                ]
        }]};
        expect(addlAttr).not.toEqual(addAttrGroup);
    });

    it("should not create addlAttr", () => {
        let addlAttr = {};
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('productName', 'MODEM', 'otcAdjustmentInfo', addlAttr);
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('reasonCode', 'AJ0400', 'oct1', addlAttr);
        addlAttr = scheduleHelperService.addOrderAttributeNameAndValue('reasonDescription', 'Missed Due Date Credit', 'otc2', addlAttr);
        expect(addlAttr).toEqual({});
    });

    it("should call reserveAppointment", () => {
      scheduleHelperService.reserveAppointment(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });

    it("should call viewRccsDisclosure", () => {
      scheduleHelperService.viewRccsDisclosure(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });

    it("should call continueClick", () => {
      scheduleHelperService.continueClick(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });
    
    it("should call changeEffectiveBill", () => {
      scheduleHelperService.changeEffectiveBill(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });

    it("should call toContinue", () => {
      scheduleHelperService.toContinue(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });

    it("should call useServiceAddress", () => {
      const returnValue = scheduleHelperService.useServiceAddress(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });

    it("should call referralResp", () => {
      const returnValue = scheduleHelperService.referralResp("", schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });

    it("should call dueDateUpdated", () => {
      const returnValue = scheduleHelperService.dueDateUpdated("", schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    it("should call effectiveBillDateUpdated", () => {
      const returnValue = scheduleHelperService.effectiveBillDateUpdated("", schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    it("should call handleEffectiveBillDateUpdated", () => {
      const returnValue = scheduleHelperService.handleEffectiveBillDateUpdated("", schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
   
    it("should call customerRequestedDueDateUpdated", () => {
      const returnValue = scheduleHelperService.customerRequestedDueDateUpdated("", schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    it('check fetchAddlOrderAttributes method',()=>{
      const returnValue = scheduleHelperService.fetchAddlOrderAttributes(schedulingVariables.appointmentResponse.payload.addlOrderAttributes,'')
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBe('');
    })
    it("should call getTechRemarks", () => {
      let appNotes = {'notes' :[
        {'name':'Driving Directions','value':'no value'},{'name':'Additional Comments','value':'no value'}]}
      const returnValue = scheduleHelperService.getTechRemarks(appNotes, schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    it("should call additionalAttrData", () => {
      const returnValue = scheduleHelperService.additionalAttrData("", schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    it("should call changeShippingAddress", () => {
      schedulingVariables.validatedNewAddress = {
        "name":"Test Data",
        "streetAddress":"",
        "unitNumber":"",
        "stateOrProvince":"",
        "city":"",
        "locality":"",
        "postCode":""
      }
      const returnValue = scheduleHelperService.changeShippingAddress(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    xit("should call changeShippingAddress with selected address", () => {
      schedulingVariables.selectedAddress = {        
        "streetAddress":"Test Data",        
        "stateOrProvince":"",        
        "locality":"",
        "postCode":""
      }
      const returnValue = scheduleHelperService.changeShippingAddress(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
    it("check reason appointment ",()=>{
      schedulingVariables.selectedResonSchedule  ='No reason'
      let reason = schedulingVariables.selectedResonSchedule 
      const returnValue = scheduleHelperService.checkReasonAppt(reason,schedulingVariables);
      expect(returnValue).toBeUndefined();
    })
    it("check CBR method ",()=>{      
      let num = 9876542130
      const returnValue = scheduleHelperService.checkReasonAppt(num,schedulingVariables);
      expect(returnValue).toBeUndefined();
    })
    
    it("should call showRefundTextMessage", () => {
      const returnValue = scheduleHelperService.showRefundTextMessage(new Date(2020, 10, 2),new Date(2020, 12, 2),schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });

    it("should call revertShippingAddress", () => {
      const returnValue = scheduleHelperService.revertShippingAddress(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });

    it("should call validateAddress", () => {
      const returnValue = scheduleHelperService.validateAddress(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });

    it("should call addRemarks", () => {
      const returnValue = scheduleHelperService.addRemarks('Any tech remark details', schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });
  });

  describe('API failed scenario', () => {
    const errorObj = {}
    class MockAddressService {
      getGeoesAddress() {
        return throwError(errorObj)
      }
    }
    class MockDisclosuresService {
      viewRccsDisclosure() {
        return throwError(errorObj)
      }
    }
    class MockSchedulingService {
      scheduleAppointment() {
        return throwError(errorObj)
      }
    }
    const mockDisclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
    const mockAddressService = { provide: AddressService, useClass: MockAddressService };
    const _providers = [...providers, mockAddressService, mockDisclosuresService];
    beforeEach(async(() => {
      TestBed.resetTestingModule();
        TestBed.configureTestingModule({
            providers: _providers
        });
    }));

    beforeEach(() => {
        scheduleHelperService = TestBed.get(SchedulingHelperService);
        schedulingVariables = mockServer.getVariables("scheduleVariableFor_reserveAppointment")
    });

    it("should call validateAddress and execute catch block", () => {
      const returnValue = scheduleHelperService.validateAddress(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
      expect(returnValue).toBeUndefined();
    });

    it("should call viewRccsDisclosure and execute catch block", () => {
      scheduleHelperService.viewRccsDisclosure(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });

    it("should call toContinue and execute catch block", () => {
      scheduleHelperService.toContinue(schedulingVariables);
      expect(schedulingVariables).toBeDefined();
    });
  });

})