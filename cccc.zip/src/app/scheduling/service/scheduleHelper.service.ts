import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Store } from '@ngrx/store';
import { SchedulingVariables } from 'app/common/models/schedule.shipping.model';
import { AddressService } from 'app/common/service/address.service';
import { AppointmentPayload, AvailableAppointment, Reason } from '../../common/models/appointment.model';
import { DatePipe, UpperCasePipe } from '@angular/common';
import { AppointmentShipping, ShippingAddres } from 'app/common/models/schedule-shipping.model';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Router } from '@angular/router';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { User } from 'app/common/models/user.model';
import { APIErrorLists, GenericValues } from 'app/common/models/common.model';
import { SchedulingService } from 'app/common/service/scheduling.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Validations } from 'app/common/validations/validations';
import { Logger } from 'app/common/logging/default-log.service';
import { ShoppingCart, EnterpriseAddress, WaivedOtcInfo } from 'app/common/models/cart.model';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisclosuresRes } from 'app/common/models/disclosures.model';
import * as _ from 'lodash';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';

@Injectable()
export class SchedulingHelperService {
    public user: Observable<any>;
    constructor(
        private logger: Logger,
        public store: Store<any>,
        private router: Router,
        private ctlHelperService: CTLHelperService,
        private systemErrorService: SystemErrorService,
        private schedulingService: SchedulingService,
        private fb: FormBuilder,
        private disclosuresService: DisclosuresService,
        private addressService: AddressService,
        private disconnectService: DisconnectService,
        public appStateService: AppStateService,
        private helperService: HelperService,
        private propertiesHelperService: PropertiesHelperService,
    ) {
    }

    public getTechRemarks(apptNotes, schedulingVariables) {
        schedulingVariables.animalsPresentCheckBox = apptNotes.animalsPresent;
        schedulingVariables.electricFenceCheckBox = apptNotes.electricFence;
        schedulingVariables.lockedGateCheckBox = apptNotes.lockedGate;
        apptNotes && apptNotes.notes && apptNotes.notes.map((x) => {
            if (x.name === 'Driving Directions') {
                schedulingVariables.drivingDirections = x.value;
            } else if (x.name === 'Additional Comments') {
                schedulingVariables.additionalComments = x.value;
            }
        });
    }

    public additionalAttrData(event, schedulingVariables) {
        schedulingVariables.appointmentResponse &&
        schedulingVariables.appointmentResponse.payload &&
        schedulingVariables.appointmentResponse.payload.addlOrderAttributes &&
        schedulingVariables.appointmentResponse.payload.addlOrderAttributes.push(event);
    }
    public reqFormat(schedulingVariables) {
        let notesValues: any;
        let cartValue;
        let productConfValue;
        if ((schedulingVariables.schedulingShippingPage && (schedulingVariables.potsRemoved || schedulingVariables.phonenoChanged === "yes") && schedulingVariables.isChangeFlow) || (schedulingVariables.currentUrl === '/schedule-appt-ship' && schedulingVariables.isAmend)) {
            if (schedulingVariables.drivingDirections !== '' && schedulingVariables.drivingDirections !== undefined
                && schedulingVariables.additionalComments !== '' && schedulingVariables.additionalComments !== undefined) {
                notesValues = [
                    {
                        name: 'Driving Directions',
                        value: schedulingVariables.drivingDirections,
                        author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                    },
                    {
                        name: 'Additional Comments',
                        value: schedulingVariables.additionalComments,
                        author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                    }
                ];
            }
            if (schedulingVariables.drivingDirections !== '' && schedulingVariables.drivingDirections !== undefined
                && schedulingVariables.additionalComments === '') {
                notesValues = [
                    {
                        name: 'Driving Directions',
                        value: schedulingVariables.drivingDirections,
                        author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                    }

                ];
            }
            if (schedulingVariables.drivingDirections === ''
                && schedulingVariables.additionalComments !== '' && schedulingVariables.additionalComments !== undefined) {
                notesValues = [
                    {
                        name: 'Additional Comments',
                        value: schedulingVariables.additionalComments,
                        author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                    }
                ];
            }
            cartValue = (schedulingVariables.potsRemoved || schedulingVariables.phonenoChanged === "yes") && schedulingVariables.isChangeFlow ? schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload && schedulingVariables.referralRequest.payload.cart : schedulingVariables.appointmentResponse.payload.cart;
            productConfValue = (schedulingVariables.potsRemoved || schedulingVariables.phonenoChanged === "yes") && schedulingVariables.isChangeFlow ? schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload && schedulingVariables.referralRequest.payload.productConfiguration : null;
        } else {
            if (!schedulingVariables.isVacationFlow && schedulingVariables.orderFlow !== "Disconnect") {
                if (schedulingVariables.drivingDirections !== '' && schedulingVariables.drivingDirections !== undefined
                    && schedulingVariables.additionalComments !== '' && schedulingVariables.additionalComments !== undefined) {
                    notesValues = [
                        {
                            name: 'Driving Directions',
                            value: schedulingVariables.drivingDirections,
                            date: schedulingVariables.schedulingShippingPage ? undefined : new DatePipe('en-US').transform(new Date(), 'mediumDate'),
                            author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                        },
                        {
                            name: 'Additional Comments',
                            value: schedulingVariables.additionalComments,
                            date: schedulingVariables.schedulingShippingPage ? undefined : new DatePipe('en-US').transform(new Date(), 'mediumDate'),
                            author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                        }
                    ];
                }
                if (schedulingVariables.drivingDirections !== '' && schedulingVariables.drivingDirections !== undefined
                    && schedulingVariables.additionalComments === '') {
                    notesValues = [
                        {
                            name: 'Driving Directions',
                            value: schedulingVariables.drivingDirections,
                            date: schedulingVariables.schedulingShippingPage ? undefined : new DatePipe('en-US').transform(new Date(), 'mediumDate'),
                            author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                        }

                    ];
                }
                if (schedulingVariables.drivingDirections === ''
                    && schedulingVariables.additionalComments !== '' && schedulingVariables.additionalComments !== undefined) {
                    notesValues = [
                        {
                            name: 'Additional Comments',
                            value: schedulingVariables.additionalComments,
                            date: schedulingVariables.schedulingShippingPage ? undefined : new DatePipe('en-US').transform(new Date(), 'mediumDate'),
                            author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName
                        }
                    ];
                }
                cartValue = schedulingVariables.schedulingShippingPage ? null : (schedulingVariables.potsRemoved || schedulingVariables.phonenoChanged === "yes") && schedulingVariables.isChangeFlow ? schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload && schedulingVariables.referralRequest.payload.cart : schedulingVariables.appointmentResponse.payload.cart;
                productConfValue = (schedulingVariables.potsRemoved || schedulingVariables.phonenoChanged === "yes") ? schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload && schedulingVariables.referralRequest.payload.productConfiguration : schedulingVariables.currentUrl === '/move-schedule-appt-ship' ? null : undefined;
            } else if (schedulingVariables.orderFlow === "Disconnect") {
                let schedulerequest = {
                    orderRefNumber: schedulingVariables.appointmentResponse.orderRefNumber,
                    processInstanceId: schedulingVariables.appointmentResponse.processInstanceId,
                    taskId: schedulingVariables.isReEntrant ? schedulingVariables.taskId : schedulingVariables.appointmentResponse.taskId,
                    taskName: schedulingVariables.appointmentResponse.taskName,
                    payload:
                    {
                        dueDate: schedulingVariables.appointmentResponse.payload.dueDate,
                        cart: schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload ? schedulingVariables.referralRequest.payload.cart : schedulingVariables.appointmentResponse.payload.cart,
                        productConfiguration: schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload ? schedulingVariables.referralRequest && schedulingVariables.referralRequest.payload && schedulingVariables.referralRequest.payload.productConfiguration : schedulingVariables.appointmentResponse.payload.productConfiguration,
                        reservedTN: schedulingVariables.appointmentResponse.payload.reservedTN,
                        ban: schedulingVariables.appointmentResponse.payload.ban,
                        referralRequired: schedulingVariables.appointmentResponse.payload.referralRequired,
                        addlOrderAttributes: schedulingVariables.appointmentResponse.payload.addlOrderAttributes,
                        finalPaymentDate: schedulingVariables.nextPaymentDate
                    }
                };
                return schedulerequest;
            } else {
                let schedulerequest = {
                    "orderRefNumber": schedulingVariables.vacScheOrderRefNumber,
                    "processInstanceId": schedulingVariables.vacScheProcessInstanceId,
                    "taskId": schedulingVariables.vacScheTaskId,
                    "taskName": schedulingVariables.vacScheTaskName,
                    "payload": {
                        "dueDate": {
                            "calculatedDueDate": schedulingVariables.appointmentResponse.payload.dueDate.calculatedDueDate,
                            "requestedDueDate": schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate,
                            "finalDueDate": schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate,
                            "overrideFlag": false,
                            "effectiveBillDate": schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate,
                            "isCRDAvailable": true,
                        },
                        "addlOrderAttributes": schedulingVariables.appointmentResponse.payload.addlOrderAttributes
                    }
                }
                return schedulerequest;
            }
        }
        schedulingVariables.apiRequest = {
            orderRefNumber: schedulingVariables.appointmentResponse.orderRefNumber,
            processInstanceId: schedulingVariables.appointmentResponse.processInstanceId,
            taskId: schedulingVariables.appointmentResponse.taskId,
            taskName: schedulingVariables.appointmentResponse.taskName,
            schedulingAction: "SHOWACCOUNTPAGE",
            payload:
            {
                dueDate: schedulingVariables.appointmentResponse.payload.dueDate,
                availableAppointment: schedulingVariables.reservedAppointment,
                apptNotes: {
                    animalsPresent: schedulingVariables.animalsPresentCheckBox,
                    electricFence: schedulingVariables.electricFenceCheckBox,
                    lockedGate: schedulingVariables.lockedGateCheckBox,
                    notes: schedulingVariables.isAmend && schedulingVariables.isRTDChk ? schedulingVariables.remarkObj : notesValues
                },
                shippingInfo: schedulingVariables.appointmentResponse.payload.shippingInfo,
                cart: cartValue,
                addlOrderAttributes: schedulingVariables.appointmentResponse.payload.addlOrderAttributes,
                productConfiguration: productConfValue,
                reason: [schedulingVariables.requestReason]
            }
        };
        return schedulingVariables.apiRequest;
    }
    public referralResp(event, schedulingVariables) {
        schedulingVariables.referralRequest = event;
    }
    public customerRequestedDueDateUpdated(event, schedulingVariables) {
        schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate = schedulingVariables.currentUrl ? this.ctlHelperService.convertDateFormat(event) : event;
    }
    public handleEffectiveBillDateUpdated(event, schedulingVariables) {
        schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = event;
        schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate;
    }
    public revertShippingAddress(schedulingVariables) {
        schedulingVariables.changeShippingAddressSelected = false;
        schedulingVariables.showShippingAddress = !schedulingVariables.showShippingAddress;
        schedulingVariables.addressArray = [];
        schedulingVariables.selectedAddress = schedulingVariables.shippingAddress;
    }
    public effectiveBillDateUpdated(event, schedulingVariables) {
        this.store.dispatch({ type: 'EFFECTIVE_BILLDATE_CHANGE', payload: true })
        schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = event;
        schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate;
    }
    public dueDateUpdated(event, schedulingVariables) {
        schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = event;
        schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = this.ctlHelperService.convertDateFormat(event);
        schedulingVariables.isdateChanged = schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        schedulingVariables.finalDateInfo = schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        if (schedulingVariables.orderFlow === "Move" && (schedulingVariables.finalDateInfo < schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate)) {
            schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = schedulingVariables.finalDateInfo;
            this.splitDueDateEligibleCheck(schedulingVariables.appointmentResponse.payload.addlOrderAttributes, schedulingVariables, event);
        } else {
            schedulingVariables.showChangeApptReasons = true;
            schedulingVariables.isDueDateUpdated = true;
        }
    }

    public useServiceAddress(schedulingVariables) {
        schedulingVariables.showShippingAddress = !schedulingVariables.showShippingAddress;
        schedulingVariables.shippingValidateAddress = false;
        schedulingVariables.changeShippingAddressSelected = false;
        schedulingVariables.changeShippingAdr = false;
        schedulingVariables.validatedAddress = false;
        schedulingVariables.postalAddressValidated = true;
        schedulingVariables.shippingAddress = schedulingVariables.shippingAddressObject;
        schedulingVariables.isRedAddressReturned = false;
        if(schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.shippingInfo) {
            schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress = schedulingVariables.shippingAddress;
            schedulingVariables.appointmentResponse.payload.shippingInfo.isShipAddrSameAsServiceAddress = true;
        }
    }

    public validateAddress(schedulingVariables) {
        schedulingVariables.addressLoading = true;
        schedulingVariables.shippingValidateAddress = false;
        schedulingVariables.validatedAddress = true;
        schedulingVariables.postalAddressValidated = true;
        schedulingVariables.yellowNewAddresses = false;
        schedulingVariables.isRedAddressReturned = false;
        schedulingVariables.selectedAddress = null;
        schedulingVariables.yellowAddresses = [];
        schedulingVariables.inputAddress = {
            streetAddress: schedulingVariables.myForm.value.addressLine,
            unitNumber: schedulingVariables.myForm.value.unitNumber,
            stateOrProvince: schedulingVariables.myForm.value.state,
            city: schedulingVariables.myForm.value.city,
            postCode: schedulingVariables.myForm.value.zipCode,
            addressLine2: schedulingVariables.myForm.value.unitNumber,
        };
        let lunitNumber: string = schedulingVariables.myForm.value.unitNumber;
        schedulingVariables.loading = true;
        this.logger.log("info", "schedule-shipping.appointment.component.ts", "getGeoesAddressRequest", JSON.stringify(schedulingVariables.inputAddress));
        this.logger.startTime();
        this.addressService.getGeoesAddress(schedulingVariables.inputAddress, 'civicAddresses')
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", schedulingVariables.currentComponet, "geoesAddrServiceResponse", JSON.stringify(error));
                this.logger.log("error", schedulingVariables.currentComponet, "geoesAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                schedulingVariables.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "SUBMIT_TASK", "schedule-shipping-appointment.component.ts", "Schedule Appointment Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", schedulingVariables.currentComponet, "geoesAddrServiceResponse", JSON.stringify(data));
                this.logger.log("info", schedulingVariables.currentComponet, "geoesAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                schedulingVariables.loading = false;
                if (data && data !== undefined && data !== null && (data.result === "Green" || data.result === "GREEN") && data.civicAddresses && data.civicAddresses.length === 1) {
                    if (data.civicAddresses[0].subAddress !== undefined) {
                        lunitNumber = data.civicAddresses[0].subAddress.designator + ' ' + data.civicAddresses[0].subAddress.value;
                    }
                    let geoesResponseAddress: EnterpriseAddress = {
                        isValidated: true,
                        streetAddress: data.civicAddresses[0].streetAddress,
                        streetNrFirst: data.civicAddresses[0].streetNrFirst,
                        streetNrFirstSuffix: '',
                        streetNamePrefix: data.civicAddresses[0].streetNamePrefix,
                        streetName: data.civicAddresses[0].streetName,
                        streetType: data.civicAddresses[0].streetType,
                        locality: data.civicAddresses[0].locality,
                        city: data.civicAddresses[0].locality,
                        stateOrProvince: data.civicAddresses[0].stateOrProvince,
                        postCode: data.civicAddresses[0].postCode,
                        postCodeSuffix: data.civicAddresses[0].postCodeSuffix !== 'undefined' ? data.civicAddresses[0].postCodeSuffix : '',
                        source: data.civicAddresses[0].source,
                        country: 'USA',
                        unitNumber: lunitNumber,
                        subAddress: {
                            sourceId: '',
                            source: data.civicAddresses[0].source,
                            geoSubAddressId: '',
                            combinedDesignator: lunitNumber,
                            elements: [
                                {
                                    designator: data.civicAddresses[0].subAddress !== undefined && data.civicAddresses[0].subAddress.designator !== undefined ? data.civicAddresses[0].subAddress.designator : '',
                                    value: data.civicAddresses[0].subAddress !== undefined && data.civicAddresses[0].subAddress.value !== undefined ? data.civicAddresses[0].subAddress.value : ''
                                }
                            ]
                        }
                    }
                    schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress = geoesResponseAddress;
                    schedulingVariables.appointmentResponse.payload.shippingInfo.isShipAddrSameAsServiceAddress = false;
                    schedulingVariables.validatedNewAddress = geoesResponseAddress;
                    schedulingVariables.validatedNewAddress.name = schedulingVariables.myForm.value.name;
                } else {
                    if (data && (data.result === 'RED' || data.result === 'Red')) {
                        schedulingVariables.responseFlag = 'red';
                        schedulingVariables.isRedAddressReturned = true;
                    } else {
                        schedulingVariables.responseFlag = 'yellow';
                        schedulingVariables.yellowNewAddresses = true;
                        schedulingVariables.yellowAddresses = data && data.civicAddresses;
                        if (schedulingVariables.orderFlow !== "Move" && data && data.civicAddresses && (data.civicAddresses.length > 0)) {
                            let geoesResponseAddress: EnterpriseAddress = {
                                isValidated: true,
                                streetAddress: data.civicAddresses[0].streetAddress,
                                streetNrFirst: data.civicAddresses[0].streetNrFirst,
                                streetNrFirstSuffix: '',
                                streetNamePrefix: data.civicAddresses[0].streetNamePrefix,
                                streetName: data.civicAddresses[0].streetName,
                                streetType: data.civicAddresses[0].streetType,
                                locality: data.civicAddresses[0].locality,
                                city: data.civicAddresses[0].locality,
                                stateOrProvince: data.civicAddresses[0].stateOrProvince,
                                postCode: data.civicAddresses[0].postCode,
                                postCodeSuffix: data.civicAddresses[0].postCodeSuffix !== 'undefined' ? data.civicAddresses[0].postCodeSuffix : '',
                                source: data.civicAddresses[0].source,
                                country: 'USA',
                                unitNumber: lunitNumber,
                                subAddress: {
                                    sourceId: '',
                                    source: data.civicAddresses[0].source,
                                    geoSubAddressId: '',
                                    combinedDesignator: lunitNumber,
                                    elements: [
                                        {
                                            designator: data.civicAddresses[0].subAddress !== undefined && data.civicAddresses[0].subAddress.designator !== undefined ? data.civicAddresses[0].subAddress.designator : '',
                                            value: data.civicAddresses[0].subAddress !== undefined && data.civicAddresses[0].subAddress.value !== undefined ? data.civicAddresses[0].subAddress.value : ''
                                        }
                                    ]
                                }
                            }
                            schedulingVariables.validatedNewAddress = geoesResponseAddress;
                        }
                        if(schedulingVariables.yellowAddresses) {
                            schedulingVariables.yellowAddresses.push(schedulingVariables.inputAddress);
                        }
                    }
                }
                schedulingVariables.addressLoading = false;
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", schedulingVariables.currentComponet, "geoesAddrServiceResponse", error);
                    this.logger.log("error", schedulingVariables.currentComponet, "geoesAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    schedulingVariables.addressLoading = false;
                    schedulingVariables.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        schedulingVariables.apiResponseError = JSON.parse(error);
                        if (schedulingVariables.apiResponseError !== undefined && schedulingVariables.apiResponseError !== null && schedulingVariables.apiResponseError.errorResponse &&
                            schedulingVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task", "schedule-shipping-appointment.component.ts", "Add-Ons Page", schedulingVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(schedulingVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task", "schedule-shipping-appointment.component.ts", "Add-Ons Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    public changeShippingAddress(schedulingVariables) {
        schedulingVariables.changeShippingAddressSelected = false;
        schedulingVariables.changeShippingAdr = true;
        schedulingVariables.showShippingAddress = !schedulingVariables.showShippingAddress;
        schedulingVariables.shippingValidateAddress = false;
        schedulingVariables.validatedAddress = false;
        schedulingVariables.postalAddressValidated = true;
        schedulingVariables.shippingAddress = schedulingVariables.validatedNewAddress;
        if (schedulingVariables.selectedAddress) {
            schedulingVariables.addressStreet = schedulingVariables.selectedAddress.streetAddress + ', ' + schedulingVariables.selectedAddress.locality + ', ' + schedulingVariables.selectedAddress.stateOrProvince + ', ' + schedulingVariables.selectedAddress.postCode;
            schedulingVariables.shippingAddress = schedulingVariables.selectedAddress;
            schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress = schedulingVariables.selectedAddress;
            schedulingVariables.appointmentResponse.payload.shippingInfo.isShipAddrSameAsServiceAddress = false;
        } else {
            let validAddress = {
                name: schedulingVariables.shippingAddress.name ? schedulingVariables.shippingAddress.name : schedulingVariables.shippingName,
                streetAddress: schedulingVariables.shippingAddress.streetAddress,
                unitNumber: schedulingVariables.shippingAddress.unitNumber,
                stateOrProvince: schedulingVariables.shippingAddress.stateOrProvince,
                city: schedulingVariables.shippingAddress.city,
                locality: schedulingVariables.shippingAddress.locality,
                postCode: schedulingVariables.shippingAddress.postCode,
            }
            this.store.dispatch({ type: 'UPDATE_USER', payload: { shippingName: validAddress.name } })
            schedulingVariables.shippingAddress = validAddress;
        }
        schedulingVariables.yellowAddresses = [];
        schedulingVariables.selectedAddress = null;
    }
    public changeEffectiveBill(schedulingVariables) {
        !schedulingVariables.isPendingFlow ? this.store.dispatch({ type: 'SPLITDUEDATE_CLICKED', payload: true }) : this.store.dispatch({ type: 'SUP2_SPLITDUEDATE_CLICKED', payload: true });
        if (!schedulingVariables.isPendingFlow) {
            schedulingVariables.dueDateStartText = 'Due Date (Start service)';
            schedulingVariables.dueDateEndText = 'Due Date (End service)';
        }
        schedulingVariables.changeEffectiveBillAddress = !schedulingVariables.changeEffectiveBillAddress;
        this.splitDueDateEligibleCheck(schedulingVariables.appointmentResponse.payload.addlOrderAttributes, schedulingVariables, schedulingVariables.finalDateInfo);
    }
    public splitDueDateEligibleCheck(addlOrderAttributes: any, schedulingVariables?: any, eventDate?: any) {
        if (addlOrderAttributes && addlOrderAttributes[0].orderAttributeGroup.length > 0) {
            addlOrderAttributes[0].orderAttributeGroup.map((chkDueDate) => {
                if (chkDueDate.orderAttributeGroupName === "splitDueDateInfo") {
                    chkDueDate.orderAttributeGroupInfo.map((groupInfo => {
                        groupInfo.orderAttributes.map(odrAttributes => {
                            if (odrAttributes.orderAttributeName === "isSplitDueDateEligible" && (odrAttributes.orderAttributeValue === "Y" || odrAttributes.orderAttributeValue === "y")) {
                                schedulingVariables.showSplitDueDateLink = true;
                            }
                            if (odrAttributes.orderAttributeName === "fromCalculatedDueDate") {
                                schedulingVariables.fromCalculatedDueDate = odrAttributes.orderAttributeValue;
                            }
                            if (odrAttributes.orderAttributeName === "fromFinalDueDate" && eventDate) {
                                if (eventDate === "noDate") {
                                    schedulingVariables.calculatedDueDate = odrAttributes.orderAttributeValue;
                                    schedulingVariables.fromFinalDueDate = odrAttributes.orderAttributeValue;
                                } else {
                                    odrAttributes.orderAttributeValue = this.ctlHelperService.convertDateFormat(eventDate);
                                    schedulingVariables.fromFinalDueDate = odrAttributes.orderAttributeValue;
                                }
                            }
                            if (odrAttributes.orderAttributeName === "fromFinalDueDate" && schedulingVariables.isReEntrant) {
                                schedulingVariables.calculatedDueDate = odrAttributes.orderAttributeValue;
                                if (eventDate) {
                                    schedulingVariables.fromFinalDueDate = this.ctlHelperService.convertDateFormat(eventDate);
                                } else {
                                    schedulingVariables.fromFinalDueDate = odrAttributes.orderAttributeValue;
                                }
                            }
                        })
                    }))
                }
            })
        }
    }

    public handleAppointmentUpdated(event, schedulingVariables) {
        schedulingVariables.reservedAppointment = event;
        schedulingVariables.selectedAppointmentDate = event && event.commitmentDateTime && event.commitmentDateTime.trim().substr(0, 10);
        this.showRefundTextMessage(schedulingVariables.selectedDueDate, schedulingVariables.selectedAppointmentDate, schedulingVariables);
        if (schedulingVariables.isApptUpdated) {
            schedulingVariables.isDueDateUpdated = true;
        }
        if (schedulingVariables.isReEntrant && !schedulingVariables.isPendingFlow) {
            this.reserveAppointment(schedulingVariables);
        } else {
            schedulingVariables.reservedCount === 0 ? schedulingVariables.reservedCount++ : this.reserveAppointment(schedulingVariables);
        }
    }
    public showRefundTextMessage(duedate, appointmentDate, schedulingVariables?) {
        duedate = duedate ? duedate : schedulingVariables.calculatedDueDate.trim().substr(0, 10);
        if (duedate !== appointmentDate && duedate < appointmentDate) {
            if(schedulingVariables && schedulingVariables.showRefundMessage) { schedulingVariables.showRefundMessage = true; }
        } else {
            if(schedulingVariables && schedulingVariables.showRefundMessage) { schedulingVariables.showRefundMessage = false; }
        }
    }
    public reserveAppointment(schedulingVariables) {
        schedulingVariables.earliestAvailableAppt = 'Appointment is reserved';
        schedulingVariables.showReserveItButton = false;
        if (schedulingVariables.isRTD) {
            schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = schedulingVariables.reservedAppointment.timeSlot.endDateTime.substr(0, 10) + 'T00:00:00.000Z';
        } else {
            schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = schedulingVariables.reservedAppointment.timeSlot.startDateTime.substr(0, 10) + 'T00:00:00.000Z';
        }
        if (schedulingVariables.currentUrl === '/schedule-appt-ship') {
            let currentDate = new DatePipe('en-US').transform(new Date(schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/')));
            if (currentDate !== schedulingVariables.prevDate) {
                schedulingVariables.isDueDateUpdated = true;
            }
        } else if (schedulingVariables.isPendingFlow) {
            schedulingVariables.isDueDateUpdated = true;
        }
        if (schedulingVariables.isDueDateUpdated) {
            schedulingVariables.showChangeApptReasons = true;
        } else {
            schedulingVariables.showChangeApptReasons = false;
        }
        let dateInString = schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
        schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
    }

    public handleBackToExistingProducts(event, schedulingVariables) {
        schedulingVariables.isPendingFlow ? this.router.navigate(['/pending-order']) : this.router.navigate(['/existing-products']);
    }

    public checkReasonAppt(selectedResonSchedule, schedulingVariables) {
        if (schedulingVariables.selectedResonSchedule !== undefined) {
            schedulingVariables.showErrorReason = false;
        }
    }
    public cbrMethod(contactNum, schedulingVariables) {
        schedulingVariables.cbrForm = this.fb.group({
            additionalNumber: [false],
            contactNumber: [contactNum ? contactNum : '', [Validators.required, Validations.cbrphoneValidator]],
        });
    }
    public addRemarks(value: any, schedulingVariables) {
        schedulingVariables.techRemark = '';
        if(schedulingVariables.remarkObj) schedulingVariables.remarkObj.push({ name: 'New Tech Remark', value: value, author: schedulingVariables.agentFirstName + ' ' + schedulingVariables.agentLastName });
    }
    public viewRccsDisclosure(schedulingVariables) {
        let cart1 = <Observable<ShoppingCart>>this.store.select('cart');
        let cartDetails;
        cart1.subscribe((data) => {
            cartDetails = data && data.payload && data.payload.cart;
        });
        for (let i in schedulingVariables.reasonReschedule) {
            if (schedulingVariables.reasonReschedule[i].reasonText === schedulingVariables.selectedResonSchedule) {
                schedulingVariables.requestReason = schedulingVariables.reasonReschedule[i];
                break;
            }
        }
        //For getting and reformating dueDate details
        if (schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate) {
            schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.replace(/\//g, '-');
        }
        if (schedulingVariables.effectiveBillDate && schedulingVariables.effectiveBillDate !== "" && schedulingVariables.effectiveBillDate !== null) {
            schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = schedulingVariables.effectiveBillDate.replace(/\//g, '-') + "T00:00:00.000Z";
        }
        if (schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate) {
            schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate.replace(/\//g, '-');
        }
        if (schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate) {
            schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate = schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate.replace(/\//g, '-');
        }
        if ((schedulingVariables.selectedResonSchedule === 'Choose your option..' || schedulingVariables.selectedResonSchedule === '') && schedulingVariables.showChangeApptReasons && schedulingVariables.isDueDateUpdated && schedulingVariables.isAmend) {
            schedulingVariables.showErrorReason = true;
            return;
        } else {
            schedulingVariables.loading = true;
            let request = {
                orderRefNumber: schedulingVariables.orderRefNumber,
                rccGroupId: "SCHEDULE",
                salesChannel: "ESHOP - Customer Care",
                versionNumber: "",
                cart: cartDetails,
                schedule: {
                    dates: schedulingVariables.appointmentResponse.payload.dueDate,
                    appointmentInfo: schedulingVariables.reservedAppointment,
                    billeffectiveDateInfo: schedulingVariables.appointmentResponse.payload.defaultBillEffectiveDate
                }
            }
            if(request.orderRefNumber === "" )
            {
                request.orderRefNumber =  schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.orderRefNumber;
            }
            schedulingVariables.loading = true;
            let errorResolved = false;
            this.logger.log("info", schedulingVariables.currentComponet, "retrieveRccDisclosuresRequest", JSON.stringify(request));
            this.logger.startTime();
            this.disclosuresService.viewRccsDisclosure(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", schedulingVariables.currentComponet, "retrieveRccDisclosuresResponse", JSON.stringify(error));
                    this.logger.log("error", schedulingVariables.currentComponet, "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    schedulingVariables.loading = false;
                    errorResolved = true;
                    this.continueClick(schedulingVariables);
                    return Observable.throwError(null);
                })
                .subscribe((data: DisclosuresRes) => {
                    this.logger.endTime();
                    this.logger.log("info", schedulingVariables.currentComponet, "retrieveRccDisclosuresResponse", JSON.stringify(data));
                    this.logger.log("info", schedulingVariables.currentComponet, "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    schedulingVariables.loading = false;
                    schedulingVariables.discloserPopUpSelected = true;
                    if (data && data.rccGroup) {
                        if (data && data.rccGroup && data.rccGroup.length > 0) {
                            this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: data });
                            if(schedulingVariables.orderDisclosures) schedulingVariables.orderDisclosures.open();
                        } else {
                            this.continueClick(schedulingVariables);
                        }
                    } else {
                        this.continueClick(schedulingVariables);
                    }
                },
                    (error) => {
                        this.logger.endTime();
                        this.logger.log("error", schedulingVariables.currentComponet, "retrieveRccDisclosuresResponse", error);
                        this.logger.log("error", schedulingVariables.currentComponet, "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.ctlHelperService.isJson(error) && this.logger.log("error", schedulingVariables.currentComponet, "retrieveRccDisclosuresResponse", JSON.stringify(error));
                            this.ctlHelperService.isJson(error) && this.logger.log("error", schedulingVariables.currentComponet, "retrieveRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.continueClick(schedulingVariables);
                            schedulingVariables.loading = false;
                        }
                    })
        }
    }
    public toContinue(schedulingVariables) {
        let isDisclosureAllowed = true;
        let apiRequest;
      
        if (!apiRequest) {
            apiRequest = this.reqFormat(schedulingVariables);
        }
        if (schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.appointmentInfo && schedulingVariables.appointmentResponse.payload.appointmentInfo.apptmntSvcsDown) {
            if(schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.dueDate && schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate && schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.appointmentInfo &&schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment && schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0] && schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0].commitmentDateTime)
            schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.appointmentInfo &&schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment && schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0] && schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment[0].commitmentDateTime.substr(0, 10) + "T00:00:00.000Z" ;
        
        }

        if (schedulingVariables.discloserPopUpSelected || schedulingVariables.isReEntrant) {
            let currentStore = this.appStateService.getState();
            let retainVal = currentStore.retain;
            if (retainVal && retainVal.moveSchedulingReq) {
                schedulingVariables.retainedSchedulingData = retainVal.moveSchedulingReq;
            }
            let existingReq = schedulingVariables.retainedSchedulingData;
            if (existingReq && existingReq.payload && apiRequest && apiRequest.payload && _.isEqual(JSON.stringify(existingReq.payload), JSON.stringify(apiRequest.payload))) {
                isDisclosureAllowed = false;
            }
        }
        if (isDisclosureAllowed) {
            this.viewRccsDisclosure(schedulingVariables);
        } else {
            this.continueClick(schedulingVariables);
        }
    }
    public continueClick(schedulingVariables) {
        schedulingVariables.isNotFromContinue = true;
        this.store.dispatch({ type: 'RETAIN_RESERVED_APPOINTMENT', payload: schedulingVariables.reservedAppointment });
        this.store.dispatch({ type: 'RESERVED_APPOINTMENT', payload: schedulingVariables.reservedAppointment });
        this.store.dispatch({ type: 'RESERVED_CBR', payload: schedulingVariables.cbrForm.value.contactNumber });
        schedulingVariables.errorMsg = '';
        if (!schedulingVariables.referralRequest && schedulingVariables.potsRemoved && schedulingVariables.isChangeFlow &&  !schedulingVariables.isCenturyLink) {
            schedulingVariables.errorMsg = 'Please Add Call Referral to continue';
            return
        }
        if (!schedulingVariables.postalAddressValidated) {
            schedulingVariables.addressNotValidatedMsg = 'Looks like the address needs to be validated.';
            return
        }
        let appointmentInfoNoValue: boolean = false;
        schedulingVariables.loading = true;
        let apptObservable = <Observable<any>>this.store.select('appointment');
        let apptObservableSub = apptObservable.subscribe((data) => {
            this.user = <Observable<User>>this.store.select('user');
            let userSub = this.user.subscribe((data) => {
                if (data.taskId !== null && data.taskId !== undefined)
                    schedulingVariables.appointmentResponse.taskId = data.taskId;
                if (data.autoLogin && data.autoLogin.oamData && data.autoLogin.oamData.agentFirstName && data.autoLogin.oamData.agentLastName) {
                    schedulingVariables.agentFirstName = data.autoLogin.oamData.agentFirstName;
                    schedulingVariables.agentLastName = data.autoLogin.oamData.agentLastName;
                }

            });
            userSub.unsubscribe();
        });
        apptObservableSub.unsubscribe();
        if (schedulingVariables.appointmentResponse.payload.appointmentInfo === null || schedulingVariables.appointmentResponse.payload.appointmentInfo === undefined) {
            appointmentInfoNoValue = true;
            this.store.dispatch({ type: 'APPOINTMENT_DATA', payload: appointmentInfoNoValue})
        }
        if (schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.addlOrderAttributes
            && Array.isArray(schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
            schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                    item.orderAttributeGroup.forEach((item: any) => {
                        if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                            item.orderAttributeGroupInfo.forEach((item: any) => {
                                if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                    item.orderAttributes.forEach((item: any) => {
                                        if (item.orderAttributeName === "orderLevelCBRNumber") {
                                            item.orderAttributeValue = schedulingVariables.cbrForm.value.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                                            schedulingVariables.isCbr = true;
                                        } else if (item.orderAttributeName === "Techdroppedmodem" && schedulingVariables.orderFlow !== "Disconnect" && schedulingVariables.orderFlow !== "billing" && !schedulingVariables.isVacationFlow) {
                                            item.orderAttributeValue = schedulingVariables.techdropped;
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
        if (!schedulingVariables.isCbr) {
            let additionalAttr =
            {
                "orderAttributeGroup": [{
                    "orderAttributeGroupName": "orderLevelCBRInfo",
                    "orderAttributeGroupInfo": [{
                        "orderAttributes": [{
                            "orderAttributeName": "orderLevelCBRNumber",
                            "orderAttributeValue": schedulingVariables.cbrForm.value.contactNumber.toString().replace(/[^A-Z0-9]/ig, "")
                        }]
                    }]
                }]
            };
            this.addAddlOrderAttribute(additionalAttr, schedulingVariables);
        }
        if(schedulingVariables.isWaiveOtcAllowed){
            let additionalAttribute;
            let group = "otcAdjustmentInfo";
            if(schedulingVariables && schedulingVariables.waivedOtcInfo && schedulingVariables.waivedOtcInfo.otcWaiverList &&
                schedulingVariables.waivedOtcInfo.otcWaiverList.reason && schedulingVariables.waivedOtcInfo.otcWaiverList.reason.code &&
                schedulingVariables.waivedOtcInfo.otcWaiverList.reason.description && schedulingVariables.waivedOtcInfo.otcWaiverList.waivers.length > 0 &&
                schedulingVariables.waivedOtcInfo.totalWaivedOtc > 0){
                    schedulingVariables.waivedOtcInfo.otcWaiverList.waivers.map((otcproduct)=>{
                        if(otcproduct && otcproduct.productName){
                            additionalAttribute = this.addOrderAttributeNameAndValue("productName",otcproduct.productName,group,additionalAttribute);
                        }
                    });
                    additionalAttribute = this.addOrderAttributeNameAndValue("reasonCode",schedulingVariables.waivedOtcInfo.otcWaiverList.reason.code,group,additionalAttribute);
                    additionalAttribute = this.addOrderAttributeNameAndValue("reasonDescription",schedulingVariables.waivedOtcInfo.otcWaiverList.reason.description,group,additionalAttribute);            
                    this.addAddlOrderAttribute(additionalAttribute, schedulingVariables);
            }                  
        }
        if (schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate) {
            schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate.replace(/\//g, '-');
        }
        if (schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate) {
            schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate = schedulingVariables.appointmentResponse.payload.dueDate.effectiveBillDate.replace(/\//g, '-');
        }
        if (schedulingVariables.formattedContactNumber !== schedulingVariables.formattedNumber) {
            schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes = [];
            schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup[0]
                .orderAttributeGroupInfo[0].orderAttributes.push({
                    "orderAttributeName": "orderLevelCBRNumber",
                    "orderAttributeValue": schedulingVariables.cbrForm.value.contactNumber.toString().replace(/[^A-Z0-9]/ig, "")
                })
            schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup[0]
                .orderAttributeGroupInfo[0].orderAttributes.push({
                    "orderAttributeName": "storeAsAccountLevelCBR2",
                    "orderAttributeValue": schedulingVariables.cbrForm.value.additionalNumber ? 'true' : 'false',
                });
        }
        if (!schedulingVariables.fromFinalDueDate && schedulingVariables.orderFlow !== "billing" && !schedulingVariables.isVacationFlow) { // move
            this.splitDueDateEligibleCheck(schedulingVariables.appointmentResponse.payload.addlOrderAttributes, schedulingVariables, schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate);
        }
        if (schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate && schedulingVariables.orderFlow !== "billing" && !schedulingVariables.isVacationFlow) {
            schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate = schedulingVariables.appointmentResponse.payload.dueDate.requestedDueDate.replace(/\//g, '-');
        }
        for (let i in schedulingVariables.reasonReschedule) {
            if (schedulingVariables.reasonReschedule[i].reasonText === schedulingVariables.selectedResonSchedule) {
                schedulingVariables.requestReason = schedulingVariables.reasonReschedule[i];
                break;
            }
        }
        let apiRequest: any;
        if (((schedulingVariables.potsRemoved || schedulingVariables.phonenoChanged === "yes") && schedulingVariables.isChangeFlow) || schedulingVariables.isAmend) {
            apiRequest = this.reqFormat(schedulingVariables);
        } else if (schedulingVariables.orderFlow !== "billing") {
            apiRequest = this.reqFormat(schedulingVariables);
        } else {
            if(schedulingVariables.orderFlow === "billing") { delete schedulingVariables.appointmentResponse.payload.adjustableOtcInfo; }
            apiRequest = schedulingVariables.appointmentResponse
}
        if (apiRequest.payload && apiRequest.payload.availableAppointment !== undefined && apiRequest.payload.availableAppointment && (apiRequest.payload.availableAppointment.commitmentDateTime === undefined || apiRequest.payload.availableAppointment.commitmentDateTime === null)) {
            delete apiRequest.payload.availableAppointment;
        }
        if (apiRequest && apiRequest.payload && apiRequest.payload.reason && (apiRequest.payload.reason[0] === undefined || apiRequest.payload.reason[0] === null)) {
            delete apiRequest.payload.reason;
        }
        if (schedulingVariables.orderFlow === "billing" && (schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.billeffectiveDateInfo) || (schedulingVariables.appointmentResponse && schedulingVariables.appointmentResponse.payload && schedulingVariables.appointmentResponse.payload.billeffectiveDateInfo === null)) {
            delete schedulingVariables.appointmentResponse.payload.billeffectiveDateInfo;
        }
        if (schedulingVariables.isCORFlow) {
            if (schedulingVariables.mandatorySubOffers && schedulingVariables.mandatorySubOffers.length > 0) {
                schedulingVariables.appointmentResponse.payload.cart.customerOrderItems.push(schedulingVariables.mandatorySubOffers[0]);
            }
            delete apiRequest.productConfiguration;
            delete apiRequest.payload.apptNotes;
            if (apiRequest.payload.cart === null) {
                apiRequest.payload.cart = schedulingVariables.appointmentResponse.payload.cart;
            }
        }
        if (schedulingVariables.orderFlow === "Disconnect") {
            if (schedulingVariables.isReEntrant) {
                schedulingVariables.appointmentResponse.taskId = schedulingVariables.taskId;
            } else {
                this.disconnectService.offersData = schedulingVariables.appointmentResponse.payload.offers;
                this.disconnectService.accounInfo = schedulingVariables.appointmentResponse.payload.accountName;
            }
            if (schedulingVariables.appointmentResponse.payload.accountName) delete schedulingVariables.appointmentResponse.payload.accountName;
            if (schedulingVariables.appointmentResponse.payload.offers) delete schedulingVariables.appointmentResponse.payload.offers;
        }
        this.store.dispatch({ type: 'EFFECTIVE_DUE_DATE', payload: schedulingVariables.appointmentResponse });
        this.store.dispatch({ type: 'MOVE_SCHEDULING_REQUEST', payload: apiRequest });
        schedulingVariables.loading = true;
        this.logger.log("info", schedulingVariables.currentComponet, "scheduleAppointmentRequest", JSON.stringify(apiRequest));
        this.logger.startTime();
        this.schedulingService.scheduleAppointment(apiRequest, schedulingVariables.isChangeFlow, schedulingVariables.agentFirstName, schedulingVariables.agentLastName, schedulingVariables.orderFlow,
            appointmentInfoNoValue, schedulingVariables.appointmentResponse.payload.exceptionDaysInfo,
            schedulingVariables.appointmentResponse.payload.exceptionfromDueDaysInfo,
            schedulingVariables.isVacationFlow
        )
            .mergeMap((primaryRes: any) => {
                if (primaryRes.taskName === "Credit Review" && primaryRes.payload.depositInfo && primaryRes.payload.depositInfo.depositRequired === false && primaryRes.payload.addlOrderAttributes && primaryRes.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo.length === 0 && schedulingVariables.orderFlow !== "Move") {
                    let subApiRequest = {
                        orderRefNumber: primaryRes.orderRefNumber,
                        processInstanceId: primaryRes.processInstanceId,
                        taskId: schedulingVariables.isReEntrant ? schedulingVariables.appointmentResponse.taskId : primaryRes.taskId,
                        taskName: primaryRes.taskName,
                        payload: {
                            "creditReviewAction": "SHOWSUMMARY",
                            "accountName": {
                                "firstName": schedulingVariables.userStore.firstName,
                                "lastName": schedulingVariables.userStore.lastName,
                                "middleName": "",
                                "businessName": null,
                                "title": "Mr",
                                "generation": null
                            },
                            "personalDetails": {
                                "dateOfBirth": null,
                                "dLExpirationDate": null,
                                "dLlicenseNo": null,
                                "dLlicenseState": null,
                                "ssn": null,
                                "taxId": null,
                                "creditCheck": true,
                                "underAgeAck": null
                            },
                            "addlOrderAttributes": [
                                {
                                    "orderAttributeGroup": [
                                        {
                                            "orderAttributeGroupName": "otcInstallmentInfo",
                                            "orderAttributeGroupInfo": []
                                        }
                                    ]
                                }
                            ]
                        }
                    };
                    return this.schedulingService.scheduleAppointment(subApiRequest, schedulingVariables.isChangeFlow, schedulingVariables.agentFirstName, schedulingVariables.agentLastName)
                        .map((data) => {
                            return {
                                "switchCase": "1",
                                "data": data
                            }
                        });
                } else if (primaryRes.taskName === "Credit Review" && ((primaryRes.payload.depositInfo && primaryRes.payload.depositInfo.depositRequired === true) || (schedulingVariables.isPrepaid && schedulingVariables.orderFlow === 'Move'))) {
                    // case 2 - deposit and installment
                    return Observable.of({
                        "switchCase": "3",
                        "data": primaryRes
                    });
                } else if (primaryRes.taskName === "Credit Review" && primaryRes.payload.depositInfo && primaryRes.payload.depositInfo.depositRequired === false && primaryRes.payload.addlOrderAttributes && primaryRes.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo.length > 0) {
                    // case 3 - no deposit and installment
                    return Observable.of({
                        "switchCase": "3",
                        "data": primaryRes
                    });
                } else if (schedulingVariables.isAmend && primaryRes.taskName === "Credit Review") {
                    // case 5 - Prepaid Account 
                    return Observable.of({
                        "switchCase": "5",
                        "data": primaryRes
                    });
                } else if ((primaryRes.taskName === "Submit Order" && schedulingVariables.orderFlow !== "Disconnect") ||  (primaryRes.taskName === "Credit Review" && schedulingVariables.orderFlow === "billing")) {
                    // case 4 - no deposit and installment
                    return Observable.of({
                        "switchCase": "4",
                        "data": primaryRes
                    });
                } else {
                    // case '' for Account Information
                    return Observable.of({
                        "switchCase": "",
                        "data": primaryRes
                    });
                }
            })
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", schedulingVariables.currentComponet, "scheduleAppointmentResponse", JSON.stringify(error));
                this.logger.log("error", schedulingVariables.currentComponet, "scheduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                schedulingVariables.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "submitTask - scheduleAppointment", schedulingVariables.currentComponet, "Schedule Appointment", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", schedulingVariables.currentComponet, "scheduleAppointmentResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", schedulingVariables.currentComponet, "scheduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let response = data;
                    switch (response.switchCase) {
                        case "1":
                            if (response.data.taskName === 'Submit Order') {
                                this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                this.store.dispatch({ type: 'REVIEW_ORDER', payload: response.data });
                                if (schedulingVariables.dtvYes) {
                                    this.router.navigate(['/directv-account']);
                                } else {
                                    this.store.dispatch({ type: 'CREDIT_REVIEW_PAYMENT_STATUS', payload: true })
                                    this.router.navigate(['/co-review-order']);
                                }
                            } break;
                        case "2":
                            if (response.data.taskName === 'Credit Review' && !schedulingVariables.isChange) {
                                if (schedulingVariables.reuseBan) {
                                    this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                                    this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                    this.store.dispatch({ type: 'BILLING_ADDR', payload: response.data.payload.billingAddress });
                                    this.router.navigate(['/reuse-ban-account']);
                                } else {
                                    this.store.dispatch({ type: 'DEPOSIT_DATA', payload: response.data });
                                    this.store.dispatch({ type: 'BILLING_ADDR', payload: response.data.payload.billingAddress });
                                    this.router.navigate(['/account']);
                                    this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                                    this.store.dispatch({ type: 'CREDIT_REVIEW', payload: response.data });
                                    this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                }
                            } else {
                                this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId })
                                this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                                this.router.navigate(['/change-account']);
                            }
                            break;
                        case "3":
                            if (response.data.taskName === 'Credit Review' && !schedulingVariables.isChange && schedulingVariables.orderFlow !== "Move") {
                                this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                if (schedulingVariables.reuseBan) {
                                    this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                                    this.store.dispatch({ type: 'TASK_NAME', payload: response.data.taskName });
                                    this.store.dispatch({ type: 'BILLING_ADDR', payload: response.data.payload.billingAddress });
                                    this.router.navigate(['/reuse-ban-account']);
                                } else {
                                    this.store.dispatch({ type: 'DEPOSIT_DATA', payload: response.data });
                                    this.store.dispatch({ type: 'CREDIT_REVIEW', payload: response.data });
                                    this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                                    this.store.dispatch({ type: 'BILLING_ADDR', payload: response.data.payload.billingAddress });
                                    this.router.navigate(['/account']);
                                }
                            } else if (schedulingVariables.orderFlow !== "Move") {
                                this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId })
                                this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                                this.router.navigate(['/change-account']);
                            } else {
                                this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                                this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                if (schedulingVariables.dtvYes) {
                                    this.router.navigate(['/directv-account']);
                                } else {
                                    this.router.navigate(['/move-account']);
                                }
                            }
                            break;
                        case "4":
                            this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                            this.store.dispatch({ type: 'REVIEW_ORDER', payload: response.data });
                            if (schedulingVariables.dtvYes) {
                                this.router.navigate(['/directv-account']);
                            } else if (schedulingVariables.orderFlow !== "billing" && schedulingVariables.orderFlow !== "Disconnect") {
                                this.store.dispatch({ type: 'CREDIT_REVIEW_PAYMENT_STATUS', payload: true })
                                this.router.navigate(['/co-review-order']);
                            } else {
                                this.router.navigate(['/billing-review-order']);
                            }
                            break;
                        case "5":
                            this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                            this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                            this.store.dispatch({ type: 'CREDIT_REVIEW', payload: response.data });
                            this.router.navigate(['/amend-account']);
                            break;
                        default:
                            if (response.data && response.data.errorResponse && response.data.errorResponse.length > 0) {
                                schedulingVariables.apiResponseError = response.data;
                                schedulingVariables.apiResponseError.errorResponse[0].statusCode = '200';
                                if(response.data.errorResponse[0] && response.data.errorResponse[0].reasonCode === 'ARN_NOT_APPROVED') {
                                    schedulingVariables.errorMsg = response.data.errorResponse[0].messageDetail;
                                } else {
                                    this.systemErrorService.logAndeRouteToSystemError("error", schedulingVariables.appointmentResponse.taskName, schedulingVariables.currentComponet, "Schedule Shipping Appointment Page", schedulingVariables.apiResponseError);
                                }
                                schedulingVariables.loading = false;
                                return false;
                            }
                            this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                            this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                            if (schedulingVariables.isVacationFlow) {
                                this.ctlHelperService.storeRequestProcessData(data, 'vacation-account', 'submit', 'vacation');
                                this.router.navigate(['/vacation-account']);
                            } else if (schedulingVariables.orderFlow === "Disconnect") {
                                if (response.data && response.data.taskName === 'Submit Order') {
                                    this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                    this.store.dispatch({ type: 'DISCONNECT_REVIEW_ORDER', payload: { disconnect_review_order: response.data } });
                                    this.router.navigate(['/disconnect-review-order']);
                                } else {
                                    this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: response.data });
                                    this.store.dispatch({ type: 'TASK_ID', payload: response.data.taskId });
                                    this.router.navigate(['/disconnect-account']);
                                }
                            } else {
                                let maxCreditCheckReached = response && response.data.payload && response.data.payload.maxCreditCheckReached;
                                this.store.dispatch({ type: 'UPDATE_APPLICATION_COUNT', payload: maxCreditCheckReached });
                                this.store.dispatch({ type: 'BILLING_ADDR', payload: response.data.payload.billingAddress });
                                this.router.navigate(['/account']);
                            }
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", schedulingVariables.currentComponet, "scheduleAppointmentResponse", error);
                    this.logger.log("error", schedulingVariables.currentComponet, "scheduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    schedulingVariables.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        schedulingVariables.apiResponseError = JSON.parse(error);
                        if (schedulingVariables.apiResponseError !== undefined && schedulingVariables.apiResponseError !== null && schedulingVariables.apiResponseError.errorResponse &&
                            schedulingVariables.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", schedulingVariables.appointmentResponse.taskName, schedulingVariables.currentComponet, "Schedule Shipping Appointment Page", schedulingVariables.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(schedulingVariables.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", schedulingVariables.appointmentResponse.taskName, schedulingVariables.currentComponet, "Schedule Shipping Appointment Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                }
            );
    }

    public setDefaultsVariables(schedulingVariables: SchedulingVariables) {
        schedulingVariables = {} as SchedulingVariables;
        schedulingVariables.animalsPresentCheckBox = false;
        schedulingVariables.electricFenceCheckBox = false;
        schedulingVariables.lockedGateCheckBox = false;
        schedulingVariables.drivingDirections = '';
        schedulingVariables.additionalComments = '';
        schedulingVariables.reservedCount = 0;
        schedulingVariables.selectedAppointment = false;
        schedulingVariables.reservedAppointment = {} as AvailableAppointment;
        schedulingVariables.appointmentResponse = {} as AppointmentShipping;
        schedulingVariables.apiResponseError = {} as APIErrorLists;
        schedulingVariables.earliestAvailableAppt = 'Earliest available appointment';
        schedulingVariables.showReserveItButton = true;
        schedulingVariables.isRTD = false;
        schedulingVariables.isReEntrant = false;
        schedulingVariables.appointmentPayload = {} as AppointmentPayload;
        schedulingVariables.dueDate = '';
        schedulingVariables.isApptUpdated = false;
        schedulingVariables.isDueDateUpdated = false;
        schedulingVariables.prevDate = '';
        schedulingVariables.showChangeApptReasons = false;
        schedulingVariables.currentUrl = '';
        schedulingVariables.isPendingFlow = false;
        schedulingVariables.selectedAppointmentDate = '';
        schedulingVariables.selectedDueDate = '';
        schedulingVariables.calculatedDueDate = '';
        schedulingVariables.showRefundMessage = false;
        schedulingVariables.changeEffectiveBillAddress = false;
        schedulingVariables.changeEffectiveBillAddressCalendar = false;
        schedulingVariables.dueDateStartText = 'Due Date(both locations)';
        schedulingVariables.dueDateEndText = 'Due Date (End service)';
        schedulingVariables.dueDateEndText = 'Due Date (End service)';
        schedulingVariables.finalDateInfo = '';
        schedulingVariables.fromCalculatedDueDate = '';
        schedulingVariables.fromFinalDueDate = '';
        schedulingVariables.showSplitDueDateLink = false;
        schedulingVariables.changeShippingAddressSelected = false;
        schedulingVariables.showShippingAddress = false;
        schedulingVariables.addressArray = [];
        schedulingVariables.selectedAddress = {} as EnterpriseAddress;
        schedulingVariables.selectedResonSchedule = "Choose your option..";
        schedulingVariables.showErrorReason = false;
        schedulingVariables.remarkObj = [];
        schedulingVariables.techRemark = '';
        schedulingVariables.firstname = '';
        schedulingVariables.lastname = '';
        schedulingVariables.agentFirstName = '';
        schedulingVariables.agentLastName = '';
        schedulingVariables.isAmend = false;
        schedulingVariables.isStack = false;
        schedulingVariables.isRTDChk = false;
        schedulingVariables.potsRemoved = false;
        schedulingVariables.phonenoChanged = '';
        schedulingVariables.isChangeFlow = false;
        schedulingVariables.referralRequest = null;
        schedulingVariables.requestReason = null;
        schedulingVariables.apiRequest = {};
        schedulingVariables.errorMsg = '';
        schedulingVariables.schedulingShippingPage = false;
        schedulingVariables.addressNotValidatedMsg = '';
        schedulingVariables.postalAddressValidated = true;
        schedulingVariables.isCbr = false;
        schedulingVariables.techdropped = false;
        schedulingVariables.formattedContactNumber = '';
        schedulingVariables.formattedNumber = '';
        schedulingVariables.reasonReschedule = {} as Reason[];
        schedulingVariables.isCORFlow = false;
        schedulingVariables.mandatorySubOffers = [];
        schedulingVariables.orderFlow = '';
        schedulingVariables.userStore = {} as User;
        schedulingVariables.isChange = false;
        schedulingVariables.reuseBan = false;
        schedulingVariables.orderRefNumber = '';
        schedulingVariables.dtvYes = false;
        schedulingVariables.myForm = FormGroup;
        schedulingVariables.cbrForm = FormGroup;
        schedulingVariables.loading = false;
        schedulingVariables.currentComponet = '';
        schedulingVariables.orderDisclosures = '';
        schedulingVariables.discloserPopUpSelected = false;
        schedulingVariables.retainedSchedulingData = null;
        schedulingVariables.isVacationFlow = false;
        schedulingVariables.vacScheOrderRefNumber = "";
        schedulingVariables.vacScheProcessInstanceId = "";
        schedulingVariables.vacScheTaskId = "";
        schedulingVariables.vacScheTaskName = "";
        schedulingVariables.isdateChanged = "";
        schedulingVariables.finalDateInfo = "";
        schedulingVariables.shippingValidateAddress = false;
        schedulingVariables.validatedAddress = false;
        schedulingVariables.validatedNewAddress = {} as EnterpriseAddress;
        schedulingVariables.shippingAddress = null;
        schedulingVariables.addressStreet = '';
        schedulingVariables.shippingName = '';
        schedulingVariables.yellowAddresses = [] as EnterpriseAddress[];
        schedulingVariables.changeShippingAdr = false;
        schedulingVariables.addressLoading = false;
        schedulingVariables.yellowNewAddresses = false;
        schedulingVariables.isRedAddressReturned = false;
        schedulingVariables.inputAddress = {} as EnterpriseAddress;
        schedulingVariables.responseFlag = '';
        schedulingVariables.isNotFromContinue = false;
        schedulingVariables.taskId = '';
        schedulingVariables.nextPaymentDate = '';
        schedulingVariables.effectiveBillDate = '';
        schedulingVariables.previousUrl = '';
        schedulingVariables.shippingAddressObject = {} as ShippingAddres;
        schedulingVariables.isCenturyLink = false;
        schedulingVariables.isWaiveOtcAllowed = false;
        schedulingVariables.adjustableOtcProducts = [];
        schedulingVariables.waivedReasonList = [];
        schedulingVariables.eligibleCharges = 0;
        schedulingVariables.waivedOtcInfo = {} as WaivedOtcInfo;
        schedulingVariables.waivedOtcInfo.totalWaivedOtc = 0;
        return schedulingVariables;
    }


    public fetchAddlOrderAttributes(AddlOrderAttributes, AttributeName) {
        let AttributeValue = '';
        AddlOrderAttributes && AddlOrderAttributes.map(Attribute => {
            Attribute.orderAttributeGroup.map(AttributeGroup => {
                if (AttributeGroup.orderAttributeGroupName) {
                    AttributeGroup.orderAttributeGroupInfo.map(GroupInfo => {
                        GroupInfo.orderAttributes.map(orderAttributes => {
                            if (orderAttributes.orderAttributeName === AttributeName) {
                                AttributeValue = orderAttributes.orderAttributeValue;
                            }
                        })
                    })
                }
            })
        });
        return AttributeValue;
    }

    public waiveOtcAllowedCheck(schedulingVariables) {
        let allowedFlows = {
            NEWINSTALL: true,
            MOVE: true,
            BILLING: true,
            CHANGE: (schedulingVariables && schedulingVariables.isChangeFlow && schedulingVariables.isStack) ? false : true,
            BILLANDREC: true
        };
        if(schedulingVariables && schedulingVariables.orderFlow) 
        schedulingVariables.isWaiveOtcAllowed = this.helperService.isAuthorized(ProfileEnums.WAIVE_ADJUSTABLE_OTCS) 
        && this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_WAIVE_OTC) && allowedFlows[schedulingVariables.orderFlow.toUpperCase()] 
        && schedulingVariables.adjustableOtcProducts && schedulingVariables.adjustableOtcProducts.length > 0;
    }

    public initializeAdjustableOtcInfo(schedulingVariables: SchedulingVariables) {
        let apptObservable = <Observable<any>>this.store.select('appointment');
        let apptObservableSub = apptObservable.subscribe((data) => {
            if(data && data.payload && data.payload.adjustableOtcInfo) {
                if(data.payload.adjustableOtcInfo.adjustableOtcProducts && data.payload.adjustableOtcInfo.adjustableOtcProducts.productOfferDetails) {
                    schedulingVariables.adjustableOtcProducts = data.payload.adjustableOtcInfo.adjustableOtcProducts.productOfferDetails;
                    schedulingVariables.adjustableOtcProducts.forEach(obj=>obj.waived = false);
                }
                if(data.payload.adjustableOtcInfo.reason) {
                    schedulingVariables.waivedReasonList = data.payload.adjustableOtcInfo.reason;
                }
            }
        });
        if(apptObservableSub) {
            apptObservableSub.unsubscribe();
        }
        let cartDisplayCustOrdItems;
        let cartObservable = <Observable<any>>this.store.select('cart');
        let cartObservableSub = cartObservable.subscribe((data)=>{
            cartDisplayCustOrdItems = data && data.payload && data.payload.cart && data.payload.cart.customerOrderItems
        });
        if(cartObservableSub) {
            cartObservableSub.unsubscribe();
        }
        let isModemPresent = false;
            cartDisplayCustOrdItems.map((item)=>{
                item.customerOrderSubItems.map((subitem)=>{
                    if(subitem.productName ===  GenericValues.modem){
                        isModemPresent = true;
                    }
                })
            })
        if(!isModemPresent && schedulingVariables.adjustableOtcProducts){
            schedulingVariables.adjustableOtcProducts = schedulingVariables.adjustableOtcProducts.filter((prod)=>{
                return prod.productName !== GenericValues.modem;
            })
        }        
    }

    public retainWaivedOtc(schedulingVariables) {
        if(schedulingVariables && schedulingVariables.waivedOtcInfo && schedulingVariables.adjustableOtcProducts && schedulingVariables.adjustableOtcProducts.length > 0) {
            schedulingVariables.adjustableOtcProducts.forEach(obj=>obj.waived = false);
            if(schedulingVariables.waivedOtcInfo.otcWaiverList && schedulingVariables.waivedOtcInfo.otcWaiverList.waivers && schedulingVariables.waivedOtcInfo.otcWaiverList.waivers.length > 0) {
                schedulingVariables.waivedOtcInfo.otcWaiverList.waivers.map(waivedProd => {
                    let index = schedulingVariables.adjustableOtcProducts.findIndex(prod => prod.productName === waivedProd.productName);
                    if(index !== -1) {
                        schedulingVariables.adjustableOtcProducts[index].waived = waivedProd.waived;
                    }
                });
            }
        }
    }

    public addAddlOrderAttribute( additionalAttr , schedulingVariables){
        if (schedulingVariables.appointmentResponse.payload.addlOrderAttributes && schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup) {
            let index = schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup.findIndex(group => group.orderAttributeGroupName === additionalAttr.orderAttributeGroup[0].orderAttributeGroupName);
            if(index !== -1) {
                schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup[index] = additionalAttr.orderAttributeGroup[0];
            } else {
                schedulingVariables.appointmentResponse.payload.addlOrderAttributes[0].orderAttributeGroup.push(additionalAttr.orderAttributeGroup[0]);
            }
        } else {
            schedulingVariables.appointmentResponse.payload.addlOrderAttributes = [];
            schedulingVariables.appointmentResponse.payload.addlOrderAttributes.push(additionalAttr);
        }
    }

    public addOrderAttributeNameAndValue( name, value, group, additionalAttr){
        if(!additionalAttr){
            additionalAttr = {
                "orderAttributeGroup": [{
                    "orderAttributeGroupName": group,
                    "orderAttributeGroupInfo": [{
                        "orderAttributes": []
                      }]
                  }]          
            };
        }

        if(additionalAttr && additionalAttr.orderAttributeGroup){
            additionalAttr.orderAttributeGroup.map((gp)=>{
                if(gp.orderAttributeGroupName === group && gp.orderAttributeGroupInfo && gp.orderAttributeGroupInfo.length > 0 && gp.orderAttributeGroupInfo[0].orderAttributes && Array.isArray(gp.orderAttributeGroupInfo[0].orderAttributes)){
                    gp.orderAttributeGroupInfo[0].orderAttributes.push(
                            {
                                "orderAttributeName": name,
                                "orderAttributeValue": value
                            }
                    );
                }
            });
        }

        return additionalAttr;
    }
}