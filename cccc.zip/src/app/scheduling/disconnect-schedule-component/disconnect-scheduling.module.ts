import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { DisconnectScheduleComponent } from './disconnect.schedule.component';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: DisconnectScheduleComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        SharedModule,
        SharedCommonModule,
        TextMaskModule
    ],
    declarations: [
        DisconnectScheduleComponent,
    ],
    exports: [
        DisconnectScheduleComponent,
    ],
    providers: [       
        SchedulingHelperService              
    ]
})

/**
 * Shared Module - Used to import reusable component's for different modules
 * eg. BreadcrumbComponent and ControlMessagesComponent
 * import shared module in corresponding module and use the component
 */
export class DisconnectSchedulingModule { }
