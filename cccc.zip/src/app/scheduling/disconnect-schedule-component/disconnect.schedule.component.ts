import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { User } from '../../common/models/user.model';
import { AppStore } from '../../common/models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { DisconnectService } from '../../common/service/disconnect.service';
import { SchedulingVariables } from '../../common/models/schedule.shipping.model';
import { AppStateService } from '../../common/service/app-state.service';
import { Logger } from '../../common/logging/default-log.service';
import { APIErrorLists, GenericValues } from '../../common/models/common.model';
import { TextMaskService } from '../../common/service/text-mask.service';
import { DialogComponent } from 'app/common/popup/dialog.component';
import "rxjs/add/operator/catch";
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';

@Component({
    selector: 'disconnect-schedule',
    styleUrls: ['../schedule-component/schedule.component.scss'],
    templateUrl: './disconnect.schedule.component.html'
})

export class DisconnectScheduleComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild('orderDisclosures', { static: false }) public orderDisclosures: DialogComponent;
    public isBillEffectiveDate: boolean = false;;
    private scheduleSubscription: Subscription;
    private schedule: Observable<any>;
    public phoneMask: any;
    private contactNumber = '';
    public dueDate: string;
    public apiResponseError: APIErrorLists;
    private scheduleRe: any;
    public retain: any;
    private userSubscription: any;
    public isReferralRequired: any;
    public appointmentResponse: any;
    public checkBoxChecked = false;
    public finalDateInfo: any;
    public isdateChanged: any;
    public orderRefNumber: string;
    public isChecked = false;
    private isReentrantAdditionalnumberChecked = false;
    private isadditionalNumberChecked = false;
    public contactNumberExists = false;
    public contactNumber2: any
    public existingData: any;
    public billeffectmindate: string;
    public billeffectmaxdate: string;
    public disableCalRef: boolean = false;
    public customizedSubscription: Subscription;
    public currentTN: any;
    public formattedNumber: any;
    public reentrantnumber: any;
    public formattedContactNumber: any;
    public billingType: string = '';
    public hideEffectiveBillDate: boolean = false;
    public disconnectFlow: boolean;
    public billeffectiveDateInfo: any;
    public billEffectiveMaxDate: any;
    public prepaidFinalPayment: any;
    public ebDate: any;
    public finalDD: any;
    public schedulingVariables: SchedulingVariables;
    public errorMsg: any;

    constructor(
        private logger: Logger,
        private appStateService: AppStateService,
        private disconnectService: DisconnectService,
        private store: Store<AppStore>,
        private textMask: TextMaskService,
        public schedulingHelperService: SchedulingHelperService
    ) {
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.appStateService.setLocationURLs();
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);
        this.schedule = store.select('appointment');
        if (this.schedule && this.schedule !== null && this.schedule !== undefined) {
            this.scheduleSubscription = this.schedule.subscribe((data) => {
                this.appointmentResponse = data;
                let user = <Observable<User>>store.select('user');
                let retainDisconnectResume = false;
                this.userSubscription = user.subscribe(
                    (usr) => {
                        if (usr.previousUrl !== '/existing-products' && usr.previousUrl !== '/offer-change') {
                            this.schedulingVariables.isReEntrant = true;
                            this.schedulingVariables.taskId = usr.taskId;
                            let retainVal = <Observable<any>>store.select('retain');
                            let retSubscribe = retainVal.subscribe(
                                retVal => {
                                    this.retain = retVal;
                                    this.scheduleRe = retVal.account;
                                    if (retVal && retVal.retainscheduling && retVal.retainscheduling !== undefined && retVal.retainscheduling.payload && retVal.retainscheduling.payload !== undefined) {
                                        this.isReferralRequired = retVal.retainscheduling.payload.referralRequired;
                                        this.prepaidFinalPayment = retVal.retainscheduling.payload.finalPaymentDate;
                                        this.billEffectiveMaxDate = retVal.retainscheduling.payload.billeffectiveDateInfo.maxBedDate;
                                    } else {
                                        this.fromHold(store);
                                    }
                                    if (this.scheduleRe) {
                                        data = this.scheduleRe;
                                    }
                                }
                            )
                            if (retSubscribe !== undefined) retSubscribe.unsubscribe();
                        }
                        else {
                            this.schedulingVariables.taskId = usr.taskId;
                            let reentrant = this.disconnectService.isSchedulingReEntrant;
                            if (reentrant) {
                                this.schedulingVariables.isReEntrant = true;
                                this.schedulingVariables.taskId = usr.taskId;
                            }
                            else {
                                this.schedulingVariables.isReEntrant = false;
                            }
                            this.fromHold(store);
                            let retain: any = this.store.select('retain');
                            retain.subscribe((data) => {
                                retainDisconnectResume = data.reentrant;
                                if (data && data.retainscheduling) {
                                    this.schedulingVariables.isReEntrant = data.reentrantscheduling;
                                    if(this.schedulingVariables.isReEntrant) { this.schedulingVariables.taskId = usr.taskId; }
                                    if (data.retainscheduling.payload &&
                                        data.retainscheduling.payload.referralRequired) {
                                        this.isReferralRequired = data.retainscheduling.payload.referralRequired;
                                    }
                                }
                            })
                        }
                        if (usr.phoneNumber !== undefined && usr.phoneNumber !== '') {
                            this.contactNumber = usr.phoneNumber;
                        }
                        if (usr && usr.orderRefNumber) {
                            this.orderRefNumber = usr.orderRefNumber;
                        }
                    });

                if (data && data !== null && data !== undefined
                    && data.payload &&
                    data.payload !== null &&
                    data.payload !== undefined) {
                    this.schedulingVariables.appointmentResponse = data;
                    this.schedulingVariables.orderRefNumber = data.orderRefNumber
                    if (retainDisconnectResume) {
                        this.schedulingVariables.appointmentResponse.taskId = this.schedulingVariables.taskId;
                    }
                    if (data !== undefined && data !== null && data.reservedCbr) {
                        this.contactNumber = data.reservedCbr;
                    }
                    if (this.schedulingVariables.isReEntrant) {
                        this.schedulingVariables.nextPaymentDate = this.prepaidFinalPayment;
                    } else {
                        this.schedulingVariables.nextPaymentDate =  data.payload.finalPaymentDate;
                    }
                    data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.map(i => { if (i && i.orderAttributeGroup) { i.orderAttributeGroup.map(k => { if (k.orderAttributeGroupName === "interceptlOptionInd") { var ls = k.orderAttributeGroupInfo; ls.map(j => { if (j) { j.orderAttributes.map(l => { if (l.orderAttributeValue) { this.disableCalRef = true } }) } }) } }) } });
                    this.finalDateInfo = data.payload.dueDate.finalDueDate;
                    this.isdateChanged = this.finalDateInfo;
                    this.dueDate = data.payload.dueDate.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                    if (data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.minBedDate) {
                        this.billeffectmindate = data.payload.billeffectiveDateInfo.minBedDate;
                        this.isBillEffectiveDate = true;
                    } else if (this.appointmentResponse.payload.billeffectiveDateInfo && this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate) {
                        if (this.schedulingVariables.isReEntrant && this.appointmentResponse.payload.billeffectiveDateInfo && this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate !== undefined && (this.appointmentResponse.payload.billeffectiveDateInfo.maxBedDate === this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate)) {
                            this.billeffectmindate = this.appointmentResponse.billeffectiveDateInfo.minBedDate;
                            this.isBillEffectiveDate = true;
                        } else if (this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate !== undefined) {
                            this.billeffectmindate = this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate;
                            this.isBillEffectiveDate = true;
                        }
                    }
                    if (data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.maxBedDate) {
                        this.billeffectmaxdate = data.payload.billeffectiveDateInfo.maxBedDate;
                        this.isBillEffectiveDate = true;
                    } else if (this.appointmentResponse.payload.billeffectiveDateInfo && this.appointmentResponse.payload.billeffectiveDateInfo.maxBedDate) {
                        if (this.schedulingVariables.isReEntrant && (this.appointmentResponse.payload.billeffectiveDateInfo.maxBedDate === this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate)) {
                            this.billeffectmaxdate = this.appointmentResponse.billeffectiveDateInfo.maxBedDate;
                            this.isBillEffectiveDate = true;
                        } else {
                            this.billeffectmaxdate = this.appointmentResponse.payload.billeffectiveDateInfo.maxBedDate;
                            this.isBillEffectiveDate = true;
                        }
                    }
                    if ((data.payload.billeffectiveDateInfo !== null && data.payload.billeffectiveDateInfo.minBedDate && data.payload.billeffectiveDateInfo.maxBedDate &&
                        (data.payload.billeffectiveDateInfo.minBedDate === data.payload.billeffectiveDateInfo.maxBedDate)) ||
                        (this.schedulingVariables.isReEntrant && this.appointmentResponse.billeffectiveDateInfo && this.appointmentResponse.billeffectiveDateInfo !== null &&
                            this.appointmentResponse.billeffectiveDateInfo.minBedDate && this.appointmentResponse.billeffectiveDateInfo.maxBedDate &&
                            (this.appointmentResponse.billeffectiveDateInfo.minBedDate === this.appointmentResponse.billeffectiveDateInfo.maxBedDate))) {
                        this.hideEffectiveBillDate = true;
                        if (this.schedulingVariables.isReEntrant) {
                            this.schedulingVariables.effectiveBillDate = this.billEffectiveMaxDate + "T00:00:00.000Z";;
                        } else {
                            this.schedulingVariables.effectiveBillDate = data.payload.billeffectiveDateInfo.maxBedDate + "T00:00:00.000Z";;
                        }
                        var d = new Date(this.schedulingVariables.effectiveBillDate);
                        var dt = new Date(data.payload.dueDate.finalDueDate.substr(0, 10));
                        this.ebDate = d.getDate();
                        this.finalDD = dt.getDate();
                        if (this.finalDD > this.ebDate) {
                            d.setMonth(dt.getMonth() + 1);
                            if (dt.getMonth() < 11) {
                                d.setFullYear(dt.getFullYear());
                            } else {
                                d.setFullYear(d.getFullYear());
                            }
                            this.schedulingVariables.effectiveBillDate = d.toISOString().slice(0, 10);
                            this.billeffectmindate = d.toISOString().slice(0, 10);
                            this.billeffectmaxdate = d.toISOString().slice(0, 10);
                        } else {
                            dt.setDate(this.ebDate);
                            this.schedulingVariables.effectiveBillDate = dt.toISOString().slice(0, 10);
                            this.billeffectmindate = dt.toISOString().slice(0, 10);
                            this.billeffectmaxdate = dt.toISOString().slice(0, 10);
                        }
                    } else {
                        this.hideEffectiveBillDate = false;
                        this.schedulingVariables.effectiveBillDate = data.payload.dueDate.effectiveBillDate && data.payload.dueDate.effectiveBillDate.trim().substr(0, 10).replace(/-/g, '\/');
                    }
                    this.schedulingHelperService.cbrMethod(this.contactNumber.trim(), this.schedulingVariables);
                    let existingProd = <Observable<any>>this.store.select('existingProducts');
                    existingProd.subscribe((data) => {
                        this.schedulingVariables.orderFlow = data.orderFlow.flow;
                        if (data.orderFlow.flow === 'Disconnect') {
                            this.disconnectFlow = true;
                        } else {
                            this.disconnectFlow = false;
                        }
                        if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                            && data.existingProductsAndServices[0].accountInfo) {
                            if (data.existingProductsAndServices[0].accountInfo.billingType === 'PREPAID') this.billingType = 'PREPAID';
                            if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                                this.contactNumberExists = true;
                            }
                        }
                    })
                    if (!this.schedulingVariables.isNotFromContinue) {
                        if (data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.length > 0) {
                            let additionalAttributes = data.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes;
                            if (!this.schedulingVariables.isReEntrant && additionalAttributes.length > 0 && additionalAttributes[0].orderAttributeName === "orderLevelCBRNumber") {
                                this.schedulingHelperService.cbrMethod(additionalAttributes[0].orderAttributeValue, this.schedulingVariables);
                            }
                            if (this.schedulingVariables.isReEntrant && additionalAttributes.length > 0 && additionalAttributes[0].orderAttributeName === "orderLevelCBRNumber") {
                                this.formattedNumber = additionalAttributes[0].orderAttributeValue;
                                this.reentrantnumber = this.formattedNumber;
                            }
                            if (this.schedulingVariables.isReEntrant && additionalAttributes.length > 1 && additionalAttributes[1].orderAttributeName === "storeAsAccountLevelCBR2") {
                                this.isChecked = true;
                                this.schedulingHelperService.cbrMethod(additionalAttributes[0].orderAttributeValue, this.schedulingVariables);
                                this.isReentrantAdditionalnumberChecked = true;
                                this.isadditionalNumberChecked = additionalAttributes[1].orderAttributeValue === true ? true : false;
                                this.schedulingVariables.cbrForm.controls.additionalNumber.reset();
                                this.schedulingVariables.cbrForm.controls.additionalNumber.setValue(true);
                            }
                        }
                    }
                }
            });
        }
    }
    private handleEffectiveBillDate(dd) {
        if (this.schedulingVariables.isReEntrant) {
            this.schedulingVariables.effectiveBillDate = this.billEffectiveMaxDate;
        } else {
            this.schedulingVariables.effectiveBillDate = this.appointmentResponse.payload.billeffectiveDateInfo.maxBedDate;
        }
        var d = new Date(this.schedulingVariables.effectiveBillDate);
        var dt = new Date(this.appointmentResponse.payload.dueDate.finalDueDate);
        this.ebDate = d.getDate();
        this.finalDD = dt.getDate();
        if (this.finalDD > this.ebDate) {
            d.setMonth(dt.getMonth() + 1);
            if (dt.getMonth() < 11) {
                d.setFullYear(dt.getFullYear());
            } else {
                d.setFullYear(d.getFullYear());
            }
            this.schedulingVariables.effectiveBillDate = d.toISOString().slice(0, 10);
            this.billeffectmindate = d.toISOString().slice(0, 10);
            this.billeffectmaxdate = d.toISOString().slice(0, 10);
        } else {
            dt.setDate(this.ebDate);
            this.schedulingVariables.effectiveBillDate = dt.toISOString().slice(0, 10);
            this.billeffectmindate = dt.toISOString().slice(0, 10);
            this.billeffectmaxdate = dt.toISOString().slice(0, 10);
        }
        this.billeffectiveDateInfo = {
            minBedDate: this.billeffectmindate,
            maxBedDate: this.billeffectmaxdate
        }
        this.store.dispatch({ type: 'BILL_EFFECTIVE_DATE_INFO', payload: this.billeffectiveDateInfo });
    }
    private fromHold(store: Store<AppStore>) {
        let existingProducts = <Observable<any>>store.select('existingProducts');
        let existingProductsSubscription = existingProducts.subscribe((data) => {
            if (data && data.orderFlow && data.orderFlow.flow === 'Disconnect' && data.orderFlow.type === 'fromHold') {
                this.schedulingVariables.isReEntrant = true;
                let pendingSummaryObservable = <Observable<any>>store.select('pending');
                let pendingSummarySubscription = pendingSummaryObservable.subscribe((pendingData) => {
                    if (pendingData && pendingData.orderDocument && pendingData.orderDocument.customerOrderItems && pendingData.orderDocument.customerOrderItems.length > 0) {
                        pendingData.orderDocument.customerOrderItems.map(item => {
                            if (item.offerCategory === GenericValues.cHP && item.offerType === 'VAS_INTERCEPT') {
                                this.isReferralRequired = 'yes';
                                this.schedulingVariables.referralRequest = {
                                    payload: {
                                        cart: pendingData.orderDocument.customerOrderItems
                                    }
                                };
                                this.retain = {
                                    account: {
                                        payload: {
                                            productConfiguration: pendingData.orderDocument.productConfiguration
                                        }
                                    }
                                };
                            }
                        });
                    }
                });
                if (pendingSummarySubscription !== undefined)
                    pendingSummarySubscription.unsubscribe();
                this.schedulingVariables.taskId = this.appointmentResponse.taskId;
            }
        });
        if (existingProductsSubscription !== undefined)
            existingProductsSubscription.unsubscribe();
    }

    public ngOnInit() {
        this.logger.metrics('SchedulingDisconnectPage');
        this.schedulingVariables.isNotFromContinue = false;
        window.scroll(0, 0);
        this.schedulingVariables.currentComponet = "disconnect.schedule.component.ts";
        let existingProd = <Observable<any>>this.store.select('existingProducts');
        existingProd.subscribe((data) => {
            this.existingData = data;
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== '') {
                    this.contactNumberExists = true;
                }
            }
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].accountInfo) {
                if (data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber && data.existingProductsAndServices[0].accountInfo.contact.contactNumber !== '') {
                    this.contactNumber2 = data.existingProductsAndServices[0].accountInfo.contact.contactNumber;
                }
            }
            if (data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0]
                && data.existingProductsAndServices[0].serviceAddress && data.existingProductsAndServices[0].serviceAddress.locationAttributes
                && data.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider === 'CENTURYLINK') {
                this.schedulingVariables.isCenturyLink = true;
            }
        })
        this.schedulingHelperService.cbrMethod(this.contactNumber.trim(), this.schedulingVariables);
        this.schedulingVariables.cbrForm && this.schedulingVariables.cbrForm.controls.contactNumber.valueChanges.subscribe(value => {
            if (!this.schedulingVariables.isReEntrant) {
                this.isadditionalNumberChecked = false;
                this.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                this.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                if (this.formattedNumber !== this.formattedContactNumber) {
                    if (this.schedulingVariables.cbrForm && this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                        this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                    }
                }
            } else {
                if (this.reentrantnumber === value.toString().replace(/[^A-Z0-9]/ig, "")) {
                    this.isChecked = this.isReentrantAdditionalnumberChecked;
                    if (this.isReentrantAdditionalnumberChecked) {
                        this.formattedNumber = '';
                    }
                    this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(this.isadditionalNumberChecked);
                } else {
                    this.isadditionalNumberChecked = false;
                    this.isChecked = true;
                    this.formattedNumber = value.toString().replace(/[^A-Z0-9]/ig, "");
                    this.formattedContactNumber = this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                    if (this.formattedNumber !== this.formattedContactNumber) {
                        if (this.schedulingVariables.cbrForm && this.schedulingVariables.cbrForm.controls.additionalNumber.value === true) {
                            this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                        }
                    }
                }
            }
        });
        let customize = <Observable<any>>this.store.select('customize');
        this.customizedSubscription = customize.subscribe((data) => {
            if (data && data.payload && data.payload !== undefined && data.payload.reservedTN !== undefined && data.payload.reservedTN.length !== 0) {
                this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
            }
        });
    }
    public ngAfterViewInit() {
        this.schedulingVariables.orderDisclosures = this.orderDisclosures;
    }
    public ngOnDestroy() {
        this.userSubscription.unsubscribe();
        this.scheduleSubscription.unsubscribe();
    }
    public handleDueDateUpdated(event) {
        this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = event;
        this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        this.isdateChanged = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        this.finalDateInfo = this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate;
        if (this.appointmentResponse.payload.billeffectiveDateInfo !== null && (this.appointmentResponse.payload.billeffectiveDateInfo.maxBedDate === this.appointmentResponse.payload.billeffectiveDateInfo.minBedDate)) {
            this.handleEffectiveBillDate(this.schedulingVariables.appointmentResponse.payload.dueDate.finalDueDate);
        }
    }

    public referralResp(event) {
        this.schedulingVariables.referralRequest = event;
    }
    public additionalNumberChange(data) {
        this.schedulingVariables.cbrForm && this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(data.currentTarget.checked);
        this.checkBoxChecked = data.currentTarget.checked;
    }
}