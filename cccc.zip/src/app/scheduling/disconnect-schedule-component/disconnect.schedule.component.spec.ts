import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { SchedulingService } from '../../common/service/scheduling.service';
import { BlueMarbleService } from '../../common/service/bm.service';
import { AuthService } from '../../common/service/auth.service';
import {
  Appointment, AppointmentPayload,
  AppointmentNotes, AvailableAppointment
} from '../../common/models/appointment.model';
import { userReducer } from '../../common/reducers/user.reducer';
import { User } from '../../common/models/user.model';
import { Observable } from 'rxjs/Observable';
import { Store, StoreModule } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { DatePipe, Location } from '@angular/common';
import { AppStateService } from '../../common/service/app-state.service';
import { ScheduleShippingConfirmation } from '../../common/models/schedule.shipping.model';
import { Logger } from '../../common/logging/default-log.service';
import { ContactInfo, EnterpriseAddress } from '../../common/models/cart.model';
import {
  GenericValues, serverErrorMessages, APIErrorLists, ErrorResponse
} from '../../common/models/common.model';
import { AppointmentShipping, ShippingAddres } from '../../common/models/schedule-shipping.model';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Validations } from '../../common/validations/validations';
import { SystemErrorService } from '../../common/service/system-error.service';
import { AddressService } from '../../common/service/address.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { State } from '../../common/models/state.model';
import { MockServer } from '../../MockServer.test';
import { Http, BaseRequestOptions, ConnectionBackend, RequestOptions } from '@angular/http';
import { inject, TestBed, fakeAsync } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { Response, ResponseOptions, RequestMethod } from '@angular/http';
import { AppConfig } from '../../common/service/app-config.service';
import { DisconnectScheduleComponent } from './disconnect.schedule.component';
import { DisconnectService } from '../../common/service/disconnect.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { HttpClient } from '@angular/common/http';
//disabling this component - need to redesign using TestBed
xdescribe('Disconnect Schedule Component', () => {
  let mockRouter: any = {
    navigate: jasmine.createSpy('navigate')
  };
  
  let req = {
    taskName: "Appointments"
  };
  const mockRedux: any = {
    dispatch(action) { },
    configureStore() { },
    select(reducer) {
      
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  }
  class mockAuthService {
    public getJWTToken() {
    }
    public setRequestOptions() {
    }
  }
  let defaultOptions, authService, component, service, mockServer, addressService, disconnectService, ctlHelperService;
  beforeEach(() => {
    let location: Location;
    ctlHelperService = new CTLHelperService();
    mockServer = new MockServer();
    defaultOptions = new BaseRequestOptions();
    let backend = new MockBackend();
    let httpHandler;
    let http = new HttpClient(httpHandler);
    authService = new mockAuthService();
    let appConfig = new AppConfig(http);
    let store: Store<AppStore>;
    let props: any;
    let bm = new BlueMarbleService(http, authService, props);
    let fb = new FormBuilder();
    service = new SchedulingService(bm, mockRedux);
    let appstr = new AppStateService(mockRedux, mockRouter);
    let logger = new Logger();
    let textMask= new TextMaskService();
    let countryStateService = new CountryStateService();
    disconnectService = new DisconnectService(mockRedux, bm);
    addressService = new AddressService(bm, countryStateService, mockRedux);
    let systemErrorService = new SystemErrorService(logger, mockRedux, this.router, ctlHelperService);

    component = new DisconnectScheduleComponent(logger,appstr, disconnectService,
      mockRedux, textMask, service);

    TestBed.configureTestingModule({

      providers: [
        BaseRequestOptions,
        MockBackend,
        {
          provide: AuthService, useClass: class { AuthService }
        },
        {
          provide: HttpClient,
          useFactory: function (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) {
            return new HttpClient(httpHandler);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: Router,
          useValue: mockRouter
        },

        AuthService, SchedulingService, BlueMarbleService, AppStateService, Logger, StoreModule.forRoot({ user: userReducer })
      ]
    })
  });

  xit('cancelClick should have been called...', () => {
    component.handleBackToExistingProducts();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/existing-products']);
  });

  xit('handleBackToExistingProducts should have been called...', () => {
    component.handleBackToExistingProducts();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/existing-products']);
  });

  xit('ngOnInit() should have been called...', () => {
    expect(component.ngOnInit()).toHaveBeenCalled;
  });

  xit('ngOnDestroy() should have been called...', () => {
    expect(component.ngOnDestroy()).toHaveBeenCalled;
  });

  xit('handleDueDateUpdated() should have been called...', () => {
    component.handleDueDateUpdated('2018-02-14');
    expect(component.disconnectSchedulingResponse.payload.dueDate.finalDueDate).toBe('2018-02-14T00:00:00.000Z');
  });

  xit('cancelOrder() should have been called...', () => {
    component.cancelOrder();
    expect(component.isDisconnectSchedulingSelected).toBe(true);
    expect(component.isDisconnectandSchedulingSelected).toBe(false);
  });

  xit('discardDisconnShcedule() should have been called...', () => {
    component.discardDisconnShcedule('');
    expect(component.isShowDisconnectFlowScheduleButtons).toBe(false);
  });

  xit('handleEffectiveBillDateUpdated() should have been called...', () => {
    component.handleEffectiveBillDateUpdated('2018-02-14');
    expect(component.disconnectSchedulingResponse.payload.dueDate.effectiveBillDate).toBe('2018-02-14T00:00:00.000Z');
  });

  xit('checking Schedule Appointment Service Call...', () => {
    let req = {
      taskName: 'Appointment Scheduling'
    };
    let data = mockServer.getResponseForRequest('submitTask', req);
    let spy = spyOn(disconnectService, 'submitInformation').and.callFake(() => {
      return Observable.of(data);
    })
    component.continueClick();
    expect(spy).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/disconnect-account']);
  });
});
