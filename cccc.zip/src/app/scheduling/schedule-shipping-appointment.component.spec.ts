import {TestBed, async, ComponentFixture, tick, fakeAsync} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ScheduleShippingAppointmentComponent } from './schedule-shipping-appointment.component';
import { MockServer } from '../MockServer.test';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStateService } from '../common/service/app-state.service';
import { CountryStateService } from '../common/service/country-state.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { PropertiesHelperService } from '../common/service/propertiesHelper.service';
import { BlueMarbleService } from '../common/service/bm.service';
import { SchedulingHelperService } from './service/scheduleHelper.service';
import { SchedulingService } from '../common/service/scheduling.service';
import { MockAppStateService, MockSystemErrorService, MockHelperService, MockLogger, MockRouter, 
  MockBlueMarbleService, MockProductService, MockAddressService, MockCountryStateService, MockTextMaskService, MockPropertiesHelperService, MockReviewOrderService, MockDisclosuresService, MockDisconnectService, MockPendingOrderService, MockAccountService, MockDirectvService, MOCK_ROUTES, MockSchedulingService} from '../common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import "rxjs/add/observable/of"; 
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskService } from '../common/service/text-mask.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { AccountService } from 'app/common/service/account.service';
import { DirectvService } from 'app/common/service/directv.services';
import { By } from '@angular/platform-browser';
import { TextMaskModule } from 'angular2-text-mask';
import { of } from 'rxjs';
import { SchedulingModule } from './scheduling.module';

describe('schedule Shipping Appointment Component', () => {
  let component: ScheduleShippingAppointmentComponent;
  let fixture: ComponentFixture<ScheduleShippingAppointmentComponent>;
  let mockServer= new MockServer();
  
  const imports = [
    SchedulingModule,
    RouterTestingModule
  ]

  let mockRouter: any = {
    navigate: jasmine.createSpy('navigate')
  };

  const mockRedux : any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
      return of(
        mockServer.getMockStore("NI_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return of(null);
    }
  }

  class MockAppStateService {
    setLocationURLs() {}
    getState() {
      return of(mockServer.getMockStore('NI_HSI_TILL_ORDER_CONFIRMATION_PAGE'))
    }
  }

  const logger = { provide: Logger, useClass: MockLogger};
  const store = { provide: Store, useValue: mockRedux};
  const schedulingHelperService =  SchedulingHelperService;
  const appStateService = { provide: AppStateService, useClass: MockAppStateService}; 
  const countryStateService = { provide: CountryStateService, useClass: MockCountryStateService };
  const textMaskService = { provide: TextMaskService, useClass:MockTextMaskService};
  const helperService = { provide: HelperService, useClass:MockHelperService};
  const propertiesHelperService = { provide: PropertiesHelperService, useClass:MockPropertiesHelperService};
  const schedulingService = { provide: SchedulingService, useClass:MockSchedulingService};;
  const cTLHelperService = CTLHelperService
  
  // dialog component providers list
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService }
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const directvService = {provide: DirectvService, useClass: MockDirectvService };

  const providers = [
    logger, store, schedulingHelperService, appStateService,
    countryStateService, textMaskService, helperService, propertiesHelperService,
    schedulingService, cTLHelperService, reviewOrderService, disclosuresService,
    addressService, blueMarbleService,  disconnectService, systemErrorService, 
    pendingOrderService, accountService, productService, directvService
  ];
 
  const baseConfig = {
    imports: imports,
    providers: providers
  }

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleShippingAppointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create schedulling shipping appointment component', () => {
    expect(component).toBeTruthy();
  });

  it('ngOninit() should have been called...', () => {
    const returnVal = component.ngOnInit();
    expect(returnVal).toBeUndefined();
  });

  it('ngOnDestroy() should have been called...', () => {
    const returnVal = component.ngOnDestroy();
    expect(returnVal).toBeUndefined();
  });

  xit('cancelClick should have been called...', () => {
    component.cancelClick();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/home']);
  });
  
  xit('customerRequestedDueDateUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.customerRequestedDueDateUpdated('2018-02-14', schedulevar);
    expect(schedulevar.appointmentResponse.payload.dueDate.requestedDueDate).toBeDefined();
    expect(schedulevar.appointmentResponse.payload.dueDate.requestedDueDate).toBe('2018-02-14T00:00:00.000Z');
  });

  it('effectiveBillDateUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.effectiveBillDateUpdated('2018-02-14', schedulevar);
    expect(schedulevar.appointmentResponse.payload.dueDate.effectiveBillDate).toBeDefined();
    expect(schedulevar.appointmentResponse.payload.dueDate.effectiveBillDate).toBe('2018-02-14', );
  });

  xit('dueDateUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.dueDateUpdated('2018-02-14', schedulevar);
    expect(schedulevar.appointmentResponse.payload.dueDate.finalDueDate).toBeDefined();
    expect(schedulevar.appointmentResponse.payload.dueDate.finalDueDate).toBe('2018-02-14T00:00:00.000Z');
  });

  xit('getStates() should have been called...', () => {
    (component as any).getStates('');
    expect(component.selectedState.stateName).toBe('Select State');
  });

  it('reserveAppointment() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.schedulingHelperService.reserveAppointment(schedulevar);
    expect(schedulevar.showReserveItButton).toBe(false);
  })

  it('revertShippingAddress() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    component.revertShippingAddress();
    expect(schedulevar.yellowAddresses.length).toBe(0);
  });

  xit('handleAppointmentUpdated() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    let event = {
      appointmentId: "ZKLV0GFQ",
      timeSlot: {
        startDateTime: "2018-03-05T08:00:00.000Z",
        endDateTime: "2018-03-05T17:00:00.000Z"
      }
    };
    component.schedulingHelperService.handleAppointmentUpdated(event, schedulevar);
    expect(schedulevar.reservedAppointment).toBe(event as any);
  });

  it('useSericeAddress() should have been called...', () => {
    let schedulevar = component && component.schedulingVariables;
    expect(schedulevar.shippingAddressObject).toBeDefined();
    schedulevar.showShippingAddress = false;
    component.schedulingHelperService.useServiceAddress(schedulevar);
    expect(schedulevar.isRedAddressReturned).toBe(false);
  });
  
  xit('checking Schedule Appointment Service Call...', () => {
    let schedulevar = component && component.schedulingVariables;
    let req = {
      taskName : 'Appointment Scheduling'
    };
    let data = mockServer.getResponseForRequest('submitTask',req);
    let service = TestBed.get(Store);
    spyOn(service, 'scheduleAppointment').and.callFake(() => {
      return Observable.of(data);
    })
    component.schedulingHelperService.continueClick(schedulevar);
    expect(mockRedux.scheduleAppointment).toHaveBeenCalled();
    expect(MockRouter).toHaveBeenCalledWith(['/account']);
    expect(MockRouter).toHaveBeenCalledWith(['/co-review-order']);
  });
 
  xit('isWaiveOtcAllowed should be as true', () => { 
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement;
    schedulevar.isWaiveOtcAllowed = true;
    schedulevar.eligibleCharges = 215;
    expect(schedulevar.isWaiveOtcAllowed).toBeTruthy;
    expect(component.billingType).not.toBe('PREPAID');
    expect(schedulevar.eligibleCharges).toBeDefined;
    expect(schedulevar.eligibleCharges).toBeGreaterThan(0);
    expect(fixture.debugElement.query(By.css('.waiveOtcBlock'))).toBeTruthy();
    const boldText = fixture.debugElement.query(By.css('.waiveOtcBlock b a')).nativeElement;
    expect(boldText.textContent).toContain('Waive one-time charges');
    const eligibleCharges = schedulevar.eligibleCharges + " eligible charges";
    expect(element.querySelector('.waiveOtcBlock div')).toBeDefined(eligibleCharges);
  });

  xit('When totalWaivedOtc value is 0', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    expect(element.querySelector('.waiveOtcBlock div.nonWaivedCharge').textContent).toContain('None waived');
  })

  it('should hide contents if isWaiveOtcAllowed is false', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.isWaiveOtcAllowed = false;
    expect(schedulevar.isWaiveOtcAllowed).toBeFalsy;
    expect(component.billingType).not.toBe('PREPAID');
  });

  xit("WaiveOTC link should be clickable", () => {
    const element = fixture.debugElement.nativeElement;
    fixture.detectChanges();
    expect(element.querySelector('.waiveOtcBlock a').click()).toBeTruthy;
  });

  it("should assign prepaidPaymentDone to true", () => {
    component.billingType = 'PREPAID';
    expect(component.prepaidPaymentDone).toBeFalsy();
  });
});