import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentNotes, AvailableAppointment } from '../../common/models/appointment.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../../common/service/app-state.service';
import { SchedulingVariables } from '../../common/models/schedule.shipping.model';
import { Logger } from '../../common/logging/default-log.service';
import { ShippingAddres } from '../../common/models/move.schedule';
import { AppointmentShipping } from 'app/common/models/schedule-shipping.model';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Validations } from '../../common/validations/validations';
import { User } from '../../common/models/user.model';
import { TextMaskService } from '../../common/service/text-mask.service';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import "rxjs/add/operator/catch";
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'billing-schedule-appt-ship',
    styleUrls: ['../schedule-component/schedule.component.scss'],
    templateUrl: './billing-schedule-shipping-appointment.component.html'
})

export class BillingScheduleShippingAppointmentComponent implements OnInit, OnDestroy, AfterViewInit {     
    public isChecked=false;
    private isReentrantAdditionalnumberChecked=false;
    private isadditionalNumberChecked=false;
    public phoneMask: any;
    private contactNumber ='';         
    public changeEffectiveBillAddress: boolean = false;
    public availableAppointment: AvailableAppointment[];    
    private appointment: Observable<AppointmentShipping>;
    private appointmentSubscription: Subscription;
    public appointmentNotes: AppointmentNotes;        
    public reservedAppointment: AvailableAppointment;    
    private shippingAddressObject: ShippingAddres;     
    public myForm: FormGroup; 
    public taskId: string;
    private scheduleRe: any;
    public currentPath: boolean = false;
    public existingObservable: Observable<any>;        
    public isDtvOpus: boolean;
    public billingRecordsFlow: boolean = true;
    public billeffectmindate:string;
    public billeffectmaxdate: string;
    public isBillEffectiveDate: boolean = false;
    public contactNumberExists=false;
    public contactNumber2:any;
    public existingData:any;
    private retainReservedAppointment;
    private previousUrl;
    public cartSubscription: Subscription;
    public customizedSubscription: Subscription;
    public cartObservable: Observable<any>;
    public schedulingVariables: SchedulingVariables;
    public currentTN:any;    
    public reentrantnumber:any;    
    @ViewChild('orderDisclosures', { static: false,}) public orderDisclosures: DialogComponent;
    public userObservable: any;
    public userSubscription: any;
    public billingType: string = '';
    public errorMsg: any;
    public waiveOtc: any[] = [{
        charge: 'Intial Jack charge',
        amount: 99,
        waived: false
    }, {
        charge: 'Phone activation charge',
        amount: 50,
        waived: false
    }];
    public eligibleCharges = 0;
    public waivedOtc = 0;
    public ngOnDestroy$ = new Subject();

    constructor(
        private logger: Logger,
        public schedulingHelperService: SchedulingHelperService,
        private router: Router,
        private store: Store<AppStore>,
        private fb: FormBuilder,
        private appStateService: AppStateService,
        private textMask: TextMaskService,
    ) {
        this.appStateService.setLocationURLs();
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.existingObservable = <Observable<any>>store.select('existingProducts');
        this.existingObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            if (data && data.orderFlow && data.orderFlow.type === 'pending') {
                this.schedulingVariables.isPendingFlow = true;
                this.schedulingVariables.orderFlow = data.orderFlow.flow;
            } else {
                if(data && data.orderFlow && data.orderFlow.flow)
                this.schedulingVariables.orderFlow = data.orderFlow.flow;
            }
        });
        this.userObservable = <Observable<User>>store.select('user');
        this.waiveOtc.forEach(otc => {
            this.eligibleCharges += otc.amount;
        });

        this.appointment = store.select('appointment');
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointmentSubscription = this.appointment
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                if(data && data.payload && data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.minBedDate) {
                    this.billeffectmindate = data.payload.billeffectiveDateInfo.minBedDate;
                    this.isBillEffectiveDate = true;
                }
                if(data && data.payload && data.payload.billeffectiveDateInfo && data.payload.billeffectiveDateInfo.maxBedDate) {
                    this.billeffectmaxdate = data.payload.billeffectiveDateInfo.maxBedDate;
                    this.isBillEffectiveDate = true;
                }
                let user = <Observable<User>>store.select('user');
                let userSubscription = user
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe(
                    (usr) => {
                        this.billingType = usr.prepaidFlag;
                        this.isDtvOpus = usr.isDtvOpus;
                        this.previousUrl = usr.previousUrl;
                        if (usr.currentUrl === '/billing-schedule-appt-ship') {
                            this.schedulingVariables.currentComponet = "billing-schedule-shipping-appointment.component.ts";
                            this.currentPath = true;
                        }
                        if (usr.previousUrl !== '/customize-services') {
                            this.schedulingVariables.isReEntrant = true;
                            this.taskId = usr.taskId;
                            let retainVal = <Observable<any>>store.select('retain');
                            retainVal
                            .pipe(takeUntil(this.ngOnDestroy$))
                            .subscribe(
                                (retVal => {
                                    this.scheduleRe = retVal.account;
                                    if (this.scheduleRe && this.scheduleRe !== null && this.scheduleRe !== undefined) {
                                        data = this.scheduleRe;
                                    }
                                    if (retVal && retVal.retainReservedAppointment) {
                                        this.retainReservedAppointment = retVal.retainReservedAppointment;
                                    }
                                })
                            )
                        }
                        if (this.isDtvOpus) {
                            if (usr.dtvOpus.taskName === 'yes') {
                                this.schedulingVariables.dtvYes = true;
                            }
                        }
                        else {
                            if (usr.dtvQuestionForm.taskName === 'yes') {
                                this.schedulingVariables.dtvYes = true;
                            }
                        }
                        if(usr.phoneNumber !== undefined && usr.phoneNumber !== '')
                        {
                        this.contactNumber= usr.phoneNumber;
                        }
                        if (usr && usr.orderRefNumber) {
                            this.schedulingVariables.orderRefNumber = usr.orderRefNumber;
                        }
                    });
                userSubscription.unsubscribe();
                // if(this.schedulingVariables.isReEntrant && item.orderAttributeName=="storeAsAccountLevelCBR2")
                if(data && data.payload && data.payload.addlOrderAttributes && data.payload.addlOrderAttributes.length > 0){
                let additionalAttributes=data.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes;
                if(this.schedulingVariables.isReEntrant&&additionalAttributes.length>0 && additionalAttributes[0].orderAttributeName === "orderLevelCBRNumber"){
                     this.schedulingVariables.formattedNumber=additionalAttributes[0].orderAttributeValue;
                     this.reentrantnumber=this.schedulingVariables.formattedNumber;
                 }
                if(this.schedulingVariables.isReEntrant&&additionalAttributes.length>1 && additionalAttributes[1].orderAttributeName === "storeAsAccountLevelCBR2"){
                     this.isChecked=true;
                     this.schedulingHelperService.cbrMethod(data.reservedCbr,this.schedulingVariables);
                     this.isReentrantAdditionalnumberChecked=true;
                     this.isadditionalNumberChecked=additionalAttributes[1].orderAttributeValue === "true"?true:false;
                     this.schedulingVariables.cbrForm.controls.additionalNumber.reset();
                     this.schedulingVariables.cbrForm.controls.additionalNumber.setValue(true);
                 }
            }
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    this.schedulingVariables.appointmentResponse = data;
                    if(data !== undefined && data !== null  && data.reservedCbr )
                    {
                    this.contactNumber= data.reservedCbr;
                  
                    }
                    else if (this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes 
                        && Array.isArray(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
                            this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                            if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0 ) {
                                item.orderAttributeGroup.forEach((item: any) => {
                                    if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0 ) {
                                        item.orderAttributeGroupInfo.forEach((item: any) => {
                                            if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                item.orderAttributes.forEach((item: any) => {
                                                    if (item.orderAttributeName === "orderLevelCBRNumber") {
                                                        this.contactNumber =item.orderAttributeValue;
                                                      
                                                       this.schedulingVariables.isCbr= true;
                                                    }
                                                });
                                        
                                            }
                                          
                                        });
                                    }
                                });
                            }
                        });
                    }
                    if(this.isChecked){
                        this.schedulingVariables.cbrForm.controls.additionalNumber.updateValueAndValidity();
                    }
                    if (this.schedulingVariables.appointmentResponse.payload.appointmentInfo) {
                        this.appointmentNotes = this.schedulingVariables.appointmentResponse.payload.apptNotes;
                    }                                                       
                    if (this.schedulingVariables.appointmentResponse.payload.appointmentInfo !== null
                        && this.schedulingVariables.appointmentResponse.payload.appointmentInfo !== undefined) {
                        this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.
                            availableAppointment;
                    }
                    if (this.schedulingVariables.appointmentResponse.payload.shippingInfo !== null && this.schedulingVariables.appointmentResponse.payload.shippingInfo !== undefined) {
                        this.shippingAddressObject = this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddress;
                        this.schedulingVariables.shippingAddress = this.shippingAddressObject.streetAddress + ',' +
                            this.shippingAddressObject.city + ',' +
                            this.shippingAddressObject.stateOrProvince + ',' +
                            this.shippingAddressObject.postCode;

                        this.myForm = this.fb.group({
                            name: [this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingName ? this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingName : '',
                            [Validators.required, <any>Validations.nameValidator]],
                            addressLine: this.shippingAddressObject.streetAddress ?
                                [this.shippingAddressObject.streetAddress,
                                Validators.required] : ['', Validators.required],
                            unitNumber: [this.shippingAddressObject.streetNrFirst ? this.shippingAddressObject.streetNrFirst : ''],
                            info: [this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddlInfo ? this.schedulingVariables.appointmentResponse.payload.shippingInfo.shippingAddlInfo : ''],
                            state: [this.shippingAddressObject.stateOrProvince, Validators.required],
                            city: [this.shippingAddressObject.city ? this.shippingAddressObject.city : '', [Validators.required,
                            <any>Validations.nameValidator]],
                            zipCode: [this.shippingAddressObject.postCode ? this.shippingAddressObject.postCode : '', Validations.zipCodeValidator]
                        });
                    }
                    this.schedulingHelperService.cbrMethod(this.contactNumber.trim(),this.schedulingVariables);
                }
            });
            this.appointmentSubscription.unsubscribe();
            let existingProd = <Observable<any>>this.store.select('existingProducts');
        existingProd
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            if(data && data !== null && data.existingProductsAndServices&& data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0] 
                &&  data.existingProductsAndServices[0].accountInfo){
                if(data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 &&  data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== ''){
                    this.contactNumberExists=true;
                }
            }
        })
        }
        this.schedulingHelperService.initializeAdjustableOtcInfo(this.schedulingVariables);
        this.schedulingHelperService.waiveOtcAllowedCheck(this.schedulingVariables);
        this.schedulingVariables.adjustableOtcProducts.forEach(otc => {
            if(otc && otc.otcDetails && otc.otcDetails.discountedOtc){
                this.schedulingVariables.eligibleCharges += +otc.otcDetails.discountedOtc;
            }
        });
    }
    
    public ngAfterViewInit() {
        this.schedulingVariables.orderDisclosures = this.orderDisclosures;   
        if (this.previousUrl === '/account' || this.previousUrl === '/customize-services') {
            if (this.retainReservedAppointment) {
                this.reservedAppointment = this.retainReservedAppointment;
            }
        }
    }

    public ngOnInit() {
        this.logger.metrics('SchedulingBillingScheduleShippingAppointmentPage');
        this.cartObservable = <Observable<any>>this.store.select('cart');
        this.cartSubscription = this.cartObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((cartdata) => {
            if(cartdata && cartdata.waivedOtcInfo){
                this.schedulingVariables.waivedOtcInfo = cartdata.waivedOtcInfo;
                if(this.schedulingVariables.waivedOtcInfo) {
                    this.schedulingHelperService.retainWaivedOtc(this.schedulingVariables);
                }
            } 
        });
        window.scroll(0, 0);
        let existingProd = <Observable<any>>this.store.select('existingProducts');
        existingProd
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((data) => {
            this.existingData = data;
            if(data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0] 
                &&  data.existingProductsAndServices[0].accountInfo){
                if(data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 &&  data.existingProductsAndServices[0].accountInfo.contact.contactNumber2 !== ''){
                    this.contactNumberExists=true;
                }
            }
            if(data && data !== null && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0] 
                &&  data.existingProductsAndServices[0].accountInfo){
                if(data.existingProductsAndServices[0].accountInfo.contact && data.existingProductsAndServices[0].accountInfo.contact.contactNumber &&  data.existingProductsAndServices[0].accountInfo.contact.contactNumber !== ''){
                    this.contactNumber2=data.existingProductsAndServices[0].accountInfo.contact.contactNumber;
                }
            }
        })

        this.schedulingVariables.cbrForm.controls.contactNumber.valueChanges.subscribe(value => {
            if(!this.schedulingVariables.isReEntrant){
                this.isadditionalNumberChecked=false;
            this.schedulingVariables.formattedNumber=value.toString().replace(/[^A-Z0-9]/ig, "");
            this.schedulingVariables.formattedContactNumber=this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
            if(this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber){
                if(this.schedulingVariables.cbrForm.controls.additionalNumber.value === true){
                    this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                }
            }
            }else{
                if(this.reentrantnumber === value.toString().replace(/[^A-Z0-9]/ig, "")){
                    this.isChecked=this.isReentrantAdditionalnumberChecked;
                    if(this.isReentrantAdditionalnumberChecked){
                    this.schedulingVariables.formattedNumber='';
                    }
                    this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(this.isadditionalNumberChecked);
                }else{
                    this.isadditionalNumberChecked=false;
                    this.isChecked=true;
                    this.schedulingVariables.formattedNumber=value.toString().replace(/[^A-Z0-9]/ig, "");
                    this.schedulingVariables.formattedContactNumber=this.contactNumber.toString().replace(/[^A-Z0-9]/ig, "");
                if(this.schedulingVariables.formattedNumber !== this.schedulingVariables.formattedContactNumber){
                    if(this.schedulingVariables.cbrForm.controls.additionalNumber.value === true){
                        this.schedulingVariables.cbrForm.controls.additionalNumber.patchValue(false);
                    }
                }
            }
            }
        });
      let customize = <Observable<any>>this.store.select('customize');
            this.customizedSubscription = customize
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                if (data && data.payload && data.payload !== undefined && data.payload.reservedTN !== undefined && data.payload.reservedTN.length !== 0) {
                    this.currentTN = data.payload.reservedTN[0].requestedTelephoneNumber;
                }
            });   

    }

    public ngOnDestroy() {
        if(this.userSubscription) this.userSubscription.unsubscribe();
        if(this.cartSubscription) this.cartSubscription.unsubscribe();
        this.ngOnDestroy$.next();
        this.ngOnDestroy$.complete();
    }              
                  
    public cancelClick() {
        this.router.navigate(['/home']);
    }

}