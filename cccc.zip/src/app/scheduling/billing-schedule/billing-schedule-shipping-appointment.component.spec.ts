import { TestBed, async, ComponentFixture} from '@angular/core/testing';
import { Router } from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import { BillingScheduleShippingAppointmentComponent } from './billing-schedule-shipping-appointment.component';
import { MockServer } from 'app/MockServer.test';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import {AppStateService } from 'app/common/service/app-state.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from 'app/common/service/helper.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import { SchedulingService } from 'app/common/service/scheduling.service';
import { MockAppStateService, MockSystemErrorService, MockHelperService, MockLogger, MockRouter, 
  MockBlueMarbleService, MockProductService, MockAddressService, MockCountryStateService, MockTextMaskService, MockPropertiesHelperService, MockReviewOrderService, MockDisclosuresService, MockDisconnectService, MockPendingOrderService, MockAccountService, MockDirectvService, MOCK_ROUTES} from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { AccountService } from 'app/common/service/account.service';
import { DirectvService } from 'app/common/service/directv.services';
import { of } from 'rxjs';

describe('billing schedule Shipping Appointment Component', () => {
  let component: BillingScheduleShippingAppointmentComponent;
  let fixture: ComponentFixture<BillingScheduleShippingAppointmentComponent>;
  const mockServer= new MockServer();

  const mockRedux : any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
      return of(
        mockServer.getBillingMockStore("onload-billing-scheduling")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return of(null);
    }
  }

  const logger = { provide: Logger, useClass: MockLogger};
  const router = { provide: Router, useClass: MockRouter };
  const store = { provide: Store, useValue: mockRedux};
  const appStateService = { provide: AppStateService, useClass: MockAppStateService}; 
  const countryStateService = { provide: CountryStateService, useClass: MockCountryStateService };
  const textMaskService = { provide: TextMaskService, useClass:MockTextMaskService};
  const helperService = { provide: HelperService, useClass:MockHelperService};
  const propertiesHelperService = { provide: PropertiesHelperService, useClass:MockPropertiesHelperService};
  
  // dialog component providers list
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const disclosuresService = { provide: DisclosuresService, useClass: MockDisclosuresService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService }
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const directvService = {provide: DirectvService, useClass: MockDirectvService };
 
  const providers = [
    logger, router, store, appStateService, countryStateService,
    textMaskService, helperService, propertiesHelperService, reviewOrderService,
    disclosuresService, addressService, disconnectService, blueMarbleService,
    systemErrorService, pendingOrderService, productService, directvService, 
    accountService, CTLHelperService, SchedulingService, SchedulingHelperService
  ]

  const baseConfig = {
    imports:[
      FormsModule, 
      ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}), 
      TextMaskModule,
      SharedModule,
      SharedCommonModule,
      RouterTestingModule.withRoutes(MOCK_ROUTES)
    ],
    declarations:[BillingScheduleShippingAppointmentComponent],
    providers: providers
  }

  beforeAll(() => {
    TestBed.resetTestingModule();
  })

  beforeEach(async(() => {
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingScheduleShippingAppointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterAll(() => {
    fixture.destroy();
  });

  it('should create billing schedulling shipping appointment component', () => {
    expect(component).toBeTruthy();
  });

  it('billing Schedule shipping ngOninit() been called...', () => {
    const returnVal = component.ngOnInit();
    expect(returnVal).toBeUndefined();
  });

  it('billing Schedule shipping ngOnDestroy() been called...', () => {
    const returnVal = component.ngOnDestroy();
    expect(returnVal).toBeUndefined();
  });

  it('isWaiveOtcAllowed should be as true', () => { 
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement;
    schedulevar.isWaiveOtcAllowed = true;
    schedulevar.eligibleCharges = 215;
    expect(schedulevar.isWaiveOtcAllowed).toBeTruthy;
    expect(component.billingType).not.toBe('PREPAID');
    expect(schedulevar.eligibleCharges).toBeDefined;
    expect(schedulevar.eligibleCharges).toBeGreaterThan(0);
    expect(element.querySelector('.waiveOtcBlock')).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock b a')).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock b a')).toBeDefined('Waive one-time charges');
    const eligibleCharges = schedulevar.eligibleCharges + " eligible charges";
    expect(element.querySelector('.waiveOtcBlock div')).toBeDefined(eligibleCharges);
  });

  it('When totalWaivedOtc value is 0', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.waivedOtcInfo.totalWaivedOtc = 0;
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeDefined();
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toEqual(0);
    expect(element.querySelector('.waiveOtcBlock div.nonWaivedCharge')).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock div.nonWaivedCharge')).toBeDefined('None waived');
  });

  it('When totalWaivedOtc value is greater than 0', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.waivedOtcInfo.totalWaivedOtc = 50;
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeDefined();
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toEqual(50);
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeGreaterThan(0);
    expect(schedulevar.waivedOtcInfo.totalWaivedOtc).toBeTruthy;
    expect(element.querySelector('.waiveOtcBlock div.waivedCharges')).toBeTruthy;
  });

  it('should hide contents if isWaiveOtcAllowed is false', () => {
    let schedulevar = component && component.schedulingVariables;
    const element = fixture.debugElement.nativeElement; 
    schedulevar.isWaiveOtcAllowed = false;
    expect(schedulevar.isWaiveOtcAllowed).toBeFalsy;
    expect(component.billingType).not.toBe('PREPAID');
  });

  it("Check cancelClick", () => {
    const returnVal = component.cancelClick();
    expect(returnVal).toBeUndefined();
  });

});
