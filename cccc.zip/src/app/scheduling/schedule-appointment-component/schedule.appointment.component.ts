import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentNotes, AvailableAppointment } from '../../common/models/appointment.model';
import { User } from '../../common/models/user.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { AppStore } from '../../common/models/appstore.model';
import { Subscription } from 'rxjs/Subscription';
import { DatePipe } from '@angular/common';
import { AppStateService } from '../../common/service/app-state.service';
import { SchedulingVariables } from 'app/common/models/schedule.shipping.model';
import { Logger } from '../../common/logging/default-log.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import { cloneDeep } from 'lodash';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { AppointmentShipping } from 'app/common/models/schedule-shipping.model';
import { SchedulingHelperService } from 'app/scheduling/service/scheduleHelper.service';
import "rxjs/add/operator/catch";
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { PropertyEnums } from 'app/common/enums/propertyEnums.ts';
import { AppConstant } from 'app/app.constant';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'schedule-appt',
    styleUrls: ['../schedule-component/schedule.component.scss'],
    templateUrl: './schedule.appointment.component.html'
})
export class ScheduleAppointmentComponent implements OnInit, OnDestroy, AfterViewInit {
    public retainedSchedulingData: any;    
    public userSubscription: Subscription;
    public user: Observable<User>;
    public apptSubscription: Subscription;
    public apptObservable: Observable<any>;           
    public phoneMask: any;
    public customerRequestedDueDateNotAvailableCheckBox: boolean = false;
    public changeEffectiveBillAddress: boolean = false;       
    private availableAppointment: AvailableAppointment[];
    public availableAppointments: AvailableAppointment[];    
    public schedulingVariables: SchedulingVariables;
    private appointment: Observable<AppointmentShipping>;
    private appointmentSubscription: Subscription;
    private appointmentNotes: AppointmentNotes;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public pendingObservable: Observable<any>;
    public pendingSubscription: Subscription;
    public cartSubscription: Subscription;
    public existingData: any;
    private taskId: string = '';
    private isChangeFlow: boolean = false;
    public isChange: boolean = false;
    private previousAppointmentInfo;    
    private contactNumber = '';
    private orderRefNumber: string;
    private finalDueDate;  
    private billeffectmindate: string;
    private billeffectmaxdate: string;
    private isBillEffectiveDate: boolean = false;
    private retainReservedAppointment;
    public disclosuresData: any;
    public rccDisclosureDetails: any;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
    rccDisclosureErrorMessage: any;
    public fromHold: boolean = false;
    public reqDeposit: boolean = false;
    public reUseBan: boolean = false;
    public billingType: string = '';
    // public offerVariables: OfferVariables;    
    public isCORSTeam: boolean = false;
    public isAmend: boolean;
    public isStack: boolean;
    public ban: any;
    public allowTechDropModems: boolean;

    public get $customerRequestedDueDateNotAvailableCheckBox(): boolean {
        return this.customerRequestedDueDateNotAvailableCheckBox;
    }        
    public get $availableAppointment(): AvailableAppointment[] {
        return this.availableAppointment;
    }   
    public get $appointment(): Observable<AppointmentShipping> {
        return this.appointment;
    }
    public get $appointmentSubscription(): Subscription {
        return this.appointmentSubscription;
    }

    public get $appointmentNotes(): AppointmentNotes {
        return this.appointmentNotes;
    }
    public cartObservable: Observable<any>;
    public prepaidPaymentDone: boolean = false;
    public onholdRestrictedMsg = AppConstant.CANNOT_HOLD_PREPAID_AFTER_PAYMENT;
    public ngOnDestroy$ = new Subject();
    
    constructor(
        private logger: Logger, 
        private router: Router, 
        private store: Store<AppStore>,    
        public schedulingHelperService: SchedulingHelperService,
        private appStateService: AppStateService,             
        private textMask: TextMaskService,
        private helperService: HelperService,
        private propertiesHelperService: PropertiesHelperService
        // private offerHelperService: OfferHelperService
    ) {
        // this.offerVariables = this.offerHelperService.setVariableDefaults(this.offerVariables);
        this.isCORSTeam = this.helperService.isAuthorized(ProfileEnums.ALLOW_CURRENT_DUE_DATE);
        this.allowTechDropModems = this.propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_TECH_DROP_MODEMS);
        this.schedulingVariables = this.schedulingHelperService.setDefaultsVariables(this.schedulingVariables);        
        this.appStateService.setLocationURLs();
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.appointment = store.select('appointment');
        let shippingObject: any;
        if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
            this.appointmentSubscription = this.appointment
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                let apoitmentData = cloneDeep(data);
                if (apoitmentData && apoitmentData.payload && apoitmentData.payload.billeffectiveDateInfo && apoitmentData.payload.billeffectiveDateInfo.minBedDate) {
                    this.billeffectmindate = apoitmentData.payload.billeffectiveDateInfo.minBedDate;
                    this.isBillEffectiveDate = true;
                }
                if (apoitmentData && apoitmentData.payload && apoitmentData.payload.billeffectiveDateInfo && apoitmentData.payload.billeffectiveDateInfo.maxBedDate) {
                    this.billeffectmaxdate = apoitmentData.payload.billeffectiveDateInfo.maxBedDate;
                    this.isBillEffectiveDate = true;
                }
                let user = <Observable<User>>store.select('user');
                let userSubscription = user
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe(
                    (usr) => {
                        this.billingType = usr.prepaidFlag;
                        if(this.billingType === 'PREPAID') {
                            this.prepaidPaymentDone = usr.paymentStatusChk;
                        }
                        this.schedulingVariables.firstname = usr.firstName;
                        this.schedulingVariables.lastname = usr.lastName;
                        this.schedulingVariables.previousUrl = usr.previousUrl;
                        this.schedulingVariables.currentUrl = usr.currentUrl;
                        if (usr.autoLogin.sfcData && usr.autoLogin.sfcData.type && usr.autoLogin.sfcData.type !== undefined) {
                            this.reUseBan = (usr.autoLogin.sfcData.type === 'ReopenBAN');
                        }
                        if(usr.autoLogin && usr.autoLogin.oamData && usr.autoLogin.oamData.agentFirstName && usr.autoLogin.oamData.agentLastName)
                        {
                            this.schedulingVariables.agentFirstName = usr.autoLogin.oamData.agentFirstName;
                            this.schedulingVariables.agentLastName = usr.autoLogin.oamData.agentLastName;
                        }
                        if (usr && usr.orderDisclosers && usr.orderDisclosers.rccGroup) {
                            this.schedulingVariables.loading = false;
                            this.disclosuresData = usr.orderDisclosers;
                            if (usr && usr.orderDisclosers && usr.orderDisclosers.rccGroup && usr.orderDisclosers.rccGroup.length > 0) {
                                this.rccDisclosureDetails = usr.orderDisclosers.rccGroup[0].rccDetails;
                                this.orderDisclosures.open();
                            } else {
                                this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: null });
                                this.schedulingHelperService.continueClick(this.schedulingVariables);
                            }
                        }
                        if (this.schedulingVariables.previousUrl === "/review-order" && this.schedulingVariables.currentUrl === "/schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (this.schedulingVariables.previousUrl === "/account" && this.schedulingVariables.currentUrl === "/schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                            this.store.dispatch({ type: 'ACCOUNT_ISPREPAID', payload: usr.prepaidFlag === 'PREPAID' ? true : false });
                        }
                        if (this.schedulingVariables.previousUrl !== '/customize-services' && this.schedulingVariables.previousUrl === '/account') {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if ((this.schedulingVariables.previousUrl === '/account' || this.schedulingVariables.previousUrl === '/reuse-ban-account') && (this.schedulingVariables.currentUrl === '/schedule-appt-ship' || this.schedulingVariables.currentUrl === '/schedule-appt')) {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                            this.store.dispatch({ type: 'ACCOUNT_ISPREPAID', payload: usr.prepaidFlag === 'PREPAID' ? true : false });
                        }
                        if (this.schedulingVariables.previousUrl === "/co-review-order" && this.schedulingVariables.currentUrl === "/schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (this.schedulingVariables.previousUrl === "/change-account" && this.schedulingVariables.currentUrl === "/schedule-appt-ship") {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (this.schedulingVariables.previousUrl !== '/customize-services' && this.schedulingVariables.previousUrl === '/change-account') {
                            this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: true });
                        }
                        if (this.schedulingVariables.previousUrl === '/customize-services') {
                            this.schedulingVariables.selectedAppointment = true;
                        }
                        let retainVal = <Observable<any>>store.select('retain');
                        let retSubscribe = retainVal
                        .pipe(takeUntil(this.ngOnDestroy$))
                        .subscribe(
                            (retVal) => {
                                this.retainedSchedulingData = retVal;
                                if (retVal && retVal.addOns && retVal.addOns.payload && retVal.addOns.payload.previousAppointmentInfo && retVal.addOns.payload.previousAppointmentInfo.appNotes && usr.previousUrl === '/order-unhold') {
                                    let tempAppNotes = retVal.addOns.payload.previousAppointmentInfo.appNotes;
                                    this.schedulingVariables.animalsPresentCheckBox = tempAppNotes.animalsPresent;
                                    this.schedulingVariables.electricFenceCheckBox = tempAppNotes.electricFence;
                                    this.schedulingVariables.lockedGateCheckBox = tempAppNotes.lockedGate;

                                    tempAppNotes.notes.map((x) => {
                                        if (x.name === 'Driving Directions') {
                                            this.schedulingVariables.drivingDirections = x.value;
                                        } else if (x.name === 'Additional Comments') {
                                            this.schedulingVariables.additionalComments = x.value;
                                        }
                                    });
                                }
                                if (usr.previousUrl !== '/order-unhold' && (usr.previousUrl === '/review-order' || usr.previousUrl === '/account') || (usr.previousUrl !== '/customize-services' && usr.previousUrl !== '/order-unhold') || retVal.accountreentrant) {
                                    if (usr.previousUrl === '/customize-services') {
                                        this.schedulingVariables.isReEntrant = retVal.accountreentrant;
                                    } else {
                                        this.schedulingVariables.isReEntrant = true;
                                        this.schedulingVariables.earliestAvailableAppt = 'Appointment is reserved';
                                        this.schedulingVariables.showReserveItButton = false;
                                    }
                                }
                                if (usr.previousUrl !== '/order-unhold' && (usr.previousUrl === '/co-review-order' || usr.previousUrl === '/change-account') || (usr.previousUrl !== '/customize-services' && usr.previousUrl !== '/order-unhold') || retVal.accountreentrant) {
                                    if (usr.previousUrl === '/customize-services') {
                                        this.schedulingVariables.isReEntrant = retVal.accountreentrant;
                                    } else {
                                        this.schedulingVariables.isReEntrant = true;
                                        this.schedulingVariables.earliestAvailableAppt = 'Appointment is reserved';
                                        this.schedulingVariables.showReserveItButton = false;
                                    }
                                    if(usr.taskId !== null && usr.taskId !== undefined)
                                    this.schedulingVariables.appointmentResponse.taskId = usr.taskId;
                                    shippingObject = retVal.account;
                                    if (shippingObject && shippingObject.payload && shippingObject.payload.apptNotes) {
                                        this.schedulingHelperService.getTechRemarks(shippingObject.payload.apptNotes, this.schedulingVariables);
                                    }
                                }
                                this.finalDueDate = retVal && retVal.account && retVal.account.payload && retVal.account.payload.dueDate && retVal.account.payload.dueDate.finalDueDate;
                                if (retVal && retVal.retainReservedAppointment) {
                                    this.retainReservedAppointment = retVal.retainReservedAppointment;
                                }
                            });
                        if (retSubscribe && retSubscribe !== undefined) {
                            retSubscribe.unsubscribe();
                        }
                        if (this.schedulingVariables.isReEntrant && !this.schedulingVariables.selectedAppointment) {
                            this.schedulingVariables.earliestAvailableAppt = 'Appointment is reserved';
                            this.schedulingVariables.showReserveItButton = false;
                        }
                        if (usr.isDtvOpus) {
                            if (usr && usr.dtvOpus && usr.dtvOpus.taskName === 'yes') {
                                this.schedulingVariables.dtvYes = true;
                            }
                        } else {
                            if (usr && usr.dtvQuestionForm && usr.dtvQuestionForm.taskName === 'yes') {
                                this.schedulingVariables.dtvYes = true;
                            }
                        }
                        if (usr.phoneNumber !== undefined && usr.phoneNumber !== '') {
                            this.contactNumber = usr.phoneNumber;
                        }
                        if (usr && usr.orderRefNumber) {
                            this.orderRefNumber = usr.orderRefNumber;
                        }
                    });
                userSubscription.unsubscribe();
                this.existingObservable = <Observable<any>>store.select('existingProducts');
                this.pendingObservable = <Observable<any>>store.select('pending');
                let pendingObj;
                this.pendingSubscription = this.pendingObservable
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe(p => {
                    pendingObj = p;
                    // if(p && p.orderReference && p.orderReference.pointOfNoReturn) this.ponr = p.orderReference.pointOfNoReturn;
                })
                this.existingSubscription = this.existingObservable
                .pipe(takeUntil(this.ngOnDestroy$))
                .subscribe((data) => {
                    this.existingData = data;
                    this.schedulingVariables.orderFlow = this.existingData.orderFlow && this.existingData.orderFlow.flow;
                    if (this.existingData && this.existingData.stackamend && this.existingData.stackamend.stackAmendFlag) {
                        if (this.existingData.stackamend.stackAmendFlag === "amendOrder") {
                            this.isAmend = true;
                        } else if (this.existingData.stackamend.stackAmendFlag === "stackOrder") {
                            this.isStack = true;
                        }
                    }
                    if (this.existingData && this.existingData !== undefined && this.existingData.orderFlow !== undefined && this.existingData.orderFlow.flow !== undefined && this.existingData.orderFlow.type === 'fromHold') {
                        this.fromHold = true;
                        pendingObj && pendingObj.orderDocument && pendingObj.orderDocument.creditReview && pendingObj.orderDocument.creditReview.depositInfo &&
                            pendingObj.orderDocument.creditReview.depositInfo.depositRequired ? this.reqDeposit = true : this.reqDeposit = false;
                    }
                    if (this.existingData && this.existingData !== undefined && this.existingData.orderFlow !== undefined && this.existingData.orderFlow.flow !== undefined && this.existingData.orderFlow.flow === 'Change') {
                        this.isChangeFlow = true;
                        this.isChange = true;
                    }
                });
                if (this.existingSubscription) this.existingSubscription.unsubscribe();
                if (this.pendingSubscription) this.pendingSubscription.unsubscribe();
                if (data && data !== null && data !== undefined &&
                    data.payload && data.payload !== null && data.payload !== undefined) {
                    this.schedulingVariables.appointmentResponse = data;
                    this.schedulingVariables.appointmentPayload = data.payload;
                    if (data.reservedCbr !== undefined && data.reservedCbr !== null) {
                        this.contactNumber = data.reservedCbr;
                    } else if (this.isChange && this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes
                        && Array.isArray(this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes) && this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.length > 0) {
                        this.schedulingVariables.appointmentResponse.payload.addlOrderAttributes.forEach((item: any) => {
                            if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                                item.orderAttributeGroup.forEach((item: any) => {
                                    if (item.orderAttributeGroupInfo && Array.isArray(item.orderAttributeGroupInfo) && item.orderAttributeGroupInfo.length > 0) {
                                        item.orderAttributeGroupInfo.forEach((item: any) => {
                                            if (item.orderAttributes && Array.isArray(item.orderAttributes) && item.orderAttributes.length > 0) {
                                                item.orderAttributes.forEach((item: any) => {
                                                    if (item.orderAttributeName === "orderLevelCBRNumber") {
                                                        this.contactNumber = item.orderAttributeValue;
                                                        this.schedulingVariables.isCbr = true;
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                    this.contactNumber = this.contactNumber.trim();
                    this.schedulingHelperService.cbrMethod(this.contactNumber,this.schedulingVariables);
                    if (data.payload.appointmentInfo && data.payload.appointmentInfo.apptNotes) {
                        this.appointmentNotes = data.payload!.appointmentInfo!.apptNotes;
                    }
                    let dateInString = this.schedulingVariables.appointmentPayload.appointmentInfo.availableAppointment[0].commitmentDateTime.trim().substr(0, 10).replace(/-/g, '\/');
                    this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
                    if (this.appointmentNotes !== undefined && this.schedulingVariables.previousUrl !== '/order-unhold') {
                        this.schedulingVariables.animalsPresentCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.animalsPresentCheckBox : this.appointmentNotes.animalsPresent ?
                            this.appointmentNotes.animalsPresent : false;
                        this.schedulingVariables.electricFenceCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.electricFenceCheckBox : this.appointmentNotes.electricFence ?
                            this.appointmentNotes.electricFence : false;
                        this.schedulingVariables.lockedGateCheckBox = this.schedulingVariables.isReEntrant ? this.schedulingVariables.lockedGateCheckBox : this.appointmentNotes.lockedGate ?
                            this.appointmentNotes.lockedGate : false;
                    }
                    this.schedulingVariables.appointmentResponse && this.schedulingVariables.appointmentResponse.payload && this.schedulingVariables.appointmentResponse.payload.appointmentInfo &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment &&
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment.map((slot) => {
                            if (slot.timeSlotType === 'SI-RTD' || slot.timeSlotType === 'OTH-BTAP' || slot.timeSlotType === 'TI-RTD' || slot.timeSlotType === 'TI-NORTD' || slot.timeSlotType === 'NOAPPT' || slot.timeSlotType === 'HSI-FCD' || slot.timeSlotType === 'POTS-FCD') {
                                this.schedulingVariables.isRTDChk = true;
                            }
                        });
                    if (this.schedulingVariables.appointmentPayload.appointmentInfo !== null
                        && this.schedulingVariables.appointmentPayload.appointmentInfo !== undefined) {
                        this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment.forEach((x) => {
                            if (x.timeSlotType === 'SI-RTD' || x.timeSlotType === 'OTH-BTAP' || x.timeSlotType === 'POTS-FCD') {
                                this.schedulingVariables.isRTD = true;
                                this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.
                                    availableAppointment.filter((y) => {
                                        return y.timeSlotType === 'SI-RTD' || y.timeSlotType === 'OTH-BTAP' || y.timeSlotType === 'POTS-FCD';
                                    });
                            } else {
                                this.availableAppointment = this.schedulingVariables.appointmentResponse.payload.appointmentInfo.availableAppointment;
                                this.schedulingVariables.isRTD = false;
                            }
                        });
                        this.availableAppointments = this.availableAppointment;
                    }                    
                }
            });        
            this.appointmentSubscription.unsubscribe();
            this.existingObservable = <Observable<any>>store.select('existingProducts');
            this.existingSubscription = this.existingObservable
            .pipe(takeUntil(this.ngOnDestroy$))
            .subscribe((data) => {
                this.existingData = data;
                if (this.existingData && this.existingData !== undefined && this.existingData.orderFlow !== undefined && this.existingData.orderFlow.flow !== undefined && this.existingData.orderFlow.flow === 'Change') {
                    this.isChangeFlow = true;
                    this.isChange = true;
                }
            });
            
        }
        this.schedulingHelperService.initializeAdjustableOtcInfo(this.schedulingVariables);
        this.schedulingHelperService.waiveOtcAllowedCheck(this.schedulingVariables);
        this.schedulingVariables.adjustableOtcProducts.forEach(otc => {
            if(otc && otc.otcDetails && otc.otcDetails.discountedOtc){
                this.schedulingVariables.eligibleCharges += +otc.otcDetails.discountedOtc;
            }
        });
    }
    
    ngAfterViewInit() {
        this.schedulingVariables.orderDisclosures = this.orderDisclosures;   
        if (this.schedulingVariables.previousUrl === '/account' || this.schedulingVariables.previousUrl === '/customize-services') {
            if (this.finalDueDate) {
                let dateInString = this.finalDueDate.trim().substr(0, 10).replace(/-/g, '\/');
                this.schedulingVariables.dueDate = new DatePipe('en-US').transform(new Date(dateInString), 'mediumDate');
            }
        }
        if (this.retainReservedAppointment) {
            this.schedulingVariables.reservedAppointment = this.retainReservedAppointment;
        }
    }
    
    public ngOnInit() {
        this.logger.metrics('SchedulingAppointmentPage');
        this.cartObservable = <Observable<any>>this.store.select('cart');
        this.cartSubscription = this.cartObservable
        .pipe(takeUntil(this.ngOnDestroy$))
        .subscribe((cartdata) => {
            if(cartdata && cartdata.waivedOtcInfo && cartdata.waivedOtcInfo){
                this.schedulingVariables.waivedOtcInfo = cartdata.waivedOtcInfo;
                if(this.schedulingVariables.waivedOtcInfo) {
                    this.schedulingHelperService.retainWaivedOtc(this.schedulingVariables);
                }
            } 
        });
        window.scroll(0, 0);
    }

    private cancelClick() {
        this.router.navigate(['/home']);
    }
  
    ngOnDestroy() {
        this.ngOnDestroy$.next();
        this.ngOnDestroy$.complete();
    }

}
