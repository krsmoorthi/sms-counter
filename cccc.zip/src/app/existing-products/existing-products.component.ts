import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { DomSanitizer } from '@angular/platform-browser';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { ProductService } from 'app/common/service/product.service';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../common/logging/default-log.service';
import { Appointment } from '../common/models/appointment.model';
import { AppStore } from '../common/models/appstore.model';
import { CustomerOrderItems, ShoppingCart } from '../common/models/cart.model';
import { APIErrorLists, GenericValues, Switch } from '../common/models/common.model';
import { DisconnectReasons } from '../common/models/disconnect-reasons.model';
import { ExistingProducts, ExistingProductsAndService, ExistingServiceItem, Price } from '../common/models/existing-products.model';
import { AttributesCombination, Catalogs, ProductOfferings, Products } from '../common/models/product.model';
import { User } from '../common/models/user.model';
import { FirstCustomizePipe } from '../common/pipes/firstcapcustom.pipe';
import { AddressService } from '../common/service/address.service';
import { AppStateService } from '../common/service/app-state.service';
import { BlueMarbleService } from '../common/service/bm.service';
import { DisconnectService } from '../common/service/disconnect.service';
import { SystemErrorService } from '../common/service/system-error.service';
import { TextMaskService } from '../common/service/text-mask.service';
import * as moment from 'moment-timezone';
import { HelperService } from '../common/service/helper.service';
import { ProfileEnums } from '../common/enums/profileEnums';
import { VacationDialogComponent } from 'app/common/popup/vacation-dialog.component';
import { VacationEnums } from 'app/common/enums/vacationEnums';
import { env } from '../../environments/environment';
import "rxjs/add/operator/catch";
import 'rxjs/add/observable/throw';
import { PropertiesHelperService } from '../common/service/propertiesHelper.service';
import { PropertyEnums } from '../common/enums/propertyEnums';

@Component({
    selector: 'existing-products',
    templateUrl: './existing-products.html',
    styleUrls: ['./existing-products.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ExistingProductsComponent implements OnInit, OnDestroy, AfterViewInit {
    public pendingDueDate: any;
    public multiplePending: any;
    public isLifelineActive: boolean = false;
    public isLdPartiallySuspended: boolean = false;
    public ldProdSuspend: boolean = false;
    public restoreAllProd: boolean;
    public suspendActive: boolean = false;
    public dtvProdSuspend: boolean;
    public hsiProdSuspend: boolean;
    public dhpProdSuspend: boolean;
    public potsProdSuspend: boolean;
    public nonPaySuspendSelected: boolean = false;
    public offerDisplayName: any;
    public pendingTabSelected: boolean = false;
    public isExistingdiscSelected: boolean = true;
    public allTabs: boolean;
    public disconenctTabSelected: boolean = false;
    public enabledisconnecttab: boolean = false;
    public lifelineDHPExisting: boolean = false;
    public lifelinePOTSExisting: boolean = false;
    public lifelineProductType: any;
    public exisitngData: any;
    public existingProductStoreSubscription: Subscription;
    public existingProductStore$: Observable<any>;
    public lifelineHSIExisting: boolean = false;
    public changeTabSelected: boolean = false;
    public moveTabSelected: boolean = false;
    public billingTabSelected: boolean = false;
    public isExistingProductsSelected = true;
    private isReferralSelected = 'No referral needed';
    public existingProductsResponse: ExistingProducts;
    private existingProducts: Observable<ExistingProducts>;
    public existingDiscounts: any = {};
    public endingDiscounts: any[] = [];
    public isRetentionDiscountDisplayed: boolean[] = [];
    private previousUrl: string;
    public directvAccountId: any = '';
    public dt: Date;
    private userSubscription: Subscription;
    public isDisconnectLandLineSelected = false;
    public isShowDisconnectFlowButtons = false;
    public user: Observable<User>;
    public legacy: string;
    public disconnectPending: boolean = false;
    public existingProductsSubscription: Subscription;
    public internetDisconnectData: ExistingServiceItem;
    public prismDisconnectData: ExistingServiceItem;
    public DHPDisconnectData: ExistingServiceItem;
    public POTSDisconnectData: ExistingServiceItem;
    public dtvDisconnectData: ExistingServiceItem;
    public disconnectResponse: DisconnectReasons;
    public disIsReentrent: boolean = false;
    public isDisplayedMonthlyDiscount: boolean = false;
    public isInternetTotalForRetentionDiscountCalculated: boolean = false;
    public internetTotal = 0;
    public prismTotal = 0;
    public dhpTotal = 0;
    public potsTotal = 0;
    public dtvTotal = 0;
    private potsPrice = 0;
    public completeTotal;
    public loading: boolean = false;
    public orderInitObject: any;
    public retain: any;
    public monthSelected: any;
    public reentrant: boolean = false;
    public finalAddressObject: any;
    public apiResponseError: APIErrorLists;
    private sfdcAccountId: string;
    private sfdcBillingAccountID: string;
    public agentFullName: string;
    private agentCuid: string;
    private customerOrderStatusDisplayText: any;
    @ViewChild('disconnectAll', { static: false, }) public disconnectDialog: DialogComponent;
    @ViewChild('RestoreProdPending', { static: false, }) public RestoreProdPending: DialogComponent;
    @ViewChild('suspendProdActive', { static: false, }) public suspendProdActive: DialogComponent;
    @ViewChild('unableToStack', { static: false, }) public unableToStack: DialogComponent;
    @ViewChild('unableToAmend', { static: false, }) public unableToAmend: DialogComponent;
    @ViewChild('moveService', { static: false, }) public moveServiceDialog: DialogComponent;
    @ViewChild('billingRecordsCorrectionMultiple', { static: false, }) public billingRecordsCorrectionMultiple: DialogComponent;
    public depositHistory: any;
    public selectedMonth: number;
    public phoneMask: any;
    public displayText: string = 'Pending';
    public reentrantFlag: boolean = false;
    private appointment: Observable<Appointment>;
    private appointmentSubscription: Subscription;
    private appointmentResponse: any;
    private retainSubscription: Subscription;
    private firstName: string;
    private lastName: string;
    private ensembleId: string;
    public isFinalDueDateZero: boolean = false;
    private orderRefNumber: string;
    public isDtvOpus: boolean;
    public pendingOrder: any;
    public vacationTabSelected: boolean = false;
    public hasVacationService: boolean = false;
    private callStartTime: string;
    private ucid: string;
    private tfn: string;
    public isVacationRestoreFlow: boolean = false;
    private isVacationSuspendFlow: boolean = true;
    public isPOTSExisintgProduct: boolean = false;
    private isDHPExistingProduct: boolean = false;
    public vacationsuspendflow: boolean;
    private isHSISuspendActive: boolean;
    private isPOTSSuspendActive: boolean;
    public vsflow: boolean;
    public isProfileSuspendRestore: boolean;
    public isProfileVacationService: boolean;
    private flagStackOrder: boolean = false;
    private flagAmendOrder: boolean = false;
    private flagIsStackAmendCall: boolean = false;
    public internetexistingProduct: boolean = false;
    public potsexistingProduct: boolean = false;
    public isJeopardy: boolean = false;
    public unabletoStackMsg: string = '';
    public orderType: string = '';
    public userData: any;
    public isChangeResponsibility: boolean = true;
    public stackAllowed: any;
    public amendAllowed: any;
    public unabletoAmendMsg: string = '';
    public otherOrderActivitiesAllowed: boolean = true;
    public otherOrderActivitiesDropdownSelected: string;
    public recommendedItems: any;
    public recommendVacationOffer: boolean = false;
    public flagMakeChange: boolean = false;
    public isPrepaid: boolean = false;
    public CORTabSelected: boolean = false;
    public recommendedErrorOpened = false;
    public sup3AllowedOnCon: any;
    public isOrderNIPending = false;
    public invokeCall: any;
    @ViewChild('billingRecordsCorrection', { static: false, }) public billingRecordsCorrection: DialogComponent;
    public isVacSusActiveOnAccount: boolean = false;
    public disclosureModalOpenSub: Subscription;
    public internetRCTotal: any;
    public group1: any;
    public changeTabEnabled: any;
    public vacOptionTabEnable: boolean = false;
    public allowNonpayDisconnect = true;
    public isBRProfile: boolean = false;
    public resetOrderRefNumber = false;

    constructor(
        private logger: Logger,
        private router: Router,
        private appStateService: AppStateService,
        public store: Store<AppStore>,
        private disconnectService: DisconnectService,
        private addressService: AddressService,
        private firstcapCustom: FirstCustomizePipe,
        private systemErrorService: SystemErrorService,
        private bMService: BlueMarbleService,
        private pendingOrderService: PendingOrderService,
        private textMask: TextMaskService,
        private ctlHelperService: CTLHelperService,
        private productService: ProductService,
        private helperService: HelperService,
        private sanitizer: DomSanitizer,
        private propertiesHelperService: PropertiesHelperService
    ) {
        this.isProfileSuspendRestore = helperService.isAuthorized(ProfileEnums.NONPAY_SUSPEND_RESTORE);
        this.isProfileVacationService = helperService.isAuthorized(ProfileEnums.SUSPEND_RESTORE_VACA);
        this.allowNonpayDisconnect = propertiesHelperService.getPropertyValueTrueFalse(PropertyEnums.ALLOW_NONPAY_DISCONNECT);
        this.isBRProfile = helperService.isAuthorized(ProfileEnums.ALLOW_B_AND_R_ORDER);
        this.phoneMask = this.textMask.getPhoneNumberMaskTN();
        this.appStateService.setLocationURLs();
        this.retain = store.select('retain');
        this.retainSubscription = this.retain.subscribe((retain) => {
            this.reentrantFlag = retain.reentrant;
            this.customerOrderStatusDisplayText = retain && retain.displayText;
            if (this.customerOrderStatusDisplayText && this.customerOrderStatusDisplayText.displayText) {
                if (this.customerOrderStatusDisplayText.displayText.indexOf('Unsubmitted') !== -1) {
                    this.displayText = 'Unsubmitted';
                } else {
                    this.displayText = 'Pending';
                }
            }
        })
        if (this.previousUrl !== '/existing-product' && this.previousUrl !== '/home' && this.reentrantFlag) {
            this.reentrant = true;
            if (this.retain !== null && this.retain !== undefined && this.retain) {
                this.retainSubscription = this.retain.subscribe((retain) => {
                    if (retain && retain.retainscheduling) {
                        this.referralResponse = retain.retainscheduling;
                        this.referralRequired(retain.retainscheduling);
                    }
                    if (retain && retain.monthSelected) {
                        this.monthSelected = retain.monthSelected;
                    }
                })
                if (this.retainSubscription && this.retainSubscription !== undefined) {
                    this.retainSubscription.unsubscribe();
                }
            }
            this.appointment = store.select('appointment');
            if (this.appointment !== null && this.appointment !== undefined && this.appointment) {
                this.appointmentSubscription = this.appointment.subscribe((data) => {
                    this.appointmentResponse = data;
                    this.disconnectService.offersData = this.appointmentResponse.payload.offers;
                    this.disconnectService.accounInfo = this.appointmentResponse.payload.accountName;
                    if (data && data.payload && data.payload.referralRequired && data.payload.referralRequired === 'yes') {
                        if (data && data.payload && data.payload.productConfiguration) {
                            data.payload.productConfiguration.map((configDetails) => {
                                if (configDetails.productType === GenericValues.cHP) {
                                    configDetails && configDetails.configItems && configDetails.configItems.map((configItems) => {
                                        if (configItems && configItems.productName) {
                                            this.isReferralSelected = configItems.productName;
                                            if (this.isReferralSelected !== 'New Number Referral') {
                                                this.monthSelected = 'na'
                                            }
                                        }
                                        configItems && configItems.configDetails && configItems.configDetails.map((conf) => {
                                            if (conf && conf.formName && conf.formName === 'Referral form') {
                                                conf.formItems && conf.formItems.map((formItems) => {
                                                    if (configItems && configItems.productName && configItems.productName === 'Split Referral' && formItems.attributeName === 'Referral End date') {
                                                        this.splitReferalEndDateValue = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'Free Basic Referral' && formItems.attributeName === 'Referral End date') {
                                                        this.freeReferralEndDate = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'New Number Referral' && formItems.attributeName === 'Referral End date') {
                                                        this.newReferralEndDateValue = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'New Number Referral' && formItems.attributeName === 'Referral Number') {
                                                        this.newReferralNumber = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'Split Referral' && formItems.attributeName === 'Referral Number 1') {
                                                        this.splitReferralNumber1 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'Split Referral' && formItems.attributeName === 'Referral Number 2') {
                                                        this.splitReferralNumber2 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'Split Referral' && formItems.attributeName === 'Name1') {
                                                        this.splitReferralName1 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                    if (configItems && configItems.productName && configItems.productName === 'Split Referral' && formItems.attributeName === 'Name2') {
                                                        this.splitReferralName2 = formItems.attributeValue && formItems.attributeValue[0] && formItems.attributeValue[0].value;
                                                    }
                                                })
                                            }
                                        })
                                    })
                                }
                            })
                        }
                    }
                })
            }
            if (this.appointmentSubscription && this.appointmentSubscription !== undefined) {
                this.appointmentSubscription.unsubscribe();
            }
        }
        this.user = <Observable<User>>store.select('user');
        this.userSubscription = this.user.subscribe((data) => {
            this.userData = data;
            this.isDtvOpus = data.isDtvOpus;
            if (data && data.offerDisplayName && data.offerDisplayName !== undefined && data.offerDisplayName.outputAttribute && data.offerDisplayName.outputAttribute !== undefined) {
                if (data.offerDisplayName.outputAttribute.length === 1) {
                    if (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" || data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                        this.offerDisplayName = data.offerDisplayName.outputAttribute[0][2];
                    }
                } else if (data.offerDisplayName.outputAttribute.length > 1) {
                    if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "INTERNET")) {
                        if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") || (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "INTERNET")) {
                            this.offerDisplayName = data.offerDisplayName.outputAttribute[0][2];
                        } else if (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" && data.offerDisplayName.outputAttribute[0][3] === "VOICE-HP") {
                            this.offerDisplayName = data.offerDisplayName.outputAttribute[1][2];
                        }
                    } else if ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" || (data.offerDisplayName.outputAttribute[0][3] === "VOICE-DHP" || data.offerDisplayName.outputAttribute[0][3] === "VIDEO-DTV")) && (data.offerDisplayName.outputAttribute[1][3] === "INTERNET" || (data.offerDisplayName.outputAttribute[1][3] === "VOICE-DHP" || data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV")) && (data.offerDisplayName.outputAttribute[0][2] !== null && data.offerDisplayName.outputAttribute[1][2] !== null)) {
                        this.offerDisplayName = ((data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DTV") || (data.offerDisplayName.outputAttribute[0][3] === "INTERNET" && data.offerDisplayName.outputAttribute[1][3] === "VIDEO-DHP")) ? data.offerDisplayName.outputAttribute[0][2] + ' ' + data.offerDisplayName.outputAttribute[1][2] : data.offerDisplayName.outputAttribute[1][2] + ' ' + data.offerDisplayName.outputAttribute[0][2];
                    }
                }
            }
            if (data.autoLogin !== null && data.autoLogin !== undefined) {
                if (data.autoLogin.sfcData) {
                    this.sfdcAccountId = data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : '';
                    this.sfdcBillingAccountID = data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID : '';
                    if (data.autoLogin.sfcData.orderActivity) {
                        if (data.autoLogin.sfcData.orderActivity.callStartTime) {
                            this.callStartTime = data.autoLogin.sfcData.orderActivity.callStartTime;
                            if (this.callStartTime && this.callStartTime.length > 0 && this.callStartTime !== "NA") {
                                var UTCTime = moment.utc(this.callStartTime).toDate();
                                var MSTTime = moment(UTCTime).tz('America/Denver').format('YYYY-MM-DD HH:mm:ss');
                                this.callStartTime = MSTTime;
                            } else {
                                this.callStartTime = "NA";
                            }
                        } else {
                            this.callStartTime = "NA";
                        }
                        if (data.autoLogin.sfcData.orderActivity.ucid) {
                            this.ucid = data.autoLogin.sfcData.orderActivity.ucid;
                        } else {
                            this.ucid = "NA";
                        }
                        if (data.autoLogin.sfcData.orderActivity.tfn) {
                            this.tfn = data.autoLogin.sfcData.orderActivity.tfn;
                        } else {
                            this.tfn = "NA";
                        }
                    } else {
                        this.callStartTime = "NA";
                        this.ucid = "NA";
                        this.tfn = "NA";
                    }
                    //get recommendItems from sfc
                    if (data.autoLogin && data.autoLogin.sfcData && data.autoLogin.sfcData.recommendedItems) {
                        this.recommendedItems = data.autoLogin.sfcData.recommendedItems;
                    }

                    //check recommendVacationOffer from sfc
                    if (data.autoLogin && data.autoLogin.sfcData && data.autoLogin.sfcData.recommendVacationOffer) {
                        this.recommendVacationOffer = data.autoLogin.sfcData.recommendVacationOffer;
                    }
                }
                if (data.autoLogin.oamData) {
                    this.agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    this.firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    this.lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    this.agentFullName = data.autoLogin.oamData.agentFullName ? data.autoLogin.oamData.agentFullName : '';
                    this.ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                }
            }
            if (data.previousUrl !== null && data.previousUrl !== undefined) {
                this.previousUrl = data.previousUrl;
                if (this.previousUrl.startsWith('/disconnect')) {
                    this.isShowDisconnectFlowButtons = true;
                } else {
                    this.isShowDisconnectFlowButtons = false;
                }
            }
            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
        });
        this.store.dispatch({ type: 'POTS_REMOVED', payload: false });
        this.existingProducts = <Observable<ExistingProducts>>store.select('existingProducts');
        this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
            if (data && data !== undefined && data.stackamend && data.stackamend !== undefined && data.stackamend.isStackAllowed && data.stackamend.isStackAllowed !== undefined) {
                this.stackAllowed = data.stackamend.isStackAllowed;
            }
            if (data && data !== undefined && data.stackamend && data.stackamend !== undefined && data.stackamend.isAmendAllowed && data.stackamend.isAmendAllowed !== undefined) {
                this.amendAllowed = data.stackamend.isAmendAllowed;
            }
            if (data !== null && data !== undefined) {
                this.existingProductsResponse = data;
                if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0] !== undefined && this.existingProductsResponse.existingProductsAndServices[0].existingServices !== null && this.existingProductsResponse.existingProductsAndServices[0].existingServices !== undefined && this.existingProductsResponse.existingProductsAndServices[0].existingServices.existingServiceItems) {
                    this.existingProductsResponse.existingProductsAndServices[0] !== undefined && this.existingProductsResponse.existingProductsAndServices[0].existingServices.existingServiceItems.map(data => {
                        this.existingProductsResponse.existingProductsAndServices[0].accountInfo && this.existingProductsResponse.existingProductsAndServices[0].accountInfo.billingType === 'PREPAID' ? this.isPrepaid = true : this.isPrepaid = false;
                        if (data.offerCategory === GenericValues.cHP) {
                            if (data.action === "SUSPEND") {
                                this.potsProdSuspend = true;
                            } else {
                                this.potsProdSuspend = false;
                            }
                            data.existingServiceSubItems.forEach(subData => {
                                if (subData.action === "SUSPEND") {
                                    this.ldProdSuspend = true;
                                }
                            })
                            if (data.action === "ADD") {
                                if (data.existingServiceSubItems[0].productName === "Selective Carrier Denial") {
                                    this.isLdPartiallySuspended = true;
                                } else {
                                    this.isLdPartiallySuspended = false;
                                }
                            }
                        }
                        if (data.offerCategory === GenericValues.cDHP) {
                            if (data.action === "SUSPEND") {
                                this.dhpProdSuspend = true;
                            } else {
                                this.dhpProdSuspend = false;
                            }
                        }
                        if (data.offerCategory === GenericValues.iData) {
                            if (data.action === "SUSPEND") {
                                this.hsiProdSuspend = true;
                            } else {
                                this.hsiProdSuspend = false;
                            }
                        }
                        if (data.offerCategory === GenericValues.cDTV) {
                            if (data.action === "SUSPEND") {
                                this.dtvProdSuspend = true;
                            } else {
                                this.dtvProdSuspend = false;
                            }
                        }
                        if (this.potsProdSuspend || this.hsiProdSuspend || this.dhpProdSuspend || this.dtvProdSuspend || this.ldProdSuspend) {
                            this.suspendActive = true;
                        }
                    })
                }
                if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0] !== undefined && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders !== null && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders !== undefined && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 0) {
                    if (this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus === "PENDING") {
                        this.otherOrderActivitiesAllowed = false;
                        this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.sort((a, b) => new Date(b.orderReference.orderDate).getTime() - new Date(a.orderReference.orderDate).getTime());
                        if (this.existingProductsResponse.existingProductsAndServices[0].pendingOrders) {
                            this.pendingDueDate = this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderDocument.schedule.dates.finalDueDate;
                        }
                        this.multiplePending = this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length;
                    }
                    if (this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus === "PENDING" && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderType === "NONPAYSUSPEND") {
                        this.suspendActive = true;
                    }
                }
                if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0] !== undefined && this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes && this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes !== undefined) {
                    for (let i = 0; this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes[0].orderAttributeGroup.length; i++) {
                        if (this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes[0].orderAttributeGroup[i].orderAttributeGroupName === "banSuspendStatus") {
                            if (this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes[0].orderAttributeGroup[i].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeName === "nonPaySuspend") {
                                this.restoreAllProd = (this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes[0].orderAttributeGroup[i].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue === "Yes") ? true : false;
                                break;
                            }
                        }
                    }
                }
                if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0]) {
                    this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.sort((a, b) => new Date(b.orderReference.orderDate).getTime() - new Date(a.orderReference.orderDate).getTime());
                    this.pendingOrder = this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0];
                }
                if (this.existingProductsResponse
                    && this.existingProductsResponse.existingProductsAndServices) {
                    this.existingProductsResponse.existingProductsAndServices.forEach((item) => {
                        item && item.pendingOrders && item.pendingOrders.map((pending) => {
                            if (pending && pending.orderReference && pending.orderReference.customerOrderType && pending.orderReference.customerOrderType === 'DISCONNECT') {
                                this.disconnectPending = true;
                            }
                            if (true) {
                                this.hasVacationService = true;
                            }
                            if (pending && pending.orderDocument && pending.orderDocument.schedule && pending.orderDocument.schedule.dates && pending.orderDocument.schedule.dates.finalDueDate && pending.orderDocument.schedule.dates.finalDueDate === '0000-00-00') {
                                this.isFinalDueDateZero = true;
                            }
                        })
                        if (!this.isDtvOpus) {
                            item && item.productConfiguration && item.productConfiguration.map((data) => {
                                if (data && data.productType === GenericValues.cDTV) {
                                    data.configItems && data.configItems.map((config) => {
                                        config && config.configDetails && config.configDetails.map((details) => {
                                            if (details && details.formName === 'DTV AccountID') {
                                                details.formItems && details.formItems.map((items) => {
                                                    if (items && items.attributeName === 'DIRECTV Account ID') {
                                                        if (items.attributeValue && items.attributeValue[0] && items.attributeValue[0].value) {
                                                            this.directvAccountId = items.attributeValue[0].value;
                                                        }
                                                    }
                                                })
                                            }
                                        })
                                    })
                                }
                            })
                        }
                        let existsItems = [];
                        item && item.existingServices && item.existingServices.existingServiceItems && item.existingServices.existingServiceItems.map((existServItemObj) => {
                            if (!(existsItems.indexOf(existServItemObj.offerCategory) > -1)) {
                                existsItems.push(existServItemObj.offerCategory);
                            }
                            if (existServItemObj && (existServItemObj.action === 'VACSUS-ADD')) {
                                this.isVacationRestoreFlow = true;
                                this.isVacationSuspendFlow = false;
                            }
                            if ((existServItemObj.action === 'VACSUS-ADD') && existServItemObj.offerCategory === GenericValues.iData) {
                                this.isHSISuspendActive = true;
                            }
                            if ((existServItemObj.action === 'VACSUS-ADD') && existServItemObj.offerCategory === GenericValues.cHP) {
                                this.isPOTSSuspendActive = true;
                            }
                            if (this.isHSISuspendActive || this.isPOTSSuspendActive) {
                                this.isVacSusActiveOnAccount = true;
                            }
                        });
                        this.store.dispatch({ type: 'EXISTS_PRODUCTS', payload: existsItems });
                        this.store.dispatch({ type: 'EXISTS_SERVICES', payload: existsItems });
                    })
                    this.store.dispatch({ type: 'VAC_SUS_ACTIVE_PRODUCTS', payload: { isHSISuspendActive: this.isHSISuspendActive, isPOTSSuspendActive: this.isPOTSSuspendActive } })
                    this.legacy = this.existingProductsResponse.existingProductsAndServices[0] &&
                        this.existingProductsResponse.existingProductsAndServices[0].serviceAddress &&
                        this.existingProductsResponse.existingProductsAndServices[0].serviceAddress.locationAttributes &&
                        this.existingProductsResponse.existingProductsAndServices[0].serviceAddress.locationAttributes.legacyProvider;
                    this.legacy = this.firstcapCustom.transform(this.legacy);
                    for (let i = 0; i < this.existingProductsResponse.existingProductsAndServices.length; i++) {
                        if (this.existingProductsResponse.existingProductsAndServices[i].existingServices) {
                            for (let j = 0; j < this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems.length; j++) {
                                switch (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerCategory) {
                                    case GenericValues.iData: if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'SUBOFFER') {
                                        this.internetDisconnectData = this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j]
                                    }
                                        break;
                                    case GenericValues.sData: if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'SUBOFFER') {
                                        this.internetDisconnectData = this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j]
                                    }
                                        break;
                                    case 'VIDEO-PRISM':
                                        if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'SUBOFFER') { this.prismDisconnectData = this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j]; }
                                        break;
                                    case 'VOICE-DHP': if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'SUBOFFER') { this.DHPDisconnectData = this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j]; this.isDHPExistingProduct = true; }
                                        break;
                                    case 'VOICE-HP': if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'SUBOFFER' && this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'BILLING_CORPOTS') { this.POTSDisconnectData = cloneDeep(this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j]); this.isPOTSExisintgProduct = true; }
                                    else if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType === 'SUBOFFER') {
                                        let checkDuplicate = [];
                                        checkDuplicate = this.POTSDisconnectData && this.POTSDisconnectData.existingServiceSubItems &&
                                            this.POTSDisconnectData.existingServiceSubItems.filter(subItem => {
                                                return subItem.productName === this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].existingServiceSubItems[0].productName
                                            })
                                        if (checkDuplicate && checkDuplicate.length === 0) {
                                            this.POTSDisconnectData.existingServiceSubItems.push(this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].existingServiceSubItems[0]);
                                        }
                                    }
                                        break;
                                    case 'VIDEO-DTV': if (this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j].offerType !== 'SUBOFFER') { this.dtvDisconnectData = this.existingProductsResponse.existingProductsAndServices[i].existingServices.existingServiceItems[j]; }
                                        break;
                                    default: break;
                                }
                            }
                        }
                    }
                }
                //This is required as internet total calcualted in constructor, assign the existing discounts to the component's global variable. 
                if (this.existingProductsResponse && this.existingProductsResponse.existingDiscounts) {
                    this.existingDiscounts = this.existingProductsResponse.existingDiscounts;
                    this.existingDiscounts && this.existingDiscounts.orderDiscounts && this.existingDiscounts.orderDiscounts[0] && this.existingDiscounts.orderDiscounts[0].productDiscounts && this.existingDiscounts.orderDiscounts[0].productDiscounts.map((data) => {
                        if (data.productType === "VOICE-HP") {
                            this.potsexistingProduct = true;
                        }
                        if (data.productType === "INTERNET") {
                            this.internetexistingProduct = true;
                        }
                    });
                }
                this.isJeopardy = false;
                if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus === "IN-JEOPARDY") {
                    this.isJeopardy = true;
                }
            }
        });
        let type = this.existingProductsResponse.orderFlow.type;
        if (this.internetDisconnectData) {
            if (type === "fromHold") {
                if (this.internetDisconnectData && this.internetDisconnectData !== null
                    && this.internetDisconnectData.customerOrderSubItems && this.internetDisconnectData.customerOrderSubItems !== null
                    && this.internetDisconnectData.customerOrderSubItems.length > 0) {
                    for (let i = 0; i < this.internetDisconnectData.customerOrderSubItems.length; i++) {
                        if (this.internetDisconnectData.customerOrderSubItems[i].productName && this.internetDisconnectData.customerOrderSubItems[i].productName !== 'ISP'
                            && this.internetDisconnectData.customerOrderSubItems[i].productAttributes && this.internetDisconnectData.customerOrderSubItems[i].productAttributes !== null && this.internetDisconnectData.customerOrderSubItems[i].productAttributes.length > 0) {
                            for (let j = 0; j < this.internetDisconnectData.customerOrderSubItems[i].productAttributes.length; j++) {
                                if (this.internetDisconnectData.customerOrderSubItems[i].componentType === 'PRIMARY') {
                                    if (this.internetDisconnectData.rc > 0) {
                                        this.internetTotal += this.internetDisconnectData.rc;
                                    }
                                    break;
                                } else {
                                    if (this.internetDisconnectData.customerOrderSubItems[i].productAttributes[j].prices) {
                                        for (let k = 0; k < this.internetDisconnectData.customerOrderSubItems[i].productAttributes[j].prices.length; k++) {
                                            if (this.internetDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                                if (this.internetDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                                    this.internetTotal += this.internetDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (this.internetDisconnectData && this.internetDisconnectData.existingServiceSubItems) {
                    for (let i = 0; i < this.internetDisconnectData.existingServiceSubItems.length; i++) {
                        if (this.internetDisconnectData.existingServiceSubItems[i].productName !== 'ISP') {
                            for (let j = 0; j < this.internetDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                                if (this.internetDisconnectData.existingServiceSubItems[i].componentType === 'PRIMARY') {
                                    if (this.internetDisconnectData.rc > 0) {
                                        this.internetTotal += this.internetDisconnectData.rc;
                                    }
                                    break;
                                } else {
                                    if (this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                                        for (let k = 0; k < this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                            if (this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                                if (this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                                    this.internetTotal += this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.prismDisconnectData) {
            if (type === "fromHold") {
                if (this.prismDisconnectData && this.prismDisconnectData !== null
                    && this.prismDisconnectData.customerOrderSubItems && this.prismDisconnectData.customerOrderSubItems !== null
                    && this.prismDisconnectData.customerOrderSubItems.length > 0) {
                    for (let i = 0; i < this.prismDisconnectData.customerOrderSubItems.length; i++) {
                        for (let j = 0; j < this.prismDisconnectData.customerOrderSubItems[i].productAttributes.length; j++) {
                            if (this.prismDisconnectData.customerOrderSubItems[i].productAttributes[j].prices) {
                                for (let k = 0; k < this.prismDisconnectData.customerOrderSubItems[i].productAttributes[j].prices.length; k++) {
                                    if (this.prismDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                        if (this.prismDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                            this.prismTotal += this.prismDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                for (let i = 0; i < this.prismDisconnectData.existingServiceSubItems.length; i++) {
                    for (let j = 0; j < this.prismDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                        if (this.prismDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                            for (let k = 0; k < this.prismDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                if (this.prismDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                    if (this.prismDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                        this.prismTotal += this.prismDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.DHPDisconnectData) {
            if (type === "fromHold") {
                if (this.DHPDisconnectData && this.DHPDisconnectData !== null
                    && this.DHPDisconnectData.customerOrderSubItems && this.DHPDisconnectData.customerOrderSubItems !== null
                    && this.DHPDisconnectData.customerOrderSubItems.length > 0) {
                    for (let i = 0; i < this.DHPDisconnectData.customerOrderSubItems.length; i++) {
                        for (let j = 0; j < this.DHPDisconnectData.customerOrderSubItems[i].productAttributes.length; j++) {
                            if (this.DHPDisconnectData.customerOrderSubItems[i].productAttributes[j].prices) {
                                for (let k = 0; k < this.DHPDisconnectData.customerOrderSubItems[i].productAttributes[j].prices.length; k++) {
                                    if (this.DHPDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                        if (this.DHPDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                            this.dhpTotal += this.DHPDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                for (let i = 0; i < this.DHPDisconnectData.existingServiceSubItems.length; i++) {
                    for (let j = 0; j < this.DHPDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                        if (this.DHPDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                            for (let k = 0; k < this.DHPDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                if (this.DHPDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                    if (this.DHPDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                        this.dhpTotal += this.DHPDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.POTSDisconnectData) {
            if (type === "fromHold") {
                if (this.POTSDisconnectData && this.POTSDisconnectData !== null
                    && this.POTSDisconnectData.customerOrderSubItems && this.POTSDisconnectData.customerOrderSubItems !== null
                    && this.POTSDisconnectData.customerOrderSubItems.length > 0) {
                    for (let i = 0; i < this.POTSDisconnectData.customerOrderSubItems.length; i++) {
                        for (let j = 0; j < this.POTSDisconnectData.customerOrderSubItems[i].productAttributes.length; j++) {
                            if (this.POTSDisconnectData.customerOrderSubItems[i].productAttributes[j].prices) {
                                for (let k = 0; k < this.POTSDisconnectData.customerOrderSubItems[i].productAttributes[j].prices.length; k++) {
                                    if (this.POTSDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k]) {
                                        if (this.POTSDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                            this.potsTotal += this.POTSDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                for (let i = 0; i < this.POTSDisconnectData.existingServiceSubItems.length; i++) {
                    for (let j = 0; j < this.POTSDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                        if (this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                            for (let k = 0; k < this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                if (this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k]) {
                                    if (this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                        this.potsTotal += this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.dtvDisconnectData) {
            if (type === "fromHold") {
                if (this.dtvDisconnectData && this.dtvDisconnectData !== null
                    && this.dtvDisconnectData.customerOrderSubItems && this.dtvDisconnectData.customerOrderSubItems !== null
                    && this.dtvDisconnectData.customerOrderSubItems.length > 0) {
                    for (let i = 0; i < this.dtvDisconnectData.customerOrderSubItems.length; i++) {
                        for (let j = 0; j < this.dtvDisconnectData.customerOrderSubItems[i].productAttributes.length; j++) {
                            if (this.dtvDisconnectData.customerOrderSubItems[i].productAttributes[j].prices) {
                                for (let k = 0; k < this.dtvDisconnectData.customerOrderSubItems[i].productAttributes[j].prices.length; k++) {
                                    if (this.dtvDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                        if (this.dtvDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                            this.dtvTotal += this.dtvDisconnectData.customerOrderSubItems[i].productAttributes[j].prices[k].rc;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                for (let i = 0; i < this.dtvDisconnectData.existingServiceSubItems.length; i++) {
                    for (let j = 0; j < this.dtvDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                        if (this.dtvDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                            for (let k = 0; k < this.dtvDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                if (this.dtvDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                    if (this.dtvDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                        this.dtvTotal += this.dtvDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.completeTotal = this.internetTotal + this.prismTotal + this.dhpTotal + this.potsTotal + this.dtvTotal;
    }
    public ngAfterViewInit() {
        setTimeout(() => {
            if (this.isVacationRestoreFlow) {
                this.existingProductsResponse &&
                    this.existingProductsResponse.existingProductsAndServices &&
                    this.existingProductsResponse.existingProductsAndServices.map((existsProdAndServ) => {
                        existsProdAndServ &&
                            existsProdAndServ.existingServices &&
                            existsProdAndServ.existingServices.existingServiceItems &&
                            existsProdAndServ.existingServices.existingServiceItems.map((existsServiceItems) => {
                                if (existsServiceItems.offerCategory === 'INTERNET' && existsServiceItems.action === 'VACSUS-ADD' && existsServiceItems.offerType !== 'SUBOFFER') {
                                    this.internetDisconnectData = existsServiceItems;
                                }
                                if (existsServiceItems.offerCategory === 'VOICE-HP' && existsServiceItems.action === 'VACSUS-ADD' && existsServiceItems.offerType !== 'SUBOFFER') {
                                    this.POTSDisconnectData = existsServiceItems;
                                }
                            });
                    });
                this.internetTotal = 0;
                this.completeTotal = 0;
                this.potsTotal = 0;
                if (this.internetDisconnectData) {
                    for (let i = 0; i < this.internetDisconnectData.existingServiceSubItems.length; i++) {
                        if (this.internetDisconnectData.existingServiceSubItems[i].productName !== 'ISP') {
                            for (let j = 0; j < this.internetDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                                if (this.internetDisconnectData.existingServiceSubItems[i].componentType === 'PRIMARY') {
                                    this.internetTotal += this.internetDisconnectData.rc;
                                    break;
                                } else {
                                    if (this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                                        for (let k = 0; k < this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                            if (this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].priceType === 'PRICE') {
                                                if (this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                                    this.internetTotal += this.internetDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (this.POTSDisconnectData) {
                    for (let i = 0; i < this.POTSDisconnectData.existingServiceSubItems.length; i++) {
                        for (let j = 0; j < this.POTSDisconnectData.existingServiceSubItems[i].productAttributes.length; j++) {
                            if (this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices) {
                                for (let k = 0; k < this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices.length; k++) {
                                    if (this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k]) {
                                        if (this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc > 0) {
                                            this.potsTotal += this.POTSDisconnectData.existingServiceSubItems[i].productAttributes[j].prices[k].rc;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                this.calculateInternetTotalForRetentionDiscount(this.existingDiscounts);
                this.completeTotal = this.internetTotal + this.potsTotal;
            }
        }, 90);
    }
    public getSummedPrice(prices: Price[]): number {
        let sumPrice: number = 0;
        prices && prices.map(price => {
            if (price.rc > 0) {
                sumPrice += price.rc
            }
        })
        return sumPrice;
    }
    public setDisplayedMonthlyDiscount(discountId) {
        this.isRetentionDiscountDisplayed[discountId] = true;
    }
    public calculateInternetTotalForRetentionDiscount(existingDiscounts) {
        if (existingDiscounts) {
            if (this.isInternetTotalForRetentionDiscountCalculated === false && this.existingDiscounts && this.existingDiscounts.orderDiscounts && this.existingDiscounts.orderDiscounts.length > 0 && this.existingDiscounts.orderDiscounts[0].productDiscounts) {
                for (let i = 0; i < this.existingDiscounts.orderDiscounts[0].productDiscounts.length; i++) {
                    for (let j = 0; j < this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails.length; j++) {
                        let discountType = this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType;
                        if ((discountType === 'R' || discountType === 'C' || discountType === 'P') && this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDuration > 1  && (this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountRule === null || this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountRule.toUpperCase() !== "CHILD DISCOUNT")) {
                            this.internetTotal -= this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountRate;
                            this.completeTotal -= this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountRate;
                        }
                    }
                }
                this.isInternetTotalForRetentionDiscountCalculated = true;
            }
        }
    }
    public pushEndingDiscountsForRetentionDiscount(existingDiscounts) {
        if (existingDiscounts) {
            var currentDt = new Date();
            if (this.existingDiscounts && this.existingDiscounts.orderDiscounts && this.existingDiscounts.orderDiscounts.length > 0 && this.existingDiscounts.orderDiscounts[0].productDiscounts) {
                for (let i = 0; i < this.existingDiscounts.orderDiscounts[0].productDiscounts.length; i++) {
                    for (let j = 0; j < this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails.length; j++) {
                        if (this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'R' && this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDuration > 1) {
                            var expiryDt = new Date(this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountExpiryDate);
                            var priorTwoMonthsDtFromCurrentDt = new Date();
                            var afterTwoMonthsDtFromCurrentDt = new Date();
                            priorTwoMonthsDtFromCurrentDt.setHours(expiryDt.getHours());
                            priorTwoMonthsDtFromCurrentDt.setMinutes(expiryDt.getMinutes());
                            priorTwoMonthsDtFromCurrentDt.setSeconds(expiryDt.getSeconds());
                            priorTwoMonthsDtFromCurrentDt.setMilliseconds(expiryDt.getMilliseconds());
                            priorTwoMonthsDtFromCurrentDt.setDate(priorTwoMonthsDtFromCurrentDt.getDate() - 60);
                            afterTwoMonthsDtFromCurrentDt.setHours(expiryDt.getHours());
                            afterTwoMonthsDtFromCurrentDt.setMinutes(expiryDt.getMinutes());
                            afterTwoMonthsDtFromCurrentDt.setSeconds(expiryDt.getSeconds());
                            afterTwoMonthsDtFromCurrentDt.setMilliseconds(expiryDt.getMilliseconds());
                            afterTwoMonthsDtFromCurrentDt.setDate(afterTwoMonthsDtFromCurrentDt.getDate() + 60);
                            if (expiryDt > priorTwoMonthsDtFromCurrentDt && expiryDt < currentDt) {
                                var discDesc = this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDescription;
                                var discexpiryDt = this.getYMDTStoMDY(this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountExpiryDate);
                                this.endingDiscounts.push({ discDesc, discexpiryDt });
                            }
                            if (expiryDt < afterTwoMonthsDtFromCurrentDt && expiryDt > currentDt) {
                                var discDesc = this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDescription;
                                var discexpiryDt = this.getYMDTStoMDY(this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountExpiryDate);
                                this.endingDiscounts.push({ discDesc, discexpiryDt });
                            }
                        }
                    }
                }
            }
        }
    }
    public intializeDispalyedMonthlyRetentionDiscount(existingDiscounts) {
        //assign the existing discounts to the component's global variable
        if (existingDiscounts) {
            let tempDiscountId = []
            if (this.existingDiscounts && this.existingDiscounts.orderDiscounts && this.existingDiscounts.orderDiscounts.length > 0 && this.existingDiscounts.orderDiscounts[0].productDiscounts) {
                for (let i = 0; i < this.existingDiscounts.orderDiscounts[0].productDiscounts.length; i++) {
                    for (let j = 0; j < this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails.length; j++) {
                        if (this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountType === 'R' && this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountDuration > 1) {
                            tempDiscountId.push(this.existingDiscounts.orderDiscounts[0].productDiscounts[i].discountDetails[j].discountId);
                        }
                    }
                }
            }
            for (let i = 0; i < tempDiscountId.length; i++) {
                this.isRetentionDiscountDisplayed[tempDiscountId[i]] = false;
            }
        }
    }
    public callDisconnectReasons() {
        if(this.legacy !== 'Qwest' && this.suspendActive && this.allowNonpayDisconnect && this.isProfileSuspendRestore) {
            this.getToSuspendText();
            return;
        }
        if (!this.otherOrderActivitiesAllowed && this.pendingOrder.orderReference.customerOrderStatus === "PENDING") {
            this.unabletoStackMsg = 'disconnect';
            this.otherOrderActivitiesDropdownSelected = 'Disconnect';
            this.unableToStack.open();
            return;
        }
        let disconnectReasonsRequest;
        if (this.existingProductsResponse.existingProductsAndServices
            && this.existingProductsResponse.existingProductsAndServices.length > 0) {
            disconnectReasonsRequest = {
                ban: this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban,
                salesChannel: 'ESHOP-Customer Care',
                customerOrderType: 'DISCONNECT',
                serviceAddress: this.existingProductsResponse.existingProductsAndServices[0].serviceAddress,
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
            }
            if (this.sfdcBillingAccountID && this.sfdcAccountId) {
                disconnectReasonsRequest.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
            disconnectReasonsRequest = this.addAddlOrderAttributes(disconnectReasonsRequest);
        } else if (this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders) {
            disconnectReasonsRequest = {
                ban: '459688681',
                salesChannel: 'ESHOP-Customer Care',
                customerOrderType: 'DISCONNECT',
                serviceAddress: this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderDocument.serviceAddress,
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
            }
            if (this.sfdcBillingAccountID && this.sfdcAccountId) {
                disconnectReasonsRequest.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
        } else {
            disconnectReasonsRequest = {
                ban: '459713025',
                salesChannel: 'ESHOP-Customer Care',
                customerOrderType: 'DISCONNECT',
                serviceAddress: {
                    addressId: "",
                    streetAddress: "611 FENWICK DR",
                    streetNrFirst: "611",
                    streetNrFirstSuffix: "",
                    streetNrLast: "",
                    streetNrLastSuffix: "",
                    streetName: "FENWICK DR",
                    streetType: "",
                    locality: "PAPILLION",
                    city: "PAPILLION",
                    stateOrProvince: "NE",
                    postCode: "68046",
                    postCodeSuffix: "",
                    sourceId: "OMAHNE841F7KF.Q",
                    source: "LFACS",
                    geoAddressId: "200005657",
                    subAddress: {
                        combinedDesignator: "",
                        elements: [],
                        geoSubAddressId: "",
                        source: "",
                        sourceId: ""
                    },
                    country: "USA"
                },
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                },
            }
            if (this.sfdcBillingAccountID && this.sfdcAccountId) {
                disconnectReasonsRequest.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
            }
        }
        this.loading = true;
        this.logger.log("info", "existing-products.component.ts", "initDisconnectRequest", JSON.stringify(disconnectReasonsRequest));
        this.logger.startTime();
        this.disconnectService.initDisconnect(disconnectReasonsRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "initDisconnectResponse", error);
                this.logger.log("error", "existing-products.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "existing-products.component.ts", "initDisconnectResponse", JSON.stringify(data));
                    this.logger.log("info", "existing-products.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.disconnectResponse = data;
                    let orderFlow = {
                        flow: "Disconnect"
                    }
                    this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
                    this.disconnectDialog.open();
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "initDisconnectResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", lAPIErrorLists);
                    }
                });
    }
    public retrieveSecurityDepositHistory() {
        this.loading = true;
        this.logger.log("info", "existing-products.component.ts", "getSecurityDepositHistoryRequest", JSON.stringify(this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban));
        this.logger.startTime();
        this.bMService.getSecurityDepositHistory(this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban)
            .catch((error: any) => {
                this.loading = false;
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "getSecurityDepositHistoryResponse", error);
                this.logger.log("error", "existing-products.component.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.systemErrorService.logAndRouteUnexpectedError("error", this.disconnectResponse.orderRefNumber, "retrieveSecurityDepositHistoryCall", "existing-products.component.ts", "Existing Products Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "existing-products.component.ts", "getSecurityDepositHistoryResponse", JSON.stringify(data));
                this.logger.log("info", "existing-products.component.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data && data.depositInfo && data.depositInfo.length > 0) {
                    this.depositHistory = data;
                    this.store.dispatch({ type: 'DEPOSIT_INFO', payload: this.depositHistory })
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "getSecurityDepositHistoryResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "getSecurityDepositHistorySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "retrieveSecurityDepositHistoryError", "existing-products.component.ts", "Existing Products Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    public summaryClicked(event) {
        let pendingOrder = this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[event];
        this.store.dispatch({ type: 'PENDING_SUMMARY', payload: pendingOrder });
        this.router.navigate(['/pending-order']);
    }
    public ngOnInit() {
        this.logger.metrics('ExistingProductsPage');
        window.scroll(0, 0);
        this.existingProductStore$ = <Observable<any>>this.store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            this.exisitngData = respData
            //assign the existing discounts to the component's global variable
            if (this.exisitngData && this.exisitngData.existingDiscounts) {
                this.existingDiscounts = this.exisitngData.existingDiscounts;
            }
            if (this.exisitngData && this.exisitngData.enablechangetab === true && !this.amendAllowed && !this.stackAllowed) {
                this.changeTabSelected = this.exisitngData.enablechangetab;
            } else if (this.exisitngData && this.exisitngData.enablechangetab === false) {
                this.changeTabSelected = false;
            }
            if (this.exisitngData && this.exisitngData.enablemovetab === true) {
                this.moveTabSelected = this.exisitngData.enablemovetab;
            } else if (this.exisitngData && this.exisitngData.moveTabSelected === false) {
                this.moveTabSelected = false;
            }
            if (this.exisitngData && this.exisitngData.enablebillingtab === true) {
                this.billingTabSelected = this.exisitngData.enablebillingtab;
            } else if (this.exisitngData && this.exisitngData.billingTabSelected === false) {
                this.billingTabSelected = false;
            }
            if (this.exisitngData && this.exisitngData.enabledisctab === true) {
                this.disconenctTabSelected = this.exisitngData.enabledisctab;
            } else if (this.exisitngData && this.exisitngData.disconenctTabSelected === false) {
                this.disconenctTabSelected = false;
            }
            if (this.exisitngData && this.exisitngData.enablependingtab === true) {
                this.pendingTabSelected = this.exisitngData.enablependingtab;
            } else if (this.exisitngData && this.exisitngData.enablependingtab === false) {
                this.pendingTabSelected = false;
            }
            if (this.exisitngData && this.exisitngData.enableCORtab) {
                this.CORTabSelected = true;
            }
            if (this.exisitngData && this.exisitngData.existingProductsAndServices && this.exisitngData.existingProductsAndServices[0] &&
                this.exisitngData.existingProductsAndServices[0].lifelineInfo) {
                respData.existingProductsAndServices[0].lifelineInfo.map((data) => {
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "INTERNET") {
                        this.lifelineHSIExisting = true;
                    }
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-HP") {
                        this.lifelinePOTSExisting = true;
                    }
                    if (data.lifelineProductType !== undefined && data.lifelineProductType && data.lifelineProductType === "VOICE-DHP") {
                        this.lifelineDHPExisting = true;
                    }
                    if (this.lifelineHSIExisting || this.lifelinePOTSExisting || this.lifelineDHPExisting) {
                        this.isLifelineActive = true;
                    }
                    this.store.dispatch({ type: 'LIFELINE_ACTIVE', payload: this.isLifelineActive });
                })
            }
            // vacation tab visibility
            if (this.exisitngData && this.exisitngData.enablebillingtab === true) {
                this.vacationTabSelected = this.exisitngData.enablebillingtab;
            } else if (this.exisitngData && this.exisitngData.vacationTabSelected === false) {
                this.vacationTabSelected = false;
            }
            if (this.exisitngData && this.exisitngData.enableNonSuspendTab !== undefined && this.exisitngData.enableNonSuspendTab === true) {
                this.nonPaySuspendSelected = this.exisitngData.enableNonSuspendTab;
            } else {
                this.nonPaySuspendSelected = false;
            }
            if (this.exisitngData && this.exisitngData.newReferralPriceArray) {
                this.user = <Observable<User>>this.store.select('user');
                this.userSubscription = this.user.subscribe((data) => {
                    if (data.previousUrl === '/disconnect-schedule') {
                        this.isDisconnectLandLineSelected = true;
                        this.newReferralPriceArray = respData.newReferralPriceArray;
                    }
                });
            }
        });
        this.intializeDispalyedMonthlyRetentionDiscount(this.existingDiscounts);
        //navigation to change-product
        if (this.recommendedItems && !this.recommendVacationOffer) {
            this.goToChangeProduct();
        }
        // navigation to Vacation Service If recommendVacationOffer is true
        if (this.recommendVacationOffer) {
            this.initializeVacationService();
        }
        //set NI Pending flag
        if (this.exisitngData && this.exisitngData.pendingOrders && this.exisitngData.pendingOrders.length > 0) {
            this.exisitngData.pendingOrders.map((po) => {
                if (po.orderReference && po.orderReference.customerOrderStatus.toUpperCase() === "PENDING"
                    && po.orderReference.customerOrderType.toUpperCase() === "NEWINSTALL") {
                    this.isOrderNIPending = true;
                }
            });
        }

        this.disclosureModalOpenSub = this.ctlHelperService.disclosureModalOpen.subscribe(next => {
            if(next) {
                this.onDisclosureModalOpen();
            }
        });
        let vacationObservable = <Observable<any>>this.store.select('vacation');
        let vacSubscription = vacationObservable.subscribe((v) => {
            if(v && v.cartForVacOpt) this.vacOptionTabEnable = true;
        });
        if(vacSubscription) vacSubscription.unsubscribe();
    }
    public getDate(): number {
        return this.dt && this.dt.getTime() || new Date().getTime();
    }
    public getYMDTStoMDY(datetimestamp) {
        return new DatePipe('en-US').transform(datetimestamp, 'M/dd/yyyy');
    }
    public ngOnDestroy() {
        if (this.existingProductsSubscription !== undefined) this.existingProductsSubscription.unsubscribe();
        if (this.existingProductStoreSubscription && this.existingProductStoreSubscription !== undefined) {
            this.existingProductStoreSubscription.unsubscribe();
        }
        if (this.userSubscription !== undefined) this.userSubscription.unsubscribe();
        if (this.disclosureModalOpenSub) this.disclosureModalOpenSub.unsubscribe();
    }
    public gotopendingorder() {
        this.router.navigate(['/pending-order']);
    }
    public clickedContinue() {
        this.isExistingProductsSelected = false;
    }
    public referralResponse: any;
    public splitReferralMonthCount: number;
    public splitRferrralPrice: string;
    public referralType: string;
    public newReferralPriceArray: any = [];
    public referralRequired(event) {
        window.scroll(0, 0);
        this.isDisconnectLandLineSelected = true;
        this.referralResponse = event;
        if (this.referralResponse && this.referralResponse.payload && this.referralResponse.payload !== undefined && this.referralResponse.payload.offers && this.referralResponse.payload.offers !== null && this.referralResponse.payload.offers.offers !== undefined && this.referralResponse.payload.offers.offers.length > 0) {
            this.referralResponse.payload.offers.offers.map(offer => {
                offer.catalogs.map(catalog => {
                    catalog.catalogItems.map(catalogItem => {
                        if (catalogItem.productOffer.offerName === 'Call Referral') {
                            catalogItem.productOffer.productComponents.map(product => {
                                this.referralType = product.product.productName;
                                if (this.referralType === 'Split Referral') {
                                    product.product.productAttributes.map(productAttr => {
                                        if (productAttr.isPriceable) {
                                            productAttr.compositeAttribute.map(compAttr => {
                                                if (compAttr.attributeName === 'Duration') {
                                                    this.splitReferralMonthCount = compAttr.attributeValue;
                                                }
                                            });
                                            productAttr.prices.map(price => {
                                                this.splitRferrralPrice = price.otc;
                                            });
                                        }
                                    });
                                } else if (this.referralType === 'New Number Referral') {
                                    product.product.productAttributes.map(productAttr => {
                                        if (productAttr.isPriceable) {
                                            let monthCount = '';
                                            let priceValue = '';
                                            productAttr.compositeAttribute.map(compAttr => {
                                                if (compAttr.attributeName === 'Duration') {
                                                    monthCount = compAttr.attributeValue;
                                                }
                                            });
                                            productAttr.prices.map(price => {
                                                priceValue = price.otc;
                                                this.newReferralPriceArray = this.newReferralPriceArray.filter((data) => { return data.month !== monthCount })
                                                this.newReferralPriceArray.push({ 'month': monthCount, 'price': priceValue })
                                            });
                                        }
                                    });
                                    this.store.dispatch({ type: 'NEW_REFFERRAL_PRICE', payload: this.newReferralPriceArray });
                                }
                            });
                        }
                    });
                });
            });
        }
    }
    public newReferralChange(selectedReferral) {
        this.isReferralSelected = selectedReferral;
        if (selectedReferral === 'New Number Referral') {
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: selectedReferral,
                price: this.potsPrice
            }
            this.store.dispatch({ type: 'CREATE_CART', payload: cartRequest });
        } else if (selectedReferral === 'Split Referral') {
            this.potsPrice = 0;
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: selectedReferral,
                price: this.splitRferrralPrice
            }
            this.store.dispatch({ type: 'CREATE_CART', payload: cartRequest });
        } else if (selectedReferral === 'No referral needed') {
            this.potsPrice = 0;
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: '',
                price: ''
            }
            this.store.dispatch({ type: 'CREATE_CART', payload: cartRequest });
        } else if (selectedReferral === 'Free Basic Referral') {
            this.potsPrice = 0;
            let cartRequest: ShoppingCart;
            cartRequest = {
                selectedReferral: '',
                price: ''
            }
            this.store.dispatch({ type: 'CREATE_CART', payload: cartRequest });
        }
    }
    public movetabselect() {
        this.store.dispatch({ type: 'MOVE_EXISTING_TAB', payload: false });
    }
    public cartPush(splitRferrralPrice: number, SplitReferral: string) {
        this.store.dispatch({ type: 'DATE_PICKER_ALLOWED_MONTH', payload: 3 });
    }
    public toNextStage(isReentrant: boolean) {
        this.disconnectService.isSchedulingReEntrant = isReentrant;
        this.fillDetailsForProductConfigAndCart();
        this.store.dispatch({ type: 'REENTRANT', payload: true });
        if (isReentrant && this.disconnectService.offersData || isReentrant && this.disconnectService.accounInfo) {
            this.appointmentResponse.payload.offers = {};
            this.appointmentResponse.payload.offers = this.disconnectService.offersData;
            this.appointmentResponse.payload.accountName = this.disconnectService.accounInfo;
        } else {
            this.store.dispatch({ type: 'SCHEDULE_DISCONNECT', payload: this.reentrant });
        }
    }
    private diff_months(dt2, dt1) {
        var diff = (new Date(dt2).getTime() - new Date().getTime()) / 1000;
        diff /= (60 * 60 * 24 * 7 * 4);
        return Math.abs(Math.round(diff));
    }
    private freeReferralEndDate = this.ctlHelperService.convertDateFormat(this.getDate()).replace(/\//g, '-');
    private newReferralNumber = '';
    private newReferralEndDateValue = this.ctlHelperService.convertDateFormat(this.getDate()).replace(/\//g, '-');
    private newReferralMonthCount = 0;
    private splitReferralName1 = '';
    private splitReferralNumber1 = '';
    private splitReferralName2 = '';
    private splitReferralNumber2 = '';
    private splitReferalEndDateValue = this.ctlHelperService.convertDateFormat(this.getDate()).replace(/\//g, '-');
    private splitReferalMonthCount = 0;
    public freebasicDateSelected(event) {
        this.freeReferralEndDate = event.replace(/\//g, '-');
    }
    private updateReferralPrice(months) {
        this.newReferralPriceArray.map(price => {
            if (price.month === months) {
                this.potsPrice = price.price;
            }
        });
    }
    public onChangeReferralMonth(event) {
        if (event === "na") {
            this.store.dispatch({ type: 'MONTHSELECTED', payload: event });
            this.potsPrice = 0;
            this.newReferralChange(this.isReferralSelected);
        }
        if (event !== "na") {
            event.split(" ");
            this.selectedMonth = event[0];
            this.updateReferralPrice(this.selectedMonth);
            this.newReferralChange(this.isReferralSelected);
            this.store.dispatch({ type: 'MONTHSELECTED', payload: this.selectedMonth });
        } else {
            this.potsPrice = 0;
        }
    }
    public resetPotsprice(e) {
        if (e === "New Number Referral") {
            this.potsPrice = 0;
        }
    }
    public newReferralEndDate(event) {
        this.newReferralEndDateValue = event.replace(/\//g, '-');
        if (this.referralResponse.payload.dueDate.finalDueDate && event) {
            this.newReferralMonthCount = this.diff_months(event, this.referralResponse.payload.dueDate.finalDueDate);
            this.updateReferralPrice(this.newReferralMonthCount);
        }
    }
    public splitReferralDate(event) {
        this.splitReferalEndDateValue = event.replace(/\//g, '-');
        if (this.referralResponse.payload.dueDate.finalDueDate && event) {
            this.splitReferalMonthCount = this.diff_months(event, this.referralResponse.payload.dueDate.finalDueDate);
            this.updateReferralPrice(this.splitReferalMonthCount);
        }
    }
    private fillDetailsForProductConfigAndCart() {
        let selectedComponent = '';
        if (this.referralResponse && this.referralResponse.payload) {
            let selectedConfig = cloneDeep(this.referralResponse.payload.productConfiguration);
            this.referralResponse.payload.productConfiguration.map(productConfig => {
                if (productConfig.productType === 'VOICE-HP') {
                    selectedConfig[0].configItems = [];
                    productConfig.configItems.map(configItem => {
                        if (configItem.productName === 'Free Basic Referral' && this.isReferralSelected === 'Free Basic Referral') {
                            selectedComponent = configItem.productName;
                            configItem.configDetails.map(configDetail => {
                                configDetail.formItems.map(formItem => {
                                    if (formItem.attributeName === 'Referral End date') {
                                        formItem.attributeValue.map(attrValue => {
                                            attrValue.value = this.freeReferralEndDate;
                                        });
                                    }
                                });
                            });
                            selectedConfig[0].configItems[0] = configItem;
                        } else if (configItem.productName === 'New Number Referral' && this.isReferralSelected === 'New Number Referral') {
                            selectedComponent = configItem.productName;
                            configItem.configDetails.map(configDetail => {
                                configDetail.formItems.map(formItem => {
                                    switch (formItem.attributeName) {
                                        case 'duration':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.newReferralMonthCount;
                                            });
                                            break;
                                        case 'Referral End date':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.newReferralEndDateValue;
                                            });
                                            break;
                                        case 'Referral Number':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.newReferralNumber ? this.newReferralNumber.replace(/-/g, "") : '';
                                            });
                                            break;
                                    }
                                });
                            });
                            selectedConfig[0].configItems[0] = configItem;
                        } else if (configItem.productName === 'Split Referral' && this.isReferralSelected === 'Split Referral') {
                            selectedComponent = configItem.productName;
                            configItem.configDetails.map(configDetail => {
                                configDetail.formItems.map(formItem => {
                                    switch (formItem.attributeName) {
                                        case 'duration':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.splitReferalMonthCount;
                                            });
                                            break;
                                        case 'Referral End date':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.splitReferalEndDateValue;
                                            });
                                            break;
                                        case 'Name1':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.splitReferralName1;
                                            });
                                            break;
                                        case 'Name2':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.splitReferralName2;
                                            });
                                            break;
                                        case 'Referral Number 1':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.splitReferralNumber1 ? this.splitReferralNumber1.replace(/-/g, "") : '';
                                            });
                                            break;
                                        case 'Referral Number 2':
                                            formItem.attributeValue.map(attrValue => {
                                                attrValue.value = this.splitReferralNumber2 ? this.splitReferralNumber2.replace(/-/g, "") : '';
                                            });
                                            break;
                                    }
                                });
                            });
                            selectedConfig[0].configItems[0] = configItem;
                        }
                    });
                }
            });
            let catalog: Catalogs;
            let offer: ProductOfferings;
            let toCart: CustomerOrderItems;
            if (this.referralResponse && this.referralResponse.payload && this.referralResponse.payload.offers && this.referralResponse.payload.offers.offers
                && this.referralResponse.payload.offers.offers.length > 0) {
                this.referralResponse.payload.offers.offers.map(categor => {
                    if (categor.serviceCategory === GenericValues.cHP && categor.catalogs && categor.catalogs.length > 0 && categor.catalogs[0]
                        && categor.catalogs[0].catalogItems && categor.catalogs[0].catalogItems.length > 0 && categor.catalogs[0].catalogItems[0]) {
                        catalog = categor.catalogs[0];
                        offer = catalog.catalogItems[0];
                        catalog && catalog.catalogItems[0].productOffer && catalog.catalogItems[0].productOffer.productComponents.map(component => {
                            if ((component.product.productName === 'Free Basic Referral' || component.product.productName === 'Split Referral')
                                && component.product.productName === selectedComponent) {
                                let subItems: Products[] = [];
                                subItems.push({
                                    action: 'ADD',
                                    productId: component.product.productId,
                                    productName: component.product.productName,
                                    productType: component.product.productType,
                                    componentType: component.componentType,
                                    productAttributes: component.product.productAttributes,
                                    productAssociations: component.product.productAssociations,
                                    productCategory: component.product.productCategory,
                                    quantity: component.product.quantity.minQuantity,
                                    provisioningAction: null
                                })
                                toCart = {
                                    action: 'ADD',
                                    catalogId: catalog.catalogId,
                                    contractStartDate: offer.productOffer.validFor ? offer.productOffer.validFor.saleEffectiveDate : null,
                                    productOfferingId: offer.productOfferingId,
                                    offerName: offer.productOffer.offerName,
                                    offerType: offer.productOffer.offerType,
                                    offerSubType: offer.productOffer.offerSubType,
                                    offerCategory: offer.productOffer.offerCategory,
                                    quantity: 1,
                                    rc: offer.defaultOfferPrice ? offer.defaultOfferPrice.rc : 0,
                                    discountedRc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedRc : 0,
                                    otc: Number(this.splitRferrralPrice) ? Number(this.splitRferrralPrice) : offer.defaultOfferPrice.otc,
                                    discountedOtc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedOtc : 0,
                                    contractTerm: 0,
                                    customerOrderSubItems: subItems
                                }
                            } else if (component.product.productName === 'New Number Referral' && component.product.productName === selectedComponent) {
                                let subItems: Products[] = [];
                                let prodAttr: AttributesCombination[] = [];
                                component && component.product && component.product.productAttributes.map(pAttr => {
                                    if (!pAttr.isPriceable) {
                                        prodAttr.push(pAttr);
                                    } else {
                                        pAttr && pAttr.compositeAttribute && pAttr.compositeAttribute.map(compAttr => {
                                            if (compAttr.attributeName === 'Duration' && compAttr.attributeValue === this.newReferralNumber && this.newReferralNumber === '1') {
                                                prodAttr.push(pAttr);
                                            } else if (compAttr.attributeName === 'Duration' && compAttr.attributeValue === '3' && this.newReferralNumber !== '1') {
                                                prodAttr.push(pAttr);
                                            }
                                        })
                                    }
                                })
                                subItems.push({
                                    action: 'ADD',
                                    productId: component.product.productId,
                                    productName: component.product.productName,
                                    productType: component.product.productType,
                                    componentType: component.componentType,
                                    productAttributes: prodAttr,
                                    productAssociations: component.product.productAssociations,
                                    productCategory: component.product.productCategory,
                                    quantity: component.product.quantity.minQuantity,
                                    provisioningAction: null
                                })
                                toCart = {
                                    action: 'ADD',
                                    catalogId: catalog.catalogId,
                                    contractStartDate: offer.productOffer.validFor ? offer.productOffer.validFor.saleEffectiveDate : null,
                                    productOfferingId: offer.productOfferingId,
                                    offerName: offer.productOffer.offerName,
                                    offerType: offer.productOffer.offerType,
                                    offerSubType: offer.productOffer.offerSubType,
                                    offerCategory: offer.productOffer.offerCategory,
                                    quantity: 1,
                                    rc: offer.defaultOfferPrice ? offer.defaultOfferPrice.rc : 0,
                                    discountedRc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedRc : 0,
                                    otc: this.potsPrice ? this.potsPrice : offer.defaultOfferPrice.otc,
                                    discountedOtc: offer.defaultOfferPrice ? offer.defaultOfferPrice.discountedOtc : 0,
                                    contractTerm: 0,
                                    customerOrderSubItems: subItems
                                }
                            }
                        })
                    }
                })
            }
            let request = cloneDeep(this.referralResponse);
            if (toCart) {
                request.payload.cart.customerOrderItems.push(toCart);
            }
            request.payload.productConfiguration = selectedConfig;
            delete request.payload.offers;
            this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: request });
        }
        this.router.navigate(['/disconnect-schedule']);
    }
    private cancelOrder() {
        this.isExistingProductsSelected = true;
        this.isDisconnectLandLineSelected = false;
    }
    public clickChange() {
        if (this.sup3AllowedOnCon && this.flagAmendOrder && Switch.amendMultiple) {
            this.router.navigate(['/stack-amend-product']);
        } else if (this.existingProductsResponse.stackamend &&
            ((this.existingProductsResponse.stackamend.isAmendAllowed === "false" && this.existingProductsResponse.stackamend.isStackAllowed === "false")
                || (this.existingProductsResponse.stackamend.isAmendAllowed === undefined && this.existingProductsResponse.stackamend.isStackAllowed === undefined))) {
            this.router.navigate(['/offer-change']);
        } else {
            this.router.navigate(['/stack-amend-product']);
        }
    }
    public clickMoveTab() {
        this.router.navigate(['/move-product']);
    }
    public clickBillingTab() {
        this.router.navigate(['/billing-product']);
    }
    public clickPendingTab() {
        this.router.navigate(['/pending-order']);
    }
    public clickVacationTab() {
        this.router.navigate(['/vacation-suspend']);
    }
    public clickNonPaySuspendTab() {
        this.router.navigate(['/nonpay-suspend']);
    }
    public clickCORTab() {
        this.router.navigate(['/change-responsibility']);
    }
    public clickedDiscard() {
        this.cancelOrder();
        this.isShowDisconnectFlowButtons = false;
    }
    public discExistingSelected() {
        this.enabledisconnecttab = true;
        this.disconenctTabSelected = true;
        this.isExistingdiscSelected = true;
        this.store.dispatch({ type: 'DISCONNECT_EXISTING_TAB', payload: this.enabledisconnecttab });
        this.store.dispatch({ type: 'CHANGE_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'MOVE_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'BILLING_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'PENDING_EXISTING_TAB', payload: false });
        this.store.dispatch({ type: 'COR_EXISTING_TAB', payload: false });
    }
    public selectDisconnectAllTab() {
        this.isExistingdiscSelected = false;
        this.disconenctTabSelected = true;
    }
    public clickedDiscardSession() {
        this.router.navigate(['/home']);
    }
    public clickedDiscardViewingSession() {
        this.router.navigate(['/home']);
    }
    public onSaveVacationSuspend($event) {
        this.vacationTabSelected = $event.saveChanges;
    }
    public onContinueFromResModal($event) {
        this.goToChangeProduct();
    }
    public onDisclosureModalOpen() {
        this.orderDisclosures.open();
    }
    
    public serviceCategory(isCOR?: boolean) {
        if (this.existingProductsResponse
            && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices[0]) {
            let serviceCategories = this.existingProductsResponse.existingProductsAndServices[0].serviceCategory;
            let internetCheck = false;
            let videoAvail = false;
            let phoneAvail: boolean = false;
            let phoneType = [];
            let videoType = [];
            if (serviceCategories !== undefined) {
                serviceCategories.forEach((item) => {
                    if (item.serviceCategory === GenericValues.sData) {
                        internetCheck = true;
                    }
                    if (item.serviceCategory === 'DATA/VIDEO') {
                        videoAvail = true;
                        videoType.push({
                            name: 'DATA/VIDEO',
                            displayName: 'PRISM TV',
                            code: 'PTV',
                            tabName: 'PRISM'
                        });
                    }
                    if (item.serviceCategory === 'VIDEO-DTV') {
                        videoAvail = true;
                        videoType.push({
                            name: 'VIDEO-DTV',
                            displayName: 'DIRECTV',
                            code: 'DTV',
                            tabName: 'DIRECTV'
                        });
                    }
                    if (item.serviceCategory === 'VOICE-DHP') {
                        phoneAvail = true;
                        phoneType.push({
                            name: 'VOICE-DHP',
                            displayName: 'Digital(DHP)',
                            code: 'DHP',
                            tabName: 'DHP'
                        });
                    }
                    if (item.serviceCategory === 'VOICE-HP') {
                        phoneAvail = true;
                        phoneType.push({
                            name: 'VOICE-HP',
                            displayName: 'Home Phone',
                            code: 'HMP',
                            tabName: 'Home Phone'
                        });
                    }
                });
            }
            let user: User = {
                id: 1,
                internetCheck,
                videoCheck: videoAvail,
                phoneCheck: phoneAvail,
                phoneType: phoneType,
                videoType: videoType,
                enabledServiceList: serviceCategories,
                ban: this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban
            };
            let orderFlow = {
                flow: isCOR ? "COR" : "Change"
            }
            this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
            this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
        }
    }
    public goToChangeProduct() {
        this.loading = true;
        let request;
        request = {
            ban: this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban,
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            },
            salesChannel: "ESHOP-Customer Care",
            serviceAddress: {
                city: "",
                country: "",
                geoAddressId: "",
                locality: "",
                postCode: "",
                postCodeSuffix: "",
                source: "",
                sourceId: "",
                stateOrProvince: "",
                streetAddress: "",
                streetName: "",
                streetNrFirst: "",
                streetNrFirstSuffix: "",
                streetNrLast: "",
                streetNrLastSuffix: "",
                streetType: "",
                subAddress: {
                    combinedDesignator: "",
                    elements: {
                        designator: "",
                        value: ""
                    },
                    geoSubAddressId: "",
                    source: "",
                    sourceId: ""
                }
            },
        }
        if (this.sfdcBillingAccountID && this.sfdcAccountId) {
            request.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
        }
        //recomendedItems attach on request
        if (this.recommendedItems && !this.recommendedErrorOpened && !this.changeTabSelected) {
            request.recommendedItems = cloneDeep(this.recommendedItems);
        }
        this.serviceCategory();
        if (this.flagIsStackAmendCall) {
            let pendingOrder;
            if (this.flagAmendOrder && this.sup3AllowedOnCon && Switch.amendMultiple) {
                if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 0) {
                    this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.forEach((po) => {
                        if (po.orderReference.customerOrderNumber === this.sup3AllowedOnCon) {
                            pendingOrder = po;
                        }
                    })
                }
            }
            if (!pendingOrder) {
                pendingOrder = this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0];
            }
            request['isStackOrder'] = this.flagStackOrder;
            request['isAmendOrder'] = this.flagAmendOrder;
            request['customerOrderNumber'] = pendingOrder.orderReference.customerOrderNumber;
            this.flagStackOrder ? request['customerOrderType'] = 'CHANGE' : request['customerOrderType'] = pendingOrder.orderReference.customerOrderType;
        } else {
            request['customerOrderType'] = 'CHANGE';
        }
        this.logger.log("info", "existing-products.component.ts", "getInitChangeRequest", JSON.stringify(request));
        this.logger.startTime();
        this.addressService.getInitChangeCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "getInitChangeResponse", error);
                this.logger.log("error", "existing-products.component.ts", "getInitChangeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "existing-products.component.ts", "getInitChangeResponse", JSON.stringify(data));
                this.logger.log("info", "existing-products.component.ts", "getInitChangeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                this.store.dispatch({ type: 'CHANGE_ORDER_INIT', payload: data });
                if (data.orderRefNumber) {
                    this.helperService.appendToCookie("eshop_trace", "orderReferenceNumber", data.orderRefNumber);
                }
                if (!this.flagMakeChange && data.payload && data.payload.recommendedObject) {
                    this.store.dispatch({ type: 'RECOMMENDED_OBJECT', payload: data.recommendedObject });
                    let recommendationSuccess = false;
                    if (data.payload.recommendedObject[0] && data.payload.recommendedObject[0].errorInfo && data.payload.recommendedObject[0].errorInfo.length > 0) {
                        recommendationSuccess = true;
                        data.payload.recommendedObject[0].errorInfo.map(error => {
                            if (error.status !== '200') {
                                recommendationSuccess = false;
                            }
                        });
                    }
                    if (recommendationSuccess) {
                        this.clickChange();
                    } else {
                        this.loading = false;
                        this.recommendedError.open();
                        this.recommendedErrorOpened = true;
                    }
                } else {
                    //if no recommendedObjec no redirct to offer-change
                    this.loading = false;
                }
                if (this.isVacationRestoreFlow && !this.flagIsStackAmendCall && !this.flagMakeChange) {
                    this.store.dispatch({ type: 'VACATION_FLOW_NAME', payload: { isVacSusFlow: this.isVacationSuspendFlow, isVacResFlow: this.isVacationRestoreFlow } });
                    this.store.dispatch({ type: 'IS_OFFER_PAGE_CONTINUE_ALLOWED', payload: false });
                    this.router.navigate(['/vacation-product-offer']);
                } else {
                    if (this.flagMakeChange) {
                        this.clickChange();
                    }
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "getInitChangeResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "getInitChangeSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", lAPIErrorLists);
                    }
                })
    }
    public getToSuspendText() {
        this.suspendProdActive.open()
    }
    public unholdOrder() {
        if (this.existingProductsResponse
            && this.existingProductsResponse.existingProductsAndServices) {
            this.existingProductsResponse.existingProductsAndServices.forEach((existingItem) => {
                let data = existingItem && existingItem.pendingOrders && existingItem.pendingOrders[0];
                this.store.dispatch({ type: 'PENDING_SUMMARY', payload: data });
                if ((data.orderReference.lastCustomerOrderNumber === null && existingItem.existingServices === undefined && data.orderReference.customerOrderType === "NEWINSTALL" && data.orderReference.customerOrderNumber !== null) ||
                    (data.orderReference.customerOrderNumber !== null && existingItem.existingServices !== undefined && (data.orderReference.customerOrderType === "CHANGE" || data.orderReference.customerOrderType === "MOVE" || data.orderReference.customerOrderType === "DISCONNECT"))) {
                    this.router.navigate(['/pending-order']);
                } else {
                    this.holdPending(existingItem);
                }
            })
        }
    }
    private holdPending(existingItem: ExistingProductsAndService) {
        let data = existingItem && existingItem.pendingOrders && existingItem.pendingOrders[0];
        let flow: any;
        this.logger.startTime();
        let orderFlow: any;
        flow = data.orderReference.customerOrderType;
        let payload: any = {
            dueDate: data.orderDocument.schedule.dates,
            availableAppointment: data.orderDocument.schedule.appointmentInfo,
            apptNotes: data.orderDocument.schedule.apptNotes,
            shippingInfo: null,
            cart: null
        };
        let appointmentObj = {
            success: true,
            orderRefNumber: data.orderRefNumber,
            processInstanceId: data.processInstanceId,
            taskId: data.taskId,
            taskName: data.taskName,
            payload: payload
        };
        this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
        let customerOrderItems = {
            customerOrderItems: data.orderDocument.customerOrderItems
        };
        orderFlow = {
            flow: data.orderReference.customerOrderType.charAt(0).toUpperCase() + data.orderReference.customerOrderType.slice(1).toLowerCase(),
            type: 'fromHold'
        };
        this.store.dispatch({ type: 'ORDER_FlOW', payload: orderFlow });
        let selected = '';
        for (let i = 0; i < data.orderDocument.customerOrderItems.length; i++) {
            let offerCategory = data.orderDocument.customerOrderItems[i].offerCategory;
            if (offerCategory === "INTERNET") {
                selected = 'Internet,';
            } else if (offerCategory === "VOICE-HP") {
                selected += 'HMPhone';
            } else if (offerCategory === "VOICE-DHP") {
                selected += 'DHPhone';
            } else if (offerCategory === "VIDEO-DTV") {
                selected += 'TV';
            }
        }
        let cart: ShoppingCart;
        cart = { selectedService: selected };
        this.store.dispatch({ type: 'CREATE_CART', payload: cart });
        let customerAddonOfferItems = [];
        data && data.orderDocument && data.orderDocument.customerOrderItems && data.orderDocument.customerOrderItems.map(item => {
            if (item.offerType === 'SUBOFFER') {
                customerAddonOfferItems.push(item);
            }
        });
        payload = {
            cart: { customerOrderItems: data.orderDocument.customerOrderItems },
            customerAddonOfferItems: customerAddonOfferItems,
            productConfiguration: data.orderDocument.productConfiguration,
            addOnOffers: customerAddonOfferItems,
            reservedTN: data.orderDocument.reservedTN
        };
        let cartObject = {
            payload: payload,
            selectedService: selected
        };
        this.store.dispatch({ type: 'CREATE_CART', payload: cartObject });
        this.store.dispatch({ type: 'ADD-ONS', payload: cartObject });
        let cartObjToDispatch = {
            payload: {
                cart: customerOrderItems
            }
        };
        this.store.dispatch({ type: 'CREATE_CART', payload: cartObjToDispatch });
        this.loading = true;
        let taskNameFromResponse;
        let selectProduct = {
            taskName: 'Select Product'
        };
        this.store.dispatch({ type: 'SELECT_PRODUCT', payload: selectProduct });
        if (flow === 'MOVE') {
            this.existDataDispatch(data, orderFlow);
            this.router.navigate(['/move-product']);
        } else if (flow === 'CHANGE') {
            this.existDataDispatch(data, orderFlow);
        } else if (flow === 'BILLANDREC') {
            this.existDataDispatch(data, orderFlow);
            this.router.navigate(['/billing-product']);
        } else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
            this.vsflow = true;
            this.store.dispatch({ type: 'UNHOLD_VACATION_FLOW', payload: this.vsflow });
            let request = {
                ban: data.orderDocument.accountInfo.ban,
                salesChannel: 'ESHOP-Customer Care',
                customerOrderType: data.orderReference.customerOrderType,
                serviceAddress: data.orderDocument.serviceAddress,
                orderRefNumber: data.orderReference.orderReferenceNumber,
                sfdcAccountId: '',
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                }
            }
            this.loading = true;
            let errorResolved = false;
            this.logger.log("info", "existing-products.component.ts", "initVacationCallRequest", JSON.stringify(request));
            this.logger.startTime();
            this.bMService.initVacationCall(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "initVacationCallResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "initVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorResolved = true;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "address.component.ts", "Existing Products Page", error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (vacationData) => {
                        this.logger.endTime();
                        this.logger.log("info", "existing-products.component.ts", "initVacationCallResponse", JSON.stringify(vacationData));
                        this.logger.log("info", "existing-products.component.ts", "initVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        let vacationscheduleObj = {
                            orderRefNumber: vacationData.orderRefNumber,
                            processInstanceId: vacationData.processInstanceId,
                            taskId: vacationData.taskId,
                            taskName: vacationData.taskName,
                            payload: {
                                cart: vacationData.payload.cart
                            }
                        };
                        this.store.dispatch({ type: 'VACATION_FLOW', payload: this.vacationsuspendflow });
                        this.store.dispatch({ type: 'FINAL_VAC_CART', payload: vacationData.payload.cart });
                        this.store.dispatch({ type: 'VACATIONSCHEDULING', payload: vacationscheduleObj });
                        this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
                        let errorResolved = false;
                        this.logger.log("info", "existing-products.component.ts", "scheduleVacationCallRequest", JSON.stringify(vacationscheduleObj));
                        this.logger.startTime();
                        this.bMService.scheduleVacationCall(vacationscheduleObj)
                            .catch((error: any) => {
                                this.logger.endTime();
                                this.logger.log("error", "existing-products.component.ts", "scheduleVacationCallResponse", error);
                                this.logger.log("error", "existing-products.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                errorResolved = true;
                                this.loading = false;
                                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                                return Observable.throwError(null);
                            })
                            .subscribe(
                                (vacsdata) => {
                                    this.logger.endTime();
                                    this.logger.log("info", "existing-products.component.ts", "scheduleVacationResponse", JSON.stringify(vacsdata));
                                    this.logger.log("info", "existing-products.component.ts", "scheduleVacationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                    this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: vacsdata });
                                    this.store.dispatch({ type: 'TASK_ID', payload: vacsdata.taskId });
                                    this.store.dispatch({ type: 'VACATION_FLOW', payload: this.vacationsuspendflow });
                                    this.router.navigate(['/vacation-schedule-appt-ship']);
                                });
                    })
        } else if (flow === "DISCONNECT") {
            let request = {
                ban: data.orderDocument.accountInfo.ban,
                salesChannel: 'ESHOP-Customer Care',
                customerOrderType: 'DISCONNECT',
                serviceAddress: data.orderDocument.serviceAddress,
                orderRefNumber: data.orderReference.orderReferenceNumber,
                sfdcAccountId: '',
                party: {
                    id: this.agentCuid,
                    firstName: this.firstName,
                    lastName: this.lastName,
                    type: "CSR",
                    partyRoles: [
                        {
                            partyRole: env.CSR_NAME,
                            sourceSystem: env.CSR_PROFILE,
                            id: this.agentCuid
                        },
                        {
                            partyRole: env.ENSEMBLEID,
                            sourceSystem: env.ENS_OPERATOR,
                            id: this.ensembleId
                        }
                    ]
                }
            };
            this.loading = true;
            request = this.addAddlOrderAttributes(request);
            this.logger.log("info", "existing-products.component.ts", "initDisconnectRequest", JSON.stringify(request));
            this.logger.startTime();
            this.disconnectService.initDisconnect(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "initDisconnectResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                    return Observable.throwError(null);
                })
                .subscribe((disconnectData) => {
                    this.logger.endTime();
                    this.logger.log("info", "existing-products.component.ts", "initDisconnectResponse", JSON.stringify(disconnectData));
                    this.logger.log("info", "existing-products.component.ts", "initDisconnectSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let scheduleObj = {
                        orderRefNumber: disconnectData.orderRefNumber,
                        processInstanceId: disconnectData.processInstanceId,
                        taskId: disconnectData.taskId,
                        taskName: disconnectData.taskName,
                        payload: disconnectData.payload
                    };
                    this.store.dispatch({ type: 'SCHEDULING', payload: scheduleObj });
                    let appointmentObj = {
                        success: true,
                        orderRefNumber: disconnectData.orderRefNumber,
                        processInstanceId: disconnectData.processInstanceId,
                        taskId: disconnectData.taskId,
                        taskName: disconnectData.taskName,
                        payload: disconnectData.payload
                    };
                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
                    this.router.navigate(['/disconnect-schedule']);
                });
        } else {
            this.router.navigate(['/product-offer']);
        }
        if (taskNameFromResponse === "Confirm Scheduling" || taskNameFromResponse === "Schedule Disconnect Date") {
            data.payload.cart = customerOrderItems;
            let cartObjToDispatch = {
                payload: {
                    cart: customerOrderItems
                }
            };
            this.store.dispatch({ type: 'CREATE_CART', payload: cartObjToDispatch });
            let scheduleObj = {
                orderRefNumber: data.orderRefNumber,
                processInstanceId: data.processInstanceId,
                taskId: data.taskId,
                taskName: data.taskName,
                payload: data.payload
            };
            this.store.dispatch({ type: 'SCHEDULING', payload: scheduleObj });
            let vacationscheduleObj = {
                orderRefNumber: data.orderRefNumber,
                processInstanceId: data.processInstanceId,
                taskId: data.taskId,
                taskName: data.taskName,
                payload: data.payload
            };
            this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
            this.store.dispatch({ type: 'VACATIONSCHEDULING', payload: vacationscheduleObj });
            let cartObj = {
                orderRefNumber: data.orderRefNumber,
                processInstanceId: data.processInstanceId,
                taskId: data.taskId,
                taskName: data.taskName,
                payload: data.payload
            };
            this.store.dispatch({ type: 'ADD-ONS', payload: cartObj });
            let selectProduct = {
                taskName: 'Select Product'
            };
            this.store.dispatch({ type: 'SELECT_PRODUCT', payload: selectProduct });
            let appointmentObj = {
                success: true,
                orderRefNumber: data.orderRefNumber,
                processInstanceId: data.processInstanceId,
                taskId: data.taskId,
                taskName: data.taskName,
                payload: data.payload
            };
            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
            this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: appointmentObj });
            if (flow === "BILLANDREC") {
                this.router.navigate(['/billing-schedule-appt-ship']);
            } else if (flow === "DISCONNECT") {
                this.router.navigate(['/disconnect-schedule']);
            } else if (flow === "VACATIONSUSPEND" || flow === "VACATIONRESTORE") {
                this.router.navigate(['/vacation-schedule-appt-ship']);
            } else {
                if (flow === 'MOVE') {
                    this.existDataDispatch(data, orderFlow);
                    this.router.navigate(['/move-product']);
                } else if (flow === 'CHANGE') {
                    this.existDataDispatch(data, orderFlow);
                } else if (flow === 'BILLANDREC') {
                    this.existDataDispatch(data, orderFlow);
                    this.router.navigate(['/billing-product']);
                } else {
                    this.router.navigate(['/product-offer']);
                }
            }
            this.store.dispatch({ type: 'UPDATE_USER', payload: { oTCustomize: true } });
        }
        if (flow !== 'CHANGE')
            this.loading = false;
    }
    public getOrderTypeText(value: any) {
        return this.pendingOrderService.setOrderTypeText(value);
    }
    public stackAmendPopupDecider(popupObj, flag) {
        let flagPonr = "AnyThingButPENDING_ORDER_CROSSED_PONR";
        this.flagMakeChange = flag;
        this.unabletoStackMsg = '';
        //Getting the CON allowed for amend in case of multiple pending orders
        if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders
            && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 1 && Switch.amendMultiple) {
            if (this.existingProductsResponse.existingProductsAndServices
                && this.existingProductsResponse.existingProductsAndServices.length > 0
                && this.existingProductsResponse.existingProductsAndServices[0].validateResponse
                && this.existingProductsResponse.existingProductsAndServices[0].validateResponse.length > 0
                && this.existingProductsResponse.existingProductsAndServices[0].validateResponse[0].stackValidation) {
                this.existingProductsResponse.existingProductsAndServices[0].validateResponse[0].stackValidation.map((supAllowed) => {
                    if (supAllowed.attributeName === 'sup3AllowedOnStack') {
                        this.sup3AllowedOnCon = supAllowed.attributeValue;
                    }
                });
            }
            this.store.dispatch({ type: 'SUP3_ALLOWED_CON', payload: this.sup3AllowedOnCon });
        }
        if (this.suspendActive) {
            this.getToSuspendText()
        } else if (this.isVacSusActiveOnAccount) {
            this.canNotStartChangeOrder.open();
        } else {
            if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 2) {
                this.unabletoStackMsg = 'multiple';
                this.unableToStack.open();
            } else if (this.isJeopardy) {
                this.unabletoStackMsg = 'jeopardy';
                this.unableToStack.open();
            } else if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders &&
                this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus === 'IN-JEOPARDY') {
                this.unabletoStackMsg = 'jeopardy';
                this.unableToStack.open();
            } else if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0 && this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders &&
                this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length > 0 && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus === 'HOLD') {
                this.unabletoStackMsg = 'hold';
                this.unableToStack.open();
            } else if (this.pendingOrder && this.pendingOrder.orderReference && (this.pendingOrder.orderReference.customerOrderType === "VACATIONSUSPEND" || this.pendingOrder.orderReference.customerOrderType === "NONPAYSUSPEND" || this.pendingOrder.orderReference.customerOrderType === "NONPAYRESTORE" || this.pendingOrder.orderReference.customerOrderType === "DISCONNECT" || this.pendingOrder.orderReference.customerOrderType === "MOVE" || this.pendingOrder.orderReference.customerOrderType === "BILLANDREC")) {
                if (this.pendingOrder.orderReference.customerOrderType === "VACATIONSUSPEND") this.unabletoStackMsg = 'vacation';
                if (this.pendingOrder.orderReference.customerOrderType === "NONPAYSUSPEND" || this.pendingOrder.orderReference.customerOrderType === "NONPAYRESTORE") this.unabletoStackMsg = 'nopay';
                if (this.pendingOrder.orderReference.customerOrderType === "DISCONNECT") this.unabletoStackMsg = 'disconnect';
                if (this.pendingOrder.orderReference.customerOrderType === "MOVE") this.unabletoStackMsg = 'move';
                if (this.pendingOrder.orderReference.customerOrderType === "BILLANDREC") this.unabletoStackMsg = 'billandrec';
                this.orderType = this.pendingOrderService.setOrderTypeText(this.pendingOrder.orderReference.customerOrderType);
                this.unableToStack.open();
            } else if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0
                && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length === 1
                && flagPonr !== "PENDING_ORDER_CROSSED_PONR"
                && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderStatus.toUpperCase() === 'PENDING') {
                if (this.existingProductsResponse.stackamend.isStackAllowed === 'true' && this.existingProductsResponse.stackamend.isAmendAllowed === 'true') {
                    popupObj.open();
                } else if (this.existingProductsResponse.stackamend.isStackAllowed === 'true' && this.existingProductsResponse.stackamend.isAmendAllowed === 'false') {
                    let amendCheckForAgents: boolean = this.amendEligibilityCheckForAgents();
                    if (amendCheckForAgents) {
                        popupObj.open();
                    } else {
                        if (this.existingProductsResponse.stackamend.isStackAllowed === 'true' && !this.isPrepaid) {
                            this.onEmitStackAmend('stackOrder')
                            this.loading = true;
                        } else if (this.existingProductsResponse.stackamend.isAmendAllowed === 'false') {
                            this.unabletoAmendMsg = 'default';
                            this.unableToAmend.open();
                        } else {
                            this.unabletoAmendMsg = 'default';
                            this.unableToAmend.open();
                        }
                    }
                } else if (this.existingProductsResponse.stackamend.isStackAllowed === 'false' && this.existingProductsResponse.stackamend.isAmendAllowed === 'true') {
                    this.onEmitStackAmend('amendOrder');
                    this.loading = true;
                } else if (this.existingProductsResponse.stackamend.isStackAllowed === 'false' && this.existingProductsResponse.stackamend.isAmendAllowed === 'false') {
                    let amendCheckForAgents: boolean = this.amendEligibilityCheckForAgents();
                    if (amendCheckForAgents) {
                        this.onEmitStackAmend('amendOrder')
                        this.loading = true;
                    } else {
                        this.orderType = this.pendingOrderService.setOrderTypeText(this.existingProductsResponse.existingProductsAndServices[0].pendingOrders[0].orderReference.customerOrderType);
                        let exsPrdRes = this.existingProductsResponse.existingProductsAndServices[0].validateResponse[0];
                        exsPrdRes && exsPrdRes.stackValidation && exsPrdRes.stackValidation.map(a => {
                            if (a.attributeName === "stackIneligibleReasonCode" && a.attributeValue.indexOf("PORTIN") !== -1) {
                                this.unabletoStackMsg = 'portin';
                            } else if (a.attributeName === "stackIneligibleReasonCode" && a.attributeValue.indexOf("ORDER_TYPE_NOT_SUPPORTED") !== -1) {
                                this.unabletoStackMsg = 'orderNotSupport';
                            }
                        })
                        this.unableToStack.open();
                    }
                } else {
                    this.goToChangeProduct();
                }
            } else if (this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices.length > 0
                && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders && this.existingProductsResponse.existingProductsAndServices[0].pendingOrders.length === 2) {
                if (this.sup3AllowedOnCon) {
                    this.onEmitStackAmend('amendOrder');
                    this.loading = true;
                } else {
                    if (Switch.amendMultiple) {
                        this.unabletoAmendMsg = 'laterorder';
                        this.unableToAmend.open();
                    } else {
                        this.unabletoStackMsg = 'multiple';
                        this.unableToStack.open();
                    }
                }
            } else {
                this.goToChangeProduct();
            }
        }
    }
    public amendEligibilityCheckForAgents(): boolean {
        let amendIneligiblecheck: boolean = false;
        let amendProfileCheck: boolean = false;
        this.existingProductsResponse && this.existingProductsResponse.existingProductsAndServices && this.existingProductsResponse.existingProductsAndServices[0] &&
            this.existingProductsResponse.existingProductsAndServices[0].validateResponse && this.existingProductsResponse.existingProductsAndServices[0].validateResponse[0] &&
            this.existingProductsResponse.existingProductsAndServices[0].validateResponse[0].amendValidation &&
            this.existingProductsResponse.existingProductsAndServices[0].validateResponse[0].amendValidation.map(amend => {
                if (amend.attributeName.trim() === 'amendIneligibleExceptionCode' && amend.attributeValue.trim() === 'DueTodayOrPast') {
                    amendIneligiblecheck = true;
                }
            });
        amendProfileCheck = this.helperService.isAuthorized(ProfileEnums.ALLOW_CURRENT_DUE_DATE);
        if (amendIneligiblecheck && amendProfileCheck) {
            return true;
        } else {
            this.unabletoAmendMsg = 'Order is PONR';
            return false;
        }
    }
    public onEmitStackAmend(stackAmendFlag) {
        let payload = this.existingProductsResponse.stackamend
        payload['stackAmendFlag'] = stackAmendFlag;
        if (stackAmendFlag === 'stackOrder') {
            this.flagStackOrder = true;
            this.flagAmendOrder = false;
        } else if (stackAmendFlag === 'amendOrder') {
            this.flagStackOrder = false;
            this.flagAmendOrder = true;
        }
        this.store.dispatch({ type: 'STACK_AMEND', payload: payload });
        this.store.dispatch({ type: 'NI_PENDING_STACK_AMEND', payload: this.isOrderNIPending });
        this.flagIsStackAmendCall = true;
        this.goToChangeProduct();
    }
    private existDataDispatch(existingData: any, orderFlow) {
        let existingObject;
        let pendingSubscription;
        let refreshSessionObservable = <Observable<any>>this.store.select('pending');
        let sfdcAccountId, sfdcBillingAccountID, agentFullName, agentCuid, firstName, lastName, ensembleId;
        this.user.subscribe((data) => {
            if (data.autoLogin !== null && data.autoLogin !== undefined) {
                if (data.autoLogin.sfcData) {
                    sfdcAccountId = data.autoLogin.sfcData.sfdcID ? data.autoLogin.sfcData.sfdcID : '';
                    sfdcBillingAccountID = data.autoLogin.sfcData.sfdcBillingAccountID ? data.autoLogin.sfcData.sfdcBillingAccountID : '';
                }
                if (data.autoLogin.oamData) {
                    agentCuid = data.autoLogin && data.autoLogin.oamData.agentCuid ? data.autoLogin.oamData.agentCuid : '';
                    firstName = data.autoLogin && data.autoLogin.oamData.agentFirstName;
                    lastName = data.autoLogin && data.autoLogin.oamData.agentLastName;
                    agentFullName = data.autoLogin.oamData.agentFullName ? data.autoLogin.oamData.agentFullName : '';
                    ensembleId = data.autoLogin && data.autoLogin.oamData.ensembleId ? data.autoLogin.oamData.ensembleId : '';
                }
            }
        })
        pendingSubscription = refreshSessionObservable.subscribe(pending => {
            if (pending && pending.orderDocument) {
                existingObject = { existingProductsAndServices: [pending && pending.orderDocument] }
            } else {
                existingObject = { existingProductsAndServices: existingData.existingProductsAndServices }
            }
            existingObject.orderFlow = orderFlow;
        });
        if (pendingSubscription !== undefined) pendingSubscription.unsubscribe();
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
        this.loading = true;
        let serviceCategories;
        let banRequest = { "ban": existingObject.existingProductsAndServices[0].accountInfo.ban, "salesChannel": "ESHOP-Customer Care" };
        this.logger.log("info", "existing-products.component.ts", "getOrderSummaryRequest", JSON.stringify(banRequest));
        this.logger.startTime();
        this.pendingOrderService.getOrderSummary(banRequest)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "getOrderSummaryResponse", error);
                this.logger.log("error", "existing-products.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (error && error.status === 404) {
                    this.ctlHelperService.setLocalStorage('getOrderByBANOrCOR-Call', true);
                } else {
                    this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "pendingSummary - getOrderSummary", "existing-products.component.ts", "Address Page", error);
                    return Observable.throwError(null);
                }
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "existing-products.component.ts", "getOrderSummaryResponse", JSON.stringify(data));
                    this.logger.log("info", "existing-products.component.ts", "getOrderSummarySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices.length > 0 && data.existingProductsAndServices[0].telephoneNumber) {
                        this.store.dispatch({ type: 'EXISTING_TN', payload: data.existingProductsAndServices[0].telephoneNumber });
                    }
                    serviceCategories = data.existingProductsAndServices[0].serviceCategory;
                    let request;
                    request = {
                        ban: data.existingProductsAndServices[0].accountInfo.ban,
                        customerOrderType: "CHANGE",
                        orderRefNumber: existingData.orderReference && existingData.orderReference.orderReferenceNumber ? existingData.orderReference.orderReferenceNumber : existingData.existingProductsAndServices[0].pendingOrders[0].orderReference.orderReferenceNumber,
                        party: {
                            id: agentCuid,
                            firstName: firstName,
                            lastName: lastName,
                            type: "CSR",
                            partyRoles: [
                                {
                                    partyRole: env.CSR_NAME,
                                    sourceSystem: env.CSR_PROFILE,
                                    id: agentCuid
                                },
                                {
                                    partyRole: env.ENSEMBLEID,
                                    sourceSystem: env.ENS_OPERATOR,
                                    id: ensembleId
                                }
                            ]
                        },
                        salesChannel: "ESHOP-Customer Care",
                        serviceAddress: {
                            city: "",
                            country: "",
                            geoAddressId: "",
                            locality: "",
                            postCode: "",
                            postCodeSuffix: "",
                            source: "",
                            sourceId: "",
                            stateOrProvince: "",
                            streetAddress: "",
                            streetName: "",
                            streetNrFirst: "",
                            streetNrFirstSuffix: "",
                            streetNrLast: "",
                            streetNrLastSuffix: "",
                            streetType: "",
                            subAddress: {
                                combinedDesignator: "",
                                elements: {
                                    designator: "",
                                    value: ""
                                },
                                geoSubAddressId: "",
                                source: "",
                                sourceId: ""
                            }
                        },
                    }
                    if (sfdcBillingAccountID && sfdcAccountId) {
                        request.sfdcAccountId = (sfdcBillingAccountID ? sfdcBillingAccountID + ':' : '') + (sfdcAccountId ? sfdcAccountId : '');
                    }
                    if (data && data.existingProductsAndServices && data.existingProductsAndServices[0]) {
                        let internetCheck;
                        let videoAvail;
                        let phoneAvail: boolean = false;
                        let phoneType = [];
                        let videoType = [];
                        if (serviceCategories !== undefined) {
                            serviceCategories.map((item) => {
                                if (item.serviceCategory === GenericValues.sData) {
                                    internetCheck = true;
                                }
                                if (item.serviceCategory === 'DATA/VIDEO') {
                                    videoAvail = true;
                                    videoType.push({
                                        name: 'DATA/VIDEO',
                                        displayName: 'PRISM TV',
                                        code: 'PTV',
                                        tabName: 'PRISM'
                                    });
                                }
                                if (item.serviceCategory === 'VIDEO-DTV') {
                                    videoAvail = true;
                                    videoType.push({
                                        name: 'VIDEO-DTV',
                                        displayName: 'DIRECTV',
                                        code: 'DTV',
                                        tabName: 'DIRECTV'
                                    });
                                }
                                if (item.serviceCategory === 'VOICE-DHP') {
                                    phoneAvail = true;
                                    phoneType.push({
                                        name: 'VOICE-DHP',
                                        displayName: 'Digital(DHP)',
                                        code: 'DHP',
                                        tabName: 'DHP'
                                    });
                                }
                                if (item.serviceCategory === 'VOICE-HP') {
                                    phoneAvail = true;
                                    phoneType.push({
                                        name: 'VOICE-HP',
                                        displayName: 'Home Phone',
                                        code: 'HMP',
                                        tabName: 'Home Phone'
                                    });
                                }
                            });
                        }
                        let user: User = {
                            id: 1,
                            internetCheck,
                            videoCheck: videoAvail,
                            phoneCheck: phoneAvail,
                            phoneType: phoneType,
                            videoType: videoType,
                            enabledServiceList: serviceCategories,
                            ban: data.existingProductsAndServices[0].accountInfo.ban
                        };
                        this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
                    }
                    if (orderFlow.flow === 'Change') {
                        this.loading = true;
                        this.logger.log("info", "existing-products.component.ts", "getInitChangeCallRequest", JSON.stringify(request));
                        this.logger.startTime();
                        this.addressService.getInitChangeCall(request)
                            .catch((error: any) => {
                                this.logger.endTime();
                                this.logger.log("error", "existing-products.component.ts", "getInitChangeCallResponse", error);
                                this.logger.log("error", "existing-products.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                                return Observable.throwError(null);
                            })
                            .subscribe(
                                (address) => {
                                    this.logger.endTime();
                                    this.logger.log("info", "existing-products.component.ts", "getInitChangeCallResponse", JSON.stringify(address));
                                    this.logger.log("info", "existing-products.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                    data.orderInit = address;
                                    this.store.dispatch({ type: 'TASK_ID', payload: address.taskId });
                                    this.store.dispatch({ type: 'CHANGE_ORDER_INIT', payload: address });
                                    this.router.navigate(['/offer-change']);
                                },
                                (error) => {
                                    this.logger.endTime();
                                    this.logger.log("error", "existing-products.component.ts", "getInitChangeCallResponse", error);
                                    this.logger.log("error", "existing-products.component.ts", "getInitChangeCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                    this.loading = false;
                                    if (error === undefined || error === null)
                                        return;
                                    let unexpectedError = false;
                                    if (this.ctlHelperService.isJson(error)) {
                                        this.apiResponseError = JSON.parse(error);
                                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Address Page", this.apiResponseError);
                                        } else unexpectedError = true;
                                    } else unexpectedError = true;
                                    if (unexpectedError) {
                                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Address Page", lAPIErrorLists);
                                    }
                                });
                    } else if (existingData && existingData.orderReference && existingData.orderReference.customerOrderType === 'BILLANDREC') {
                        this.store.dispatch({ type: 'BAN', payload: banRequest.ban });
                        let changedAddress = false;
                        let serviceAddress: any;
                        if (existingData.orderDocument && existingData.orderDocument.serviceAddress) {
                            serviceAddress = existingData.orderDocument.serviceAddress;
                            if (existingData.orderDocument && existingData.orderDocument.existingServiceAddress &&
                                existingData.orderDocument.existingServiceAddress.streetAddress !==
                                existingData.orderDocument.serviceAddress.streetAddress) {
                                changedAddress = true;
                            }
                        }
                        let billRequest = {
                            "ban": banRequest.ban,
                            "salesChannel": "ESHOP-Customer Care",
                            "customerOrderType": "BILLANDREC",
                            "serviceAddressChanged": changedAddress ? 'Yes' : 'No',
                            "serviceAddress": {
                                "addressLine": "",
                                "streetAddress": "",
                                "streetNrFirst": serviceAddress && serviceAddress.streetNrFirst,
                                "streetNrLast": "",
                                "streetNrLastSuffix": "",
                                "streetName": serviceAddress && serviceAddress.streetName,
                                "streetNamePrefix": "",
                                "streetType": "",
                                "locality": serviceAddress && serviceAddress.locality,
                                "city": serviceAddress && serviceAddress.city,
                                "stateOrProvince": serviceAddress && serviceAddress.stateOrProvince,
                                "postCode": serviceAddress && serviceAddress.postCode,
                                "postCodeSuffix": serviceAddress && serviceAddress.postCodeSuffix,
                                "geoAddressId": serviceAddress && serviceAddress.geoAddressId,
                                "sourceId": serviceAddress && serviceAddress.sourceId,
                                "source": serviceAddress && serviceAddress.source,
                                "subAddress": serviceAddress && serviceAddress.subAddress,
                                "country": serviceAddress && serviceAddress.country
                            },
                            "party": {
                                id: agentCuid,
                                firstName: firstName,
                                lastName: lastName,
                                type: 'CSR',
                                partyRoles: [
                                    {
                                        partyRole: env.CSR_NAME,
                                        sourceSystem: env.CSR_PROFILE,
                                        id: agentCuid
                                    },
                                    {
                                        partyRole: env.ENSEMBLEID,
                                        sourceSystem: env.ENS_OPERATOR,
                                        id: ensembleId
                                    }
                                ]
                            }
                        }
                        this.loading = true;
                        this.logger.log("info", "existing-products.component.ts", "billingFromHoldRequest", JSON.stringify(billRequest));
                        this.logger.startTime();
                        this.addressService.billingFromHold(billRequest)
                            .catch((error: any) => {
                                this.logger.endTime();
                                this.logger.log("error", "existing-products.component.ts", "billingFromHoldResponse", error);
                                this.logger.log("error", "existing-products.component.ts", "billingFromHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                if (error && error.status === 404) {
                                    this.ctlHelperService.setLocalStorage('getOrderByBANOrCOR-Call', true);
                                } else {
                                    this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "billingandrecords - removeHold", "existing-products.component.ts", "Address Page", error);
                                    return Observable.throwError(null);
                                }
                            })
                            .subscribe(
                                (data) => {
                                    this.logger.endTime();
                                    this.logger.log("info", "existing-products.component.ts", "billingFromHoldResponse", JSON.stringify(data));
                                    this.logger.log("info", "existing-products.component.ts", "billingFromHoldSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                    let response = data;
                                    let internetCheck;
                                    let videoAvail;
                                    let phoneAvail: boolean = false;
                                    let phoneType = [];
                                    let videoType = [];
                                    if (this.addressService.checkCategoryId('DATA', response.payload.serviceCategory) !== undefined) {
                                        internetCheck = true;
                                    }
                                    if (this.addressService.checkCategoryId('DATA/VIDEO', response.payload.serviceCategory) !== undefined) {
                                        videoAvail = true;
                                        videoType.push({
                                            name: 'DATA/VIDEO',
                                            displayName: 'PRISM TV',
                                            code: 'PTV',
                                            tabName: 'PRISM'
                                        });
                                    }
                                    if (this.addressService.checkCategoryId('VIDEO-DTV', response.payload.serviceCategory) !== undefined) {
                                        videoAvail = true;
                                        videoType.push({
                                            name: 'VIDEO-DTV',
                                            displayName: 'DIRECTV',
                                            code: 'DTV',
                                            tabName: 'DIRECTV'
                                        });
                                    }
                                    if (this.addressService.checkCategoryId('VOICE-DHP', response.payload.serviceCategory) !== undefined) {
                                        phoneAvail = true;
                                        phoneType.push({
                                            name: 'VOICE-DHP',
                                            displayName: 'Digital(DHP)',
                                            code: 'DHP',
                                            tabName: 'DHP'
                                        });
                                    }
                                    if (this.addressService.checkCategoryId('VOICE-HP', response.payload.serviceCategory) !== undefined) {
                                        phoneAvail = true;
                                        phoneType.push({
                                            name: 'VOICE-HP',
                                            displayName: 'Home Phone',
                                            code: 'HMP',
                                            tabName: 'Home Phone'
                                        });
                                    }
                                    let user: User = {
                                        id: 1,
                                        internetCheck,
                                        videoCheck: videoAvail,
                                        phoneCheck: phoneAvail,
                                        phoneType: phoneType,
                                        videoType: videoType,
                                        enabledServiceList: response.payload.serviceCategory
                                    };
                                    this.store.dispatch({ type: 'CHANGE_UPDATE_USER', payload: user });
                                    this.store.dispatch({ type: 'UPDATE_USER', payload: user });
                                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                    this.store.dispatch({ type: 'ADD_ORDER_INIT', payload: data });
                                    this.store.dispatch({ type: 'INCLUDING_GIFTCARDS', payload: data.payload.giftCardOffers });
                                    this.store.dispatch({ type: 'INCLUDING_OFFERS', payload: data.payload.offers })
                                    this.router.navigate(['/billing-product']);
                                })
                    }
                },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "billingFromHoldInitResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "billingFromHoldInitSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "existDataDispatch", "existing-products.component.ts", "CustomizeService Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "existDataDispatch", "existing-products.component.ts", "Address Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }
    @ViewChild('vacationSuspend', { static: false, }) public vacationSuspend: DialogComponent;
    @ViewChild('vacationRestore', { static: false, }) public vacationRestore: DialogComponent;
    @ViewChild('vacationServiceNotAvailable', { static: false, }) public vacationServiceNotAvailable: DialogComponent;
    @ViewChild('canNotStartMoveOrder', { static: false, }) public canNotStartMoveOrder: DialogComponent;
    @ViewChild('canNotStartChangeOrder', { static: false, }) public canNotStartChangeOrder: DialogComponent;
    @ViewChild('canNotStartBillingOrder', { static: false, }) public canNotStartBillingOrder: DialogComponent;
    @ViewChild('stackAmendPopup', { static: false, }) public stackAmendPopup: DialogComponent;
    @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: VacationDialogComponent;
    @ViewChild('recommendedError', { static: false, }) public recommendedError: DialogComponent;
    public suspendIneligibilityReason: string;
    public initializeVacationService() {
        if (!this.otherOrderActivitiesAllowed && this.pendingOrder.orderReference.customerOrderStatus === "PENDING") {
            this.unabletoStackMsg = 'vacation';
            this.otherOrderActivitiesDropdownSelected = 'Vacation Service';
            this.unableToStack.open();
            return;
        }
        let request;
        this.vacationsuspendflow = true;
        this.store.dispatch({ type: 'VACATION_FLOW', payload: this.vacationsuspendflow });
        this.store.dispatch({ type: 'VACATION_FLOW_NAME', payload: { isVacSusFlow: this.isVacationSuspendFlow, isVacResFlow: this.isVacationRestoreFlow } });
        if (this.sfdcBillingAccountID && this.sfdcAccountId) {
            this.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
        }
        request = {
            ban: this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban,
            salesChannel: "ESHOP-Customer Care",
            sfdcAccountId: this.sfdcAccountId,
            orderRefNumber: this.resetOrderRefNumber ? undefined : this.orderRefNumber,
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            }
        };
        if (this.recommendedItems && !this.recommendedErrorOpened && !this.changeTabSelected) {
            request.recommendedItems = cloneDeep(this.recommendedItems);
        }
        if (this.isVacationSuspendFlow) {
            request.orderAction = 'VACATIONSUSPEND';
        }
        if (this.isVacationRestoreFlow) {
            request.orderAction = 'VACATIONRESTORE';
        }
        request = this.addAddlOrderAttributes(request);
        this.loading = true;
        this.logger.log("info", "existing-products.component.ts", "initVacationCallRequest", JSON.stringify(request));
        this.logger.startTime();
        this.bMService.initVacationCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "initVacationCallResponse", error);
                this.logger.log("error", "existing-products.component.ts", "initVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", " ", "initVacationCall", "existing-products.component.ts", "Existing Products Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "existing-products.component.ts", "initVacationCallResponse", JSON.stringify(data));
                this.logger.log("info", "existing-products.component.ts", "initVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.ctlHelperService.storeRequestProcessData(data, 'existing-products', 'init', 'vacation');
                if (this.isVacationSuspendFlow) {
                    /**
                     * TODO due data not availability mocking discounts[]
                     */
                    data.payload.retrievalTypes[0].offers[0].catalogs[0].catalogItems.map(ci => {
                        if(ci.productOffer.offerCategory === "INTERNET" && ci.productOffer.offerName === "HSI Vacation"){
                            ci.productOffer.productComponents.map(pc => {
                                if(pc.componentType === "PRIMARY") {
                                    pc.product.productAttributes.map(pa => {
                                        /* if(pa.prices !== null && pa.prices !== undefined && pa.isPriceable === true && pa.discounts.length === 0) {
                                            pa.discounts = [{
                                                "autoAttachInd": "Y",
                                                "discountId": "8261KQ",
                                                "discountDescription": "Vacation HSI Discount 6 Mos",
                                                "discountRate": 9.99,
                                                "discountMethod": "D",
                                                "discountLevel": "P",
                                                "discountDuration": 6,
                                                "discountType": "R",
                                                "discountCategory": "RCD",
                                                "discountMaxAmount": 0,
                                                "discountMinimumAmount": 0,
                                                "discountRule": "A",
                                                "discountIdSequence": 1000
                                            }];
                                        }  */
                                        /* else if(pa.prices !== null && pa.prices !== undefined && pa.isPriceable === true) {
                                            pa.discounts = [{
                                                "autoAttachInd": "N",
                                                "discountId": "8261KQ",
                                                "discountDescription": "Vacation HSI Discount 6 Mos",
                                                "discountRate": 9.99,
                                                "discountMethod": "D",
                                                "discountLevel": "P",
                                                "discountDuration": 6,
                                                "discountType": "R",
                                                "discountCategory": "RCD",
                                                "discountMaxAmount": 0,
                                                "discountMinimumAmount": 0,
                                                "discountRule": "A",
                                                "discountIdSequence": 1000
                                            }];
                                        } */
                                    })
                                }
                            })
                        }
                    })
                    this.store.dispatch({ type: 'VACATION_SUSPEND_INIT_RESPONSE', payload: data });
                    if (data && data.payload && data.payload.suspendEligibilityFlag && (data.payload.suspendEligibilityFlag.toUpperCase() === 'YES')) {
                        if (this.isPOTSExisintgProduct && data.payload && data.payload.retrievalTypes && (data.payload.retrievalTypes.length > 0)) {
                            data.payload.retrievalTypes.map((retType) => {
                                if (retType && retType.offers && (retType.offers.length > 0)) {
                                    retType && retType.offers && retType.offers.map((offer) => {
                                        if (offer.serviceCategory && (offer.serviceCategory.toUpperCase() === 'VOICE-HP')) {
                                            offer.catalogs && offer.catalogs.map((catalog) => {
                                                catalog && catalog.catalogItems && catalog.catalogItems.map((catalogItem) => {
                                                    if (catalogItem && catalogItem.productOffer && (catalogItem.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_SUS_OFFER_NAME.toUpperCase())) {
                                                        this.store.dispatch({ type: 'VACATION_VOICE_HP_OFFER', payload: { retrievalTypes: [{ offers: [{ catalogs: offer.catalogs }] }] } });
                                                    }
                                                });
                                            });
                                        }
                                    })
                                }
                            });
                        }
                        this.vacationSuspend.open();
                    } else if (data && data.payload && data.payload.suspendEligibilityFlag && (data.payload.suspendEligibilityFlag.toUpperCase() === 'NO')) {
                        if (data.payload.suspendIneligibilityReason.toUpperCase() === 'LOCATION')
                            this.suspendIneligibilityReason = 'LOCATION';
                        else
                            this.suspendIneligibilityReason = 'ACCOUNT';
                        this.vacationServiceNotAvailable.open();
                    }
                } else if (this.isVacationRestoreFlow) {
                    this.serviceCategory();
                    this.store.dispatch({ type: 'VACATION_RESTORE_INIT_RESPONSE', payload: data });
                    this.store.dispatch({ type: 'CHANGE_ORDER_INIT', payload: data });
                    this.store.dispatch({ type: 'IS_OFFER_PAGE_CONTINUE_ALLOWED', payload: true });
                    if (this.isPOTSExisintgProduct) {
                        data && data.payload && data.payload.retrievalTypes && data.payload.retrievalTypes.map((retType) => {
                            retType && retType.offers && retType.offers.map((offer) => {
                                if (offer.serviceCategory && (offer.serviceCategory.toUpperCase() === 'VOICE-HP')) {
                                    offer.catalogs && offer.catalogs.map((catalog) => {
                                        catalog && catalog.catalogItems && catalog.catalogItems.map((catalogItem) => {
                                            if (catalogItem && catalogItem.productOffer && (catalogItem.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_RES_OFFER_NAME.toUpperCase())) {
                                                this.store.dispatch({ type: 'VACATION_VOICE_HP_OFFER', payload: { retrievalTypes: [{ offers: [{ catalogs: offer.catalogs }] }] } });
                                            }
                                        });
                                    });
                                }
                            });
                        });
                    }
                    this.vacationRestore.open();
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "initVacationCallResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "initVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) return;
                    this.systemErrorService.getAPIResponseError(error, 'INIT', 'existing-products.component.ts', 'Existing Products Page');
                });
    }
    public selectSuspendRestore() {
        if (!this.otherOrderActivitiesAllowed && this.pendingOrder.orderReference.customerOrderStatus === "PENDING" && this.pendingOrder.orderReference.customerOrderType !== "NONPAYSUSPEND") {
            this.unabletoStackMsg = 'suspendOrRestore';
            this.otherOrderActivitiesDropdownSelected = 'suspendOrRestore';
            this.RestoreProdPending.open()
            return;
        }
        this.loading = true;
        this.store.dispatch({ type: 'NON-PAY-RESTOREALL', payload: this.restoreAllProd });
        let req = {
            ban: this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban,
            salesChannel: "ESHOP-Customer Care",
            party: {
                firstName: this.firstName,
                id: this.agentCuid,
                type: "CSR",
                lastName: this.lastName,
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            }
        }
        this.logger.log("info", "existing-products.component.ts", "initNonPaySuspendRequest", JSON.stringify(req));
        this.logger.startTime();
        this.bMService.initNonpaySupspend(req)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "initNonPaySuspendResponse", JSON.stringify(error));
                this.logger.log("error", "existing-products.component.ts", "initNonPaySuspendSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.ctlHelperService.setLocalStorage("error", error);
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "Init", "existing-Products.component.ts", "Existing Products Page", error);
                return Observable.throwError(null);
            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "existing-products.component.ts", "initNonPaySuspendResponse", JSON.stringify(data));
                this.logger.log("info", "existing-products.component.ts", "initNonPaySuspendSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.router.navigate(['/nonpay-suspend']);
                this.store.dispatch({ type: 'NON-PAY-SUSPEND_INIT_RES', payload: data });
            },
            (error) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "initNonPaySuspendResponse", error);
                this.logger.log("error", "existing-products.component.ts", "initNonPaySuspendSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                let unexpectedError = false;
                if (this.ctlHelperService.isJson(error)) {
                    this.apiResponseError = JSON.parse(error);
                    if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                        this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT-NonPaysuspendResponse", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                    } else unexpectedError = true;
                } else unexpectedError = true;
                if (unexpectedError) {
                    let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                    this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "INIT-NonPaysuspendResponse", "Existing Products Page", lAPIErrorLists);
                }
            });
    }
    public addAddlOrderAttributes(request: any): any {
        let addlOrderAttributes = [
            {
                orderAttributeGroup: [
                    {
                        orderAttributeGroupName: "sfcAttrData",
                        orderAttributeGroupInfo: [
                            {
                                orderAttributes: [
                                    {
                                        orderAttributeName: "tfn",
                                        orderAttributeValue: this.tfn
                                    },
                                    {
                                        orderAttributeName: "ucid",
                                        orderAttributeValue: this.ucid
                                    },
                                    {
                                        orderAttributeName: "callStartTime",
                                        orderAttributeValue: this.callStartTime
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ];
        request.addlOrderAttributes = addlOrderAttributes;
        return request;
    }
    public retrievePhoneOffer(offerDataLinkURL) {
        this.loading = true;
        this.productService.getOffersFromLink(offerDataLinkURL)
            .catch((error: any) => {
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "Link - getOffersFromLink", "offer.component.ts", "Product Offer Page", error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.loading = false;
                    this.store.dispatch({ type: 'VACATION_VOICE_HP_OFFER', payload: data });
                },
                (error) => {
                    this.loading = false;
                    this.systemErrorService.getAPIResponseError(error, 'getPhoneOffer', 'vacation-dialog.component.ts', 'Existing Product Page');
                }
            );
    }
    public interpolationCount = 0;
    public getIndividualPrices(prices) {
        this.interpolationCount++;
        const getDisplayPrice = (price) => {
            let displayPrice = "";
            if (!isNaN(price)) {
                displayPrice = parseFloat(price).toFixed(2);
            }
            return displayPrice;
        }
        const individualPrices = prices.reduce((accumulator, priceItem) => {
            accumulator[priceItem.priceTypeDescription] = {
                ...priceItem,
                displayPrice: getDisplayPrice(priceItem.discountedRc)
            };
            return accumulator;
        }, {});
        const getSubscriberAndAccessPrices = (allPrices) => getDisplayPrice(allPrices["Access Recovery Charge"].discountedRc + allPrices["Subscriber Line Charge"].discountedRc);
        const subscriberAndAccessPrice = getSubscriberAndAccessPrices(individualPrices);
        return this.sanitizer.bypassSecurityTrustHtml(`
        <div>
          <span style="margin-left:100px">1Pty Residential Line</span>
          <span style="float: right; margin-right:15px">
              $${individualPrices["MRC/OTC"].displayPrice}
          </span>
        </div>
        <div>
          <span style="margin-left:100px">Subscriber Line & Access Recovery Charge</span>
          <span style="float: right; margin-right:15px">
              $${subscriberAndAccessPrice}
          </span>
        </div>
        ${individualPrices["Facility Relocation Fee RES"] !== undefined &&
                individualPrices["Facility Relocation Fee RES"].discountedRc !== undefined ?
                `<div>
            <span style="margin-left: 100px">Facility Relocation Cost Recovery Fee</span>
            <span style="float: right; margin-right:15px">
              $${individualPrices["Facility Relocation Fee RES"].displayPrice}
            </span>
          </div>`: ``}
        `);
    }
    public changeResponsibility() {
        if (!this.otherOrderActivitiesAllowed || this.isJeopardy) {
            this.unabletoStackMsg = 'Change of Responsibility';
            this.otherOrderActivitiesDropdownSelected = 'Change of Responsibility';
            this.unableToStack.open();
            return;
        }
        this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: false });
        this.store.dispatch({ type: 'PAYMENT_STATUS', payload: false });
        this.store.dispatch({ type: 'CREDIT_DATA_RETAIN', payload: null });
        this.store.dispatch({ type: 'CREDIT_DATA_RETAIN_SSN', payload: null });
        this.store.dispatch({ type: 'CC_DONE', payload: false });
        this.store.dispatch({ type: 'FREEZEPAGE', payload: false });
        this.store.dispatch({ type: 'CHANGE_RESPONSIBILITY_APPROVAL', payload: "" });
        this.loading = true;
        let request;
        request = {
            ban: this.existingProductsResponse.existingProductsAndServices[0].accountInfo.ban,
            salesChannel: "ESHOP-Customer Care",
            customerType: "Individual",
            customerSegment: "Retail",
            customerOrderType: "CHANGERESP",
            party: {
                id: this.agentCuid,
                firstName: this.firstName,
                lastName: this.lastName,
                type: "CSR",
                partyRoles: [
                    {
                        partyRole: env.CSR_NAME,
                        sourceSystem: env.CSR_PROFILE,
                        id: this.agentCuid
                    },
                    {
                        partyRole: env.ENSEMBLEID,
                        sourceSystem: env.ENS_OPERATOR,
                        id: this.ensembleId
                    }
                ]
            },
        }
        if (this.existingProductsResponse.existingProductsAndServices[0] && this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes) {
            request.addlOrderAttributes = this.existingProductsResponse.existingProductsAndServices[0].addlOrderAttributes;
        }
        if (this.sfdcBillingAccountID && this.sfdcAccountId) {
            request.sfdcAccountId = (this.sfdcBillingAccountID ? this.sfdcBillingAccountID + ':' : '') + (this.sfdcAccountId ? this.sfdcAccountId : '');
        }
        this.serviceCategory(true);
        this.logger.log("info", "existing-products.component.ts", "getInitChangeResponsiblityRequest", JSON.stringify(request));
        this.logger.startTime();
        this.addressService.getInitCORespCall(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "existing-products.component.ts", "getInitChangeResponsiblityResponse", error);
                this.logger.log("error", "existing-products.component.ts", "getInitChangeResponsiblitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", "Not Applicable", "INIT", "existing-products.component.ts", "Existing Products Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "existing-products.component.ts", "initChangeResponsiblityResponse", JSON.stringify(data));
                this.logger.log("info", "existing-products.component.ts", "initChangeResponsiblitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                let response = data;
                if (this.isPOTSExisintgProduct || this.isDHPExistingProduct) {
                    this.store.dispatch({ type: 'CHANGE_RESP_INIT', payload: response });
                    this.router.navigate(['/change-responsibility']);
                } else {
                    this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: response });
                    this.router.navigate(['/schedule-appt-ship']);
                }
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "existing-products.component.ts", "initChangeResponsiblityResponse", error);
                    this.logger.log("error", "existing-products.component.ts", "initChangeResponsiblitySrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null)
                        return;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                            this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", this.apiResponseError);
                        } else unexpectedError = true;
                    } else unexpectedError = true;
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "INIT", "existing-products.component.ts", "Existing Products Page", lAPIErrorLists);
                    }
                }
            );
    }
    public billingRecords() {
        if (!this.otherOrderActivitiesAllowed) {
            this.invokeCall = "Billing Records Correction";
            this.billingRecordsCorrectionMultiple.open();
        } else {
            this.invokeCall = "Service Address";
            this.billingRecordsCorrection.open();
        }
    }
    public moveServiceCall() {
        if (!this.otherOrderActivitiesAllowed) {
            this.unabletoStackMsg = "move";
            this.otherOrderActivitiesDropdownSelected = "Move";
            this.unableToStack.open();
        } else {
            this.movetabselect();
            this.moveServiceDialog.open();
        }
    }
}
