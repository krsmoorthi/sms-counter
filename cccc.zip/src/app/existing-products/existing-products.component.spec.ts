import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingProductsComponent } from './existing-products.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsModule, AccordionModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { MockServer } from 'app/MockServer.test';
import { MockLogger, MockAppStateService, MockDisconnectService, MockAddressService, MockBlueMarbleService, MockPendingOrderService, MockTextMaskService, MockHelperService, MockProductService, MockSystemErrorService, MockReviewOrderService, MockAccountService, MockDirectvService, MockDisclosuresService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { FirstCustomizePipe } from 'app/common/pipes/firstcapcustom.pipe';
import { DomSanitizer } from '@angular/platform-browser';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { Logger } from 'app/common/logging/default-log.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { Store } from '@ngrx/store';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { AddressService } from 'app/common/service/address.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { ProductService } from 'app/common/service/product.service';
import { HelperService } from 'app/common/service/helper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { of, Observable, throwError } from 'rxjs';
import { VacationDialogComponent } from 'app/common/popup/vacation-dialog.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { AccountService } from 'app/common/service/account.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpResponse } from '@angular/common/http';

describe('ExistingProductsComponent', () => {
  let component: ExistingProductsComponent;
  let fixture: ComponentFixture<ExistingProductsComponent>;
  const mockServer = new MockServer();

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    TextMaskModule,
    SharedCommonModule,
    SharedModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES),
    BrowserAnimationsModule
  ];

  const mockRedux: any = {
    dispatch() { },
    configureStore() { },
    select(reducer) {
      return of(
        mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return of(null);
    }
  };

  class MockBlueMarbleService {
    initVacationCall() {
      return of(mockServer.getVacationStoreOrApiData('HSI_STANDALONE_VS_RESPONSE'));
    }
  }

  const logger = {provide: Logger, useClass: MockLogger};
  const appStateService = {provide: AppStateService, useClass: MockAppStateService};
  const store = {provide: Store, useValue: mockRedux};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const systemErrorService = {provide: SystemErrorService, useClass: MockSystemErrorService};
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const pendingOrderService = {provide: PendingOrderService, useClass: MockPendingOrderService};
  const textMaskService = {provide: TextMaskService, useClass: MockTextMaskService};
  const productService = {provide: ProductService, useClass: MockProductService};
  const helperService =  {provide: HelperService, useClass: MockHelperService};
  const firstCustomizePipe = FirstCustomizePipe;
  const domSanitizer = DomSanitizer;
  const cTLHelperService = CTLHelperService;
  const propertiesHelperService = PropertiesHelperService;
  const reviewOrderService = {provide: ReviewOrderService, useClass: MockReviewOrderService};
  const accountService = {provide: AccountService, useClass: MockAccountService};
  const directvService = {provide: DirectvService, useClass: MockDirectvService};
  const disclosuresService = {provide: DisclosuresService, useClass: MockDisclosuresService};
  const countryStateService = CountryStateService;

  const providers = [
    logger, appStateService, store, disconnectService, addressService,
    systemErrorService, blueMarbleService, pendingOrderService, textMaskService,
    productService, helperService, firstCustomizePipe, domSanitizer, cTLHelperService, 
    propertiesHelperService,reviewOrderService, accountService,  directvService,  disclosuresService,
    countryStateService 
  ]

  describe('HSI Vacation Suspend - Success Response', () => {
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  
    it('onclick vacation service, should get the vacation data', () => {
      component.initializeVacationService();
      expect(component.isPOTSExisintgProduct).toBe(true);
    });
  });

  describe('HSI Vacation Suspend - Incorrect Response', () => {
    class MockBlueMarbleService {
      initVacationCall() {
        return of({});
      }
    }

    const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};

    const _providers = [ ...providers, blueMarbleService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick vacation service, should execute the code without null and undefined error', () => {
      component.initializeVacationService();
    });
  });

  describe('HSI Vacation Suspend - Failed Response', () => {
    class MockBlueMarbleService {
      initVacationCall() {
        const data: any = {errorResponse: []};
        return throwError(new HttpResponse(data));
      }
    }

    const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};

    const _providers = [ ...providers, blueMarbleService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick vacation service, should get error response and it should execute catch block', () => {
      component.initializeVacationService();
      expect(component.loading).toBeFalsy();
    });
  });

  describe('Change Responsibility - Error response', () => {

    class MockAddressService {
      getInitCORespCall() {
        return throwError(new HttpResponse(mockServer.getResponseForRequest('changeResponsibilityInitRes')))
      }
    }
    
    const addressService = {provide: AddressService, useClass: MockAddressService};

    const _providers = [ ...providers, addressService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick change responsibility, should call init API and get error response', () => {
      component.changeResponsibility();
      expect(component.loading).toBe(false);
    });
  });

  describe('Change Responsibility - Success response', () => {

    class MockAddressService {
      getInitCORespCall() {
        return of(mockServer.getResponseForRequest('changeResponsibilityInitRes'))
      }
    }
    
    const addressService = {provide: AddressService, useClass: MockAddressService};

    const _providers = [ ...providers, addressService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick change responsibility, should call init API and get success response', () => {
      component.changeResponsibility();
      expect(component.loading).toBe(true);
    });
  });

  describe('NonPay Suspend - Success response', () => {

    class MockBlueMarbleService {
      initNonpaySupspend() {
        return of(new HttpResponse(mockServer.getResponseForRequest('nonPaySuspendRes')))
      }
      getSecurityDepositHistory() {
        return of(new HttpResponse(mockServer.getResponseForRequest('depositInfoRes')))
      }
    }

    const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};

    const _providers = [ ...providers, blueMarbleService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick non pay suspend/restore, should call init API and get the success response', () => {
      component.selectSuspendRestore();
      expect(component.loading).toBe(true);
    });
    it('onclick retrieveSecurityDepositHistory, should  get the success response', () => {
      component.retrieveSecurityDepositHistory();
      expect(component.loading).toBe(false);
    });
  });

  describe('NonPay Suspend - Error response', () => {

    class MockBlueMarbleService {
      initNonpaySupspend() {
        return throwError(new HttpResponse(mockServer.getResponseForRequest('nonPaySuspendRes')))
      }
      getSecurityDepositHistory() {
        return throwError(new HttpResponse({}))
      }
    }

    const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};

    const _providers = [ ...providers, blueMarbleService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick non pay suspend/restore, should call init API and get the error response', () => {
      component.selectSuspendRestore();
      expect(component.loading).toBe(false);
    });
    it('onclick retrieveSecurityDepositHistory, should  get the success response', () => {
      component.retrieveSecurityDepositHistory();
      expect(component.loading).toBe(false);
    });
  });

  describe('Disconnect All - Success response', () => {
    const mockRedux: any = {
      dispatch() { },
      configureStore() { },
      select(reducer) {
        return of(
          mockServer.getMockStore("MOVE_POTS_TILL_REVIEW_ORDER")[reducer]
        );
      },
      take<T>(this: Observable<T>, count: number) {
        return of(null);
      }
    };

    class MockDisconnectService {
      initDisconnect() {
        return of(new HttpResponse(mockServer.getResponseForRequest('callDisconnectReasonsInitRes')))
      }
    }

    const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
    const store = {provide: Store, useValue: mockRedux};

    const _providers = [ ...providers, disconnectService, store];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick disconnect all , should call init API and get the success response', () => {
      component.callDisconnectReasons();
      expect(component.loading).toBe(false);
    });
  });

  describe('Disconnect All - Error response', () => {

    class MockDisconnectService {
      initDisconnect() {
        return throwError(new HttpResponse({}))
      }
    }

    const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};

    const _providers = [ ...providers, disconnectService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick disconnect all , should call init API and get the error response', () => {
      component.callDisconnectReasons();
      expect(component.loading).toBe(false);
    });
  });

  describe('Make Changes - Success response', () => {
    const mockRedux: any = {
      dispatch() { },
      configureStore() { },
      select(reducer) {
        return of(
          mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
      },
      take<T>(this: Observable<T>, count: number) {
        return of(null);
      }
    };
    class MockAddressService {
      getInitChangeCall() {
        return of(new HttpResponse(mockServer.getResponseForRequest('getInitChangeCallRes')))
      }
    }
    
    const addressService = {provide: AddressService, useClass: MockAddressService};
    const store = {provide: Store, useValue: mockRedux};


    const _providers = [ ...providers, addressService, store];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick make changes , should call init API and get the success response', () => {
      component.goToChangeProduct();
      expect(component.loading).toBe(false);
    });
  });

  describe('Make Changes - Error response', () => {
    class MockAddressService {
      getInitChangeCall() {
        return throwError(new HttpResponse({}))
      }
    }
    
    const addressService = {provide: AddressService, useClass: MockAddressService};

    const _providers = [ ...providers, addressService];

    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [ ExistingProductsComponent, VacationDialogComponent ],
        providers: _providers
      })
      .compileComponents();
    }));
  
    beforeEach(() => {
      fixture = TestBed.createComponent(ExistingProductsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  
    it('onclick make changes , should call init API and get the error response', () => {
      component.goToChangeProduct();
      expect(component.loading).toBe(false);
    });

    it('should call moveServiceCall', () => {
      const returnVal = component.moveServiceCall();
      expect(returnVal).toBeUndefined();
    });

    it('should call billingRecords', () => {
      const returnVal = component.billingRecords();
      expect(returnVal).toBeUndefined();
    });


  });

  

});