import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { TextMaskModule } from 'angular2-text-mask';
import { VacationDialogComponent } from 'app/common/popup/vacation-dialog.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { FirstCustomizePipe } from '../common/pipes/firstcapcustom.pipe';
import { TextMaskService } from '../common/service/text-mask.service';
import { SharedModule } from '../shared/shared.module';
import { ExistingProductsComponent } from './existing-products.component';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: ExistingProductsComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,
        SharedCommonModule,
        SharedModule,
    ],
    exports: [
        ExistingProductsComponent,
        VacationDialogComponent
    ],
    declarations: [
        ExistingProductsComponent,
        VacationDialogComponent
    ],
    providers: [
        TextMaskService,
        FirstCustomizePipe
    ]
})
export class ExistingProductsModule { }
