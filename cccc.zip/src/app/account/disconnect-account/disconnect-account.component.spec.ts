import { TestBed, ComponentFixture,  async } from "@angular/core/testing";
import { Observable } from "rxjs";
import { MockServer } from "app/MockServer.test";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { MockLogger, MockSystemErrorService, MockAppStateService, MockPendingOrderService, MockDisconnectService, MockPropertiesHelperService, MockDirectvService, MockCountryStateService, MockAddressService, MockAccountService, MockReviewOrderService, MockProductService, MockBlueMarbleService, MOCK_ROUTES } from 'app/common/service/mockServices.test';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { Store } from '@ngrx/store';
import { Logger } from 'app/common/logging/default-log.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { AppStateService } from 'app/common/service/app-state.service';
import { RouterTestingModule } from '@angular/router/testing';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { TextMaskModule } from 'angular2-text-mask';
import { DisconnectAccountComponent } from './disconnect-account.component';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';

describe('DisconnectAccountComponent', () => {
  let component: DisconnectAccountComponent;
  let fixture: ComponentFixture<DisconnectAccountComponent>;
  let mockServer = new MockServer();

  const imports = [
    FormsModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES),
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    TextMaskModule,
    SharedCommonModule,
    SharedModule
  ];
  
  const mockRedux: any = {
    dispatch() {},
    configureStore() {},
    select(reducer) {
        return Observable.of(mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]);
    },
    take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
    }
  }
  
  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const ctlHelperService = CTLHelperService;
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService};
  const productService = { provide: ProductService, useClass: MockProductService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService};
  //Dialog Component services
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const countryStateService = { provide: CountryStateService, useClass: MockCountryStateService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };
  const propertiesHelperService = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };

  const baseConfig = {
    imports: imports,
    declarations: [DisconnectAccountComponent],
    providers: [logger, store, appStateService, systemErrorService, disconnectService,
        ctlHelperService, reviewOrderService, productService, blueMarbleService,
        pendingOrderService, accountService, addressService, countryStateService,
        directvService, propertiesHelperService]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisconnectAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should call ngOnIt()', () => {
    component['apiResponse'] = {
        payload : {
            paperlessInfo : {
                paperlessBillAllowed : true,
                paperlessBilling : false
            }
        }
    }
    component['isReEntrant'] = true;
    component.ngOnInit();
    expect(component.refObj.finalEmail).toBe('');
  });
  
//   it('should call updateSelectedNewAddress', () => {
//     component.updateSelectedNewAddress({ });
//     expect((component as any).billingAdditionalInfo).toBe(undefined);
//   });
  
  it('should call onNewAddressValidation', () => {
    component.onNewAddressValidation(true);
    expect(component.isNewAddressValid).toBe(true);
  });
  
  it('should call retainAddress', () => {
    component.retainAddress('address');
    expect(component.retainedAddress).toBe('address');
  });
  
  it('should call updateSelectedNewShipping', () => {
    component.updateSelectedNewShipping({
        address : 'address'
    });
    expect((component as any).tempShippingAddr).toBe('address');
  });
  
  it('should call updateShipping', () => {
    (component as any).tempShippingAddr = {
        streetAddress : 'abc',
        combinedDesignator : 'def',
        city : 'ghi',
        stateOrProvince : 'jkl',
        postCode : '01234'
    }
    component.updateShipping({});
    expect(component.shippingAddress).toBe(undefined);
  });
  
  it('should call newAddressClicked', () => {
    component.newAddressClicked('selected');
    expect(component.isAddressSelected).toBe('selected');
  });
  
  it('should call currentAddressClicked', () => {
    component.currentAddressClicked('address');
    expect(component.isBillingSaved).toBe(false);
  });
  
  it('should call changeShippingAddr', () => {
    component.changeShippingAddr();
    expect(component.isShippingSaved).toBe(false);
  });
  
  it('should call changeBillingAddr', () => {
    component.changeBillingAddr();
    expect(component.isBillingSaved).toBe(false);
  });
  
  it('should call updateBilling', () => {
    component.updateBilling();
    expect(component.isBillingSaved).toBe(false);
  });
  
  it('should call continueClick', () => {
    component.continueClick();
    expect(component.isBillingSaved).toBe(false);
  });
  
  it('should call optionClickHandler', () => {
    let temp = component.optionClickHandler("abc", "abc");
    expect(temp).toBe(undefined);
  });

});