import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Validations } from 'app/common/validations/validations';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AccountInfomation } from '../../common/models/account.model';
import { APIErrorLists, GenericValues } from '../../common/models/common.model';
import { User } from '../../common/models/user.model';
import { DisconnectService } from '../../common/service/disconnect.service';
import { SystemErrorService } from '../../common/service/system-error.service';
import { Logger } from './../../common/logging/default-log.service';
import { AppStore } from './../../common/models/appstore.model';
import { AppStateService } from './../../common/service/app-state.service';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'disconnect-account',
    templateUrl: './disconnect-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})
export class DisconnectAccountComponent implements OnInit, OnDestroy {
    public modem: any;
    public lastName: string;
    public firstName: string;
    public loading = false;
    public errorMsg = '';
    public isAddressSelected;
    private apiResponse;
    public isNewAddressValid: boolean = false;
    public isShowDisconnectFlowAccountButtons = false;
    public isBillingSaved = false;
    public isShippingSaved = false;
    public apiResponseError: APIErrorLists;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    private originalBillingAddr;
    private tempShippingAddr;
    private tempBillingAddr;
    private billingTypeAddress;
    private billingAdditionalInfo;
    public accountObservable: Observable<AccountInfomation>;
    public accountSubscription;
    public billingAddress: string;
    public shippingAddress: string;
    private isReEntrant: boolean = false;
    private taskId: string;
    public isShippingSelected: string;
    private orderRefNumber: string;
    public retainedAddress: any;
    public refObj = {
        finalEmail: '',
        selectedOpt: '',
        submitted: false,
        isEmailValid: true
    };
    public emailPlaceHolder: string = "";
    public paperlessBilling;
    public ispaperlessBillingAllowed;
    public paperlessForm: FormGroup;
    public apiResponsedata: any;

    constructor(
        private logger: Logger,
        private router: Router,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private disconnectService: DisconnectService,
        private ctlHelperService: CTLHelperService
    ) {
        this.isAddressSelected = "New address";
        this.isShippingSelected = "Yes, use same address";
        this.appStateService.setLocationURLs();
        this.accountObservable = <Observable<AccountInfomation>>store.select('account');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            this.apiResponse = respData;
            this.apiResponsedata = respData;
            let user = <Observable<User>>store.select('user');
            let userSubscription = user.subscribe(
                (usr) => {
                    this.firstName = usr.firstName;
                    this.lastName = usr.lastName;
                    if (usr.previousUrl !== '/disconnect-schedule') {
                        this.isReEntrant = true;
                        this.taskId = usr.taskId;
                        let retainVal = <Observable<any>>store.select('retain');
                        retainVal.subscribe(
                            (retVal => {
                                this.apiResponse = retVal.review;
                            })
                        );
                    }
                    if (usr && usr.orderRefNumber) {
                        this.orderRefNumber = usr.orderRefNumber;
                    }
                });
            if (this.isReEntrant) {
                this.isAddressSelected = this.apiResponsedata.AddressTypes;
            }
            userSubscription.unsubscribe();
            this.existingObservable = <Observable<any>>store.select('existingProducts');
            this.existingSubscription = this.existingObservable.subscribe((data) => {
                if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems) {
                    data.existingProductsAndServices[0].existingServices.existingServiceItems.map((serviceItem) => {
                        if (serviceItem.offerCategory === (GenericValues.iData || name === GenericValues.sData)) {
                            serviceItem.existingServiceSubItems.map((existingServiceSubItems) => {
                                if (existingServiceSubItems.productType === (GenericValues.iData || name === GenericValues.sData) && existingServiceSubItems.productName === 'MODEM') {
                                    existingServiceSubItems.productAttributes.map((productAttributes) => {
                                        productAttributes.compositeAttribute.map((compositeAttribute) => {
                                            if (compositeAttribute.attributeName.toLowerCase() !== 'modem type' && compositeAttribute.attributeName.toLowerCase() !== 'modem class' && compositeAttribute.attributeValue === 'Lease') {
                                                this.modem = compositeAttribute.attributeValue;
                                            }
                                        });
                                    });
                                }
                            });
                        }
                    });
                }

                if (data && data.orderFlow && data.orderFlow.flow === 'Disconnect' && data.orderFlow.type === 'fromHold') {
                    let pendingSummaryObservable = <Observable<any>>store.select('pending');
                    pendingSummaryObservable.subscribe((pendingData) => {
                        if (pendingData && pendingData.orderDocument && pendingData.orderDocument.accountInfo) {
                            this.apiResponse = pendingData.orderDocument.accountInfo;
                            if (!pendingData.isFinalBillAddressChanged) {
                                this.isAddressSelected = "Current Billing address";
                            }
                        }
                    });
                }
            });
            if (this.existingSubscription !== undefined) { this.existingSubscription.unsubscribe(); }

            if (this.apiResponse && this.apiResponse.payload) {
                if (this.apiResponse && this.apiResponse.payload.billingAddress) {
                    this.billingAddress = this.apiResponse.payload.billingAddress.streetAddress + ', ' +
                        this.apiResponse.payload.billingAddress.subAddress.combinedDesignator + ', ' +
                        this.apiResponse.payload.billingAddress.city + ', ' +
                        this.apiResponse.payload.billingAddress.stateOrProvince + ', ' +
                        this.apiResponse.payload.billingAddress.postCode;

                    this.shippingAddress = this.apiResponse.payload.billingAddress.streetAddress + ', ' +
                        this.apiResponse.payload.billingAddress.subAddress.combinedDesignator + ', ' +
                        this.apiResponse.payload.billingAddress.city + ', ' +
                        this.apiResponse.payload.billingAddress.stateOrProvince + ', ' +
                        this.apiResponse.payload.billingAddress.postCode;

                }
                this.originalBillingAddr = this.apiResponse.payload.billingAddress;
                if (this.apiResponse.payload.shippingInfo && this.apiResponse.payload.shippingInfo.shippingAddress) {
                    this.apiResponse.payload.shippingInfo.shippingAddress = this.apiResponse.payload.billingAddress;
                    this.apiResponse.payload.isFinalBillAddressChanged = false;
                }
            }

        });

    }

    public ngOnInit() {
        this.logger.metrics('AccountDisconnectPage');
        window.scroll(0, 0);
        if (this.apiResponse && this.apiResponse.payload && this.apiResponse.payload.paperlessInfo) {
            this.paperlessBilling = this.apiResponse.payload.paperlessInfo.paperlessBilling ? this.apiResponse.payload.paperlessInfo.paperlessBilling : false;
            this.refObj.finalEmail = this.apiResponse.payload.paperlessInfo.emailAddress ? this.apiResponse.payload.paperlessInfo.emailAddress : "";
            this.ispaperlessBillingAllowed = this.apiResponse.payload.paperlessInfo.paperlessBillAllowed ? this.apiResponse.payload.paperlessInfo.paperlessBillAllowed : false;
        }
        if (this.ispaperlessBillingAllowed) {
            this.refObj.selectedOpt = 'yesPaperless';
        }
        if (this.isReEntrant) {
            if (!this.paperlessBilling) {
                this.refObj.selectedOpt = 'noPaperless';
            }
            let retainVal = <Observable<any>>this.store.select('retain');
            let retSubscribe = retainVal.subscribe(
                (data => {
                    if (data && data.accountPageReEntrant && data.accountPageReEntrant.isAddressSelected) {
                        this.isAddressSelected = data.accountPageReEntrant.isAddressSelected;
                        if (this.isAddressSelected === 'New address') {
                            this.isUpdateBillingCalled = true;
                            this.newAddressClicked(this.isAddressSelected);
                        }
                    }
                }));
            if (retSubscribe) { retSubscribe.unsubscribe(); }
        }
        this.paperlessForm = new FormGroup({
            'radioPaperless': new FormControl(this.refObj.selectedOpt),
            'finalEmail': new FormControl(this.refObj.finalEmail ? [this.refObj.finalEmail, [Validations.emailValidator]] :
                ['', [Validations.emailValidator]]),
        });

        this.paperlessForm.get('finalEmail').valueChanges.debounceTime(750).subscribe((values) => {
            this.refObj.submitted = false;
            let isValidMail = Validations.emailValidator({ value: this.paperlessForm.value.finalEmail });
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
        });
        if (this.isAddressSelected === 'Current Billing address') { this.isBillingSaved = true; }

    }

    public updateSelectedNewAddress(newAddrObj) {
        this.tempBillingAddr = newAddrObj.address;
        this.billingTypeAddress = newAddrObj.billingAddressType;
        this.billingAdditionalInfo = newAddrObj.billingAdditionalInfo;
        this.updateBilling();
    }

    public onNewAddressValidation(isNewAddressValid) {
        this.isNewAddressValid = isNewAddressValid;
    }

    public retainAddress(address) {
        this.retainedAddress = address;
    }

    public updateSelectedNewShipping(newAddrObj) {
        this.tempShippingAddr = newAddrObj.address;
    }

    public updateShipping(event) {
        this.isShippingSaved = true;
        if (this.apiResponse && this.apiResponse.payload && this.apiResponse.payload.shippingInfo && this.tempShippingAddr) {
            this.apiResponse.payload.shippingInfo.shippingAddress = this.tempShippingAddr;
            this.apiResponse.payload.shippingInfo.isShipAddrSameAsServiceAddress = false;
            if (this.apiResponse.payload.shippingInfo.shippingAddress) {
                this.shippingAddress = this.apiResponse.payload.shippingInfo.shippingAddress.streetAddress + ', ' +
                    this.apiResponse.payload.shippingInfo.subAddress.combinedDesignator + ', ' +
                    this.apiResponse.payload.shippingInfo.shippingAddress.city + ', ' +
                    this.apiResponse.payload.shippingInfo.shippingAddress.stateOrProvince + ', ' +
                    this.apiResponse.payload.shippingInfo.shippingAddress.postCode;
            }
        }
    }

    public newAddressClicked(event?: string) {
        if (event && event !== undefined) {
            this.isAddressSelected = event;
        }
        this.isNewAddressValid = false;
        if (!this.isUpdateBillingCalled) { this.isBillingSaved = false; }
        else { this.updateBilling(); }
    }

    public currentAddressClicked(event) {
        this.isAddressSelected = event;
        if (this.isAddressSelected === 'Current Billing address') { this.isBillingSaved = true; }
        else { this.isBillingSaved = false; }
        if (this.apiResponse && this.apiResponse.payload) {
            this.apiResponse.payload.isFinalBillAddressChanged = false;
            this.apiResponse.payload.billingAddress = this.originalBillingAddr;
            if (this.apiResponse.payload.billingAddress) {
                this.billingAddress = this.apiResponse.payload.billingAddress.streetAddress + ', ' +
                    this.apiResponse.payload.billingAddress.subAddress.combinedDesignator + ', ' +
                    this.apiResponse.payload.billingAddress.city + ', ' +
                    this.apiResponse.payload.billingAddress.stateOrProvince + ', ' +
                    this.apiResponse.payload.billingAddress.postCode;
            }
        }
    }

    public changeShippingAddr() {
        this.isShippingSelected = 'No, enter a different address';
        this.isShippingSaved = false;
    }

    public changeBillingAddr() {
        this.isAddressSelected = 'New address';
        this.isBillingSaved = false;
    }

    public isUpdateBillingCalled = false;
    public updateBilling() {
        if (this.apiResponse && this.apiResponse.payload) {
            this.apiResponse.payload.isFinalBillAddressChanged = true;
            this.isBillingSaved = true;
            this.isUpdateBillingCalled = true;
            this.apiResponse.payload.billingAddress = this.tempBillingAddr;

            if (this.billingTypeAddress === 'International') {
                this.apiResponse.payload.billingAddressType = 'F';
            } else if (this.billingTypeAddress === 'Street Address') {
                this.apiResponse.payload.billingAddressType = 'S';
            } else if (this.billingTypeAddress === 'P.O. Box') {
                this.apiResponse.payload.billingAddressType = 'P';
            } else if (this.billingTypeAddress === 'Rural Route') {
                this.apiResponse.payload.billingAddressType = 'R';
            } else if (this.billingTypeAddress === 'Military') {
                this.apiResponse.payload.billingAddressType = 'M';
            }
            this.apiResponse.payload.billingAdditionalInfo = this.billingAdditionalInfo;
            if (this.billingTypeAddress === 'International') {
                this.billingAddress = this.apiResponse.payload.billingAddress.streetAddress + ', ' +
                    this.apiResponse.payload.billingAddress.subAddress.combinedDesignator + ', ' +
                    (this.apiResponse.payload.billingAddress.city ? this.apiResponse.payload.billingAddress.city + ', ' : '') +
                    this.apiResponse.payload.billingAddress.country + '  ' +
                    this.apiResponse.payload.billingAddress.postCode;
            } else if (this.apiResponse.payload.billingAddress) {
                this.billingAddress = this.apiResponse.payload.billingAddress.streetAddress + ', ' +
                    this.apiResponse.payload.billingAddress.subAddress.combinedDesignator + ', ' +
                    this.apiResponse.payload.billingAddress.city + ', ' +
                    this.apiResponse.payload.billingAddress.stateOrProvince + ', ' +
                    this.apiResponse.payload.billingAddress.postCode;
            }
        }
    }

    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    public continueClick() {
        if (this.refObj.selectedOpt === "yesPaperless" && !this.refObj.isEmailValid) {
            this.refObj.submitted = true;
            window.scroll(0, 200);
            return;
        }
        else {
            this.loading = true;
            if (this.isReEntrant && this.apiResponse) {
                this.apiResponse.taskId = this.taskId;
            }

            if (this.apiResponse && this.apiResponse.payload && this.apiResponse.payload.paperlessInfo) {
                this.apiResponse.payload.paperlessInfo.paperlessBilling = this.refObj.selectedOpt === "yesPaperless" ? true : false;
                this.apiResponse.payload.paperlessInfo.emailAddress = this.refObj.selectedOpt === "yesPaperless" ? this.refObj.finalEmail : '';
            }
            this.logger.log("info", "disconnect-account.component.ts", "disconnectAcctInfoRequest", JSON.stringify(this.apiResponse));
            this.logger.startTime();
            let errorResolved = false;
            this.disconnectService.submitInformation(this.apiResponse)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "disconnect-account.component.ts", "disconnectAcctInfoResponse", error);
                    this.logger.log("error", "disconnect-account.component.ts", "disconnectAcctInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorResolved = true;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", "Not Applicable",
                        "Submit Task", "disconnect-account.component.ts",
                        "Disconnect Account Page",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "disconnect-account.component.ts", "disconnectAcctInfoResponse", JSON.stringify(data));
                        this.logger.log("info", "disconnect-account.component.ts", "disconnectAcctInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        let response = data;
                        if (response) {
                            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            this.store.dispatch({ type: 'DISCONNECT_REVIEW_ORDER', payload: { disconnect_review_order: response } });
                            this.store.dispatch({ type: 'ACCOUNT_PAGE_REENTRANT', payload: { isAddressSelected: this.isAddressSelected } });
                            this.router.navigate(['/disconnect-review-order']);
                        }
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "disconnect-account.component.ts", "disconnectAcctInfoResponse", error);
                            this.logger.log("error", "disconnect-account.component.ts", "disconnectAcctInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        if (error === undefined || error === null) {
                            return;
                        }
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "disconnectAcctInfoResponseError", "disconnect-account.component.ts", "Disconnect Account Page", this.apiResponseError);
                            } else { unexpectedError = true; }
                        } else { unexpectedError = true; }
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "disconnectAcctInfoResponseError", "disconnect-account.component.ts", "Disconnect Account Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    });
        }


    }

    public optionClickHandler(currentOpt, previousOpt) {
        if (currentOpt !== previousOpt) {
            this.refObj.selectedOpt = currentOpt;
        }

    }


    /** unsubscribe on destroy */
    public ngOnDestroy() {

    }


}
