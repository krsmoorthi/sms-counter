import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoveAccountComponent } from './move-account.component';
import { MockServer } from 'app/MockServer.test';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import {
  MockLogger,
  MockRouter,
  MockAppStateService,
  MockSystemErrorService,
  MockReviewOrderService,
  MockAccountService,
  MockPendingOrderService,
  MockAddressService,
  MockCountryStateService,
  MockDirectvService,
  MockPropertiesHelperService,
  MockDisconnectService,
  MockProductService,
  MockBlueMarbleService,
  MockHelperService,
  MOCK_ROUTES
} from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Router, Routes } from '@angular/router';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { AccountService } from 'app/common/service/account.service';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import "rxjs/add/observable/of";
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { AddressService } from 'app/common/service/address.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { creditService } from 'app/common/service/credit-check.service';
import { HelperService } from 'app/common/service/helper.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('MoveAccountComponent', () => {
  let component: MoveAccountComponent;
  let fixture: ComponentFixture<MoveAccountComponent>;
  const mockServer = new MockServer();
  
  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
    TextMaskModule,
    SharedModule,
    SharedCommonModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ];


  const mockRedux: any = {
    dispatch() { },
    configureStore() { },
    select(reducer) {
      return Observable.of(
        mockServer.getMockStore("MOVE_HSI_TILL_REVIEW_ORDER")[reducer]
      );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  };

  class MockCreditCheckService {

  }

  // Move account component provides
  const logger = { provide: Logger, useClass: MockLogger };
  const router = { provide: Router, useClass: MockRouter };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const ctlHelperService = CTLHelperService;
  const store = { provide: Store, useValue: mockRedux };

  // Dialog component provides
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const countryStateService = { provide: CountryStateService, useClass: MockCountryStateService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };
  const propertiesHelperService = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };

  // Credit check component provides
  const credService = { provide: creditService, useClass: MockCreditCheckService };
  const helperService = { provide: HelperService, useClass: MockHelperService };

  const providers = [
    logger, router, appStateService,
    systemErrorService, reviewOrderService, accountService,
    ctlHelperService, store, pendingOrderService, addressService,
    countryStateService, directvService, propertiesHelperService,
    disconnectService, productService, blueMarbleService, credService,
    helperService
  ];

  describe('HSI Standalone', () => {
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [MoveAccountComponent],
        providers: providers
      })
        .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(MoveAccountComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create move account component for hsi standalone flow', () => {
      expect(component).toBeTruthy();
    });

    it('should have isPrepaid flag as false for postpaid order', () => {
      expect(typeof component.isPrepaid).toBe('boolean');
      expect(component.isPrepaid).toBe(false);
    });

    it('should have defined and assigned orderRefNumber', () => {
      expect((component as any).orderRefNumber).toBeDefined();
      expect(typeof (component as any).orderRefNumber).toBe('string');
      expect((component as any).orderRefNumber).toBe('ORN-3334839321289352');
    });

    it('should have isAddressSelected as `New Service address`', () => {
      expect(component.isAddressSelected).toBeDefined();
      expect(typeof component.isAddressSelected).toBe('string');
      expect(component.isAddressSelected).toBe('New Service address');
    });

    it('should have isEmailValid as valid', () => {
      expect(component.refObj.isEmailValid).toBeDefined();
      expect(typeof component.refObj.isEmailValid).toBe('boolean');
      expect(component.refObj.isEmailValid).toBe(true);
    });

    it('should call discardMoveAccount', () => {
      component.discardMoveAccount();
      expect(component.isMoveAccountSelected).toBeTruthy();
    });

  });

  describe('POTS Standalone', () => {
    const mockRedux: any = {
      dispatch() { },
      configureStore() { },
      select(reducer) {
        return Observable.of(
          mockServer.getMockStore("MOVE_POTS_TILL_REVIEW_ORDER")[reducer]
        );
      },
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    class MockReviewOrderService {
      public getMoveReviewOrderInfo() {
        return Observable.of(mockServer.getResponseForRequest('move-account-submitTask'));
      }
    }
    const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
    const store = { provide: Store, useValue: mockRedux };
    const _providers = [...providers, store, reviewOrderService];
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [MoveAccountComponent],
        providers: _providers
      })
        .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(MoveAccountComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create move account component for pots standalone flow', () => {
      expect(component).toBeTruthy();
    });

    it('should call continueClick() method and able to proceed to next page', () => {
      component.continueClick();
      expect(component.loading).toBe(true);
    });

    it('should call assignBillingAddress() and updateBilling() method assign correct values', () => {
      component.assignBillingAddress('Different address');
      expect(typeof component.isAddressSelected).toBe('string');
      expect(component.isAddressSelected).toBe('Different address');
      component.updateBilling({ success: true });
      expect(typeof component.postalAddressValidated).toBe('boolean');
      expect(component.postalAddressValidated).toBe(true);
    });

    it('should call continueClick() method and able to proceed to next page for prepaid move flow', () => {
      component.isPrepaid = true;
      component.continueClick();
      expect(component.loading).toBe(true);
    });

  });

  describe('HSI POTS', () => {
    const mockRedux: any = {
      dispatch() { },
      configureStore() { },
      select(reducer) {
        return Observable.of(
          mockServer.getMockStore("MOVE_HSI_POTS_TILL_CONFIRMATION")[reducer]
        );
      },
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };
    const store = { provide: Store, useValue: mockRedux };
    const _providers = [...providers, store];
    beforeEach(async(() => {
      TestBed.resetTestingModule();
      TestBed.configureTestingModule({
        imports: imports,
        declarations: [MoveAccountComponent],
        providers: _providers
      })
        .compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(MoveAccountComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create move account component for hsi+pots flow', () => {
      expect(component).toBeTruthy();
    });

    it('should have defined and assigned ban and accountPin', () => {
      expect(component.ban).toBeDefined();
      expect(typeof component.ban).toBe('string');
      expect(component.ban).toBe('681113008');
      expect(component.accountPin).toBeDefined();
      expect(typeof component.accountPin).toBe('string');
      expect(component.accountPin).toBe('3023');
    });

    it('should have depositBypass as false', () => {
      expect(component.depositBypass).toBeDefined();
      expect(typeof component.depositBypass).toBe('boolean');
      expect(component.depositBypass).toBe(false);
    });

    it('should allow paperless billing', () => {
      expect(component.refObj).toBeDefined();
      expect(component.ispaperlessBillingAllowed).toBeDefined();
      expect(component.ispaperlessBillingAllowed).toBe(true);
    });

  });

});
