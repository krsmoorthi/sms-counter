import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Validations } from 'app/common/validations/validations';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AccountInfomation } from '../../common/models/account.model';
import { APIErrorLists } from '../../common/models/common.model';
import { User } from '../../common/models/user.model';
import { SystemErrorService } from '../../common/service/system-error.service';
import { Logger } from './../../common/logging/default-log.service';
import { AppStore } from './../../common/models/appstore.model';
import { AccountService } from './../../common/service/account.service';
import { AppStateService } from './../../common/service/app-state.service';
import { ReviewOrderService } from './../../common/service/review-order.service';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'move-account',
    templateUrl: './move-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})
export class MoveAccountComponent implements OnInit, OnDestroy {
    public loading = false;
    public errorMsg = '';
    public accountSubscription: Subscription;
    public moveSubscription: Subscription;
    public otcUpdated: any;
    public accountObservable: Observable<AccountInfomation>;
    public moveObservable: Observable<any>;
    public nextReqPayloadObj: any = {};
    public user: Observable<User>;
    public userData: any;
    public userSubscription: Subscription;
    public newServiceAddress: string;
    private newServiceAddressObj: any = {};
    private newBillingAddress: any;
    public apiResponseError: APIErrorLists;
    public payload: any;
    public accInformation: any = {};
    public isAddressSelected = 'New Service address';
    public isNewAddressValid: boolean = true;
    public isBillingSaved = true;
    public billingAddress: string;
    public intbillingAddress: string;
    public showInternatinoalBillingAddress: boolean = false;
    private isReEntrant: boolean = false;
    private taskId: string = '';
    public accountRentrantValue: any = false;
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public ban: any;
    public existingObservable: Observable<any>;
    public accountPin: any;
    public existingSubscription: Subscription;
    public OtcSubscription: Subscription;
    public isMoveandAccountSelected = false;
    public isShowMoveFlowAccountButtons = false;
    public isMoveAccountSelected = true;
    private accInformationCreditReview: any;
    private orderRefNumber: string;
    public postalAddressValidated: boolean = true;
    public depositBypass: boolean = false;
    public refObj = {
        finalEmail: '',
        selectedOpt: '',
        submitted: false,
        isEmailValid: true
    };
    public emailPlaceHolder: string = "";
    public paperlessBilling: any;
    public ispaperlessBillingAllowed: any;
    public paperlessForm: FormGroup;
    public isValidatedAgain: boolean = true;
    public isPrepaid: boolean;
    public onNewAddressValidation: any;
    public otcDataResponse: any;

    constructor(
        private logger: Logger,
        private router: Router,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private reviewOrderService: ReviewOrderService,
        private accountService: AccountService,
        private ctlHelperService: CTLHelperService
    ) {
        this.appStateService.setLocationURLs();
        this.user = <Observable<User>>store.select('user');
        let userData: User;
        this.userSubscription = this.user.subscribe((data) => {
            this.isPrepaid = data.prepaidFlag && data.prepaidFlag === 'PREPAID' ? true : false;
            userData = data;
            this.userData = userData;
            if (userData.previousUrl !== '/move-schedule-appt' && userData.previousUrl !== '/move-schedule-appt-ship' && userData.previousUrl === '/mo-review-order') {
                this.isReEntrant = true;
                this.taskId = data.taskId;
                this.store.dispatch({ type: 'MOVE_ACCOUNT_REENTRANT', payload: this.isReEntrant });
            }
            if (userData.previousUrl !== '/move-schedule-appt-ship') {
                this.isReEntrant = true;
                this.taskId = userData.taskId;
            }
            if (userData && userData.orderRefNumber) {
                this.orderRefNumber = userData.orderRefNumber;
            }
        });
        this.newServiceAddressObj = this.userData.orderInit.payload.newLocation.serviceAddress;
        if (this.userData.finalAddress.addressLine) {
            this.newServiceAddress = this.userData.finalAddress.addressLine;
        } else {
            let postCodeSuffix: string = this.newServiceAddressObj.postCodeSuffix ? '- ' + this.newServiceAddressObj.postCodeSuffix : '';
            this.newServiceAddress = this.newServiceAddressObj.streetAddress + ', ' + this.newServiceAddressObj.locality + ', ' + this.newServiceAddressObj.stateOrProvince + ', ' + this.newServiceAddressObj.postCode + ' ' + postCodeSuffix;
        }
        this.accountObservable = <Observable<AccountInfomation>>store.select('account');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            if (respData) {
                this.accInformation = respData;
                this.initializeData();
            }
        });
        //Accessing data from credit review store
        this.accountObservable = <Observable<AccountInfomation>>store.select('creditReview');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            if (respData) {
                this.accInformationCreditReview = respData;
                this.initializeData();
            }
        });
        this.moveObservable = <Observable<AccountInfomation>>store.select('move');
        this.moveSubscription = this.moveObservable.subscribe((respData) => {
            if (respData && this.isReEntrant) {
                this.isAddressSelected = respData.AddressType;
                this.initializeData();
            }
        });
        if (this.accountService.otcRelated$) {
            this.OtcSubscription = this.accountService.otcRelated$.subscribe((data) => {
                this.otcUpdated = data;
            });
        }
        this.existingObservable = <Observable<any>>store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            this.ban = data.existingProductsAndServices[0].accountInfo.ban;
            this.accountPin = data.existingProductsAndServices[0].accountInfo.accountPin;
        });
    }

    public ngOnInit() {
        this.logger.metrics('AccountMovePage');
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((respData) => {
            if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
                this.accountRentrantValue = respData.accountreentrant;
            }
            this.depositBypass = respData.bypassedvalue ? respData.bypassedvalue : false;
        });
        window.scroll(0, 0);
        if (this.accInformation && this.accInformation.payload && this.accInformation.payload.paperlessInfo && this.accInformation.taskName === 'Credit Review') {
            this.paperlessBilling = this.accInformation.payload.paperlessInfo.paperlessBilling ? this.accInformation.payload.paperlessInfo.paperlessBilling : false;
            this.refObj.finalEmail = this.accInformation.payload.paperlessInfo.emailAddress ? this.accInformation.payload.paperlessInfo.emailAddress : "";
            this.ispaperlessBillingAllowed = this.accInformation.payload.paperlessInfo.paperlessBillAllowed ? this.accInformation.payload.paperlessInfo.paperlessBillAllowed : false;
        }
        if (this.ispaperlessBillingAllowed) {
            this.refObj.selectedOpt = 'yesPaperless';
        }
        if (this.isReEntrant) {
            this.postalAddressValidated = true;
            if (!this.paperlessBilling) {
                this.refObj.selectedOpt = 'noPaperless';
            }
            let retainVal = <Observable<any>>this.store.select('retain');
            let retSubscribe = retainVal.subscribe((data) => {
                if (data && data.billingValidatedAdddress && data.billingValidatedAdddress.billingAddress) {
                    let postCodeSuffix: string = data.billingValidatedAdddress.billingAddress.postCodeSuffix ? '- ' + data.billingValidatedAdddress.billingAddress.postCodeSuffix : '';
                    this.newServiceAddress = data.billingValidatedAdddress.billingAddress.streetAddress + ', ' + data.billingValidatedAdddress.billingAddress.locality + ', ' + data.billingValidatedAdddress.billingAddress.stateOrProvince + ', ' + data.billingValidatedAdddress.billingAddress.postCode + ' ' + postCodeSuffix;
                    this.isValidatedAgain = false;
                }
            });
            if (retSubscribe) { retSubscribe.unsubscribe(); }
        }
        this.paperlessForm = new FormGroup({
            'radioPaperless': new FormControl(this.refObj.selectedOpt),
            'finalEmail': new FormControl(this.refObj.finalEmail ? [this.refObj.finalEmail, [Validations.emailValidator]] :
                ['', [Validations.emailValidator]]),
        });

        this.paperlessForm.get('finalEmail').valueChanges.debounceTime(750).subscribe((values) => {
            this.refObj.submitted = false;
            let isValidMail = Validations.emailValidator({ value: this.paperlessForm.value.finalEmail });
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
        });
        if (this.accInformation.payload.billingAddress !== null && this.accInformation.payload.billingAddress !== undefined && this.accInformation.payload.billingAddress.isValidated !== undefined && this.accInformation.payload.billingAddress.isValidated !== null && !this.accInformation.payload.billingAddress.isValidated && !this.isReEntrant) {
            this.postalAddressValidated = false;
        }
    }

    public initializeData() {
        if (this.accInformation.taskName === 'Credit Review' && this.accInformation.payload && this.accInformation.payload.billingAddress) {
            this.billingAddress = this.accInformation.payload.billingAddress.streetAddress + ', ' +
                this.accInformation.payload.billingAddress.city + ', ' +
                this.accInformation.payload.billingAddress.stateOrProvince + ', ' +
                this.accInformation.payload.billingAddress.postCode + ', ';
        }
        //as continue click failed with 400, come back to same page and reinitialized international billling to service address. So added a if condition here. This can be removed if BM fixes 400 issue
        if (this.nextReqPayloadObj && this.nextReqPayloadObj.billingAddressType && this.nextReqPayloadObj.billingAddressType !== 'F') {
            this.nextReqPayloadObj = {
                paymentStatus: [],
                billingAddress: this.newServiceAddressObj,
                isBillAddrSameAsServiceAddress: false,
                billingAdditionalInfo: this.accInformation && this.accInformation.payload && this.accInformation.payload.billingAdditionalInfo,
                billingAddressType: this.accInformation && this.accInformation.payload && this.accInformation.payload.billingAddressType
            };
        }
    }

    public assignBillingAddress(entry?: string) {
        if (entry && entry !== undefined) {
            this.isAddressSelected = entry;
        }
        if (this.isAddressSelected === 'New Service address') {
            this.nextReqPayloadObj.isBillAddrSameAsServiceAddress = true;
            this.nextReqPayloadObj.billingAddress = this.newServiceAddressObj;
            this.isBillingSaved = true;
        }
        else if (this.isAddressSelected === 'Current Billing address') {
            this.nextReqPayloadObj.isBillAddrSameAsServiceAddress = false;
            this.nextReqPayloadObj.billingAddress = this.accInformation && this.accInformation.payload && this.accInformation.payload.billingAddress;
            this.isBillingSaved = true;
        }
        if (this.isAddressSelected === 'Different address') {
            this.isNewAddressValid = false;
            this.isBillingSaved = false;
        }
    }

    public updateSelectedNewAddress(newAddrObj: { address: any; isBillAddrSameAsServiceAddress: any; billingAdditionalInfo: any; billingAddressType: string; }) {
        this.nextReqPayloadObj.billingAddress = newAddrObj.address;
        this.nextReqPayloadObj.isBillAddrSameAsServiceAddress = newAddrObj.isBillAddrSameAsServiceAddress;
        this.nextReqPayloadObj.billingAdditionalInfo = newAddrObj.billingAdditionalInfo;
        this.postalAddressValidated = true;
        this.isBillingSaved = true;
        this.isValidatedAgain = true;
        if (newAddrObj.billingAddressType === 'International') {
            this.nextReqPayloadObj.billingAddressType = 'F';
            this.showInternatinoalBillingAddress = true;
        } else if (newAddrObj.billingAddressType === 'Street Address') {
            this.nextReqPayloadObj.billingAddressType = 'S';
        } else if (newAddrObj.billingAddressType === 'P.O. Box') {
            this.nextReqPayloadObj.billingAddressType = 'P';
        } else if (newAddrObj.billingAddressType === 'Rural Route') {
            this.nextReqPayloadObj.billingAddressType = 'R';
        } else if (newAddrObj.billingAddressType === 'Military') {
            this.nextReqPayloadObj.billingAddressType = 'M';
        }
        this.intbillingAddress = this.nextReqPayloadObj.billingAddress.streetAddress + ', ' +
            (this.nextReqPayloadObj.billingAddress.streetName ? (this.nextReqPayloadObj.billingAddress.streetName + ', ') : '') +
            (this.nextReqPayloadObj.billingAddress.city ? (this.nextReqPayloadObj.billingAddress.city + ', ') : '') +
            this.nextReqPayloadObj.billingAddress.country +
            (this.nextReqPayloadObj.billingAddress.postCode ? (', ' + this.nextReqPayloadObj.billingAddress.postCode) : '');
    }

    public updateBilling(event: any) {
        this.postalAddressValidated = true;
    }

    public updateMovePaymentDetails(paidObj: any) {
        if (this.nextReqPayloadObj && this.nextReqPayloadObj !== undefined && this.nextReqPayloadObj.paymentStatus && this.nextReqPayloadObj.paymentStatus !== undefined) {
            this.nextReqPayloadObj.paymentStatus.push(paidObj);
        }
    }

    public handleBackToExistingProducts(event: any) {
        this.router.navigate(['/existing-products']);
    }

    public disabledContinue() {
        if (!this.postalAddressValidated) {
            return true;
        }
    }

    public continueClick() {
        if (this.refObj.selectedOpt === "yesPaperless" && !this.refObj.isEmailValid) {
            this.refObj.submitted = true;
            window.scroll(0, 200);
            return;
        }
        else if (this.isPrepaid) {
            this.assignBillingAddress();
            let finalBillAddressToReq = this.nextReqPayloadObj.billingAddress;
            let tmpbillingAdditionalInfo = this.nextReqPayloadObj.billingAdditionalInfo;
            let tmpbillingAddressType = this.nextReqPayloadObj.billingAddressType;
            //getting updated billing address from payment submitTask response
            this.newBillingAddress = this.accInformationCreditReview.billingAddress;
            if (finalBillAddressToReq) {
                delete finalBillAddressToReq.timeZone;
                delete finalBillAddressToReq.npaNxxList;
                delete finalBillAddressToReq.locationAttributes;
                delete finalBillAddressToReq.geoPoint;
                delete finalBillAddressToReq.streetNrLastSuffix;
                delete finalBillAddressToReq.streetNrLast;
                delete finalBillAddressToReq.addressId;
                delete finalBillAddressToReq.validated;
                delete finalBillAddressToReq.isValidated;
                delete finalBillAddressToReq.sourceId;
                delete finalBillAddressToReq.geoAddressId;
            }
            if (this.newBillingAddress) {
                delete this.newBillingAddress.timeZone;
                delete this.newBillingAddress.npaNxxList;
                delete this.newBillingAddress.locationAttributes;
                delete this.newBillingAddress.geoPoint;
                delete this.newBillingAddress.streetNrLastSuffix;
                delete this.newBillingAddress.streetNrLast;
                delete this.newBillingAddress.addressId;
                delete this.newBillingAddress.validated;
                delete this.newBillingAddress.isValidated;
                delete this.newBillingAddress.sourceId;
                delete this.newBillingAddress.geoAddressId;
            }
            let addressType = this.isAddressSelected;
            this.store.dispatch({ type: 'ADDRESS_TYPE', payload: { AddressType: addressType } });
            this.payload = {
                "creditReviewAction": "SHOWSUMMARY",
                //updated billing address for updated credit-review request
                "paperlessInfo": this.accInformation.payload.paperlessInfo,
                "billingAdditionalInfo": tmpbillingAdditionalInfo,
                "billingAddressType": tmpbillingAddressType,
                "billingAddress": this.newBillingAddress === undefined ? finalBillAddressToReq : this.newBillingAddress,
                "addlOrderAttributes": this.otcUpdated ? this.otcUpdated : this.accInformation.payload.addlOrderAttributes
            };
            let requestObject: AccountInfomation = {
                orderRefNumber: this.accInformation.orderRefNumber,
                processInstanceId: this.accInformation.processInstanceId,
                taskId: this.isReEntrant ? this.taskId : this.accInformation.taskId,
                taskName: this.accInformation.taskName,
                payload: this.payload
            };
            this.loading = true;
            let errorResolved = false;
            this.logger.log("info", "move-account.component.ts", "moveReviewOrderRequest", JSON.stringify(requestObject));
            this.logger.startTime();
            this.reviewOrderService.getMoveReviewOrderInfo(requestObject, 'move')
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "move-account.component.ts", "moveReviewOrderResponse", error);
                    this.logger.log("error", "move-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorResolved = true;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", "Not Applicable",
                        "Submit Task", "move-account.component.ts",
                        "Move to Review Order - Move Account Page",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "move-account.component.ts", "moveReviewOrderResponse", JSON.stringify(data));
                        this.logger.log("info", "move-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        let response = data;
                        if (response.payload && response.payload.paymentDetails !== undefined && response.payload.paymentDetails) {
                            this.store.dispatch({ type: 'PAYMENT_DATA', payload: response.payload.paymentDetails });
                        }
                        if (response) {
                            this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            this.router.navigate(['/mo-review-order']);
                        }
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "move-account.component.ts", "moveReviewOrderResponse", error);
                            this.logger.log("error", "move-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        if (error === undefined || error === null) {
                            return;
                        }
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task -  Move to Review Order", "move-account.component.ts", "move Account Page", this.apiResponseError);
                            } else { unexpectedError = true; }
                        } else { unexpectedError = true; }
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Move to Review Order Page", "move-account.component.ts", "Move Account Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    });
        } else {
            this.assignBillingAddress();
            let finalBillAddressToReq = this.nextReqPayloadObj.billingAddress;
            let tmpbillingAdditionalInfo = this.nextReqPayloadObj.billingAdditionalInfo;
            let tmpbillingAddressType = this.nextReqPayloadObj.billingAddressType;
            this.accountObservable = <Observable<AccountInfomation>>this.store.select('creditReview');
            this.accountSubscription = this.accountObservable.subscribe((respData) => { // getting updated taskid from credit reiew store
                if (respData) {
                    this.accInformationCreditReview = respData;
                    this.initializeData();
                }
            });
            //getting updated billing address from payment submitTask response
            this.newBillingAddress = this.accInformationCreditReview.billingAddress;
            if (finalBillAddressToReq) {
                delete finalBillAddressToReq.timeZone;
                delete finalBillAddressToReq.npaNxxList;
                delete finalBillAddressToReq.locationAttributes;
                delete finalBillAddressToReq.geoPoint;
                delete finalBillAddressToReq.streetNrLastSuffix;
                delete finalBillAddressToReq.streetNrLast;
                delete finalBillAddressToReq.addressId;
                delete finalBillAddressToReq.validated;
                delete finalBillAddressToReq.isValidated;
                delete finalBillAddressToReq.sourceId;
                delete finalBillAddressToReq.geoAddressId;
            }
            if (this.newBillingAddress) {
                delete this.newBillingAddress.timeZone;
                delete this.newBillingAddress.npaNxxList;
                delete this.newBillingAddress.locationAttributes;
                delete this.newBillingAddress.geoPoint;
                delete this.newBillingAddress.streetNrLastSuffix;
                delete this.newBillingAddress.streetNrLast;
                delete this.newBillingAddress.addressId;
                delete this.newBillingAddress.validated;
                delete this.newBillingAddress.isValidated;
                delete this.newBillingAddress.sourceId;
                delete this.newBillingAddress.geoAddressId;
            }
            let addressType = this.isAddressSelected;
            this.store.dispatch({ type: 'ADDRESS_TYPE', payload: { AddressType: addressType } });
            if (this.accInformation && this.accInformation.payload && this.accInformation.payload.paperlessInfo) {
                this.accInformation.payload.paperlessInfo.paperlessBilling = this.refObj.selectedOpt === "yesPaperless" ? true : false;
                this.accInformation.payload.paperlessInfo.emailAddress = this.refObj.selectedOpt === "yesPaperless" ? this.refObj.finalEmail : '';
            }
            this.payload = {
                "creditReviewAction": "SHOWSUMMARY",
                "accountName": {
                    "firstName": this.userData.firstName,
                    "lastName": this.userData.lastName,
                    "ban": this.ban,
                    "accountPin": this.accountPin,
                    "ssn": null,
                    "dob": null
                },
                //updated billing address for updated credit-review request
                "paperlessInfo": this.accInformation.payload.paperlessInfo,
                "billingAdditionalInfo": tmpbillingAdditionalInfo,
                "billingAddressType": tmpbillingAddressType,
                "billingAddress": this.newBillingAddress === undefined ? finalBillAddressToReq : this.newBillingAddress,
                "addlOrderAttributes": this.otcUpdated ? this.otcUpdated : this.accInformation.payload.addlOrderAttributes
            };
            let requestObject: AccountInfomation = {
                orderRefNumber: this.accInformation.orderRefNumber,
                processInstanceId: this.accInformation.processInstanceId,
                taskId: this.isReEntrant ? this.taskId : this.accInformation.taskId,
                taskName: this.accInformation.taskName,
                payload: this.payload
            };
            let dipositBypass = {
                "orderAttributeGroup": [
                    {
                        "orderAttributeGroupName": "depositBypassed",
                        "orderAttributeGroupInfo": [
                            {
                                "orderAttributes": [
                                    {
                                        "orderAttributeName": "depositBypassedInd",
                                        "orderAttributeValue": this.depositBypass
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };
            let depositeBypassOptional = {
                "orderAttributeGroup": [
                    {
                        "orderAttributeGroupName": "agentEnsembleIdInfo",
                        "orderAttributeGroupInfo": [
                            {
                                "orderAttributes": [
                                    {
                                        "orderAttributeName": "agentEnsembleId",
                                        "orderAttributeValue": "string"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };
            if (!this.isReEntrant) {
                requestObject.payload.addlOrderAttributes.push(dipositBypass);
                requestObject.payload.addlOrderAttributes.push(depositeBypassOptional);
            }
            requestObject.payload.addlOrderAttributes.map(bipassData => {
                if (bipassData.orderAttributeGroup[0].orderAttributeGroupName === "depositBypassed") {
                    bipassData.orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue = this.depositBypass;
                }
            });
            if (this.accInformationCreditReview && this.accInformationCreditReview.taskId && this.accInformationCreditReview.taskId !== null) {
                requestObject.taskId = this.accInformationCreditReview.taskId;
            }
            this.loading = true;
            let errorResolved = false;
            this.logger.log("info", "move-account.component.ts", "moveReviewOrderRequest", JSON.stringify(requestObject));
            this.logger.startTime();
            this.reviewOrderService.getMoveReviewOrderInfo(requestObject, 'move')
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "move-account.component.ts", "moveReviewOrderResponse", error);
                    this.logger.log("error", "move-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    errorResolved = true;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", "Not Applicable",
                        "Submit Task", "move-account.component.ts",
                        "Move to Review Order - Move Account Page",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "move-account.component.ts", "moveReviewOrderResponse", JSON.stringify(data));
                        this.logger.log("info", "move-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        let response = data;
                        if (response.payload && response.payload.paymentDetails !== undefined && response.payload.paymentDetails) {
                            this.store.dispatch({ type: 'PAYMENT_DATA', payload: response.payload.paymentDetails });
                        }
                        if (response) {
                            this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            this.router.navigate(['/mo-review-order']);
                        }
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "move-account.component.ts", "moveReviewOrderResponse", error);
                            this.logger.log("error", "move-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        if (error === undefined || error === null) {
                            return;
                        }
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task -  Move to Review Order", "move-account.component.ts", "move Account Page", this.apiResponseError);
                            } else { unexpectedError = true; }
                        } else { unexpectedError = true; }
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Move to Review Order Page", "move-account.component.ts", "Move Account Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    });
        }
        if (this.refObj.submitted && !this.postalAddressValidated) {
            return;
        }
    }

    /** unsubscribe on destroy */
    public ngOnDestroy() {

        if (this.OtcSubscription) {
            this.OtcSubscription.unsubscribe();
        }
        if (this.existingSubscription) {
            this.existingSubscription.unsubscribe();
        }
        if (this.moveSubscription) {
            this.moveSubscription.unsubscribe();
        }
        if (this.accountSubscription) {
            this.accountSubscription.unsubscribe();
        }
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }

    private cancelOrder() {
        this.isMoveAccountSelected = true;
        this.isMoveandAccountSelected = false;
    }
    public discardMoveAccount() {
        this.cancelOrder();
        this.isShowMoveFlowAccountButtons = false;
    }

    public optionClickHandler(currentOpt: string, previousOpt: any) {
        if (currentOpt !== previousOpt) {
            this.refObj.selectedOpt = currentOpt;
        }
    }

}
