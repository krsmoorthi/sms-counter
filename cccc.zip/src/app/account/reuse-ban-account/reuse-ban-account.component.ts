import { Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { HelperService } from "app/common/service/helper.service";
import { DirectvService } from 'app/common/service/directv.services';
import { SystemErrorService } from "app/common/service/system-error.service";
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../../common/logging/default-log.service';
import { AccountContactDetails, AccountInfo, AccountInfomation, AccountPreferences, PersonalDetails, AuthUsersList } from '../../common/models/account.model';
import { AppStore } from '../../common/models/appstore.model';
import { EnterpriseAddress } from '../../common/models/cart.model';
import { APIErrorLists, ErrorResponse, GenericValues, serverErrorMessages } from '../../common/models/common.model';
import { CreditCheck, CreditCheckPayload, CreditInfo, DepositInfo, PaymentInfo, PaymentsRq } from '../../common/models/credit-check.model';
import { Order } from '../../common/models/order.model';
import { User } from '../../common/models/user.model';
import { AccountService } from '../../common/service/account.service';
import { AddressService } from '../../common/service/address.service';
import { AppStateService } from '../../common/service/app-state.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import { Validations } from '../../common/validations/validations';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import 'rxjs/add/operator/debounceTime';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
    selector: 'reuse-ban-account',
    templateUrl: './reuse-ban-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})

export class ReuseBanAccountComponent implements OnInit, OnDestroy, AfterViewInit {
    public bypassButtonSelected: boolean = false;
    public accountInfoAfterDoneCredit: any;
    public reviewOrdeAddAttrrResponse: any;
    public dtvRefoundAmt: any;
    public dhpRefoundAmt: any;
    public dtvPaymentDone: boolean = false;
    public dhpPaymentDone: boolean = false;
    public allProductsPaid: boolean = true;
    public paymentPending: boolean = false;
    public potsPaymentDone: boolean = false;
    public hsiPaymentDone: boolean = false;
    public depositInfo: any;
    public potsRefoundAmt: any;
    public reentrantDepositPayStatus: any;
    public hsiRefundAmt: any;
    public potsPaymentData: boolean = false;
    public retrieveDtvData: any;
    public addlOrderAttributesDepositData: any;
    public isPaymentDone: boolean = false;
    public userSubscription$: Subscription;
    public userdata: Observable<User>;
    public accountdata: Observable<AccountInfomation>;
    public previousURL: string;
    public retainSSN: any;
    public creditRevObsv2: any;
    public creditDataObj: CreditCheck;
    public creditCheckRetain: Subscription;
    public user: Observable<User>;
    public retryButtonEnabled: boolean = false;
    public userSubscription: Subscription;
    public accountObservable: Observable<AccountInfomation>;
    public accountSubscription;
    public creditRevObsv: Observable<CreditCheck>;
    public creditRevSubscription: Subscription;
    public orderObservable: Observable<Order>;
    public orderSubscription: Subscription;
    public currUrl: string;
    public accountForm: FormGroup;
    public accRespObj: AccountInfo;                   // Account info Parent Object
    public showDriverLicense: boolean = false;
    public phoneMask: any;
    public ssnMask: any;
    public otcData1: any[];
    public otcDataResponse: any[];
    public otcData: any[];
    public otcUpdated: any[];
    public internationalFormattingUrl: string = `${env.INTERNATIONAL_FORMATTING_URL}`;
    public creditObj: CreditCheckPayload;                    // Credit check Parent Object
    public creditDepositInfo: DepositInfo;            // Credit check deposit info
    public billingAddr: EnterpriseAddress;            // Reference billing address
    public serviceAddress: EnterpriseAddress;
    private initialServiceAddress: EnterpriseAddress;
    public isAuthorizedParties: AuthUsersList;
    public authUsers: any = [];
    public authorizedParties: boolean = false;
    public oneAuthorzedParty: boolean = false;
    private isServiceAddressInitialized: boolean = false;
    public contactDet: AccountContactDetails;         // Contact Details
    public personalDet: PersonalDetails;              // Account Personal details Object
    public products: any = [];
    public isInitializedFormObj: boolean = false;     // Flag to display initial page
    public accountObj: any = {};                      // Reference obj
    public payobj: any = {};
    public accInformation: AccountInfomation;
    public creditResponse: CreditCheck;
    public paymentReqObj: PaymentInfo[] = [];
    public errorMsg: string;
    public creditInfo: CreditInfo;
    private creditReviewResp: any;
    private autoLoginEmailAddress: any = '';
    private autoLoginPhoneNumber: any = '';
    private phoneNumber: any = '';
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public retainObservableData: any;
    public paidSecurityDeposit: boolean = false;
    public ban: string;
    public legacy: string;
    private enumActions = {
        UPDATE_APPLN: 'UPDATEAPPLN',
        REFRESH_DECISION: 'REFRESHDECISION',
        SHOW_SUMMARY: 'SHOWSUMMARY',
        PAY_DEPOSIT: 'PAYDEPOSIT',
        PAY_FBILL: 'PAYFBILL'
    };
    public refObj: any =
        {
            billingOptions: [{ name: 'Email and SMS', disable: false },
            { name: 'Email only', disable: false },
            { name: 'SMS only', disable: false },
            { name: 'Do not notify', disable: false }],
            billingChk: true,
            orderChk: true,
            repairChk: true,
            changeAddrClicked: false,
            month: '',
            day: '',
            year: '',
            underAge: false,
            isEmailValid: true,
            isValidAccPassword: true,
            submitted: false,
            addressTypes: ['Street Address', 'P.O. Box', 'Rural Route', 'Military', 'International'],
            stateCountries: [],
            dlStateCountries: [] = this.countryStateService.getStates(),
            addrCareOf: '',
            selectedState: {},
            nearAddresses: [],
            isExactAddr: '',
            selectedAddr: {},
            isEnteredAllAddsFields: true,
            disableSaveAddr: true,
            disableValidateAddr: false,
            totalDepositAmount: 0,
            userData: {},
            isValidDob: true,
            dobMessage: '',
            addrPlaceholders: {},
            addrModels: {},
            addrTypeSelected: '',
            billingOpt: 'none',
            savedAddress: {},
            selectedOpt: 'none',
            disableDepositBtn: false,
            displayPaidDeposit: false,
            isPaymentSuccess: false,
            depositPaidDate: '',
            sessionId: '',
            pastDueAccs: [],
            displayPaidPastDue: false,
            disablePastDueBtn: false,
            paymentFailed: false,
            displayPaidPD: false,
            paymentFailedPD: false,
            paymentStatusPD: false,
            isPaymentSuccessPD: false,
            depositInstallmentObj: null,
            clickedAddress: {}
        };
    public visible: boolean = false;
    public postalAddressValidated: boolean = true;
    public addressNotValidatedMsg: string;
    public visibleDeposit: boolean;
    public visibleBalance: boolean;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public geoesAddressValidationError: string;
    public isDTV = false;
    public newDtv = false;
    public existingProductStore$: Observable<any>;
    public existingProductStoreSubscription: Subscription;
    public dtvForm: FormGroup;
    @ViewChild('ssnfield', { static: false, })
    private ssnfield: ElementRef;
    private reEntrant: boolean = false;
    public taskId: string = '';
    public paymentDone: boolean = false;
    private userPaidObj = null;
    public paymentUrl: string = `${env.DEPOSIT_AND_FINAL_BILL_URL}`;
    public orderRefNumber: string;
    private accountPassword: any;
    public reservedAppointment: any;
    public apptObservable: Observable<any>;
    public apptSubscription: Subscription;
    public isDtvSessionInfo: boolean = false;
    public isDtvOpus: any;
    @ViewChild('validateCreditModal', { static: false, }) public validateCreditModal: DialogComponent;
    @ViewChild('opusSessionInfoNotFound', { static: false, }) public opusSessionInfoNotFound: DialogComponent;
    public maxCreditCheckReached: boolean = false;
    private removedDTV: boolean = false;
    private accountPasswordPin: boolean;
    private sfcPaperlessFlag: boolean = false;
    public showHidePaymentProducts: boolean = false;
    public bypassDepositUser: boolean = false;
    public sfcData: any;
    public emailAddrDeclinedManually: boolean = false;
    public accountForm_originalValues: any;
    public accountForm_currentValues: any;
    public accountForm_ValuesChanged: boolean = false;
    public accountHolderName: string;
    constructor(
        private logger: Logger,
        private router: Router,
        private fb: FormBuilder,
        public store: Store<AppStore>,
        private sanitizer: DomSanitizer,
        private appStateService: AppStateService,
        private textMask: TextMaskService,
        private accountService: AccountService,
        private addressService: AddressService,
        private countryStateService: CountryStateService,
        private reviewOrderService: ReviewOrderService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
        private directvService: DirectvService) {

        this.user = <Observable<User>>store.select('user');
        this.phoneMask = this.textMask.getPhoneNumberMaskFormat();
        this.ssnMask = this.textMask.getSsnMask();
        this.appStateService.setLocationURLs();
        this.userSubscription = this.user.subscribe((data) => {
            this.isDtvOpus = data.isDtvOpus;
            this.currUrl = data.currentUrl;
            this.refObj.userData = data;

            this.previousURL = data.previousUrl;
            if (data.previousUrl !== '/schedule-appt' && data.previousUrl !== '/schedule-appt-ship' && data.previousUrl === '/review-order') {
                this.reEntrant = true;
                this.taskId = data.taskId;
                this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: this.reEntrant });
            }
            if (Array.isArray(data.currentSelected)) {
                data.currentSelected.forEach((val: any) => {
                    if (val.selected === GenericValues.cDTV) {
                        this.isDTV = true;
                    }
                });
                if (this.isDtvOpus) {
                    if (data.dtvOpus) {
                        if (data.dtvOpus.taskName === 'yes') {
                            this.newDtv = true;
                        }
                    }
                } else {
                    if (data.dtvQuestionForm) {
                        if (data.dtvQuestionForm.taskName === 'yes') {
                            this.newDtv = true;
                        }
                    }
                }
            }

            if (data.autoLogin !== null && data.autoLogin.sfcData !== undefined && data.autoLogin.sfcData !== null && !this.reEntrant) {
                if (data.autoLogin.sfcData.emailID !== null && data.autoLogin.sfcData.emailID !== undefined && data.autoLogin.sfcData.emailID.length > 0) {
                    if (!this.accountForm_ValuesChanged) {
                        this.autoLoginEmailAddress = data.autoLogin.sfcData.emailID;
                    }
                    if (!this.sfcPaperlessFlag) {
                        this.refObj.billingOpt = 'paperless';
                        this.refObj.selectedOpt = 'paperless';
                        this.sfcPaperlessFlag = true;
                    }
                }
                if (!this.accountForm_ValuesChanged) {
                    if (!data.autoLogin.sfcData.isPrimaryPhoneSms) {
                        this.autoLoginPhoneNumber = '';
                    } else if (data.autoLogin.sfcData.contactNumber !== null && data.autoLogin.sfcData.contactNumber.length > 0 && !this.reEntrant) {
                        this.autoLoginPhoneNumber = data.autoLogin.sfcData.contactNumber;
                    }
                }
            }

            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
                this.legacy = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
        });

        this.accountObservable = <Observable<AccountInfomation>>store.select('account');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            this.accInformation = respData;
            if (respData && respData.addressType) {
                this.refObj.addrTypeSelected = respData.addressType;
            }
            if (respData.isAuthorizedParties) {
                this.authUsers = respData.isAuthorizedParties;
                if (this.authUsers[0].firstName !== "" || this.authUsers[1].firstName !== "") {
                    this.authorizedParties = true;
                }
                if (this.authUsers[0].firstName === "" || this.authUsers[1].firstName === "") {
                    this.oneAuthorzedParty = true;
                }
            }
        });
        //this.accountSubscription.unsubscribe();

        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((respData) => {
            if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
                this.reEntrant = respData.accountreentrant;
            }
            if (respData.dtvSessionInfo && respData.dtvSessionInfo.payload) {
                this.isDtvSessionInfo = true;
            }
            if (respData.maxCreditCheckReached) {
                this.maxCreditCheckReached = respData.maxCreditCheckReached;
            }

            if (this.reEntrant && respData.accountPageReEntrant && respData.accountPageReEntrant !== undefined) {
                this.accInformation = respData.accountPageReEntrant;
                if (respData && respData.payload && respData.payload.accountPassword) {
                    this.accountPassword = respData.payload.accountPassword;
                }
                this.autoLoginEmailAddress = this.accInformation.payload.accountInfo.contact.emailAddress;
                if (this.autoLoginEmailAddress && this.autoLoginEmailAddress !== undefined) {
                    this.accInformation.payload.accountInfo.contact.emailAddrDeclined = false;
                }

                this.autoLoginPhoneNumber = this.accInformation.payload.accountInfo.contact.smsNumber;
                this.phoneNumber = this.accInformation.payload.accountInfo.contact.contactNumber;
            }
        });
        this.retainSubscription.unsubscribe();
        this.initializeData();

        if (this.reEntrant) {
            this.creditRevObsv = <Observable<CreditCheck>>store.select('creditReview');
            this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                if (creditData && creditData.payload && creditData.payload.addlOrderAttributes && creditData.payload.addlOrderAttributes !== undefined) {
                    this.addlOrderAttributesDepositData = creditData.payload.addlOrderAttributes;
                    if (this.addlOrderAttributesDepositData && this.addlOrderAttributesDepositData !== undefined && this.addlOrderAttributesDepositData[0] && this.addlOrderAttributesDepositData[0].orderAttributeGroup) {
                        this.addlOrderAttributesDepositData[0].orderAttributeGroup.map(depositData => {
                            if (depositData && depositData.orderAttributeGroupName === "depositData") {
                                depositData.orderAttributeGroupInfo.map(paymentData => {
                                    if (paymentData && paymentData.orderAttributes[0].orderAttributeValue === "INTERNET") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.hsiPaymentDone = true;
                                            this.paidSecurityDeposit = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.hsiPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.hsiRefundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                    if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-HP") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.potsPaymentDone = true;
                                            this.paidSecurityDeposit = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.potsPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.potsRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                    if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-DHP") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.dhpPaymentDone = true;
                                            this.paidSecurityDeposit = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.dhpPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.dhpRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                });
                            }
                        });
                    }
                    this.creditReviewResp = creditData;
                    this.creditObj = creditData.payload;
                    this.initCreditInfo();
                    if (!this.dhpPaymentDone && this.hsiPaymentDone && !this.allProductsPaid) {
                        this.refObj.disableDepositBtn = false;
                    }
                }
            });
            this.creditRevSubscription.unsubscribe();
            this.orderObservable = <Observable<Order>>store.select('order');
            this.orderSubscription = this.orderObservable.subscribe((orderData) => {
                if (orderData && orderData.payload && orderData.payload.accountInfo) {
                    this.accInformation.orderRefNumber = orderData.orderRefNumber;
                    this.accInformation.processInstanceId = orderData.processInstanceId;
                    this.accInformation.taskId = this.refObj.userData.taskId;
                    this.accInformation.taskName = 'Credit Review';
                }
            });
            this.orderSubscription.unsubscribe();
        }

        this.apptObservable = <Observable<any>>this.store.select('appointment');
        this.apptSubscription = this.apptObservable.subscribe((data) => {
            if (data.reservedAppointment) {
                this.reservedAppointment = data.reservedAppointment;
            } else if (data.payload && data.payload.dueDate && data.payload.dueDate.finalDueDate) {
                this.reservedAppointment = data.payload.dueDate.finalDueDate;
            }
        });

        this.retainObservable = <Observable<any>>this.store.select("retain");
        this.retainSubscription = this.retainObservable.subscribe(response => {
            this.retainObservableData = response;
            if (response.removedDTV) {
                this.removedDTV = response.removedDTV;
            }
            this.bypassButtonSelected = response.bypassvalue ? response.bypassvalue : false;
        });

        this.accountForm.valueChanges.subscribe(changedValue => {
            if (!this.accountForm.dirty) {
                this.accountForm_originalValues = JSON.stringify(this.accountForm.value);
            }
            if (this.accountForm.dirty) {
                this.accountForm_currentValues = JSON.stringify(this.accountForm.value);
            }
            if (this.accountForm_originalValues !== this.accountForm_currentValues) {
                this.accountForm_ValuesChanged = true;
            }

        });
    }

    public ngOnInit() {
        this.logger.metrics('AccountReuseBanPage');
        this.userdata = <Observable<User>>this.store.select('user');
        this.userSubscription$ = this.userdata.subscribe((userdata) => {
            this.bypassDepositUser = this.helperService.isAuthorized(ProfileEnums.BYPASS_SECURITY_DEPOSIT);
            if (!this.reEntrant) {
                if (!this.accountForm_ValuesChanged && userdata.autoLogin && userdata.autoLogin.sfcData && userdata.autoLogin.sfcData.emailID === '') {
                    this.accountForm.controls['emailAddress'].setValue('');
                    this.autoLoginEmailAddress = "";
                    this.emailPlaceHolder = 'Not provided';
                } else {
                    if (!this.emailAddrDeclinedManually && userdata.autoLogin.sfcData !== null && userdata.autoLogin.sfcData !== undefined && userdata.autoLogin.sfcData.emailID && userdata.autoLogin.sfcData.emailID !== undefined && userdata.autoLogin.sfcData.emailID !== null) {
                        this.contactDet.emailAddrDeclined = false;
                        this.autoLoginEmailAddress = (this.accInformation && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddress) ? this.accInformation.payload.accountInfo.contact.emailAddress : userdata.autoLogin.sfcData.emailID;

                    }
                }
            }
        });
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((respData) => {
            if (respData.dtvSessionInfo && respData.dtvSessionInfo.payload) {
                this.isDtvSessionInfo = true;
            }
        });

        window.scroll(0, 0);
        this.dtvForm = this.fb.group({
            'dtvAccNo': ['']
        });
        this.accountForm.get('emailAddress').valueChanges.debounceTime(750).subscribe((values) => {
            let isValidMail = Validations.emailValidator({ value: this.accountForm.value.emailAddress });
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
        });


        if (!this.reEntrant) {
            this.phoneNumber = this.refObj.userData.phoneNumber;
            if (this.autoLoginEmailAddress !== '' && this.autoLoginPhoneNumber !== '') {
                this.refObj.billingOptions[0]['disable'] = false;
                this.setDefaultNotification(0);
            } else if (this.autoLoginEmailAddress !== '' && this.autoLoginPhoneNumber === '') {
                this.refObj.billingOptions[1]['disable'] = false;
                this.setDefaultNotification(1);
            } else if (this.autoLoginEmailAddress === '' && this.autoLoginPhoneNumber !== '') {
                this.refObj.billingOptions[2]['disable'] = false;
                this.setDefaultNotification(2);
            }
        }
        if (this.accRespObj.accountInfo.billingAddress !== null && this.accRespObj.accountInfo.billingAddress !== undefined && !this.accRespObj.accountInfo.billingAddress.isValidated && !this.reEntrant) {
            this.postalAddressValidated = false;
        }

    }

    public disabledContinue() {
        if (this.isDtvOpus && this.newDtv && this.removedDTV) {
            return false;
        } else if (this.isDtvOpus && this.newDtv && !this.isDtvSessionInfo) {
            return true;
        } else if (this.creditInfo && this.creditInfo.creditClass === '9') {
            return true;
        } else if (this.refObj.submitted && (!this.postalAddressValidated || (!this.contactDet.emailAddrDeclined && !this.refObj.isEmailValid))) {
            return true;
        } else {
            return false;
        }
    }

    public ngAfterViewInit() {
        if (this.retainSSN !== undefined && this.retainSSN !== null && this.previousURL !== '/review-order') {
            this.ssnfield && this.ssnfield !== undefined && this.ssnfield.nativeElement !== undefined && this.ssnfield.nativeElement.focus();
        }
        this.accRespObj.accountPassword = this.accountPassword;
    }
    /** Initialize new account page data, after getting response */
    public initializeData() {
        this.accRespObj = this.accInformation.payload;
        this.ban = this.accRespObj.accountInfo.ban;
        if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.accountInfo.personalDetails && this.accRespObj.accountInfo.personalDetails !== undefined) {
            this.personalDet = this.accRespObj.accountInfo.personalDetails;
        }
        if (this.personalDet && this.personalDet !== undefined && this.personalDet.underAgeAck !== undefined && this.personalDet.underAgeAck) {
            this.personalDet.underAgeAck = false;
        }
        if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.accountInfo.contact && this.accRespObj.accountInfo.contact !== undefined) {
            this.contactDet = this.accRespObj.accountInfo.contact;
        }

        this.refObj.savedAddress = this.accRespObj.accountInfo.billingAddress;
        this.billingAddr = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
        this.serviceAddress = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
        this.accountHolderName = this.accRespObj.accountInfo.accountName.firstName + ' ' + (this.accRespObj.accountInfo.accountName.middleName ? this.accRespObj.accountInfo.accountName.middleName : '') + ' ' + (this.accRespObj.accountInfo.accountName.lastName ? this.accRespObj.accountInfo.accountName.lastName : '');
        this.creditObj = {
            'creditInfo': this.accInformation.payload.creditInfo,
            'depositInfo': this.accInformation.payload.depositInfo,
            'paymentDetails': this.accInformation.payload.paymentDetails,
            'addlOrderAttributes': this.accInformation.payload.addlOrderAttributes
        };
        this.initCreditInfo();
        this.creditReviewResp = this.accInformation;

        if (!this.isServiceAddressInitialized) {
            this.initialServiceAddress = Object.assign({}, this.serviceAddress);
            this.isServiceAddressInitialized = true;
        }
        let lzipcode: string;
        if (this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode !== undefined && this.billingAddr.postCode && this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix) {
            lzipcode = this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix;
        } else if (this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode && (this.billingAddr.postCodeSuffix === '' || this.billingAddr.postCodeSuffix === undefined)) {
            lzipcode = this.billingAddr.postCode;
        } else {
            lzipcode = '';
        }
        this.accountForm = this.fb.group({
            contactNumber: this.refObj.userData.phoneNumber ?
                [this.refObj.userData.phoneNumber, [Validators.required, Validations.phoneValidator]] :
                [this.contactDet.contactNumber, [Validators.required, Validations.phoneValidator]],
            smsNumber: this.contactDet.smsNumber ? [this.contactDet.smsNumber,
            [Validations.phoneValidator]] :
                ['', [Validations.phoneValidator]],
            emailAddress: this.contactDet.emailAddress ?
                [this.contactDet.emailAddress, [Validations.emailValidator]] :
                ['', [Validations.emailValidator]],
            zipCode: [lzipcode, Validations.zipCodeValidator],
            zipCodeInt: [(this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode !== undefined && this.billingAddr.postCode) ? this.billingAddr.postCode : '', Validations.zipCodeValidatorInt],
        });

        if (this.accountForm.value.contactNumber && this.accountForm.value.contactNumber !== "") {
            if (this.phoneNumber !== "") {
                this.accountForm.controls['contactNumber'].setValue(this.phoneNumber);
            }
            else {
                this.phoneNumber = this.accountForm.value.contactNumber;
                this.accountForm.controls['contactNumber'].setValue(this.phoneNumber);
            }

        }
        this.isInitializedFormObj = true;
        if (this.contactDet.emailAddrDeclined) {
            this.accountForm.controls['emailAddress'].setValue('');
            this.emailPlaceHolder = 'Not provided';
        }

        if (this.autoLoginEmailAddress) {
            this.accountForm.controls['emailAddress'].setValue(this.autoLoginEmailAddress);
        }
        if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.accountInfo.accountPreferences && this.accRespObj.accountInfo.accountPreferences !== undefined) {
            let loc: AccountPreferences = this.accRespObj.accountInfo.accountPreferences;
            Object.keys(loc).forEach((key) => {
                if (key !== 'emailNotification' && key !== 'textNotification' && loc[key] === null) {
                    loc[key] = false;
                }
            });
            this.accRespObj.accountInfo.accountPreferences = loc;
        }

        /** If no email, set billing options to SMS */
        if (!this.contactDet.emailAddress && !this.autoLoginEmailAddress) {
            this.refObj.billingOptions[1]['disable'] = true;
            this.refObj.billingOptions[0]['disable'] = true;
            let isValidMail = Validations.emailValidator({ value: this.autoLoginEmailAddress });
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
            this.setDefaultNotification(2);
        }
        /* If no smsNumber & valid email is present set billing options to Email,
        * else set to "Do not notify" */
        if (!this.contactDet.smsNumber && !this.autoLoginPhoneNumber) {
            this.refObj.billingOptions[2]['disable'] = true;
            this.refObj.billingOptions[0]['disable'] = true;
            this.setDefaultNotification(3);
            //this.refObj.isEmailValid ? this.setDefaultNotification(1) : this.setDefaultNotification(3);
        }
        if (this.personalDet.dateOfBirth) {
            let dateParts = this.personalDet.dateOfBirth.split('-');
            this.refObj.day = dateParts[2];
            this.refObj.month = dateParts[1];
            this.refObj.year = dateParts[0];
            this.getAge();
        }
        let prevyr = (new Date().getFullYear() - 1).toString();
        this.refObj.yrpatrn = '19[0-9][0-9]|200[0-9]|20[1-' + prevyr.substr(2, 1) + '][0-' + prevyr.substr(3, 1) + ']';
        if (this.reEntrant) {
            this.postalAddressValidated = true;
            if(this.accRespObj.accountInfo.accountPreferences.paperlessBilling) { this.refObj.billingOpt = 'paperless'; }
            if(this.accRespObj.accountInfo.accountPreferences.spanishBillPrint) { this.refObj.billingOpt = 'spanish'; }
            if(this.accRespObj.accountInfo.accountPreferences.largePrint) { this.refObj.billingOpt = 'large'; }
            if(this.accRespObj.accountInfo.accountPreferences.braille) { this.refObj.billingOpt = 'braille'; }
            if (this.accRespObj.accountInfo.accountPreferences.textNotification &&
                this.accRespObj.accountInfo.accountPreferences.emailNotification) {
                if (this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification &&
                    this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification) {
                    this.setBillingNotification(0);
                }
                else if (this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification && !this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification) {
                    this.setBillingNotification(2);
                }
                else if (this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification && !this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification) {
                    this.setBillingNotification(1);
                }
                else {
                    this.setBillingNotification(3);
                    this.refObj.billingChk = false;
                }

                if (this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification &&
                    this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification) {
                    this.setOrderNotification(0);
                }

                else if (this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification && !this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification) {
                    this.setOrderNotification(2);
                }
                else if (this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification && !this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification) {
                    this.setOrderNotification(1);
                }
                else {
                    this.setOrderNotification(3);
                    this.refObj.orderChk = false;
                }

                if (this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification &&
                    this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification) {
                    this.setRepairCheckNotification(0);
                }

                else if (this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification && !this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification) {
                    this.setRepairCheckNotification(2);
                }
                else if (this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification && !this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification) {
                    this.setRepairCheckNotification(1);
                }
                else {
                    this.setRepairCheckNotification(3);
                    this.refObj.repairChk = false;
                }
            }
        }
    }

    /** Initialize credit check variables after getting credit response */
    public initCreditInfo() {
        this.creditDepositInfo = this.creditObj.depositInfo;
        this.otcData1 = this.creditObj.addlOrderAttributes;
        this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup && this.otcData1[0].orderAttributeGroup.map(group => {
            if (group.orderAttributeGroupName === 'otcInstallmentInfo') {
                this.isOTCAvail = true;
            }
        });
        this.otcDataResponse = cloneDeep(this.otcData1);
        this.userPaidObj = this.creditObj.paymentDetails;
        this.products = [];
        this.refObj.pastDueAccs = [];
        this.store.dispatch({ type: 'CC_DONE', payload: true });
        if (this.creditDepositInfo !== undefined && this.creditDepositInfo.products && this.creditDepositInfo.products.length > 0) {
            this.products = this.creditDepositInfo.products;
            if (this.userPaidObj.depositPaymentStatus === 'PAID') {
                this.refObj.isPaymentSuccess = true;
                if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                    let paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                    this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
                } else {
                    let currDate = new Date();
                    this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
                }
                this.refObj.disableDepositBtn = true;
                this.refObj.paymentStatus = 'success';
            } else {
                let currDate = new Date();
                this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
            }
        } else {
            this.refObj.isPaymentSuccess = true;
        }
        this.creditInfo = this.creditObj.creditInfo;
        if (this.creditInfo !== undefined && this.creditInfo.finalBillInfo && this.creditInfo.finalBillInfo.length > 0) {
            this.refObj.pastDueAccs = this.creditInfo.finalBillInfo;
            if (this.userPaidObj.finalBillPaymentStatus === 'PAID') {
                this.refObj.isPaymentSuccessPD = true;
                if (this.userPaidObj.finalBillPaymentDate !== null && this.userPaidObj.finalBillPaymentDate !== '') {
                    let paidDate = this.userPaidObj.finalBillPaymentDate.split(' ')[0].split('-');
                    this.refObj.paidDatePD = paidDate[1] + '/' + paidDate[2];
                } else {
                    let currDate = new Date();
                    this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
                }
                this.refObj.paymentStatusPD = 'success';
                this.refObj.disablePastDueBtn = true;
            }
        } else {
            this.refObj.isPaymentSuccessPD = true;
        }
        let laccRespObjPostCode = this.accRespObj.accountInfo.billingAddress.postCode && this.accRespObj.accountInfo.billingAddress.postCodeSuffix !== undefined && this.accRespObj.accountInfo.billingAddress.postCodeSuffix !== '' ? this.accRespObj.accountInfo.billingAddress.postCode + ' - ' + this.accRespObj.accountInfo.billingAddress.postCodeSuffix : this.accRespObj.accountInfo.billingAddress.postCode;;
        let addr = `${this.accRespObj.accountInfo.billingAddress.streetAddress}, ${this.accRespObj.accountInfo.billingAddress.city}, ${this.accRespObj.accountInfo.billingAddress.stateOrProvince}, ${laccRespObjPostCode} ${this.accRespObj.accountInfo.billingAddress.country}`;;

        this.payobj = {
            name: this.accRespObj.accountInfo.accountName.firstName + ' ' +
                this.accRespObj.accountInfo.accountName.lastName,
            contactNumber: this.contactDet.contactNumber, address: addr,
            paymentheader: 'Advance payment required'
        };
        this.calculateTotalDeposit();
    }

    /** Set Billing Option display */
    public setDefaultNotification(index) {
        this.refObj.billingChk ? this.refObj.billingOption = this.refObj.billingOptions[index] : this.refObj.billingOption = this.refObj.billingOptions[3];
        this.refObj.orderChk ? this.refObj.orderOption = this.refObj.billingOptions[index] : this.refObj.orderOption = this.refObj.billingOptions[3];
        this.refObj.repairChk ? this.refObj.repairOption = this.refObj.billingOptions[index] : this.refObj.repairOption = this.refObj.billingOptions[3];
    }

    public setBillingNotification(index) {
        this.refObj.billingOption = this.refObj.billingOptions[index];
    }

    public setOrderNotification(index) {
        this.refObj.orderOption = this.refObj.billingOptions[index];
    }

    public setRepairCheckNotification(index) {
        this.refObj.repairOption = this.refObj.billingOptions[index];
    }

    public billingOptClickHandler(currentOpt, previousOpt) {
        if (currentOpt !== previousOpt) {
            this.refObj.billingOpt = currentOpt;
            this.refObj.selectedOpt = currentOpt;
        }
    }

    public unCheck(proactiveName) {
        if (proactiveName === 'billing') {
            this.refObj.billingOption === this.refObj.billingOptions[3] ? this.refObj.billingChk = false : this.refObj.billingChk = true;
        }
        if (proactiveName === 'ordering') {
            this.refObj.orderOption === this.refObj.billingOptions[3] ? this.refObj.orderChk = false : this.refObj.orderChk = true;
        }
        if (proactiveName === 'repair') {
            this.refObj.repairOption === this.refObj.billingOptions[3] ? this.refObj.repairChk = false : this.refObj.repairChk = true;
        }
    }

    /**
     * Validate entered email & smsNumber. Based on valid fields set billing options
     *  & disable remaining options
     */
    public emailPlaceHolder: string;
    public notificationValidation() {
        if (this.contactDet.emailAddrDeclined) {
            this.emailAddrDeclinedManually = true;
            this.accountForm.controls['emailAddress'].setValue('');
            this.autoLoginEmailAddress = "";
            this.emailPlaceHolder = 'Not provided';
        }
        else {
            this.emailPlaceHolder = '';
        }
        let isValidMail = Validations.emailValidator({ value: this.accountForm.value.emailAddress });
        if (isValidMail === null && this.refObj.billingOpt !== 'paperless') {
            this.refObj.billingOpt = 'paperless';
            this.refObj.selectedOpt = 'paperless';
        }
        if (!this.refObj.isEmailValid && this.refObj.billingOpt === 'paperless') {
            this.refObj.billingOpt = 'none';
            this.refObj.selectedOpt = 'none';
        }
        if (this.refObj.billingOpt === 'paperless' && this.contactDet.emailAddrDeclined) {
            isValidMail = { invalidEmailAddress: true };
            this.refObj.isEmailValid = false;
            this.refObj.billingOpt = 'none';
            this.refObj.selectedOpt = 'none';
        }

        this.billingOptionValidation();
    }
    public billingOptionValidation() {
        let isValidMail = Validations.emailValidator({ value: this.accountForm.value.emailAddress });
        let isValidPh = Validations.phoneValidator({ value: this.accountForm.value.smsNumber });
        if (isValidMail || isValidPh) {
            this.refObj.billingOptions[0]['disable'] = true;
        } else {
            this.refObj.billingOptions[0]['disable'] = false;
        }
        if (!isValidMail) {
            this.refObj.billingOptions[1]['disable'] = false;
            this.refObj.isEmailValid = true;
            this.setDefaultNotification(1);
        } else {
            this.refObj.billingOptions[1]['disable'] = true;
            this.refObj.isEmailValid = false;
        }
        if (!isValidPh) {
            this.refObj.billingOptions[2]['disable'] = false;
            this.refObj.isEmailValid === true ? this.setDefaultNotification(0) : this.setDefaultNotification(2);
        } else {
            this.refObj.billingOptions[2]['disable'] = true;
            this.refObj.isEmailValid === true ? this.setDefaultNotification(1) : this.setDefaultNotification(3);
        }
    }
    /** Get States from countryStateService */
    public getStates() {
        this.refObj.stateCountries = this.countryStateService.getStates();
        this.refObj.stateCountries.splice(0, 0, { stateName: 'Select State', stateCode: '' });
        let stateObj = this.refObj.stateCountries.find((obj) => obj.stateCode === this.accRespObj.accountInfo.billingAddress.stateOrProvince);
        stateObj ? this.refObj.selectedState = stateObj : this.refObj.selectedState = { stateName: 'Select State', stateCode: '' };
    }

    public checkUpdatedOtc(data) {
        this.otcUpdated = data;
    }

    /** Get MilitaryStates from countryStateService */
    public getMilitaryState() {
        this.refObj.stateCountries = this.countryStateService.getMilitaryStates();
        this.refObj.stateCountries.splice(0, 0, { militaryStateName: 'Select Armed Forces Location', militaryStateCode: '' });
        let armyLoc = this.refObj.stateCountries.find((obj) =>
            obj.militaryStateCode === (this.reEntrant ? this.accRespObj.accountInfo.billingAddress.stateOrProvince : (this.accRespObj.accountInfo.billingAddress.armedForceLoc ? this.accRespObj.accountInfo.billingAddress.armedForceLoc : this.accRespObj.accountInfo.billingAddress.stateOrProvince))
        );
        armyLoc ? this.refObj.selectedState = armyLoc : this.refObj.selectedState = this.refObj.stateCountries[0];
    }

    /** Get Countries from countryStateService */
    public getCountries() {
        this.loading = true;
        let countryListReq = {
            "inputAttribute": [
                {
                    "attributeName": "dataType",
                    "attributeValue": [
                        "countryList"
                    ]
                }
            ],
            "outputAttribute": [
                {
                    "attributeName": "countryISOCode"
                },
                {
                    "attributeName": "countryName"
                }
            ],
            "requestDate": "",
            "ruleId": "100"
        };

        let countryRes = '';
        let countryResObj: any = '';

        let errorResolved = false;
        this.logger.log("info", "reuse-ban-account.component.ts", "getInternationalBillingCountryListRequest", JSON.stringify(countryListReq));
        this.logger.startTime();
        this.accountService.getInternationalBillingCountryList(countryListReq)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "getInternationalBillingCountryListResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(error._body);
            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "reuse-ban-account.component.ts", "getInternationalBillingCountryListResponse", JSON.stringify(data));
                this.logger.log("info", "reuse-ban-account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                countryRes = JSON.stringify(data);
                countryResObj = JSON.parse(countryRes);
                let countryResAry = [];
                countryResAry = countryResObj.outputAttribute;
                let countryAry = [];
                for (var i = 0, len = countryResAry.length; i < len; i++) {
                    let countr = {};
                    countr['countryCode'] = countryResAry[i][0];
                    countr['countryName'] = countryResAry[i][1];
                    countryAry.push(countr);
                }

                this.refObj.stateCountries = countryAry;
                this.refObj.stateCountries.splice(0, 0, { countryName: 'Select Country', countryCode: '' });
                let country = this.refObj.stateCountries.find((obj) =>
                    obj.countryCode === this.accRespObj.accountInfo.billingAddress.country
                );
                if (this.refObj.addrModels.field1 === "") {
                    this.refObj.selectedState = this.refObj.stateCountries[0];
                    this.accountForm.patchValue({ zipCodeInt: '' });

                } else {
                    country ? this.refObj.selectedState = country : this.refObj.selectedState = this.refObj.stateCountries[0];
                }
                this.loading = false;
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "reuse-ban-account.component.ts", "getInternationalBillingCountryListResponse", error);
                    this.logger.log("error", "reuse-ban-account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) {
                        return;
                    }
                    try {
                        this.apiResponseError = JSON.parse(error);
                    } catch (e) {
                        if (error.status === 500) {
                            let lAPIErrorLists: APIErrorLists = {
                                errorResponse: [{
                                    statusCode: "500",
                                    reasonCode: "500",
                                    message: "500 Internal Server Error",
                                    messageDetail: "Discount compatibility error",
                                    source: "",
                                    timestamp: "",
                                    orderRefNumber: "",
                                    serverDown: "",
                                    tnNotFound: "",
                                    tnNotAvail: ""
                                }]
                            };
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        } else {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        }
                    }
                    if (this.apiResponseError && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", this.apiResponseError);
                    } else {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                    }
                });
    }

    /** Change billing address click handler */
    public handleChangeAddr() {
        this.refObj.changeAddrClicked = true;
        if (this.refObj.addrTypeSelected) {
            this.refObj.addrTypeSelected = this.refObj.addrTypeSelected;
        } else if (this.refObj.addrTypeSelected === '' || this.refObj.addrTypeSelected === null || this.refObj.addrTypeSelected === undefined) {
            this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
        } else if (this.accRespObj.accountInfo.billingAddress.addressTypeSelected) {
            this.refObj.addrTypeSelected = this.accRespObj.accountInfo.billingAddress.addressTypeSelected;
        } else if (this.accRespObj.accountInfo.billingAddress.subAddress && (this.accRespObj.accountInfo.billingAddress.subAddress.combinedDesignator !== null || this.accRespObj.accountInfo.billingAddress.subAddress.combinedDesignator !== undefined || this.accRespObj.accountInfo.billingAddress.subAddress.combinedDesignator !== '')) {
            this.accRespObj.accountInfo.billingAddress.addressTypeSelected = this.refObj.addressTypes[1];
            this.refObj.addrTypeSelected = this.refObj.addressTypes[1];
        } else {
            this.accRespObj.accountInfo.billingAddress.addressTypeSelected = this.refObj.addressTypes[0];
            this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
        }
        this.refObj.initialAddrType = this.refObj.addrTypeSelected;
        this.addressTypeSelectionHandler();
    }

    /** Change billing address, different address type selection handler */
    public addressTypeSelectionHandler() {
        if (this.apiResponseError && this.apiResponseError.errorResponse[0]) {
            this.apiResponseError.errorResponse[0].messageDetail = '';
        }
        this.billingAddr = {
            city: '', street: '', addressLine: '', stateOrProvince: '',
            streetType: '', addressTypeSelected: this.refObj.addrTypeSelected
        };
        if (this.accRespObj.accountInfo.billingAddress.postCodeSuffix) {
            this.accountForm.patchValue({ zipCode: this.accRespObj.accountInfo.billingAddress.postCode + '-' + this.accRespObj.accountInfo.billingAddress.postCodeSuffix });
        } else {
            this.accountForm.patchValue({ zipCode: this.accRespObj.accountInfo.billingAddress.postCode });
        }
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Street Address', addrPlchd2: 'Unit #',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: this.accRespObj.accountInfo.billingAddress.streetAddress ?
                        this.accRespObj.accountInfo.billingAddress.streetAddress : '',
                    field2: this.accRespObj.accountInfo.billingAddress.unitNumber ?
                        this.accRespObj.accountInfo.billingAddress.unitNumber : '',
                    field3: this.accRespObj.accountInfo.billingAddress.city ? this.accRespObj.accountInfo.billingAddress.city : this.accRespObj.accountInfo.billingAddress.locality
                };
                this.getStates();
                break;
            case 'P.O. Box':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Box Number', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: this.accRespObj.accountInfo.billingAddress.streetNrFirst ?
                        this.accRespObj.accountInfo.billingAddress.streetNrFirst : '',
                    field2: this.accRespObj.accountInfo.billingAddress.subAddress.combinedDesignator ?
                        this.accRespObj.accountInfo.billingAddress.subAddress.combinedDesignator : '',
                    field3: this.accRespObj.accountInfo.billingAddress.city ? this.accRespObj.accountInfo.billingAddress.city : this.accRespObj.accountInfo.billingAddress.locality
                };
                this.getStates();
                break;
            case 'Rural Route':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Rural Route', addrPlchd2: 'Box Number',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: this.accRespObj.accountInfo.billingAddress.streetName ?
                        this.accRespObj.accountInfo.billingAddress.streetName.replace("RR ", '') : this.accRespObj.accountInfo.billingAddress.streetAddress,
                    field2: this.accRespObj.accountInfo.billingAddress.streetNrFirst ?
                        this.accRespObj.accountInfo.billingAddress.streetNrFirst : '',
                    field3: this.accRespObj.accountInfo.billingAddress.city ? this.accRespObj.accountInfo.billingAddress.city : this.accRespObj.accountInfo.billingAddress.locality
                };
                this.getStates();
                break;
            case 'Military':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'APO, FPO, DPO'
                };
                if (this.accRespObj.accountInfo.billingAddress.apoFpoDpo) {
                    this.refObj.addrModels = {
                        field1: this.accRespObj.accountInfo.billingAddress.addressLine1 ?
                            this.accRespObj.accountInfo.billingAddress.addressLine1 : this.accRespObj.accountInfo.billingAddress.streetAddress,
                        field2: this.accRespObj.accountInfo.billingAddress.addressLine2 ?
                            this.accRespObj.accountInfo.billingAddress.addressLine2 : '',
                        field3: this.accRespObj.accountInfo.billingAddress.apoFpoDpo ?
                            this.accRespObj.accountInfo.billingAddress.apoFpoDpo : ''
                    };
                } else {
                    this.refObj.addrModels = {
                        field1: this.accRespObj.accountInfo.billingAddress.addressLine1 ?
                            this.accRespObj.accountInfo.billingAddress.addressLine1 : this.accRespObj.accountInfo.billingAddress.streetName,
                        field2: this.accRespObj.accountInfo.billingAddress.addressLine2 ?
                            this.accRespObj.accountInfo.billingAddress.addressLine2 : this.accRespObj.accountInfo.billingAddress.streetNrFirst,
                        field3: this.accRespObj.accountInfo.billingAddress.apoFpoDpo ?
                            this.accRespObj.accountInfo.billingAddress.apoFpoDpo : this.accRespObj.accountInfo.billingAddress.city
                    };
                }
                this.getMilitaryState();
                break;
            case 'International':
                this.refObj.disableValidateAddr = true;
                this.refObj.disableSaveAddr = false;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'City'
                };

                this.refObj.addrModels = {
                    field1: this.accRespObj.accountInfo.billingAddress.addressLine1 ?
                        this.accRespObj.accountInfo.billingAddress.addressLine1 : this.accRespObj.accountInfo.billingAddress.streetAddress,
                    field2: this.accRespObj.accountInfo.billingAddress.addressLine2 ?
                        this.accRespObj.accountInfo.billingAddress.addressLine2 : this.accRespObj.accountInfo.billingAddress.streetName,
                    field3: this.accRespObj.accountInfo.billingAddress.city ? this.accRespObj.accountInfo.billingAddress.city : this.accRespObj.accountInfo.billingAddress.locality
                };
                this.getCountries();
                break;
            default: break;
        }
        if (this.refObj.initialAddrType !== this.refObj.addrTypeSelected) {
            this.accountForm.patchValue({ zipCode: '' });
            this.refObj.addrModels = {
                field1: '', field2: '', field3: ''
            };
        }
    }

    /** Change billing address state/country selection handler */
    public stateCountrySelectionHandler() {
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
            case 'P.O. Box':
            case 'Rural Route':
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                break;
            case 'Military':
                this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
                break;
            case 'International':
                this.billingAddr.country = this.refObj.selectedState.countryCode;
                break;
            default: break;
        }
    }

    /** Change billing address Validate button handler */
    public validateBillingAddr() {
        this.refObj.isExactAddr = '';
        this.refObj.disableSaveAddr = true;
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
                this.billingAddr.streetAddress = this.refObj.addrModels.field1;
                this.billingAddr.addressLine1 = this.billingAddr.streetAddress;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.streetAddress}
                                        ${this.billingAddr.addressLine2},
                                        ${this.billingAddr.stateOrProvince}, 
                                        ${this.billingAddr.city}`;
                break;
            case 'P.O. Box':
                this.billingAddr.streetAddress = "PO BOX " + this.refObj.addrModels.field1;
                this.billingAddr.boxNumber = "PO BOX " + this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.addressLine1 = this.billingAddr.boxNumber;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.boxNumber}
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.stateOrProvince}, 
                                        ${this.billingAddr.city}`;
                break;
            case 'Rural Route':
                this.billingAddr.ruralRoute = this.refObj.addrModels.field1;
                this.billingAddr.boxNumber = this.refObj.addrModels.field2;
                this.billingAddr.addressLine1 = "RR " + this.billingAddr.ruralRoute;
                this.billingAddr.addressLine2 = "BOX " + this.billingAddr.boxNumber;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.ruralRoute}
                                    ${this.billingAddr.boxNumber}, 
                                    ${this.billingAddr.stateOrProvince}, 
                                    ${this.billingAddr.city}`;
                break;
            case 'Military':
                this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.apoFpoDpo = this.refObj.addrModels.field3;
                this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
                this.billingAddr.city = this.billingAddr.apoFpoDpo;
                this.billingAddr.locality = this.billingAddr.city;
                this.billingAddr.stateOrProvince = this.billingAddr.armedForceLoc;
                this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.apoFpoDpo}, 
                                        ${this.billingAddr.armedForceLoc}`;
                break;
            case 'International':
                this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.billingAddr.country = this.refObj.selectedState.countryCode;
                this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.city},
                                        ${this.billingAddr.country}`;
                break;
            default: break;
        }

        this.billingAddr.postCode = this.accountForm.value.zipCode;
        let zipValid = Validations.zipCodeValidator({ value: this.accountForm.value.zipCode });
        /** Unit number is optional for street address, checking with only mandatory fields */
        if (!this.refObj.addrModels.field1 || !this.refObj.addrModels.field3 || zipValid) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        if (this.refObj.addrTypeSelected === '' || this.refObj.addrTypeSelected === undefined) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        if (!this.refObj.selectedState.stateCode && !this.refObj.selectedState.militaryStateCode
            && !this.refObj.selectedState.countryCode) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        this.refObj.isEnteredAllAddsFields = true;
        let lpostCode = this.billingAddr.postCode.length === 5 && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix !== '' ? this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix : this.billingAddr.postCode;
        this.refObj.combinedAddress = this.refObj.combinedAddress + ', ' + lpostCode;
        let civicOrpostal =  'postalAddresses';
        this.loading = true;
        this.logger.log("info", "reuse-ban-account.component.ts", "geoesAddressValidationRequest", JSON.stringify(this.billingAddr));
        let errorResolved = false;
        this.logger.startTime();
        this.addressService.getGeoesAddress(this.billingAddr, civicOrpostal)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "geoesAddressValidationResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "geoesAddressValidationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "reuse-ban-account.component.ts", "geoesAddressValidationResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "reuse-ban-account.component.ts", "getE911AcntPageSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let respAddressesArray = [];
                    this.loading = false;
                    let lunitNumber: string = '';
                    if (civicOrpostal === 'civicAddresses') {
                        respAddressesArray = data.civicAddresses;
                    } else {
                        respAddressesArray = data.postalAddresses;
                    }

                    if (data && data !== undefined && data !== null && data.result === "Green") {
                        this.refObj.isExactAddr = 'exact';
                        this.refObj.disableSaveAddr = false;
                        if (respAddressesArray[0].subAddress !== undefined) {
                            lunitNumber = respAddressesArray[0].subAddress.designator + ' ' + respAddressesArray[0].subAddress.value;
                        }
                        let geoesResponseAddress: EnterpriseAddress = {
                            isValidated: true,
                            streetAddress: respAddressesArray[0].streetAddress,
                            streetNrFirst: respAddressesArray[0].streetNrFirst,
                            streetNrFirstSuffix: '',
                            streetNamePrefix: respAddressesArray[0].streetNamePrefix,
                            streetName: respAddressesArray[0].streetName,
                            streetType: respAddressesArray[0].streetType,
                            locality: respAddressesArray[0].locality,
                            city: respAddressesArray[0].locality,
                            stateOrProvince: respAddressesArray[0].stateOrProvince,
                            postCode: respAddressesArray[0].postCode,
                            postCodeSuffix: respAddressesArray[0].postCodeSuffix !== 'undefined' ? respAddressesArray[0].postCodeSuffix : '',
                            source: respAddressesArray[0].source,
                            country: 'USA',
                            subAddress: {
                                sourceId: '',
                                source: respAddressesArray[0].source,
                                geoSubAddressId: '',
                                combinedDesignator: lunitNumber,
                                elements: [
                                    {
                                        designator: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.designator !== undefined ? respAddressesArray[0].subAddress.designator : '',
                                        value: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.value !== undefined ? respAddressesArray[0].subAddress.value : ''
                                    }
                                ]
                            }
                        };
                        this.accRespObj.accountInfo.billingAddress = geoesResponseAddress;
                        this.refObj.validatedAddr = this.accRespObj.accountInfo.billingAddress;
                        this.refObj.savedAddress = this.accRespObj.accountInfo.billingAddress;
                        this.refObj.selectedAddr = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
                        this.accRespObj.accountInfo.isBillAddrSameAsServiceAddress = false;
                        this.accountObservable = <Observable<any>>this.store.select('account');
                        this.accRespObj.accountInfo.contact.emailAddress = this.accountForm.value.emailAddress;
                        this.accRespObj.accountInfo.contact.contactNumber = this.accountForm.value.contactNumber;
                        this.accInformation.payload.accountInfo.billingAddress = this.refObj.savedAddress;
                        this.store.dispatch({ type: 'BILLING_ADDRESS', payload: this.accRespObj });

                    } else if (data && data !== undefined && data !== null && data.result === 'Yellow') {
                        this.refObj.isExactAddr = 'multi';
                        this.refObj.nearAddresses = [];
                        for (let i = 0; i < respAddressesArray.length; i++) {
                            if (respAddressesArray[i].subAddress !== undefined) {
                                lunitNumber = respAddressesArray[i].subAddress.designator + ' ' + respAddressesArray[i].subAddress.value;
                            }
                            let geoesResponseAddress: EnterpriseAddress = {
                                isValidated: true,
                                streetAddress: respAddressesArray[i].streetAddress,
                                streetNrFirst: respAddressesArray[i].streetNrFirst,
                                streetNrFirstSuffix: '',
                                streetNamePrefix: respAddressesArray[i].streetNamePrefix,
                                streetName: respAddressesArray[i].streetName,
                                streetType: respAddressesArray[i].streetType,
                                locality: respAddressesArray[i].locality,
                                city: respAddressesArray[i].locality,
                                stateOrProvince: respAddressesArray[i].stateOrProvince,
                                postCode: respAddressesArray[i].postCode,
                                postCodeSuffix: respAddressesArray[i].postCodeSuffix !== 'undefined' ? respAddressesArray[i].postCodeSuffix : '',
                                source: respAddressesArray[i].source,
                                country: 'USA',
                                subAddress: {
                                    sourceId: '',
                                    source: respAddressesArray[i].source,
                                    geoSubAddressId: '',
                                    combinedDesignator: lunitNumber,
                                    elements: [
                                        {
                                            designator: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.designator !== undefined ? respAddressesArray[i].subAddress.designator : '',
                                            value: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.value !== undefined ? respAddressesArray[i].subAddress.value : ''
                                        }
                                    ]
                                }
                            };
                            this.refObj.nearAddresses.push(geoesResponseAddress);
                        }
                        const newNearAddress = Object.assign({}, this.accRespObj.accountInfo.billingAddress, this.billingAddr);
                        if (newNearAddress.postCode.indexOf("-") > -1) {
                            newNearAddress.postCode = newNearAddress.postCode.substr(0, newNearAddress.postCode.indexOf("-"));
                        }
                        this.refObj.nearAddresses.push(newNearAddress);
                    } else {
                        this.refObj.isExactAddr = 'red';
                    }
                },
                (error) => {
                    if (error === undefined || error === null) {
                        return;
                    }
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "reuse-ban-account.component.ts", "geoesAddressValidationResponse", error);
                        this.logger.log("error", "reuse-ban-account.component.ts", "geoesAddressValidationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                }
            );
    }

    /** Billing address selection handler from multiple addresses, after validation */
    public addressRadioHandler() {
        this.refObj.disableSaveAddr = false;
        this.refObj.selectedAddr.addressTypeSelected = this.refObj.addrTypeSelected;
        let lpostCode = this.refObj.selectedAddr.postCode && this.refObj.selectedAddr.postCodeSuffix !== undefined && this.refObj.selectedAddr.postCodeSuffix !== '' ? this.refObj.selectedAddr.postCode + ' - ' + this.refObj.selectedAddr.postCodeSuffix : this.refObj.selectedAddr.postCode;
        this.refObj.combinedAddress = `${this.refObj.selectedAddr.streetAddress}
        ${this.refObj.selectedAddr.unitNumber ? ', ' + this.refObj.selectedAddr.unitNumber : ''}
                              ${this.refObj.selectedAddr.city ? this.refObj.selectedAddr.city : this.refObj.selectedAddr.locality}, 
                              ${this.refObj.selectedAddr.stateOrProvince} 
                              ${lpostCode}`;
    }

    /** Save billing address button handler */
    public saveChangedAddr() {
        if ((!this.refObj.addrModels.field1 || !this.refObj.selectedState.countryCode) && this.refObj.addrTypeSelected === "International") {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        this.postalAddressValidated = true;
        this.billingAddr = this.refObj.selectedAddr;
        if (this.refObj.addrTypeSelected === 'International') {
            this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
            this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
            this.billingAddr.city = this.refObj.addrModels.field3;
            this.billingAddr.locality = this.billingAddr.city;
            this.billingAddr.postCode = this.accountForm.value.zipCodeInt;
            this.billingAddr.country = this.refObj.selectedState.countryCode;
            this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                    ${this.billingAddr.addressLine2}, 
                                    ${this.billingAddr.city},
                                    ${this.billingAddr.country}`;
            this.refObj.selectedAddr = this.billingAddr;

            let internationalAddressEntry: EnterpriseAddress = {
                isValidated: true,
                streetAddress: this.refObj.addrModels.field1,
                streetNrFirst: '',
                streetNrFirstSuffix: '',
                streetNamePrefix: '',
                streetName: this.refObj.addrModels.field2,
                streetType: '',
                locality: this.refObj.addrModels.field3,
                city: this.refObj.addrModels.field3,
                stateOrProvince: '',
                postCode: this.billingAddr.postCode,
                postCodeSuffix: '',
                source: '',
                country: this.billingAddr.country,
                subAddress: {
                    sourceId: '',
                    source: '',
                    geoSubAddressId: '',
                    combinedDesignator: '',
                    elements: [
                        {
                            designator: '',
                            value: ''
                        }
                    ]
                }
            };
            this.store.dispatch({ type: 'ADD_TYPE', payload: this.refObj.addrTypeSelected });
            this.refObj.savedAddress = this.refObj.selectedAddr;
            this.refObj.isExactAddr = '';
            this.refObj.disableSaveAddr = true;
            this.accRespObj.accountInfo.billingAddress = Object.assign({}, internationalAddressEntry);
            this.refObj.changeAddrClicked = false;
            this.accRespObj.accountInfo.isBillAddrSameAsServiceAddress = false;
        } else {
            this.store.dispatch({ type: 'ADD_TYPE', payload: this.refObj.addrTypeSelected });
            this.refObj.savedAddress = this.refObj.selectedAddr;
            this.refObj.isExactAddr = '';
            this.refObj.disableSaveAddr = true;
            this.accRespObj.accountInfo.billingAddress = Object.assign({}, this.refObj.selectedAddr);
            this.refObj.changeAddrClicked = false;
            this.accRespObj.accountInfo.isBillAddrSameAsServiceAddress = false;
        }
        this.store.dispatch({ type: 'BILLING_ADDR', payload: this.accRespObj.accountInfo.billingAddress });

    }

    public useServiceAddress() {
        this.serviceAddress = Object.assign({}, this.initialServiceAddress);
        this.refObj.savedAddress = Object.assign({}, this.serviceAddress);
        this.billingAddr = Object.assign({}, this.serviceAddress);
        this.accRespObj.accountInfo.billingAddress = Object.assign({}, this.serviceAddress);
        this.accRespObj.accountInfo.isBillAddrSameAsServiceAddress = true;
        this.refObj.changeAddrClicked = false;
        this.refObj.isExactAddr = '';
        this.refObj.disableSaveAddr = true;
    }
    public setDefaultVal(proactiveName) {
        if (proactiveName === 'bill') {
            this.refObj.billingChk ? this.billingOptionValidation() : this.refObj.billingOption = this.refObj.billingOptions[3];
        }
        if (proactiveName === 'order') {
            this.refObj.orderChk ? this.billingOptionValidation() : this.refObj.orderOption = this.refObj.billingOptions[3];
        }
        if (proactiveName === 'repair') {
            this.refObj.repairChk ? this.billingOptionValidation() : this.refObj.repairOption = this.refObj.billingOptions[3];
        }
    }

    public onKeyUpAccountPassword() {
        this.accountPasswordPin = true;
        this.store.dispatch({ type: 'ACCOUNTPASSWORD_PIN', payload: this.accountPasswordPin });
        let inValidAccPassword = Validations.accountPasswordValidator({ value: this.accRespObj.accountPassword });
        if (!inValidAccPassword) {
            this.refObj.isValidAccPassword = true;
        } else {
            this.refObj.isValidAccPassword = false;
        }
    }


    public displayEmailMandatoryAlert() {
        if ((!this.refObj.isEmailValid && !this.contactDet.emailAddrDeclined) || (this.contactDet.emailAddrDeclined && this.refObj.billingOpt === 'paperless')) {
            window.scroll(0, 200);
        }
    }

    public showOption(installmentOptions) {
        if (installmentOptions && installmentOptions.noOfInstallments > 1) {
            return true;
        } else {
            return false;
        }
    }

    public isOTCAvail = false;



    /** Function to Calulate age */
    public getAge() {
        if (this.refObj.month && this.refObj.day && this.refObj.year) {
            let isDobValid = Validations
                .dobValidator(this.refObj.month, this.refObj.day, this.refObj.year);
            if (!isDobValid) {
                let today = new Date();
                let birthDate = new Date(this.refObj.month + '/' + this.refObj.day
                    + '/' + this.refObj.year);
                let age = today.getFullYear() - birthDate.getFullYear();
                let m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                age < 18 ? this.refObj.underAge = true : this.refObj.underAge = false;
                this.personalDet.dateOfBirth = this.refObj.year + '-' + this.refObj.month +
                    '-' + this.refObj.day;
                this.personalDet.underAgeAck = false;
                this.refObj.isValidDob = true;
            } else {
                this.refObj.isValidDob = false;
                this.refObj.dobMessage = isDobValid.message;
            }
        }
    }

    private prepareInstDepositReq(product: any) {
        let arr = [
            { orderAttributeName: 'productType', orderAttributeValue: product.productType },
        ];
        for (let item of product.installmentOptions) {
            if (item.noOfInstallments === 1) {
                arr.push({ orderAttributeName: 'totalDepositAmount', orderAttributeValue: item.paymentAmount });
            }
            if (item.paymentAmount === product.depositAmount.amount) {
                arr.push({ orderAttributeName: 'selectedNoOfInstallment', orderAttributeValue: item.noOfInstallments });
                arr.push({ orderAttributeName: 'installmentAmount', orderAttributeValue: item.paymentAmount });
            }
        }
        this.refObj.depositInstallmentObj.push({ orderAttributes: arr });
    }

    /** On installment option selection calculate total deposit */
    public calculateTotalDeposit() {
        let tot = 0;
        this.refObj.depositInstallmentObj = [];
        for (let prd of this.products) {
            if (!this.allProductsPaid && ((!this.hsiPaymentDone && prd.productType === 'INTERNET') || (!this.potsPaymentDone && prd.productType === 'VOICE-HP') || (!this.dhpPaymentDone && prd.productType === 'VOICE-DHP')) || this.allProductsPaid) {
                tot += parseInt(prd.depositAmount.amount, 10);
                if (prd.installmentOptions.length) {
                    this.prepareInstDepositReq(prd);
                }
            }
        }
        this.refObj.totalDepositAmount = tot;
        this.payobj.amount = tot;

    }

    /** Set content for deposit modal */
    public setModalDepositData(modalRef, urlObj) {
        this.visibleDeposit = true;
        this.refObj.disableDepositBtn = true;
        this.payobj.paymentStatement = 'Total Deposit Due Today';
        this.payobj.isDepositModal = true;
        this.payobj.amount = this.refObj.totalDepositAmount;
        this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(`${env.DEPOSIT_AND_FINAL_BILL_URL}` + urlObj.paymentURL + urlObj.sessionId);
        modalRef.open();
    }

    /** Set content for past due modal */
    public setModalBalanceData(balanceAccDet, modalRef, urlObj) {
        this.visibleBalance = true;
        this.refObj.disablePastDueBtn = true;
        this.payobj.paymentStatement = 'Total Payment Due Today';
        this.payobj.isDepositModal = false;
        this.payobj.acctNumber = balanceAccDet.btn;
        this.payobj.amount = balanceAccDet.finalBillAmt.amount;
        this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(`${env.DEPOSIT_AND_FINAL_BILL_URL}` + urlObj.paymentURL + urlObj.sessionId);
        modalRef.open();
    }

    /**
     * Function to prepare deposit products request
    * @param paidDepositProd
     */
    public prepareDepositRequest() {
        let paymentObj: PaymentInfo = {
            sessionId: this.refObj.sessionId,
            paymentCategory: "DEPOSIT",
            paymentStatus: "SUCCESS",
            paymentErr: null
        };
        this.paymentReqObj.push(paymentObj);
    }

    /**
     * Function to prepare Past due account request
     * @param paidPastAccount
     */
    public preparePastDueRequest() {
        let paymentObj: PaymentInfo = {
            sessionId: this.refObj.sessionId,
            paymentCategory: "PASTDUE",
            paymentStatus: "SUCCESS",
            paymentErr: null
        };
        this.paymentReqObj.push(paymentObj);
    }

    public retryGetPaymentDetails(depOrFBill, modalRef, dueObj, flow) {
        this.loading = true;
        this.retryButtonEnabled = true;
        let callbackURL = 'https://' + window.location.hostname + (window.location.port ? ":" + window.location.port : "") + '/';
        let reqObj: any = {
            orderRefNumber: this.creditReviewResp.orderRefNumber,
            processInstanceId: this.creditReviewResp.processInstanceId,
            taskId: this.refObj.userData.taskId,
            taskName: this.creditReviewResp.taskName,
            payload: {
                creditReviewAction: depOrFBill === 'DEPOSIT' ? this.enumActions.PAY_DEPOSIT : this.enumActions.PAY_FBILL,
                addlOrderAttributes: [{
                    orderAttributeGroup: [{
                        orderAttributeGroupName: 'paymentCallbackURL',
                        orderAttributeGroupInfo: [{
                            orderAttributes: [{
                                orderAttributeName: 'hostname',
                                orderAttributeValue: callbackURL
                            }]
                        }]
                    }]
                }]
            }
        };
        let payloadAddtlObj = {
            'orderAttributeGroupName': 'depositCreated',
            'orderAttributeGroupInfo': [{
                'orderAttributes':
                    [{
                        'orderAttributeName': 'depositCreatedInd',
                        'orderAttributeValue': flow === 'retry' ? true : false
                    }]
            }]
        };
        reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push(payloadAddtlObj);
        if (depOrFBill === 'DEPOSIT') {
            if (this.refObj.depositInstallmentObj && this.refObj.depositInstallmentObj.length) {
                reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push({
                    'orderAttributeGroupName': 'depositInstallmentSelection',
                    'orderAttributeGroupInfo': this.refObj.depositInstallmentObj
                });
            }
            let payloadAddtlObj = {
                'orderAttributeGroupName': 'depositOnOrder',
                'orderAttributeGroupInfo': [
                    {
                        'orderAttributes': [
                            {
                                'orderAttributeName': 'depositDueToday',
                                'orderAttributeValue': this.refObj.totalDepositAmount
                            }
                        ]
                    }
                ]
            };
            reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push(payloadAddtlObj);
        }

        let errorResolved = false;
        this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoRequest", JSON.stringify(reqObj));
        this.logger.startTime();
        this.accountService.getCreditResponse(reqObj)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(error._body);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                    this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.apiResponseError = null;
                    this.creditReviewResp.taskId = respData.taskId;
                    this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
                    this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                    depOrFBill === 'DEPOSIT' ? this.setModalDepositData(modalRef, respData.payload.depositBillpaymentURL) :
                        this.setModalBalanceData(dueObj, modalRef, respData.payload.finalBillpaymentURL);
                    this.loading = false;
                },
                (error) => {
                    if (error === undefined || error === null) {
                        return;
                    }
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoResponse", error);
                        this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "reuse-ban-account.component.ts", "Account Page", this.apiResponseError);
                        } else { unexpectedError = true; }
                    } else { unexpectedError = true; }
                    if (unexpectedError) {
                        let errorResponseCustom: ErrorResponse = {
                            statusCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDown
                        };
                        if (this.apiResponseError && this.apiResponseError.errorResponse) {
                            this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                            this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                        }
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "reuse-ban-account.component.ts", "Account Page", lAPIErrorLists);
                    }
                });
    }

    public updatePaidDetails(paymentRespAttrs) {
        if (paymentRespAttrs.paymentStatus === 'success') {
            this.loading = true;
            this.allProductsPaid = true;
            this.paidSecurityDeposit = true;
            this.store.dispatch({ type: 'PAYMENT_STATUS', payload: true });
            if (this.allProductsPaid) {
                this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup.map(data => {
                    if (data && data.orderAttributeGroupName === "depositData") {
                        data.orderAttributeGroupInfo && data.orderAttributeGroupInfo.map(addatrData => {
                            addatrData && addatrData.orderAttributes && addatrData.orderAttributes.map(dat => {
                                if (dat && dat.orderAttributeName === "depositPayStatus") {
                                    dat.orderAttributeValue = 'PAID';
                                }
                            });
                        });
                    }
                });
            }
            this.initCreditInfo();
            let reqObj: any = {
                orderRefNumber: this.creditReviewResp.orderRefNumber,
                processInstanceId: this.creditReviewResp.processInstanceId,
                taskId: this.creditReviewResp.taskId,
                taskName: 'Payments',
                payload: {
                    paymentStatus: [{
                        sessionId: paymentRespAttrs.sessionId,
                        paymentCategory: paymentRespAttrs.invokeCall === 'Pay Deposit' ? 'DEPOSIT' : 'PASTDUE',
                        paymentStatus: paymentRespAttrs.error === 'success' ? 'SUCCESS' : 'FAIL',
                        paymentErr: [{
                            errorCode: '',
                            errorDesc: ''
                        }]
                    }]
                }
            };

            let errorResolved = false;
            this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoRequest", JSON.stringify(reqObj));
            this.logger.startTime();
            this.accountService.getCreditResponse(reqObj)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoResponse", error);
                    this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    errorResolved = true;
                    this.ctlHelperService.setLocalStorage('error', error);
                    this.loading = false;
                    return Observable.throwError(error._body);
                })
                .subscribe(
                    (respData) => {
                        this.logger.endTime();
                        this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                        this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.apiResponseError = null;
                        this.creditReviewResp.payload.paymentDetails = respData.payload.paymentDetails;
                        this.creditReviewResp.taskId = respData.taskId;
                        this.refObj.userData.taskId = respData.taskId;
                        this.creditReviewResp.taskName = respData.taskName;
                        this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                        this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
                        this.loading = false;
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoResponse", error);
                            this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "reuse-ban-account.ts", "Account Page", this.apiResponseError);
                                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            } else { unexpectedError = true; }
                        } else { unexpectedError = true; }
                        if (unexpectedError) {
                            let errorResponseCustom: ErrorResponse = {
                                statusCode: serverErrorMessages.statusCode,
                                message: serverErrorMessages.serverDown
                            };
                            if (this.apiResponseError && this.apiResponseError.errorResponse) {
                                this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                                this.logger.log("error", "reuse-ban-account.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            }
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "reuse-ban-account.ts", "Account Page", lAPIErrorLists);
                        }
                    });
        }
        this.refObj.paidDepOrPD = paymentRespAttrs.invokeCall;
        if (this.refObj.paidDepOrPD === 'Pay Deposit') {
            if (paymentRespAttrs.error === 'success') {
                this.apiResponseError = null;
                this.paymentDone = true;
                this.userPaidObj.depositPaymentStatus = 'PAID';
                this.store.dispatch({ type: 'FREEZEPAGE', payload: true });
                this.refObj.isPaymentSuccess = true;
                this.refObj.displayPaidDeposit = true;
                this.refObj.paymentFailed = false;
                this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
                var currDate = new Date();
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
            } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled' || paymentRespAttrs.error === 'CANCELLED') {
                this.refObj.isPaymentSuccess = false;
                this.refObj.displayPaidDeposit = true;
                this.refObj.paymentFailed = false;
                this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
                var currDate = new Date();
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
            } else {
                this.refObj.isPaymentSuccess = false;
                this.refObj.paymentFailed = true;
                this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
                paymentRespAttrs.isDepositCallback ?
                    this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
            }
            this.prepareDepositRequest();
        } else {
            if (paymentRespAttrs.error === 'success') {
                this.apiResponseError = null;
                this.refObj.isPaymentSuccessPD = true;
                this.refObj.displayPaidPD = true;
                this.refObj.paymentFailedPD = false;
                this.userPaidObj.finalBillPaymentStatus = 'PAID';
                this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
                var currDate = new Date();
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
            } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled' || paymentRespAttrs.error === 'CANCELLED') {
                this.refObj.isPaymentSuccessPD = false;
                this.refObj.paymentFailedPD = false;
                this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
                var currDate = new Date();
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
            } else {
                this.refObj.isPaymentSuccessPD = false;
                this.refObj.paymentFailedPD = true;
                this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
                paymentRespAttrs.isDepositCallback ?
                    this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
            }
            this.preparePastDueRequest();
        }
    }

    public bmOrderProcess(requestObj, requestObject) {
        let errorResolved = false;
        this.logger.log("info", "reuse-ban-account.component.ts", "reviewOrderRequest", JSON.stringify(requestObject));
        this.logger.startTime();
        this.loading = true;
        this.reviewOrderService.postSubmitTaskService(requestObj, false)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "reviewOrderResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(error._body);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "reuse-ban-account.component.ts", "reviewOrderResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "reuse-ban-account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let response = data;
                    if (response) {
                        this.apiResponseError = null;
                        this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                        this.store.dispatch({ type: 'TASK_ID', payload: response.taskId });
                        this.store.dispatch({ type: 'FREEZEPAGE', payload: true });
                        this.store.dispatch({ type: 'FREEZEACC', payload: true });
                        this.router.navigate(['/review-order']);
                    }
                },
                (error) => {
                    if (error === undefined || error === null) {
                        return;
                    }
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "reuse-ban-account.component.ts", "reviewOrderResponse", error);
                        this.logger.log("error", "reuse-ban-account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.logger.log("error", "reuse-ban-account.component.ts", "reviewOrderError", JSON.stringify(this.apiResponseError));
                            this.systemErrorService.logAndeRouteToSystemError("error", 'reviewOrderError', "reuse-ban-account.component.ts", "Account Page", this.apiResponseError);
                        } else { unexpectedError = true; }
                    } else { unexpectedError = true; }
                    if (unexpectedError) {
                        let errorResponseCustom: ErrorResponse = {
                            statusCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDown
                        };
                        if (this.apiResponseError && this.apiResponseError.errorResponse) {
                            this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                            this.logger.log("error", "reuse-ban-account.component.ts", "reviewOrderError", JSON.stringify(this.apiResponseError));
                        }
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", 'reviewOrderError', "reuse-ban-account.account.component.ts", "Account Page", lAPIErrorLists);
                    }
                }
            );
    }

    public orderDtvProcess() {
        let request: any;
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((data) => {
            request = {
                orderRefNumber: data.dtvSessionInfo.payload.orderReferenceNumber,
                processInstanceId: data.dtvSessionInfo.processInstanceId,
                taskId: data.dtvSessionInfo.taskId,
                taskName: data.dtvSessionInfo.taskName,
                payload: {
                    uniqueSessionId: data.dtvSessionInfo.payload.sessionInfo.uniqueSessionId,
                    attOrderType: "DIRECTV"
                }
            };
        });

        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.orderDtvProcess(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVinit", "reuse-ban-account.component.ts",
                    "DIRECTV order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                this.loading = false;
                if (data && data.payload.taskName === 'Enter DTV Manually') {
                    this.opusSessionInfoNotFound.open();
                }
            }, (error) => {
                if (error === undefined || error === null || errorResolved) { return; }
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "reuse-ban-account.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    public retrieveDtvOrder(requestObj, requestObject) {
        this.loading = true;
        let request: any;
        request = {
            "uniqueSessionId": "",
            "attOrderType": "DIRECTV",
            "orderReferencNumber": requestObj.orderRefNumber
        };
        if (this.retainObservableData && this.retainObservableData.dtvSessionInfo && this.retainObservableData.dtvSessionInfo.payload && this.retainObservableData.dtvSessionInfo.payload.sessionInfo && this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId) {
            request.uniqueSessionId = this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId;
        }

        let errorResolved = false;
        this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.retrieveDtvOrder(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVRetrieveOrder", "reuse-ban-account.ts",
                    "DIRECTV Retrieve order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    this.loading = false;
                    data.errorResponse[0]['status'] = "200";
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error",
                        "",
                        "retrieveDTVOrder",
                        "reuse-ban-account.ts",
                        "Retrieve  DTV order",
                        data.errorResponse[0]
                    );
                    return Observable.throwError(null);
                } else {
                    this.logger.endTime();
                    this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                    this.orderDtvProcess();
                    this.bmOrderProcess(requestObj, requestObject);
                }

            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "reuse-ban-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }

                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "reuse-ban-account.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    /** On second time click on continue button, get order response & navigate to order page */
    public getOrderResponse() {
        this.refObj.submitted = true;
        let inValidAccPassword = Validations.accountPasswordValidator({ value: this.accRespObj.accountPassword });
        if (!inValidAccPassword) {
            this.store.dispatch({ type: 'ACCT_PASSWORD', payload: this.accRespObj.accountPassword });
        } else {
            this.accRespObj.accountPassword = null;
            this.store.dispatch({ type: 'ACCT_PASSWORD', payload: this.accRespObj.accountPassword });
        }
        if (!this.postalAddressValidated) {
            this.addressNotValidatedMsg = 'Looks like the address needs to be validated.';
            return;
        }
        if ((this.refObj.isEmailValid || (this.contactDet.emailAddrDeclined && this.refObj.billingOpt !== 'paperless'))) {
            if (!this.isDtvOpus && this.isDTV) {
                let dtvAccountNo = this.dtvForm.get('dtvAccNo').value;
                if (!dtvAccountNo && this.newDtv && this.isDTV && dtvAccountNo === '') {
                    return;
                } else {
                    if (dtvAccountNo !== '' && this.newDtv && this.isDTV) {
                        this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'yes', accNo: dtvAccountNo } } });
                        this.accountService.saveDtvAccountNo(dtvAccountNo, this.creditReviewResp.orderRefNumber).subscribe((resp) => { });
                    }
                }
            }
            this.loading = true;
            let requestObject: PaymentsRq = {};
            if (this.paymentReqObj && this.paymentReqObj !== null && this.paymentReqObj !== undefined && this.paymentReqObj.length === 0) {
                this.paymentReqObj = null;
            }
            requestObject = {
                orderRefNumber: this.creditReviewResp.orderRefNumber,
                processInstanceId: this.creditReviewResp.processInstanceId,
                taskId: this.creditReviewResp.taskId,
                taskName: this.creditReviewResp.taskName,
                payload: {
                    paymentStatus: this.paymentReqObj
                }
            };
            this.creditReviewResp.payload.creditReviewAction = this.enumActions.SHOW_SUMMARY;
            this.updateaccRespObj();
            let requestObj = {
                orderRefNumber: this.creditReviewResp.orderRefNumber,
                processInstanceId: this.creditReviewResp.processInstanceId,
                taskId: this.refObj.userData.taskId,
                taskName: this.creditReviewResp.taskName,
                payload: {
                    creditReviewAction: this.enumActions.SHOW_SUMMARY,
                    accountInfo: {
                        accountName: this.accRespObj.accountInfo.accountName,
                        accountPassword: this.accRespObj.accountPassword,
                        accountPin: this.creditReviewResp.payload.accountInfo.accountPin,
                        accountPreferences: this.accRespObj.accountInfo.accountPreferences,
                        accountSubType: this.accRespObj.accountInfo.accountSubType,
                        accountType: this.accRespObj.accountInfo.accountType,
                        ban: this.creditReviewResp.payload.accountInfo.ban,
                        billCycle: this.accRespObj.accountInfo.billCycle,
                        billingAdditionalInfo: this.accRespObj.accountInfo.billingAdditionalInfo,
                        billingAddress: this.accRespObj.accountInfo.billingAddress,
                        billingAddressType: this.accRespObj.accountInfo.billingAddressType,
                        contact: this.accRespObj.accountInfo.contact,
                        creditClass: this.creditReviewResp.payload.creditInfo.creditClass,
                        geoCode: this.accRespObj.accountInfo.geoCode,
                        isBillAddrSameAsServiceAddress: this.accRespObj.accountInfo.isBillAddrSameAsServiceAddress,
                        personalDetails: this.accRespObj.accountInfo.personalDetails
                    },
                    addlOrderAttributes: this.otcUpdated ? this.otcUpdated : this.otcData1
                }
            };
            this.bypassDeposit(requestObj);
            this.authorizedContact(requestObj, this.authUsers);
            this.accountService.getAccountData(this.accountForm.value);
            this.accInformation.payload.accountInfo = this.accRespObj.accountInfo;
            this.accInformation.payload.paymentDetails = this.creditReviewResp.payload.paymentDetails;
            this.store.dispatch({ type: 'ACCOUNT_PAGE_REENTRANT', payload: this.accInformation });
            this.store.dispatch({ type: 'CREDIT_REVIEW', payload: this.accInformation });
            if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV) {
                this.retrieveDtvOrder(requestObj, requestObject);
            } else {
                this.bmOrderProcess(requestObj, requestObject);
            }
        } else {
            this.loading = false;
            this.displayEmailMandatoryAlert();
        }

    }
    private bypassDeposit(data) {
        let dipositBypass = {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "depositBypassed",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "depositBypassedInd",
                                    "orderAttributeValue": this.bypassButtonSelected
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        let depositeBypassOptional = {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "agentEnsembleIdInfo",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "agentEnsembleId",
                                    "orderAttributeValue": "string"
                                }
                            ]
                        }
                    ]
                }
            ]
        };

        data.payload.addlOrderAttributes[1] = dipositBypass;
        data.payload.addlOrderAttributes[2] = depositeBypassOptional;

        this.store.dispatch({ type: 'BYPASS-VALUE', payload: this.bypassButtonSelected });

    }
    private authorizedContact(respData, AuthUsers) {
        if (respData && respData.payload && Array.isArray(respData.payload.addlOrderAttributes) && respData.payload.addlOrderAttributes.length > 0) {
            respData.payload.addlOrderAttributes.forEach((item: any) => {
                if (Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                    for (let i = 0; i < item.orderAttributeGroup.length; i++) {
                        if (item.orderAttributeGroup[i].orderAttributeGroupName === "authorizedContact") {
                            item.orderAttributeGroup.splice(i, 1);
                        }
                    }
                }
            });
        }
        if (Array.isArray(AuthUsers) && AuthUsers.length > 0) {
            let additionalAttr: any = [
                {
                    "orderAttributeGroup": [
                        {
                            "orderAttributeGroupName": "authorizedContact",
                            "orderAttributeGroupInfo": [
                                {
                                    "orderAttributes": [
                                        {
                                            "orderAttributeName": "action",
                                            "orderAttributeValue": "ADD"
                                        },
                                        {
                                            "orderAttributeName": "contactType",
                                            "orderAttributeValue": "AUP"
                                        },
                                        {
                                            "orderAttributeName": "firstName",
                                            "orderAttributeValue": this.authUsers[0].firstName
                                        },
                                        {
                                            "orderAttributeName": "lastName",
                                            "orderAttributeValue": this.authUsers[0].lastName
                                        },
                                        {
                                            "orderAttributeName": "contactPhone",
                                            "orderAttributeValue": this.authUsers[0].contactPhone ? this.authUsers[0].contactPhone.match(/\d/g).join('') : ""
                                        }
                                    ]
                                },
                                {
                                    "orderAttributes": [
                                        {
                                            "orderAttributeName": "action",
                                            "orderAttributeValue": "ADD"
                                        },
                                        {
                                            "orderAttributeName": "contactType",
                                            "orderAttributeValue": "AUP"
                                        },
                                        {
                                            "orderAttributeName": "firstName",
                                            "orderAttributeValue": this.authUsers[1].firstName
                                        },
                                        {
                                            "orderAttributeName": "lastName",
                                            "orderAttributeValue": this.authUsers[1].lastName
                                        },
                                        {
                                            "orderAttributeName": "contactPhone",
                                            "orderAttributeValue": this.authUsers[1].contactPhone ? this.authUsers[1].contactPhone.match(/\d/g).join('') : ""
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }

            ];

            if (respData.payload && Array.isArray(respData.payload.addlOrderAttributes) && respData.payload.addlOrderAttributes.length > 0
                && respData.payload.addlOrderAttributes[0].orderAttributeGroup) {
                respData.payload.addlOrderAttributes[0].orderAttributeGroup.push(additionalAttr[0].orderAttributeGroup[0]);
            } else {
                respData.payload.addlOrderAttributes = [];
                respData.payload.addlOrderAttributes.push(additionalAttr);
            }
            this.store.dispatch({ type: 'AUTHORIZED_PARTIES', payload: this.authUsers });
        }
    }

    private updateaccRespObj() {

        this.refObj && this.refObj.billingOption && this.refObj.billingOption.name && this.refObj.billingOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification = false;

        this.refObj && this.refObj.billingOption && this.refObj.billingOption.name && this.refObj.billingOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification = false;

        this.refObj && this.refObj.orderOption && this.refObj.orderOption.name && this.refObj.orderOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification = false;

        this.refObj && this.refObj.orderOption && this.refObj.orderOption.name && this.refObj.orderOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification = false;

        this.refObj && this.refObj.repairOption && this.refObj.repairOption.name && this.refObj.repairOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification = true :
            this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification = false;

        this.refObj && this.refObj.repairOption && this.refObj.repairOption.name && this.refObj.repairOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification = true :
            this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification = false;

        this.accRespObj.accountInfo.accountName.title = '';
        this.accRespObj.accountInfo.contact.contactNumber = this.accountForm.value.contactNumber;
        this.accRespObj.accountInfo.contact.smsNumber = this.autoLoginPhoneNumber;
        this.accRespObj.accountInfo.contact.emailAddress = this.accountForm.value.emailAddress;
        this.accRespObj.accountInfo.accountPreferences.paperlessBilling = false;
        this.accRespObj.accountInfo.accountPreferences.braille = false;
        this.accRespObj.accountInfo.accountPreferences.spanishBillPrint = false;
        this.accRespObj.accountInfo.accountPreferences.largePrint = false;
        if (this.accountForm.value.emailAddrDeclined === true) {
            this.accRespObj.accountInfo.contact.emailAddrDeclined = true;
            this.accRespObj.accountInfo.contact.emailAddress = "";
        }

        switch (this.refObj.billingOpt) {
            case 'paperless':
                this.accRespObj.accountInfo.accountPreferences.paperlessBilling = true;
                break;
            case 'braille':
                this.accRespObj.accountInfo.accountPreferences.braille = true;
                break;
            case 'spanish':
                this.accRespObj.accountInfo.accountPreferences.spanishBillPrint = true;
                break;
            case 'large':
                this.accRespObj.accountInfo.accountPreferences.largePrint = true;
                break;
            default: break;
        }
        this.accRespObj.accountInfo.accountType = 'I';
        this.accRespObj.accountInfo.accountSubType = 'R';
        let cont = this.accRespObj.accountInfo.contact.contactNumber;
        if (cont) {
            this.accRespObj.accountInfo.contact.contactNumber = cont.match(/\d/g).join('');
        }
        let sms = this.accRespObj.accountInfo.contact.smsNumber;
        if (sms) {
            this.accRespObj.accountInfo.contact.smsNumber = sms.match(/\d/g).join('');
        }
        this.accRespObj = Object.assign({},
            this.accRespObj, {
            creditClass: this.accRespObj.accountInfo.creditClass !== null ? this.accRespObj.accountInfo.creditClass : '3'
        });
        this.accRespObj.accountInfo.billingAdditionalInfo = this.refObj.addrCareOf;
        if (this.refObj.addrTypeSelected === 'International') {
            this.accRespObj.accountInfo.billingAddressType = 'F';
        } else if (this.refObj.addrTypeSelected === 'Street Address') {
            this.accRespObj.accountInfo.billingAddressType = 'S';
        } else if (this.refObj.addrTypeSelected === 'P.O. Box') {
            this.accRespObj.accountInfo.billingAddressType = 'P';
        } else if (this.refObj.addrTypeSelected === 'Rural Route') {
            this.accRespObj.accountInfo.billingAddressType = 'R';
        } else if (this.refObj.addrTypeSelected === 'Military') {
            this.accRespObj.accountInfo.billingAddressType = 'M';
        }
    }

    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }

    public refreshCreditCheck() {
        this.loading = true;
        let reqObj = {
            orderRefNumber: this.creditReviewResp.orderRefNumber,
            processInstanceId: this.creditReviewResp.processInstanceId,
            taskId: this.creditReviewResp.taskId,
            taskName: this.creditReviewResp.taskName,
            payload: {
                creditReviewAction: this.enumActions.REFRESH_DECISION,
                accountName: this.accRespObj.accountInfo.accountName,
                personalDetails: this.accRespObj.accountInfo.personalDetails,
                addlOrderAttributes: this.creditReviewResp.payload.addlOrderAttributes
            }
        };

        let errorResolved = false;
        this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoRequest", JSON.stringify(reqObj ? reqObj : ''));
        this.logger.startTime();
        this.accountService.getCreditResponse(reqObj)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoResponse", error);
                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throw(error._body);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                    this.logger.log("info", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.apiResponseError = null;
                    this.creditReviewResp = respData;
                    this.store.dispatch({ type: 'CREDIT_REVIEW', payload: respData });
                    this.creditObj = respData.payload;
                    this.initCreditInfo();
                    this.loading = false;
                    this.taskId = respData.taskId;
                    this.refObj.userData.taskId = respData.taskId;
                    this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoResponse", error);
                        this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (this.creditInfo.creditClass === '9' || this.creditInfo.creditClass > '8') {
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", 'creditInfoError', "reuse-ban-account.ts", "Account Page", this.apiResponseError);
                                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            } else { unexpectedError = true; }
                        } else { unexpectedError = true; }
                        if (unexpectedError) {
                            let errorResponseCustom: ErrorResponse = {
                                statusCode: serverErrorMessages.statusCode,
                                message: serverErrorMessages.serverDown
                            };
                            if (this.apiResponseError && this.apiResponseError.errorResponse) {
                                this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                                this.logger.log("error", "reuse-ban-account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            }
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "reuse-ban-account.ts", "Account Page", lAPIErrorLists);
                        }
                    }
                });
    }

    public cancelOrder() {
        this.router.navigate(['/home']);
    }

    public popupCenter(url, w, h) {
        var left = (screen.width / 2) - (w / 2);
        var top = (screen.height / 2) - (h / 2);
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    }

    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacy === 'CENTURYLINK') {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Atrue%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%2216%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22Y5YzQ2MWM0YjIzMTExYmRi%22%2C%22ssid%22%3A%22rI28qh_OTFKTGfGQbOQIFA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
        } else {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083512%2C%22eid%22%3A1570086812%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22AzY2QxNDAyNDE2YTdhMGI1%22%2C%22ssid%22%3A%22C-xqYDpuQr692Su1zOt-6Q%22%2C%22lewid%22%3A1570246912%2C%22skill%22%3A%22credit-service-cris%22%7D%7D';
        }
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }
    /** unsubscribe on destroy */
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.accountSubscription !== undefined) {
            this.accountSubscription.unsubscribe();
        }
        if (this.creditRevSubscription !== undefined) {
            this.creditRevSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.retainSubscription !== undefined) {
            this.retainSubscription.unsubscribe();
        }
        if (this.existingProductStoreSubscription !== undefined) {
            this.existingProductStoreSubscription.unsubscribe();
        }
        if (this.creditCheckRetain !== undefined) {
            this.creditCheckRetain.unsubscribe();
        }
        if (this.apptSubscription !== undefined) {
            this.apptSubscription.unsubscribe();
        }
        if (this.userSubscription$ !== undefined) {
            this.userSubscription$.unsubscribe();
        }
    }

}
