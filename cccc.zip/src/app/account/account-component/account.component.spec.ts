import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { MockServer } from 'app/MockServer.test';
import { Observable, of } from 'rxjs';
import { AccountComponent } from './account.component';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { MockLogger, MockTextMaskService, MockAccountService, MockAddressService, MockReviewOrderService, MockSystemErrorService, MockHelperService, MockDirectvService, MockPendingOrderService, MockDisconnectService, MockProductService, MockBlueMarbleService, MockPropertiesHelperService } from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { AccountService } from 'app/common/service/account.service';
import { AddressService } from 'app/common/service/address.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { HelperService } from 'app/common/service/helper.service';
import { DirectvService } from 'app/common/service/directv.services';
import { DomSanitizer } from '@angular/platform-browser';
import { CountryStateService } from 'app/common/service/country-state.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { RouterTestingModule } from '@angular/router/testing';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { Validations } from 'app/common/validations/validations';

describe('AccountComponent', () => {
  let component: AccountComponent;
  let fixture: ComponentFixture<AccountComponent>;
  const mockServer = new MockServer();
  const addr: any = {
		"isValidated": true,
		"streetAddress": "918 N ROYER ST",
		"streetNrFirst": "918",
		"streetNamePrefix": "E",
		"streetName": "N ROYER",
		"streetType": "ST",
		"locality": "COLORADO SPRINGS",
		"city": "COLORADO SPRINGS",
		"stateOrProvince": "CO",
		"postCode": "80903",
		"postCodeSuffix": "2385",
		"source": "Trillium",
		"subAddress": [{
			"designator": "APT",
			"value": 2
		}],
		"country": "USA"
	};


  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    TextMaskModule,
    SharedCommonModule,
    SharedModule,
    RouterTestingModule.withRoutes([])    
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }

  class MockAppStateService {
	setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('NI_HSI_POTS_TILL_ORDER_CONFIRMATION_PAGE');
    }
  }

  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const textMaskService = { provide: TextMaskService, useClass: MockTextMaskService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };

  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const propertiesHelperService = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
  

  const providers = [
    logger, store, appStateService, textMaskService, accountService, addressService, 
    reviewOrderService, systemErrorService, helperService, directvService, FormBuilder,
    DomSanitizer,  CountryStateService, CTLHelperService , pendingOrderService,
    disconnectService, productService, blueMarbleService, propertiesHelperService, Validations
  ];

  const baseConfig = {
    imports: imports,
    declarations: [ AccountComponent ],
    providers: providers
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create account component', () => {
    expect(component).toBeTruthy();
  });

  it('accountForm should have been defined', () => {
		expect(component.accountForm).toBeDefined();
  });
  
  it('currUrl should have been defined', () => {
		expect(component.currUrl).toBeDefined();
  });
  
  it('should call ngOnInit()', () => {
    const returnVal = component.ngOnInit();
		expect(returnVal).toBeUndefined();
  });
  
  it('phoneMask should have been defined', () => {
		expect(component.phoneMask).toBeDefined();
  });
  
  it('accRespObj should have been defined', () => {
		expect(component.accRespObj).toBeDefined();
  });
  
  it('creditObj should have been defined', () => {
		expect(component.creditObj).toBeDefined();
  });
  
  it('creditDepositInfo should have been defined', () => {
		expect(component.creditDepositInfo).toBeDefined();
  });
  
  it('billingAddr should have been defined', () => {
		expect(component.billingAddr).toBeDefined();
  });
  
  it('contactDet should have been defined', () => {
		expect(component.contactDet).toBeDefined();
  });
  
  it('isCreditChecked should have been defined', () => {
		expect(component.isCreditChecked).toBeDefined();
  });
  
  it('personalDet should have been defined', () => {
		expect(component.personalDet).toBeDefined();
  });
  
  it('products should have been defined', () => {
		expect(component.products).toBeDefined();
  });
  
  it('isInitializedFormObj should have been defined', () => {
		expect(component.isInitializedFormObj).toBeDefined();
  });
  
  it('accountObj should have been defined', () => {
		expect(component.accountObj).toBeDefined();
  });
  
  it('refObj should have been defined', () => {
		expect(component.refObj).toBeDefined();
  });
  
  it('payobj should have been defined', () => {
		expect(component.payobj).toBeDefined();
  });
  
  it('should Match the get PhoneNumberMask Call', () => {
		let phoneMask: any;
		phoneMask = ['(', /[2-9]/, /[0-8]/, /\d/, ')', ' ', /[2-9]/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
		expect(component.phoneMask.length).toBe(phoneMask.length);
  });
  
  it('should Check the  Name Validation True', inject([Validations], () => {
		let firstName = { value: 'Nandish' };
		expect(Validations.nameValidator(firstName)).toBe(null);
  }));
  
  it('should Check the  Name Validation false', inject([Validations], () => {
		let firstName = { value: 'Nandish_123' };
		expect(Validations.nameValidator(firstName)).not.toBe(null);
  }));
  
  it('should Check the  Zip Code Validation true', inject([Validations], () => {
		let zipCode = { value: '5124' };
		expect(Validations.zipCodeValidator(zipCode)).not.toBe(null);
  }));
  
  it('should Check the  Zip Code Validation false', inject([Validations], () => {
		let zipCode = { value: '5124154da' };
		expect(Validations.zipCodeValidator(zipCode)).not.toBe(null);
  }));
  
  it('should Match notificationValidation Call', () => {
		component.accountForm = (component as any).fb.group({
			firstName: ['Nandish', [Validators.required, <any>Validations.nameValidator]],
			lastName: ['dm', [Validations.nameValidator]],
			contactNumber: '720-301-1514' ? ['720-301-1514', [Validations.phoneValidator]] :
				['720-301-1514', [Validations.phoneValidator]],
			smsNumber: ['720-301-1514', [Validations.phoneValidator]],
			emailAddress: ['vj4235@gmail.com', [Validations.emailValidator]],
			zipCode: ['56689', Validations.zipCodeValidator]
		});
		component.contactDet = { emailAddrDeclined: true };
		component.accountForm.value.emailAddress = 'vj4235@gmail.com';
		component.notificationValidation();
		expect(component.emailPlaceHolder).toBe("Not provided");
  });
  
  it('should Match notificationValidation Call, invalid email ', () => {
		component.accountForm = (component as any).fb.group({
			firstName: ['Nandish', [Validators.required, <any>Validations.nameValidator]],
			lastName: ['dm', [Validations.nameValidator]],
			contactNumber: '720-301-1514' ? ['720-301-1514', [Validations.phoneValidator]] :
				['720-301-1514', [Validations.phoneValidator]],
			smsNumber: ['720-301-1514', [Validations.phoneValidator]],
			emailAddress: ['', [Validations.emailValidator]],
			zipCode: ['56689', Validations.zipCodeValidator]
		});
		component.contactDet = { emailAddrDeclined: true };
		component.notificationValidation();
		expect(component.emailPlaceHolder).toBe("Not provided");
  });
  
  it('should Match notificationValidation Call, invalid smsNumber ', () => {
		component.accountForm = (component as any).fb.group({
			firstName: ['Nandish', [Validators.required, <any>Validations.nameValidator]],
			lastName: ['dm', [Validations.nameValidator]],
			contactNumber: '720-301-1514' ? ['720-301-1514', [Validations.phoneValidator]] :
				['720-301-1514', [Validations.phoneValidator]],
			smsNumber: ['', [Validations.phoneValidator]],
			emailAddress: ['vj4235@gmail.com', [Validations.emailValidator]],
			zipCode: ['56689', Validations.zipCodeValidator]
		});
		component.contactDet = { emailAddrDeclined: true };
		component.notificationValidation();
		expect(component.emailPlaceHolder).toBe("Not provided");
  });
  
  it('should Match the addressRadioHandler Call', () => {
		component.addressRadioHandler();
		expect(component.refObj.disableSaveAddr).toBe(false);
  });
  
  it('should Match the setDefaultVal Call', () => {
		component.accountForm = (component as any).fb.group({
			smsNumber: ['720-301-1514', [Validations.phoneValidator]],
			emailAddress: ['vj4235@gmail.com', [Validations.emailValidator]]
		});
		component.contactDet = { emailAddrDeclined: true };
		const returnVal = component.setDefaultVal('bill');
		expect(returnVal).toBeUndefined();
  });
  
  it('should Match the setDefaultVal Call', () => {
		component.accountForm = (component as any).fb.group({
			smsNumber: ['720-301-1514', [Validations.phoneValidator]],
			emailAddress: ['vj4235@gmail.com', [Validations.emailValidator]]
		});
		component.contactDet = { emailAddrDeclined: true };
		const returnVal = component.setDefaultVal('order');
		expect(returnVal).toBeUndefined();
  });
  
  it('cancelClick should have been called', () => {
		const returnVal = component.cancelOrder();
		expect(returnVal).toBeUndefined();
  });
  
  it('should Match the setDefaultVal Call', () => {
		component.accountForm = (component as any).fb.group({
			smsNumber: ['720-301-1514', [Validations.phoneValidator]],
			emailAddress: ['vj4235@gmail.com', [Validations.emailValidator]]
		});
		component.contactDet = { emailAddrDeclined: true };
		const returnVal = component.setDefaultVal('repair');
		expect(returnVal).toBeUndefined();
  });
  
  it('should Match the getAge Call', () => {
		component.refObj.month = '10';
		component.refObj.day = '10';
		component.refObj.year = '1980';
		component.getAge()
		expect(component.refObj.underAge).toBe(false);
  });
  
  xit('should check invalid DOB for the getAge Call', () => {
		component.refObj.month = '10';
		component.refObj.day = '10';
		component.refObj.year = '2120';
		component.getAge();
		expect(component.refObj.isValidDob).toBe(false);
  });

  it("should Match the getAge Call underage", () => {
	component.refObj.month = "10";
	component.refObj.day = "10";
	component.refObj.year = "2005";
	component.getAge();
	expect(component.refObj.underAge).toBe(true);
  });
  
  it("should call setFirstLastName", () => {
	const returnVal = component.setFirstLastName();
	expect(returnVal).toBeUndefined();
  });
  
  it("should call setApproval", () => {
	const returnVal = component.setApproval({});
	expect(returnVal).toBeUndefined();
  });

  it("should call handleBackToExistingProducts", () => {
	const returnVal = component.handleBackToExistingProducts({});
	expect(returnVal).toBeUndefined();
  });

  it("should call selectBypassButton", () => {
	const returnVal = component.selectBypassButton({ target: {} });
	expect(returnVal).toBeUndefined();
  });

  it("should call updateApplClickHandler", () => {
	const returnVal = component.updateApplClickHandler();
	expect(returnVal).toBeUndefined();
  });

  it("should call removeLater", () => {
	const returnVal = component.removeLater();
	expect(returnVal).toBeUndefined();
  });

  it("should call preparePrepaidPayRequest", () => {
	const returnVal = component.preparePrepaidPayRequest();
	expect(returnVal).toBeUndefined();
  });

  it("should call preparePastDueRequest", () => {
	const returnVal = component.preparePastDueRequest();
	expect(returnVal).toBeUndefined();
  });

  it("should call prepareDepositRequest", () => {
	const returnVal = component.prepareDepositRequest();
	expect(returnVal).toBeUndefined();
  });

  it("should call calculateTotalDepositForChange", () => {
	const returnVal = component.calculateTotalDepositForChange();
	expect(returnVal).toBeUndefined();

  });

  it("should call prepareInstDepositReq", () => {
	const returnVal = (component as any).prepareInstDepositReq(undefined);
	expect(returnVal).toBeUndefined();
  });
  
  it("ngOnDestroy should have been called", () => {
	const returnVal =component.ngOnDestroy();
	expect(returnVal).toBeUndefined();
  });
  
  it("User subscription check on saveChangedAddr", () => {
	component.saveChangedAddr();
	expect(component.refObj.disableSaveAdd).toBe(undefined);
  });
  
  it("check on getStates()", () => {
	let result: any = { stateName: "Select State", stateCode: "" };
	let state = (component as any).countryStateService.getStates();
	state.splice(0, 0, result);
	component.getStates();
	expect(component.refObj.stateCountries).toEqual(state);
  });
  
  it("check on getMilitaryState()", () => {
	let result: any = {
	  militaryStateName: "Select Armed Forces Location",
	  militaryStateCode: "",
	};
	let military = (component as any).countryStateService.getMilitaryStates();
	military.splice(0, 0, result);
	component.getMilitaryState();
	expect(component.refObj.stateCountries).toEqual(military);
  });
  
  it("check on stateCountrySelectionHandler() with Street Address", () => {
	component.billingAddr = addr;
	component.refObj.addrTypeSelected = "Street Address";
	component.stateCountrySelectionHandler();
  });
  
  it("check on stateCountrySelectionHandler() with P.O. Box", () => {
	component.billingAddr = addr;
	component.refObj.addrTypeSelected = "P.O. Box";
	component.stateCountrySelectionHandler();
  });
  
  it("check on stateCountrySelectionHandler() with Rural Route", () => {
	component.billingAddr = addr;
	component.refObj.addrTypeSelected = "Rural Route";
	component.stateCountrySelectionHandler();
	expect(component.billingAddr.stateOrProvince).toBe(
	  component.refObj.selectedState.stateCode
	);
  });
  
  it("check on stateCountrySelectionHandler() with Rural Route", () => {
	component.billingAddr = addr;
	component.refObj.addrTypeSelected = "Rural Route";
	component.stateCountrySelectionHandler();
	expect(component.billingAddr.stateOrProvince).toBe(
	  component.refObj.selectedState.stateCode
	);
  });
  
  it("check on stateCountrySelectionHandler() with Military", () => {
	component.billingAddr = addr;
	component.refObj.addrTypeSelected = "Military";
	component.stateCountrySelectionHandler();
	expect(component.billingAddr.armedForceLoc).toBe(
	  component.refObj.selectedState.militaryStateCode
	);
  });
  
  it("check on stateCountrySelectionHandler() with International", () => {
	component.billingAddr = addr;
	component.refObj.addrTypeSelected = "International";
	component.stateCountrySelectionHandler();
	expect(component.billingAddr.country).toBe(
	  component.refObj.selectedState.countryCode
	);
  });
  
  xit(" call validateBillingAddr() error", () => {
	component.billingAddr = addr;
	let data = { _body: { error: { errorMessage: "Unexpected error occured" } } };
	component.accountForm = (component as any).fb.group({
	  firstName: [
		"Nandish",
		[Validators.required, <any>Validations.nameValidator],
	  ],
	  lastName: ["dm", [Validations.nameValidator]],
	  contactNumber: "720-301-1514"
		? ["720-301-1514", [Validations.phoneValidator]]
		: ["720-301-1514", [Validations.phoneValidator]],
	  smsNumber: ["720-301-1514", [Validations.phoneValidator]],
	  emailAddress: ["vj4235@gmail.com", [Validations.emailValidator]],
	  zipCode: ["98004", Validations.zipCodeValidator],
	});
	component.refObj.addrTypeSelected = "Street Address";
	let req = {
	  taskName: "initAddressGreen",
	};
	component.validateBillingAddr();
	// expect(component.errorMsg).toBe(data._body.error.errorMessage);
  });
  
});
