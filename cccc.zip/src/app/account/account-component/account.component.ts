import { Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import * as moment from 'moment-timezone';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { DirectvService } from 'app/common/service/directv.services';
import { SystemErrorService } from "app/common/service/system-error.service";
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../../common/logging/default-log.service';
import { AccountContactDetails, AccountInfo, AccountInfomation, AccountPreferences, PersonalDetails, LoginDetails } from '../../common/models/account.model';
import { AppStore } from '../../common/models/appstore.model';
import { EnterpriseAddress } from '../../common/models/cart.model';
import { APIErrorLists, ErrorResponse, GenericValues, serverErrorMessages } from '../../common/models/common.model';
import { CreditCheck, CreditCheckPayload, CreditInfo, DepositInfo, PaymentInfo, PaymentsRq } from '../../common/models/credit-check.model';
import { Order } from '../../common/models/order.model';
import { User } from '../../common/models/user.model';
import { AuthUsersList } from '../../common/models/account.model';
import { AccountService } from '../../common/service/account.service';
import { AddressService } from '../../common/service/address.service';
import { AppStateService } from '../../common/service/app-state.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import { Validations } from '../../common/validations/validations';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import 'rxjs/add/operator/debounceTime';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";
import { AppConstant } from '../../app.constant';

@Component({
    selector: 'account',
    templateUrl: './account.component.html',
    styleUrls: ['./account.component.scss']
})

export class AccountComponent implements OnInit, OnDestroy, AfterViewInit {
    public refreshDecisionSelected: boolean = false;
    public bypassButtonSelected: boolean = false;
    public bypassCreditCheck: boolean = false;
    public bypassCreditCheckSelected: boolean = false;
    public updateAppilicationSelected: boolean = false;
    public accountInfoAfterDoneCredit: any;
    public reentrantCreditCheckdone: boolean;
    public creditCheckDone: boolean = false;
    public reviewOrdeAddAttrrResponse: any;
    public dtvRefoundAmt: any;
    public dhpRefoundAmt: any;
    public dtvPaymentDone: boolean = false;
    public dhpPaymentDone: boolean = false;
    public allProductsPaid: boolean = true;
    public paymentPending: boolean = false;
    public potsPaymentDone: boolean = false;
    public hsiPaymentDone: boolean = false;
    public depositInfo: any;
    public potsRefoundAmt: any;
    public reentrantDepositPayStatus: any;
    public hsiRefundAmt: any;
    public potsPaymentData: boolean = false;
    public retrieveDtvData: any;
    public addlOrderAttributesDepositData: any;
    public isPaymentDone: boolean = false;
    public userSubscription$: Subscription;
    public userdata: Observable<User>;
    public accountdata: Observable<AccountInfomation>;
    public previousURL: string;
    public retainSSN: any;
    public creditRevObsv2: Observable<any>;
    public creditDataObj: CreditCheck;
    public creditCheckRetain: Subscription;
    public user: Observable<User>;
    public retryButtonEnabled: boolean = false;
    public userSubscription: Subscription;
    public accountObservable: Observable<any>;
    public accountSubscription;
    public creditRevObsv: Observable<CreditCheck>;
    public creditRevSubscription: Subscription;
    public orderObservable: Observable<Order>;
    public orderSubscription: Subscription;
    public currUrl: string;
    public accountForm: FormGroup;
    public accRespObj: AccountInfo;                   // Account info Parent Object
    public showDriverLicense: boolean = false;
    public phoneMask: any;
    public ssnMask: any;
    public otcData1: any[];
    public otcDataResponse: any[];
    public otcData: any[];
    public otcUpdated: any[];
    public internationalFormattingUrl: string = `${env.INTERNATIONAL_FORMATTING_URL}`;
    public creditObj: CreditCheckPayload;                    // Credit check Parent Object
    public creditDepositInfo: DepositInfo;            // Credit check deposit info
    public billingAddr: EnterpriseAddress;            // Reference billing address
    public serviceAddress: EnterpriseAddress;
    public isAuthorizedParties: AuthUsersList;
    public authUsers: any = [];
    public authorizedParties: boolean = false;
    public oneAuthorzedParty: boolean = false;
    public contactDet: AccountContactDetails;         // Contact Details
    public isCreditChecked: boolean = false;
    public personalDet: PersonalDetails;              // Account Personal details Object
    public loginDetails: LoginDetails;
    public products: any = [];
    public isInitializedFormObj: boolean = false;     // Flag to display initial page
    public accountObj: any = {};                      // Reference obj
    public payobj: any = {};
    public accInformation: AccountInfomation;
    public creditResponse: CreditCheck;
    public paymentReqObj: PaymentInfo[] = [];
    public errorMsg: string;
    public creditInfo: CreditInfo;
    public accountRentrantValues: AccountInfomation;
    public accountRentrantValue: any = false;
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public retainObservableData: any;
    public paidSecurityDeposit: boolean = false;
    public ban: string;
    public uName: any = '';
    public refObj: any =
        {
            billingOptions: [{ name: 'Email and SMS', disable: false },
            { name: 'Email only', disable: false },
            { name: 'SMS only', disable: false },
            { name: 'Do not notify', disable: false }],
            billingChk: true,
            orderChk: true,
            repairChk: true,
            changeAddrClicked: false,
            month: '',
            day: '',
            year: '',
            underAge: false,
            isEmailValid: true,
            isValidAccPassword: true,
            submitted: false,
            dobEntered: false,
            enteredSsn: true,
            addressTypes: ['Street Address', 'P.O. Box', 'Rural Route', 'Military', 'International'],
            stateCountries: [],
            dlStateCountries: [] = this.countryStateService.getStates(),
            addrCareOf: '',
            selectedState: {},
            nearAddresses: [],
            isExactAddr: '',
            selectedAddr: {},
            isEnteredAllAddsFields: true,
            disableSaveAddr: true,
            disableValidateAddr: false,
            totalDepositAmount: 0,
            gotCreditResponse: false,
            userData: {},
            isValidDob: true,
            dobMessage: '',
            addrPlaceholders: {},
            addrModels: {},
            addrTypeSelected: '',
            billingOpt: 'none',
            savedAddress: {},
            selectedOpt: 'none',
            disableDepositBtn: false,
            displayPaidDeposit: false,
            isPaymentSuccess: false,
            depositPaidDate: '',
            sessionId: '',
            pastDueAccs: [],
            displayPaidPastDue: false,
            disablePastDueBtn: false,
            paymentFailed: false,
            displayPaidPD: false,
            paymentFailedPD: false,
            paymentStatusPD: false,
            isPaymentSuccessPD: false,
            updateAppClicked: false,
            depositInstallmentObj: null,
            clickedAddress: {},
            billingType: '',
            disablePrepaidbtn: false,
            prepaidPaymentStatus: false,
            isPrepaidPaymentSuccess: false,
            displayPaidPrepaid: false,
            paymentFailedPrepaid: false
        };
    public visible: boolean = false;
    public postalAddressValidated: boolean = true;
    public visibleDeposit: boolean;
    public visibleBalance: boolean;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public geoesAddressValidationError: string;
    public isDTV = false;
    public newDtv = false;
    public existingProductStore$: Observable<any>;
    public existingProductStoreSubscription: Subscription;
    public currentFlow = 'normal';
    public dtvForm: FormGroup;
    @ViewChild('ssnfield', { static: false }) public ssnfield: ElementRef;
    public paymentDone: boolean = false;
    public paymentUrl: string = `${env.DEPOSIT_AND_FINAL_BILL_URL}`;
    public orderRefNumber: string;
    public reservedAppointment: any;
    public apptObservable: Observable<any>;
    public apptSubscription: Subscription;
    public isDtvSessionInfo: boolean = false;
    public isDtvOpus: any;
    @ViewChild('validateCreditModal', { static: false, }) public validateCreditModal: DialogComponent;
    @ViewChild('opusSessionInfoNotFound', { static: false, }) public opusSessionInfoNotFound: DialogComponent;
    public showHidePaymentProducts: boolean = false;
    public securitydiposit: any;
    public security: any;
    public profile: string;
    public bypassDepositUser: boolean = false;
    public sfcData: any;
    public emailAddrDeclinedManually: boolean = false;
    public accountFormOriginalValues: any;
    public accountFormCurrentValues: any;
    public accountFormValuesChanged: boolean = false;
    public isPrepaid: boolean = false;
    public QConnectResp: any;
    public QConnectErrTxt: boolean = false;
    public isUnameValid: boolean = false;
    public QcErrMsg: any;
    public isQcDown: boolean = false;
    public pastDueAmountExist: boolean = false;
    public finalBillforPostPaid: any;
    public prepaidAcctNumber: any;
    public firstMonthMRC: any = [];
    public firstMonthOTC: any = [];
    public firstMonthMRCTotal: number = 0;
    public firstMonthOTCTotal: number = 0;
    public prepaidFirstMonth: any;
    public invokeCallPrepaid: string;
    public existingProductData: any;
    public totalPastDueAmount: number = 0;
    public pastDueAmountBTNs: any[] = [];
    public totalCharges: any;
    public isUnameChanged: boolean = false;
    public validMail: any;
    public validUname: any;
    public prevUnameVal: any;
    public changedUnameVal: boolean = false;
    public currentUnameVal: any;
    public loadingonetime: boolean = false;
    public mrcTaxes: number = 0;
    public otcTaxes: number = 0;
    public addrTypeDpdwnError: string = '';
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    private creditReviewResp: any;
    public autoLoginEmailAddress: any = '';
    public autoLoginPhoneNumber: any = '';
    public phoneNumber: any = '';
    public redAddressFlag: boolean = false;
    public maxCreditCheckReached: boolean = false;
    private isOnHoldFlow: boolean = false;
    private onHoldCreditReviewOrderRefNo: string;
    private onHoldProcessInstanceId: string;
    public removedDTV: boolean = false;
    private accountPasswordPin: boolean;
    private sfcPaperlessFlag: boolean = false;
    public changeRes: string = "";
    public reEntrant: boolean = false;
    private initialServiceAddress: EnterpriseAddress;
    private taskId: string = '';
    public hideItems: boolean = false;
    private dtvAccountInfoManuallyEntered: any = false;
    private accountPassword: any;
    private userPaidObj = null;
    public addressNotValidatedMsg: string;
    private isServiceAddressInitialized: boolean = false;
    public legacy: string;
    private enumActions = {
        UPDATE_APPLN: 'UPDATEAPPLN',
        REFRESH_DECISION: 'REFRESHDECISION',
        SHOW_SUMMARY: 'SHOWSUMMARY',
        PAY_DEPOSIT: 'PAYDEPOSIT',
        PAY_FBILL: 'PAYFBILL',
        PAY_INITIAL_BILL: 'PAYINITIALBILL'
    };
    public isPaymentsError: boolean = false;
    public creditCheckStatusFromAccountInfo: boolean = false;
    public currDate : Date = new Date();
    public onholdRestrictedMsg = AppConstant.CANNOT_HOLD_PREPAID_AFTER_PAYMENT;
    public effectiveBilldate:any;
    public effectiveBilldateNumber:any;

    constructor(
        private logger: Logger,
        private router: Router,
        private fb: FormBuilder,
        public store: Store<AppStore>,
        private sanitizer: DomSanitizer,
        private appStateService: AppStateService,
        private textMask: TextMaskService,
        private accountService: AccountService,
        private addressService: AddressService,
        private countryStateService: CountryStateService,
        private reviewOrderService: ReviewOrderService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
        private directvService: DirectvService
       ) {

        this.user = this.store.select('user');
        this.phoneMask = this.textMask.getPhoneNumberMaskFormat();
        this.ssnMask = this.textMask.getSsnMask();
        this.appStateService.setLocationURLs();
        this.userSubscription = this.user.subscribe((data) => {
            this.isPrepaid = data.prepaidFlag === 'PREPAID' ? true : false;
            this.sfcData = data;
            this.isDtvOpus = data.isDtvOpus;
            this.currUrl = data.currentUrl;
            this.refObj.userData = cloneDeep(data);
            this.previousURL = data.previousUrl;
            if (data.previousUrl !== '/schedule-appt' && data.previousUrl !== '/schedule-appt-ship' && data.previousUrl === '/review-order') {
                this.reEntrant = true;
                this.taskId = data.taskId;
                this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: this.reEntrant });
            }
            if (Array.isArray(data.currentSelected)) {
                data.currentSelected.forEach((val: any) => {
                    if (val.selected === GenericValues.cDTV) {
                        this.isDTV = true;
                    }
                });
                if (this.isDtvOpus) {
                    if (data.dtvOpus) {
                        if (data.dtvOpus.taskName === 'yes') {
                            this.newDtv = true;
                        }
                    }
                } else {
                    if (data.dtvQuestionForm) {
                        if (data.dtvQuestionForm.taskName === 'yes') {
                            this.newDtv = true;
                        }
                    }
                }
            }

            if (data.autoLogin !== null && data.autoLogin.sfcData !== undefined && data.autoLogin.sfcData !== null && !this.reEntrant) {
                if (data.autoLogin.sfcData.emailID !== null && data.autoLogin.sfcData.emailID !== undefined && data.autoLogin.sfcData.emailID.length > 0) {
                    if (!this.accountFormValuesChanged) {
                        this.autoLoginEmailAddress = data.autoLogin.sfcData.emailID;
                        this.notificationValidation();
                    }
                    if (!this.sfcPaperlessFlag) {
                        this.refObj.billingOpt = 'paperless';
                        this.refObj.selectedOpt = 'paperless';
                        this.sfcPaperlessFlag = true;
                    }
                }
                if (!this.accountFormValuesChanged) {
                    if (!data.autoLogin.sfcData.isPrimaryPhoneSms) {
                        this.autoLoginPhoneNumber = '';
                    } else if (data.autoLogin.sfcData.contactNumber !== null && data.autoLogin.sfcData.contactNumber.length > 0 && !this.reEntrant) {
                        this.autoLoginPhoneNumber = data.autoLogin.sfcData.contactNumber;
                    }
                }
            }

            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
            if (data.profile && Array.isArray(data.profile.securityElements)) {
                data.profile.securityElements.forEach((securityElement: any) => {
                    if (securityElement['securityElementName'] === 'BYPASS_CREDIT_CHECK' && securityElement['securityElementFlag'] === "true") {
                        this.bypassCreditCheck = true;
                    }
                });
            }
            if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
                this.legacy = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
            }
        });


        this.existingProductStore$ = this.store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            this.existingProductData = respData;
            if (respData && respData.orderFlow && respData.orderFlow.flow) {
                this.currentFlow = respData.orderFlow.flow;
            }
            if (respData && respData.orderFlow && respData.orderFlow.type === 'fromHold') {
                this.isOnHoldFlow = true;
            }
        });


        this.creditRevObsv2 = this.store.select('creditReview');
        this.creditCheckRetain = this.creditRevObsv2.subscribe((creditData) => {
            if (creditData !== undefined && creditData !== null && creditData.credit_detail !== undefined && creditData.credit_detail !== null) {
                this.refObj.month = creditData.credit_detail.month;
                this.refObj.day = creditData.credit_detail.day;
                this.refObj.year = creditData.credit_detail.year;
                this.retainSSN = creditData.ssn_detail;
                this.refObj.submitted = false;
                this.refObj.dobEntered = true;
                this.refObj.enteredSsn = true;
            }
            if (creditData.payload && creditData.payload.bypassCreditCheckSelected === true) {
                this.bypassCreditCheckSelected = true;
            }
            this.checkForRefundAmount(creditData);
        });


        if (this.reEntrant) {
            this.accountObservable = this.store.select('account');
            this.postalAddressValidated = true;
            this.accountSubscription = this.accountObservable.subscribe((respData) => {
                this.accInformation = respData;
                if (respData.isAuthorizedParties !== undefined && respData.isAuthorizedParties !== null) {
                    this.authUsers = respData.isAuthorizedParties;
                    this.authorizedParties = false;
                    this.oneAuthorzedParty = false;
                    if (this.authUsers[0].firstName !== "" || this.authUsers[1].firstName !== "") {
                        this.authorizedParties = true;
                    }
                    if (this.authUsers[0].firstName === "" || this.authUsers[1].firstName === "") {
                        this.oneAuthorzedParty = true;
                    }
                }
                this.refObj.addrTypeSelected = this.accInformation.addressType;
                if (respData && respData.accountPassword) {
                    this.accountPassword = respData.accountPassword;
                }
                this.autoLoginEmailAddress = this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress;
                if (this.autoLoginEmailAddress && this.autoLoginEmailAddress !== undefined) {
                    this.accInformation.contact.emailAddrDeclined = false;
                }

                if (this.accInformation && this.accInformation.contact) {
                    this.autoLoginPhoneNumber = this.accInformation.contact.smsNumber;
                    this.phoneNumber = this.accInformation.contact.contactNumber;
                }
                this.initializeData();
            });
            //this.accountSubscription.unsubscribe();
            this.refObj.gotCreditResponse = false;
            this.orderObservable = this.store.select('order');
            this.orderSubscription = this.orderObservable.subscribe((orderData) => {
                if (orderData && orderData.payload && orderData.payload.accountInfo) {
                    this.accInformation =
                    {
                        orderRefNumber: orderData.orderRefNumber,
                        processInstanceId: orderData.processInstanceId,
                        taskId: this.refObj.userData.taskId,
                        taskName: 'Credit Review',
                        payload: orderData.payload.accountInfo
                    };
                }
            });

            this.creditRevObsv = this.store.select('creditReview');
            this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                this.addlOrderAttributesDepositData = creditData.payload.addlOrderAttributes;
                if (this.isPrepaid && this.reEntrant) {
                    this.prepaidReEntrant(creditData);
                }
                this.isCreditChecked = true;
                this.accountRentrantValue = false;
                let hsiPayment;
                let potsPayment;
                if (creditData.payload && creditData.payload.accountInfo && creditData.payload.accountInfo.ban) {
                    this.ban = creditData.payload.accountInfo.ban;
                }
                if (this.addlOrderAttributesDepositData && this.addlOrderAttributesDepositData !== undefined && this.addlOrderAttributesDepositData[0] && this.addlOrderAttributesDepositData[0].orderAttributeGroup) {
                    this.addlOrderAttributesDepositData[0].orderAttributeGroup.map((depositData) => {
                        if (depositData && depositData.orderAttributeGroupName === "depositData") {
                            depositData.orderAttributeGroupInfo.map((paymentData) => {
                                if (paymentData && paymentData.orderAttributes[0].orderAttributeValue === "INTERNET") {
                                    if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                        this.hsiPaymentDone = true;
                                        this.paidSecurityDeposit = true;
                                        hsiPayment = true;
                                    } else {
                                        this.allProductsPaid = false;
                                        this.hsiPaymentDone = false;
                                        this.refObj.disableDepositBtn = false;
                                        hsiPayment = false;
                                    }
                                    if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                        this.hsiRefundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                    }
                                }
                                if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-HP") {
                                    if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                        this.potsPaymentDone = true;
                                        this.paidSecurityDeposit = true;
                                        potsPayment = true;
                                    } else {
                                        this.allProductsPaid = false;
                                        this.potsPaymentDone = false;
                                        this.refObj.disableDepositBtn = false;
                                        potsPayment = false;
                                    }
                                    if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                        this.potsRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                    }
                                }
                                if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-DHP") {
                                    if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                        this.dhpPaymentDone = true;
                                        this.paidSecurityDeposit = true;
                                        potsPayment = true;
                                    } else {
                                        this.allProductsPaid = false;
                                        this.dhpPaymentDone = false;
                                        this.refObj.disableDepositBtn = false;
                                    }
                                    if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                        this.dhpRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                    }
                                }
                            });
                        }
                    });
                }
                this.isCreditChecked = true;
                this.refObj.updateAppClicked = false;
                this.creditReviewResp = creditData;
                this.creditObj = creditData.payload;
                this.isPrepaid ? this.initCreditPrepaidInfo() : this.initCreditInfo();
                this.refObj.gotCreditResponse = true;
                if (!this.dhpPaymentDone && this.hsiPaymentDone && !this.allProductsPaid) {
                    this.refObj.disableDepositBtn = false;
                }
            });
            this.creditRevSubscription.unsubscribe();

        } else {
            this.accountObservable = this.store.select('account');
            this.accountSubscription = this.accountObservable.subscribe((respData) => {
                if (respData.isAuthorizedParties !== undefined && respData.isAuthorizedParties !== null) {
                    this.authUsers = respData.isAuthorizedParties;
                    this.authorizedParties = false;
                    this.oneAuthorzedParty = false;
                    if (this.authUsers[0].firstName !== "" || this.authUsers[1].firstName !== "") {
                        this.authorizedParties = true;
                    }
                    if (this.authUsers[0].firstName === "" || this.authUsers[1].firstName === "") {
                        this.oneAuthorzedParty = true;
                    }
                }
                this.accInformation = respData;
                if (this.autoLoginEmailAddress === null || this.autoLoginEmailAddress === undefined || this.autoLoginEmailAddress === "") {
                    this.autoLoginEmailAddress = this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress;
                }
                this.existingObservable = this.store.select('existingProducts');
                this.existingSubscription = this.existingObservable.subscribe(
                    (exist) => {
                        if (exist && exist.orderFlow && exist.orderFlow.type === 'fromHold' && exist.existingProductsAndServices && exist.existingProductsAndServices[0]
                            && exist.existingProductsAndServices[0].accountInfo) {
                            this.accInformation.payload = Object.assign({}, exist.existingProductsAndServices[0].accountInfo);
                            if (exist.pendingOrders && exist.pendingOrders[0] && exist.pendingOrders[0].orderDocument && exist.pendingOrders[0].orderDocument.addlOrderAttributes) {
                                this.addlOrderAttributesDepositData = exist.pendingOrders[0].orderDocument.addlOrderAttributes;
                            }
                            //Changes done as part of DE83185 fix as suggested by BM
                            if (Array.isArray(respData) && respData.length === 0) {
                                this.creditRevObsv = this.store.select('creditReview');
                                this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                                    if (creditData) {
                                        this.isCreditChecked = true;
                                        this.accInformation.payload.billingAddress = creditData.payload.accountInfo.billingAddress;
                                    }
                                });
                                this.creditRevSubscription.unsubscribe();
                            }

                            this.store.dispatch({ type: 'ON_HOLD_FLOW_ACCOUNT_INFORMATION_PAYLOAD', payload: this.accInformation.payload });
                            this.initializeData();
                        } else {
                            this.initializeData();
                        }
                    });
            });

        }
        this.apptObservable = this.store.select('appointment');
        this.apptSubscription = this.apptObservable.subscribe((data) => {
            if (data.reservedAppointment) {
                this.reservedAppointment = data.reservedAppointment;
            } else if (data.payload && data.payload.dueDate && data.payload.dueDate.finalDueDate) {
                this.reservedAppointment = data.payload.dueDate.finalDueDate;
            }
        });

        this.retainObservable = this.store.select("retain");
        this.retainSubscription = this.retainObservable.subscribe((response) => {
            this.retainObservableData = response;
            if (response.removedDTV) {
                this.removedDTV = response.removedDTV;
            }
            this.changeRes = response.cResponsibility ? response.cResponsibility : "";
            this.bypassButtonSelected = response.bypassvalue ? response.bypassvalue : false;

        });

        this.store.dispatch({ type: 'UPDATE_USER', payload: this.sfcData });

        this.accountForm.valueChanges.subscribe((changedValue) => {

            if (!this.accountForm.dirty) {
                this.accountFormOriginalValues = JSON.stringify(this.accountForm.value);
            }
            if (this.accountForm.dirty) {
                this.accountFormCurrentValues = JSON.stringify(this.accountForm.value);
            }
            if (this.accountFormOriginalValues !== this.accountFormCurrentValues) {
                this.accountFormValuesChanged = true;
            }

        });
    }

    private prepaidReEntrant(creditData: CreditCheck) {
        this.creditObj = creditData.payload;
        if (this.creditObj && this.creditObj.creditInfo) { this.creditInfo = this.creditObj.creditInfo; }
        if (this.creditObj && this.creditObj.currentBillQuote) {
            this.calculateChargesForPrepaid();
            this.isCreditChecked = true;
        }
        if (this.creditObj && this.creditObj.pastDueAmount && this.creditObj.pastDueAmount.finalBillInfo && this.creditObj.pastDueAmount.finalBillInfo.length > 0) {
            this.creditObj.pastDueAmount.finalBillInfo[0]
                && this.creditObj.pastDueAmount.finalBillInfo[0].paymentRequiredInd ? this.pastDueAmountExist = true : this.pastDueAmountExist = false;
            this.refObj.totalDepositAmount = this.creditObj.pastDueAmount.finalBillInfo[0].finalBillAmt.amount;
            this.finalBillforPostPaid = this.creditObj.pastDueAmount.finalBillInfo[0];
        }
    }

    public checkForRefundAmount(creditData: CreditCheck) {
        this.creditObj = creditData.payload;
        if (this.creditObj && ((this.isPrepaid && this.creditObj.depositInfo && this.creditObj.depositInfo.depositRequired && this.creditObj.paymentDetails.depositPaymentStatus === 'PAID')
            || (!this.isPrepaid && this.creditObj.currentBillQuote && this.creditObj.paymentDetails.finalBillPaymentStatus === 'PAID'))) {
            const refundFlag: any = {};
            refundFlag.showBanner = true;
            !this.isPrepaid ? refundFlag.amount = this.creditObj.currentBillQuote.firstMonthList.totalCharges : refundFlag.amount = this.refundPostpaidAmount();
            this.store.dispatch({ type: 'SHOW_REFUND_FLAG', payload: refundFlag });
        }
    }

    public refundPostpaidAmount() {
        let amount: number = 0;
        this.creditObj && this.creditObj.depositInfo && this.creditObj.depositInfo.products && this.creditObj.depositInfo.products.map((prod) => {
            amount += prod.depositAmount.amount;
        });
        return amount;
    }

    public opusSessionInfoNotFoundCallback(data) {
        this.dtvAccountInfoManuallyEntered = data;
        this.getOrderResponse();
    }

    public numericOnly(event: any) {
        const patt = /^([0-9])$/;
        const result = patt.test(event.key);
        return result;
    }

    public ngOnInit() {
        this.logger.metrics('AccountPage');
        this.bypassDepositUser = this.helperService.isAuthorized(ProfileEnums.BYPASS_SECURITY_DEPOSIT);
        this.userdata = this.store.select('user');
        this.userSubscription$ = this.userdata.subscribe(
            (userdata) => {
                if (!this.reEntrant) {
                    if (!this.accountFormValuesChanged && userdata && userdata.autoLogin && userdata.autoLogin.sfcData && userdata.autoLogin.sfcData.emailID === '') {
                        //this.contactDet.emailAddrDeclined = true;
                        this.accountForm.controls['emailAddress'].setValue('');
                        this.autoLoginEmailAddress = "";
                        this.emailPlaceHolder = 'Not provided';
                    } else {
                        if (!this.emailAddrDeclinedManually && userdata && userdata.autoLogin && userdata.autoLogin.sfcData && userdata.autoLogin.sfcData !== null && userdata.autoLogin.sfcData !== undefined && userdata.autoLogin.sfcData.emailID && userdata.autoLogin.sfcData.emailID !== undefined && userdata.autoLogin.sfcData.emailID !== null) {
                            this.contactDet.emailAddrDeclined = false;
                            if (userdata && userdata.emailAddress) {
                                this.autoLoginEmailAddress = userdata.emailAddress;
                            } else {
                                this.autoLoginEmailAddress = (this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress) ? this.accInformation.contact.emailAddress : userdata.autoLogin.sfcData.emailID;
                            }
                        }
                    }
                }
                this.isPrepaid = userdata.prepaidFlag === 'PREPAID' ? true : false;
            });

        this.store.dispatch({ type: 'TASK_NAME', payload: "Account Information" });
        window.scroll(0, 0);
        this.dtvForm = this.fb.group({
            'dtvAccNo': ['']
        });
        this.accountForm.get('emailAddress').valueChanges.debounceTime(750).subscribe((values) => {
            const isValidMail = Validations.emailValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress });
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
        });
        this.retainObservable = this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((respData) => {
            if (respData.dtvAccountInfo) {
                this.dtvAccountInfoManuallyEntered = respData.dtvAccountInfo;
            }
            if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
                this.accountRentrantValue = respData.accountreentrant;
            }
            if (respData.dtvSessionInfo && respData.dtvSessionInfo.payload) {
                this.isDtvSessionInfo = true;
            }
            if (respData.maxCreditCheckReached) {
                this.maxCreditCheckReached = respData.maxCreditCheckReached;
                if (this.maxCreditCheckReached) { this.refObj.dobEntered = true; }
            }
            if (respData.accInformationPayload) {
                this.accInformation.payload = respData.accInformationPayload;
                if (this.accInformation.payload.contact) {
                    this.accInformation.contact = this.accInformation.payload.contact;
                }
                this.refObj.dobEntered = true;
                this.initializeData();
            }
        });

        this.orderObservable = this.store.select('order');
        this.orderSubscription = this.orderObservable.subscribe((orderData) => {
            if (orderData.loginDetails && orderData.loginDetails.userName) { this.uName = orderData.loginDetails.userName; }
            this.isUnameValid = true;
        });
        this.orderSubscription.unsubscribe();

        if (!this.accountRentrantValue && this.isPrepaid && this.autoLoginEmailAddress && this.autoLoginEmailAddress !== '' && !this.loadingonetime)  // added condition this.loadingonetime to avoide multiple times calling.
        {
            this.loadingonetime = true;
            const emailFlag = 'E';
            this.emailValidation(this.autoLoginEmailAddress, emailFlag);
        }


        if (this.accountRentrantValue && this.refObj.userData.previousUrl !== '/review-order' && !this.reEntrant) {
            if (this.accountRentrantValue && this.accInformation && !this.accInformation.billingaddr && this.accRespObj && this.accRespObj.billingAddress) {
                this.accInformation.billingaddr = this.accRespObj && this.accRespObj.billingAddress ? this.accRespObj.billingAddress :
                    this.accInformation && this.accInformation.payload && this.accInformation.payload.billingaddr;
            }
            if (this.accInformation && this.accInformation !== undefined && this.accInformation.contact && this.accInformation.contact !== undefined) {
                this.autoLoginEmailAddress = this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress;

                if (this.sfcData.isPrimaryPhoneSms === false) {
                    this.autoLoginPhoneNumber = '';
                } else if (this.accInformation && this.accInformation.contact && this.accInformation.contact.smsNumber) {
                    this.autoLoginPhoneNumber = this.accInformation && this.accInformation.contact && this.accInformation.contact.smsNumber;
                }
                this.autoLoginEmailAddress = this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress;

                this.phoneNumber = this.accInformation.contact.contactNumber;
                if (this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddrDeclined) {
                    this.contactDet.emailAddrDeclined = true;
                    this.accountForm.controls['emailAddress'].setValue('');
                    this.autoLoginEmailAddress = "";
                    this.emailPlaceHolder = 'Not provided';

                } else {
                    this.contactDet.emailAddrDeclined = false;
                    this.autoLoginEmailAddress = this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress;


                }
            }
            this.refObj.addrTypeSelected = this.accInformation.addressType;
            this.refObj.savedAddress = this.accInformation.billingaddr;
            if (this.accInformation.accountReqDetails && this.accInformation.accountReqDetails !== undefined) {
                if (this.accInformation.accountReqDetails.paperlessBilling) { this.refObj.billingOpt = 'paperless'; }
                if (this.accInformation.accountReqDetails.spanishBillPrint) { this.refObj.billingOpt = 'spanish'; }
                if (this.accInformation.accountReqDetails.largePrint) { this.refObj.billingOpt = 'large'; }
                if (this.accInformation.accountReqDetails.braille) { this.refObj.billingOpt = 'braille'; }
                this.accountObj.accountPreferences.noDirectMail = this.accInformation.accountReqDetails.noDirectMail;
                this.accountObj.accountPreferences.noEmail = this.accInformation.accountReqDetails.noEmail;
                this.accountObj.accountPreferences.noTeleMarketing = this.accInformation.accountReqDetails.noTeleMarketing;
                if (this.accInformation.accountReqDetails.textNotification &&
                    this.accInformation.accountReqDetails.emailNotification) {
                    if (this.accInformation.accountReqDetails.textNotification.billingNotification &&
                        this.accInformation.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(0);
                    }
                    else if (this.accInformation.accountReqDetails.textNotification.billingNotification && !this.accInformation.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(2);
                    }
                    else if (this.accInformation.accountReqDetails.emailNotification.billingNotification && !this.accInformation.accountReqDetails.textNotification.billingNotification) {
                        this.setBillingNotification(1);
                    }
                    else {
                        this.setBillingNotification(3);
                        this.refObj.billingChk = false;
                    }

                    if (this.accInformation.accountReqDetails.textNotification.orderingNotification &&
                        this.accInformation.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(0);
                    }

                    else if (this.accInformation.accountReqDetails.textNotification.orderingNotification && !this.accInformation.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(2);
                    }
                    else if (this.accInformation.accountReqDetails.emailNotification.orderingNotification && !this.accInformation.accountReqDetails.textNotification.orderingNotification) {
                        this.setOrderNotification(1);
                    }
                    else {
                        this.setOrderNotification(3);
                        this.refObj.orderChk = false;
                    }

                    if (this.accInformation.accountReqDetails.textNotification.repairNotification &&
                        this.accInformation.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(0);
                    }

                    else if (this.accInformation.accountReqDetails.textNotification.repairNotification && !this.accInformation.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(2);
                    }
                    else if (this.accInformation.accountReqDetails.emailNotification.repairNotification && !this.accInformation.accountReqDetails.textNotification.repairNotification) {
                        this.setRepairCheckNotification(1);
                    }
                    else {
                        this.setRepairCheckNotification(3);
                        this.refObj.repairChk = false;
                    }
                    this.refObj.billingOptions[0]['disable'] = false;
                    this.refObj.billingOptions[1]['disable'] = false;
                    this.refObj.billingOptions[2]['disable'] = false;
                }
            }
            this.creditRevObsv = this.store.select('creditReview');
            this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                if (this.isPrepaid) {
                    this.prepaidReEntrant(creditData);
                    this.initCreditPrepaidInfo();
                }
                if (creditData.creditreviewdepositdata && creditData.creditreviewdepositdata !== undefined && creditData.creditreviewdepositdata.payload && creditData.creditreviewdepositdata.payload !== undefined) {
                    this.addlOrderAttributesDepositData = creditData.creditreviewdepositdata.payload.addlOrderAttributes;
                    this.depositInfo = creditData.creditreviewdepositdata.payload.depositInfo;
                    this.onHoldCreditReviewOrderRefNo = creditData.creditreviewdepositdata.orderRefNumber;
                    this.onHoldProcessInstanceId = creditData.creditreviewdepositdata.processInstanceId;
                    this.isCreditChecked = true;
                    let hsiPayment;
                    let potsPayment;
                    if (this.addlOrderAttributesDepositData && this.addlOrderAttributesDepositData !== undefined && this.addlOrderAttributesDepositData[0] && this.addlOrderAttributesDepositData[0].orderAttributeGroup) {
                        this.addlOrderAttributesDepositData[0].orderAttributeGroup.map((depositData) => {
                            if (depositData && depositData.orderAttributeGroupName === "depositData") {
                                depositData.orderAttributeGroupInfo.map((paymentData) => {
                                    if (paymentData && paymentData.orderAttributes[0].orderAttributeValue === "INTERNET") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.hsiPaymentDone = true;
                                            hsiPayment = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.hsiPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                            hsiPayment = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.hsiRefundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                    if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-HP") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.potsPaymentDone = true;
                                            potsPayment = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.potsPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                            potsPayment = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.potsRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                    if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-DHP") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.dhpPaymentDone = true;
                                            potsPayment = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.dhpPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.dhpRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                });
                            }
                        });
                    }
                    if (this.isCreditChecked) {
                        this.refObj.updateAppClicked = false;
                        this.creditReviewResp = creditData;
                        this.creditObj = creditData.payload;
                        this.isPrepaid ? this.initCreditPrepaidInfo() : this.initCreditInfo();
                        this.refObj.gotCreditResponse = true;
                        this.products = this.depositInfo && this.depositInfo.products;
                        if (this.products) { this.calculateTotalDeposit(); }
                    }
                    if (!this.dhpPaymentDone && this.hsiPaymentDone && !this.allProductsPaid) {
                        this.refObj.disableDepositBtn = false;
                    }
                }
            });

        }
        if (!this.reEntrant && !this.accountRentrantValue) {
            this.phoneNumber = this.refObj.userData.phoneNumber;
            if (this.autoLoginEmailAddress !== '' && this.autoLoginPhoneNumber !== '') {
                this.refObj.billingOptions[0]['disable'] = false;
                this.setDefaultNotification(0);
            } else if (this.autoLoginEmailAddress !== '' && this.autoLoginPhoneNumber === '') {
                this.refObj.billingOptions[1]['disable'] = false;
                this.setDefaultNotification(1);
            } else if (this.autoLoginEmailAddress === '' && this.autoLoginPhoneNumber !== '') {
                this.refObj.billingOptions[2]['disable'] = false;
                this.setDefaultNotification(2);
            }
        }

        this.accountForm.get('ssnNumber').valueChanges.debounceTime(750).subscribe((values) => {
            this.personalDet.ssn === 'xxx-xx-xxxx' ? this.refObj.enteredSsn = true : this.refObj.enteredSsn = false;
            const ssnNumber = this.accountForm.get("ssnNumber").value;
            const ssnArr = ssnNumber.match(/\d/g);
            if (ssnArr && ssnArr.length === 9) {
                if (ssnArr && ssnNumber !== '000-00-0000') {
                    this.refObj.enteredSsn = true;
                    this.personalDet.ssn = ssnArr.join('');
                    this.ssnfield.nativeElement.value = 'xxx-xx-' + this.personalDet.ssn.substr(this.personalDet.ssn.length - 4);
                }
            } else {
                if (ssnNumber !== 'xxx-xx-xxxx') {
                    this.refObj.enteredSsn = false;
                }
            }
        });
        if (this.accRespObj.billingAddress !== null && this.accRespObj.billingAddress !== undefined && !this.accRespObj.billingAddress.isValidated && !this.reEntrant) {
            this.postalAddressValidated = false;
        }
        this.changedUnameVal = false;
        this.isUnameChanged = false;
        this.currentUnameVal = '';
        this.QConnectErrTxt = false;
        if(this.creditObj && this.creditObj.accountInfo && this.creditObj.accountInfo.loginDetails) {
            this.uName = this.creditObj.accountInfo.loginDetails.userName;
        }
        this.accountForm.get('username').valueChanges.subscribe((uname) => {
            if (uname !== '' && uname.length >= 6 && uname !== this.prevUnameVal) {
                this.changedUnameVal = true;
                this.currentUnameVal = uname;
                this.isUnameChanged = true;
            } else {
                this.QConnectErrTxt = true;
                this.QcErrMsg = "Enter a valid username.";
                this.isUnameChanged = false;
            }
        });
       if(this.isPrepaid) {
           this.getEffectiveBilldate();
       }
    }

    public disabledContinue() {
        if (this.isDtvOpus && this.isCreditChecked && this.newDtv && this.removedDTV) {
            return false;
        } else if (this.isDtvOpus && this.isCreditChecked && this.newDtv && !this.isDtvSessionInfo) {
            return true;
        } else if (this.creditInfo && this.creditInfo.creditClass === '9') {
            return true;
        } else if (!this.isPrepaid && this.refObj.submitted && (!this.refObj.enteredSsn || !this.refObj.enteredDL || this.refObj.underAge || this.accountForm.controls.firstName.invalid || this.accountForm.controls.lastName.invalid || !this.refObj.dobEntered || !this.postalAddressValidated || (!(this.contactDet && this.contactDet.emailAddrDeclined) && !this.refObj.isEmailValid) || this.personalDet.creditCheck === null)) {
            return true;
        } else if (this.isPrepaid && this.refObj.submitted && (!(this.contactDet && this.contactDet.emailAddrDeclined)) && !this.refObj.isEmailValid) {
            return true;
        } else if (this.isPrepaid && (!this.refObj.isEmailValid || this.QConnectErrTxt || this.isQcDown)) {
            return true;
        } else if (this.isPrepaid && this.isCreditChecked) {
            if (this.pastDueAmountExist && !this.refObj.paymentStatusPD && this.refObj.paymentFailed) {
                return true;
            } else if (!this.pastDueAmountExist && !this.refObj.isPrepaidPaymentSuccess && !this.refObj.paymentFailedPrepaid) {
                return true;
            } else if (this.isPaymentsError) {
                return true;
            }
        } else {
            return false;
        }

    }

    public ngAfterViewInit() {
        if (this.retainSSN !== undefined && this.retainSSN !== null && this.previousURL !== '/review-order') {
            if (this.ssnfield && this.ssnfield.nativeElement) { this.ssnfield.nativeElement.focus(); }
        }
        this.accRespObj.accountPassword = this.accountPassword;
    }
    /** Initialize new account page data, after getting response */
    public initializeData() {
        if (this.currentFlow !== 'Change') {
            this.accountObj.orderRefNumber = this.accInformation.orderRefNumber;
            this.accountObj.taskId = this.accInformation.taskId;
            this.accountObj.processInstanceId = this.accInformation.processInstanceId;
            this.accountObj.taskName = this.accInformation.taskName;
            this.accRespObj = this.accInformation.payload;
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.personalDetails && this.accRespObj.personalDetails !== undefined) {
                this.personalDet = this.accRespObj.personalDetails;
            } else {
                this.personalDet = this.accInformation.personaldetails;
            }
            if (
                this.accRespObj &&
                this.accRespObj !== undefined &&
                this.accRespObj.loginDetails &&
                this.accRespObj.loginDetails !== undefined) {
                this.loginDetails = this.accRespObj.loginDetails;
            }
            if (this.personalDet && this.personalDet !== undefined && this.personalDet.underAgeAck !== undefined && this.personalDet.underAgeAck) {
                this.personalDet.underAgeAck = false;
            }
            if (this.isOnHoldFlow && this.isCreditChecked && this.personalDet && this.personalDet !== undefined) {
                this.personalDet.creditCheck = true;
            }
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.contact && this.accRespObj.contact !== undefined) {
                this.contactDet = this.accRespObj.contact;
            } else {
                this.contactDet = this.accInformation.contact;

            }
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.billingAddress && this.accRespObj.billingAddress !== undefined) {
                if (this.accRespObj.billingAddress.stateOrProvince === null && this.accInformation &&
                    this.accInformation.billingaddr) {
                    this.accRespObj.billingAddress = this.accInformation.billingaddr;
                }

            }
            if (!this.accountRentrantValue) {
                this.refObj.savedAddress = this.accRespObj.billingAddress;
            }
            this.billingAddr = Object.assign({}, this.accRespObj.billingAddress);
            this.serviceAddress = Object.assign({}, this.accRespObj.billingAddress);
            if (!this.isServiceAddressInitialized) {
                this.initialServiceAddress = Object.assign({}, this.serviceAddress);
                this.isServiceAddressInitialized = true;
            }
            let lzipcode: string;
            if (this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode !== undefined && this.billingAddr.postCode && this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix) {
                lzipcode = this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix;
            } else if (this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode && (this.billingAddr.postCodeSuffix === '' || this.billingAddr.postCodeSuffix === undefined)) {
                lzipcode = this.billingAddr.postCode;
            } else {
                lzipcode = '';
            }
            if (this.accountForm === undefined) {
                this.accountForm = this.fb.group({
                    firstName: [this.refObj.userData.firstName,
                    [Validators.required, Validations.accountNameValidator as any]],
                    lastName: [this.refObj.userData.lastName, [Validators.required, Validations.accountNameValidator]],
                    middleName: this.refObj.userData.middleName ?
                        [this.refObj.userData.middleName, [Validations.accountNameValidator]] :
                        ['', [Validations.accountNameValidator]],
                    contactNumber: this.refObj.userData.phoneNumber ?
                        [this.refObj.userData.phoneNumber, [Validators.required, Validations.phoneValidator]] :
                        [this.contactDet.contactNumber, [Validators.required, Validations.phoneValidator]],
                    smsNumber: this.contactDet && this.contactDet.smsNumber ? [this.contactDet && this.contactDet.smsNumber,
                    [Validations.phoneValidator]] :
                        ['', [Validations.phoneValidator]],
                    emailAddress: this.contactDet && this.contactDet.emailAddress ?
                        [this.contactDet && this.contactDet.emailAddress, [Validations.emailValidator]] :
                        ['', [Validations.emailValidator]],
                    zipCode: [lzipcode, Validations.zipCodeValidator],
                    zipCodeInt: [(this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode !== undefined && this.billingAddr.postCode) ? this.billingAddr.postCode : '', Validations.zipCodeValidatorInt],
                    ssnNumber: [(this.personalDet && this.personalDet !== undefined && this.personalDet.ssn !== undefined && this.personalDet.ssn) ? this.personalDet.ssn : (this.retainSSN !== undefined && this.retainSSN !== null) ? this.retainSSN : '', [Validators.required]],
                    dlNumber: [(this.personalDet && this.personalDet !== undefined && this.personalDet.dLlicenseNo !== undefined && this.personalDet.dLlicenseNo) ? this.personalDet.dLlicenseNo : ''],
                    dLlicenseState: [this.personalDet && this.personalDet.dLlicenseState, Validators.required],
                    username: this.isPrepaid ? this.uName : ''
                });
            }
            if (this.accountForm.value.contactNumber && this.accountForm.value.contactNumber !== "") {
                if (this.phoneNumber !== "") {
                    this.accountForm.controls['contactNumber'].setValue(this.phoneNumber);
                }
                else {
                    this.phoneNumber = this.accountForm.value.contactNumber;
                    this.accountForm.controls['contactNumber'].setValue(this.phoneNumber);
                }

            }
            this.isInitializedFormObj = true;
            if (this.contactDet && this.contactDet.emailAddrDeclined) {
                this.accountForm.controls['emailAddress'].setValue('');
                this.emailPlaceHolder = 'Not provided';
            }

            if (this.autoLoginEmailAddress) {
                this.accountForm.controls['emailAddress'].setValue(this.autoLoginEmailAddress);
            }
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.accountPreferences && this.accRespObj.accountPreferences !== undefined) {
                const loc: AccountPreferences = this.accRespObj.accountPreferences;
                Object.keys(loc).forEach((key) => {
                    if (key !== 'emailNotification' && key !== 'textNotification' && loc[key] === null) {
                        loc[key] = false;
                    }
                });
                this.accountObj.accountPreferences = loc;
            }
            if (this.currentFlow === "COR") {
                this.setFirstLastName();
                this.store.dispatch({
                    type: 'UPDATE_USER_FROM_ACCOUNT_PAGE', payload: {
                        firstName: this.accountForm.value.firstName,
                        lastName: this.accountForm.value.lastName,
                        phoneNumber: this.accountForm.value.contactNumber,
                        smsNumber: this.accountForm.value.smsNumber,
                        emailAddress: this.accountForm.value.emailAddress,
                        emailAddrDeclined: this.contactDet.emailAddrDeclined
                    }
                });
            }

            /** If no email, set billing options to SMS */
            if (!(this.contactDet && this.contactDet.emailAddress) && !this.autoLoginEmailAddress) {
                this.refObj.billingOptions[1]['disable'] = true;
                this.refObj.billingOptions[0]['disable'] = true;
                const isValidMail = Validations.emailValidator({ value: this.autoLoginEmailAddress });
                if (!isValidMail) {
                    this.refObj.isEmailValid = true;
                } else {
                    this.refObj.isEmailValid = false;
                }
                this.setDefaultNotification(2);
            }
            /* If no smsNumber & valid email is present set billing options to Email,
            * else set to "Do not notify" */
            if (!(this.contactDet && this.contactDet.smsNumber) && !this.autoLoginPhoneNumber) {
                this.refObj.billingOptions[2]['disable'] = true;
                this.refObj.billingOptions[0]['disable'] = true;
                this.setDefaultNotification(3);
                this.refObj.isEmailValid ? this.setDefaultNotification(1) : this.setDefaultNotification(3);
            }
            if (this.personalDet && this.personalDet.dateOfBirth) {
                const dateParts = this.personalDet.dateOfBirth.split('-');
                this.refObj.day = dateParts[2];
                this.refObj.month = dateParts[1];
                this.refObj.year = dateParts[0];
                this.refObj.dobEntered = true;
                this.getAge();
            }
            const prevyr = (new Date().getFullYear() - 1).toString();
            this.refObj.yrpatrn = '19[0-9][0-9]|200[0-9]|20[1-' + prevyr.substr(2, 1) + '][0-' + prevyr.substr(3, 1) + ']';
            if (this.personalDet && this.personalDet.ssn && this.personalDet.ssn !== null && this.personalDet.ssn !== '') {
                this.refObj.enteredSsn = true;
            }
            this.checkEnteredDL();
            if (this.reEntrant && !this.isOnHoldFlow) {
                this.postalAddressValidated = true;
                this.accountObservable = this.store.select('account');
                this.accountSubscription = this.accountObservable.subscribe((data) => {
                    this.accountRentrantValues = data;
                });
                this.contactDet = this.accountRentrantValues.contact;
                if (!(this.contactDet && this.contactDet.emailAddrDeclined)) {
                    this.autoLoginEmailAddress = this.accountRentrantValues && this.accountRentrantValues.contact && this.accountRentrantValues.contact.emailAddress;
                } else {
                    this.autoLoginEmailAddress = "";
                    this.emailPlaceHolder = 'Not provided';

                }
                if (this.accountRentrantValues.accountReqDetails.paperlessBilling) { this.refObj.billingOpt = 'paperless'; }
                if (this.accountRentrantValues.accountReqDetails.spanishBillPrint) { this.refObj.billingOpt = 'spanish'; }
                if (this.accountRentrantValues.accountReqDetails.largePrint) { this.refObj.billingOpt = 'large'; }
                if (this.accountRentrantValues.accountReqDetails.braille) { this.refObj.billingOpt = 'braille'; }
                this.accountObj.accountPreferences.noDirectMail = this.accountRentrantValues.accountReqDetails.noDirectMail;
                this.accountObj.accountPreferences.noEmail = this.accountRentrantValues.accountReqDetails.noEmail;
                this.accountObj.accountPreferences.noTeleMarketing = this.accountRentrantValues.accountReqDetails.noTeleMarketing;
                if (this.accountRentrantValues.accountReqDetails.textNotification &&
                    this.accountRentrantValues.accountReqDetails.emailNotification) {
                    if (this.accountRentrantValues.accountReqDetails.textNotification.billingNotification &&
                        this.accountRentrantValues.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(0);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.textNotification.billingNotification && !this.accountRentrantValues.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(2);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.emailNotification.billingNotification && !this.accountRentrantValues.accountReqDetails.textNotification.billingNotification) {
                        this.setBillingNotification(1);
                    }
                    else {
                        this.setBillingNotification(3);
                        this.refObj.billingChk = false;
                    }

                    if (this.accountRentrantValues.accountReqDetails.textNotification.orderingNotification &&
                        this.accountRentrantValues.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(0);
                    }

                    else if (this.accountRentrantValues.accountReqDetails.textNotification.orderingNotification && !this.accountRentrantValues.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(2);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.emailNotification.orderingNotification && !this.accountRentrantValues.accountReqDetails.textNotification.orderingNotification) {
                        this.setOrderNotification(1);
                    }
                    else {
                        this.setOrderNotification(3);
                        this.refObj.orderChk = false;
                    }

                    if (this.accountRentrantValues.accountReqDetails.textNotification.repairNotification &&
                        this.accountRentrantValues.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(0);
                    }

                    else if (this.accountRentrantValues.accountReqDetails.textNotification.repairNotification && !this.accountRentrantValues.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(2);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.emailNotification.repairNotification && !this.accountRentrantValues.accountReqDetails.textNotification.repairNotification) {
                        this.setRepairCheckNotification(1);
                    }
                    else {
                        this.setRepairCheckNotification(3);
                        this.refObj.repairChk = false;
                    }
                }

            }
        } else {
            this.calculateTotalDepositForChange();
            this.isInitializedFormObj = true;
        }
    }

    /** Set Billing Option display */
    public setDefaultNotification(index) {
        this.refObj.billingChk ? this.refObj.billingOption = this.refObj.billingOptions[index] : this.refObj.billingOption = this.refObj.billingOptions[3];
        this.refObj.orderChk ? this.refObj.orderOption = this.refObj.billingOptions[index] : this.refObj.orderOption = this.refObj.billingOptions[3];
        this.refObj.repairChk ? this.refObj.repairOption = this.refObj.billingOptions[index] : this.refObj.repairOption = this.refObj.billingOptions[3];
    }

    public setBillingNotification(index) {
        this.refObj.billingOption = this.refObj.billingOptions[index];
    }

    public setOrderNotification(index) {
        this.refObj.orderOption = this.refObj.billingOptions[index];
    }

    public setRepairCheckNotification(index) {
        this.refObj.repairOption = this.refObj.billingOptions[index];
    }

    public billingOptClickHandler(currentOpt, previousOpt) {
        if (currentOpt !== previousOpt) {
            this.refObj.billingOpt = currentOpt;
            this.refObj.selectedOpt = currentOpt;
        }
    }

    /** Not using uncheck function */
    public uncheck(value: string) {
        if (this.refObj.billingOption === this.refObj.billingOptions[3] || this.refObj.orderOption === this.refObj.billingOptions[3] || this.refObj.repairOption === this.refObj.billingOptions[3]) {
            switch (value) {
                case 'billing': this.refObj.billingOption = this.refObj.billingOptions[3] ? this.refObj.billingChk = false && this.refObj.billingOption === this.refObj.billingOptions[3] : this.refObj.billingChk;
                    break;
                case 'ordering': this.refObj.orderOption = this.refObj.billingOptions[3] ? this.refObj.orderChk = false && this.refObj.orderOption === this.refObj.billingOptions[3] : this.refObj.orderChk;
                    break;
                case 'repair': this.refObj.repairOption = this.refObj.billingOptions[3] ? this.refObj.repairChk = false && this.refObj.repairOption === this.refObj.billingOptions[3] : this.refObj.repairChk;
                    break;
            }
        }
    }

    public unCheck(proactiveName) {
        if (proactiveName === 'billing') {
            this.refObj.billingOption === this.refObj.billingOptions[3] ? this.refObj.billingChk = false : this.refObj.billingChk = true;
        }
        if (proactiveName === 'ordering') {
            this.refObj.orderOption === this.refObj.billingOptions[3] ? this.refObj.orderChk = false : this.refObj.orderChk = true;
        }
        if (proactiveName === 'repair') {
            this.refObj.repairOption === this.refObj.billingOptions[3] ? this.refObj.repairChk = false : this.refObj.repairChk = true;
        }
    }
    public emailValidation(event: any, flag: any) {
        this.QConnectErrTxt = false;
        if (event === this.accountForm.value.emailAddress && flag === "E") {
            this.validMail = Validations.prepaidEmailValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress });
            this.validUname = Validations.prepaidUnameValidator({ value: event });
            this.prevUnameVal = this.accountForm && this.accountForm.value && this.accountForm.value.username;
            this.isUnameChanged = true;
        } else {
            if (event !== '') {
                const uNamePrev = this.prevUnameVal;
                this.prevUnameVal = this.accountForm && this.accountForm.value && this.accountForm.value.username;
                this.validUname = Validations.prepaidUnameValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.username });
                if (!this.validUname) {
                    this.QConnectErrTxt = true;
                    this.QcErrMsg = "Enter a valid username.";
                }
                if (this.validUname && this.changedUnameVal && this.prevUnameVal !== (undefined || "") &&
                    (this.prevUnameVal !== this.accountForm.value.emailAddress || this.prevUnameVal === this.accountForm.value.emailAddress) &&
                    this.currentUnameVal !== uNamePrev) {
                    this.isUnameChanged = true;
                } else {
                    this.isUnameChanged = false;
                }
            } else {
                this.QConnectErrTxt = true;
                this.QcErrMsg = "Enter a valid username.";
            }

        }
        if (this.validMail && this.isUnameChanged) {
            this.refObj.isEmailValid = true;
            if (!this.loading) {
                this.validateEmail(event, flag);

            }
        } else {
            //this.refObj.isEmailValid = false;
        }
    }

    public validateEmail(email, flag) {
        let event = email;
        this.loading = true;
        const date = new Date();
        const userObj = {
            "UserName": event,
            "RequestId": 'ESHOP-' + String(date.getTime())
        };
        this.logger.log("info", "account.component.ts", "QuickConnectRequest", JSON.stringify(userObj));
        this.logger.startTime();
        this.accountService.getEmailValidated(userObj)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "QuickConnectResponse", error);
                this.logger.log("error", "account.component.ts", "Srvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.isQcDown = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError("error", 'Not Applicable', "QuickConnectRequest", "account.component.ts", "Account Page", error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "QuickConnectResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "account.component.ts", "Srvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data) {
                    this.QConnectResp = data;
                    this.loadingonetime = true;
                    this.isQcDown = false;
                    if (this.QConnectResp.PrimaryMessageStatus.TransactionStatus === 'S') {
                        if ((flag === "E" && this.currentUnameVal !== '' && this.currentUnameVal !== event) ||
                            (this.currentUnameVal === '' || this.currentUnameVal === event)
                        ) {
                            this.uName = event;
                        } else {
                            this.uName = this.currentUnameVal;
                        }
                        if (this.uName) {
                            if (this.loginDetails) { this.loginDetails.userName = this.uName; }
                        }
                        this.isUnameValid = true;
                        this.QConnectErrTxt = false;
                        this.contactDet.emailAddrDeclined = false;
                    } else {
                        this.QConnectErrTxt = true;
                        this.isUnameValid = false;
                        if (this.QConnectResp.PrimaryMessageStatus.ErrorCode) {
                            if (this.QConnectResp.PrimaryMessageStatus.ErrorCode === 'QC7521') {
                                this.QcErrMsg = "Username is taken. Try a different one.";
                            } else {
                                this.QcErrMsg = this.QConnectResp.PrimaryMessageStatus.ErrorMessage;
                            }
                        } else if (!this.validUname) {
                            this.QcErrMsg = "Enter a valid username.";
                        }
                    }
                }
                this.loading = false;
            },
                (error) => {
                    if (!this.isQcDown) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "QuickConnectResponse", error);
                        this.logger.log("error", "account.component.ts", "Srvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) { return; }
                });
    }


    /**
     * Validate entered email & smsNumber. Based on valid fields set billing options
     *  & disable remaining options
     */
    public emailPlaceHolder: string;
    public notificationValidation() {
        if (this.isPrepaid) {
            //do nothing
        } else if (this.contactDet && this.contactDet.emailAddrDeclined) {
            this.emailAddrDeclinedManually = true;
            this.accountForm.controls['emailAddress'].setValue('');
            this.autoLoginEmailAddress = "";
            this.emailPlaceHolder = 'Not provided';
        }
        else {
            this.emailPlaceHolder = '';
        }
        let isValidMail = Validations.emailValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress });
        if (isValidMail === null && this.refObj.billingOpt !== 'paperless') {
            this.refObj.billingOpt = 'paperless';
            this.refObj.selectedOpt = 'paperless';
        }
        if (!this.refObj.isEmailValid && this.refObj.billingOpt === 'paperless') {
            this.refObj.billingOpt = 'none';
            this.refObj.selectedOpt = 'none';
        }
        if (this.refObj.billingOpt === 'paperless' && (this.contactDet && this.contactDet.emailAddrDeclined)) {

            this.refObj.isEmailValid = false;
            this.refObj.billingOpt = 'none';
            this.refObj.selectedOpt = 'none';
        }

        this.billingOptionValidation();
        const emailFlag = 'E';
        if (this.isPrepaid && this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress) { this.emailValidation(this.accountForm.value.emailAddress, emailFlag); }
    }

    public billingOptionValidation() {
        const isValidMail = Validations.emailValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress });
        const isValidPh = Validations.phoneValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.smsNumber });
        if (isValidMail || isValidPh) {
            this.refObj.billingOptions[0]['disable'] = true;
        } else {
            this.refObj.billingOptions[0]['disable'] = false;
        }
        if (!isValidMail) {
            this.refObj.billingOptions[1]['disable'] = false;
            this.refObj.isEmailValid = true;
            this.setDefaultNotification(1);
        } else {
            this.refObj.billingOptions[1]['disable'] = true;
            this.refObj.isEmailValid = false;
        }
        if (!isValidPh) {
            this.refObj.billingOptions[2]['disable'] = false;
            this.refObj.isEmailValid === true ? this.setDefaultNotification(0) : this.setDefaultNotification(2);
        } else {
            this.refObj.billingOptions[2]['disable'] = true;
            this.refObj.isEmailValid === true ? this.setDefaultNotification(1) : this.setDefaultNotification(3);
        }
    }
    /** Get States from countryStateService */
    public getStates() {
        this.refObj.stateCountries = this.countryStateService.getStates();
        this.refObj.stateCountries.splice(0, 0, { stateName: 'Select State', stateCode: '' });
        const stateObj = (this.accountRentrantValue && !this.reEntrant) ? (this.refObj.stateCountries.find((obj) =>
            obj.stateCode === this.accInformation.billingaddr.stateOrProvince
        )) : (this.refObj.stateCountries.find((obj) =>
            obj.stateCode === this.accRespObj.billingAddress.stateOrProvince
        ));
        stateObj ? this.refObj.selectedState = stateObj : this.refObj.selectedState = { stateName: 'Select State', stateCode: '' };
    }

    public checkUpdatedOtc(data) {
        this.otcUpdated = data;
    }

    /** Get MilitaryStates from countryStateService */
    public getMilitaryState() {
        this.refObj.stateCountries = this.countryStateService.getMilitaryStates();
        this.refObj.stateCountries.splice(0, 0, { militaryStateName: 'Select Armed Forces Location', militaryStateCode: '' });
        const armyLoc = (this.accountRentrantValue && !this.reEntrant) ? this.refObj.stateCountries.find((obj) =>
            obj.militaryStateCode === this.accInformation.billingaddr.stateOrProvince) : this.refObj.stateCountries.find((obj) =>
                obj.militaryStateCode === (this.reEntrant ? this.accRespObj.billingAddress.stateOrProvince : (this.accRespObj.billingAddress.armedForceLoc ? this.accRespObj.billingAddress.armedForceLoc : this.accRespObj.billingAddress.stateOrProvince))
            );
        armyLoc ? this.refObj.selectedState = armyLoc : this.refObj.selectedState = this.refObj.stateCountries[0];
    }

    /** Get Countries from countryStateService */
    public getCountries() {
        this.loading = true;
        const countryListReq = {
            "inputAttribute": [
                {
                    "attributeName": "dataType",
                    "attributeValue": [
                        "countryList"
                    ]
                }
            ],
            "outputAttribute": [
                {
                    "attributeName": "countryISOCode"
                },
                {
                    "attributeName": "countryName"
                }
            ],
            "requestDate": "",
            "ruleId": "100"
        };

        let countryRes = '';
        let countryResObj: any = '';
        this.logger.log("info", "account.component.ts", "getInternationalBillingCountryListRequest", JSON.stringify(countryListReq));
        this.logger.startTime();
        this.accountService.getInternationalBillingCountryList(countryListReq)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListResponse", error);
                this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "getInternationalBillingCountryListResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                countryRes = JSON.stringify(data);
                countryResObj = JSON.parse(countryRes);
                let countryResAry = [];
                countryResAry = countryResObj.outputAttribute;
                const countryAry = [];
                for (var i = 0, len = countryResAry.length; i < len; i++) {
                    const countr = {};
                    countr['countryCode'] = countryResAry[i][0];
                    countr['countryName'] = countryResAry[i][1];
                    countryAry.push(countr);
                }

                this.refObj.stateCountries = countryAry;
                this.refObj.stateCountries.splice(0, 0, { countryName: 'Select Country', countryCode: '' });
                const country = this.refObj.stateCountries.find((obj) =>
                    obj.countryCode === this.accRespObj.billingAddress.country
                );
                if (this.refObj.addrModels.field1 === "") {
                    this.refObj.selectedState = this.refObj.stateCountries[0];
                    this.accountForm.patchValue({ zipCodeInt: '' });

                } else {
                    country ? this.refObj.selectedState = country : this.refObj.selectedState = this.refObj.stateCountries[0];
                }
                this.loading = false;
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListResponse", error);
                    this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) {
                        return;
                    }
                    try {
                        this.apiResponseError = JSON.parse(error);
                    } catch (e) {
                        if (error.status === 500) {
                            const lAPIErrorLists: APIErrorLists = {
                                errorResponse: [{
                                    statusCode: "500",
                                    reasonCode: "500",
                                    message: "500 Internal Server Error",
                                    messageDetail: "Discount compatibility error",
                                    source: "",
                                    timestamp: "",
                                    orderRefNumber: "",
                                    serverDown: "",
                                    tnNotFound: "",
                                    tnNotAvail: ""
                                }]
                            };
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        } else {
                            const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        }
                    }
                    if (this.apiResponseError && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", this.apiResponseError);
                    } else {
                        const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                    }
                });
    }

    /** Change billing address click handler */
    public handleChangeAddr() {
        this.refObj.changeAddrClicked = true;
        if (this.refObj.addrTypeSelected) {
            this.refObj.addrTypeSelected = this.refObj.addrTypeSelected;
        } else if (this.refObj.addrTypeSelected === '' || this.refObj.addrTypeSelected === null || this.refObj.addrTypeSelected === undefined) {
            this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
        } else if (this.accRespObj.billingAddress.addressTypeSelected) {
            this.refObj.addrTypeSelected = this.accRespObj.billingAddress.addressTypeSelected;
        } else if (this.accRespObj.billingAddress.subAddress && (this.accRespObj.billingAddress.subAddress.combinedDesignator !== null || this.accRespObj.billingAddress.subAddress.combinedDesignator !== undefined || this.accRespObj.billingAddress.subAddress.combinedDesignator !== '')) {
            this.accRespObj.billingAddress.addressTypeSelected = this.refObj.addressTypes[1];
            this.refObj.addrTypeSelected = this.refObj.addressTypes[1];
        } else {
            this.accRespObj.billingAddress.addressTypeSelected = this.refObj.addressTypes[0];
            this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
        }
        this.refObj.initialAddrType = this.refObj.addrTypeSelected;
        this.addressTypeSelectionHandler();
    }

    /** Change billing address, different address type selection handler */
    public addressTypeSelectionHandler() {
        if (this.apiResponseError && this.apiResponseError.errorResponse[0]) {
            this.apiResponseError.errorResponse[0].messageDetail = '';
        }
        this.billingAddr = {
            city: '', street: '', addressLine: '', stateOrProvince: '',
            streetType: '', addressTypeSelected: this.refObj.addrTypeSelected
        };
        if (this.accRespObj.billingAddress.postCodeSuffix) {
            this.accountForm.patchValue({ zipCode: this.accRespObj.billingAddress.postCode + '-' + this.accRespObj.billingAddress.postCodeSuffix });
        } else {
            this.accountForm.patchValue({ zipCode: this.accRespObj.billingAddress.postCode });
        }
        this.addrTypeDpdwnError = '';
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Street Address', addrPlchd2: 'Unit #',
                    addrPlchd3: 'City'
                };
                if (this.accountRentrantValue && this.accInformation && !this.accInformation.billingaddr && this.accRespObj && this.accRespObj.billingAddress) {
                    this.accInformation.billingaddr = this.accRespObj.billingAddress;
                }
                if (this.accRespObj.billingAddress && this.accRespObj.billingAddress.unitNumber === undefined) {
                    this.accRespObj.billingAddress.unitNumber = this.accRespObj.billingAddress.subAddress && this.accRespObj.billingAddress.subAddress.combinedDesignator;
                }
                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetAddress : (this.accRespObj.billingAddress.streetAddress ?
                        this.accRespObj.billingAddress.streetAddress : ''),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.unitNumber : (this.accRespObj.billingAddress.unitNumber ?
                        this.accRespObj.billingAddress.unitNumber : ''),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : (this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality)
                };
                this.getStates();
                break;
            case 'P.O. Box':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Box Number', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.streetNrFirst ?
                        this.accRespObj.billingAddress.streetNrFirst : (this.accRespObj.billingAddress.streetAddress ?
                            this.accRespObj.billingAddress.streetAddress : '')),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.subAddress.combinedDesignator : (this.accRespObj.billingAddress.subAddress.combinedDesignator ?
                        this.accRespObj.billingAddress.subAddress.combinedDesignator : ''),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality
                };
                this.getStates();
                break;
            case 'Rural Route':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Rural Route', addrPlchd2: 'Box Number',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetName.replace("RR ", '') : (this.accRespObj.billingAddress.streetName ?
                        this.accRespObj.billingAddress.streetName.replace("RR ", '') : this.accRespObj.billingAddress.streetAddress),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.streetNrFirst ?
                        this.accRespObj.billingAddress.streetNrFirst : ''),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : (this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality)
                };
                this.getStates();
                break;
            case 'Military':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'APO, FPO, DPO'
                };
                if (this.accRespObj.billingAddress.apoFpoDpo) {
                    this.refObj.addrModels = {
                        field1: (this.accountRentrantValue || this.reEntrant) ? (this.accInformation.billingaddr.addressLine1 ? this.accInformation.billingaddr.addressLine1 : this.accInformation.billingaddr.streetName) : (this.accRespObj.billingAddress.addressLine1 ?
                            this.accRespObj.billingAddress.addressLine1 : this.accRespObj.billingAddress.streetAddress),
                        field2: (this.accountRentrantValue || this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.addressLine2 ?
                            this.accRespObj.billingAddress.addressLine2 : ''),
                        field3: (this.accountRentrantValue || this.reEntrant) ? this.accInformation.billingaddr.city : (this.accRespObj.billingAddress.apoFpoDpo ?
                            this.accRespObj.billingAddress.apoFpoDpo : '')
                    };
                } else {
                    this.refObj.addrModels = {
                        field1: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.addressLine1 ? this.accInformation.billingaddr.addressLine1 : this.accInformation.billingaddr.streetName) : (this.accRespObj.billingAddress.addressLine1 ?
                            this.accRespObj.billingAddress.addressLine1 : this.accRespObj.billingAddress.streetName),
                        field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.addressLine2 ?
                            this.accRespObj.billingAddress.addressLine2 : this.accRespObj.billingAddress.streetNrFirst),
                        field3: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.city : (this.accRespObj.billingAddress.apoFpoDpo ?
                            this.accRespObj.billingAddress.apoFpoDpo : this.accRespObj.billingAddress.city)
                    };
                }
                this.getMilitaryState();
                break;
            case 'International':
                this.refObj.disableValidateAddr = true;
                this.refObj.disableSaveAddr = false;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'City'
                };

                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.addressLine1 ? this.accInformation.billingaddr.addressLine1 : this.accInformation.billingaddr.streetAddress) : (this.accRespObj.billingAddress.addressLine1 ?
                        this.accRespObj.billingAddress.addressLine1 : this.accRespObj.billingAddress.streetAddress),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.addressLine2 ? this.accInformation.billingaddr.addressLine2 : this.accInformation.billingaddr.streetName) : (this.accRespObj.billingAddress.addressLine2 ?
                        this.accRespObj.billingAddress.addressLine2 : this.accRespObj.billingAddress.streetName),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : (this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality)
                };
                this.getCountries();
                break;
            default: break;
        }
        if (this.refObj.initialAddrType !== this.refObj.addrTypeSelected) {
            this.accountForm.patchValue({ zipCode: '' });
            this.refObj.addrModels = {
                field1: '', field2: '', field3: ''
            };
        }
    }

    public checkAddressTypeSelected() {
        const addrModelsField1Val = this.refObj.addrModels.field1.toUpperCase();
        if (((addrModelsField1Val.indexOf('POB') !== -1) ||
            (addrModelsField1Val.indexOf('PBOX') !== -1) ||
            (addrModelsField1Val.indexOf('PO BOX') !== -1) ||
            (addrModelsField1Val.indexOf('P.O. BOX') !== -1) ||
            (addrModelsField1Val.indexOf('P.O.BOX') !== -1)) && this.refObj.addrTypeSelected !== 'P.O. Box') {
            this.addrTypeDpdwnError = 'Incorrect Address Type';
            this.refObj.disableValidateAddr = true;
        } else {
            this.addrTypeDpdwnError = '';
            this.refObj.disableValidateAddr = false;
        }
    }

    /** Change billing address state/country selection handler */
    public stateCountrySelectionHandler() {
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
            case 'P.O. Box':
            case 'Rural Route':
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                break;
            case 'Military':
                this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
                break;
            case 'International':
                this.billingAddr.country = this.refObj.selectedState.countryCode;
                break;
            default: break;
        }
    }

    /** Change billing address Validate button handler */
    public validateBillingAddr() {
        this.refObj.isExactAddr = '';
        this.refObj.disableSaveAddr = true;
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
                this.billingAddr.streetAddress = this.refObj.addrModels.field1;
                this.billingAddr.addressLine1 = this.billingAddr.streetAddress;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.streetAddress}
                                        ${this.billingAddr.addressLine2},
                                        ${this.billingAddr.stateOrProvince}, 
                                        ${this.billingAddr.city}`;
                break;
            case 'P.O. Box':
                this.refObj.addrModels.field1 = this.refObj.addrModels.field1.toUpperCase();
                if (this.refObj.addrModels.field1.indexOf('PO BOX') === -1) {
                    this.billingAddr.streetAddress = 'PO BOX ' + String(this.refObj.addrModels.field1);
                } else {
                    this.billingAddr.streetAddress = this.refObj.addrModels.field1;
                }
                this.billingAddr.boxNumber = this.billingAddr.streetAddress;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.addressLine1 = this.billingAddr.boxNumber;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.boxNumber}
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.stateOrProvince}, 
                                        ${this.billingAddr.city}`;
                break;
            case 'Rural Route':
                this.billingAddr.ruralRoute = this.refObj.addrModels.field1;
                this.billingAddr.boxNumber = this.refObj.addrModels.field2;
                this.billingAddr.addressLine1 = "RR " + this.billingAddr.ruralRoute;
                this.billingAddr.addressLine2 = "BOX " + this.billingAddr.boxNumber;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.ruralRoute}
                                    ${this.billingAddr.boxNumber}, 
                                    ${this.billingAddr.stateOrProvince}, 
                                    ${this.billingAddr.city}`;
                break;
            case 'Military':
                this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.apoFpoDpo = this.refObj.addrModels.field3;
                this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
                this.billingAddr.city = this.billingAddr.apoFpoDpo;
                this.billingAddr.locality = this.billingAddr.city;
                this.billingAddr.stateOrProvince = this.billingAddr.armedForceLoc;
                this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.apoFpoDpo}, 
                                        ${this.billingAddr.armedForceLoc}`;
                break;
            case 'International':
                this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.billingAddr.country = this.refObj.selectedState.countryCode;
                this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.city},
                                        ${this.billingAddr.country}`;
                break;
            default: break;
        }

        this.billingAddr.postCode = this.accountForm.value.zipCode;
        const zipValid = Validations.zipCodeValidator({ value: this.accountForm.value.zipCode });
        /** Unit number is optional for street address, checking with only mandatory fields */
        if (!this.refObj.addrModels.field1 || !this.refObj.addrModels.field3 || zipValid) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        if (this.refObj.addrTypeSelected === '' || this.refObj.addrTypeSelected === undefined) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        if (!this.refObj.selectedState.stateCode && !this.refObj.selectedState.militaryStateCode
            && !this.refObj.selectedState.countryCode) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        this.refObj.isEnteredAllAddsFields = true;
        const lpostCode = this.billingAddr.postCode.length === 5 && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix !== '' ? this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix : this.billingAddr.postCode;
        this.refObj.combinedAddress = this.refObj.combinedAddress + ', ' + String(lpostCode);
        let civicOrpostal = 'postalAddresses';

        this.logger.log("info", "account.component.ts", "geoesAddressValidationRequest", JSON.stringify(this.billingAddr));
        let errorResolved = false;
        this.logger.startTime();
        this.addressService.getGeoesAddress(this.billingAddr, civicOrpostal)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "geoesAddressValidationResponse", error);
                this.logger.log("error", "account.component.ts", "geoesAddressValidationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "geoesAddressValidationResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "account.component.ts", "getE911AcntPageSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let respAddressesArray = [];
                    let lunitNumber: string = '';
                    if (this.refObj && this.refObj.addrModels && this.refObj.addrModels.field2) {
                        lunitNumber = this.refObj.addrModels.field2 ? this.refObj.addrModels.field2 : '';
                    }

                    if (civicOrpostal === 'civicAddresses') {
                        respAddressesArray = data.civicAddresses;
                    } else {
                        respAddressesArray = data.postalAddresses;
                    }

                    if (data && data !== undefined && data !== null && data.result === "Green") {
                        this.refObj.isExactAddr = 'exact';
                        this.refObj.disableSaveAddr = false;
                        if (respAddressesArray[0].subAddress !== undefined) {
                            lunitNumber = String(respAddressesArray[0].subAddress.designator) + ' ' + String(respAddressesArray[0].subAddress.value);
                        }
                        const geoesResponseAddress: EnterpriseAddress = {
                            isValidated: true,
                            streetAddress: respAddressesArray[0].streetAddress,
                            streetNrFirst: respAddressesArray[0].streetNrFirst,
                            streetNrFirstSuffix: '',
                            streetNamePrefix: respAddressesArray[0].streetNamePrefix,
                            streetName: respAddressesArray[0].streetName,
                            streetType: respAddressesArray[0].streetType,
                            locality: respAddressesArray[0].locality,
                            city: respAddressesArray[0].locality,
                            stateOrProvince: respAddressesArray[0].stateOrProvince,
                            postCode: respAddressesArray[0].postCode,
                            postCodeSuffix: respAddressesArray[0].postCodeSuffix !== 'undefined' ? respAddressesArray[0].postCodeSuffix : '',
                            source: respAddressesArray[0].source,
                            country: 'USA',
                            subAddress: {
                                sourceId: '',
                                source: respAddressesArray[0].source,
                                geoSubAddressId: '',
                                combinedDesignator: lunitNumber,
                                elements: [
                                    {
                                        designator: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.designator !== undefined ? respAddressesArray[0].subAddress.designator : '',
                                        value: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.value !== undefined ? respAddressesArray[0].subAddress.value : ''
                                    }
                                ]
                            }
                        };
                        this.accRespObj.billingAddress = geoesResponseAddress;
                        this.refObj.validatedAddr = this.accRespObj.billingAddress;
                        this.refObj.savedAddress = this.accRespObj.billingAddress;
                        this.refObj.selectedAddr = Object.assign({}, this.accRespObj.billingAddress);
                        this.accRespObj.isBillAddrSameAsServiceAddress = false;
                        this.accountObservable = this.store.select('account');
                        this.accRespObj.contact.emailAddress = this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress;
                        this.accRespObj.contact.contactNumber = this.accountForm.value.contactNumber;
                        this.accInformation.payload.billingAddress = this.refObj.savedAddress;
                        this.store.dispatch({ type: 'BILLING_ADDRESS', payload: this.accRespObj });

                    }
                    else if (data && data !== undefined && data !== null && (data.result === 'Yellow' || data.result.toUpperCase() === 'RED')) {
                        this.refObj.isExactAddr = 'multi';
                        this.refObj.nearAddresses = [];
                        if (data && data.result.toUpperCase() !== 'RED') {
                            this.redAddressFlag = false;
                            for (let i = 0; i < respAddressesArray.length; i++) {
                                if (respAddressesArray[i].subAddress !== undefined) {
                                    lunitNumber = String(respAddressesArray[i].subAddress.designator) + ' ' + String(respAddressesArray[i].subAddress.value);
                                }
                                const geoesResponseAddress: EnterpriseAddress = {
                                    isValidated: true,
                                    streetAddress: respAddressesArray[i].streetAddress,
                                    streetNrFirst: respAddressesArray[i].streetNrFirst,
                                    streetNrFirstSuffix: '',
                                    streetNamePrefix: respAddressesArray[i].streetNamePrefix,
                                    streetName: respAddressesArray[i].streetName,
                                    streetType: respAddressesArray[i].streetType,
                                    locality: respAddressesArray[i].locality,
                                    city: respAddressesArray[i].locality,
                                    stateOrProvince: respAddressesArray[i].stateOrProvince,
                                    postCode: respAddressesArray[i].postCode,
                                    postCodeSuffix: respAddressesArray[i].postCodeSuffix !== 'undefined' ? respAddressesArray[i].postCodeSuffix : '',
                                    source: respAddressesArray[i].source,
                                    country: 'USA',
                                    subAddress: {
                                        sourceId: '',
                                        source: respAddressesArray[i].source,
                                        geoSubAddressId: '',
                                        combinedDesignator: lunitNumber,
                                        elements: [
                                            {
                                                designator: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.designator !== undefined ? respAddressesArray[i].subAddress.designator : '',
                                                value: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.value !== undefined ? respAddressesArray[i].subAddress.value : ''
                                            }
                                        ]
                                    }
                                };
                                this.refObj.nearAddresses.push(geoesResponseAddress);
                            }
                        }
                        else {
                            this.redAddressFlag = true;
                        }
                        const newNearAddress = Object.assign({}, this.accRespObj.billingAddress, this.billingAddr);
                        if (newNearAddress.postCode.indexOf("-") > -1) {
                            // post ocde already has a suffix, remove it
                            newNearAddress.postCode = newNearAddress.postCode.substr(0, newNearAddress.postCode.indexOf("-"));
                        }
                        this.refObj.nearAddresses.push(newNearAddress);

                    } else {
                        this.refObj.isExactAddr = 'red';
                    }

                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "geoesAddressValidationResponse", error);
                        this.logger.log("error", "account.component.ts", "geoesAddressValidationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                }
            );
    }

    /** Billing address selection handler from multiple addresses, after validation */
    public addressRadioHandler() {
        this.refObj.disableSaveAddr = false;
        this.refObj.selectedAddr.addressTypeSelected = this.refObj.addrTypeSelected;
        const lpostCode = this.refObj.selectedAddr.postCode && this.refObj.selectedAddr.postCodeSuffix !== undefined && this.refObj.selectedAddr.postCodeSuffix !== '' ? String(this.refObj.selectedAddr.postCode) + ' - ' + String(this.refObj.selectedAddr.postCodeSuffix) : String(this.refObj.selectedAddr.postCode);
        this.refObj.combinedAddress = `${this.refObj.selectedAddr.streetAddress}
        ${String(this.refObj.selectedAddr.unitNumber) ? ', ' + String(this.refObj.selectedAddr.unitNumber) : ''}
                              ${this.refObj.selectedAddr.city ? this.refObj.selectedAddr.city : this.refObj.selectedAddr.locality}, 
                              ${this.refObj.selectedAddr.stateOrProvince} 
                              ${lpostCode}`;
    }

    /** Save billing address button handler */
    public saveChangedAddr() {
        if ((!this.refObj.addrModels.field1 || !this.refObj.selectedState.countryCode) && this.refObj.addrTypeSelected === "International") {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        this.postalAddressValidated = true;
        this.billingAddr = this.refObj.selectedAddr;
        if (this.refObj.addrTypeSelected === 'International') {
            this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
            this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
            this.billingAddr.city = this.refObj.addrModels.field3;
            this.billingAddr.locality = this.billingAddr.city;
            this.billingAddr.postCode = this.accountForm.value.zipCodeInt;
            this.billingAddr.country = this.refObj.selectedState.countryCode;
            this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                    ${this.billingAddr.addressLine2}, 
                                    ${this.billingAddr.city},
                                    ${this.billingAddr.country}`;
            this.refObj.selectedAddr = this.billingAddr;

            const internationalAddressEntry: EnterpriseAddress = {
                isValidated: true,
                streetAddress: this.refObj.addrModels.field1,
                streetNrFirst: '',
                streetNrFirstSuffix: '',
                streetNamePrefix: '',
                streetName: this.refObj.addrModels.field2,
                streetType: '',
                locality: this.refObj.addrModels.field3,
                city: this.refObj.addrModels.field3,
                stateOrProvince: '',
                postCode: this.billingAddr.postCode,
                postCodeSuffix: '',
                source: '',
                country: this.billingAddr.country,
                subAddress: {
                    sourceId: '',
                    source: '',
                    geoSubAddressId: '',
                    combinedDesignator: '',
                    elements: [
                        {
                            designator: '',
                            value: ''
                        }
                    ]
                }
            };
            this.store.dispatch({ type: 'ADD_TYPE', payload: this.refObj.addrTypeSelected });
            this.refObj.savedAddress = this.refObj.selectedAddr;
            this.refObj.isExactAddr = '';
            this.refObj.disableSaveAddr = true;
            this.accRespObj.billingAddress = Object.assign({}, internationalAddressEntry);
            this.refObj.changeAddrClicked = false;
            this.accRespObj.isBillAddrSameAsServiceAddress = false;
        } else {
            this.store.dispatch({ type: 'ADD_TYPE', payload: this.refObj.addrTypeSelected });
            this.refObj.savedAddress = this.refObj.selectedAddr;
            this.refObj.isExactAddr = '';
            this.refObj.disableSaveAddr = true;
            this.accRespObj.billingAddress = Object.assign({}, this.refObj.selectedAddr);
            this.refObj.changeAddrClicked = false;
            this.accRespObj.isBillAddrSameAsServiceAddress = false;
        }
        this.store.dispatch({ type: 'BILLING_ADDR', payload: this.accRespObj.billingAddress });

    }

    public useServiceAddress() {
        this.serviceAddress = Object.assign({}, this.initialServiceAddress);
        this.refObj.savedAddress = Object.assign({}, this.serviceAddress);
        this.billingAddr = Object.assign({}, this.serviceAddress);
        this.accRespObj.billingAddress = Object.assign({}, this.serviceAddress);
        this.accRespObj.isBillAddrSameAsServiceAddress = true;

        // moved to this handler from template:
        this.refObj.changeAddrClicked = false;
        this.refObj.isExactAddr = '';
        this.refObj.disableSaveAddr = true;
    }
    public setDefaultVal(proactiveName) {
        if (proactiveName === 'bill') {
            this.refObj.billingChk ? this.billingOptionValidation() : this.refObj.billingOption = this.refObj.billingOptions[3];
        }
        if (proactiveName === 'order') {
            this.refObj.orderChk ? this.billingOptionValidation() : this.refObj.orderOption = this.refObj.billingOptions[3];
        }
        if (proactiveName === 'repair') {
            this.refObj.repairChk ? this.billingOptionValidation() : this.refObj.repairOption = this.refObj.billingOptions[3];
        }
    }

    /** OnFocusOut from ssn field */
    public handleBlurSsn() {
        this.personalDet.ssn === 'xxx-xx-xxxx' ? this.refObj.enteredSsn = true : this.refObj.enteredSsn = false;
        const ssnNumber = this.accountForm.get("ssnNumber").value;
        const ssnArr = ssnNumber.match(/\d/g);
        const ssnReplacedNumber = ssnNumber.replace(new RegExp('-', 'g'), '');
        if (ssnArr && ssnArr.length === 9) {
            if (ssnArr && ssnReplacedNumber !== '000000000' && ssnReplacedNumber.match(/^(\d)(?!\1+$)\d{8}$/) && !ssnReplacedNumber.match(/^0*1*2*3*4*5*6*7*8*9*$/) || (ssnArr && ssnReplacedNumber === '999999999')) {
                this.refObj.enteredSsn = true;
                this.personalDet.ssn = ssnArr.join('');
                this.ssnfield.nativeElement.value = 'xxx-xx-' + this.personalDet.ssn.substr(this.personalDet.ssn.length - 4);
            }
        } else {
            if (ssnNumber !== 'xxx-xx-xxxx') {
                this.refObj.enteredSsn = false;
            }
        }
    }

    public ssnKeyUp(event) {
        const p = event.target.value;
        if (p.indexOf('x') !== -1) {
            this.ssnfield.nativeElement.value = '';
        }
    }

    public showDL(show: boolean) {
        this.showDriverLicense = show;
    }

    public isFNPeriodsEntered() {
        let isFirstnameField = false;
        if (this.accountForm.value.firstName.indexOf('.') !== -1) {
            isFirstnameField = true;
        }
        return isFirstnameField;
    }

    public isLNPeriodsEntered() {
        let isLasttnameField = false;
        if (this.accountForm.value.lastName.indexOf('.') !== -1) {
            isLasttnameField = true;
        }
        return isLasttnameField;
    }

    public handleBlurDL() {
        this.personalDet.dLlicenseState = this.accountForm.get("dLlicenseState").value;
        const dlNumber = this.accountForm.get("dlNumber").value;
        const dlReplacedNumber = dlNumber.replace(new RegExp('-', 'g'), '');
        if (dlNumber && dlNumber.length >= 7 && dlNumber.length <= 20 && !dlReplacedNumber.match(/^0*1*2*3*4*5*6*7*8*9*$/) && !dlReplacedNumber.match(/^9*8*7*6*5*4*3*2*1*0*$/)) {
            this.refObj.enteredDL = true;
            this.personalDet.dLlicenseNo = dlNumber;
        } else {
            this.refObj.enteredDL = false;
            return;
        }
        this.checkEnteredDL();
    }
    /**
     * check whether DL licenseNo and state having value or not and vise versa
    */
    public checkEnteredDL() {
        if (this.personalDet &&
            ((this.personalDet.dLlicenseNo !== null && this.personalDet.dLlicenseState === null) ||
                (this.personalDet.dLlicenseNo !== '' && this.personalDet.dLlicenseState === ''))) {
            this.refObj.enteredDL = false;
            return;
        } else {
            this.refObj.enteredDL = true;
        }
    }

    public onKeyUpAccountPassword() {
        this.accountPasswordPin = true;
        this.store.dispatch({ type: 'ACCOUNTPASSWORD_PIN', payload: this.accountPasswordPin });
        const inValidAccPassword = Validations.accountPasswordValidator({ value: this.accRespObj.accountPassword });
        if (!inValidAccPassword) {
            this.refObj.isValidAccPassword = true;
        } else {
            this.refObj.isValidAccPassword = false;
        }
    }

    /** Function to get Credit information */
    public getCreditInformation() {
        if (!this.isPrepaid) {
            if ((this.refObj.submitted && !this.refObj.enteredSsn && this.accountForm.controls.ssnNumber.invalid) || !this.refObj.enteredSsn) {
                return;
            }
            if (this.personalDet && this.personalDet.ssn && this.personalDet.ssn !== null && this.personalDet.ssn !== '') {
                this.refObj.enteredSsn = true;
            } else {
                this.refObj.enteredSsn = false;
            }
        }
        this.loading = true;
        this.checkEnteredDL();
        if ((this.refObj.isEmailValid || ((this.contactDet && this.contactDet.emailAddrDeclined) && this.refObj.billingOpt !== 'paperless')) &&
            this.refObj.dobEntered && this.refObj.isValidDob &&
            (this.isPrepaid ? true : this.refObj.enteredSsn) &&
            (this.isPrepaid ? true : this.personalDet.creditCheck !== null) &&
            this.refObj.isValidAccPassword) {
            this.refObj.billingOption.name.indexOf('Email') !== -1 ?
                this.accountObj.accountPreferences.emailNotification.billingNotification = true :
                this.accountObj.accountPreferences.emailNotification.billingNotification = false;

            this.refObj.billingOption.name.indexOf('SMS') !== -1 ?
                this.accountObj.accountPreferences.textNotification.billingNotification = true :
                this.accountObj.accountPreferences.textNotification.billingNotification = false;

            this.refObj.orderOption.name.indexOf('Email') !== -1 ?
                this.accountObj.accountPreferences.emailNotification.orderingNotification = true :
                this.accountObj.accountPreferences.emailNotification.orderingNotification = false;

            this.refObj.orderOption.name.indexOf('SMS') !== -1 ?
                this.accountObj.accountPreferences.textNotification.orderingNotification = true :
                this.accountObj.accountPreferences.textNotification.orderingNotification = false;

            this.refObj.repairOption.name.indexOf('Email') !== -1 ?
                this.accountObj.accountPreferences.emailNotification.repairNotification = true :
                this.accountObj.accountPreferences.emailNotification.repairNotification = false;

            this.refObj.repairOption.name.indexOf('SMS') !== -1 ?
                this.accountObj.accountPreferences.textNotification.repairNotification = true :
                this.accountObj.accountPreferences.textNotification.repairNotification = false;

            this.accRespObj.accountName.firstName = this.accountForm.value.firstName;
            this.accRespObj.accountName.lastName = this.accountForm.value.lastName;
            this.accRespObj.accountName.middleName = this.accountForm.value.middleName;
            this.accRespObj.accountName.title = '';
            this.accRespObj.contact.contactNumber = this.accountForm.value.contactNumber;
            //this.accRespObj.contact.smsNumber = this.accountForm.value.smsNumber;
            this.accRespObj.contact.smsNumber = this.autoLoginPhoneNumber;
            this.accRespObj.contact.emailAddress = this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress;
            this.accountObj.accountPreferences.paperlessBilling = false;
            this.accountObj.accountPreferences.braille = false;
            this.accountObj.accountPreferences.spanishBillPrint = false;
            this.accountObj.accountPreferences.largePrint = false;
            //this.accRespObj.contact.emailAddrDeclined = this.accountForm.value.emailAddrDeclined;
            if (this.accountForm && this.accountForm.value && this.accountForm.value.emailAddrDeclined === true) {
                this.accRespObj.contact.emailAddrDeclined = true;
                this.accRespObj.contact.emailAddress = "";
            }

            switch (this.refObj.billingOpt) {
                case 'paperless':
                    this.accountObj.accountPreferences.paperlessBilling = true;
                    break;
                case 'braille':
                    this.accountObj.accountPreferences.braille = true;
                    break;
                case 'spanish':
                    this.accountObj.accountPreferences.spanishBillPrint = true;
                    break;
                case 'large':
                    this.accountObj.accountPreferences.largePrint = true;
                    break;
                default: break;
            }
            this.accRespObj.accountType = 'I';
            this.accRespObj.accountSubType = 'R';
            const cont = this.accRespObj.contact.contactNumber;
            if (cont) {
                this.accRespObj.contact.contactNumber = cont.match(/\d/g).join('');
            }
            const sms = this.accRespObj.contact.smsNumber;
            if (sms) {
                this.accRespObj.contact.smsNumber = sms.match(/\d/g).join('');
            }
            this.accRespObj = Object.assign({},
                this.accRespObj, {
                creditClass: this.accRespObj.creditClass !== null ? this.accRespObj.creditClass : '3'
            });
            this.accRespObj.billingAdditionalInfo = this.refObj.addrCareOf;
            if (this.refObj.addrTypeSelected === 'International') {
                this.accRespObj.billingAddressType = 'F';
            } else if (this.refObj.addrTypeSelected === 'Street Address') {
                this.accRespObj.billingAddressType = 'S';
            } else if (this.refObj.addrTypeSelected === 'P.O. Box') {
                this.accRespObj.billingAddressType = 'P';
            } else if (this.refObj.addrTypeSelected === 'Rural Route') {
                this.accRespObj.billingAddressType = 'R';
            } else if (this.refObj.addrTypeSelected === 'Military') {
                this.accRespObj.billingAddressType = 'M';
            }

            if (this.accRespObj && this.accRespObj.personalDetails && this.accRespObj.personalDetails !== undefined && this.accRespObj.personalDetails.dateOfBirth === null) {
                this.accRespObj.personalDetails.dateOfBirth = this.accInformation && this.accInformation.personaldetails && this.accInformation.personaldetails.dateOfBirth;
            }
            let reqobj: any = {
                orderRefNumber: this.accountObj.orderRefNumber,
                processInstanceId: this.accountObj.processInstanceId
            };
            if (this.refObj.updateAppClicked) {
                reqobj.taskId = this.reEntrant ? this.taskId : this.creditReviewResp.taskId;
                reqobj.taskName = this.creditReviewResp.taskName;
                reqobj.payload = {
                    creditReviewAction: this.enumActions.UPDATE_APPLN,
                    accountName: this.accRespObj.accountName,
                    personalDetails: this.accRespObj.personalDetails,
                    addlOrderAttributes: this.creditReviewResp.payload.addlOrderAttributes
                };
            }

            else if (!this.refObj.updateAppclicked) {
                reqobj.taskId = this.reEntrant ? this.creditReviewResp.taskId : this.accountObj.taskId;
                if (this.accountObj.taskName === 'Account Information' && !this.reEntrant) {
                    reqobj.taskName = 'Account Information',
                        reqobj.payload = this.accRespObj;
                }
                else {
                    reqobj.taskName = this.creditReviewResp.taskName;
                    reqobj.payload = {
                        creditReviewAction: this.enumActions.SHOW_SUMMARY,
                        accountInfo: this.accRespObj,
                        addlOrderAttributes: this.otcUpdated ? this.otcUpdated : this.otcData1
                    };
                }
            }

            if (this.onHoldCreditReviewOrderRefNo && this.onHoldProcessInstanceId && this.isOnHoldFlow) {
                reqobj = Object.assign({}, ...reqobj, {
                    orderRefNumber: this.onHoldCreditReviewOrderRefNo,
                    processInstanceId: this.onHoldProcessInstanceId
                });
            }

            if (this.isOnHoldFlow) {
                reqobj.payload = { ...reqobj.payload, addlOrderAttributes: this.otcUpdated ? this.otcUpdated : this.addlOrderAttributesDepositData };
            }
            this.store.dispatch({ type: 'BILLING_ADDR', payload: this.accRespObj.billingAddress });
            this.store.dispatch({ type: 'ACCOUNT_PREFERENCES_DETAILS', payload: this.accRespObj.accountPreferences });
            this.store.dispatch({ type: 'CONTACT_DETAILS', payload: this.accRespObj.contact });
            this.store.dispatch({ type: 'PERSONAL_DETAILS', payload: this.accRespObj.personalDetails });
            this.userdata = this.store.select('user');
            this.userSubscription$ = this.userdata.subscribe(
                (userdata) => {
                    reqobj.taskId = userdata.taskId;
                });
            if (reqobj.payload && reqobj.payload.personalDetails && reqobj.payload.personalDetails.creditCheck && reqobj.payload.personalDetails.creditCheck === 'bypassCreditCheck') {
                reqobj.payload.personalDetails.creditCheck = false;
                this.bypassCreditCheckSelected = true;
                const bypassCreditCheckOrderAttr = {
                    "orderAttributeGroupName": "bypassCreditCheck",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "creditCheckBypassed",
                                    "orderAttributeValue": "true"
                                }
                            ]
                        }
                    ]
                };
                if (reqobj.payload && Array.isArray(reqobj.payload.addlOrderAttributes) && reqobj.payload.addlOrderAttributes[0].orderAttributeGroup && Array.isArray(reqobj.payload.addlOrderAttributes[0].orderAttributeGroup)) {
                    reqobj.payload.addlOrderAttributes[0].orderAttributeGroup.push(bypassCreditCheckOrderAttr);
                }

            } else {
                this.bypassCreditCheckSelected = false;
            }
            this.changeResponsibility(reqobj);
            this.authorizedContact(reqobj, this.authUsers);
            this.accountInfoAfterDoneCredit = reqobj;
            if (!this.reentrantCreditCheckdone || this.updateAppilicationSelected) {
                this.accountService.getAccountData(this.accountForm.value);

                let errorResolved = false;
                this.logger.log("info", "account.component.ts", "creditInfoRequest", JSON.stringify(reqobj));
                this.logger.startTime();
                this.accountService.getCreditResponse(reqobj, this.currentFlow)
                    .catch((error: any) => {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                        this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        errorResolved = true;
                        this.loading = false;
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error", 'Not Applicable',
                            "submitTask - getCreditResponse", "account.component.ts", "Account Page",
                            error);
                        return Observable.throwError(null);
                    })
                    .subscribe(
                        (respData) => {
                            this.logger.endTime();
                            this.logger.log("info", "account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                            this.logger.log("info", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            if (respData && respData.payload && respData.payload.creditCheckErrorResp && respData.payload.creditCheckErrorResp !== undefined && respData.payload.creditCheckErrorResp.reasonCode === "202") {
                                this.loading = false;
                                const errorResponseArray: ErrorResponse[] = [];
                                const localErrorResponse: ErrorResponse = {
                                    orderRefNumber: respData.orderRefNumber,
                                    statusCode: respData.payload.creditCheckErrorResp.reasonCode,
                                    reasonCode: respData.payload.creditCheckErrorResp.reasonCode,
                                    message: respData.payload.creditCheckErrorResp.message,
                                    messageDetail: respData.payload.creditCheckErrorResp.messageDetail
                                };
                                errorResponseArray.unshift(localErrorResponse);
                                const lAPIErrorLists: APIErrorLists = {
                                    errorResponse: errorResponseArray
                                };
                                this.systemErrorService.logAndeRouteToSystemError("error", "submitTask - getCreditResponse", "account.component.ts", "creditInfoResponse", lAPIErrorLists);
                                this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                                this.store.dispatch({ type: 'TASK_NAME', payload: respData.taskName });
                            } else {
                                this.logger.endTime();
                                this.logger.log("info", "account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                                this.logger.log("info", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                                this.loading = false;
                                this.apiResponseError = null;
                                this.creditObj = respData.payload;
                                if (this.isPrepaid) { this.calculateChargesForPrepaid(); }
                                this.isCreditChecked = true;
                                this.creditCheckDone = true;
                                this.creditReviewResp = this.udpateServiceGroup(respData);
                                if (respData.payload && this.bypassCreditCheckSelected) {
                                    respData.payload['bypassCreditCheckSelected'] = true;
                                }
                                this.store.dispatch({ type: 'CREDIT_REVIEW', payload: respData });
                                this.creditResponse = respData;
                                this.taskId = respData.taskId;
                                this.isPrepaid ? this.initCreditPrepaidInfo() : this.initCreditInfo();
                                this.refObj.gotCreditResponse = true;
                                this.taskId = respData.taskId;
                                this.refObj.userData.taskId = respData.taskId;
                                this.store.dispatch({ type: 'BAN', payload: respData.payload.accountInfo.ban });
                                this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                                this.store.dispatch({ type: 'TASK_NAME', payload: respData.taskName });
                                this.store.dispatch({ type: 'CREDIT_DATA_RETAIN', payload: this.refObj });
                                this.store.dispatch({ type: 'CREDIT_DATA_RETAIN_SSN', payload: this.accountForm.get("ssnNumber").value });
                                if (this.creditObj && this.creditObj.accountInfo && this.creditObj.accountInfo.personalDetails && this.creditObj.accountInfo.personalDetails.creditCheck) {
                                    this.creditCheckStatusFromAccountInfo = true;
                                }
                                this.validateCreditModal.close(true);
                                this.maxCreditCheckReached = respData && respData.payload && respData.payload.maxCreditCheckReached;
                                this.store.dispatch({ type: 'UPDATE_APPLICATION_COUNT', payload: this.maxCreditCheckReached });
                            }
                        },
                        (error) => {
                            if (!errorResolved) {
                                this.logger.endTime();
                                this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                                this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            }
                            this.loading = false;
                            if (error === undefined || error === null || errorResolved) { return; }
                            let unexpectedError = false;
                            if (this.ctlHelperService.isJson(error)) {
                                this.apiResponseError = JSON.parse(error);
                                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                    this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                    this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                                } else {
                                    unexpectedError = true;
                                }
                            }
                            else {
                                unexpectedError = true;
                            }
                            if (unexpectedError) {
                                const errorResponseCustom: ErrorResponse = {
                                    statusCode: serverErrorMessages.statusCode,
                                    message: serverErrorMessages.serverDown
                                };
                                if (this.apiResponseError) {
                                    this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                                    this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                                }
                            }
                        });
            }
        } else {
            this.loading = false;
            this.displayEmailMandatoryAlert();
        }
        this.refObj.submitted = true;
    }

    public validateCreditModalFn() {
        this.store.dispatch({
            type: 'UPDATE_USER_FROM_ACCOUNT_PAGE', payload: {
                firstName: this.accountForm.value.firstName,
                lastName: this.accountForm.value.lastName,
                phoneNumber: this.accountForm.value.contactNumber,
                smsNumber: this.accountForm && this.accountForm.value && this.accountForm.value.smsNumber,
                emailAddress: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress,
                emailAddrDeclined: this.contactDet && this.contactDet.emailAddrDeclined
            }
        });
        if (!this.isPrepaid) {
            if ((this.refObj.submitted && !this.refObj.enteredSsn && this.accountForm.controls.ssnNumber.invalid) || !this.refObj.enteredSsn) {
                return;
            }
            if (this.personalDet && this.personalDet.ssn && this.personalDet.ssn !== null && this.personalDet.ssn !== '') {
                this.refObj.enteredSsn = true;
            } else {
                this.refObj.enteredSsn = false;
            }
            this.checkEnteredDL();
            const inValidAccPassword = Validations.accountPasswordValidator({ value: this.accRespObj.accountPassword });
            if (!inValidAccPassword) {
                this.store.dispatch({ type: 'ACCT_PASSWORD', payload: this.accRespObj.accountPassword });
            } else {
                this.accRespObj.accountPassword = null;
                this.store.dispatch({ type: 'ACCT_PASSWORD', payload: this.accRespObj.accountPassword });
            }
            this.refObj.submitted = true;
            this.disabledContinue();
            if (this.refObj.submitted && !this.postalAddressValidated) {
                this.addressNotValidatedMsg = 'Looks like the address needs to be validated.';
                return;
            }
            if ((this.refObj.isEmailValid || ((this.contactDet && this.contactDet.emailAddrDeclined) && this.refObj.billingOpt !== 'paperless')) &&
                this.refObj.dobEntered && this.refObj.enteredSsn && this.personalDet.creditCheck !== null && this.refObj.isValidAccPassword && this.refObj.enteredDL && this.postalAddressValidated && !this.refObj.underAge && !this.accountForm.controls.firstName.invalid && !this.accountForm.controls.lastName.invalid) {
                this.store.dispatch({ type: 'CALLER_DOB_AND_SSN', payload: { dob: String(this.refObj.month) + '/' + String(this.refObj.day) + '/' + String(this.refObj.year), ssn: this.personalDet.ssn, dLlicenseNo: this.personalDet.dLlicenseNo, dLlicenseState: this.personalDet.dLlicenseState } });
                this.validateCreditModal.open();
            } else {
                this.displayEmailMandatoryAlert();
            }
        } else if (this.isPrepaid) {
            if (!this.isUnameValid) {
                this.displayEmailMandatoryAlert(); // this will take the scroll bar the error section
            } else {
                this.getCreditInformation();
            }

        }
        this.refObj.submitted = true;
        if (this.refObj.submitted && !this.postalAddressValidated) {
            this.addressNotValidatedMsg = 'Looks like the address needs to be validated.';
            return;
        }
    }

    /** If email not provided & not declined email, on submit
     * display error message & scroll to email part of the page
     */
    public creditCheckClose(value) {
        if (value) {
            this.refObj.submitted = false;
        }
    }
    public displayEmailMandatoryAlert() {
        if ((this.isPrepaid && this.isUnameValid) || (!this.refObj.isEmailValid && !(this.contactDet && this.contactDet.emailAddrDeclined)) || ((this.contactDet && this.contactDet.emailAddrDeclined) && this.refObj.billingOpt === 'paperless')) {
            window.scroll(0, 200);
        }
    }

    public displayPasswordMandatoryAlert() {
        if (!this.refObj.isValidAccPassword) {
            window.scroll(0, 500);
        }
    }

    public showOption(installmentOptions) {
        if (installmentOptions && installmentOptions.noOfInstallments > 1) {
            return true;
        } else {
            return false;
        }
    }

    public isOTCAvail = false;

    /** Initialize credit check variables after getting credit response */
    public initCreditInfo() {
        this.creditDepositInfo = this.creditObj.depositInfo;
        this.otcData1 = this.creditObj.addlOrderAttributes;
        this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup && this.otcData1[0].orderAttributeGroup.map((group) => {
            if (group.orderAttributeGroupName === 'otcInstallmentInfo') {
                this.isOTCAvail = true;
            }
        });
        this.otcDataResponse = cloneDeep(this.otcData1);
        this.userPaidObj = this.creditObj.paymentDetails;
        this.products = [];
        this.refObj.pastDueAccs = [];
        this.store.dispatch({ type: 'CC_DONE', payload: true });
        if (this.creditDepositInfo !== undefined && this.creditDepositInfo.products && this.creditDepositInfo.products.length > 0) {
            this.products = this.creditDepositInfo.products;
            if (this.userPaidObj.depositPaymentStatus === 'PAID') {
                this.refObj.isPaymentSuccess = true;
                if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                    const paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                    this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
                } else {
                    this.refObj.depositPaidDate = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
                }
                this.refObj.disableDepositBtn = true;
                this.refObj.paymentStatus = 'success';
            } else {
                this.refObj.depositPaidDate = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            }
        } else {
            this.refObj.isPaymentSuccess = true;
        }
        this.creditInfo = this.creditObj.creditInfo;
        if (this.creditInfo !== undefined && this.creditInfo.finalBillInfo && this.creditInfo.finalBillInfo.length > 0) {
            this.refObj.pastDueAccs = this.creditInfo.finalBillInfo;
            this.totalPastDueAmount = this.ctlHelperService.getTotalPastDueAmount(this.creditInfo.finalBillInfo);
            this.pastDueAmountBTNs = this.ctlHelperService.getBTNsArray(this.creditInfo.finalBillInfo);
            if (this.userPaidObj.finalBillPaymentStatus === 'PAID') {
                this.refObj.isPaymentSuccessPD = true;
                if (this.userPaidObj.finalBillPaymentDate !== null && this.userPaidObj.finalBillPaymentDate !== '') {
                    const paidDate = this.userPaidObj.finalBillPaymentDate.split(' ')[0].split('-');
                    this.refObj.paidDatePD = paidDate[1] + '/' + paidDate[2];
                } else {
                    this.refObj.paidDatePD = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
                }
                this.refObj.paymentStatusPD = 'success';
                this.refObj.disablePastDueBtn = true;
            }
        } else {
            this.refObj.isPaymentSuccessPD = true;
        }
        const laccRespObjPostCode = this.accRespObj.billingAddress.postCode && this.accRespObj.billingAddress.postCodeSuffix !== undefined && this.accRespObj.billingAddress.postCodeSuffix !== '' ? this.accRespObj.billingAddress.postCode + ' - ' + this.accRespObj.billingAddress.postCodeSuffix : this.accRespObj.billingAddress.postCode;
        const addr = `${this.accRespObj.billingAddress.streetAddress}, ${this.accRespObj.billingAddress.city}, ${this.accRespObj.billingAddress.stateOrProvince}, ${laccRespObjPostCode} ${this.accRespObj.billingAddress.country}`;
        this.payobj = {
            name: this.accRespObj.accountName.firstName + ' ' +
                this.accRespObj.accountName.lastName,
            contactNumber: this.contactDet.contactNumber, address: addr,
            paymentheader: 'Advance payment required'
        };
        this.calculateTotalDeposit();
    }

    /** Prepaid Initialize credit check variables after getting credit response */
    public initCreditPrepaidInfo() {
        if(this.creditObj === undefined || this.creditObj === null) return false;
        this.prepaidAcctNumber = this.creditObj.currentBillQuote && this.creditObj.currentBillQuote.accountId;
        this.userPaidObj = this.creditObj.paymentDetails;
        this.store.dispatch({ type: 'CC_DONE', payload: true });
        if (this.userPaidObj.depositPaymentStatus === 'PAID') {
            this.refObj.isPaymentSuccess = true;
            if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                const paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
            } else {
                this.refObj.depositPaidDate = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            }
            this.refObj.disableDepositBtn = true;
            this.refObj.paymentStatus = 'success';
            this.refObj.isPrepaidPaymentSuccess = true;
        } else if (this.userPaidObj.finalBillPaymentStatus === 'PAID') {
            this.refObj.isPaymentSuccess = true;
            if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                const paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
            } else {
                this.refObj.paidDatePD = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            }
            this.refObj.disablePrepaidbtn = true;
            this.refObj.prepaidPaymentStatus = 'success';
            this.refObj.isPrepaidPaymentSuccess = true;
        } else {
            this.creditObj && this.creditObj.paymentInfo && this.creditObj.paymentInfo.map((payment) => {
                if (payment.paymentTypeCode === 'P' && payment.paymentStatusCd === 'S') {
                    this.refObj.disablePrepaidbtn = true;
                    this.refObj.prepaidPaymentStatus = 'success';
                    this.refObj.isPrepaidPaymentSuccess = true;
                    this.refObj.isPaymentSuccess = true;
                    const paidDate = payment.depositPayDate.split(' ')[0].split('-');
                    this.refObj.paidDatePD = paidDate[1] + '/' + paidDate[2];
                }
            });
        }
        if (this.creditObj.pastDueAmount && this.creditObj.pastDueAmount.finalBillInfo && this.creditObj.pastDueAmount.finalBillInfo.length > 0) {
            this.creditObj.pastDueAmount.finalBillInfo[0] && this.creditObj.pastDueAmount.finalBillInfo[0].paymentRequiredInd ?
                this.pastDueAmountExist = true : this.pastDueAmountExist = false;
            this.refObj.totalDepositAmount = this.creditObj.pastDueAmount.finalBillInfo[0].finalBillAmt.amount;
            this.finalBillforPostPaid = this.creditObj.pastDueAmount.finalBillInfo[0];
        }
        const laccRespObjPostCode = this.accRespObj.billingAddress.postCode && this.accRespObj.billingAddress.postCodeSuffix !== undefined && this.accRespObj.billingAddress.postCodeSuffix !== '' ? this.accRespObj.billingAddress.postCode + ' - ' + this.accRespObj.billingAddress.postCodeSuffix : this.accRespObj.billingAddress.postCode;
        const addr = `${this.accRespObj.billingAddress.streetAddress}, ${this.accRespObj.billingAddress.city}, ${this.accRespObj.billingAddress.stateOrProvince}, ${laccRespObjPostCode} ${this.accRespObj.billingAddress.country}`;
        this.payobj = {
            name: this.accRespObj.accountName.firstName + ' ' +
                this.accRespObj.accountName.lastName,
            contactNumber: this.contactDet.contactNumber, address: addr
        };
    }

    private calculateChargesForPrepaid() {
        this.firstMonthMRC = [];
        this.firstMonthOTC = [];
        this.firstMonthOTCTotal = 0;
        this.firstMonthMRCTotal = 0;
        this.mrcTaxes = 0;
        this.otcTaxes = 0;
        this.creditObj && this.creditObj.currentBillQuote && this.creditObj.currentBillQuote.firstMonthList &&
            this.creditObj.currentBillQuote.firstMonthList.offerDetails && this.creditObj.currentBillQuote.firstMonthList.offerDetails.map((offer) => {
                if (!offer.otc) {
                    const x = {
                        "offerName": offer.offerName,
                        "offerPrice": offer.offerPrice
                    };
                    this.firstMonthMRCTotal += offer.offerPrice + offer.tax;
                    this.mrcTaxes += offer.tax;
                    this.firstMonthMRC.push(x);
                    this.getDiscountObj(offer.specialDiscountsList, this.firstMonthMRC, (total) => { this.firstMonthMRCTotal += total; });

                } else {
                    const x = {
                        "offerName": offer.offerName,
                        "offerPrice": offer.offerPrice
                    };
                    this.firstMonthOTCTotal += offer.offerPrice + offer.tax;
                    this.otcTaxes += offer.tax;
                    this.firstMonthOTC.push(x);
                    this.getDiscountObj(offer.specialDiscountsList, this.firstMonthOTC, (total) => { this.firstMonthOTCTotal += total; });

                }
            });
        if (this.creditObj && this.creditObj.currentBillQuote && this.creditObj.currentBillQuote.firstMonthList && this.creditObj.currentBillQuote.firstMonthList.totalCharges) {
            this.prepaidFirstMonth = this.creditObj.currentBillQuote.firstMonthList;
            this.totalCharges = this.firstMonthMRCTotal;
        }
    }

    public getDiscountObj = (discountsList, list, CB) => {
        let total = 0;
        if (discountsList && discountsList.length) {
            discountsList.map(discounts => {
                if (discounts.specialDiscount && discounts.specialDiscount.length) {
                    discounts.specialDiscount.map(discount => {
                        if (list.length) {
                            list.push({
                                "offerName": discount.discountReason,
                                "offerPrice": -discount.discountAmount
                            });
                            total -= discount.discountAmount;
                        }
                    });
                }
            });
            if (CB) { CB(total); }
        }
    }
    /** Function to Calulate age */
    public getAge() {
        this.refObj.isValidDob = true;
        if (this.refObj.month && this.refObj.day && this.refObj.year) {
            const isDobValid = Validations
                .dobValidator(this.refObj.month, this.refObj.day, this.refObj.year);
            if (!isDobValid) {
                const today = new Date();
                const birthDate = new Date(String(this.refObj.month) + '/' + String(this.refObj.day)
                    + '/' + String(this.refObj.year));
                let age = today.getFullYear() - birthDate.getFullYear();
                const m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                age < 18 ? this.refObj.underAge = true : this.refObj.underAge = false;
                this.personalDet.dateOfBirth = String(this.refObj.year) + '-' + String(this.refObj.month) +
                    '-' + String(this.refObj.day);
                this.refObj.dobEntered = true;
                this.personalDet.underAgeAck = false;
                this.refObj.isValidDob = true;
            } else {
                this.refObj.isValidDob = false;
                this.refObj.dobMessage = isDobValid.message;
            }
        } else if (this.refObj.month || this.refObj.day || this.refObj.year) {
            let isDobValid = Validations
                .dateofbirthValidation(this.refObj.month, this.refObj.day, this.refObj.year);
            if (isDobValid) {
                this.refObj.isValidDob = false;
                this.refObj.dobMessage = isDobValid.message;
            } else {
                this.refObj.isValidDob = true;
            }
        }
    }

    private prepareInstDepositReq(product: any) {
        if (product) {
            const arr = [
                { orderAttributeName: 'productType', orderAttributeValue: product.productType },
            ];
            for (const item of product.installmentOptions) {
                if (item.noOfInstallments === 1) {
                    arr.push({ orderAttributeName: 'totalDepositAmount', orderAttributeValue: item.paymentAmount });
                }
                if (item.paymentAmount === product.depositAmount.amount) {
                    arr.push({ orderAttributeName: 'selectedNoOfInstallment', orderAttributeValue: item.noOfInstallments });
                    arr.push({ orderAttributeName: 'installmentAmount', orderAttributeValue: item.paymentAmount });
                }
            }
            this.refObj.depositInstallmentObj.push({ orderAttributes: arr });
        }
    }

    /** On installment option selection calculate total deposit */
    public calculateTotalDeposit() {
        let tot = 0;
        this.refObj.depositInstallmentObj = [];
        for (const prd of this.products) {
            if ((!this.accountRentrantValue && !this.reEntrant) || ((this.accountRentrantValue || this.reEntrant) && !this.allProductsPaid && ((!this.hsiPaymentDone && prd.productType === 'INTERNET') || (!this.potsPaymentDone && prd.productType === 'VOICE-HP') || (!this.dhpPaymentDone && prd.productType === 'VOICE-DHP')) || this.allProductsPaid)) {
                tot += parseInt(prd.depositAmount.amount, 10);
                if (prd && prd.installmentOptions && prd.installmentOptions.length) {
                    this.prepareInstDepositReq(prd);
                }
            }
        }
        this.refObj.totalDepositAmount = tot;
        this.payobj.amount = tot;
    }

    public calculateTotalDepositForChange() {
        let tot = 0;
        if (this.accInformation && this.accInformation !== undefined && this.accInformation.payload && this.accInformation.payload !== undefined && this.accInformation.payload.depositInfo && this.accInformation.payload.depositInfo !== undefined && this.accInformation.payload.depositInfo.products && this.accInformation.payload.depositInfo.products !== undefined) {
            for (const prd of this.accInformation.payload.depositInfo.products) {
                tot += parseInt(prd.depositAmount.amount, 10);
            }
        }
        this.refObj.totalDepositAmount = tot;
        this.payobj.amount = tot;
    }

    /** Set content for deposit modal */
    public setModalDepositData(modalRef, urlObj) {
        this.visibleDeposit = true;
        this.refObj.disableDepositBtn = true;
        this.payobj.paymentStatement = 'Total Deposit Due Today';
        this.payobj.isDepositModal = true;
        this.payobj.amount = this.refObj.totalDepositAmount;
        this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(`${env.DEPOSIT_AND_FINAL_BILL_URL}` + urlObj.paymentURL + String(urlObj.sessionId));
        modalRef.open();
    }

    /** Set content for past due modal */
    public setModalBalanceData(balanceAccDet, modalRef, urlObj) {
        this.visibleBalance = true;
        this.refObj.disablePastDueBtn = true;
        this.payobj.paymentStatement = 'Total Payment Due Today';
        this.payobj.isDepositModal = false;
        this.payobj.acctNumber = balanceAccDet.btn;
        this.payobj.amount = balanceAccDet.finalBillAmt.amount;
        this.invokeCallPrepaid = 'Pay Due';
        this.payobj.paymentheader = 'Past Due Payment';
        this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(`${env.DEPOSIT_AND_FINAL_BILL_URL}` + urlObj.paymentURL + String(urlObj.sessionId));
        modalRef.open();
    }

    /** Set content for prepaid modal */
    public setModalPrepaidData(modalRef, urlObj) {
        this.visibleBalance = true;
        this.refObj.disablePrepaidbtn = true;
        this.payobj.paymentStatement = 'Initial Payment';
        this.payobj.isDepositModal = false;
        this.payobj.amount = this.firstMonthMRCTotal;
        this.payobj.acctNumber = this.prepaidAcctNumber;
        this.invokeCallPrepaid = 'Prepaid Pay';
        this.payobj.paymentheader = 'Initial Payment';
        this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(`${env.DEPOSIT_AND_FINAL_BILL_URL}` + urlObj.paymentURL + String(urlObj.sessionId));
        modalRef.open();
    }


    /**
     * Function to prepare deposit products request
    * @param paidDepositProd
     */
    public prepareDepositRequest() {
        const paymentObj: PaymentInfo = {
            sessionId: this.refObj.sessionId,
            paymentCategory: "DEPOSIT",
            paymentStatus: "SUCCESS",
            paymentErr: null
        };
        this.paymentReqObj.push(paymentObj);
    }

    /**
     * Function to prepare Past due account request
     * @param paidPastAccount
     */
    public preparePastDueRequest() {
        const paymentObj: PaymentInfo = {
            sessionId: this.refObj.sessionId,
            paymentCategory: "PASTDUE",
            paymentStatus: "SUCCESS",
            paymentErr: null
        };
        this.paymentReqObj.push(paymentObj);
    }

    public preparePrepaidPayRequest() {
        const paymentObj: PaymentInfo = {
            sessionId: this.refObj.sessionId,
            paymentCategory: "PAYINITIALBILL",
            paymentStatus: "SUCCESS",
            paymentErr: null
        };
        this.paymentReqObj.push(paymentObj);
    }

    public removeLater() {
        if (this.paymentReqObj.length === 0) {
            this.paymentReqObj = null;
        }
    }

    public retryGetPaymentDetails(depOrFBill, modalRef, dueObj, flow) {
        this.loading = true;
        this.retryButtonEnabled = true;
        const callbackURL = 'https://' + window.location.hostname + (window.location.port ? ":" + window.location.port : "") + '/';
        const reqObj: any = {
            orderRefNumber: this.creditReviewResp.orderRefNumber,
            processInstanceId: this.creditReviewResp.processInstanceId,
            taskId: this.refObj.userData.taskId,
            taskName: this.creditReviewResp.taskName,
            payload: {
                creditReviewAction: this.isPrepaid && depOrFBill !== 'DUE' ? this.enumActions.PAY_INITIAL_BILL : depOrFBill === 'DEPOSIT' ? this.enumActions.PAY_DEPOSIT : this.enumActions.PAY_FBILL,
                addlOrderAttributes: [{
                    orderAttributeGroup: [{
                        orderAttributeGroupName: 'paymentCallbackURL',
                        orderAttributeGroupInfo: [{
                            orderAttributes: [{
                                orderAttributeName: 'hostname',
                                orderAttributeValue: callbackURL
                            }]
                        }]
                    }]
                }]
            }
        };
        if (!this.isPrepaid) {
            const payloadAddtlObj = {
                'orderAttributeGroupName': 'depositCreated',
                'orderAttributeGroupInfo': [{
                    'orderAttributes':
                        [{
                            'orderAttributeName': 'depositCreatedInd',
                            'orderAttributeValue': flow === 'retry' ? true : false
                        }]
                }]
            };
            reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push(payloadAddtlObj);
        }
        if (depOrFBill === 'DEPOSIT') {
            if (this.refObj.depositInstallmentObj && this.refObj.depositInstallmentObj.length) {
                reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push({
                    'orderAttributeGroupName': 'depositInstallmentSelection',
                    'orderAttributeGroupInfo': this.refObj.depositInstallmentObj
                });
            }
            const payloadAddtlObj = {
                'orderAttributeGroupName': 'depositOnOrder',
                'orderAttributeGroupInfo': [
                    {
                        'orderAttributes': [
                            {
                                'orderAttributeName': 'depositDueToday',
                                'orderAttributeValue': this.refObj.totalDepositAmount
                            }
                        ]
                    }
                ]
            };
            reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push(payloadAddtlObj);
        }
        if (depOrFBill === 'PREPAID') {
            const payloadAddtlObj = {
                'orderAttributeGroupName': 'intialPayOnOrder',
                'orderAttributeGroupInfo': [
                    {
                        'orderAttributes': [
                            {
                                'orderAttributeName': 'intialPayDueToday',
                                'orderAttributeValue': this.firstMonthMRCTotal
                            }
                        ]
                    }
                ]
            };
            reqObj.payload.addlOrderAttributes[0].orderAttributeGroup.push(payloadAddtlObj);
        }

        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "creditInfoRequest", JSON.stringify(reqObj));
        this.logger.startTime();
        this.accountService.getCreditResponse(reqObj, this.currentFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                    this.logger.log("info", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.apiResponseError = null;
                    this.creditReviewResp.taskId = respData.taskId;
                    if (!this.creditObj.accountInfo.ban) { this.creditObj.accountInfo = respData.payload.accountInfo; }
                    this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
                    this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                    depOrFBill === 'DEPOSIT' ? this.setModalDepositData(modalRef, respData.payload.depositBillpaymentURL) :
                        depOrFBill === 'PREPAID' ? this.setModalPrepaidData(modalRef, respData.payload.initialBillpaymentURL) : this.setModalBalanceData(dueObj, modalRef, respData.payload.finalBillpaymentURL);
                    this.loading = false;
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                        this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "account.component.ts", "Account Page", this.apiResponseError);
                        } else {
                            unexpectedError = true;
                        }
                    } else {
                        unexpectedError = true;
                    }
                    if (unexpectedError) {
                        const errorResponseCustom: ErrorResponse = {
                            statusCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDown
                        };
                        if (this.apiResponseError && this.apiResponseError.errorResponse) {
                            this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                            this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                        }
                        const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "account.component.ts", "Account Page", lAPIErrorLists);
                    }
                });
    }

    public updatePaidDetails(paymentRespAttrs) {
        if (paymentRespAttrs.paymentStatus === 'success') {
            this.loading = true;
            this.allProductsPaid = true;
            this.paidSecurityDeposit = true;
            this.store.dispatch({ type: 'PAYMENT_STATUS', payload: true });
            if (this.allProductsPaid) {
                this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup.map((data) => {
                    if (data && data.orderAttributeGroupName === "depositData") {
                        data.orderAttributeGroupInfo && data.orderAttributeGroupInfo.map((addatrData) => {
                            addatrData && addatrData.orderAttributes && addatrData.orderAttributes.map((dat) => {
                                if (dat && dat.orderAttributeName === "depositPayStatus") {
                                    dat.orderAttributeValue = 'PAID';
                                }
                            });
                        });
                    }
                });
            }
            this.isPrepaid ? this.initCreditPrepaidInfo() : this.initCreditInfo();
            const reqObj: any = {
                orderRefNumber: this.creditReviewResp.orderRefNumber,
                processInstanceId: this.creditReviewResp.processInstanceId,
                taskId: this.creditReviewResp.taskId,
                taskName: 'Payments',
                payload: {
                    paymentStatus: [{
                        sessionId: paymentRespAttrs.sessionId,
                        paymentCategory: paymentRespAttrs.invokeCall === 'Pay Deposit' ? 'DEPOSIT' : paymentRespAttrs.invokeCall === 'Prepaid Pay' ? 'PAYINITIALBILL' : 'PASTDUE',
                        paymentStatus: paymentRespAttrs.error === 'success' ? 'SUCCESS' : 'FAIL',
                        paymentErr: [{
                            errorCode: '',
                            errorDesc: ''
                        }]
                    }]
                }
            };

            let errorResolved = false;
            this.logger.log("info", "account.component.ts", "creditInfoRequest", JSON.stringify(reqObj));
            this.logger.startTime();
            this.accountService.getCreditResponse(reqObj, this.currentFlow)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                    this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    errorResolved = true;
                    this.ctlHelperService.setLocalStorage('error', error);
                    this.loading = false;
                    return Observable.throwError(null);
                })
                .subscribe(
                    (respData) => {
                        this.logger.endTime();
                        this.logger.log("info", "account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                        this.logger.log("info", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        this.apiResponseError = null;
                        //paymentDetails update                    
                        this.creditReviewResp.paymentDetails = respData.payload.paymentDetails;
                        if (!this.creditObj.accountInfo.ban) { this.creditObj.accountInfo = respData.payload.accountInfo; }
                        this.ban = this.creditObj.accountInfo.ban;
                        this.creditReviewResp.taskId = respData.taskId;
                        this.refObj.userData.taskId = respData.taskId;
                        this.creditReviewResp.taskName = respData.taskName;
                        this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                        this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
                        this.loading = false;
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                            this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        this.isPaymentsError = true;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "account.component.ts", "Account Page", this.apiResponseError);
                                this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            } else {
                                unexpectedError = true;
                            }
                        } else {
                            unexpectedError = true;
                        }
                        if (unexpectedError) {
                            const errorResponseCustom: ErrorResponse = {
                                statusCode: serverErrorMessages.statusCode,
                                message: serverErrorMessages.serverDown
                            };
                            if (this.apiResponseError && this.apiResponseError.errorResponse) {
                                this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                                this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            }
                            const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "account.component.ts", "Account Page", lAPIErrorLists);
                        }
                    });
        }
        this.refObj.paidDepOrPD = paymentRespAttrs.invokeCall;
        if (this.refObj.paidDepOrPD === 'Pay Deposit') {
            if (paymentRespAttrs.error === 'success') {
                this.apiResponseError = null;
                this.paymentDone = true;
                this.userPaidObj.depositPaymentStatus = 'PAID';
                this.store.dispatch({ type: 'FREEZEPAGE', payload: true });
                this.refObj.isPaymentSuccess = true;
                this.refObj.displayPaidDeposit = true;
                this.refObj.paymentFailed = false;
                this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.depositPaidDate = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled' || paymentRespAttrs.error === 'CANCELLED') {
                this.refObj.isPaymentSuccess = false;
                this.refObj.displayPaidDeposit = true;
                this.refObj.paymentFailed = false;
                this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.depositPaidDate = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            } else {
                this.refObj.isPaymentSuccess = false;
                this.refObj.paymentFailed = true;
                this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
                paymentRespAttrs.isDepositCallback ?
                    this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
            }
            this.prepareDepositRequest();
        } else if (this.refObj.paidDepOrPD === 'Prepaid Pay') {
            if (paymentRespAttrs.error === 'success') {
                this.apiResponseError = null;
                this.refObj.isPrepaidPaymentSuccess = true;
                this.refObj.displayPaidPrepaid = true;
                this.refObj.paymentFailedPrepaid = false;
                this.userPaidObj.finalBillPaymentStatus = 'PAID';
                this.refObj.prepaidPaymentStatus = paymentRespAttrs.paymentStatus;
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.paidDatePD = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled' || paymentRespAttrs.error === 'CANCELLED') {
                this.refObj.isPrepaidPaymentSuccess = false;
                this.refObj.paymentFailedPrepaid = false;
                this.refObj.prepaidPaymentStatus = paymentRespAttrs.paymentStatus;
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.paidDatePD = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            } else {
                this.refObj.isPrepaidPaymentSuccess = false;
                this.refObj.paymentFailedPrepaid = true;
                this.refObj.prepaidPaymentStatus = paymentRespAttrs.paymentStatus;
                paymentRespAttrs.isDepositCallback ?
                    this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
            }
            this.preparePrepaidPayRequest();
        } else {
            if (paymentRespAttrs.error === 'success') {
                this.apiResponseError = null;
                this.refObj.isPaymentSuccessPD = true;
                this.refObj.displayPaidPD = true;
                this.refObj.paymentFailedPD = false;
                this.userPaidObj.finalBillPaymentStatus = 'PAID';
                this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.paidDatePD = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled' || paymentRespAttrs.error === 'CANCELLED') {
                this.refObj.isPaymentSuccessPD = false;
                this.refObj.paymentFailedPD = false;
                this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
                this.refObj.sessionId = paymentRespAttrs.sessionId;
                this.refObj.paidDatePD = String(this.currDate.getMonth() + 1) + '/' + String(this.currDate.getDate());
            } else {
                this.refObj.isPaymentSuccessPD = false;
                this.refObj.paymentFailedPD = true;
                this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
                paymentRespAttrs.isDepositCallback ?
                    this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
            }
            this.preparePastDueRequest();
        }
    }

    public bmOrderProcess(requestObj, isChangeFlow, requestObject) {
        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "reviewOrderRequest", JSON.stringify(requestObject));
        this.logger.startTime();
        this.reviewOrderService.postSubmitTaskService(requestObj, this.currentFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "reviewOrderResponse", error);
                this.logger.log("error", "account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "reviewOrderResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    const response = data;
                    if (response) {
                        this.apiResponseError = null;
                        // placeholder for store saving, pull from previous page through store object
                        this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                        this.store.dispatch({ type: 'TASK_ID', payload: response.taskId });
                        this.store.dispatch({ type: 'FREEZEPAGE', payload: true });
                        this.store.dispatch({ type: 'FREEZEACC', payload: true });
                        if (this.currentFlow !== undefined && (this.currentFlow === 'Change' || this.currentFlow === "COR")) {
                            this.router.navigate(['/co-review-order']);
                        }
                        else {
                            this.router.navigate(['/review-order']);
                        }
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "reviewOrderResponse", error);
                        this.logger.log("error", "account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.logger.log("error", "account.component.ts", "reviewOrderError", JSON.stringify(this.apiResponseError));
                            this.systemErrorService.logAndeRouteToSystemError("error", 'reviewOrderError', "account.component.ts", "Account Page", this.apiResponseError);
                        } else {
                            unexpectedError = true;
                        }
                    } else {
                        unexpectedError = true;
                    }
                    if (unexpectedError) {
                        const errorResponseCustom: ErrorResponse = {
                            statusCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDown
                        };
                        if (this.apiResponseError && this.apiResponseError.errorResponse) {
                            this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                            this.logger.log("error", "account.component.ts", "reviewOrderError", JSON.stringify(this.apiResponseError));
                        }
                        const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", 'reviewOrderError', "account.component.ts", "Account Page", lAPIErrorLists);
                    }
                }
            );
    }

    public orderDtvProcess(requestObj, isChangeFlow, requestObject) {
        let request: any;
        this.retainObservable = this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((data) => {
            request = {
                orderRefNumber: data.dtvSessionInfo.payload.orderReferenceNumber,
                processInstanceId: data.dtvSessionInfo.processInstanceId,
                taskId: data.dtvSessionInfo.taskId,
                taskName: data.dtvSessionInfo.taskName,
                payload: {
                    uniqueSessionId: data.dtvSessionInfo.payload.sessionInfo.uniqueSessionId,
                    attOrderType: "DIRECTV"
                }
            };
        });

        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.orderDtvProcess(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVinit", "account.component.ts",
                    "DIRECTV order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                if (data && data.payload.taskName === 'Enter DTV Manually') {
                    this.opusSessionInfoNotFound.open();
                }
            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    const errorResponseArray: ErrorResponse[] = [];
                    const localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    const lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    public retrieveDtvOrder(requestObj, isChangeFlow, requestObject) {
        this.loading = true;
        let request: any;
        request = {
            "uniqueSessionId": "",
            "attOrderType": "DIRECTV",
            "orderReferencNumber": requestObj.orderRefNumber
        };
        if (this.retainObservableData && this.retainObservableData.dtvSessionInfo && this.retainObservableData.dtvSessionInfo.payload && this.retainObservableData.dtvSessionInfo.payload.sessionInfo && this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId) {
            request.uniqueSessionId = this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId;
        }

        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.retrieveDtvOrder(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVRetrieveOrder", "account.component.ts",
                    "DIRECTV Retrieve order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    this.loading = false;
                    if (data.errorResponse[0].message === 'SESSION_ID_NON_FOUND') {
                        this.opusSessionInfoNotFound.open();
                    } else {
                        data.errorResponse[0]['status'] = "200";
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error",
                            "",
                            "retrieveDTVOrder",
                            "account.component.ts",
                            "Retrieve  DTV order",
                            data.errorResponse[0]
                        );
                        return Observable.throwError(null);
                    }
                } else {

                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                    this.orderDtvProcess(requestObj, isChangeFlow, requestObject);
                    this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
                }

            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }

                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    const errorResponseArray: ErrorResponse[] = [];
                    const localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    const lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    /** On second time click on continue button, get order response & navigate to order page */
    public getOrderResponse() {
        if ((this.refObj.isEmailValid || ((this.contactDet && this.contactDet.emailAddrDeclined) && this.refObj.billingOpt !== 'paperless')) &&
            this.refObj.dobEntered && this.isPrepaid ? true : this.refObj.enteredSsn && this.isPrepaid ? true : this.personalDet.creditCheck !== null) {
            if (!this.isDtvOpus && this.isDTV) {
                const dtvAccountNo = this.dtvForm.get('dtvAccNo').value;
                if (!dtvAccountNo && this.newDtv && this.isDTV && dtvAccountNo === '') {
                    return;
                } else {
                    if (dtvAccountNo !== '' && this.newDtv && this.isDTV) {
                        this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'yes', accNo: dtvAccountNo } } });
                        this.accountService.saveDtvAccountNo(dtvAccountNo, this.creditReviewResp.orderRefNumber).subscribe((resp) => { });
                    }
                }
            }
            this.loading = true;
            let requestObject: PaymentsRq = {};
            this.store.dispatch({ type: 'Prepaid_LoginDetails', payload: this.loginDetails });
            if (this.paymentReqObj && this.paymentReqObj !== null && this.paymentReqObj !== undefined && this.paymentReqObj.length === 0) {
                this.paymentReqObj = null;
            }
            let isChangeFlow: boolean = false;
            if (this.currentFlow !== undefined && this.currentFlow === 'Change') {
                isChangeFlow = true;
                requestObject = {
                    taskName: 'Disconnect Review Order'
                };
            } else {
                requestObject = {
                    orderRefNumber: this.creditReviewResp.orderRefNumber,
                    processInstanceId: this.creditReviewResp.processInstanceId,
                    taskId: this.creditReviewResp.taskId,
                    taskName: this.creditReviewResp.taskName,
                    payload: {
                        paymentStatus: this.paymentReqObj
                    }
                };
            }
            this.creditReviewResp.payload.creditReviewAction = this.enumActions.SHOW_SUMMARY;
            this.userdata = this.store.select('user');
            let reentrentTaskId: string;
            this.userSubscription$ = this.userdata.subscribe(
                (userdata) => {
                    reentrentTaskId = userdata.taskId;
                    userdata.phoneNumber = this.phoneNumber;
                });
            if (this.reEntrant && !this.creditCheckDone && this.isCreditChecked) {
                this.reentrantCreditCheckdone = true;
                this.getCreditInformation();
                if (this.accountInfoAfterDoneCredit) {
                    const inValidAccPassword = Validations.accountPasswordValidator({ value: this.accountInfoAfterDoneCredit.payload.accountInfo.accountPassword });
                    if (!inValidAccPassword) {
                        this.accRespObj.accountPassword = this.accountInfoAfterDoneCredit.payload.accountInfo.accountPassword;
                        this.store.dispatch({ type: 'ACCT_PASSWORD', payload: this.accRespObj.accountPassword });
                    } else {
                        this.accRespObj.accountPassword = null;
                        this.store.dispatch({ type: 'ACCT_PASSWORD', payload: this.accRespObj.accountPassword });
                    }
                    let requestObj: any = {
                        orderRefNumber: this.creditReviewResp.orderRefNumber,
                        processInstanceId: this.creditReviewResp.processInstanceId,
                        taskId: this.refObj.userData.taskId,
                        taskName: this.creditReviewResp.taskName,
                        payload: {
                            creditReviewAction: this.enumActions.SHOW_SUMMARY,
                            accountInfo: {
                                accountName: this.accountInfoAfterDoneCredit.payload.accountInfo.accountName,
                                accountPassword: this.accountInfoAfterDoneCredit.payload.accountInfo.accountPassword,
                                accountPin: this.creditReviewResp.payload.accountInfo.accountPin,
                                accountPreferences: this.accountInfoAfterDoneCredit.payload.accountInfo.accountPreferences,
                                accountSubType: this.accountInfoAfterDoneCredit.payload.accountInfo.accountSubType,
                                accountType: this.accountInfoAfterDoneCredit.payload.accountInfo.accountType,
                                ban: this.creditReviewResp.payload.accountInfo.ban,
                                billCycle: this.accountInfoAfterDoneCredit.payload.accountInfo.billCycle,
                                billingAdditionalInfo: this.accountInfoAfterDoneCredit.payload.accountInfo.billingAdditionalInfo,
                                billingAddress: this.accountInfoAfterDoneCredit.payload.accountInfo.billingAddress,
                                billingAddressType: this.accountInfoAfterDoneCredit.payload.accountInfo.billingAddressType,
                                contact: this.accountInfoAfterDoneCredit.payload.accountInfo.contact,
                                creditClass: this.creditReviewResp.payload.creditInfo.creditClass,
                                geoCode: this.accountInfoAfterDoneCredit.payload.accountInfo.geoCode,
                                isBillAddrSameAsServiceAddress: this.accountInfoAfterDoneCredit.payload.accountInfo.isBillAddrSameAsServiceAddress,
                                personalDetails: this.accountInfoAfterDoneCredit.payload.accountInfo.personalDetails
                            },
                            addlOrderAttributes: this.otcUpdated ? this.otcUpdated : this.otcData1,
                            loginDetails: this.loginDetails
                        }
                    };
                    this.store.dispatch({ type: 'BILLING_ADDR', payload: this.accountInfoAfterDoneCredit.payload.accountInfo.billingAddress });
                    this.store.dispatch({ type: 'ACCOUNT_PREFERENCES_DETAILS', payload: this.accountInfoAfterDoneCredit.payload.accountInfo.accountPreferences });
                    this.store.dispatch({ type: 'CONTACT_DETAILS', payload: this.accountInfoAfterDoneCredit.payload.accountInfo.contact });
                    this.store.dispatch({ type: 'PERSONAL_DETAILS', payload: this.accountInfoAfterDoneCredit.payload.accountInfo.personalDetails });
                    this.userdata = this.store.select('user');
                    this.userSubscription$ = this.userdata.subscribe(
                        (userdata) => {
                            requestObj.taskId = userdata.taskId;
                            userdata.phoneNumber = this.accountInfoAfterDoneCredit.payload.accountInfo.contact.contactNumber;
                        });
                    requestObj = this.updateCreditCheckStatusForCreditReview(requestObj);
                    this.changeResponsibility(requestObj);
                    if (!this.isPrepaid) { this.bypassDeposit(requestObj); }
                    this.authorizedContact(requestObj, this.authUsers);
                    this.accountService.getAccountData(this.accountForm.value);
                    if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV && this.dtvAccountInfoManuallyEntered) {
                        this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
                    } else if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV) {
                        this.retrieveDtvOrder(requestObj, isChangeFlow, requestObject);
                    } else {
                        this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
                    }
                }
            } else {
                this.updateaccRespObj();
                let requestObj: any = {
                    orderRefNumber: this.creditReviewResp.orderRefNumber,
                    processInstanceId: this.creditReviewResp.processInstanceId,
                    taskId: reentrentTaskId,
                    taskName: this.creditReviewResp.taskName,
                    payload: {
                        creditReviewAction: this.enumActions.SHOW_SUMMARY,
                        accountInfo: {
                            accountName: this.accRespObj.accountName,
                            accountPassword: this.accRespObj.accountPassword,
                            accountPin: this.creditReviewResp.payload.accountInfo.accountPin,
                            accountPreferences: this.accRespObj.accountPreferences,
                            accountSubType: this.accRespObj.accountSubType,
                            accountType: this.accRespObj.accountType,
                            ban: this.creditReviewResp.payload.accountInfo.ban,
                            billCycle: this.accRespObj.billCycle,
                            billingAdditionalInfo: this.accRespObj.billingAdditionalInfo,
                            billingAddress: this.accRespObj.billingAddress,
                            billingAddressType: this.accRespObj.billingAddressType,
                            contact: this.accRespObj.contact,
                            creditClass: this.isPrepaid ? this.creditReviewResp.payload.pastDueAmount.creditClass : this.creditReviewResp.payload.creditInfo.creditClass,
                            geoCode: this.accRespObj.geoCode,
                            isBillAddrSameAsServiceAddress: this.accRespObj.isBillAddrSameAsServiceAddress,
                            personalDetails: this.accRespObj.personalDetails
                        },
                        addlOrderAttributes: this.otcUpdated ? this.otcUpdated : this.otcData1,
                        loginDetails: this.loginDetails
                    }
                };
                this.changeResponsibility(requestObj);
                requestObj = this.updateCreditCheckStatusForCreditReview(requestObj);
                if (!this.isPrepaid) { this.bypassDeposit(requestObj); }
                this.authorizedContact(requestObj, this.authUsers);
                this.accountService.getAccountData(this.accountForm.value);
                if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV && this.dtvAccountInfoManuallyEntered) {
                    this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
                } else if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV) {
                    this.retrieveDtvOrder(requestObj, isChangeFlow, requestObject);
                } else {
                    this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
                }
            }
        } else {
            this.loading = false;
            this.displayEmailMandatoryAlert();
        }

    }
    private bypassDeposit(data) {
        const dipositBypass = {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "depositBypassed",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "depositBypassedInd",
                                    "orderAttributeValue": this.bypassButtonSelected
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        const depositeBypassOptional = {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "agentEnsembleIdInfo",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "agentEnsembleId",
                                    "orderAttributeValue": "string"
                                }
                            ]
                        }
                    ]
                }
            ]
        };

        data.payload.addlOrderAttributes[1] = dipositBypass;
        data.payload.addlOrderAttributes[2] = depositeBypassOptional;

        this.store.dispatch({ type: 'BYPASS-VALUE', payload: this.bypassButtonSelected });
    }

    private authorizedContact(respData, AuthUsers) {
        if (respData && respData.payload && respData.payload.addlOrderAttributes
            && Array.isArray(respData.payload.addlOrderAttributes) && respData.payload.addlOrderAttributes.length > 0) {
            respData.payload.addlOrderAttributes.forEach((item: any) => {
                if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                    for (let i = 0; i < item.orderAttributeGroup.length; i++) {
                        if (item.orderAttributeGroup[i].orderAttributeGroupName === "authorizedContact") {
                            item.orderAttributeGroup.splice(i, 1);
                        }
                    }
                }
            });
        }
        if (AuthUsers && AuthUsers !== undefined && AuthUsers !== null && AuthUsers.length > 0) {
            const additionalAttr: any = [
                {
                    "orderAttributeGroup": [
                        {
                            "orderAttributeGroupName": "authorizedContact",
                            "orderAttributeGroupInfo": [
                                {
                                    "orderAttributes": [
                                        {
                                            "orderAttributeName": "action",
                                            "orderAttributeValue": "ADD"
                                        },
                                        {
                                            "orderAttributeName": "contactType",
                                            "orderAttributeValue": "AUP"
                                        },
                                        {
                                            "orderAttributeName": "firstName",
                                            "orderAttributeValue": this.authUsers[0].firstName
                                        },
                                        {
                                            "orderAttributeName": "lastName",
                                            "orderAttributeValue": this.authUsers[0].lastName
                                        },
                                        {
                                            "orderAttributeName": "contactPhone",
                                            "orderAttributeValue": this.authUsers[0].contactPhone ? this.authUsers[0].contactPhone.match(/\d/g).join('') : ""
                                        }
                                    ]
                                },
                                {
                                    "orderAttributes": [
                                        {
                                            "orderAttributeName": "action",
                                            "orderAttributeValue": "ADD"
                                        },
                                        {
                                            "orderAttributeName": "contactType",
                                            "orderAttributeValue": "AUP"
                                        },
                                        {
                                            "orderAttributeName": "firstName",
                                            "orderAttributeValue": this.authUsers[1].firstName
                                        },
                                        {
                                            "orderAttributeName": "lastName",
                                            "orderAttributeValue": this.authUsers[1].lastName
                                        },
                                        {
                                            "orderAttributeName": "contactPhone",
                                            "orderAttributeValue": this.authUsers[1].contactPhone ? this.authUsers[1].contactPhone.match(/\d/g).join('') : ""
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }

            ];

            if (respData.payload && respData.payload.addlOrderAttributes !== undefined
                && respData.payload.addlOrderAttributes && respData.payload.addlOrderAttributes.length > 0
                && respData.payload.addlOrderAttributes[0].orderAttributeGroup) {
                respData.payload.addlOrderAttributes[0].orderAttributeGroup.push(additionalAttr[0].orderAttributeGroup[0]);
            } else {
                respData.payload.addlOrderAttributes = [];
                respData.payload.addlOrderAttributes.push(additionalAttr);
            }
            this.store.dispatch({ type: 'AUTHORIZED_PARTIES', payload: this.authUsers });
        }
    }

    private updateaccRespObj() {

        this.refObj && this.refObj.billingOption && this.refObj.billingOption.name && this.refObj.billingOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountPreferences.emailNotification.billingNotification = true :
            this.accRespObj.accountPreferences.emailNotification.billingNotification = false;

        this.refObj && this.refObj.billingOption && this.refObj.billingOption.name && this.refObj.billingOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountPreferences.textNotification.billingNotification = true :
            this.accRespObj.accountPreferences.textNotification.billingNotification = false;

        this.refObj && this.refObj.orderOption && this.refObj.orderOption.name && this.refObj.orderOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountPreferences.emailNotification.orderingNotification = true :
            this.accRespObj.accountPreferences.emailNotification.orderingNotification = false;

        this.refObj && this.refObj.orderOption && this.refObj.orderOption.name && this.refObj.orderOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountPreferences.textNotification.orderingNotification = true :
            this.accRespObj.accountPreferences.textNotification.orderingNotification = false;

        this.refObj && this.refObj.repairOption && this.refObj.repairOption.name && this.refObj.repairOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountPreferences.emailNotification.repairNotification = true :
            this.accRespObj.accountPreferences.emailNotification.repairNotification = false;

        this.refObj && this.refObj.repairOption && this.refObj.repairOption.name && this.refObj.repairOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountPreferences.textNotification.repairNotification = true :
            this.accRespObj.accountPreferences.textNotification.repairNotification = false;

        this.accRespObj.accountName.firstName = this.accountForm.value.firstName;
        this.accRespObj.accountName.lastName = this.accountForm.value.lastName;
        this.accRespObj.accountName.middleName = this.accountForm.value.middleName;
        this.accRespObj.accountName.title = '';
        this.accRespObj.contact.contactNumber = this.accountForm.value.contactNumber;
        this.accRespObj.contact.smsNumber = this.accountForm && this.accountForm.value && this.accountForm.value.smsNumber;
        this.accRespObj.contact.emailAddress = this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress;
        this.accRespObj.accountPreferences.paperlessBilling = false;
        this.accRespObj.accountPreferences.braille = false;
        this.accRespObj.accountPreferences.spanishBillPrint = false;
        this.accRespObj.accountPreferences.largePrint = false;
        if (this.accountForm && this.accountForm.value && this.accountForm.value.emailAddrDeclined === true) {
            this.accRespObj.contact.emailAddrDeclined = true;
            this.accRespObj.contact.emailAddress = "";
        }

        switch (this.refObj.billingOpt) {
            case 'paperless':
                this.accRespObj.accountPreferences.paperlessBilling = true;
                break;
            case 'braille':
                this.accRespObj.accountPreferences.braille = true;
                break;
            case 'spanish':
                this.accRespObj.accountPreferences.spanishBillPrint = true;
                break;
            case 'large':
                this.accRespObj.accountPreferences.largePrint = true;
                break;
            default: break;
        }
        this.accRespObj.accountType = 'I';
        this.accRespObj.accountSubType = 'R';
        const cont = this.accRespObj.contact.contactNumber;
        if (cont) {
            this.accRespObj.contact.contactNumber = cont.match(/\d/g).join('');
        }
        const sms = this.accRespObj.contact.smsNumber;
        if (sms) {
            this.accRespObj.contact.smsNumber = sms.match(/\d/g).join('');
        }
        this.accRespObj = Object.assign({},
            this.accRespObj, {
            creditClass: this.accRespObj.creditClass !== null ? this.accRespObj.creditClass : '3'
        });
        this.accRespObj.billingAdditionalInfo = this.refObj.addrCareOf;
        if (this.refObj.addrTypeSelected === 'International') {
            this.accRespObj.billingAddressType = 'F';
        } else if (this.refObj.addrTypeSelected === 'Street Address') {
            this.accRespObj.billingAddressType = 'S';
        } else if (this.refObj.addrTypeSelected === 'P.O. Box') {
            this.accRespObj.billingAddressType = 'P';
        } else if (this.refObj.addrTypeSelected === 'Rural Route') {
            this.accRespObj.billingAddressType = 'R';
        } else if (this.refObj.addrTypeSelected === 'Military') {
            this.accRespObj.billingAddressType = 'M';
        }
    }

    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            const H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + String(h)) : h;
            const ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }

    public updateApplClickHandler() {
        this.updateAppilicationSelected = true;
        this.isCreditChecked = false;
        this.refObj.gotCreditResponse = false;
        this.creditObj = null;
        this.refObj.updateAppClicked = true;
        if (this.creditInfo.creditClass === '9') { this.creditInfo.creditClass = ''; }
    }

    public refreshCreditCheck() {
        if (this.bypassCreditCheckSelected) {
            return;
        }
        this.loading = true;
        if (this.creditReviewResp.taskName === "Credit Review" && this.accRespObj && this.accRespObj.personalDetails && this.accRespObj.personalDetails !== undefined && this.accRespObj.personalDetails.ssn === null && this.isOnHoldFlow) {
            this.accRespObj.personalDetails.ssn = "999999999";
            this.refreshDecisionSelected = true;
        }
        if (this.creditReviewResp.taskName === "Credit Review" && this.accRespObj && this.accRespObj.personalDetails && this.accRespObj.personalDetails !== undefined && this.accRespObj.personalDetails.dateOfBirth === null && this.isOnHoldFlow) {
            this.accRespObj.personalDetails.dateOfBirth = "1996-11-11";
            this.refreshDecisionSelected = true;
        }
        const reqObj = {
            orderRefNumber: this.creditReviewResp.orderRefNumber,
            processInstanceId: this.creditReviewResp.processInstanceId,
            taskId: this.reEntrant ? this.taskId : this.creditReviewResp.taskId,
            taskName: this.creditReviewResp.taskName,
            payload: {
                creditReviewAction: this.enumActions.REFRESH_DECISION,
                accountName: this.accRespObj.accountName,
                personalDetails: this.accRespObj.personalDetails,
                addlOrderAttributes: this.creditReviewResp.payload.addlOrderAttributes
            }
        };

        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "creditInfoRequest", JSON.stringify(reqObj ? reqObj : ''));
        this.logger.startTime();
        this.accountService.getCreditResponse(reqObj, this.currentFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(null);
            })
            .subscribe(
                (respData) => {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "creditInfoResponse", JSON.stringify(respData ? respData : ''));
                    this.logger.log("info", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.apiResponseError = null;
                    this.creditReviewResp = respData;
                    this.store.dispatch({ type: 'CREDIT_REVIEW', payload: respData });
                    this.creditObj = respData.payload;
                    this.initCreditInfo();
                    this.loading = false;
                    this.taskId = respData.taskId;
                    this.refObj.userData.taskId = respData.taskId;
                    this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "creditInfoResponse", error);
                        this.logger.log("error", "account.component.ts", "creditInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (this.creditInfo.creditClass === '9' || this.creditInfo.creditClass > '8') {
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", 'creditInfoError', "account.component.ts", "Account Page", this.apiResponseError);
                                this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            } else {
                                unexpectedError = true;
                            }
                        } else {
                            unexpectedError = true;
                        }
                        if (unexpectedError) {
                            const errorResponseCustom: ErrorResponse = {
                                statusCode: serverErrorMessages.statusCode,
                                message: serverErrorMessages.serverDown
                            };
                            if (this.apiResponseError && this.apiResponseError.errorResponse) {
                                this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                                this.logger.log("error", "account.component.ts", "creditInfoError", JSON.stringify(this.apiResponseError));
                            }
                            const lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", 'submitTask', "account.component.ts", "Account Page", lAPIErrorLists);
                        }
                    }
                });
        if (this.refreshDecisionSelected) {
            this.accRespObj.personalDetails.ssn = null;
            this.accRespObj.personalDetails.dateOfBirth = null;
        }
    }

    public cancelOrder() {
        this.router.navigate(['/home']);
    }

    public popupCenter(url, w, h) {
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }

    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacy === 'CENTURYLINK') {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Atrue%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%2216%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22Y5YzQ2MWM0YjIzMTExYmRi%22%2C%22ssid%22%3A%22rI28qh_OTFKTGfGQbOQIFA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
        } else {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083512%2C%22eid%22%3A1570086812%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22AzY2QxNDAyNDE2YTdhMGI1%22%2C%22ssid%22%3A%22C-xqYDpuQr692Su1zOt-6Q%22%2C%22lewid%22%3A1570246912%2C%22skill%22%3A%22credit-service-cris%22%7D%7D';
        }
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }
    public udpateServiceGroup(creditReviewResp) {
        if (creditReviewResp && creditReviewResp.payload && creditReviewResp.payload.depositInfo && creditReviewResp.payload.depositInfo.products) {
            for (const product of creditReviewResp.payload.depositInfo.products) {
                if (product.productType) {
                    switch (product.productType) {
                        case "INTERNET":
                            product.serviceGroup = "Internet";
                            break;
                        case "VOICE-HP":
                            product.serviceGroup = "Home Phone";
                            break;
                        case "VOICE-DHP":
                            product.serviceGroup = "Digital Home Phone";
                            break;
                        case "VIDEO-DTV":
                            product.serviceGroup = "DIRECTV";
                            break;
                        case "VIDEO-PRISM":
                            product.serviceGroup = "Prism";
                            break;
                    }
                }
            }
        }
        return creditReviewResp;
    }


    public selectBypassButton(e: any) {
        if (e.target.checked) {
            this.bypassButtonSelected = true;
        } else {
            this.bypassButtonSelected = false;
        }
    }

    public setApproval(val) {
        this.store.dispatch({ type: 'CHANGE_RESPONSIBILITY_APPROVAL', payload: val });
    }

    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    public CRpolicyDetails() {
        window.open(' https://ecms.corp.intranet/livelink/llisapi.dll/fetch/46352800/Change_of_Responsibility__Overview_%28Bus_%26_Res%29.html?nodeid=50594063&vernum=-2');
    }

    private changeResponsibility(data) {
        if (data && this.currentFlow === 'COR') {
            let flag = false;
            const obj = {
                "orderAttributeGroupName": "approvalMethodInfo",
                "orderAttributeGroupInfo": [
                    {
                        "orderAttributes": [
                            {
                                "orderAttributeName": "approvalMethod",
                                "orderAttributeValue": this.changeRes
                            }
                        ]
                    }
                ]
            };
            if (data && data.payload && data.payload.addlOrderAttributes
                && Array.isArray(data.payload.addlOrderAttributes) && data.payload.addlOrderAttributes.length > 0) {
                data.payload.addlOrderAttributes.forEach((item: any) => {
                    if (item.orderAttributeGroup && Array.isArray(item.orderAttributeGroup) && item.orderAttributeGroup.length > 0) {
                        for (let i = 0; i < item.orderAttributeGroup.length; i++) {
                            if (item.orderAttributeGroup[i].orderAttributeGroupName === "approvalMethodInfo") {
                                item.orderAttributeGroup[i].orderAttributeGroupInfo.map((j) => {
                                    j.orderAttributes = [{
                                        "orderAttributeName": "approvalMethod",
                                        "orderAttributeValue": this.changeRes
                                    }];
                                    flag = true;
                                });
                            }
                        }
                    }
                    if (!flag) {
                        item.orderAttributeGroup.push(obj);
                    }
                });
            }
        }
    }

    public setFirstLastName() {
        const retainObservable = this.store.select('retain');
        const retainSubscription = retainObservable.subscribe((data) => {
            if (data && data.prodConfig && data.prodConfig.prodConfig && data.prodConfig.prodConfig.length) {
                data.prodConfig.prodConfig.map((item) => {
                    if (item.productType === "VOICE-DHP" || item.productType === "VOICE-HP") {
                        item.configItems.map((configDetailsItem) => {
                            configDetailsItem.configDetails.map((form) => {
                                form.formItems.map((frmVal) => {
                                    if (frmVal.attributeName === "First Name") {
                                        this.accountForm.controls['firstName'].setValue(frmVal.attributeValue[0].value);
                                    }
                                    if (frmVal.attributeName === "Last Name") {
                                        this.accountForm.controls['lastName'].setValue(frmVal.attributeValue[0].value);
                                    }
                                });
                            });
                        });
                    }
                });
            }
        });
        retainSubscription.unsubscribe();
    }
    /** unsubscribe on destroy */
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.accountSubscription !== undefined) {
            this.accountSubscription.unsubscribe();
        }
        if (this.creditRevSubscription !== undefined) {
            this.creditRevSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.retainSubscription !== undefined) {
            this.retainSubscription.unsubscribe();
        }
        if (this.existingProductStoreSubscription !== undefined) {
            this.existingProductStoreSubscription.unsubscribe();
        }
        if (this.creditCheckRetain !== undefined) {
            this.creditCheckRetain.unsubscribe();
        }
        if (this.apptSubscription !== undefined) {
            this.apptSubscription.unsubscribe();
        }

    }

    public updateCreditCheckStatusForCreditReview(req: any): any {
        if (req && req.payload && req.payload.accountInfo && req.payload.accountInfo.personalDetails) {
            req.payload.accountInfo.personalDetails.creditCheck = this.creditCheckStatusFromAccountInfo;
        }
        return req;
    }

    public getEffectiveBilldate(){
        let currentStore = this.appStateService.getState();
        let retainVal = currentStore.order;
        if (retainVal && retainVal["effectivebilldate"]) {
           let effectivebilldate= retainVal["effectivebilldate"] ;
           if(effectivebilldate && effectivebilldate.payload && effectivebilldate.payload.dueDate && effectivebilldate.payload.dueDate.finalDueDate)
           {
               this.effectiveBilldate= effectivebilldate.payload.dueDate.finalDueDate;
             // return effectivebilldate.payload.dueDate.finalDueDate;
             this.convertToString(this.effectiveBilldate);
           }
        }
    }

    public convertToString(date){
      let effectiveBilldateNumber = parseInt(moment(date).utc().format('DD'));
     // let effectiveBilldateNumber = parseInt(moment(UTCTime).tz('America/Denver').format('DD'));
      let list =[29,30,31]
      if(list.indexOf(effectiveBilldateNumber) > -1){
        effectiveBilldateNumber = 1;
      }
      if(effectiveBilldateNumber)
      {
          this.effectiveBilldateNumber = effectiveBilldateNumber;
      }
    }
    public nth = (d: number) => {
        if (d > 3 && d < 21) return 'th';
        switch (d % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }
}
