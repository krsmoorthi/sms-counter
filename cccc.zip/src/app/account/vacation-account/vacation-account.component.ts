import { Component, OnInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AccountInfomation } from '../../common/models/account.model';
import { APIErrorLists, GenericValues } from '../../common/models/common.model';
import { User } from '../../common/models/user.model';
import { SystemErrorService } from '../../common/service/system-error.service';
import { VacationService } from '../../common/service/vacation.service';
import { Validations } from '../../common/validations/validations';
import { Logger } from './../../common/logging/default-log.service';
import { AppStore } from './../../common/models/appstore.model';
import { AppStateService } from './../../common/service/app-state.service';
import 'rxjs/add/operator/debounceTime';
import "rxjs/add/operator/catch";

@Component({
    selector: 'vacation-account',
    templateUrl: './vacation-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})
export class VacationAccountComponent implements OnInit {
    public lastName: string;
    public firstName: string;
    public modem: any;
    public loading = false;
    public errorMsg = '';
    public accountSubscription;
    public moveSubscription;
    public otcUpdated: any;
    public accountObservable: Observable<AccountInfomation>;
    public moveObservable: Observable<any>;
    public nextReqPayloadObj: any = {};
    public user: Observable<User>;
    public userData: any;
    public userSubscription: Subscription;
    public newServiceAddress: string;
    public apiResponseError: APIErrorLists;
    public payload: any;
    public accInformation: any = {};
    public isAddressSelected = 'New address';
    public billingAddress: string;
    public intbillingAddress: string;
    public showInternatinoalBillingAddress: boolean = false;
    private isReEntrant: boolean = false;
    private taskId: string = '';
    public accountRentrantValue: any = false;
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public ban: any;
    public existingObservable: Observable<any>;
    public accountPin: any;
    public existingSubscription: Subscription;
    public OtcSubscription: Subscription;
    private originalBillingAddr;
    public isBillingSaved = false;
    private orderRefNumber: string;
    private apiResponse;
    private billingTypeAddress;
    private tempBillingAddr;
    private billingAdditionalInfo;
    public shippingAddress;
    public isNewAddressValid: boolean = false;
    public retainedAddress: any;
    public refObj = {
        finalEmail: '',
        selectedOpt: '',
        submitted: false,
        isEmailValid: true
    }
    public emailPlaceHolder: string = "";
    public paperlessBilling;
    public ispaperlessBillingAllowed;
    public paperlessForm: FormGroup;
    public apiResponsedata: any;

    constructor(
        private logger: Logger,
        private router: Router,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private vacationService: VacationService
    ) {
        this.appStateService.setLocationURLs();
        this.accountObservable = <Observable<AccountInfomation>>store.select('account');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            this.apiResponse = respData;
            this.apiResponsedata = respData;
            let user = <Observable<User>>store.select('user');
            let userSubscription = user.subscribe(
                (usr) => {
                    this.firstName = usr.firstName;
                    this.lastName = usr.lastName;
                    if (usr.previousUrl !== '/vacation-schedule-appt-ship') {
                        this.isReEntrant = true;
                        this.taskId = usr.taskId;
                        let retainVal = <Observable<any>>store.select('retain');
                        retainVal.subscribe(
                            (retVal => {
                                this.apiResponse = retVal.review;
                            })
                        )
                    }
                    if (usr && usr.orderRefNumber) {
                        this.orderRefNumber = usr.orderRefNumber;
                    }
                });
            if (this.isReEntrant) {
                this.isAddressSelected = this.apiResponsedata.AddressTypes;
            }
            userSubscription.unsubscribe();
            this.existingObservable = <Observable<any>>store.select('existingProducts');
            this.existingSubscription = this.existingObservable.subscribe((data) => {
                if (data && data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].existingServices && data.existingProductsAndServices[0].existingServices.existingServiceItems) {
                    data.existingProductsAndServices[0].existingServices.existingServiceItems.map((serviceItem) => {
                        if (serviceItem.offerCategory === (GenericValues.iData || name === GenericValues.sData)) {
                            serviceItem.existingServiceSubItems.map((existingServiceSubItems) => {
                                if (existingServiceSubItems.productType === (GenericValues.iData || name === GenericValues.sData) && existingServiceSubItems.productName === 'MODEM') {
                                    existingServiceSubItems.productAttributes.map((productAttributes) => {
                                        productAttributes.compositeAttribute.map((compositeAttribute) => {
                                            if (compositeAttribute.attributeName.toLowerCase() !== 'modem type' && compositeAttribute.attributeName.toLowerCase() !== 'modem class' && compositeAttribute.attributeValue === 'Lease') {
                                                this.modem = compositeAttribute.attributeValue;
                                            }
                                        })
                                    })
                                }
                            })
                        }
                    })
                }
            });
            if (this.existingSubscription !== undefined) this.existingSubscription.unsubscribe();

            if (this.apiResponse && this.apiResponse.payload) {
                if (this.apiResponse && this.apiResponse.payload.billingAddress) {
                    this.billingAddress = this.setAddress(this.apiResponse.payload.billingAddress);

                    this.shippingAddress = this.setAddress(this.apiResponse.payload.billingAddress);;

                }
                this.originalBillingAddr = this.apiResponse.payload.billingAddress;
                if (this.apiResponse.payload.shippingInfo && this.apiResponse.payload.shippingInfo.shippingAddress) {
                    this.apiResponse.payload.shippingInfo.shippingAddress = this.apiResponse.payload.billingAddress;
                    this.apiResponse.payload.sameAddressFlag = false;
                }
            }
        });
    }

    public ngOnInit() {
        this.logger.metrics('AccountVacationPage');
        window.scroll(0, 0);
        if (this.apiResponse && this.apiResponse.payload && this.apiResponse.payload.paperlessInfo) {
            this.paperlessBilling = this.apiResponse.payload.paperlessInfo.paperlessBilling ? this.apiResponse.payload.paperlessInfo.paperlessBilling : false;
            this.refObj.finalEmail = this.apiResponse.payload.paperlessInfo.emailAddress ? this.apiResponse.payload.paperlessInfo.emailAddress : "";
            this.ispaperlessBillingAllowed = this.apiResponse.payload.paperlessInfo.paperlessBillAllowed ? this.apiResponse.payload.paperlessInfo.paperlessBillAllowed : false;
        }
        if (this.ispaperlessBillingAllowed) {
            this.refObj.selectedOpt = 'yesPaperless';
        }
        if (this.isReEntrant) {
            if (!this.paperlessBilling) {
                this.refObj.selectedOpt = 'noPaperless';
            }
            let retainVal = <Observable<any>>this.store.select('retain');
            let retSubscribe = retainVal.subscribe(
                (data => {
                    if (data && data.accountPageReEntrant && data.accountPageReEntrant.isAddressSelected) {
                        this.isAddressSelected = data.accountPageReEntrant.isAddressSelected;
                        if (this.isAddressSelected === 'New address') {
                            this.isUpdateBillingCalled = true;
                            this.newAddressClicked(this.isAddressSelected);
                        }
                    }
                }));
            if (retSubscribe) retSubscribe.unsubscribe();
        }
        this.paperlessForm = new FormGroup({
            'radioPaperless': new FormControl(this.refObj.selectedOpt),
            'finalEmail': new FormControl(this.refObj.finalEmail ? [this.refObj.finalEmail, [Validations.emailValidator]] :
                ['', [Validations.emailValidator]]),
        });

        this.paperlessForm.get('finalEmail').valueChanges.debounceTime(750).subscribe((values) => {
            this.refObj.submitted = false;
            let isValidMail = Validations.emailValidator({ value: this.paperlessForm.value.finalEmail })
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
        })
        if (this.isAddressSelected === 'Current Billing address') this.isBillingSaved = true;
    }

    public newAddressClicked(event) {
        this.isAddressSelected = event;
        this.isNewAddressValid = false;
        if (!this.isUpdateBillingCalled) this.isBillingSaved = false;
        else this.updateBilling();
    }

    public changeBillingAddr() {
        this.isAddressSelected = 'New address';
        this.isBillingSaved = false;
    }

    public currentAddressClicked(event) {
        this.isAddressSelected = event;
        if (this.isAddressSelected === 'Current Billing address') this.isBillingSaved = true;
        else this.isBillingSaved = false;
        this.apiResponse.payload.sameAddressFlag = true;
        this.apiResponse.payload.billingAddress = this.originalBillingAddr;
        if (this.apiResponse.payload.billingAddress) {
            this.billingAddress = this.setAddress(this.apiResponse.payload.billingAddress);
        }
    }

    public isUpdateBillingCalled = false;
    public updateBilling() {
        this.apiResponse.payload.sameAddressFlag = false;
        this.isBillingSaved = true;
        this.isUpdateBillingCalled = true;
        this.apiResponse.payload.billingAddress = this.tempBillingAddr;
        if (this.billingTypeAddress === 'International') {
            this.apiResponse.payload.billingAddressType = 'F';
        } else if (this.billingTypeAddress === 'Street Address') {
            this.apiResponse.payload.billingAddressType = 'S';
        } else if (this.billingTypeAddress === 'P.O. Box') {
            this.apiResponse.payload.billingAddressType = 'P';
        } else if (this.billingTypeAddress === 'Rural Route') {
            this.apiResponse.payload.billingAddressType = 'R';
        } else if (this.billingTypeAddress === 'Military') {
            this.apiResponse.payload.billingAddressType = 'M';
        }
        this.apiResponse.payload.billingAdditionalInfo = this.billingAdditionalInfo;
        if (this.billingTypeAddress === 'International') {
            this.billingAddress = this.setAddress(this.apiResponse.payload.billingAddress);
        } else if (this.apiResponse.payload.billingAddress) {
            this.billingAddress = this.setAddress(this.apiResponse.payload.billingAddress);
        }
    }

    public updateSelectedNewAddress(newAddrObj) {
        this.tempBillingAddr = newAddrObj.address;
        this.billingTypeAddress = newAddrObj.billingAddressType;
        this.billingAdditionalInfo = newAddrObj.billingAdditionalInfo;
        this.updateBilling();
    }

    public onNewAddressValidation(isNewAddressValid) {
        this.isNewAddressValid = isNewAddressValid;
    }

    public retainAddress(address) {
        this.retainedAddress = address;
    }

    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    public setAddress(address) {
        let addrss = [];
        let adds: string;
        if(address) {
            if(address.streetAddress) addrss.push(address.streetAddress);
            if(address.subAddress && address.subAddress.combinedDesignator) addrss.push(address.subAddress.combinedDesignator);
            if(address.city) addrss.push(address.city);
            if(address.stateOrProvince) addrss.push(address.stateOrProvince);
            if(address.postCode) addrss.push(address.postCode);
            if(addrss) adds = addrss.join(', ').toString();
        }
        return adds;
    }

    public continueClick() {
        let addressType = this.isAddressSelected;
        this.store.dispatch({ type: 'ADDRESS_TYPES', payload: { AddressTypes: addressType } });
        if (this.refObj.selectedOpt === "yesPaperless" && !this.refObj.isEmailValid) {
            this.refObj.submitted = true;
            window.scroll(0, 200);
            return;
        }
        else {
            this.loading = true;
            if (this.isReEntrant) {
                this.apiResponse.taskId = this.taskId;
            }

            if (this.apiResponse && this.apiResponse.payload && this.apiResponse.payload.paperlessInfo) {
                this.apiResponse.payload.paperlessInfo.paperlessBilling = this.refObj.selectedOpt === "yesPaperless" ? true : false;
                this.apiResponse.payload.paperlessInfo.emailAddress = this.refObj.selectedOpt === "yesPaperless" ? this.refObj.finalEmail : '';
            }

            let request = {
                "success": true,
                "orderRefNumber": this.apiResponse.orderRefNumber,
                "processInstanceId": this.apiResponse.processInstanceId,
                "taskId": this.apiResponse.taskId,
                "taskName": this.apiResponse.taskName,
                "payload": {
                    "paperlessInfo": this.apiResponse.payload.paperlessInfo,
                    "sameAddressFlag": this.apiResponse.payload.sameAddressFlag,
                    "billingAddressType": this.apiResponse.payload.billingAddressType,
                    "billingAddress": this.apiResponse.payload.billingAddress
                }
            }

            let errorResolved = false;
            this.logger.log("info", "vacation-account.component.ts", "vacationAcctInfoRequest", JSON.stringify(request));
            this.logger.startTime();
            this.vacationService.submitInformation(request)
                .catch((error: any) => {
                    this.logger.endTime();
                    this.logger.log("error", "vacation-account.component.ts", "vacationAcctInfoResponse", error);
                    this.logger.log("error", "vacation-account.component.ts", "vacationAcctInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    errorResolved = true;
                    this.loading = false;
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", "Not Applicable",
                        "Submit Task", "vacation-account.component.ts",
                        "Vacation Account Page",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe(
                    (data) => {
                        this.logger.endTime();
                        this.logger.log("info", "vacation-account.component.ts", "vacationAcctInfoResponse", JSON.stringify(data ? data : ''));
                        this.logger.log("info", "vacation-account.component.ts", "vacationAcctInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        let response = data;
                        if (response) {
                            this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                            this.store.dispatch({ type: 'REVIEW_ORDER', payload: data });
                            this.store.dispatch({ type: 'VACATION_REVIEWORDER_RESPONSE', payload: data });
                            this.store.dispatch({ type: 'ACCOUNT_PAGE_REENTRANT', payload: { isAddressSelected: this.isAddressSelected } });
                            this.ctlHelperService.storeRequestProcessData(data, 'vacation-review-order', 'submit', 'vacation');
                            this.router.navigate(['/vacation-review-order']);
                        }
                    },
                    (error) => {
                        if (!errorResolved) {
                            this.logger.endTime();
                            this.logger.log("error", "vacation-account.component.ts", "vacationAcctInfoResponse", error);
                            this.logger.log("error", "vacation-account.component.ts", "vacationAcctInfoSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                        }
                        this.loading = false;
                        if (error === undefined || error === null)
                            return;
                        let unexpectedError = false;
                        if (this.ctlHelperService.isJson(error)) {
                            this.apiResponseError = JSON.parse(error);
                            if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                                this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                                this.systemErrorService.logAndeRouteToSystemError("error", "vacationAcctInfoResponseError", "vacation-account.component.ts", "Vacation Account Page", this.apiResponseError);
                            } else unexpectedError = true;
                        } else unexpectedError = true;
                        if (unexpectedError) {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "vacationAcctInfoResponseError", "vacation-account.component.ts", "Vacation Account Page", lAPIErrorLists);
                        }
                        window.scroll(0, 0);
                    });
        }

    }

    public optionClickHandler(currentOpt, previousOpt) {
        if (currentOpt !== previousOpt) {
            this.refObj.selectedOpt = currentOpt;
        }
    }

}