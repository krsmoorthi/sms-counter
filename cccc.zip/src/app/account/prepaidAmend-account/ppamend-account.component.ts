import { Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { DirectvService } from 'app/common/service/directv.services';
import { SystemErrorService } from "app/common/service/system-error.service";
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Logger } from '../../common/logging/default-log.service';
import { AccountContactDetails, AccountInfo, AccountInfomation, AccountPreferences, PersonalDetails, LoginDetails } from '../../common/models/account.model';
import { AppStore } from '../../common/models/appstore.model';
import { EnterpriseAddress } from '../../common/models/cart.model';
import { APIErrorLists, ErrorResponse, GenericValues, serverErrorMessages } from '../../common/models/common.model';
import { CreditCheck, CreditCheckPayload, CreditInfo, DepositInfo, PaymentInfo, PaymentsRq } from '../../common/models/credit-check.model';
import { Order } from '../../common/models/order.model';
import { User } from '../../common/models/user.model';
import { AuthUsersList } from '../../common/models/account.model';
import { AccountService } from '../../common/service/account.service';
import { AddressService } from '../../common/service/address.service';
import { AppStateService } from '../../common/service/app-state.service';
import { CountryStateService } from '../../common/service/country-state.service';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { TextMaskService } from '../../common/service/text-mask.service';
import { Validations } from '../../common/validations/validations';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import 'rxjs/add/operator/debounceTime';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";
import * as moment from 'moment-timezone';

@Component({
    selector: 'amend-account',
    templateUrl: './ppamend-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})

export class AmendAccountComponent implements OnInit, OnDestroy, AfterViewInit {
    public bypassButtonSelected: boolean = false;
    public bypassCreditCheck: boolean = false;
    public bypassCreditCheckSelected: boolean = false;
    public updateAppilicationSelected: boolean = false;
    public accountInfoAfterDoneCredit: any;
    public reentrantCreditCheckdone: boolean;
    public creditCheckDone: boolean = false;
    public reviewOrdeAddAttrrResponse: any;
    public dtvRefoundAmt: any;
    public dhpRefoundAmt: any;
    public dtvPaymentDone: boolean = false;
    public dhpPaymentDone: boolean = false;
    public allProductsPaid: boolean = true;
    public paymentPending: boolean = false;
    public potsPaymentDone: boolean = false;
    public hsiPaymentDone: boolean = false;
    public depositInfo: any;
    public potsRefoundAmt: any;
    public reentrantDepositPayStatus: any;
    public hsiRefundAmt: any;
    public potsPaymentData: boolean = false;
    public retrieveDtvData: any;
    public addlOrderAttributesDepositData: any;
    public isPaymentDone: boolean = false;
    public userSubscription$: Subscription;
    public userdata: Observable<User>;
    public accountdata: Observable<AccountInfomation>;
    public previousURL: string;
    public retainSSN: any;
    public creditRevObsv2: any;
    public creditDataObj: CreditCheck;
    public creditCheckRetain: Subscription;
    public user: Observable<User>;
    public retryButtonEnabled: boolean = false;
    public userSubscription: Subscription;
    public accountObservable: Observable<AccountInfomation>;
    public accountSubscription;
    public creditRevObsv: Observable<CreditCheck>;
    public creditRevSubscription: Subscription;
    public orderObservable: Observable<Order>;
    public orderSubscription: Subscription;
    public currUrl: string;
    public accountForm: FormGroup;
    public accRespObj: AccountInfo;                   // Account info Parent Object
    public showDriverLicense: boolean = false;
    public phoneMask: any;
    public ssnMask: any;
    public otcData1: any[];
    public otcDataResponse: any[];
    public otcData: any[];
    public otcUpdated: any[];
    public internationalFormattingUrl: string = `${env.INTERNATIONAL_FORMATTING_URL}`;
    public creditObj: CreditCheckPayload;                    // Credit check Parent Object
    public creditDepositInfo: DepositInfo;            // Credit check deposit info
    public billingAddr: EnterpriseAddress;            // Reference billing address
    public serviceAddress: EnterpriseAddress;
    private initialServiceAddress: EnterpriseAddress;
    public isAuthorizedParties: AuthUsersList;
    public authUsers: any = [];
    public authorizedParties: boolean = false;
    public oneAuthorzedParty: boolean = false;
    private isServiceAddressInitialized: boolean = false;
    public contactDet: AccountContactDetails;         // Contact Details
    public isCreditChecked: boolean = false;
    public personalDet: PersonalDetails;              // Account Personal details Object
    public loginDetails: LoginDetails;
    public products: any = [];
    public isInitializedFormObj: boolean = false;     // Flag to display initial page
    public accountObj: any = {};                      // Reference obj
    public payobj: any = {};
    public accInformation: AccountInfomation;
    public creditResponse: CreditCheck;
    public paymentReqObj: PaymentInfo[] = [];
    public errorMsg: string;
    public creditInfo: CreditInfo;
    private creditReviewResp: any;
    private autoLoginEmailAddress: any = '';
    private autoLoginPhoneNumber: any = '';
    private phoneNumber: any = '';
    public redAddressFlag: boolean = false;
    public accountRentrantValues: AccountInfomation;
    public accountRentrantValue: any = false;
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public retainObservableData: any;
    public paidSecurityDeposit: boolean = false;
    public ban: string;
    public uName: any = '';
    private enumActions = {
        UPDATE_APPLN: 'UPDATEAPPLN',
        REFRESH_DECISION: 'REFRESHDECISION',
        SHOW_SUMMARY: 'SHOWSUMMARY',
        PAY_DEPOSIT: 'PAYDEPOSIT',
        PAY_FBILL: 'PAYFBILL',
        PAY_INITIAL_BILL: 'PAYINITIALBILL'
    };
    public refObj: any =
        {
            billingOptions: [{ name: 'Email and SMS', disable: false },
            { name: 'Email only', disable: false },
            { name: 'SMS only', disable: false },
            { name: 'Do not notify', disable: false }],
            billingChk: true,
            orderChk: true,
            repairChk: true,
            changeAddrClicked: false,
            month: '',
            day: '',
            year: '',
            underAge: false,
            isEmailValid: true,
            isValidAccPassword: true,
            submitted: false,
            dobEntered: false,
            enteredSsn: true,
            addressTypes: ['Street Address', 'P.O. Box', 'Rural Route', 'Military', 'International'],
            stateCountries: [],
            dlStateCountries: [] = this.countryStateService.getStates(),
            addrCareOf: '',
            selectedState: {},
            nearAddresses: [],
            isExactAddr: '',
            selectedAddr: {},
            isEnteredAllAddsFields: true,
            disableSaveAddr: true,
            disableValidateAddr: false,
            totalDepositAmount: 0,
            gotCreditResponse: false,
            userData: {},
            isValidDob: true,
            dobMessage: '',
            addrPlaceholders: {},
            addrModels: {},
            addrTypeSelected: '',
            billingOpt: 'none',
            savedAddress: {},
            selectedOpt: 'none',
            disableDepositBtn: false,
            displayPaidDeposit: false,
            isPaymentSuccess: false,
            depositPaidDate: '',
            sessionId: '',
            pastDueAccs: [],
            displayPaidPastDue: false,
            disablePastDueBtn: false,
            paymentFailed: false,
            displayPaidPD: false,
            paymentFailedPD: false,
            paymentStatusPD: false,
            isPaymentSuccessPD: false,
            updateAppClicked: false,
            depositInstallmentObj: null,
            clickedAddress: {},
            billingType: '',
            disablePrepaidbtn: false,
            prepaidPaymentStatus: false,
            isPrepaidPaymentSuccess: false,
            displayPaidPrepaid: false,
            paymentFailedPrepaid: false
        };
    public visible: boolean = false;
    public postalAddressValidated: boolean = true;
    public addressNotValidatedMsg: string;
    public visibleDeposit: boolean;
    public visibleBalance: boolean;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public geoesAddressValidationError: string;
    public isDTV = false;
    public newDtv = false;
    public existingProductStore$: Observable<any>;
    public existingProductStoreSubscription: Subscription;
    public currentFlow = 'normal';
    public dtvForm: FormGroup;
    @ViewChild('ssnfield', { static: false, })
    private ssnfield: ElementRef;
    private reEntrant: boolean = false;
    public taskId: string = '';
    public paymentDone: boolean = false;
    private userPaidObj = null;
    public paymentUrl: string = `${env.DEPOSIT_AND_FINAL_BILL_URL}`;
    public orderRefNumber: string;
    private accountPassword: any;
    public reservedAppointment: any;
    public apptObservable: Observable<any>;
    public apptSubscription: Subscription;
    public isDtvSessionInfo: boolean = false;
    public isDtvOpus: any;
    @ViewChild('validateCreditModal', { static: false, }) public validateCreditModal: DialogComponent;
    @ViewChild('opusSessionInfoNotFound', { static: false, }) public opusSessionInfoNotFound: DialogComponent;
    private maxCreditCheckReached: boolean = false;
    private isOnHoldFlow: boolean = false;
    public onHoldCreditReviewOrderRefNo: string;
    public onHoldProcessInstanceId: string;
    private removedDTV: boolean = false;
    private accountPasswordPin: boolean;
    public sfcPaperlessFlag: boolean = false;
    public showHidePaymentProducts: boolean = false;
    public securitydiposit: any;
    public security: any;
    public profile: string;
    public bypassDepositUser: boolean = false;
    public sfcData: any;
    public emailAddrDeclinedManually: boolean = false;
    public accountForm_originalValues: any;
    public accountForm_currentValues: any;
    public accountForm_ValuesChanged: boolean = false;
    public isPrepaid: boolean = false;
    public QConnectResp: any;
    public QConnectErrTxt: boolean = false;
    public isUnameValid: boolean = false;
    public QcErrMsg: any;
    public isQcDown: boolean = false;
    public pastDueAmountExist: boolean = false;
    public finalBillforPostPaid: any;
    public prepaidAcctNumber: any;
    public firstMonthMRC: any = [];
    public firstMonthOTC: any = [];
    public firstMonthMRCTotal: number = 0;
    public firstMonthOTCTotal: number = 0;
    public prepaidFirstMonth: any;
    public invokeCallPrepaid: string;
    private dtvAccountInfoManuallyEntered: any = false;
    public existingProductData: any;
    public cResponsibility: boolean = false;
    public changeRes: string = "";
    public totalPastDueAmount: number = 0;
    public pastDueAmountBTNs: any[] = [];
    public totalCharges: any;
    public isUnameChanged: boolean = false;
    public validMail: any;
    public validUname: any;
    public prevUnameVal: any;
    public changedUnameVal: boolean = false;
    public currentUnameVal: any;
    public loadingonetime: boolean = false;
    public mrcTaxes: number = 0;
    public otcTaxes: number = 0;
    public isAmend: boolean = false;
    public isStack: boolean = false;
    public stackAmendDropDownTitle: string = '';
    public acctObsrb: Observable<AccountInfomation>;
    public acctSubscription;
    public refundAmtList: any = [];
    public newPmtList: any = [];
    public refundTotalAmt: number = 0;
    public refundTaxes: number = 0;
    public newPmtTaxes: number = 0;
    public newPmtTotalAmt: number = 0;
    public refundFlag: boolean = false;
    public newLPmtFLag: boolean = false;
    public creditCardNo: any;
    public effectiveBilldate:any;
    public effectiveBilldateNumber:any;

    constructor(
        private logger: Logger,
        private router: Router,
        private fb: FormBuilder,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private textMask: TextMaskService,
        private accountService: AccountService,
        private addressService: AddressService,
        private countryStateService: CountryStateService,
        private reviewOrderService: ReviewOrderService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private helperService: HelperService,
        private directvService: DirectvService) {

        this.user = <Observable<User>>store.select('user');
        this.phoneMask = this.textMask.getPhoneNumberMaskFormat();
        this.ssnMask = this.textMask.getSsnMask();
        this.appStateService.setLocationURLs();
        this.userSubscription = this.user.subscribe((data) => {
            this.isPrepaid = (data.prepaidFlag === 'PREPAID' || data.prepaidFlag) ? true : false;
            this.sfcData = data;
            this.isDtvOpus = data.isDtvOpus;
            this.currUrl = data.currentUrl;
            this.refObj.userData = cloneDeep(data);
            this.previousURL = data.previousUrl;
            if (data.previousUrl !== '/schedule-appt' && data.previousUrl !== '/schedule-appt-ship' && data.previousUrl === '/co-review-order') {
                this.reEntrant = true;
                this.taskId = data.taskId;
                this.store.dispatch({ type: 'ACCOUNT_REENTRANT', payload: this.reEntrant });
            }
            if (Array.isArray(data.currentSelected)) {
                data.currentSelected.forEach((val: any) => {
                    if (val.selected === GenericValues.cDTV) {
                        this.isDTV = true;
                    }
                });
                if (this.isDtvOpus) {
                    if (data.dtvOpus) {
                        if (data.dtvOpus.taskName === 'yes') {
                            this.newDtv = true;
                        }
                    }
                } else {
                    if (data.dtvQuestionForm) {
                        if (data.dtvQuestionForm.taskName === 'yes') {
                            this.newDtv = true;
                        }
                    }
                }
            }

            if (data.autoLogin !== null && data.autoLogin.sfcData !== undefined && data.autoLogin.sfcData !== null && !this.reEntrant) {
                if (data.autoLogin.sfcData.emailID !== null && data.autoLogin.sfcData.emailID !== undefined && data.autoLogin.sfcData.emailID.length > 0) {
                    if (!this.accountForm_ValuesChanged) {
                        this.autoLoginEmailAddress = data.autoLogin.sfcData.emailID;
                    }
                }
                if (!this.accountForm_ValuesChanged) {
                    if (!data.autoLogin.sfcData.isPrimaryPhoneSms) {
                        this.autoLoginPhoneNumber = '';
                    } else if (data.autoLogin.sfcData.contactNumber !== null && data.autoLogin.sfcData.contactNumber.length > 0 && !this.reEntrant) {
                        this.autoLoginPhoneNumber = data.autoLogin.sfcData.contactNumber;
                    }
                }
            }

            if (data && data.orderRefNumber) {
                this.orderRefNumber = data.orderRefNumber;
            }
        });

        this.acctObsrb = <Observable<any>>store.select('account');
        this.acctSubscription = this.acctObsrb.subscribe((acctData) => {
            if (this.isAmend && acctData.payload.accountInfo && acctData.payload.accountInfo.billingType === 'PREPAID') {
                this.isPrepaid = true;
            }
        });

        this.existingProductStore$ = <Observable<any>>store.select('existingProducts');
        this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
            this.existingProductData = respData;
            if (this.existingProductData && this.existingProductData.stackamend && this.existingProductData.stackamend.stackAmendFlag) {
                if (this.existingProductData.stackamend.stackAmendFlag === "amendOrder") {
                    this.isAmend = true;
                    this.stackAmendDropDownTitle = 'Amend Order';
                    this.isCreditChecked = true;
                } else if (this.existingProductData.stackamend.stackAmendFlag === "stackOrder") {
                    this.isStack = true;
                    this.stackAmendDropDownTitle = ' Stack Order';
                }
            }
            if (respData && respData.orderFlow && respData.orderFlow.flow) {
                this.currentFlow = respData.orderFlow.flow;
            }
            if (respData && respData.orderFlow && respData.orderFlow.type === 'fromHold') {
                this.isOnHoldFlow = true;
            }
        });

        this.creditRevObsv = <Observable<any>>this.store.select('creditReview');
        this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
            this.creditReviewResp = creditData;
            if (this.isCreditChecked) {
                this.creditReviewResp = creditData;
                this.creditObj = creditData.payload;
            }
        });

        if (this.reEntrant) {
            this.accountObservable = <Observable<any>>store.select('account');
            this.postalAddressValidated = true;
            this.accountSubscription = this.accountObservable.subscribe((respData) => {
                this.accInformation = respData;
                if (respData.isAuthorizedParties !== undefined && respData.isAuthorizedParties !== null) {
                    this.authUsers = respData.isAuthorizedParties;
                    this.authorizedParties = false;
                    this.oneAuthorzedParty = false;
                    if (this.authUsers[0].firstName !== "" || this.authUsers[1].firstName !== "") {
                        this.authorizedParties = true;
                    }
                    if (this.authUsers[0].firstName === "" || this.authUsers[1].firstName === "") {
                        this.oneAuthorzedParty = true;
                    }
                }
                this.refObj.addrTypeSelected = this.accInformation.payload.accountInfo.addressType;
                if (respData && respData.payload && respData.payload.accountPassword) {
                    this.accountPassword = respData.payload.accountPassword;
                }
                this.autoLoginEmailAddress = this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddress;
                if (this.autoLoginEmailAddress && this.autoLoginEmailAddress !== undefined) {
                    this.accInformation.payload.accountInfo.contact.emailAddrDeclined = false;
                }

                this.autoLoginPhoneNumber = this.accInformation.payload.accountInfo.contact.smsNumber;
                this.phoneNumber = this.accInformation.payload.accountInfo.contact.contactNumber;
                this.initializeData();
            });
            //this.accountSubscription.unsubscribe();
            this.refObj.gotCreditResponse = false;
            this.orderObservable = <Observable<Order>>store.select('order');
            this.orderSubscription = this.orderObservable.subscribe((orderData) => {
                if (orderData && orderData.payload && orderData.payload.accountInfo) {
                    this.accInformation =
                    {
                        orderRefNumber: orderData.orderRefNumber,
                        processInstanceId: orderData.processInstanceId,
                        taskId: this.refObj.userData.taskId,
                        taskName: 'Credit Review',
                        payload: orderData.payload.accountInfo
                    };
                }
            });

            this.creditRevObsv = <Observable<CreditCheck>>store.select('creditReview');
            this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                this.addlOrderAttributesDepositData = creditData.payload.addlOrderAttributes;
                if (this.isPrepaid && this.reEntrant) {
                    this.prepaidReEntrant(creditData);
                }
                this.isCreditChecked = true;
                this.accountRentrantValue = false;
                if (creditData.payload && creditData.payload.accountInfo && creditData.payload.accountInfo.ban) {
                    this.ban = creditData.payload.accountInfo.ban;
                }
                this.isCreditChecked = true;
                this.refObj.updateAppClicked = false;
                this.creditReviewResp = creditData;
                this.creditObj = creditData.payload;
                this.initCreditInfo();
                this.refObj.gotCreditResponse = true;
                if (!this.dhpPaymentDone && this.hsiPaymentDone && !this.allProductsPaid) {
                    this.refObj.disableDepositBtn = false;
                }
            });
            this.creditRevSubscription.unsubscribe();

        } else {
            this.accountObservable = <Observable<AccountInfomation>>store.select('account');
            this.accountSubscription = this.accountObservable.subscribe((respData) => {
                if (respData.isAuthorizedParties !== undefined && respData.isAuthorizedParties !== null) {
                    this.authUsers = respData.isAuthorizedParties;
                    this.authorizedParties = false;
                    this.oneAuthorzedParty = false;
                    if (this.authUsers[0].firstName !== "" || this.authUsers[1].firstName !== "") {
                        this.authorizedParties = true;
                    }
                    if (this.authUsers[0].firstName === "" || this.authUsers[1].firstName === "") {
                        this.oneAuthorzedParty = true;
                    }
                }
                this.accInformation = respData;
                if (this.autoLoginEmailAddress === null || this.autoLoginEmailAddress === undefined || this.autoLoginEmailAddress === "") {
                    if (this.isAmend && this.isPrepaid) {
                        this.autoLoginEmailAddress = this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddress;
                    } else {
                        this.autoLoginEmailAddress = this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress;
                    }
                }
                let existingObservable = <Observable<any>>store.select('existingProducts');
                existingObservable.subscribe(
                    (exist) => {
                        if (exist && exist.orderFlow && exist.orderFlow.type === 'fromHold' && exist.existingProductsAndServices && exist.existingProductsAndServices[0]
                            && exist.existingProductsAndServices[0].accountInfo) {
                            this.accInformation.payload = Object.assign({}, exist.existingProductsAndServices[0].accountInfo);
                            if (exist.pendingOrders && exist.pendingOrders[0] && exist.pendingOrders[0].orderDocument && exist.pendingOrders[0].orderDocument.addlOrderAttributes) {
                                this.addlOrderAttributesDepositData = exist.pendingOrders[0].orderDocument.addlOrderAttributes;
                            }
                            //Changes done as part of DE83185 fix as suggested by BM
                            if (Array.isArray(respData) && respData.length === 0) {
                                this.creditRevObsv = <Observable<CreditCheck>>store.select('creditReview');
                                this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                                    if (creditData) {
                                        this.isCreditChecked = true;
                                        this.accInformation.payload.billingAddress = creditData.payload.accountInfo.billingAddress;
                                    }
                                });
                                this.creditRevSubscription.unsubscribe();
                            }

                            this.store.dispatch({ type: 'ON_HOLD_FLOW_ACCOUNT_INFORMATION_PAYLOAD', payload: this.accInformation.payload });
                            this.initializeData();
                        } else {
                            this.initializeData();
                        }
                    });
            });

        }

        this.apptObservable = <Observable<any>>this.store.select('appointment');
        this.apptSubscription = this.apptObservable.subscribe((data) => {
            if (data.reservedAppointment) {
                this.reservedAppointment = data.reservedAppointment;
            } else if (data.payload && data.payload.dueDate && data.payload.dueDate.finalDueDate) {
                this.reservedAppointment = data.payload.dueDate.finalDueDate;
            }
        });

        this.retainObservable = <Observable<any>>this.store.select("retain");
        this.retainSubscription = this.retainObservable.subscribe(response => {
            this.retainObservableData = response;
            if (response.removedDTV) {
                this.removedDTV = response.removedDTV;
            }
            this.changeRes = response.cResponsibility ? response.cResponsibility : "";
            this.bypassButtonSelected = response.bypassvalue ? response.bypassvalue : false;

        });

        this.store.dispatch({ type: 'UPDATE_USER', payload: this.sfcData });

        this.accountForm && this.accountForm.valueChanges.subscribe(changedValue => {

            if (!this.accountForm.dirty) {
                this.accountForm_originalValues = JSON.stringify(this.accountForm.value);
            }
            if (this.accountForm.dirty) {
                this.accountForm_currentValues = JSON.stringify(this.accountForm.value);
            }
            if (this.accountForm_originalValues !== this.accountForm_currentValues) {
                this.accountForm_ValuesChanged = true;
            }

        });
    }
    private prepaidReEntrant(creditData: CreditCheck) {
        this.creditObj = creditData.payload;
        this.getPaymentAdjustInfo();
    }

    public ngOnInit() {
        this.logger.metrics('AccountPPAmendPage');
        this.getPaymentAdjustInfo();
        if (this.isAmend && this.isPrepaid && this.accRespObj && !this.accRespObj.billingAddress) {
            this.accRespObj.billingAddress = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
        }
        this.bypassDepositUser = this.helperService.isAuthorized(ProfileEnums.BYPASS_SECURITY_DEPOSIT);
        this.userdata = <Observable<User>>this.store.select('user');
        this.userSubscription$ = this.userdata.subscribe(
            (userdata) => {
                if (!this.reEntrant) {
                    if (!this.accountForm_ValuesChanged && userdata && userdata.autoLogin && userdata.autoLogin.sfcData && userdata.autoLogin.sfcData.emailID === '') {
                        //this.contactDet.emailAddrDeclined = true;
                        this.accountForm.controls['emailAddress'].setValue('');
                        this.autoLoginEmailAddress = "";
                        this.emailPlaceHolder = 'Not provided';
                    } else {
                        if (!this.emailAddrDeclinedManually && userdata && userdata.autoLogin && userdata.autoLogin.sfcData && userdata.autoLogin.sfcData !== null && userdata.autoLogin.sfcData !== undefined && userdata.autoLogin.sfcData.emailID && userdata.autoLogin.sfcData.emailID !== undefined && userdata.autoLogin.sfcData.emailID !== null) {
                            this.contactDet.emailAddrDeclined = false;
                            if (userdata && userdata.emailAddress) {
                                this.autoLoginEmailAddress = userdata.emailAddress;
                            } else {
                                this.autoLoginEmailAddress = (this.accInformation && this.accInformation.contact && this.accInformation.contact.emailAddress) ? this.accInformation.contact.emailAddress : userdata.autoLogin.sfcData.emailID;
                            }
                        }
                    }
                }
                this.isPrepaid = (userdata.prepaidFlag === 'PREPAID' || userdata.prepaidFlag) ? true : false;
            });

        this.store.dispatch({ type: 'TASK_NAME', payload: "Account Information" });
        window.scroll(0, 0);
        this.dtvForm = this.fb.group({
            'dtvAccNo': ['']
        });
        this.accountForm && this.accountForm.get('emailAddress').valueChanges.debounceTime(750).subscribe((values) => {
            let isValidMail = Validations.emailValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress });
            if (!isValidMail) {
                this.refObj.isEmailValid = true;
            } else {
                this.refObj.isEmailValid = false;
            }
        });
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((respData) => {
            if (respData.dtvAccountInfo) {
                this.dtvAccountInfoManuallyEntered = respData.dtvAccountInfo;
            }
            if (respData && respData.accountreentrant !== undefined && respData.accountreentrant) {
                this.accountRentrantValue = respData.accountreentrant;
            }
            if (respData.dtvSessionInfo && respData.dtvSessionInfo.payload) {
                this.isDtvSessionInfo = true;
            }
            if (respData.maxCreditCheckReached) {
                this.maxCreditCheckReached = respData.maxCreditCheckReached;
                if (this.maxCreditCheckReached) { this.refObj.dobEntered = true; }
            }
            if (respData.accInformationPayload) {
                this.accInformation.payload = respData.accInformationPayload;
                if (this.accInformation.payload.contact) {
                    this.accInformation.contact = this.accInformation.payload.contact;
                }
                this.refObj.dobEntered = true;
                this.initializeData();
            }
        });

        if (this.accountRentrantValue && this.refObj.userData.previousUrl !== '/co-review-order' && !this.reEntrant) {
            if (this.accountRentrantValue && this.accInformation && !this.accInformation.billingaddr && this.accRespObj && this.accRespObj.billingAddress) {
                this.accInformation.billingaddr = this.accRespObj && this.accRespObj.billingAddress ? this.accRespObj.billingAddress :
                    this.accInformation && this.accInformation.payload && this.accInformation.payload.billingaddr;
            }
            if (this.accInformation && this.accInformation !== undefined && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact !== undefined) {
                this.autoLoginEmailAddress = this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddress;

                if (this.sfcData.isPrimaryPhoneSms === false) {
                    this.autoLoginPhoneNumber = '';
                } else if (this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.smsNumber) {
                    this.autoLoginPhoneNumber = this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.smsNumber;
                }
                this.autoLoginEmailAddress = this.accInformation && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddress;

                this.phoneNumber = this.accInformation.contact.contactNumber;
                if (this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddrDeclined) {
                    this.contactDet.emailAddrDeclined = true;
                    this.accountForm.controls['emailAddress'].setValue('');
                    this.autoLoginEmailAddress = "";
                    this.emailPlaceHolder = 'Not provided';

                } else {
                    this.contactDet.emailAddrDeclined = false;
                    this.autoLoginEmailAddress = this.accInformation && this.accInformation.payload && this.accInformation.payload.accountInfo && this.accInformation.payload.accountInfo.contact && this.accInformation.payload.accountInfo.contact.emailAddress;
                }
            }
            this.refObj.addrTypeSelected = this.accInformation.addressType;
            this.refObj.savedAddress = this.accInformation.billingaddr;
            if (this.accInformation.accountReqDetails && this.accInformation.accountReqDetails !== undefined) {
                if (this.accInformation.accountReqDetails.paperlessBilling) { this.refObj.billingOpt = 'paperless'; }
                if (this.accInformation.accountReqDetails.spanishBillPrint) { this.refObj.billingOpt = 'spanish'; }
                if (this.accInformation.accountReqDetails.largePrint) { this.refObj.billingOpt = 'large'; }
                if (this.accInformation.accountReqDetails.braille) { this.refObj.billingOpt = 'braille'; }
                this.accountObj.accountPreferences.noDirectMail = this.accInformation.accountReqDetails.noDirectMail;
                this.accountObj.accountPreferences.noEmail = this.accInformation.accountReqDetails.noEmail;
                this.accountObj.accountPreferences.noTeleMarketing = this.accInformation.accountReqDetails.noTeleMarketing;
                if (this.accInformation.accountReqDetails.textNotification &&
                    this.accInformation.accountReqDetails.emailNotification) {
                    if (this.accInformation.accountReqDetails.textNotification.billingNotification &&
                        this.accInformation.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(0);
                    }
                    else if (this.accInformation.accountReqDetails.textNotification.billingNotification && !this.accInformation.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(2);
                    }
                    else if (this.accInformation.accountReqDetails.emailNotification.billingNotification && !this.accInformation.accountReqDetails.textNotification.billingNotification) {
                        this.setBillingNotification(1);
                    }
                    else {
                        this.setBillingNotification(3);
                        this.refObj.billingChk = false;
                    }

                    if (this.accInformation.accountReqDetails.textNotification.orderingNotification &&
                        this.accInformation.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(0);
                    }

                    else if (this.accInformation.accountReqDetails.textNotification.orderingNotification && !this.accInformation.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(2);
                    }
                    else if (this.accInformation.accountReqDetails.emailNotification.orderingNotification && !this.accInformation.accountReqDetails.textNotification.orderingNotification) {
                        this.setOrderNotification(1);
                    }
                    else {
                        this.setOrderNotification(3);
                        this.refObj.orderChk = false;
                    }

                    if (this.accInformation.accountReqDetails.textNotification.repairNotification &&
                        this.accInformation.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(0);
                    }

                    else if (this.accInformation.accountReqDetails.textNotification.repairNotification && !this.accInformation.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(2);
                    }
                    else if (this.accInformation.accountReqDetails.emailNotification.repairNotification && !this.accInformation.accountReqDetails.textNotification.repairNotification) {
                        this.setRepairCheckNotification(1);
                    }
                    else {
                        this.setRepairCheckNotification(3);
                        this.refObj.repairChk = false;
                    }
                    this.refObj.billingOptions[0]['disable'] = false;
                    this.refObj.billingOptions[1]['disable'] = false;
                    this.refObj.billingOptions[2]['disable'] = false;
                }
            }
            this.creditRevObsv = <Observable<any>>this.store.select('creditReview');
            this.creditRevSubscription = this.creditRevObsv.subscribe((creditData) => {
                if (this.isPrepaid) { this.prepaidReEntrant(creditData); }
                if (creditData.creditreviewdepositdata && creditData.creditreviewdepositdata !== undefined && creditData.creditreviewdepositdata.payload && creditData.creditreviewdepositdata.payload !== undefined) {
                    this.addlOrderAttributesDepositData = creditData.creditreviewdepositdata.payload.addlOrderAttributes;
                    this.depositInfo = creditData.creditreviewdepositdata.payload.depositInfo;
                    this.onHoldCreditReviewOrderRefNo = creditData.creditreviewdepositdata.orderRefNumber;
                    this.onHoldProcessInstanceId = creditData.creditreviewdepositdata.processInstanceId;
                    this.isCreditChecked = true;
                    let hsiPayment;
                    let potsPayment;
                    if (this.addlOrderAttributesDepositData && this.addlOrderAttributesDepositData !== undefined && this.addlOrderAttributesDepositData[0] && this.addlOrderAttributesDepositData[0].orderAttributeGroup) {
                        this.addlOrderAttributesDepositData[0].orderAttributeGroup.map(depositData => {
                            if (depositData && depositData.orderAttributeGroupName === "depositData") {
                                depositData.orderAttributeGroupInfo.map(paymentData => {
                                    if (paymentData && paymentData.orderAttributes[0].orderAttributeValue === "INTERNET") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.hsiPaymentDone = true;
                                            hsiPayment = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.hsiPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                            hsiPayment = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.hsiRefundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                    if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-HP") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.potsPaymentDone = true;
                                            potsPayment = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.potsPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                            potsPayment = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.potsRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                    if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-DHP") {
                                        if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                                            this.dhpPaymentDone = true;
                                            potsPayment = true;
                                        } else {
                                            this.allProductsPaid = false;
                                            this.dhpPaymentDone = false;
                                            this.refObj.disableDepositBtn = false;
                                        }
                                        if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                                            this.dhpRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                                        }
                                    }
                                });
                            }
                        });
                    }
                    if (this.isCreditChecked) {
                        this.refObj.updateAppClicked = false;
                        this.creditReviewResp = creditData;
                        this.creditObj = creditData.payload;
                        this.isPrepaid ? this.initCreditPrepaidInfo() : this.initCreditInfo();
                        this.refObj.gotCreditResponse = true;
                        this.products = this.depositInfo && this.depositInfo.products;
                        // if (this.products) this.calculateTotalDeposit();
                    }
                    if (!this.dhpPaymentDone && this.hsiPaymentDone && !this.allProductsPaid) {
                        this.refObj.disableDepositBtn = false;
                    }
                }
            });

        }
        if (!this.reEntrant && !this.accountRentrantValue) {
            this.phoneNumber = this.refObj.userData.phoneNumber;
            if (this.autoLoginEmailAddress !== '' && this.autoLoginPhoneNumber !== '') {
                this.refObj.billingOptions[0]['disable'] = false;
                this.setDefaultNotification(0);
            } else if (this.autoLoginEmailAddress !== '' && this.autoLoginPhoneNumber === '') {
                this.refObj.billingOptions[1]['disable'] = false;
                this.setDefaultNotification(1);
            } else if (this.autoLoginEmailAddress === '' && this.autoLoginPhoneNumber !== '') {
                this.refObj.billingOptions[2]['disable'] = false;
                this.setDefaultNotification(2);
            }
        }

        if (this.accRespObj && this.accRespObj.billingAddress !== null && this.accRespObj.billingAddress !== undefined && !this.accRespObj.billingAddress.isValidated && !this.reEntrant) {
            this.postalAddressValidated = false;
        }
        this.changedUnameVal = false;
        this.isUnameChanged = false;
        this.currentUnameVal = '';
        this.QConnectErrTxt = false;
        this.accountForm && this.accountForm.get('username').valueChanges.subscribe(uname => {
            if (uname !== '' && uname.length >= 6 && uname !== this.prevUnameVal) {
                this.changedUnameVal = true;
                this.currentUnameVal = uname;
                this.isUnameChanged = true;
            } else {
                this.QConnectErrTxt = true;
                this.QcErrMsg = "Enter a valid username.";
                this.isUnameChanged = false;
            }
        });
        if( this.isPrepaid) {
            this.getEffectiveBilldate();
        }
    }

    public disabledContinue() {
        if (this.isPrepaid && (!this.refObj.isEmailValid)) {
            return true;
        } else {
            return false;
        }

    }

    public ngAfterViewInit() {
        if (this.retainSSN !== undefined && this.retainSSN !== null && this.previousURL !== '/review-order') {
            this.ssnfield && this.ssnfield !== undefined && this.ssnfield.nativeElement !== undefined && this.ssnfield.nativeElement.focus();
        }
        if (this.accRespObj) {
            this.accRespObj.accountPassword = this.accountPassword;
        }
    }
    /** Initialize new account page data, after getting response */
    public initializeData() {
        if (this.currentFlow !== 'Change' || (this.currentFlow === 'Change' && this.isPrepaid && this.isAmend)) {
            this.accountObj.orderRefNumber = this.accInformation.orderRefNumber;
            this.accountObj.taskId = this.accInformation.taskId;
            this.accountObj.processInstanceId = this.accInformation.processInstanceId;
            this.accountObj.taskName = this.accInformation.taskName;
            this.accRespObj = this.accInformation.payload;
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.personalDetails && this.accRespObj.personalDetails !== undefined) {
                this.personalDet = this.accRespObj.personalDetails;
            } else {
                this.personalDet = this.accInformation.personaldetails;
            }
            if (
                this.accRespObj &&
                this.accRespObj !== undefined &&
                this.accRespObj.loginDetails &&
                this.accRespObj.loginDetails !== undefined) {
                this.loginDetails = this.accRespObj.loginDetails;
            }
            if (this.personalDet && this.personalDet !== undefined && this.personalDet.underAgeAck !== undefined && this.personalDet.underAgeAck) {
                this.personalDet.underAgeAck = false;
            }
            if (this.isOnHoldFlow && this.isCreditChecked && this.personalDet && this.personalDet !== undefined) {
                this.personalDet.creditCheck = true;
            }
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.accountInfo.contact && this.accRespObj.accountInfo.contact !== undefined) {
                this.contactDet = this.accRespObj.accountInfo.contact;
            } else {
                this.contactDet = this.accInformation.payload.accountInfo.contact;

            }
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.billingAddress && this.accRespObj.billingAddress !== undefined) {
                if (this.accRespObj.billingAddress.stateOrProvince === null && this.accInformation &&
                    this.accInformation.billingaddr) {
                    this.accRespObj.billingAddress = this.accInformation.billingaddr;
                }

            }
            if (!this.accountRentrantValue) {
                if (this.isPrepaid && this.isAmend) {
                    this.refObj.savedAddress = this.accRespObj.accountInfo && this.accRespObj.accountInfo.billingAddress;
                    this.billingAddr = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
                    this.serviceAddress = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
                } else {
                    this.refObj.savedAddress = this.accRespObj.billingAddress;
                    this.billingAddr = Object.assign({}, this.accRespObj.billingAddress);
                    this.serviceAddress = Object.assign({}, this.accRespObj.billingAddress);
                }
            }

            if (!this.isServiceAddressInitialized) {
                this.initialServiceAddress = Object.assign({}, this.serviceAddress);
                this.isServiceAddressInitialized = true;
            }
            let lzipcode: string;
            if (this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode !== undefined && this.billingAddr.postCode && this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix) {
                lzipcode = this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix;
            } else if (this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode && (this.billingAddr.postCodeSuffix === '' || this.billingAddr.postCodeSuffix === undefined)) {
                lzipcode = this.billingAddr.postCode;
            } else {
                lzipcode = '';
            }
            this.accountForm = this.fb.group({
                firstName: [this.refObj.userData.firstName,
                [Validators.required, <any>Validations.nameValidator]],
                lastName: [this.refObj.userData.lastName, [Validators.required, Validations.nameValidator]],
                middleName: this.refObj.userData.middleName ?
                    [this.refObj.userData.middleName, [Validations.nameValidator]] :
                    ['', [Validations.nameValidator]],
                contactNumber: this.refObj.userData.phoneNumber ?
                    [this.refObj.userData.phoneNumber, [Validators.required, Validations.phoneValidator]] :
                    [this.contactDet.contactNumber, [Validators.required, Validations.phoneValidator]],
                smsNumber: this.contactDet && this.contactDet.smsNumber ? [this.contactDet && this.contactDet.smsNumber,
                [Validations.phoneValidator]] :
                    ['', [Validations.phoneValidator]],
                emailAddress: this.contactDet && this.contactDet.emailAddress ?
                    [this.contactDet && this.contactDet.emailAddress, [Validations.emailValidator]] :
                    ['', [Validations.emailValidator]],
                zipCode: [lzipcode, Validations.zipCodeValidator],
                zipCodeInt: [(this.billingAddr && this.billingAddr !== undefined && this.billingAddr.postCode !== undefined && this.billingAddr.postCode) ? this.billingAddr.postCode : '', Validations.zipCodeValidatorInt],
                ssnNumber: [(this.personalDet && this.personalDet !== undefined && this.personalDet.ssn !== undefined && this.personalDet.ssn) ? this.personalDet.ssn : (this.retainSSN !== undefined && this.retainSSN !== null) ? this.retainSSN : '', [Validators.required]],
                dlNumber: [(this.personalDet && this.personalDet !== undefined && this.personalDet.dLlicenseNo !== undefined && this.personalDet.dLlicenseNo) ? this.personalDet.dLlicenseNo : ''],
                dLlicenseState: [this.personalDet && this.personalDet.dLlicenseState, Validators.required],
                username: this.isPrepaid ? this.uName : ''
            });
            if (this.accountForm.value.contactNumber && this.accountForm.value.contactNumber !== "") {
                if (this.phoneNumber !== "") {
                    this.accountForm.controls['contactNumber'].setValue(this.phoneNumber);
                }
                else {
                    this.phoneNumber = this.accountForm.value.contactNumber;
                    this.accountForm.controls['contactNumber'].setValue(this.phoneNumber);
                }
            }
            this.isInitializedFormObj = true;
            if (this.contactDet && this.contactDet.emailAddrDeclined) {
                this.accountForm.controls['emailAddress'].setValue('');
                this.emailPlaceHolder = 'Not provided';
            }

            if (this.autoLoginEmailAddress) {
                this.accountForm.controls['emailAddress'].setValue(this.autoLoginEmailAddress);
            }
            if (this.accRespObj && this.accRespObj !== undefined && this.accRespObj.accountInfo.accountPreferences && this.accRespObj.accountInfo.accountPreferences !== undefined) {
                let loc: AccountPreferences = this.accRespObj.accountInfo.accountPreferences;
                Object.keys(loc).forEach((key) => {
                    if (key !== 'emailNotification' && key !== 'textNotification' && loc[key] === null) {
                        loc[key] = false;
                    }
                });
                this.accountObj.accountPreferences = loc;
            }

            /** If no email, set billing options to SMS */
            if (!(this.contactDet && this.contactDet.emailAddress) && !this.autoLoginEmailAddress) {
                this.refObj.billingOptions[1]['disable'] = true;
                this.refObj.billingOptions[0]['disable'] = true;
                let isValidMail = Validations.emailValidator({ value: this.autoLoginEmailAddress });
                if (!isValidMail) {
                    this.refObj.isEmailValid = true;
                } else {
                    this.refObj.isEmailValid = false;
                }
                this.setDefaultNotification(2);
            }
            /* If no smsNumber & valid email is present set billing options to Email,
            * else set to "Do not notify" */
            if (!(this.contactDet && this.contactDet.smsNumber) && !this.autoLoginPhoneNumber) {
                this.refObj.billingOptions[2]['disable'] = true;
                this.refObj.billingOptions[0]['disable'] = true;
                this.setDefaultNotification(3);
                this.refObj.isEmailValid ? this.setDefaultNotification(1) : this.setDefaultNotification(3);
            }
            if (this.personalDet && this.personalDet.dateOfBirth) {
                let dateParts = this.personalDet.dateOfBirth.split('-');
                this.refObj.day = dateParts[2];
                this.refObj.month = dateParts[1];
                this.refObj.year = dateParts[0];
                this.refObj.dobEntered = true;
                this.getAge();
            }
            let prevyr = (new Date().getFullYear() - 1).toString();
            this.refObj.yrpatrn = '19[0-9][0-9]|200[0-9]|20[1-' + prevyr.substr(2, 1) + '][0-' + prevyr.substr(3, 1) + ']';
            if (this.personalDet && this.personalDet.ssn && this.personalDet.ssn !== null && this.personalDet.ssn !== '') {
                this.refObj.enteredSsn = true;
            }
            this.checkEnteredDL();
            //this.store.dispatch({ type: 'ACCOUNT_PREFERENCES_DETAILS', payload: this.accRespObj.accountInfo.accountPreferences });
            if (this.reEntrant && !this.isOnHoldFlow) {
                this.postalAddressValidated = true;
                this.accountObservable = <Observable<AccountInfomation>>this.store.select('account');
                this.accountSubscription = this.accountObservable.subscribe((data) => {
                    this.accountRentrantValues = data;
                });
                this.contactDet = this.accountRentrantValues.payload.accountInfo.contact;

                if (!(this.contactDet && this.contactDet.emailAddrDeclined)) {
                    this.autoLoginEmailAddress = this.accountRentrantValues && this.accountRentrantValues.payload && this.accountRentrantValues.payload.accountInfo && this.accountRentrantValues.payload.accountInfo.contact && this.accountRentrantValues.payload.accountInfo.contact.emailAddress;
                } else {
                    this.autoLoginEmailAddress = "";
                    this.emailPlaceHolder = 'Not provided';
                }
                /*this.accountRentrantValues.accountReqDetails.paperlessBilling ? this.refObj.billingOpt = 'paperless' : 'none';
                this.accountRentrantValues.accountReqDetails.spanishBillPrint ? this.refObj.billingOpt = 'spanish' : 'none';
                this.accountRentrantValues.accountReqDetails.largePrint ? this.refObj.billingOpt = 'large' : 'none';
                this.accountRentrantValues.accountReqDetails.braille ? this.refObj.billingOpt = 'braille' : 'none';
                this.accountObj.accountPreferences.noDirectMail = this.accountRentrantValues.accountReqDetails.noDirectMail;
                this.accountObj.accountPreferences.noEmail = this.accountRentrantValues.accountReqDetails.noEmail;
                this.accountObj.accountPreferences.noTeleMarketing = this.accountRentrantValues.accountReqDetails.noTeleMarketing;
                */
                if (this.accountRentrantValues.accountReqDetails && this.accountRentrantValues.accountReqDetails.textNotification &&
                    this.accountRentrantValues.accountReqDetails.emailNotification) {
                    if (this.accountRentrantValues.accountReqDetails.textNotification.billingNotification &&
                        this.accountRentrantValues.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(0);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.textNotification.billingNotification && !this.accountRentrantValues.accountReqDetails.emailNotification.billingNotification) {
                        this.setBillingNotification(2);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.emailNotification.billingNotification && !this.accountRentrantValues.accountReqDetails.textNotification.billingNotification) {
                        this.setBillingNotification(1);
                    }
                    else {
                        this.setBillingNotification(3);
                        this.refObj.billingChk = false;
                    }
                    if (this.accountRentrantValues.accountReqDetails.textNotification.orderingNotification &&
                        this.accountRentrantValues.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(0);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.textNotification.orderingNotification && !this.accountRentrantValues.accountReqDetails.emailNotification.orderingNotification) {
                        this.setOrderNotification(2);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.emailNotification.orderingNotification && !this.accountRentrantValues.accountReqDetails.textNotification.orderingNotification) {
                        this.setOrderNotification(1);
                    }
                    else {
                        this.setOrderNotification(3);
                        this.refObj.orderChk = false;
                    }
                    if (this.accountRentrantValues.accountReqDetails.textNotification.repairNotification &&
                        this.accountRentrantValues.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(0);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.textNotification.repairNotification && !this.accountRentrantValues.accountReqDetails.emailNotification.repairNotification) {
                        this.setRepairCheckNotification(2);
                    }
                    else if (this.accountRentrantValues.accountReqDetails.emailNotification.repairNotification && !this.accountRentrantValues.accountReqDetails.textNotification.repairNotification) {
                        this.setRepairCheckNotification(1);
                    }
                    else {
                        this.setRepairCheckNotification(3);
                        this.refObj.repairChk = false;
                    }
                }

            }
        }
    }

    /** Set Billing Option display */
    public setDefaultNotification(index) {
        this.refObj.billingChk ? this.refObj.billingOption = this.refObj.billingOptions[index] : this.refObj.billingOption = this.refObj.billingOptions[3];
        this.refObj.orderChk ? this.refObj.orderOption = this.refObj.billingOptions[index] : this.refObj.orderOption = this.refObj.billingOptions[3];
        this.refObj.repairChk ? this.refObj.repairOption = this.refObj.billingOptions[index] : this.refObj.repairOption = this.refObj.billingOptions[3];
    }

    public setBillingNotification(index) {
        this.refObj.billingOption = this.refObj.billingOptions[index];
    }

    public setOrderNotification(index) {
        this.refObj.orderOption = this.refObj.billingOptions[index];
    }

    public setRepairCheckNotification(index) {
        this.refObj.repairOption = this.refObj.billingOptions[index];
    }

    public billingOptClickHandler(currentOpt, previousOpt) {
        if (currentOpt !== previousOpt) {
            this.refObj.billingOpt = currentOpt;
            this.refObj.selectedOpt = currentOpt;
        }
    }

    /** Not using uncheck function */
    public uncheck(value: string) {
        if (this.refObj.billingOption === this.refObj.billingOptions[3] || this.refObj.orderOption === this.refObj.billingOptions[3] || this.refObj.repairOption === this.refObj.billingOptions[3]) {
            switch (value) {
                case 'billing': this.refObj.billingOption = this.refObj.billingOptions[3] ? this.refObj.billingChk = false && this.refObj.billingOption === this.refObj.billingOptions[3] : this.refObj.billingChk;
                    break;
                case 'ordering': this.refObj.orderOption = this.refObj.billingOptions[3] ? this.refObj.orderChk = false && this.refObj.orderOption === this.refObj.billingOptions[3] : this.refObj.orderChk;
                    break;
                case 'repair': this.refObj.repairOption = this.refObj.billingOptions[3] ? this.refObj.repairChk = false && this.refObj.repairOption === this.refObj.billingOptions[3] : this.refObj.repairChk;
                    break;
            }
        }
    }

    public unCheck(proactiveName) {
        if (proactiveName === 'billing') {
            this.refObj.billingOption === this.refObj.billingOptions[3] ? this.refObj.billingChk = false : this.refObj.billingChk = true;
        }
        if (proactiveName === 'ordering') {
            this.refObj.orderOption === this.refObj.billingOptions[3] ? this.refObj.orderChk = false : this.refObj.orderChk = true;
        }
        if (proactiveName === 'repair') {
            this.refObj.repairOption === this.refObj.billingOptions[3] ? this.refObj.repairChk = false : this.refObj.repairChk = true;
        }
    }

    /**
     * Validate entered email & smsNumber. Based on valid fields set billing options
     *  & disable remaining options
     */
    public emailPlaceHolder: string;
    public notificationValidation() {
        this.billingOptionValidation();
    }

    public billingOptionValidation() {
        let isValidMail = Validations.emailValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress });
        let isValidPh = Validations.phoneValidator({ value: this.accountForm && this.accountForm.value && this.accountForm.value.smsNumber });
        if (isValidMail || isValidPh) {
            this.refObj.billingOptions[0]['disable'] = true;
        } else {
            this.refObj.billingOptions[0]['disable'] = false;
        }
        if (!isValidMail) {
            this.refObj.billingOptions[1]['disable'] = false;
            this.refObj.isEmailValid = true;
            this.setDefaultNotification(1);
        } else {
            this.refObj.billingOptions[1]['disable'] = true;
            this.refObj.isEmailValid = false;
        }
        if (!isValidPh) {
            this.refObj.billingOptions[2]['disable'] = false;
            this.refObj.isEmailValid === true ? this.setDefaultNotification(0) : this.setDefaultNotification(2);
        } else {
            this.refObj.billingOptions[2]['disable'] = true;
            this.refObj.isEmailValid === true ? this.setDefaultNotification(1) : this.setDefaultNotification(3);
        }
    }
    /** Get States from countryStateService */
    public getStates() {
        this.refObj.stateCountries = this.countryStateService.getStates();
        this.refObj.stateCountries.splice(0, 0, { stateName: 'Select State', stateCode: '' });
        let stateObj = (this.accountRentrantValue && !this.reEntrant) ? (this.refObj.stateCountries.find((obj) =>
            obj.stateCode === this.accInformation.billingaddr.stateOrProvince
        )) : (this.refObj.stateCountries.find((obj) =>
            obj.stateCode === this.accRespObj.billingAddress.stateOrProvince
        ));
        stateObj ? this.refObj.selectedState = stateObj : this.refObj.selectedState = { stateName: 'Select State', stateCode: '' };
    }

    public checkUpdatedOtc(data) {
        this.otcUpdated = data;
    }

    /** Get MilitaryStates from countryStateService */
    public getMilitaryState() {
        this.refObj.stateCountries = this.countryStateService.getMilitaryStates();
        this.refObj.stateCountries.splice(0, 0, { militaryStateName: 'Select Armed Forces Location', militaryStateCode: '' });
        let armyLoc = (this.accountRentrantValue && !this.reEntrant) ? this.refObj.stateCountries.find((obj) =>
            obj.militaryStateCode === this.accInformation.billingaddr.stateOrProvince) : this.refObj.stateCountries.find((obj) =>
                obj.militaryStateCode === (this.reEntrant ? this.accRespObj.billingAddress.stateOrProvince : (this.accRespObj.billingAddress.armedForceLoc ? this.accRespObj.billingAddress.armedForceLoc : this.accRespObj.billingAddress.stateOrProvince))
            );
        armyLoc ? this.refObj.selectedState = armyLoc : this.refObj.selectedState = this.refObj.stateCountries[0];
    }

    /** Get Countries from countryStateService */
    public getCountries() {
        this.loading = true;
        let countryListReq = {
            "inputAttribute": [
                {
                    "attributeName": "dataType",
                    "attributeValue": [
                        "countryList"
                    ]
                }
            ],
            "outputAttribute": [
                {
                    "attributeName": "countryISOCode"
                },
                {
                    "attributeName": "countryName"
                }
            ],
            "requestDate": "",
            "ruleId": "100"
        };

        let countryRes = '';
        let countryResObj: any = '';
        this.logger.log("info", "account.component.ts", "getInternationalBillingCountryListRequest", JSON.stringify(countryListReq));
        this.logger.startTime();
        this.accountService.getInternationalBillingCountryList(countryListReq)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListResponse", error);
                this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(error._body);
            })
            .subscribe(data => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "getInternationalBillingCountryListResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                countryRes = JSON.stringify(data);
                countryResObj = JSON.parse(countryRes);
                let countryResAry = [];
                countryResAry = countryResObj.outputAttribute;
                let countryAry = [];
                for (var i = 0, len = countryResAry.length; i < len; i++) {
                    let countr = {};
                    countr['countryCode'] = countryResAry[i][0];
                    countr['countryName'] = countryResAry[i][1];
                    countryAry.push(countr);
                }

                this.refObj.stateCountries = countryAry;
                this.refObj.stateCountries.splice(0, 0, { countryName: 'Select Country', countryCode: '' });
                let country = this.refObj.stateCountries.find((obj) =>
                    obj.countryCode === this.accRespObj.billingAddress.country
                );
                if (this.refObj.addrModels.field1 === "") {
                    this.refObj.selectedState = this.refObj.stateCountries[0];
                    this.accountForm.patchValue({ zipCodeInt: '' });

                } else {
                    country ? this.refObj.selectedState = country : this.refObj.selectedState = this.refObj.stateCountries[0];
                }
                this.loading = false;
            },
                (error) => {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListResponse", error);
                    this.logger.log("error", "account.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    if (error === undefined || error === null) {
                        return;
                    }
                    try {
                        this.apiResponseError = JSON.parse(error);
                    } catch (e) {
                        if (error.status === 500) {
                            let lAPIErrorLists: APIErrorLists = {
                                errorResponse: [{
                                    statusCode: "500",
                                    reasonCode: "500",
                                    message: "500 Internal Server Error",
                                    messageDetail: "Discount compatibility error",
                                    source: "",
                                    timestamp: "",
                                    orderRefNumber: "",
                                    serverDown: "",
                                    tnNotFound: "",
                                    tnNotAvail: ""
                                }]
                            };
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        } else {
                            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                            this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                        }
                    }
                    if (this.apiResponseError && this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                        this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", this.apiResponseError);
                    } else {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Closer & Promos Compatibility", "closers-promos.component.ts", "Closer & Promos Page", lAPIErrorLists);
                    }
                });
    }

    /** Change billing address click handler */
    public handleChangeAddr() {
        this.refObj.changeAddrClicked = true;
        if (this.refObj.addrTypeSelected) {
            this.refObj.addrTypeSelected = this.refObj.addrTypeSelected;
        } else if (this.refObj.addrTypeSelected === '' || this.refObj.addrTypeSelected === null || this.refObj.addrTypeSelected === undefined) {
            this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
        } else if (this.accRespObj.billingAddress.addressTypeSelected) {
            this.refObj.addrTypeSelected = this.accRespObj.billingAddress.addressTypeSelected;
        } else if (this.accRespObj.billingAddress.subAddress && (this.accRespObj.billingAddress.subAddress.combinedDesignator !== null || this.accRespObj.billingAddress.subAddress.combinedDesignator !== undefined || this.accRespObj.billingAddress.subAddress.combinedDesignator !== '')) {
            this.accRespObj.billingAddress.addressTypeSelected = this.refObj.addressTypes[1];
            this.refObj.addrTypeSelected = this.refObj.addressTypes[1];
        } else {
            this.accRespObj.billingAddress.addressTypeSelected = this.refObj.addressTypes[0];
            this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
        }
        this.refObj.initialAddrType = this.refObj.addrTypeSelected;
        this.addressTypeSelectionHandler();
    }

    /** Change billing address, different address type selection handler */
    public addressTypeSelectionHandler() {
        if (this.apiResponseError && this.apiResponseError.errorResponse[0]) {
            this.apiResponseError.errorResponse[0].messageDetail = '';
        }
        this.billingAddr = {
            city: '', street: '', addressLine: '', stateOrProvince: '',
            streetType: '', addressTypeSelected: this.refObj.addrTypeSelected
        };
        if (this.isAmend && this.isPrepaid && this.accRespObj && !this.accRespObj.billingAddress) {
            this.accRespObj.billingAddress = Object.assign({}, this.accRespObj.accountInfo.billingAddress);
        }
        if (this.accRespObj.billingAddress && this.accRespObj.billingAddress.postCodeSuffix) {
            this.accountForm.patchValue({ zipCode: this.accRespObj.billingAddress.postCode + '-' + this.accRespObj.billingAddress.postCodeSuffix });
        } else {
            this.accountForm.patchValue({ zipCode: this.accRespObj.billingAddress.postCode });
        }
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Street Address', addrPlchd2: 'Unit #',
                    addrPlchd3: 'City'
                };
                if (this.accountRentrantValue && this.accInformation && !this.accInformation.billingaddr && this.accRespObj && this.accRespObj.billingAddress) {
                    this.accInformation.billingaddr = this.accRespObj.billingAddress;
                } else if (!this.accountRentrantValue && this.isAmend && this.isPrepaid && this.accInformation && !this.accInformation.billingaddr && this.accRespObj && this.accRespObj.accountInfo.billingAddress) {
                    this.accInformation.billingaddr = this.accRespObj.accountInfo.billingAddress;
                }
                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr && this.accInformation.billingaddr.streetAddress : (this.accRespObj.billingAddress.streetAddress ?
                        this.accRespObj.billingAddress.streetAddress : (this.accRespObj.accountInfo.billingAddress.streetAddress ? this.accRespObj.accountInfo.billingAddress.streetAddress : '')),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.unitNumber : (this.accRespObj.billingAddress.unitNumber ?
                        this.accRespObj.billingAddress.unitNumber : (this.accRespObj.accountInfo.billingAddress.unitNumber ? this.accRespObj.accountInfo.billingAddress.unitNumber : '')),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : (this.accRespObj.billingAddress ? (this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality) : (this.accRespObj.accountInfo.billingAddress.city ? this.accRespObj.accountInfo.billingAddress.city : this.accRespObj.accountInfo.billingAddress.locality))
                };
                this.getStates();
                break;
            case 'P.O. Box':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Box Number', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.streetNrFirst ?
                        this.accRespObj.billingAddress.streetNrFirst : ''),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.subAddress.combinedDesignator : (this.accRespObj.billingAddress.subAddress.combinedDesignator ?
                        this.accRespObj.billingAddress.subAddress.combinedDesignator : ''),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality
                };
                this.getStates();
                break;
            case 'Rural Route':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Rural Route', addrPlchd2: 'Box Number',
                    addrPlchd3: 'City'
                };
                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetName.replace("RR ", '') : (this.accRespObj.billingAddress.streetName ?
                        this.accRespObj.billingAddress.streetName.replace("RR ", '') : this.accRespObj.billingAddress.streetAddress),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.streetNrFirst ?
                        this.accRespObj.billingAddress.streetNrFirst : ''),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : (this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality)
                };
                this.getStates();
                break;
            case 'Military':
                this.refObj.disableValidateAddr = false;
                this.refObj.disableSaveAddr = true;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'APO, FPO, DPO'
                };
                if (this.accRespObj.billingAddress.apoFpoDpo) {
                    this.refObj.addrModels = {
                        field1: (this.accountRentrantValue || this.reEntrant) ? (this.accInformation.billingaddr.addressLine1 ? this.accInformation.billingaddr.addressLine1 : this.accInformation.billingaddr.streetName) : (this.accRespObj.billingAddress.addressLine1 ?
                            this.accRespObj.billingAddress.addressLine1 : this.accRespObj.billingAddress.streetAddress),
                        field2: (this.accountRentrantValue || this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.addressLine2 ?
                            this.accRespObj.billingAddress.addressLine2 : ''),
                        field3: (this.accountRentrantValue || this.reEntrant) ? this.accInformation.billingaddr.city : (this.accRespObj.billingAddress.apoFpoDpo ?
                            this.accRespObj.billingAddress.apoFpoDpo : '')
                    };
                } else {
                    this.refObj.addrModels = {
                        field1: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.addressLine1 ? this.accInformation.billingaddr.addressLine1 : this.accInformation.billingaddr.streetName) : (this.accRespObj.billingAddress.addressLine1 ?
                            this.accRespObj.billingAddress.addressLine1 : this.accRespObj.billingAddress.streetName),
                        field2: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.streetNrFirst : (this.accRespObj.billingAddress.addressLine2 ?
                            this.accRespObj.billingAddress.addressLine2 : this.accRespObj.billingAddress.streetNrFirst),
                        field3: (this.accountRentrantValue && !this.reEntrant) ? this.accInformation.billingaddr.city : (this.accRespObj.billingAddress.apoFpoDpo ?
                            this.accRespObj.billingAddress.apoFpoDpo : this.accRespObj.billingAddress.city)
                    };
                }
                this.getMilitaryState();
                break;
            case 'International':
                this.refObj.disableValidateAddr = true;
                this.refObj.disableSaveAddr = false;
                this.refObj.addrPlaceholders = {
                    addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
                    addrPlchd3: 'City'
                };

                this.refObj.addrModels = {
                    field1: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.addressLine1 ? this.accInformation.billingaddr.addressLine1 : this.accInformation.billingaddr.streetAddress) : (this.accRespObj.billingAddress.addressLine1 ?
                        this.accRespObj.billingAddress.addressLine1 : this.accRespObj.billingAddress.streetAddress),
                    field2: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.addressLine2 ? this.accInformation.billingaddr.addressLine2 : this.accInformation.billingaddr.streetName) : (this.accRespObj.billingAddress.addressLine2 ?
                        this.accRespObj.billingAddress.addressLine2 : this.accRespObj.billingAddress.streetName),
                    field3: (this.accountRentrantValue && !this.reEntrant) ? (this.accInformation.billingaddr.city ? this.accInformation.billingaddr.city : this.accInformation.billingaddr.locality) : (this.accRespObj.billingAddress.city ? this.accRespObj.billingAddress.city : this.accRespObj.billingAddress.locality)
                };
                this.getCountries();
                break;
            default: break;
        }
        if (this.refObj.initialAddrType !== this.refObj.addrTypeSelected) {
            this.accountForm.patchValue({ zipCode: '' });
            this.refObj.addrModels = {
                field1: '', field2: '', field3: ''
            };
        }
    }

    /** Change billing address state/country selection handler */
    public stateCountrySelectionHandler() {
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
            case 'P.O. Box':
            case 'Rural Route':
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                break;
            case 'Military':
                this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
                break;
            case 'International':
                this.billingAddr.country = this.refObj.selectedState.countryCode;
                break;
            default: break;
        }
    }

    /** Change billing address Validate button handler */
    public validateBillingAddr() {
        this.refObj.isExactAddr = '';
        this.refObj.disableSaveAddr = true;
        switch (this.refObj.addrTypeSelected) {
            case 'Street Address':
                this.billingAddr.streetAddress = this.refObj.addrModels.field1;
                this.billingAddr.addressLine1 = this.billingAddr.streetAddress;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.streetAddress}
                                        ${this.billingAddr.addressLine2},
                                        ${this.billingAddr.stateOrProvince}, 
                                        ${this.billingAddr.city}`;
                break;
            case 'P.O. Box':
                this.billingAddr.streetAddress = "PO BOX " + this.refObj.addrModels.field1;
                this.billingAddr.boxNumber = "PO BOX " + this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.addressLine1 = this.billingAddr.boxNumber;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.boxNumber}
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.stateOrProvince}, 
                                        ${this.billingAddr.city}`;
                break;
            case 'Rural Route':
                this.billingAddr.ruralRoute = this.refObj.addrModels.field1;
                this.billingAddr.boxNumber = this.refObj.addrModels.field2;
                this.billingAddr.addressLine1 = "RR " + this.billingAddr.ruralRoute;
                this.billingAddr.addressLine2 = "BOX " + this.billingAddr.boxNumber;
                this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.refObj.combinedAddress = `${this.billingAddr.ruralRoute}
                                    ${this.billingAddr.boxNumber}, 
                                    ${this.billingAddr.stateOrProvince}, 
                                    ${this.billingAddr.city}`;
                break;
            case 'Military':
                this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.apoFpoDpo = this.refObj.addrModels.field3;
                this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
                this.billingAddr.city = this.billingAddr.apoFpoDpo;
                this.billingAddr.locality = this.billingAddr.city;
                this.billingAddr.stateOrProvince = this.billingAddr.armedForceLoc;
                this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.apoFpoDpo}, 
                                        ${this.billingAddr.armedForceLoc}`;
                break;
            case 'International':
                this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
                this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
                this.billingAddr.city = this.refObj.addrModels.field3;
                this.billingAddr.locality = this.billingAddr.city;
                this.billingAddr.country = this.refObj.selectedState.countryCode;
                this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                        ${this.billingAddr.addressLine2}, 
                                        ${this.billingAddr.city},
                                        ${this.billingAddr.country}`;
                break;
            default: break;
        }

        this.billingAddr.postCode = this.accountForm.value.zipCode;
        let zipValid = Validations.zipCodeValidator({ value: this.accountForm.value.zipCode });
        /** Unit number is optional for street address, checking with only mandatory fields */
        if (!this.refObj.addrModels.field1 || !this.refObj.addrModels.field3 || zipValid) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        if (this.refObj.addrTypeSelected === '' || this.refObj.addrTypeSelected === undefined) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        if (!this.refObj.selectedState.stateCode && !this.refObj.selectedState.militaryStateCode
            && !this.refObj.selectedState.countryCode) {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        this.refObj.isEnteredAllAddsFields = true;
        let lpostCode = this.billingAddr.postCode.length === 5 && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix !== '' ? this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix : this.billingAddr.postCode;
        this.refObj.combinedAddress = this.refObj.combinedAddress + ', ' + lpostCode;
        let civicOrpostal = 'postalAddresses';

        this.logger.log("info", "account.component.ts", "geoesAddressValidationRequest", JSON.stringify(this.billingAddr));
        let errorResolved = false;
        this.logger.startTime();
        this.addressService.getGeoesAddress(this.billingAddr, civicOrpostal)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "geoesAddressValidationResponse", error);
                this.logger.log("error", "account.component.ts", "geoesAddressValidationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.loading = false;
                return Observable.throwError(error._body);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "geoesAddressValidationResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "account.component.ts", "getE911AcntPageSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    let respAddressesArray = [];
                    let lunitNumber: string = '';
                    if (this.refObj && this.refObj.addrModels && this.refObj.addrModels.field2) {
                        lunitNumber = this.refObj.addrModels.field2 ? this.refObj.addrModels.field2 : '';
                    }

                    if (civicOrpostal === 'civicAddresses') {
                        respAddressesArray = data.civicAddresses;
                    } else {
                        respAddressesArray = data.postalAddresses;
                    }

                    if (data && data !== undefined && data !== null && data.result === "Green") {
                        this.refObj.isExactAddr = 'exact';
                        this.refObj.disableSaveAddr = false;
                        if (respAddressesArray[0].subAddress !== undefined) {
                            lunitNumber = respAddressesArray[0].subAddress.designator + ' ' + respAddressesArray[0].subAddress.value;
                        }
                        let geoesResponseAddress: EnterpriseAddress = {
                            isValidated: true,
                            streetAddress: respAddressesArray[0].streetAddress,
                            streetNrFirst: respAddressesArray[0].streetNrFirst,
                            streetNrFirstSuffix: '',
                            streetNamePrefix: respAddressesArray[0].streetNamePrefix,
                            streetName: respAddressesArray[0].streetName,
                            streetType: respAddressesArray[0].streetType,
                            locality: respAddressesArray[0].locality,
                            city: respAddressesArray[0].locality,
                            stateOrProvince: respAddressesArray[0].stateOrProvince,
                            postCode: respAddressesArray[0].postCode,
                            postCodeSuffix: respAddressesArray[0].postCodeSuffix !== 'undefined' ? respAddressesArray[0].postCodeSuffix : '',
                            source: respAddressesArray[0].source,
                            country: 'USA',
                            subAddress: {
                                sourceId: '',
                                source: respAddressesArray[0].source,
                                geoSubAddressId: '',
                                combinedDesignator: lunitNumber,
                                elements: [
                                    {
                                        designator: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.designator !== undefined ? respAddressesArray[0].subAddress.designator : '',
                                        value: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.value !== undefined ? respAddressesArray[0].subAddress.value : ''
                                    }
                                ]
                            }
                        };
                        this.accRespObj.billingAddress = geoesResponseAddress;
                        this.refObj.validatedAddr = this.accRespObj.billingAddress;
                        this.refObj.savedAddress = this.accRespObj.billingAddress;
                        this.refObj.selectedAddr = Object.assign({}, this.accRespObj.billingAddress);
                        this.accRespObj.isBillAddrSameAsServiceAddress = false;
                        this.accountObservable = <Observable<any>>this.store.select('account');
                        if (this.isAmend && this.isPrepaid && this.accRespObj && this.accRespObj.accountInfo && this.accRespObj.accountInfo.contact.emailAddress) {
                            this.accRespObj.accountInfo.contact.emailAddress = this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress;
                            this.accRespObj.accountInfo.contact.contactNumber = this.accountForm && this.accountForm.value && this.accountForm.value.contactNumber;
                        } else {
                            this.accRespObj.contact.emailAddress = this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress;
                            this.accRespObj.contact.contactNumber = this.accountForm.value.contactNumber;
                        }
                        this.accInformation.payload.billingAddress = this.refObj.savedAddress;
                        this.store.dispatch({ type: 'BILLING_ADDRESS', payload: this.accRespObj });

                    }
                    else if (data && data !== undefined && data !== null && (data.result === 'Yellow' || data.result.toUpperCase() === 'RED')) {
                        this.refObj.isExactAddr = 'multi';
                        this.refObj.nearAddresses = [];
                        if (data && data.result.toUpperCase() !== 'RED') {
                            this.redAddressFlag = false;
                            for (let i = 0; i < respAddressesArray.length; i++) {
                                if (respAddressesArray[i].subAddress !== undefined) {
                                    lunitNumber = respAddressesArray[i].subAddress.designator + ' ' + respAddressesArray[i].subAddress.value;
                                }
                                let geoesResponseAddress: EnterpriseAddress = {
                                    isValidated: true,
                                    streetAddress: respAddressesArray[i].streetAddress,
                                    streetNrFirst: respAddressesArray[i].streetNrFirst,
                                    streetNrFirstSuffix: '',
                                    streetNamePrefix: respAddressesArray[i].streetNamePrefix,
                                    streetName: respAddressesArray[i].streetName,
                                    streetType: respAddressesArray[i].streetType,
                                    locality: respAddressesArray[i].locality,
                                    city: respAddressesArray[i].locality,
                                    stateOrProvince: respAddressesArray[i].stateOrProvince,
                                    postCode: respAddressesArray[i].postCode,
                                    postCodeSuffix: respAddressesArray[i].postCodeSuffix !== 'undefined' ? respAddressesArray[i].postCodeSuffix : '',
                                    source: respAddressesArray[i].source,
                                    country: 'USA',
                                    subAddress: {
                                        sourceId: '',
                                        source: respAddressesArray[i].source,
                                        geoSubAddressId: '',
                                        combinedDesignator: lunitNumber,
                                        elements: [
                                            {
                                                designator: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.designator !== undefined ? respAddressesArray[i].subAddress.designator : '',
                                                value: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.value !== undefined ? respAddressesArray[i].subAddress.value : ''
                                            }
                                        ]
                                    }
                                };
                                this.refObj.nearAddresses.push(geoesResponseAddress);
                            }
                        }
                        else {
                            this.redAddressFlag = true;
                        }
                        const newNearAddress = Object.assign({}, this.accRespObj.billingAddress, this.billingAddr);
                        if (newNearAddress.postCode.indexOf("-") > -1) {
                            // post ocde already has a suffix, remove it
                            newNearAddress.postCode = newNearAddress.postCode.substr(0, newNearAddress.postCode.indexOf("-"));
                        }
                        this.refObj.nearAddresses.push(newNearAddress);

                    } else {
                        this.refObj.isExactAddr = 'red';
                    }

                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "geoesAddressValidationResponse", error);
                        this.logger.log("error", "account.component.ts", "geoesAddressValidationSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                }
            );
    }

    /** Billing address selection handler from multiple addresses, after validation */
    public addressRadioHandler() {
        this.refObj.disableSaveAddr = false;
        this.refObj.selectedAddr.addressTypeSelected = this.refObj.addrTypeSelected;
        let lpostCode = this.refObj.selectedAddr.postCode && this.refObj.selectedAddr.postCodeSuffix !== undefined && this.refObj.selectedAddr.postCodeSuffix !== '' ? this.refObj.selectedAddr.postCode + ' - ' + this.refObj.selectedAddr.postCodeSuffix : this.refObj.selectedAddr.postCode;
        this.refObj.combinedAddress = `${this.refObj.selectedAddr.streetAddress}
        ${this.refObj.selectedAddr.unitNumber ? ', ' + this.refObj.selectedAddr.unitNumber : ''}
                              ${this.refObj.selectedAddr.city ? this.refObj.selectedAddr.city : this.refObj.selectedAddr.locality}, 
                              ${this.refObj.selectedAddr.stateOrProvince} 
                              ${lpostCode}`;
    }

    /** Save billing address button handler */
    public saveChangedAddr() {
        if ((!this.refObj.addrModels.field1 || !this.refObj.selectedState.countryCode) && this.refObj.addrTypeSelected === "International") {
            this.refObj.isEnteredAllAddsFields = false;
            return;
        }
        this.postalAddressValidated = true;
        this.billingAddr = this.refObj.selectedAddr;
        if (this.refObj.addrTypeSelected === 'International') {
            this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
            this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
            this.billingAddr.city = this.refObj.addrModels.field3;
            this.billingAddr.locality = this.billingAddr.city;
            this.billingAddr.postCode = this.accountForm.value.zipCodeInt;
            this.billingAddr.country = this.refObj.selectedState.countryCode;
            this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                    ${this.billingAddr.addressLine2}, 
                                    ${this.billingAddr.city},
                                    ${this.billingAddr.country}`;
            this.refObj.selectedAddr = this.billingAddr;

            let internationalAddressEntry: EnterpriseAddress = {
                isValidated: true,
                streetAddress: this.refObj.addrModels.field1,
                streetNrFirst: '',
                streetNrFirstSuffix: '',
                streetNamePrefix: '',
                streetName: this.refObj.addrModels.field2,
                streetType: '',
                locality: this.refObj.addrModels.field3,
                city: this.refObj.addrModels.field3,
                stateOrProvince: '',
                postCode: this.billingAddr.postCode,
                postCodeSuffix: '',
                source: '',
                country: this.billingAddr.country,
                subAddress: {
                    sourceId: '',
                    source: '',
                    geoSubAddressId: '',
                    combinedDesignator: '',
                    elements: [
                        {
                            designator: '',
                            value: ''
                        }
                    ]
                }
            };
            this.store.dispatch({ type: 'ADD_TYPE', payload: this.refObj.addrTypeSelected });
            this.refObj.savedAddress = this.refObj.selectedAddr;
            this.refObj.isExactAddr = '';
            this.refObj.disableSaveAddr = true;
            this.accRespObj.billingAddress = Object.assign({}, internationalAddressEntry);
            this.refObj.changeAddrClicked = false;
            this.accRespObj.isBillAddrSameAsServiceAddress = false;
        } else {
            this.store.dispatch({ type: 'ADD_TYPE', payload: this.refObj.addrTypeSelected });
            this.refObj.savedAddress = this.refObj.selectedAddr;
            this.refObj.isExactAddr = '';
            this.refObj.disableSaveAddr = true;
            this.accRespObj.billingAddress = Object.assign({}, this.refObj.selectedAddr);
            this.refObj.changeAddrClicked = false;
            this.accRespObj.isBillAddrSameAsServiceAddress = false;
        }
        this.store.dispatch({ type: 'BILLING_ADDR', payload: this.accRespObj.billingAddress });

    }

    public useServiceAddress() {
        this.serviceAddress = Object.assign({}, this.initialServiceAddress);
        this.refObj.savedAddress = Object.assign({}, this.serviceAddress);
        this.billingAddr = Object.assign({}, this.serviceAddress);
        this.accRespObj.billingAddress = Object.assign({}, this.serviceAddress);
        this.accRespObj.isBillAddrSameAsServiceAddress = true;

        // moved to this handler from template:
        this.refObj.changeAddrClicked = false;
        this.refObj.isExactAddr = '';
        this.refObj.disableSaveAddr = true;
    }
    public setDefaultVal(proactiveName) {
        if (proactiveName === 'bill') {
            this.refObj.billingChk ? this.billingOptionValidation() : this.refObj.billingOption = this.refObj.billingOptions[3];
        }
        if (proactiveName === 'order') {
            this.refObj.orderChk ? this.billingOptionValidation() : this.refObj.orderOption = this.refObj.billingOptions[3];
        }
        if (proactiveName === 'repair') {
            this.refObj.repairChk ? this.billingOptionValidation() : this.refObj.repairOption = this.refObj.billingOptions[3];
        }
    }


    public isFNPeriodsEntered() {
        let isFirstnameField = false;
        if (this.accountForm.value.firstName.indexOf('.') !== -1) {
            isFirstnameField = true;
        }
        return isFirstnameField;
    }

    public isLNPeriodsEntered() {
        let isLasttnameField = false;
        if (this.accountForm.value.lastName.indexOf('.') !== -1) {
            isLasttnameField = true;
        }
        return isLasttnameField;
    }
    /**
     * check whether DL licenseNo and state having value or not and vise versa
    */
    public checkEnteredDL() {
        if (this.personalDet &&
            ((this.personalDet.dLlicenseNo !== null && this.personalDet.dLlicenseState === null) ||
                (this.personalDet.dLlicenseNo !== '' && this.personalDet.dLlicenseState === ''))) {
            this.refObj.enteredDL = false;
            return;
        } else {
            this.refObj.enteredDL = true;
        }
    }

    public onKeyUpAccountPassword() {
        this.accountPasswordPin = true;
        this.store.dispatch({ type: 'ACCOUNTPASSWORD_PIN', payload: this.accountPasswordPin });
        let inValidAccPassword = Validations.accountPasswordValidator({ value: this.accRespObj.accountPassword });
        if (!inValidAccPassword) {
            this.refObj.isValidAccPassword = true;
        } else {
            this.refObj.isValidAccPassword = false;
        }
    }

    public displayEmailMandatoryAlert() {
        if ((this.isPrepaid && this.isUnameValid) || (!this.refObj.isEmailValid && !(this.contactDet && this.contactDet.emailAddrDeclined)) || ((this.contactDet && this.contactDet.emailAddrDeclined) && this.refObj.billingOpt === 'paperless')) {
            window.scroll(0, 200);
        }
    }

    public isOTCAvail = false;

    /** Initialize credit check variables after getting credit response */
    public initCreditInfo() {
        this.creditDepositInfo = this.creditObj.depositInfo;
        this.otcData1 = this.creditObj.addlOrderAttributes;
        this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup && this.otcData1[0].orderAttributeGroup.map(group => {
            if (group.orderAttributeGroupName === 'otcInstallmentInfo') {
                this.isOTCAvail = true;
            }
        });
        this.otcDataResponse = cloneDeep(this.otcData1);
        this.userPaidObj = this.creditObj.paymentDetails;
        this.products = [];
        this.refObj.pastDueAccs = [];
        this.store.dispatch({ type: 'CC_DONE', payload: true });
        if (this.creditDepositInfo !== undefined && this.creditDepositInfo.products && this.creditDepositInfo.products.length > 0) {
            this.products = this.creditDepositInfo.products;
            if (this.userPaidObj.depositPaymentStatus === 'PAID') {
                this.refObj.isPaymentSuccess = true;
                if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                    let paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                    this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
                } else {
                    let currDate = new Date();
                    this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
                }
                this.refObj.disableDepositBtn = true;
                this.refObj.paymentStatus = 'success';
            } else {
                let currDate = new Date();
                this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
            }
        } else {
            this.refObj.isPaymentSuccess = true;
        }
        this.creditInfo = this.creditObj.creditInfo;
        if (this.creditInfo !== undefined && this.creditInfo.finalBillInfo && this.creditInfo.finalBillInfo.length > 0) {
            this.refObj.pastDueAccs = this.creditInfo.finalBillInfo;
            this.totalPastDueAmount = this.ctlHelperService.getTotalPastDueAmount(this.creditInfo.finalBillInfo);
            this.pastDueAmountBTNs = this.ctlHelperService.getBTNsArray(this.creditInfo.finalBillInfo);
            if (this.userPaidObj.finalBillPaymentStatus === 'PAID') {
                this.refObj.isPaymentSuccessPD = true;
                if (this.userPaidObj.finalBillPaymentDate !== null && this.userPaidObj.finalBillPaymentDate !== '') {
                    let paidDate = this.userPaidObj.finalBillPaymentDate.split(' ')[0].split('-');
                    this.refObj.paidDatePD = paidDate[1] + '/' + paidDate[2];
                } else {
                    let currDate = new Date();
                    this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
                }
                this.refObj.paymentStatusPD = 'success';
                this.refObj.disablePastDueBtn = true;
            }
        } else {
            this.refObj.isPaymentSuccessPD = true;
        }
        let laccRespObjPostCode = this.accRespObj && this.accRespObj.billingAddress && this.accRespObj.billingAddress.postCode && this.accRespObj.billingAddress.postCodeSuffix !== undefined && this.accRespObj.billingAddress.postCodeSuffix !== '' ? this.accRespObj.billingAddress.postCode + ' - ' + this.accRespObj.billingAddress.postCodeSuffix : this.accRespObj.billingAddress.postCode;
        let addr = `${this.accRespObj.billingAddress.streetAddress}, ${this.accRespObj.billingAddress.city}, ${this.accRespObj.billingAddress.stateOrProvince}, ${laccRespObjPostCode} ${this.accRespObj.billingAddress.country}`;
        this.payobj = {
            name: this.accRespObj.accountInfo.accountName.firstName + ' ' +
                this.accRespObj.accountInfo.accountName.lastName,
            contactNumber: this.contactDet.contactNumber, address: addr,
            paymentheader: 'Advance payment required'
        };
        // this.calculateTotalDeposit();
    }

    /** Prepaid Initialize credit check variables after getting credit response */
    public initCreditPrepaidInfo() {
        this.prepaidAcctNumber = this.creditObj.currentBillQuote.accountId;
        this.userPaidObj = this.creditObj.paymentDetails;
        this.store.dispatch({ type: 'CC_DONE', payload: true });
        if (this.userPaidObj.depositPaymentStatus === 'PAID') {
            this.refObj.isPaymentSuccess = true;
            if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                let paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
            } else {
                let currDate = new Date();
                this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
            }
            this.refObj.disableDepositBtn = true;
            this.refObj.paymentStatus = 'success';
            this.refObj.isPrepaidPaymentSuccess = true;
        } else if (this.userPaidObj.finalBillPaymentStatus === 'PAID') {
            this.refObj.isPaymentSuccess = true;
            if (this.userPaidObj.depositPaymentDate !== null && this.userPaidObj.depositPaymentDate !== '') {
                let paidDate = this.userPaidObj.depositPaymentDate.split(' ')[0].split('-');
                this.refObj.depositPaidDate = paidDate[1] + '/' + paidDate[2];
            } else {
                let currDate = new Date();
                this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
            }
            this.refObj.disablePrepaidbtn = true;
            this.refObj.prepaidPaymentStatus = 'success';
            this.refObj.isPrepaidPaymentSuccess = true;
        }
        if (this.creditObj.pastDueAmount && this.creditObj.pastDueAmount.finalBillInfo && this.creditObj.pastDueAmount.finalBillInfo.length > 0) {
            this.creditObj.pastDueAmount.finalBillInfo[0] && this.creditObj.pastDueAmount.finalBillInfo[0].paymentRequiredInd ?
                this.pastDueAmountExist = true : this.pastDueAmountExist = false;
            this.refObj.totalDepositAmount = this.creditObj.pastDueAmount.finalBillInfo[0].finalBillAmt.amount;
            this.finalBillforPostPaid = this.creditObj.pastDueAmount.finalBillInfo[0];
        }
        let laccRespObjPostCode = this.accRespObj.billingAddress.postCode && this.accRespObj.billingAddress.postCodeSuffix !== undefined && this.accRespObj.billingAddress.postCodeSuffix !== '' ? this.accRespObj.billingAddress.postCode + ' - ' + this.accRespObj.billingAddress.postCodeSuffix : this.accRespObj.billingAddress.postCode;
        let addr = `${this.accRespObj.billingAddress.streetAddress}, ${this.accRespObj.billingAddress.city}, ${this.accRespObj.billingAddress.stateOrProvince}, ${laccRespObjPostCode} ${this.accRespObj.billingAddress.country}`;
        this.payobj = {
            name: this.accRespObj.accountName.firstName + ' ' +
                this.accRespObj.accountName.lastName,
            contactNumber: this.contactDet.contactNumber, address: addr
        };
    }

    private getPaymentAdjustInfo() {
        this.refundAmtList = [];
        this.newPmtList = [];
        this.refundTaxes = 0;
        this.refundTotalAmt = 0;
        this.newPmtTaxes = 0;
        this.newPmtTotalAmt = 0;

        if (this.creditObj && this.creditObj.currentBillQuote && this.creditObj.currentBillQuote.ccLastDigits) {
            this.creditCardNo = this.creditObj.currentBillQuote.ccLastDigits;
        }

        this.creditObj && this.creditObj.currentBillQuote && this.creditObj.currentBillQuote.refundList &&
            this.creditObj.currentBillQuote.refundList.offerDetails &&
            this.creditObj.currentBillQuote.refundList.offerDetails.map(rOffer => {
                if (!rOffer.otc) {
                    let refundOffer = {
                        "offerName": rOffer.offerName,
                        "offerPrice": rOffer.offerPrice,
                        "tax": rOffer.tax
                    };
                    this.refundTaxes += rOffer.tax;
                    this.refundTotalAmt += rOffer.offerPrice + rOffer.tax;
                    this.refundAmtList.push(refundOffer);
                }
            });

        this.creditObj && this.creditObj.currentBillQuote && this.creditObj.currentBillQuote.firstMonthList &&
            this.creditObj.currentBillQuote.firstMonthList.offerDetails &&
            this.creditObj.currentBillQuote.firstMonthList.offerDetails.map(nOffer => {
                if (nOffer.otc === true) {
                    let newPmtOffer = {
                        "offerName": nOffer.offerName,
                        "offerPrice": nOffer.offerPrice,
                        "tax": nOffer.tax
                    };
                    this.newPmtTaxes += nOffer.tax;
                    this.newPmtTotalAmt += nOffer.offerPrice + nOffer.tax;
                    this.newPmtList.push(newPmtOffer);
                }
            });

        if (this.refundAmtList && this.refundAmtList.length > 0) {
            this.refundFlag = true;
        } else {
            this.refundFlag = false;
        }

        if (this.newPmtList && this.newPmtList.length > 0) {
            this.newLPmtFLag = true;
        } else {
            this.newLPmtFLag = false;
        }
    }

    /** Function to Calulate age */
    public getAge() {
        if (this.refObj.month && this.refObj.day && this.refObj.year) {
            let isDobValid = Validations
                .dobValidator(this.refObj.month, this.refObj.day, this.refObj.year);
            if (!isDobValid) {
                let today = new Date();
                let birthDate = new Date(this.refObj.month + '/' + this.refObj.day
                    + '/' + this.refObj.year);
                let age = today.getFullYear() - birthDate.getFullYear();
                let m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                age < 18 ? this.refObj.underAge = true : this.refObj.underAge = false;
                this.personalDet.dateOfBirth = this.refObj.year + '-' + this.refObj.month +
                    '-' + this.refObj.day;
                this.refObj.dobEntered = true;
                this.personalDet.underAgeAck = false;
                this.refObj.isValidDob = true;
            } else {
                this.refObj.isValidDob = false;
                this.refObj.dobMessage = isDobValid.message;
            }
        }
    }

    public bmOrderProcess(requestObj, isChangeFlow, requestObject) {
        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "reviewOrderRequest", JSON.stringify(requestObject));
        this.logger.startTime();
        this.reviewOrderService.postSubmitTaskService(requestObj, this.currentFlow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "reviewOrderResponse", error);
                this.logger.log("error", "account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                errorResolved = true;
                this.ctlHelperService.setLocalStorage('error', error);
                this.loading = false;
                return Observable.throwError(error._body);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "reviewOrderResponse", JSON.stringify(data ? data : ''));
                    this.logger.log("info", "account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let response = data;
                    if (response) {
                        this.apiResponseError = null;
                        // placeholder for store saving, pull from previous page through store object
                        this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                        this.store.dispatch({ type: 'TASK_ID', payload: response.taskId });
                        this.store.dispatch({ type: 'FREEZEPAGE', payload: true });
                        this.store.dispatch({ type: 'FREEZEACC', payload: true });
                        if (this.currentFlow !== undefined && (this.currentFlow === 'Change')) {
                            this.router.navigate(['/co-review-order']);
                        }
                        else {
                            this.router.navigate(['/review-order']);
                        }
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "account.component.ts", "reviewOrderResponse", error);
                        this.logger.log("error", "account.component.ts", "reviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.logger.log("error", "account.component.ts", "reviewOrderError", JSON.stringify(this.apiResponseError));
                            this.systemErrorService.logAndeRouteToSystemError("error", 'reviewOrderError', "account.component.ts", "Account Page", this.apiResponseError);
                        } else { unexpectedError = true; }
                    } else { unexpectedError = true; }
                    if (unexpectedError) {
                        let errorResponseCustom: ErrorResponse = {
                            statusCode: serverErrorMessages.statusCode,
                            message: serverErrorMessages.serverDown
                        };
                        if (this.apiResponseError && this.apiResponseError.errorResponse) {
                            this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                            this.logger.log("error", "account.component.ts", "reviewOrderError", JSON.stringify(this.apiResponseError));
                        }
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", 'reviewOrderError', "account.component.ts", "Account Page", lAPIErrorLists);
                    }
                }
            );
    }

    public orderDtvProcess(requestObj, isChangeFlow, requestObject) {
        let request: any;
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((data) => {
            request = {
                orderRefNumber: data.dtvSessionInfo.payload.orderReferenceNumber,
                processInstanceId: data.dtvSessionInfo.processInstanceId,
                taskId: data.dtvSessionInfo.taskId,
                taskName: data.dtvSessionInfo.taskName,
                payload: {
                    uniqueSessionId: data.dtvSessionInfo.payload.sessionInfo.uniqueSessionId,
                    attOrderType: "DIRECTV"
                }
            };
        });

        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.orderDtvProcess(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVinit", "account.component.ts",
                    "DIRECTV order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                if (data && data.payload.taskName === 'Enter DTV Manually') {
                    this.opusSessionInfoNotFound.open();
                }
            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }


    public retrieveDtvOrder(requestObj, isChangeFlow, requestObject) {
        this.loading = true;
        let request: any;
        request = {
            "uniqueSessionId": "",
            "attOrderType": "DIRECTV",
            "orderReferencNumber": requestObj.orderRefNumber
        };
        if (this.retainObservableData && this.retainObservableData.dtvSessionInfo && this.retainObservableData.dtvSessionInfo.payload && this.retainObservableData.dtvSessionInfo.payload.sessionInfo && this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId) {
            request.uniqueSessionId = this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId;
        }

        let errorResolved = false;
        this.logger.log("info", "account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.retrieveDtvOrder(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVRetrieveOrder", "account.component.ts",
                    "DIRECTV Retrieve order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data ? data : ''));
                this.logger.log("info", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    this.loading = false;
                    if (data.errorResponse[0].message === 'SESSION_ID_NON_FOUND') {
                        this.opusSessionInfoNotFound.open();
                    } else {
                        data.errorResponse[0]['status'] = "200";
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error",
                            "",
                            "retrieveDTVOrder",
                            "account.component.ts",
                            "Retrieve  DTV order",
                            data.errorResponse[0]
                        );
                        return Observable.throwError(null);
                    }
                } else {
                    this.logger.endTime();
                    this.logger.log("info", "account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                    this.orderDtvProcess(requestObj, isChangeFlow, requestObject);
                    this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
                }

            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }


    /** On second time click on continue button, get order response & navigate to order page */
    public getOrderResponse() {
        if ((this.refObj.isEmailValid)) {
            if (!this.isDtvOpus && this.isDTV) {
                let dtvAccountNo = this.dtvForm.get('dtvAccNo').value;
                if (!dtvAccountNo && this.newDtv && this.isDTV && dtvAccountNo === '') {
                    return;
                } else {
                    if (dtvAccountNo !== '' && this.newDtv && this.isDTV) {
                        this.store.dispatch({ type: 'UPDATE_USER', payload: { dtvQuestionForm: { taskName: 'yes', accNo: dtvAccountNo } } });
                        this.accountService.saveDtvAccountNo(dtvAccountNo, this.creditReviewResp.orderRefNumber).subscribe((resp) => { });
                    }
                }
            }
            this.loading = true;
            let requestObject: PaymentsRq = {};
            this.store.dispatch({ type: 'Prepaid_LoginDetails', payload: this.loginDetails });
            if (this.paymentReqObj && this.paymentReqObj !== null && this.paymentReqObj !== undefined && this.paymentReqObj.length === 0) {
                this.paymentReqObj = null;
            }
            let isChangeFlow: boolean = false;
            this.userdata = <Observable<any>>this.store.select('user');
            let reentrentTaskId: string;
            this.userSubscription$ = this.userdata.subscribe(
                (userdata) => {
                    reentrentTaskId = userdata.taskId;
                    userdata.phoneNumber = this.phoneNumber;
                });
            this.updateaccRespObj();
            let requestObj = {
                orderRefNumber: this.accInformation.orderRefNumber,
                processInstanceId: this.accInformation.processInstanceId,
                taskId: this.refObj.userData.taskId,
                taskName: this.accInformation.taskName,
                payload: {
                    creditReviewAction: this.enumActions.SHOW_SUMMARY,
                    accountInfo: this.accInformation.payload.accountInfo,
                    addlOrderAttributes: this.otcUpdated ? this.otcUpdated : this.otcData1,
                    loginDetails: this.loginDetails
                }
            };
            this.accountService.getAccountData(this.accountForm.value);
            if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV && this.dtvAccountInfoManuallyEntered) {
                this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
            } else if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV) {
                this.retrieveDtvOrder(requestObj, isChangeFlow, requestObject);
            } else {
                this.bmOrderProcess(requestObj, isChangeFlow, requestObject);
            }
        } else {
            this.loading = false;
            this.displayEmailMandatoryAlert();
        }

    }

    private updateaccRespObj() {

        this.refObj && this.refObj.billingOption && this.refObj.billingOption.name && this.refObj.billingOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.emailNotification.billingNotification = false;

        this.refObj && this.refObj.billingOption && this.refObj.billingOption.name && this.refObj.billingOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.textNotification.billingNotification = false;

        this.refObj && this.refObj.orderOption && this.refObj.orderOption.name && this.refObj.orderOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.emailNotification.orderingNotification = false;

        this.refObj && this.refObj.orderOption && this.refObj.orderOption.name && this.refObj.orderOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification = true :
            this.accRespObj.accountInfo.accountPreferences.textNotification.orderingNotification = false;

        this.refObj && this.refObj.repairOption && this.refObj.repairOption.name && this.refObj.repairOption.name.indexOf('Email') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification = true :
            this.accRespObj.accountInfo.accountPreferences.emailNotification.repairNotification = false;

        this.refObj && this.refObj.repairOption && this.refObj.repairOption.name && this.refObj.repairOption.name.indexOf('SMS') !== -1 ?
            this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification = true :
            this.accRespObj.accountInfo.accountPreferences.textNotification.repairNotification = false;

        this.accRespObj.accountInfo.accountName.firstName = this.accountForm.value.firstName;
        this.accRespObj.accountInfo.accountName.lastName = this.accountForm.value.lastName;
        this.accRespObj.accountInfo.accountName.middleName = this.accountForm.value.middleName;
        this.accRespObj.accountInfo.accountName.title = '';
        this.accRespObj.accountInfo.contact.contactNumber = this.accountForm.value.contactNumber;
        this.accRespObj.accountInfo.contact.smsNumber = this.accountForm && this.accountForm.value && this.accountForm.value.smsNumber;
        this.accRespObj.accountInfo.contact.emailAddress = this.accountForm && this.accountForm.value && this.accountForm.value.emailAddress;
        this.accRespObj.accountInfo.accountPreferences.paperlessBilling = false;
        this.accRespObj.accountInfo.accountPreferences.braille = false;
        this.accRespObj.accountInfo.accountPreferences.spanishBillPrint = false;
        this.accRespObj.accountInfo.accountPreferences.largePrint = false;
        if (this.accountForm && this.accountForm.value && this.accountForm.value.emailAddrDeclined === true) {
            this.accRespObj.accountInfo.contact.emailAddrDeclined = true;
            this.accRespObj.accountInfo.contact.emailAddress = "";
        }

        switch (this.refObj.billingOpt) {
            case 'paperless':
                this.accRespObj.accountInfo.accountPreferences.paperlessBilling = true;
                break;
            case 'braille':
                this.accRespObj.accountInfo.accountPreferences.braille = true;
                break;
            case 'spanish':
                this.accRespObj.accountInfo.accountPreferences.spanishBillPrint = true;
                break;
            case 'large':
                this.accRespObj.accountInfo.accountPreferences.largePrint = true;
                break;
            default: break;
        }
        this.accRespObj.accountInfo.accountType = 'I';
        this.accRespObj.accountInfo.accountSubType = 'R';
        let cont = this.accRespObj.accountInfo.contact.contactNumber;
        if (cont) {
            this.accRespObj.accountInfo.contact.contactNumber = cont.match(/\d/g).join('');
        }
        let sms = this.accRespObj.accountInfo.contact.smsNumber;
        if (sms) {
            this.accRespObj.accountInfo.contact.smsNumber = sms.match(/\d/g).join('');
        }
        this.accRespObj = Object.assign({},
            this.accRespObj, {
            creditClass: this.accRespObj.creditClass !== null ? this.accRespObj.creditClass : '3'
        });
        this.accRespObj.billingAdditionalInfo = this.refObj.addrCareOf;
        if (this.refObj.addrTypeSelected === 'International') {
            this.accRespObj.billingAddressType = 'F';
        } else if (this.refObj.addrTypeSelected === 'Street Address') {
            this.accRespObj.billingAddressType = 'S';
        } else if (this.refObj.addrTypeSelected === 'P.O. Box') {
            this.accRespObj.billingAddressType = 'P';
        } else if (this.refObj.addrTypeSelected === 'Rural Route') {
            this.accRespObj.billingAddressType = 'R';
        } else if (this.refObj.addrTypeSelected === 'Military') {
            this.accRespObj.billingAddressType = 'M';
        }
    }

    public cancelOrder() {
        this.router.navigate(['/home']);
    }

    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    /** unsubscribe on destroy */
    public ngOnDestroy() {
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }
        if (this.accountSubscription !== undefined) {
            this.accountSubscription.unsubscribe();
        }
        if (this.creditRevSubscription !== undefined) {
            this.creditRevSubscription.unsubscribe();
        }
        if (this.orderSubscription !== undefined) {
            this.orderSubscription.unsubscribe();
        }
        if (this.retainSubscription !== undefined) {
            this.retainSubscription.unsubscribe();
        }
        if (this.existingProductStoreSubscription !== undefined) {
            this.existingProductStoreSubscription.unsubscribe();
        }
        if (this.creditCheckRetain !== undefined) {
            this.creditCheckRetain.unsubscribe();
        }
        if (this.apptSubscription !== undefined) {
            this.apptSubscription.unsubscribe();
        }
    }
    public getEffectiveBilldate(){
        let currentStore = this.appStateService.getState();
        let retainVal = currentStore.order;
        if (retainVal && retainVal["effectivebilldate"]) {
           let effectivebilldate= retainVal["effectivebilldate"] ;
           if(effectivebilldate && effectivebilldate.payload && effectivebilldate.payload.dueDate && effectivebilldate.payload.dueDate.finalDueDate)
           {
               this.effectiveBilldate= effectivebilldate.payload.dueDate.finalDueDate;
             // return effectivebilldate.payload.dueDate.finalDueDate;
             this.convertToString(this.effectiveBilldate);
           }
        }
    }

    public convertToString(date){
      let effectiveBilldateNumber = parseInt(moment(date).utc().format('DD'));
     // let effectiveBilldateNumber = parseInt(moment(UTCTime).tz('America/Denver').format('DD'));
      let list =[29,30,31]
      if(list.indexOf(effectiveBilldateNumber) > -1){
        effectiveBilldateNumber = 1;
      }
      if(effectiveBilldateNumber)
      {
          this.effectiveBilldateNumber = effectiveBilldateNumber;
      }
    }
    public nth = (d: number) => {
        if (d > 3 && d < 21) return 'th';
        switch (d % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }
}