import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { AmendAccountComponent } from './ppamend-account.component';
import { AccountService } from 'app/common/service/account.service';
import { creditService } from 'app/common/service/credit-check.service';
import { SharedModule } from 'app/shared/shared.module';
import { TextMaskService } from 'app/common/service/text-mask.service';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: AmendAccountComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        TextMaskModule,
        SharedCommonModule,
        SharedModule
    ],
    exports: [
        AmendAccountComponent
    ],
    declarations: [
        AmendAccountComponent
    ],
    providers: [
        AccountService,
        TextMaskService,
        creditService
    ]
})
export class AmendAccountModule { }
