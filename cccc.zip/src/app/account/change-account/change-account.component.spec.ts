import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ChangeAccountComponent } from './change-account.component';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { Router } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MockServer } from 'app/MockServer.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { AccountService } from 'app/common/service/account.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { DirectvService } from 'app/common/service/directv.services';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Observable, of, throwError } from 'rxjs';
import {
   MockAccountService,
   MockSystemErrorService,
   MockAppStateService,
   MockRouter,
   MockCTLHelperService,
   MockLogger,
   MockHelperService,
   MockPendingOrderService,
   MockBlueMarbleService,
   MockCountryStateService,
   MockDisconnectService,
   MockProductService,
   MockAddressService,
   MOCK_ROUTES
 } from 'app/common/service/mockServices.test';
import { RouterTestingModule } from '@angular/router/testing';
import "rxjs/add/observable/of";
import { creditService } from 'app/common/service/credit-check.service';
import { HelperService } from 'app/common/service/helper.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { ProductService } from 'app/common/service/product.service';
import { AddressService } from 'app/common/service/address.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';

describe('ChangeAccountComponent', () => {
  let component: ChangeAccountComponent;
  let fixture: ComponentFixture<ChangeAccountComponent>;
  const mockServer = new MockServer();
  
  const mockRedux: any = {
      dispatch(obj) {return obj},
      configureStore() {},
      select(reducer) {
          return Observable.of(
            mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
      }
  };

  const imports = [
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    TextMaskModule,
    SharedCommonModule,
    SharedModule,
    RouterTestingModule.withRoutes(MOCK_ROUTES)
  ];

  class MockCreditService {}

  class MockReviewOrderService {
    getChangeReviewOrderInfo() {
      return of(mockServer.getResponseForRequest('changeAccountPageContinueRes'));
    }
  }
  class MockDirectvService {
    retrieveDtvOrder() {
      return throwError({errorResponse: []});
    }
    orderDtvProcess() {
      return throwError({errorResponse: []});
    }
  }

  const logger = { provide: Logger, useClass: MockLogger}
  const router = { provide: Router, useClass: MockRouter };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };
  const cTLHelperService = { provide: CTLHelperService, useClass: MockCTLHelperService };
  const credService = { provide: creditService, useClass: MockCreditService };
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const blueMarbleService = {provide: BlueMarbleService, useClass: MockBlueMarbleService};
  const countryStateService = {provide: CountryStateService, useClass: MockCountryStateService};
  const disconnectService = {provide: DisconnectService, useClass: MockDisconnectService};
  const productService = {provide: ProductService, useClass: MockProductService};
  const addressService = {provide: AddressService, useClass: MockAddressService};
  const propertiesHelperService = PropertiesHelperService;
  
  const providers = [
      logger, router, store, appStateService, reviewOrderService, accountService,
      systemErrorService, directvService, cTLHelperService, credService, helperService, pendingOrderService,
      blueMarbleService, countryStateService, disconnectService, productService, addressService,
      propertiesHelperService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [ChangeAccountComponent],
    providers: providers
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call handleBackToExistingProducts', () => {
    let actual = component.handleBackToExistingProducts(event);
    expect(actual).toBeUndefined();
  });

  it('should call cancelClick', () => {
    let actual = component.cancelClick();
    expect(actual).toBeUndefined();
  });

  it('should call dtvAccNo', () => {
    let actual = component.dtvAccNo(12345);
    expect(component.saveConfigApiCall).toBe(true);
    expect(actual).toBe(undefined);
  });

  it('should call checkUpdatedOtc', () => {
    let actual = component.checkUpdatedOtc({});
    expect(component.otcUpdated).toEqual({});
    expect(actual).toBeUndefined();
  });

  it('should call updateChangePaymentDetails', () => {
    let actual = component.updateChangePaymentDetails({});
    expect(actual).toBeUndefined();
  });

  it('should call continueClick', () => {
    let actual = component.continueClick();
    expect(actual).toBeUndefined();
  });

  it('should call bmOrderProcess and get the success response', () => {
    const req = mockServer.getResponseForRequest('changeAccountPageContinueReq');
    let actual = component.bmOrderProcess(req);
    expect(component.loading).toBe(true);
    expect(actual).toBeUndefined();
  });

  it('should call retrieveDtvOrder and get the error response', () => {
    const req = mockServer.getResponseForRequest('changeAccountPageContinueReq');
    let actual = component.retrieveDtvOrder(req);
    expect(component.loading).toBe(false);
    expect(actual).toBeUndefined();
  });

  it('should call retrieveDtvOrder and get the error response', () => {
    const req = mockServer.getResponseForRequest('changeAccountPageContinueReq');
    let actual = component.orderDtvProcess(req);
    expect(component.loading).toBe(false);
    expect(actual).toBeUndefined();
  });

  it('should call opusSessionInfoNotFoundCallback and assign object', () => {
    let actual = component.opusSessionInfoNotFoundCallback({});
    expect((component as any).dtvAccountInfoManuallyEntered).toEqual({});
    expect(actual).toBeUndefined();
  });

  it('should call checkUpdatedOtc and otcUpdated should have been defined and assigned', () => {
    let data : any = {};
    component.checkUpdatedOtc(data);
    expect(component.otcUpdated).toBeDefined();
    expect(component.otcUpdated).toEqual(data);
  });

  it('should call ngOnDestroy', () => {
    component.ngOnDestroy();
    expect(component.OtcSubscription).toBeUndefined();
  });

});
