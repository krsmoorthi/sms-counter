import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { DirectvService } from 'app/common/service/directv.services';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AccountInfomation } from '../../common/models/account.model';
import { APIErrorLists, ErrorResponse, serverErrorMessages } from '../../common/models/common.model';
import { User } from '../../common/models/user.model';
import { Logger } from './../../common/logging/default-log.service';
import { AppStore } from './../../common/models/appstore.model';
import { AccountService } from './../../common/service/account.service';
import { AppStateService } from './../../common/service/app-state.service';
import { ReviewOrderService } from './../../common/service/review-order.service';
import { SystemErrorService } from './../../common/service/system-error.service';
import "rxjs/add/operator/catch";

@Component({
    selector: 'change-account',
    templateUrl: './change-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})
export class ChangeAccountComponent implements OnInit, OnDestroy {
    public retrieveDtvData: any;
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public retainObservableData: any;
    public saveConfigApiCall: boolean = false;
    public loading = false;
    public errorMsg = '';
    public accountSubscription;
    public accountObservable: Observable<AccountInfomation>;
    public nextReqPayloadObj: any;
    public accInformation: any = {};
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public user: Observable<User>;
    public userData: any;
    public userSubscription: Subscription;
    public OtcSubscription: Subscription;
    public otcUpdated: any;
    private isReEntrant: boolean = false;
    private dtvExists: boolean = false;
    private taskId: string = '';
    public dtv: boolean = false;
    public accInformationCreditReview: any;
    @ViewChild("creditCheck", { static: false, }) public creditCheck: any;
    @ViewChild('opusSessionInfoNotFound', { static: false, }) public opusSessionInfoNotFound: DialogComponent;
    public apiResponseError: APIErrorLists;
    private orderRefNumber: string;
    public isDtvSessionInfo: boolean = false;
    public isDtvOpus: boolean;
    public accountRentrantValue: any;
    private removedDTV: boolean = false;
    public isAmend: boolean = false;
    public isStack: boolean = false;
    public depositBypass: boolean = false;
    public stackAmendDropDownTitle: string = '';
    private dtvAccountInfoManuallyEntered: any = false;

    public otcDataResponse: any;
    public orderReferenceNumber: any;

    constructor(
        private logger: Logger,
        private router: Router,
        public store: Store<AppStore>,
        private appStateService: AppStateService,
        private reviewOrderService: ReviewOrderService,
        private accountService: AccountService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private directvService: DirectvService
    ) {
        this.appStateService.setLocationURLs();
        this.accountObservable = <Observable<AccountInfomation>>store.select('account');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            if (respData) {
                this.accInformation = respData;
                this.initializeData();
            }
        });
        this.accountObservable = <Observable<AccountInfomation>>store.select('creditReview');
        this.accountSubscription = this.accountObservable.subscribe((respData) => {
            if (respData) {
                this.accInformationCreditReview = respData;
                this.initializeData();
            }
        });
        this.user = <Observable<User>>store.select('user');
        let userData;
        this.userSubscription = this.user.subscribe((data) => {
            userData = data;
            this.userData = userData;
            this.isDtvOpus = data.isDtvOpus;
            if (this.isDtvOpus) {
                if (userData && userData.dtvOpus && userData.dtvOpus.taskName && userData.dtvOpus.taskName === 'yes') {
                    this.dtvExists = true;
                    this.dtv = false;
                } else {
                    this.dtvExists = false;
                    this.dtv = true;
                }
            } else {
                if (userData && userData.dtvQuestionForm && userData.dtvQuestionForm.taskName && userData.dtvQuestionForm.taskName === 'yes') {
                    this.dtvExists = true;
                    this.dtv = false;
                } else {
                    this.dtvExists = false;
                    this.dtv = true;
                }
            }

            if (userData && userData.orderRefNumber) {
                this.orderRefNumber = userData.orderRefNumber;
            }
        });

        if (this.accountService.otcRelated$) {
            this.OtcSubscription = this.accountService.otcRelated$.subscribe((data) => {
                this.otcUpdated = data;
            });
        }

        this.retainObservable = <Observable<any>>this.store.select("retain");
        this.retainObservable.subscribe(response => {
            if (response.dtvAccountInfo) {
                this.dtvAccountInfoManuallyEntered = response.dtvAccountInfo;
            }
            this.retainObservableData = response;
            if (response && response.removedDTV) {
                this.removedDTV = response.removedDTV;
            }
            this.depositBypass = response.bypassedvalue ? response.bypassedvalue : false;
        });

        this.existingObservable = <Observable<any>>this.store.select('existingProducts');
        this.existingSubscription = this.existingObservable.subscribe((data) => {
            if (data && data.stackamend && data.stackamend.stackAmendFlag === 'stackOrder') {
                this.isStack = true;
                this.stackAmendDropDownTitle = 'Stack Order';
            } else if (data && data.stackamend && data.stackamend.stackAmendFlag === 'amendOrder') {
                this.isAmend = true;
                this.stackAmendDropDownTitle = 'Amend Order';
            }
        });
        this.existingSubscription.unsubscribe();
    }

    public ngOnInit() {
        this.logger.metrics('AccountChangePage');
        window.scroll(0, 0);
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainObservable.subscribe(
            (retVal) => {
                if (retVal && retVal.accountreentrant !== undefined && retVal.accountreentrant) {
                    this.accountRentrantValue = retVal.accountreentrant;
                }
                this.isReEntrant = retVal.isreenterent;
                if (this.isReEntrant) {
                    this.dtv = true;
                }
                this.user = <Observable<User>>this.store.select('user');
                this.userSubscription = this.user.subscribe((data) => {
                    if (this.isReEntrant) {
                        this.dtv = true;
                        this.taskId = data.taskId;
                    }
                    if (data.previousUrl !== '/schedule-appt-ship') {
                        this.isReEntrant = true;
                        this.taskId = data.taskId;
                    }
                });
                if (retVal.dtvSessionInfo && retVal.dtvSessionInfo.payload) {
                    this.isDtvSessionInfo = true;
                }
            });
    }

    public disabledContinue() {
        if (this.isDtvOpus && this.dtvExists && !this.isDtvSessionInfo && this.removedDTV) {
            return false;
        } else if (this.isDtvOpus && this.dtvExists && !this.isDtvSessionInfo) {
            return true;
        } else {
            return false;
        }
    }

    public initializeData() {
        this.nextReqPayloadObj = {
            paymentStatus: []
        };
    }

    public updateChangePaymentDetails(paidObj) {
        this.nextReqPayloadObj.paymentStatus.push(paidObj);
    }

    public dtvAccNo(dtv: number) {
        this.dtv = (dtv.toString().length > 0) ? true : false;
        if (this.dtv) {
            this.saveConfigApiCall = true;
        } else {
            this.saveConfigApiCall = false;
        }
    }
    public handleBackToExistingProducts(event) {
        this.router.navigate(['/existing-products']);
    }

    public bmOrderProcess(requestObject) {
        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "change-account.component.ts", "changeReviewOrderRequest", JSON.stringify(requestObject));
        this.logger.startTime();
        this.reviewOrderService.getChangeReviewOrderInfo(requestObject).catch((error: any) => {
            this.logger.endTime();
            this.logger.log("error", "change-account.component.ts", "changeReviewOrderResponse", error);
            this.logger.log("error", "change-account.component.ts", "changeReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;
            errorResolved = true;
            this.ctlHelperService.setLocalStorage('error', error);
            this.systemErrorService.logAndRouteUnexpectedError(
                "error", "Not Applicable",
                "changeReviewOrderRequest", "change-account.component.ts",
                "changeReviewOrderRequest order",
                error);
            return Observable.throwError(null);
        })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "change-account.component.ts", "changeReviewOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "change-account.component.ts", "changeReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let response = data;
                    if (response && response.payload && response.payload.paymentDetails !== undefined && response.payload.paymentDetails) {
                        this.store.dispatch({ type: 'PAYMENT_DATA', payload: response.payload.paymentDetails });
                    }
                    if (response) {
                        this.store.dispatch({ type: 'TASK_ID', payload: response.taskId });
                        this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                        this.router.navigate(['/co-review-order']);
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "change-account.component.ts", "changeReviewOrderResponse", error);
                        this.logger.log("error", "change-account.component.ts", "changeReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null || errorResolved) { return; }
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "ChangeAccount", "change-account.component.ts", "Change Account Page", this.apiResponseError);
                        } else { unexpectedError = true; }
                    } else { unexpectedError = true; }
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "ChangeAccount", "change-account.component.ts", "Change Account Page", lAPIErrorLists);
                    }
                }
            );
    }

    public orderDtvProcess(requestObject) {
        let request: any;
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((data) => {
            request = {
                orderRefNumber: data.dtvSessionInfo && data.dtvSessionInfo.payload.orderReferenceNumber,
                processInstanceId: data.dtvSessionInfo && data.dtvSessionInfo.processInstanceId,
                taskId: data.dtvSessionInfo && data.dtvSessionInfo.taskId,
                taskName: data.dtvSessionInfo && data.dtvSessionInfo.taskName,
                payload: {
                    uniqueSessionId: data.dtvSessionInfo && data.dtvSessionInfo.payload.sessionInfo.uniqueSessionId,
                    attOrderType: "DIRECTV"
                }
            };
        });
        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.orderDtvProcess(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVinit", "account.component.ts",
                    "DIRECTV order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                this.loading = false;
                if (data && data.payload.taskName === 'Enter DTV Manually') {
                    this.opusSessionInfoNotFound.open();
                }
            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "change-account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "change-account.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });

    }

    public retrieveDtvOrder(requestObject) {
        this.loading = true;
        let request: any;
        request = {
            "uniqueSessionId": "",
            "attOrderType": "DIRECTV",
            "orderReferencNumber": requestObject.orderRefNumber
        };
        if (this.retainObservableData && this.retainObservableData.dtvSessionInfo && this.retainObservableData.dtvSessionInfo.payload && this.retainObservableData.dtvSessionInfo.payload.sessionInfo && this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId) {
            request.uniqueSessionId = this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId;
        }

        let errorResolved = false;
        this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.retrieveDtvOrder(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVRetrieveOrder", "change-account.component.ts",
                    "DIRECTV Retrieve order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    this.loading = false;
                    if (data.errorResponse[0].message === 'SESSION_ID_NON_FOUND') {
                        this.opusSessionInfoNotFound.open();
                    } else {
                        data.errorResponse[0]['status'] = "200";
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error",
                            "",
                            "retrieveDTVOrder",
                            "change-account.component.ts",
                            "Retrieve  DTV order",
                            data.errorResponse[0]
                        );
                        return Observable.throwError(null);
                    }
                } else {
                    this.logger.endTime();
                    this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                    this.orderDtvProcess(requestObject);
                    this.bmOrderProcess(requestObject);
                }

            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "change-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "change-account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    public continueClick() {
        if (this.saveConfigApiCall && !this.isDtvOpus) {
            this.creditCheck.callDtvSave();
        }
        let reqpayload = {
            "creditReviewAction": "SHOWSUMMARY",
            "accountName": {
                "firstName": this.userData.firstName,
                "lastName": this.userData.lastName,
                "middleName": this.userData.middleName ? this.userData.middleName : null,
                "businessName": null,
                "title": this.userData.title ? this.userData.title : null,
                "generation": null
            },
            "personalDetails": {
                "dateOfBirth": null,
                "dLExpirationDate": null,
                "dLlicenseNo": null,
                "dLlicenseState": null,
                "ssn": null,
                "taxId": null,
                "creditCheck": true,
                "underAgeAck": null
            },
            "addlOrderAttributes": this.otcUpdated ? this.otcUpdated : (this.accInformation && this.accInformation.payload && this.accInformation.payload.addlOrderAttributes)
        };
        let requestObject: AccountInfomation = {
            orderRefNumber: this.accInformation.orderRefNumber,
            processInstanceId: this.accInformation.processInstanceId,
            taskId: this.isReEntrant ? this.taskId : this.userData.taskId,
            taskName: this.accInformation.taskName,
            payload: reqpayload
        };
        let dipositBypass = {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "depositBypassed",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "depositBypassedInd",
                                    "orderAttributeValue": this.depositBypass
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        let depositeBypassOptional = {
            "orderAttributeGroup": [
                {
                    "orderAttributeGroupName": "agentEnsembleIdInfo",
                    "orderAttributeGroupInfo": [
                        {
                            "orderAttributes": [
                                {
                                    "orderAttributeName": "agentEnsembleId",
                                    "orderAttributeValue": "string"
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        if (!this.isReEntrant && requestObject) {
            requestObject.payload.addlOrderAttributes.push(dipositBypass);
            requestObject.payload.addlOrderAttributes.push(depositeBypassOptional);
        }

        requestObject && requestObject.payload.addlOrderAttributes.map(bipassData => {
            if (bipassData.orderAttributeGroup[0].orderAttributeGroupName === "depositBypassed") {
                bipassData.orderAttributeGroup[0].orderAttributeGroupInfo[0].orderAttributes[0].orderAttributeValue = this.depositBypass;
            }
        });
        if (this.accInformationCreditReview && this.accInformationCreditReview.taskId && this.accInformationCreditReview.taskId !== null) {
            requestObject.taskId = this.accInformationCreditReview.taskId;
        }
        if (this.dtvExists && this.isDtvOpus && !this.removedDTV && this.dtvAccountInfoManuallyEntered) {
            this.bmOrderProcess(requestObject);
        } else if (this.dtvExists && this.isDtvOpus && !this.removedDTV) {
            this.retrieveDtvOrder(requestObject);
        } else {
            this.bmOrderProcess(requestObject);
        }


    }

    public opusSessionInfoNotFoundCallback(data) {
        this.dtvAccountInfoManuallyEntered = data;
        this.continueClick();
    }

    public checkUpdatedOtc(data) {
        this.otcUpdated = data;
    }

    public cancelClick() {
        this.router.navigate(['/existing-products']);
    }

    /** unsubscribe on destroy */
    public ngOnDestroy() {
        if (this.OtcSubscription) this.OtcSubscription.unsubscribe();
        if (this.retainSubscription !== undefined) {
            this.retainSubscription.unsubscribe();
        }
        if (this.userSubscription !== undefined) {
            this.userSubscription.unsubscribe();
        }

    }
}
