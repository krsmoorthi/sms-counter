import { Component, OnInit, OnDestroy, ViewChild, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
// tslint:disable-next-line:no-unused-variable
import { FormGroup, FormBuilder } from '@angular/forms';
import { User } from '../../common/models/user.model';
import { AccountInfomation } from '../../common/models/account.model';
import { SystemErrorService } from '../../common/service/system-error.service';
import { AppStore } from '../../common/models/appstore.model';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { AppStateService } from '../../common/service/app-state.service';
import { AccountService } from '../../common/service/account.service';
import { SchedulingService } from '../../common/service/scheduling.service';
import { ReviewOrderService } from '../../common/service/review-order.service';
import { Logger } from '../../common/logging/default-log.service';
import {
    GenericValues, serverErrorMessages, APIErrorLists,
    ErrorResponse
} from '../../common/models/common.model';
import { ExistingProducts } from '../../common/models/existing-products.model';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { DirectvService } from 'app/common/service/directv.services';
import "rxjs/add/operator/catch";
import 'rxjs/add/operator/mergeMap';

@Component({
    selector: 'directv-account',
    templateUrl: './directv-account.component.html',
    styleUrls: ['../account-component/account.component.scss']
})

export class DirectTvComponent implements OnInit, OnDestroy {
    public retainSubscription: Subscription;
    public retainObservable: Observable<any>;
    public retainObservableData: any;
    public accRespObj: any;
    public personalDet: any;
    public ExtFlowObj: any;
    public isReentrant: boolean = false;
    public taskId: string;
    public user: Observable<any>;
    public userdata: Observable<User>;
    public userData: any;
    public orderData: any;
    public userSubscription: Subscription;
    public userSubscription$: Subscription;
    public isDTV = false;
    public newDtv = false;
    public ban: string;
    public flow: any;
    public schedulingRequest: any;
    public isChangeFlow: boolean = false;
    public dtvForm: FormGroup;
    public orderReferenceNumber: string;
    public moveFlow: boolean = false;
    public billingFlow: boolean;
    private existingProducts: Observable<ExistingProducts>;
    public existingProductsSubscription: Subscription;
    public dtvAccUrl: boolean = false;
    @Output() public dtvAccNo: EventEmitter<number> = new EventEmitter<number>();
    @ViewChild('opusSessionInfoNotFound', { static: false, }) public opusSessionInfoNotFound: DialogComponent;
    @ViewChild('dtvManualPriceplanEntry', { static: false, }) public dtvManualPriceplanEntry: DialogComponent;
    public apptObservable: Observable<any>;
    public apptSubscription: Subscription;
    public reservedDate: any;
    public reservedTime: any;
    public loading: boolean = false;
    public apiResponseError: APIErrorLists;
    public isDtvSessionInfo: boolean = false;
    public isDtvOpus: boolean;
    public removedDTV: boolean = false;
    public accountObservable: Observable<AccountInfomation>;
    public accountSubscription;
    private accInformationCreditReview: any;
    private newBillingAddress: any;
    private isAddressSelected = 'New Service address';
    public nextReqPayloadObj: any = {};
    private newServiceAddressObj: any = {};
    public accInformation: any = {};
    public refObj = {
        finalEmail: '',
        selectedOpt: '',
        submitted: false,
        isEmailValid: true
    };
    public payload: any;
    private isReEntrant: boolean = false;
    public accountPin: any;
    public moveSubscription;
    public moveObservable: Observable<any>;
    public OtcSubscription: Subscription;
    public existingObservable: Observable<any>;
    public existingSubscription: Subscription;
    public otcUpdated: any;
    public DTVPendingOrder: boolean = false;
    public billingAddress: string;
    public showDtvManualCorrections: boolean = false;
    private dtvAccountInfo: any = false;
    private dtvAccountInfoManuallyEntered: any = false;
    public isAmend: boolean = false;
    public agentFirstName: string;
    public agentLastName: string;
    public legacy: string;

    constructor(private logger: Logger,
        private fb: FormBuilder,
        private router: Router,
        private accountService: AccountService,
        private reviewOrderService: ReviewOrderService,
        private store: Store<AppStore>,
        private appStateService: AppStateService,
        private schedulingService: SchedulingService,
        private systemErrorService: SystemErrorService,
        private ctlHelperService: CTLHelperService,
        private directvService: DirectvService
    ) {
        this.appStateService.setLocationURLs();
        this.user = <Observable<any>>store.select('order');
        this.userSubscription = this.user.subscribe(
            (usr) => {
                if (usr && usr.orderInit && usr.orderInit.payload && usr.orderInit.payload.serviceAddress && usr.orderInit.payload.serviceAddress.locationAttributes && usr.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
                    this.legacy = usr.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
                }
                this.orderData = usr;
                this.orderReferenceNumber = usr.orderRefNumber;
                if (usr.payload && usr.payload.dtvAccountInfo) {
                    this.dtvAccountInfo = usr.payload.dtvAccountInfo;
                }
            });
        this.userSubscription.unsubscribe();
        this.userdata = <Observable<User>>store.select('user');
        this.userSubscription$ = this.userdata.subscribe(
            (userdata) => {
                this.userData = userdata;
                this.ban = userdata && userdata.ban;
                if (userdata && userdata.taskId) {
                    this.taskId = userdata.taskId;
                }
                if (userdata.autoLogin && userdata.autoLogin.oamData && userdata.autoLogin.oamData.agentFirstName && userdata.autoLogin.oamData.agentLastName) {
                    this.agentFirstName = userdata.autoLogin.oamData.agentFirstName;
                    this.agentLastName = userdata.autoLogin.oamData.agentLastName;
                }
                if (userdata.previousUrl === '/move-schedule-appt-ship') {
                    this.orderReferenceNumber = userdata.orderInit.orderRefNumber;
                    this.moveFlow = true;
                    this.flow = 'move';
                }
                if (userdata.currentUrl === '/directv-account') {
                    this.dtvAccUrl = true;
                } else {
                    this.dtvAccUrl = false;
                }
                this.isDtvOpus = userdata.isDtvOpus;
                if (Array.isArray(userdata.currentSelected)) {
                    userdata.currentSelected.forEach((val: any) => {
                        if (val.selected === GenericValues.cDTV) {
                            this.isDTV = true;
                        }
                    });
                    if (this.isDtvOpus) {
                        if (userdata.dtvOpus) {
                            if (userdata.dtvOpus.taskName === 'yes') {
                                this.newDtv = true;
                            }
                        }
                    } else {
                        if (userdata.dtvQuestionForm) {
                            if (userdata.dtvQuestionForm.taskName === 'yes') {
                                this.newDtv = true;
                            }
                        }
                    }
                }
            });
        this.userSubscription$.unsubscribe();
        this.existingProducts = <Observable<ExistingProducts>>store.select('existingProducts');
        this.existingProductsSubscription = this.existingProducts.subscribe((data) => {
            this.ExtFlowObj = data;
            if (data !== null && data !== undefined && data.ban) {
                this.ban = data.ban;
            }
            if (!this.dtvAccUrl) {
                this.orderReferenceNumber = this.ExtFlowObj && this.ExtFlowObj.orderInit && this.ExtFlowObj.orderInit.orderRefNumber;
            }
            if (data && data.orderFlow && data.orderFlow.flow && data.orderFlow.flow === 'Change') {
                this.isChangeFlow = true;
                this.flow = 'change';
            }
            if (data && data.orderFlow && data.orderFlow.flow && data.orderFlow.flow === 'billing') {
                this.billingFlow = true;
                this.flow = 'billing';
                if (data.existingProductsAndServices && data.existingProductsAndServices[0] && data.existingProductsAndServices[0].accountInfo &&
                    data.existingProductsAndServices[0].accountInfo.ban) {
                    this.ban = data.existingProductsAndServices[0].accountInfo.ban;
                }
            }
            if (data && data.stackamend && data.stackamend.stackAmendFlag === 'amendOrder') {
                this.isAmend = true;
            }

            //checking if DTV is existing and pending orders and setting the flag to true to enable continue button.
            if (data && data.pendingOrders) {
                data.pendingOrders.map(orders => {
                    if (orders.orderDocument) {
                        orders.orderDocument.productConfiguration.map(config => {
                            if (config.productType === "VIDEO-DTV") {
                                this.DTVPendingOrder = true;
                            }
                        });
                    }
                });
            }
        });
        this.apptObservable = <Observable<any>>this.store.select('appointment');
        this.apptSubscription = this.apptObservable.subscribe((data) => {
            if (data.reservedAppointment) {
                this.reservedDate = data.reservedAppointment.commitmentDateTime;
                this.reservedTime = data.reservedAppointment.timeSlot;
            } else if (data.payload.dueDate) {
                this.reservedDate = data.payload.dueDate.finalDueDate;
            }
        });

        this.retainObservable = <Observable<any>>this.store.select("retain");
        this.retainObservable.subscribe(response => {
            this.retainObservableData = response;
            if (response.removedDTV) {
                this.removedDTV = response.removedDTV;
            }
            if (response.dtvAccountInfo) {
                this.dtvAccountInfoManuallyEntered = response.dtvAccountInfo;
            }
        });

        if (!this.moveFlow) {
            this.accountObservable = <Observable<AccountInfomation>>store.select('account');
            this.accountSubscription = this.accountObservable.subscribe((respData) => {
                if (respData) {
                    this.accInformation = respData;
                    this.initializeData();
                }
            });
            this.moveObservable = <Observable<AccountInfomation>>store.select('move');
            this.moveSubscription = this.moveObservable.subscribe((respData) => {
                if (respData && this.isReEntrant) {
                    this.isAddressSelected = respData.AddressType;
                    this.initializeData();
                }
            });

            this.OtcSubscription = this.accountService.otcRelated$.subscribe((data) => {
                this.otcUpdated = data;
            });
            this.existingObservable = <Observable<any>>store.select('existingProducts');
            this.existingSubscription = this.existingObservable.subscribe((data) => {
                this.ban = data.existingProductsAndServices[0].accountInfo.ban;
                this.accountPin = data.existingProductsAndServices[0].accountInfo.accountPin;

            });

            this.accountObservable = <Observable<AccountInfomation>>this.store.select('creditReview');
            this.accountSubscription = this.accountObservable.subscribe((respData) => { // getting updated taskid from credit reiew store
                if (respData) {
                    this.accInformationCreditReview = respData;
                }
            });
        }

        if (this.flow === 'billing' && this.dtvAccountInfo) {
            this.showDtvManualCorrections = true;
        }
        if (this.userData && this.userData.orderInit && this.userData.orderInit.payload && this.userData.orderInit.payload.newLocation && this.userData.orderInit.payload.newLocation.serviceAddress) {
            this.newServiceAddressObj = this.userData.orderInit.payload.newLocation.serviceAddress;
        }
    }
    public ngOnInit() {
        this.logger.metrics('AccountDIRECTVPage');
        if (this.ExtFlowObj && this.ExtFlowObj.existingProductsAndServices && this.ExtFlowObj.existingProductsAndServices[0] && this.ExtFlowObj.existingProductsAndServices[0] &&
            this.ExtFlowObj.existingProductsAndServices[0].accountInfo) {
            this.personalDet = this.ExtFlowObj.existingProductsAndServices[0].accountInfo.personalDetails;
            this.ban = this.ExtFlowObj.existingProductsAndServices[0].accountInfo.ban;
            this.accRespObj = this.ExtFlowObj.existingProductsAndServices[0].accountInfo;
        }
        window.scroll(0, 0);
        this.dtvForm = this.fb.group({
            'dtvAccNo': ['']
        });
        this.userdata = <Observable<User>>this.store.select('user');
        this.userSubscription$ = this.userdata.subscribe((userdata) => {
            if (userdata.previousUrl !== '/schedule-appt-ship') {
                this.isReentrant = true;
                this.store.dispatch({ type: 'IS_REENTRENT', payload: this.isReentrant });
            }
        });
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe(
            (retVal) => {
                this.isReentrant = retVal.isreenterent;
                if (this.isReentrant) {
                    this.dtvForm.get('dtvAccNo').setValue(retVal.dtvaccountid);
                }
                if (retVal.dtvSessionInfo && retVal.dtvSessionInfo.payload) {
                    this.isDtvSessionInfo = true;
                }
            });
    }

    public assignBillingAddress() {
        if (this.isAddressSelected === 'New Service address') {
            this.nextReqPayloadObj.isBillAddrSameAsServiceAddress = true;
            this.nextReqPayloadObj.billingAddress = this.newServiceAddressObj;
        }
        else if (this.isAddressSelected === 'Current Billing address') {
            this.nextReqPayloadObj.isBillAddrSameAsServiceAddress = false;
            this.nextReqPayloadObj.billingAddress = this.accInformation && this.accInformation.payload && this.accInformation.payload.billingAddress;
        }
    }

    public initializeData() {
        if (this.accInformation.taskName === 'Credit Review' && this.accInformation.payload.billingAddress && this.accInformation.payload.billingAddress.streetAddress) {
            this.billingAddress = this.accInformation.payload.billingAddress.streetAddress + ', ' +
                this.accInformation.payload.billingAddress.city + ', ' +
                this.accInformation.payload.billingAddress.stateOrProvince + ', ' +
                this.accInformation.payload.billingAddress.postCode + ', ';
        }
        //as continue click failed with 400, come back to same page and reinitialized international billling to service address. So added a if condition here. This can be removed if BM fixes 400 issue
        if (this.nextReqPayloadObj && this.nextReqPayloadObj.billingAddressType && this.nextReqPayloadObj.billingAddressType !== 'F') {
            this.nextReqPayloadObj = {
                paymentStatus: [],
                billingAddress: this.newServiceAddressObj,
                isBillAddrSameAsServiceAddress: false,
                billingAdditionalInfo: this.accInformation && this.accInformation.payload && this.accInformation.payload.billingAdditionalInfo,
                billingAddressType: this.accInformation && this.accInformation.payload && this.accInformation.payload.billingAddressType
            };
        }
    }
    public sendDtv(dtv: number) {
        this.dtvAccNo.emit(dtv);
    }
    public marginleft() {
        if (this.dtvAccUrl && this.isChangeFlow) {
            return "200px";
        } else {
            return "0px";
        }
    }
    public popupCenter(url, w, h) {
        var left = (screen.width / 2) - (w / 2);
        var top = (screen.height / 2) - (h / 2);
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    }

    public bmOrderProcess() {
        this.assignBillingAddress();
        if (this.moveFlow) {
            let accountObs = <Observable<AccountInfomation>>this.store.select('account');
            let accountSub = accountObs.subscribe((respData) => {
                if (respData) {
                    this.accInformation = respData;
                }
            });
            if (accountSub !== undefined) { accountSub.unsubscribe(); }
        }
        let finalBillAddressToReq = this.nextReqPayloadObj.billingAddress;
        let tmpbillingAdditionalInfo = this.nextReqPayloadObj.billingAdditionalInfo;
        let tmpbillingAddressType = this.nextReqPayloadObj.billingAddressType;
        //getting updated billing address from payment submitTask response
        if (this.accInformationCreditReview && this.accInformationCreditReview.billingAddress) {
            this.newBillingAddress = this.accInformationCreditReview.billingAddress;
        }
        if (finalBillAddressToReq) {
            delete finalBillAddressToReq.timeZone;
            delete finalBillAddressToReq.npaNxxList;
            delete finalBillAddressToReq.locationAttributes;
            delete finalBillAddressToReq.geoPoint;
            delete finalBillAddressToReq.streetNrLastSuffix;
            delete finalBillAddressToReq.streetNrLast;
            delete finalBillAddressToReq.addressId;
            delete finalBillAddressToReq.validated;
            delete finalBillAddressToReq.isValidated;
            delete finalBillAddressToReq.sourceId;
            delete finalBillAddressToReq.geoAddressId;
        }
        if (this.newBillingAddress) {
            delete this.newBillingAddress.timeZone;
            delete this.newBillingAddress.npaNxxList;
            delete this.newBillingAddress.locationAttributes;
            delete this.newBillingAddress.geoPoint;
            delete this.newBillingAddress.streetNrLastSuffix;
            delete this.newBillingAddress.streetNrLast;
            delete this.newBillingAddress.addressId;
            delete this.newBillingAddress.validated;
            delete this.newBillingAddress.isValidated;
            delete this.newBillingAddress.sourceId;
            delete this.newBillingAddress.geoAddressId;
        }
        let addressType = this.isAddressSelected;
        this.store.dispatch({ type: 'ADDRESS_TYPE', payload: { AddressType: addressType } });
        if (this.accInformation && this.accInformation.payload && this.accInformation.payload.paperlessInfo) {
            this.accInformation.payload.paperlessInfo.paperlessBilling = this.refObj.selectedOpt === "yesPaperless" ? true : false;
            this.accInformation.payload.paperlessInfo.emailAddress = this.refObj.selectedOpt === "yesPaperless" ? this.refObj.finalEmail : '';
        }
        let paperlessInfo: any;
        let addlOrderAttributes: any;
        if (this.accInformation && this.accInformation.payload && this.accInformation.payload.paperlessInfo) {
            paperlessInfo = this.accInformation.payload.paperlessInfo;
        }
        if (this.accInformation && this.accInformation.payload && this.accInformation.payload.addlOrderAttributes) {
            addlOrderAttributes = this.accInformation.payload.addlOrderAttributes;
        }

        this.payload = {
            "creditReviewAction": "SHOWSUMMARY",
            "accountName": {
                "firstName": this.userData.firstName,
                "lastName": this.userData.lastName,
                "ban": this.ban,
                "accountPin": this.accountPin,
                "ssn": null,
                "dob": null
            },
            //updated billing address for updated credit-review request
            "paperlessInfo": paperlessInfo,
            "billingAdditionalInfo": tmpbillingAdditionalInfo,
            "billingAddressType": tmpbillingAddressType,
            "billingAddress": this.newBillingAddress === undefined ? finalBillAddressToReq : this.newBillingAddress,
            "addlOrderAttributes": this.otcUpdated ? this.otcUpdated : addlOrderAttributes
        };

        if (this.flow === 'billing' && this.dtvAccountInfo && this.dtvAccountInfoManuallyEntered) {
            this.payload['manualAddedDTV'] = this.dtvAccountInfoManuallyEntered.taskName ? false : true;
            this.payload['dtvAccountInfo'] = {
                "orderRefeNumber": this.dtvAccountInfo.orderReferenceNumber,
                "dtvSale": this.dtvAccountInfo.dtvSale,
                "attAccountNumber": this.dtvAccountInfo.attAccountNumber
            };
        }
        if (this.flow === 'billing' && this.dtvAccountInfo && !this.dtvAccountInfoManuallyEntered) {
            this.payload['manualAddedDTV'] = false;
        }
        let requestObject: AccountInfomation = {
            orderRefNumber: this.accInformation.orderRefNumber,
            processInstanceId: this.accInformation.processInstanceId,
            taskId: this.isReEntrant ? this.taskId : (this.accInformation && this.accInformation.taskId ? this.accInformation.taskId : ''),
            taskName: this.accInformation && this.accInformation.taskName ? this.accInformation.taskName : '',
            payload: this.payload
        };

        if (this.flow === 'billing') {
            delete this.payload['billingAddress']; // billing address should not there for B&R flow
            requestObject.orderRefNumber = this.orderData.orderRefNumber;
            requestObject.processInstanceId = this.orderData.processInstanceId;
            requestObject.taskId = this.orderData.taskId;
            requestObject.taskName = this.orderData.taskName;
        }

        if (this.accInformationCreditReview && this.accInformationCreditReview.taskId) {
            requestObject.taskId = this.accInformationCreditReview.taskId;
        }

        this.loading = true;
        let errorResolved = false;
        this.logger.log("info", "directv-account.component.ts", "moveReviewOrderRequest", JSON.stringify(requestObject));
        this.logger.startTime();
        this.reviewOrderService.getMoveReviewOrderInfo(requestObject, this.flow)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "directv-account.component.ts", "moveReviewOrderResponse", error);
                this.logger.log("error", "directv-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "Submit Task", "directv-account.component.ts",
                    "Move to Review Order - Move Account Page",
                    error);
                return Observable.throwError(null);
            })
            .subscribe(
                (data) => {
                    this.logger.endTime();
                    this.logger.log("info", "directv-account.component.ts", "moveReviewOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "directv-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    let response = data;
                    if (response.payload && response.payload.paymentDetails !== undefined && response.payload.paymentDetails) {
                        this.store.dispatch({ type: 'PAYMENT_DATA', payload: response.payload.paymentDetails });
                    }
                    this.store.dispatch({ type: 'REVIEW_ORDER', payload: response });
                    this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                    if (response.taskName === 'Credit Review' && response.payload.edsError) {
                        this.loading = false;
                        this.dtvManualPriceplanEntry.open();
                        return;
                    }
                    if (this.flow === 'billing') {
                        this.router.navigate(['/billing-review-order']);
                    } else {
                        this.router.navigate(['/mo-review-order']);
                    }
                },
                (error) => {
                    if (!errorResolved) {
                        this.logger.endTime();
                        this.logger.log("error", "directv-account.component.ts", "moveReviewOrderResponse", error);
                        this.logger.log("error", "directv-account.component.ts", "moveReviewOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    }
                    this.loading = false;
                    if (error === undefined || error === null) {
                        return;
                    }
                    let unexpectedError = false;
                    if (this.ctlHelperService.isJson(error)) {
                        this.apiResponseError = JSON.parse(error);
                        if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                            this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task -  Move to Review Order", "move-account.component.ts", "move Account Page", this.apiResponseError);
                        } else { unexpectedError = true; }
                    } else { unexpectedError = true; }
                    if (unexpectedError) {
                        let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderReferenceNumber);
                        this.systemErrorService.logAndeRouteToSystemError("error", "Submit Task - Move to Review Order Page", "move-account.component.ts", "Move Account Page", lAPIErrorLists);
                    }
                    window.scroll(0, 0);
                });
    }

    public orderDtvProcess() {
        let request: any;
        this.retainObservable = <Observable<any>>this.store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((data) => {
            request = {
                orderRefNumber: (data.dtvSessionInfo.payload && data.dtvSessionInfo.payload !== undefined && data.dtvSessionInfo.payload.orderReferenceNumber !== undefined) ? data.dtvSessionInfo.payload.orderReferenceNumber : data.dtvSessionInfo.orderRefNumber,
                processInstanceId: data.dtvSessionInfo.processInstanceId,
                taskId: data.dtvSessionInfo.taskId,
                taskName: data.dtvSessionInfo.taskName,
                payload: {
                    uniqueSessionId: (data.dtvSessionInfo && data.dtvSessionInfo.payload && data.dtvSessionInfo.payload !== undefined && data.dtvSessionInfo.payload.sessionInfo !== undefined) ? data.dtvSessionInfo.payload.sessionInfo.uniqueSessionId : "",
                    attOrderType: "DIRECTV"
                }
            };
        });
        this.loading = true;
        this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        let errorResolved = false;
        this.directvService.orderDtvProcess(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVinit", "account.component.ts",
                    "DIRECTV order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                if (data && data.payload.taskName === 'Enter DTV Manually') {
                    this.opusSessionInfoNotFound.open();
                }
            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null) {
                    return;
                }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "directv-account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "directv-account.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    public retrieveDtvOrder() {
        this.loading = true;
        let request: any;
        request = {
            "uniqueSessionId": "",
            "attOrderType": "DIRECTV",
            "orderReferencNumber": this.orderReferenceNumber
        };
        if (this.retainObservableData && this.retainObservableData.dtvSessionInfo && this.retainObservableData.dtvSessionInfo.payload && this.retainObservableData.dtvSessionInfo.payload.sessionInfo && this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId) {
            request.uniqueSessionId = this.retainObservableData.dtvSessionInfo.payload.sessionInfo.uniqueSessionId;
        }
        let errorResolved = false;
        this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderRequest", JSON.stringify(request));
        this.logger.startTime();
        this.directvService.retrieveDtvOrder(request)
            .catch((error: any) => {
                this.logger.endTime();
                this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderResponse", error);
                this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                errorResolved = true;
                this.systemErrorService.logAndRouteUnexpectedError(
                    "error", "Not Applicable",
                    "DTVRetrieveOrder", "directv-account.component.ts",
                    "DIRECTV retrieve order",
                    error);
                return Observable.throwError(null);
            })
            .subscribe((data) => {
                this.logger.endTime();
                this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                if (data.errorResponse && data.errorResponse !== null && data.errorResponse.length > 0) {
                    this.loading = false;
                    if (data.errorResponse[0].message === 'SESSION_ID_NON_FOUND') {
                        this.opusSessionInfoNotFound.open();
                    } else {
                        data.errorResponse[0]['status'] = "200";
                        this.systemErrorService.logAndRouteUnexpectedError(
                            "error",
                            "",
                            "retrieveDTVOrder",
                            "directv-account.component.ts",
                            "Retrieve  DTV order",
                            data.errorResponse[0]
                        );
                        return Observable.throwError(null);
                    }
                } else {
                    this.logger.endTime();
                    this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderResponse", JSON.stringify(data));
                    this.logger.log("info", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                    this.loading = false;
                    this.store.dispatch({ type: 'RETRIEVE_DTV_ORDER', payload: data });
                    this.orderDtvProcess();
                    this.bmOrderProcess();
                }
            }, (error) => {
                if (!errorResolved) {
                    this.logger.endTime();
                    this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderResponse", error);
                    this.logger.log("error", "directv-account.component.ts", "retrieveDtvOrderSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                }
                this.loading = false;
                if (error === undefined || error === null || errorResolved) { return; }
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                    this.apiResponseError.errorResponse.length > 0) {
                    this.systemErrorService.logAndeRouteToSystemError("error", "retrieveDtvOrder", "directv-account.component.ts", "DIRECTV order", this.apiResponseError);
                } else {
                    let errorResponseArray: ErrorResponse[] = [];
                    let localErrorResponse: ErrorResponse = {
                        orderRefNumber: error.payload.orderReferenceNumber,
                        statusCode: serverErrorMessages.statusCode,
                        reasonCode: serverErrorMessages.statusCode,
                        message: serverErrorMessages.serverDownSchedule01,
                        messageDetail: serverErrorMessages.serverDownNumberErrMessage,
                        serverDown: serverErrorMessages.serverDown
                    };
                    errorResponseArray.unshift(localErrorResponse);
                    let lAPIErrorLists: APIErrorLists = {
                        errorResponse: errorResponseArray
                    };
                    this.systemErrorService.logAndeRouteToSystemError("error", "captureDtvRequest", "dialog.component.ts", "Prequalify DIRECTV order popup", lAPIErrorLists);
                }
                window.scroll(0, 0);
            });
    }

    public opusSessionInfoNotFoundCallback(data) {
        this.dtvAccountInfoManuallyEntered = data;
        this.toNextStage();
    }

    public toNextStage() {
        if (!this.isDtvOpus && this.dtvForm.get('dtvAccNo').value && this.dtvForm.get('dtvAccNo').value !== undefined) {
            this.store.dispatch({ type: 'DTV_ACCOUNT_ID', payload: this.dtvForm.get('dtvAccNo').value });
            this.accountService.saveDtvAccountNo(this.dtvForm.get('dtvAccNo').value, this.orderReferenceNumber)
                .mergeMap((primaryRes: any) => {
                    if (primaryRes && ((this.isChangeFlow) && this.dtvAccUrl)) {
                        let retain: any = this.store.select('retain');
                        retain.subscribe((res) => {
                            if (res && res.scheduleReq) {
                                this.schedulingRequest = res.scheduleReq.scheduleReq;
                            }
                        });
                        this.schedulingRequest.taskId = this.taskId;
                        let subApiRequest = this.schedulingRequest;
                        return this.schedulingService.scheduleAppointment(subApiRequest, this.isChangeFlow, this.agentFirstName, this.agentLastName, this.flow)
                            .map((data) => {
                                return {
                                    "switchCase": "1",
                                    "data": data
                                };
                            });
                    } else {
                        return Observable.of({
                            "switchCase": "2",
                            "data": primaryRes
                        });
                    }
                })
                .catch((error: any) => {
                    this.systemErrorService.logAndRouteUnexpectedError(
                        "error", 'Not Applicable',
                        "submitTask - scheduleAppointment", "schedule-shipping-appointment.component.ts",
                        "Schedule Appointment",
                        error);
                    return Observable.throwError(null);
                })
                .subscribe((resp) => {
                    switch (resp.switchCase) {
                        case "1":
                            if (resp) {
                                this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: resp });
                                this.router.navigate(['/co-review-order']);
                            }
                            if (!this.moveFlow && resp.data.taskName === 'Submit Order') {
                                this.store.dispatch({ type: 'TASK_ID', payload: resp.data.taskId });
                                this.store.dispatch({ type: 'REVIEW_ORDER', payload: resp.data });
                            }
                            break;
                        case "2":
                            if (this.moveFlow) {
                                this.router.navigate(['/move-account']);
                            }
                            if (this.billingFlow) {
                                this.router.navigate(['/billing-review-order']);
                            }
                    }
                });
        }
        if (!this.DTVPendingOrder) {
            if (this.dtvAccountInfoManuallyEntered || this.isAmend) {
                this.bmOrderProcess();
            } else if (this.isDtvOpus && this.newDtv && this.isDTV && !this.removedDTV) {
                this.retrieveDtvOrder();
            } else {
                this.orderDtvProcess();
            }
        }
        if ((this.isDtvOpus && this.isChangeFlow) || this.DTVPendingOrder) {
            let retain: any = this.store.select('retain');
            let retainSubscription = retain.subscribe((res) => {
                if (res && res.scheduleReq) {
                    this.schedulingRequest = res.scheduleReq.scheduleReq;
                }
                this.logger.log("info", "directv-account.component.ts", "scheduleAppointmentRequest", JSON.stringify(this.schedulingRequest));
                this.logger.startTime();
                if (subApiRequest) {
                    this.schedulingService.scheduleAppointment(subApiRequest, this.isChangeFlow, this.agentFirstName, this.agentLastName, this.flow)
                        .subscribe((data) => {
                            this.logger.endTime();
                            this.logger.log("info", "directv-account.component.ts", "scheduleAppointmentResponse", JSON.stringify(data));
                            this.logger.log("info", "directv-account.component.ts", "scheduleAppointmentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                            this.store.dispatch({ type: 'AVAILABLE_APPOINTMENTS', payload: { "switchCase": "1", "data": data } });
                            this.router.navigate(['/co-review-order']);
                            if (data.taskName === 'Submit Order') {
                                this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
                                this.store.dispatch({ type: 'REVIEW_ORDER', payload: data });
                            }
                        });
                }
            });
            this.schedulingRequest.taskId = this.taskId;
            let subApiRequest = this.schedulingRequest;
            retainSubscription.unsubscribe();
        }
        if (this.isDtvOpus && this.billingFlow) {
            this.router.navigate(['/billing-review-order']);
        }
    }

    public tConv24(time24) {
        if (time24 !== null && time24 !== undefined) {
            let ts = time24;
            let H = +ts.substr(0, 2);
            let h: any = (H % 12) || 12;
            h = (h < 10) ? ('0' + h) : h;
            let ampm = H < 12 ? ' AM' : ' PM';
            ts = h + ts.substr(2, 3) + ampm;
            return ts;
        }
    }

    public disabledContinue() {
        if ((this.isDtvOpus && !this.isDtvSessionInfo && !this.removedDTV && this.dtvAccountInfoManuallyEntered && this.flow === 'billing')
            || (this.isDtvOpus && this.isDtvSessionInfo && !this.removedDTV)
            || this.DTVPendingOrder || this.isAmend) {
            return false;
        } else if (this.isDtvOpus && this.removedDTV) {
            return false;
        } else if ((!this.isDtvOpus && this.dtvForm.get('dtvAccNo').value === '') || (this.isDtvOpus && !this.isDtvSessionInfo) && !this.removedDTV) {
            return true;
        } else {
            return true;
        }
    }

    public actPopup(w, h) {
        let url;
        const left = (screen.width / 2) - (w / 2);
        const top = (screen.height / 2) - (h / 2);
        if (this.legacy === 'CENTURYLINK') {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Atrue%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%2216%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22Y5YzQ2MWM0YjIzMTExYmRi%22%2C%22ssid%22%3A%22rI28qh_OTFKTGfGQbOQIFA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
        } else {
            url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083512%2C%22eid%22%3A1570086812%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22AzY2QxNDAyNDE2YTdhMGI1%22%2C%22ssid%22%3A%22C-xqYDpuQr692Su1zOt-6Q%22%2C%22lewid%22%3A1570246912%2C%22skill%22%3A%22credit-service-cris%22%7D%7D';
        }
        return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
    }

    public ngOnDestroy() {
        if (this.retainSubscription !== undefined) {
            this.retainSubscription.unsubscribe();
        }
        if (this.moveSubscription !== undefined) {
            this.moveSubscription.unsubscribe();
        }
        if (this.existingSubscription !== undefined) {
            this.existingSubscription.unsubscribe();
        }
    }
}