import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AccountService } from '../../common/service/account.service';
import { creditService } from '../../common/service/credit-check.service';
import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from '../../common/service/text-mask.service';
import { DirectTvComponent } from './directv-account.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: DirectTvComponent
    }
];

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        TextMaskModule,
        SharedCommonModule,
        SharedModule,
    ],
    exports: [
        DirectTvComponent
    ],
    providers: [
        AccountService,
        TextMaskService,
        creditService
    ]
})

export class DirectvAccountModule { }
