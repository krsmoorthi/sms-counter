
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { AccountInfomation } from 'app/common/models/account.model';
import { AppStore } from 'app/common/models/appstore.model';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { SystemErrorService } from "app/common/service/system-error.service";
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { APIErrorLists } from '../../common/models/common.model';
import { User } from '../../common/models/user.model';
import { AccountService } from '../../common/service/account.service';
import { Logger } from './../../common/logging/default-log.service';
import { EnterpriseAddress } from './../../common/models/cart.model';
import { AddressService } from './../../common/service/address.service';
import { CountryStateService } from './../../common/service/country-state.service';
import { Validations } from './../../common/validations/validations';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
  selector: 'billing-address',
  templateUrl: './validate-billing-address.component.html',
  styleUrls: ['../account-component/account.component.scss']
})
export class ValidateBillingAddressComponent implements OnInit, OnDestroy {
  public apiResponse: AccountInfomation;
  public accountSubscription: Subscription;
  public accountObservable: Observable<AccountInfomation>;
  public retainSubscription: Subscription;
  public retainObservable: Observable<any>;
  public userSubscription: Subscription;
  public refObj = {
    stateCountries: [],
    addrCareOf: '',
    selectedState: null,
    stateSelected: '',
    nearAddresses: [],
    isExactAddr: '',
    selectedAddr: null,
    isEnteredAllAddsFields: true,
    disableSaveAddr: true,
    disableValidateAddr: false,
    changeAddrClicked: false,
    combinedAddress: '',
    addrTypeSelected: '',
    savedAddress: '',
    addrModels: { field1: '', field2: '', field3: '' },
    addrPlaceholders: {
      addrPlchd1: '',
      addrPlchd2: '',
      addrPlchd3: ''
    },
    validatedAddr: '',
    addressTypes: ['Street Address', 'P.O. Box', 'Rural Route', 'Military', 'International'],
    zipCode:''
  };
  public stateName: string;
  public militaryStateName: string;
  public countryName: string;
  public accRespObj: any = {};
  public billingAddr: EnterpriseAddress = {
    city: '', street: '', addressLine: '', stateOrProvince: '',
    streetType: ''
  };
  public addressForm: FormGroup;
  public address: EnterpriseAddress;
  public loading: boolean = false;
  public apiResponseError: APIErrorLists;
  public isBillingAddrReadonly: boolean = false;
  public internationalFormattingUrl: string = `${env.INTERNATIONAL_FORMATTING_URL}`;
  public orderRefNumber: string;
  @Output() public updateAddress: EventEmitter<object> = new EventEmitter<object>();
  @Output() public saveAddress: EventEmitter<object> = new EventEmitter<object>();
  @Input() public billingAddress: any;
  @Input() public saveBtnText: string;
  @Input() public retainedAddress:any;
  private isBillingAddressValidated: any;
  @Output() public onNewAddressValidation: EventEmitter<any> = new EventEmitter<any>();
  @Output() public updatedAddress: EventEmitter<any> = new EventEmitter<any>();
  public isReEntrant: boolean = false;
  public validatedAddress: boolean = false;
  public retainObj: any = {
    stateCode: '', militaryStateCode: '', countryCode: ''
  };

  constructor(
    private logger: Logger,
    private fb: FormBuilder,
    private addressService: AddressService,
    public store: Store<AppStore>,
    private accountService: AccountService,
    private systemErrorService: SystemErrorService,
    private countryStateService: CountryStateService,
    private ctlHelperService: CTLHelperService) {
    this.addressForm = this.fb.group({
      zipCode: ['', Validations.zipCodeValidator],
      zipCodeInt: ['', Validations.zipCodeValidatorInt]
    });
    this.accountObservable = <Observable<AccountInfomation>>store.select('account');
    this.accountSubscription = this.accountObservable.subscribe((respData) => {
      this.apiResponse = respData;
      let user = <Observable<User>>store.select('user');
      user.subscribe(
        (usr) => {
          if (usr && usr.orderRefNumber) {
            this.orderRefNumber = usr.orderRefNumber;
          }
        });
      this.refObj.addrTypeSelected = this.refObj.addressTypes[0];

      if (this.isReEntrant && this.apiResponse.payload !== undefined) {
        if (this.apiResponse.payload && this.apiResponse.payload !== undefined && this.apiResponse.payload.billingAddress && this.apiResponse.payload.billingAddress !== undefined && this.apiResponse.payload.billingAddress.streetAddress
          && this.apiResponse.payload.billingAddress.streetAddress !== undefined && this.apiResponse.payload.billingAddress.streetNrFirst && this.apiResponse.payload.billingAddress.streetNrFirst !== undefined && this.apiResponse.payload.billingAddress.city && this.apiResponse.payload.billingAddress.city !== undefined) {
          this.refObj.addrModels.field1 = this.apiResponse.payload.billingAddress.streetAddress;
          this.refObj.addrModels.field2 = this.apiResponse.payload.billingAddress.streetNrFirst;
          this.refObj.addrModels.field3 = this.apiResponse.payload.billingAddress.city;
        }
        this.retainObservable = <Observable<any>>store.select('retain');
        this.retainSubscription = this.retainObservable.subscribe((respData) => {
          if (respData.validateAddress && respData.validateAddress !== undefined) {
            this.refObj.addrCareOf = respData.validateAddress.billingAdditionalInfo;
            this.refObj.addrTypeSelected = respData.validateAddress && respData.validateAddress.addressType ? respData.validateAddress.addressType : '';
            this.refObj.addrModels.field1 = respData.validateAddress.addressField;
            this.refObj.addrModels.field2 = respData.validateAddress.unit !== '' ? respData.validateAddress.unit : '';
            this.refObj.addrModels.field3 = respData.validateAddress.city;
            this.refObj.validatedAddr = respData.validatedAdd;
            this.addressForm.get('zipCode').setValue(respData.validateAddress.zipcode);
            if (respData.validateAddress.stateCountries.stateName) {
              this.stateName = respData.validateAddress.stateCountries.stateName;
              this.retainObj.stateCode = respData.validateAddress.stateCountries.stateCode;
            } else if (respData.validateAddress.stateCountries.militaryStateName) {
              this.militaryStateName = respData.validateAddress.stateCountries.militaryStateName;
              this.retainObj.militaryStateCode = respData.validateAddress.stateCountries.militaryStateCode;
            } else if (respData.validateAddress.stateCountries.countryName) {
              this.countryName = respData.validateAddress.stateCountries.countryName;
              this.retainObj.countryCode = respData.validateAddress.stateCountries.countryCode;
            }
          }
          this.addressTypeSelectionHandler();
          if (respData && respData.validateAddress && respData.validateAddress.addressType && respData.validateAddress.addressType === "Rural Route") {
            this.refObj.addrModels.field1 = respData.billingValidatedAdddress.billingAddress.streetName.replace("RR ", '');
            this.refObj.addrModels.field2 = respData.billingValidatedAdddress.billingAddress.streetNrFirst;
            this.refObj.addrModels.field3 = respData.billingValidatedAdddress.billingAddress.city;
          }
          if (respData && respData.validateAddress && respData.validateAddress.addressType && respData.validateAddress.addressType === "P.O. Box") {
            this.refObj.addrModels.field1 = respData.billingValidatedAdddress.billingAddress.streetNrFirst;
            this.refObj.addrModels.field3 = respData.billingValidatedAdddress.billingAddress.city;
          }
        });
      }
    });
  }

  public ngOnInit() {
    this.logger.metrics('AccountValidateBillingAddressPage');
    if (!this.isReEntrant) {
      this.refObj.addrTypeSelected = this.refObj.addressTypes[0];
      this.refObj.addrPlaceholders = {
        addrPlchd1: 'Street Address', addrPlchd2: 'Unit #',
        addrPlchd3: 'City'
      };
    }
    if(this.retainedAddress || !this.isReEntrant){
    
      if(this.retainedAddress){
      this.refObj.stateCountries=this.retainedAddress.stateCountries;
      this.refObj.addressTypes=this.retainedAddress.addressTypes;
      this.refObj.selectedState=this.retainedAddress.selectedState;
      } else{
        this.getStates();
      }
      this.retainObservable = <Observable<any>>this.store.select('retain');
      this.retainSubscription = this.retainObservable.subscribe((respData) => {
        if (respData.validateAddress && respData.validateAddress !== undefined) {
          this.refObj.addrCareOf = respData.validateAddress.billingAdditionalInfo;
          this.refObj.addrTypeSelected = respData.validateAddress && respData.validateAddress.addressType ? respData.validateAddress.addressType : '';
          this.refObj.addrModels.field1 = respData.validateAddress.addressField;
          this.refObj.addrModels.field2 = respData.validateAddress.unit !== '' ? respData.validateAddress.unit : '';
          this.refObj.addrModels.field3 = respData.validateAddress.city;
          this.refObj.validatedAddr = respData.validatedAdd;
          this.addressForm.get('zipCode').setValue(respData.validateAddress.zipcode);
          if (respData.validateAddress.stateCountries.stateName) {
            this.stateName = respData.validateAddress.stateCountries.stateName;
            this.retainObj.stateCode = respData.validateAddress.stateCountries.stateCode;
          } else if (respData.validateAddress.stateCountries.militaryStateName) {
            this.militaryStateName = respData.validateAddress.stateCountries.militaryStateName;
            this.retainObj.militaryStateCode = respData.validateAddress.stateCountries.militaryStateCode;
          } else if (respData.validateAddress.stateCountries.countryName) {
            this.countryName = respData.validateAddress.stateCountries.countryName;
            this.retainObj.countryCode = respData.validateAddress.stateCountries.countryCode;
          }
        }
    })
  } else{
    this.getStates();
  }
}

  /** Initialize new account page data, after getting response */
  public initializeData() {
  }

  /** Get States from countryStateService */
  public getStates() {
    this.refObj.stateCountries = this.countryStateService.getStates();
    this.refObj.stateCountries.splice(0, 0, { stateName: 'Select State', stateCode: '' });
    if (!this.isReEntrant) {
      this.refObj.selectedState = this.refObj.stateCountries[0];
    } else {
      let stateObj = this.refObj.stateCountries.find((obj) =>
        obj.stateCode === this.retainObj.stateCode
      );
      this.refObj.selectedState = stateObj;
    }
  }

  /** Get MilitaryStates from countryStateService */
  public getMilitaryState() {
    this.refObj.stateCountries = this.countryStateService.getMilitaryStates();
    this.refObj.stateCountries.splice(0, 0,
      { militaryStateName: 'Select Armed Forces Location', militaryStateCode: '' });
    if (!this.isReEntrant) {
      this.refObj.selectedState = this.refObj.stateCountries[0];
    } else {
      let stateObj = this.refObj.stateCountries.find((obj) =>
        obj.militaryStateCode === this.retainObj.militaryStateCode
      );
      this.refObj.selectedState = stateObj;
    }
  }

  /** Get Countries from countryStateService */
  public getCountries() {


    this.loading = true;
    let countryListReq = {
      "inputAttribute": [
        {
          "attributeName": "dataType",
          "attributeValue": [
            "countryList"
          ]
        }
      ],
      "outputAttribute": [
        {
          "attributeName": "countryISOCode"
        },
        {
          "attributeName": "countryName"
        }
      ],
      "requestDate": "",
      "ruleId": "100"
    };

    let countryRes = '';
    let countryResObj: any = '';
    this.logger.log("info", "validate-billing-address.component.ts", "getInternationalBillingCountryListRequest", JSON.stringify(countryListReq));
    this.logger.startTime();
    this.accountService.getInternationalBillingCountryList(countryListReq)
      .catch((error: any) => {
        this.logger.endTime();
        this.logger.log("error", "validate-billing-address.component.ts", "getInternationalBillingCountryListResponse", error);
        this.logger.log("error", "validate-billing-address.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        this.loading = false;
        this.ctlHelperService.setLocalStorage('error', error);
        return Observable.throwError(error._body);
      })
      .subscribe(data => {
        this.logger.endTime();
        this.logger.log("info", "validate-billing-address.component.ts", "getInternationalBillingCountryListResponse", JSON.stringify(data));
        this.logger.log("info", "validate-billing-address.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        this.loading = false;
        countryRes = JSON.stringify(data);
        countryResObj = JSON.parse(countryRes);
        let countryResAry = [];
        countryResAry = countryResObj.outputAttribute;
        let countryAry = [];
        for (var i = 0, len = countryResAry.length; i < len; i++) {
          let countr = {};
          countr['countryCode'] = countryResAry[i][0];
          countr['countryName'] = countryResAry[i][1];
          countryAry.push(countr);

        }

        this.refObj.stateCountries = countryAry;
        this.refObj.stateCountries.splice(0, 0, { countryName: 'Select Country', countryCode: '' });

        if (this.apiResponse && this.apiResponse.payload && this.apiResponse.payload.billingAddressType === 'F' && this.refObj.addrTypeSelected === 'International' && this.refObj.selectedState && this.refObj.selectedState.stateCode === '') {
          let stateObj = this.refObj.stateCountries.find((obj) =>
            obj.countryCode === this.apiResponse.payload.billingAddress.country
          );
          this.refObj.selectedState = stateObj;
        } else if (!this.isReEntrant) {
          this.refObj.selectedState = this.refObj.stateCountries[0];
        } else {
          let stateObj = this.refObj.stateCountries.find((obj) =>
            obj.countryCode === this.retainObj.countryCode
          );
          this.refObj.selectedState = stateObj;
        }



        this.loading = false;
      },
        (error) => {
          this.logger.endTime();
          this.logger.log("error", "validate-billing-address.component.ts", "getInternationalBillingCountryListResponse", error);
          this.logger.log("error", "validate-billing-address.component.ts", "getInternationalBillingCountryListSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          this.loading = false;
          if (error === undefined || error === null)
            return;
          try {
            this.apiResponseError = JSON.parse(error);
          } catch (e) {
            if (error.status === 500) {
              let lAPIErrorLists: APIErrorLists = {
                errorResponse: [{
                  statusCode: "500",
                  reasonCode: "500",
                  message: "500 Internal Server Error",
                  messageDetail: "Country Service list error",
                  source: "",
                  timestamp: "",
                  orderRefNumber: "",
                  serverDown: "",
                  tnNotFound: "",
                  tnNotAvail: ""
                }]
              };
              this.systemErrorService.logAndeRouteToSystemError("error", "Get Country list", "Validate-billing-address.ts", "Validate Billing Address Page", lAPIErrorLists);
            } else {
              let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
              this.systemErrorService.logAndeRouteToSystemError("error", "Get Country list", "Validate-billing-address.ts", "Validate Billing Address Page", lAPIErrorLists);
            }
          }
          if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
            this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
            this.systemErrorService.logAndeRouteToSystemError("error", "Get Country list", "Validate-billing-address.ts", "Validate Billing Address Page", this.apiResponseError);
          } else {
            let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(this.orderRefNumber);
            this.systemErrorService.logAndeRouteToSystemError("error", "Get Country list", "Validate-billing-address.ts", "Validate Billing Address Page", lAPIErrorLists);
          }
        });
  }

  /** Change billing address click handler */
  public handleChangeAddr() {
    this.refObj.changeAddrClicked = true;
    if (this.accRespObj.billingAddress.streetType &&
      this.accRespObj.billingAddress.streetType === 'ST') {
      this.accRespObj.billingAddress.addressTypeSelected = 'Street Address';
    }
    !this.refObj.addrTypeSelected ?
      this.refObj.addrTypeSelected = this.refObj.addressTypes[0] :
      this.refObj.addrTypeSelected = this.accRespObj.billingAddress.addressTypeSelected;
    this.addressTypeSelectionHandler();
  }

  /** Change billing address, different address type selection handler */
  public addressTypeSelectionHandler() {
    this.isBillingAddrReadonly = false;
    this.billingAddr = {
      city: '', street: '', addressLine: '', stateOrProvince: '',
      streetType: ''
    };
    switch (this.refObj.addrTypeSelected) {
      case 'Street Address':
        this.refObj.disableValidateAddr = false;
        this.refObj.disableSaveAddr = true;
        this.refObj.addrPlaceholders = {
          addrPlchd1: 'Street Address', addrPlchd2: 'Unit #',
          addrPlchd3: 'City'
        };
        this.refObj.addrModels = { field1: '', field2: '', field3: '' };
        this.addressForm.patchValue({ zipCode: '' });
        this.getStates();
        break;
      case 'P.O. Box':
        this.refObj.disableValidateAddr = false;
        this.refObj.disableSaveAddr = true;
        this.refObj.addrPlaceholders = {
          addrPlchd1: 'Box Number', addrPlchd2: 'Address Line 2',
          addrPlchd3: 'City'
        };
        this.refObj.addrModels = { field1: '', field2: '', field3: '' };
        this.addressForm.patchValue({ zipCode: '' });
        this.getStates();
        break;
      case 'Rural Route':
        this.refObj.disableValidateAddr = false;
        this.refObj.disableSaveAddr = true;
        this.refObj.addrPlaceholders = {
          addrPlchd1: 'Rural Route', addrPlchd2: 'Box Number',
          addrPlchd3: 'City'
        };
        this.refObj.addrModels = { field1: '', field2: '', field3: '' };
        this.addressForm.patchValue({ zipCode: '' });
        this.getStates();
        break;
      case 'Military':
        this.refObj.disableValidateAddr = false;
        this.refObj.disableSaveAddr = true;
        this.refObj.addrPlaceholders = {
          addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
          addrPlchd3: 'APO, FPO, DPO'
        };
        this.refObj.addrModels = { field1: '', field2: '', field3: '' };
        this.addressForm.patchValue({ zipCode: '' });
        this.getMilitaryState();
        break;
      case 'International':

        this.refObj.isExactAddr = "InternationalAddress";
        this.refObj.disableValidateAddr = true;
        this.refObj.disableSaveAddr = false;
        this.refObj.addrPlaceholders = {
          addrPlchd1: 'Address Line 1', addrPlchd2: 'Address Line 2',
          addrPlchd3: 'City'
        };

        if (this.apiResponse.payload.billingAddressType === 'F') {
          this.refObj.addrModels = {
            field1: this.refObj.addrModels.field1 ?
              this.refObj.addrModels.field1 : this.apiResponse.payload.billingAddress.streetAddress,
            field2: this.refObj.addrModels.field2 ?
              this.refObj.addrModels.field2 : this.apiResponse.payload.billingAddress.streetName,
            field3: this.refObj.addrModels.field3 ?
              this.refObj.addrModels.field3 : this.apiResponse.payload.billingAddress.city
          };

          if (this.addressForm.value.zipCodeInt === '') {
            this.addressForm.patchValue({ zipCodeInt: this.apiResponse.payload.billingAddress.postCode });
          }
        } else {

          this.refObj.addrModels = {
            field1: this.refObj.addrModels.field1 ?
              this.refObj.addrModels.field1 : '',
            field2: this.refObj.addrModels.field2 ?
              this.refObj.addrModels.field2 : '',
            field3: this.refObj.addrModels.field3 ?
              this.refObj.addrModels.field3 : ''
          };
          if(!this.refObj.addrModels.field1) { this.addressForm.patchValue({ zipCode: '' }); }

        }

        this.getCountries();
        break;
      default: break;
    }
  }

  /** Change billing address state/country selection handler */
  public stateCountrySelectionHandler() {
    switch (this.refObj.addrTypeSelected) {
      case 'Street Address':
      case 'P.O. Box':
      case 'Rural Route':
        this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
        break;
      case 'Military':
        this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
        break;
      case 'International':
        this.billingAddr.country = this.refObj.selectedState.countryCode;
        break;
      default: break;
    }
  }

  /** Change billing address Validate button handler */
  public validateBillingAddr() {

    let differentAddressObject = {
      billingAdditionalInfo: '',
      addressType: '',
      addressField: '',
      unit: '',
      city: '',
      stateCountries: '',
      zipcode: ''
    }
    this.refObj.zipCode=this.addressForm.get('zipCode').value;
    differentAddressObject.billingAdditionalInfo = this.refObj.addrCareOf;
    differentAddressObject.addressType = this.refObj.addrTypeSelected;
    differentAddressObject.addressField = this.refObj.addrModels.field1;
    differentAddressObject.city = this.refObj.addrModels.field3;
    differentAddressObject.zipcode = this.addressForm.get('zipCode').value;
    differentAddressObject.stateCountries = this.refObj.selectedState;
    this.updatedAddress.emit(this.refObj);
    this.store.dispatch({ type: 'VALIDATE_ADDRESS', payload: { validateAddress: differentAddressObject } });
    this.refObj.isExactAddr = '';
    this.isBillingAddressValidated = false;
    this.refObj.disableSaveAddr = true;
    switch (this.refObj.addrTypeSelected) {
      case 'Street Address':
        this.billingAddr.streetAddress = this.refObj.addrModels.field2 + ' ' +
          this.refObj.addrModels.field1;
        this.billingAddr.streetName = this.refObj.addrModels.field1;
        this.billingAddr.streetNrFirst = this.refObj.addrModels.field2;
        this.billingAddr.addressLine = this.refObj.addrModels.field1;
        this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
        this.billingAddr.city = this.refObj.addrModels.field3;
        this.billingAddr.locality = this.refObj.addrModels.field3;
        this.refObj.combinedAddress = `${this.billingAddr.streetAddress}, 
                                      ${this.billingAddr.stateOrProvince}, 
                                      ${this.billingAddr.city}`;
        break;
      case 'P.O. Box':
        this.billingAddr.streetAddress = "PO BOX " + this.refObj.addrModels.field1;
        this.billingAddr.boxNumber = "PO BOX " + this.refObj.addrModels.field1;
        this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
        this.billingAddr.addressLine = this.billingAddr.boxNumber + ' ' + this.billingAddr.addressLine2;
        this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
        this.billingAddr.city = this.refObj.addrModels.field3;
        this.billingAddr.locality = this.billingAddr.city;
        this.refObj.combinedAddress = `${this.billingAddr.boxNumber},
                                       ${this.billingAddr.streetAddress},
                                       ${this.billingAddr.addressLine2}, 
                                       ${this.billingAddr.stateOrProvince}, 
                                       ${this.billingAddr.city}`;
        break;
      case 'Rural Route':
        this.billingAddr.ruralRoute = this.refObj.addrModels.field1;
        this.billingAddr.boxNumber = this.refObj.addrModels.field2;
        this.billingAddr.addressLine = this.billingAddr.ruralRoute + ' ' + this.billingAddr.boxNumber;
        this.billingAddr.addressLine1 = "RR " + this.billingAddr.ruralRoute;
        this.billingAddr.addressLine2 = "BOX " + this.billingAddr.boxNumber;
        this.billingAddr.stateOrProvince = this.refObj.selectedState.stateCode;
        this.billingAddr.city = this.refObj.addrModels.field3;
        this.billingAddr.locality = this.billingAddr.city;
        this.refObj.combinedAddress = `${this.billingAddr.boxNumber}, 
                              ${this.billingAddr.ruralRoute}, 
                              ${this.billingAddr.stateOrProvince}, 
                              ${this.billingAddr.city}`;
        break;
      case 'Military':
        this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
        this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
        this.billingAddr.addressLine = this.billingAddr.addressLine1 + ' ' + this.billingAddr.addressLine2;
        this.billingAddr.apoFpoDpo = this.refObj.addrModels.field3;
        this.billingAddr.armedForceLoc = this.refObj.selectedState.militaryStateCode;
        this.billingAddr.city = this.billingAddr.apoFpoDpo;
        this.billingAddr.locality = this.billingAddr.city;
        this.billingAddr.stateOrProvince = this.billingAddr.armedForceLoc;
        this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                              ${this.billingAddr.addressLine2}, 
                              ${this.billingAddr.apoFpoDpo}, 
                              ${this.billingAddr.armedForceLoc}`;
        break;
      case 'International':
        this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
        this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
        this.billingAddr.addressLine = this.billingAddr.addressLine1 + ' ' + this.billingAddr.addressLine2;
        this.billingAddr.city = this.refObj.addrModels.field3;
        this.billingAddr.locality = this.billingAddr.city;
        this.billingAddr.country = this.refObj.selectedState.countryCode;
        this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                              ${this.billingAddr.addressLine2}, 
                              ${this.billingAddr.city},
                              ${this.billingAddr.country}`;
        break;
      default: break;
    }
    this.billingAddr.postCode = this.addressForm.value.zipCode;
    let zipValid = Validations.zipCodeValidator({ value: this.addressForm.value.zipCode });
    /** Unit number is optional for street address, checking with only mandatory fields */
    if (!this.refObj.addrModels.field1 || !this.refObj.addrModels.field3 || zipValid) {
      this.refObj.isEnteredAllAddsFields = false;
      return;
    }
    if (!this.refObj.selectedState.stateCode && !this.refObj.selectedState.militaryStateCode
      && !this.refObj.selectedState.countryCode) {
      this.refObj.isEnteredAllAddsFields = false;
      return;
    }
    this.refObj.isEnteredAllAddsFields = true;
    let lpostCode = this.billingAddr.postCode.length === 5 && this.billingAddr.postCodeSuffix !== undefined && this.billingAddr.postCodeSuffix !== '' ? this.billingAddr.postCode + '-' + this.billingAddr.postCodeSuffix : this.billingAddr.postCode;
    this.refObj.combinedAddress = this.refObj.combinedAddress + ', ' + lpostCode;
    this.logger.startTime();
    let civicOrpostal = 'postalAddresses';

    let errorResolved = false;
    this.logger.log("info", "validate-billing-address.component.ts", "getGeoesAddressRequest", JSON.stringify(this.billingAddr ? this.billingAddr : ''));
    this.logger.startTime();
    this.loading = true;
    this.addressService.getGeoesAddress(this.billingAddr, civicOrpostal)
      .catch((error: any) => {
        this.logger.endTime();
        this.logger.log("error", "validate-billing-address.component.ts", "getGeoesAddressResponse", error);
        this.logger.log("error", "validate-billing-address.component.ts", "getGeoesAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        this.loading = false;
        errorResolved = true;
        return Observable.throwError(error._body);
      })
      .subscribe(
        (data) => {
          this.logger.endTime();
          this.logger.log("info", "validate-billing-address.component.ts", "getGeoesAddressResponse", JSON.stringify(data ? data : ''));
          this.logger.log("info", "validate-billing-address.component.ts", "getGeoesAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          this.loading = false;
          let respAddressesArray = [];
          let lunitNumber: string = '';
          if (civicOrpostal === 'civicAddresses') {
            respAddressesArray = data.civicAddresses;
          } else {
            respAddressesArray = data.postalAddresses;
          }

          if (data && data !== undefined && data !== null && data.result === "Green") {
            this.refObj.isExactAddr = 'exact';
            this.refObj.disableSaveAddr = false;
            if (respAddressesArray[0].subAddress !== undefined) {
              lunitNumber = respAddressesArray[0].subAddress.designator + ' ' + respAddressesArray[0].subAddress.value;
            }
            let geoesResponseAddress: EnterpriseAddress = {
              isValidated: true,
              streetAddress: respAddressesArray[0].streetAddress,
              streetNrFirst: respAddressesArray[0].streetNrFirst,
              streetNrFirstSuffix: '',
              streetNamePrefix: respAddressesArray[0].streetNamePrefix,
              streetName: respAddressesArray[0].streetName,
              streetType: respAddressesArray[0].streetType ? respAddressesArray[0].streetType : '',
              locality: respAddressesArray[0].locality,
              city: respAddressesArray[0].locality,
              stateOrProvince: respAddressesArray[0].stateOrProvince,
              postCode: respAddressesArray[0].postCode,
              postCodeSuffix: respAddressesArray[0].postCodeSuffix !== 'undefined' ? respAddressesArray[0].postCodeSuffix : '',
              source: respAddressesArray[0].source,
              country: 'USA',
              subAddress: {
                sourceId: '',
                source: respAddressesArray[0].source,
                geoSubAddressId: '',
                combinedDesignator: lunitNumber,
                elements: [
                  {
                    designator: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.designator !== undefined ? respAddressesArray[0].subAddress.designator : '',
                    value: respAddressesArray[0].subAddress !== undefined && respAddressesArray[0].subAddress.value !== undefined ? respAddressesArray[0].subAddress.value : ''
                  }
                ]
              }
            }
            this.accRespObj.billingAddress = geoesResponseAddress;
            this.store.dispatch({ type: 'VALIDATED_BILLING_ADDR', payload: { billingAddress: this.accRespObj.billingAddress } });
            let lpostCodeSuffix = respAddressesArray[0].postCodeSuffix ? '-' + respAddressesArray[0].postCodeSuffix : '';
            if (lunitNumber) {
              this.refObj.validatedAddr = respAddressesArray[0].streetAddress + ', ' + lunitNumber + ', ' + respAddressesArray[0].locality + ', ' + respAddressesArray[0].stateOrProvince + ' ' + respAddressesArray[0].postCode + lpostCodeSuffix;
            } else {
              this.refObj.validatedAddr = respAddressesArray[0].streetAddress + ', ' + respAddressesArray[0].locality + ', ' + respAddressesArray[0].stateOrProvince + ' ' + respAddressesArray[0].postCode + lpostCodeSuffix;
            }
            if (this.refObj.validatedAddr !== '') {
              this.validatedAddress = true;
              this.store.dispatch({ type: 'VALIDATED_ADDR', payload: { validatedAdd: this.refObj.validatedAddr } });
            }
            this.refObj.selectedAddr = Object.assign({}, this.accRespObj.billingAddress);
            this.accRespObj.isBillAddrSameAsServiceAddress = false;
            this.updateAddress.emit({
              address: this.refObj.selectedAddr,
              billingAddressType: this.refObj.addrTypeSelected,
              billingAdditionalInfo: this.refObj.addrCareOf,
              isBillAddrSameAsServiceAddress: false
            });
            this.isBillingAddressValidated = this.refObj.isExactAddr==='exact' || (this.isReEntrant && this.refObj.validatedAddr)
            this.onNewAddressValidation.emit(this.isBillingAddressValidated);
          } else if (data && data !== undefined && data !== null && data.result === 'Yellow') {
            this.refObj.isExactAddr = 'multi';
            this.refObj.nearAddresses = [];
            for (let i = 0; i < respAddressesArray.length; i++) {
              if (respAddressesArray[i].subAddress !== undefined) {
                lunitNumber = respAddressesArray[i].subAddress.designator + ' ' + respAddressesArray[i].subAddress.value;
              }
              let geoesResponseAddress: EnterpriseAddress = {
                isValidated: true,
                streetAddress: respAddressesArray[i].streetAddress,
                streetNrFirst: respAddressesArray[i].streetNrFirst,
                streetNrFirstSuffix: '',
                streetNamePrefix: respAddressesArray[i].streetNamePrefix,
                streetName: respAddressesArray[i].streetName,
                streetType: respAddressesArray[i].streetType ? respAddressesArray[i].streetType : '',
                locality: respAddressesArray[i].locality,
                city: respAddressesArray[i].locality,
                stateOrProvince: respAddressesArray[i].stateOrProvince,
                postCode: respAddressesArray[i].postCode,
                postCodeSuffix: respAddressesArray[i].postCodeSuffix !== 'undefined' ? respAddressesArray[i].postCodeSuffix : '',
                source: respAddressesArray[i].source,
                country: 'USA',
                subAddress: {
                  sourceId: '',
                  source: respAddressesArray[i].source,
                  geoSubAddressId: '',
                  combinedDesignator: lunitNumber,
                  elements: [
                    {
                      designator: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.designator !== undefined ? respAddressesArray[i].subAddress.designator : '',
                      value: respAddressesArray[i].subAddress !== undefined && respAddressesArray[i].subAddress.value !== undefined ? respAddressesArray[i].subAddress.value : ''
                    }
                  ]
                }
              }
              this.refObj.nearAddresses.push(geoesResponseAddress);
            }
            let lbillingAddr: EnterpriseAddress = {
              isValidated: true,
              streetAddress: this.billingAddr.streetAddress,
              streetNrFirst: this.billingAddr.streetNrFirst,
              streetNrFirstSuffix: this.billingAddr.streetNrFirstSuffix,
              streetNamePrefix: this.billingAddr.streetNamePrefix,
              streetName: this.billingAddr.streetName,
              streetType: this.billingAddr.streetType ? this.billingAddr.streetType : '',
              locality: this.billingAddr.locality,
              city: this.billingAddr.locality,
              stateOrProvince: this.billingAddr.stateOrProvince,
              postCode: this.billingAddr.postCode,
              postCodeSuffix: this.billingAddr.postCodeSuffix !== 'undefined' ? this.billingAddr.postCodeSuffix : '',
              source: this.billingAddr.source,
              country: 'USA',
              subAddress: {
                sourceId: '',
                source: this.billingAddr.source,
                geoSubAddressId: '',
                combinedDesignator: this.billingAddr.subAddress.combinedDesignator,
                elements: [
                  {
                    designator: '',
                    value: ''
                  }
                ]
              }
            }
            this.refObj.nearAddresses.push(Object.assign({}, this.accRespObj.billingAddress, lbillingAddr));
          } else {
            this.refObj.isExactAddr = 'red';
          }
        },
        (error) => {
          if (!errorResolved) {
            this.logger.endTime();
            this.logger.log("error", "validate-billing-address.component.ts", "getGeoesAddressResponse", error);
            this.logger.log("error", "validate-billing-address.component.ts", "getGeoesAddressSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;
          }
        }
      );
  }

  /** Billing address selection handler from multiple addresses, after validation */
  public addressRadioHandler() {
    this.refObj.disableSaveAddr = false;
    this.updateAddress.emit({
      address: this.refObj.selectedAddr,
      billingAddressType: this.refObj.addrTypeSelected,
      billingAdditionalInfo: this.refObj.addrCareOf,
      isBillAddrSameAsServiceAddress: false
    });
    let lpostCode = this.refObj.selectedAddr.postCode && this.refObj.selectedAddr.postCodeSuffix !== undefined && this.refObj.selectedAddr.postCodeSuffix !== '' ? this.refObj.selectedAddr.postCode + ' - ' + this.refObj.selectedAddr.postCodeSuffix : this.refObj.selectedAddr.postCode;
    this.refObj.combinedAddress = `${this.refObj.selectedAddr.streetAddress}, 
                              ${this.refObj.selectedAddr.city ? this.refObj.selectedAddr.city : this.refObj.selectedAddr.locality}, 
                              ${this.refObj.selectedAddr.stateOrProvince} 
                              ${lpostCode}`;
  }

  public saveChangedAddr() {
    if (this.refObj.addrTypeSelected === 'International') {
      if (!this.refObj.addrModels.field1 || !this.refObj.selectedState.countryCode) {
        this.refObj.isEnteredAllAddsFields = false;
        return;
      }
      this.billingAddr.addressLine1 = this.refObj.addrModels.field1;
      this.billingAddr.addressLine2 = this.refObj.addrModels.field2;
      this.billingAddr.city = this.refObj.addrModels.field3;
      this.billingAddr.locality = this.billingAddr.city;
      this.billingAddr.postCode = this.addressForm.value.zipCodeInt;
      this.billingAddr.country = this.refObj.selectedState.countryCode;
      this.refObj.combinedAddress = `${this.billingAddr.addressLine1}, 
                                ${this.billingAddr.addressLine2}, 
                                ${this.billingAddr.city},
                                ${this.billingAddr.country}`;
      let internationalAddressEntry: EnterpriseAddress = {
        isValidated: true,
        streetAddress: this.refObj.addrModels.field1,
        streetNrFirst: '',
        streetNrFirstSuffix: '',
        streetNamePrefix: '',
        streetName: this.refObj.addrModels.field2,
        streetType: '',
        locality: this.refObj.addrModels.field3,
        city: this.refObj.addrModels.field3,
        stateOrProvince: '',
        postCode: this.billingAddr.postCode,
        postCodeSuffix: '',
        source: '',
        country: this.billingAddr.country,
        subAddress: {
          sourceId: '',
          source: '',
          geoSubAddressId: '',
          combinedDesignator: '',
          elements: [
            {
              designator: '',
              value: ''
            }
          ]
        }
      }
      this.refObj.validatedAddr = this.billingAddr.addressLine1 + ', ' + this.billingAddr.city + ', ' + this.billingAddr.country + ' ' + this.billingAddr.postCode;
      this.store.dispatch({ type: 'VALIDATED_BILLING_ADDR', payload: { billingAddress: this.refObj.validatedAddr } });
      this.refObj.selectedAddr = Object.assign({}, internationalAddressEntry);
      this.accRespObj.isBillAddrSameAsServiceAddress = false;
      this.updateAddress.emit({
        address: this.refObj.selectedAddr,
        billingAddressType: this.refObj.addrTypeSelected,
        billingAdditionalInfo: this.refObj.addrCareOf,
        isBillAddrSameAsServiceAddress: false
      });
    }
    this.saveAddress.emit({ success: true });
    this.refObj.disableSaveAddr = true;
    this.refObj.isEnteredAllAddsFields = true;
  }

  /** unsubscribe on destroy */
  public ngOnDestroy() {
    if (this.userSubscription !== undefined) {
      this.userSubscription.unsubscribe();
    }
  }

}
