import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Store } from '@ngrx/store';
import { APIErrorLists, ErrorResponse, serverErrorMessages } from 'app/common/models/common.model';
import { creditService } from 'app/common/service/credit-check.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { cloneDeep } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { PaymentInfo } from '../../common/models/credit-check.model';
import { Logger } from './../../common/logging/default-log.service';
import { AppStore } from './../../common/models/appstore.model';
import { User } from './../../common/models/user.model';
import { HelperService } from 'app/common/service/helper.service';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { env } from '../../../environments/environment';
import "rxjs/add/operator/catch";

@Component({
  selector: 'credit-check',
  templateUrl: './credit-check.component.html',
  styleUrls: ['../account-component/account.component.scss']
})
export class CreditCheckComponent implements OnInit, OnDestroy {
  public currentFlow: any;
  public existingProductStoreSubscription: Subscription;
  public existingProductStore$: Observable<any>;
  public accountReentrant: boolean = false;
  public retainObservable: Observable<any>;
  public dhpRefoundAmt: any;
  public dhpPaymentDone: boolean = false;
  public potsRefoundAmt: any;
  public potsPaymentDone: boolean = false;
  public hsiRefundAmt: any;
  public allProductsPaid: boolean = true;
  public hsiPaymentDone: boolean = false;
  public addlOrderAttributesDepositData: any;
  public retryButtonEnabled: boolean = false;
  public accInformation: any;
  public accountSubscription: Subscription;
  public accountObservable: Observable<any>;
  public isReEntrant: boolean;
  public dtvSelected: boolean = false;
  public retry: boolean = false;
  public apiResponseError: APIErrorLists;
  public creditCheck: Observable<User>;
  public loading: boolean = false;
  public userSubscription: Subscription;
  public creditReviewSubscription: Subscription;
  public refObj: any = {
    totalDepositAmount: 0,
    disableDepositBtn: false,
    disablePastDueBtn: false,
    displayPaidDeposit: false,
    displayPaidPD: false,
    paymentFailedPD: false,
    paymentFailed: false
  };
  public accRespObj: any = {};
  public otcData1: any;
  public ban: any;
  public creditObj = {};
  public user: Observable<User>;
  public personalDet = {};
  public depositInfoObj: any = {};
  public otcDataResponse: any;
  public creditInfoObj: any = {};
  public payobj: any = {};
  public visible: boolean;
  public paymentReqObj: any = [];
  public invokeDialog: string;
  public previousUrl: any;
  public creditReview: Observable<any>;
  public depositCheck: boolean;
  public creditRespObj1: any;
  public orderAttributeGroupInfo: any = [];
  public dtvYes: boolean = false;
  public paymentURL: string;
  public ExtFlowObj: any;
  public usrData: any;
  public creditReviewResp: any;
  public currentUrl: any;
  public isDtvOpus: boolean;
  public bypassSelected: boolean = false;
  public bypassDepositUser: boolean = false;
  public securitydiposit: any;
  public profile: string;
  public legacy: string;
  @Output() public dtvAccNo: EventEmitter<number> = new EventEmitter<number>();
  @Input() public creditRespObj: any;
  @Output() public updatePaymentDetails: EventEmitter<object> = new EventEmitter<object>();
  @ViewChild("dtvAcc", { static: false, }) public dtvAcc: any;
  @ViewChild("payDeposit", { static: false, }) public payDeposit: any;
  @Input() public flowName;
  @Input() public isStatusAmend;
  public isOTCAvail: boolean = false;

  constructor(
    private logger: Logger,
    private creditService: creditService,
    private sanitizer: DomSanitizer,
    public helperService: HelperService,
    public store: Store<AppStore>,
    private ctlHelperService: CTLHelperService,
    private systemErrorService: SystemErrorService) {
    this.bypassDepositUser = helperService.isAuthorized(ProfileEnums.BYPASS_SECURITY_DEPOSIT);
    this.user = <Observable<User>>store.select('user');
    this.userSubscription = this.user.subscribe((data) => {
      if (data && data.orderInit && data.orderInit.payload && data.orderInit.payload.serviceAddress && data.orderInit.payload.serviceAddress.locationAttributes && data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider) {
        this.legacy = data.orderInit.payload.serviceAddress.locationAttributes.legacyProvider;
      }
      this.usrData = data;
      this.isDtvOpus = data.isDtvOpus;
      if (data.previousUrl !== null && data.previousUrl !== undefined) {
        this.previousUrl = data.previousUrl;
        this.currentUrl = data.currentUrl;
      }
      this.existingProductStore$ = <Observable<any>>store.select('existingProducts');
      this.existingProductStoreSubscription = this.existingProductStore$.subscribe((respData) => {
        if (respData && respData.orderFlow && respData.orderFlow.flow) {
          this.currentFlow = respData.orderFlow.flow;
        }
      });
      if (this.currentFlow === "Move") {
        if (data.previousUrl !== '/move-schedule-appt' && data.previousUrl !== '/move-schedule-appt-ship' && data.previousUrl === '/mo-review-order') {
          this.isReEntrant = true;
        } else {
          this.retainObservable = <Observable<any>>store.select('retain');
          this.retainObservable.subscribe((respData) => {
            this.accountReentrant = respData.accountreentrant;
          });
        }
      }
      if (this.currentFlow === "Change") {
        if (data.previousUrl !== '/schedule-appt-ship' && data.previousUrl !== '/schedule-appt') {
          this.isReEntrant = true;
        } else {
          this.retainObservable = <Observable<any>>store.select('retain');
          this.retainObservable.subscribe((respData) => {
            this.accountReentrant = respData.accountreentrant;
          });
        }
      }

      if (this.isDtvOpus) {
        if (data && data.dtvOpus && data.dtvOpus.taskName === 'yes') {
          this.dtvYes = true;
        }
      }
      else {
        if (data && data.dtvQuestionForm && data.dtvQuestionForm.taskName === 'yes') {
          this.dtvYes = true;
        }
      }

      if (data && data.currentSelected && data.currentSelected !== undefined) {
        if (Array.isArray(data.currentSelected)) {
          data.currentSelected.forEach((dat) => {
            if (dat.selected === "VIDEO-DTV") {
              this.dtvSelected = true;
            }
          });
        }

      }
    });
    this.retainObservable = <Observable<any>>store.select('retain');
    this.retainObservable.subscribe((respData) => {
      this.bypassSelected = respData.bypassedvalue ? respData.bypassedvalue : false;
    });
    this.user = <Observable<User>>store.select('existingProducts');
    this.userSubscription = this.user.subscribe((data) => {
      this.ExtFlowObj = data;
    });
    this.creditCheck = <Observable<User>>this.store.select('creditCheck');
    this.userSubscription = this.creditCheck.subscribe((data) => {
      this.creditReviewResp = data;
    });

    if (this.isReEntrant && !this.accountReentrant) {
      if (this.isReEntrant) {
        this.user = <Observable<any>>store.select('order');
        this.userSubscription = this.user.subscribe(data => {
          if (data && data.paymentdepositdata && data.paymentdepositdata !== undefined && data.paymentdepositdata.depositPaymentStatus === "PAID") {
            this.allProductsPaid = true;
            this.refObj.disableDepositBtn = true;
            this.refObj.paymentStatus = "success";
            let currDate = new Date();
            this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
          } else {
            this.allProductsPaid = false;
            this.refObj.disableDepositBtn = false;
          }
        });
      }
    }
    if (this.accountReentrant && !this.isReEntrant) {
      this.accountObservable = <Observable<any>>store.select('account');
      this.accountSubscription = this.accountObservable.subscribe((respData) => {
        this.addlOrderAttributesDepositData = respData && respData.payload && respData.payload.addlOrderAttributes !== undefined && respData.payload.addlOrderAttributes;
      });
      if (this.addlOrderAttributesDepositData && this.addlOrderAttributesDepositData !== undefined && this.addlOrderAttributesDepositData[0] && this.addlOrderAttributesDepositData[0].orderAttributeGroup) {
        this.addlOrderAttributesDepositData.map((data) => {
          data.orderAttributeGroup.map(depositData => {
            if (depositData && depositData.orderAttributeGroupName === "depositData") {
              depositData.orderAttributeGroupInfo.map(paymentData => {
                let currDate = new Date();
                this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
                if (paymentData && paymentData.orderAttributes[0].orderAttributeValue === "INTERNET") {
                  if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                    this.hsiPaymentDone = true;
                    this.refObj.disableDepositBtn = true;
                    this.refObj.paymentStatus = "success";
                  } else {
                    this.allProductsPaid = false;
                    this.hsiPaymentDone = false;
                    this.refObj.disableDepositBtn = false;
                  }
                  if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                    this.hsiRefundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                  }
                }
                if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-HP") {
                  if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                    this.potsPaymentDone = true;
                    this.refObj.disableDepositBtn = true;
                    this.refObj.paymentStatus = "success";
                  } else {
                    this.allProductsPaid = false;
                    this.potsPaymentDone = false;
                    this.refObj.disableDepositBtn = false;
                  }
                  if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                    this.potsRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                  }
                }
                if (paymentData.orderAttributes[0].orderAttributeValue === "VOICE-DHP") {
                  if (paymentData.orderAttributes[3].orderAttributeValue === "PAID") {
                    this.dhpPaymentDone = true;
                    this.refObj.disableDepositBtn = true;
                    this.refObj.paymentStatus = "success";
                  } else {
                    this.allProductsPaid = false;
                    this.dhpPaymentDone = false;
                    this.refObj.disableDepositBtn = false;
                  }
                  if (paymentData.orderAttributes[1].orderAttributeName === "depositAmt") {
                    this.dhpRefoundAmt = paymentData.orderAttributes[1].orderAttributeValue;
                  }
                }
                if (!this.dhpPaymentDone && this.hsiPaymentDone && !this.allProductsPaid) {
                  this.refObj.disableDepositBtn = false;
                }
              });
            }
          });
        });
      }
    }
  }

  public ngOnInit() {
    this.logger.metrics('AccountCreditCheckPage');

    // deposit required false scenario
    if (this.ExtFlowObj && this.ExtFlowObj.existingProductsAndServices && this.ExtFlowObj.existingProductsAndServices[0] && this.ExtFlowObj.existingProductsAndServices[0] &&
      this.ExtFlowObj.existingProductsAndServices[0].accountInfo) {
      this.personalDet = this.ExtFlowObj.existingProductsAndServices[0].accountInfo.personalDetails;
      this.ban = this.ExtFlowObj.existingProductsAndServices[0].accountInfo.ban;
    }

    this.creditRespObj = this.udpateServiceGroup(this.creditRespObj);

    if (this.creditRespObj && this.creditRespObj.payload && this.creditRespObj.payload.addlOrderAttributes !== null && this.creditRespObj.payload.addlOrderAttributes !== undefined && this.creditRespObj.payload.addlOrderAttributes.length > 0 && this.creditRespObj.payload.depositInfo === undefined) {
      this.depositCheck = this.creditRespObj.payload.depositRequiredInd;
      this.depositInfoObj = this.creditRespObj.payload.addlOrderAttributes[0].orderAttributeGroup[0].orderAttributeGroupInfo;
      this.store.dispatch({ type: 'CREDIT_REVIEW_PAYMENT_STATUS', payload: true });
    }
    // deposit required true scenario
    if (this.creditRespObj && this.creditRespObj.payload && this.creditRespObj.payload.depositInfo !== null && this.creditRespObj.payload.depositInfo !== undefined && this.creditRespObj.payload.depositInfo.products && this.creditRespObj.payload.depositInfo.products.length > 0 && this.creditRespObj.payload.creditInfo) {
      this.depositInfoObj = this.creditRespObj.payload.depositInfo;
      this.depositCheck = this.creditRespObj.payload.depositInfo.depositRequired;
      this.creditInfoObj = this.creditRespObj.payload.creditInfo;
      this.store.dispatch({ type: 'CREDIT_REVIEW_PAYMENT_STATUS', payload: false });
      let tot = 0;
      if (this.depositInfoObj && this.depositInfoObj.products) {
        for (let prd of this.depositInfoObj.products) {
          tot += parseInt(prd.depositAmount.amount, 10);
        }
      }
      this.refObj.totalDepositAmount = tot;
      this.payobj.amount = tot;
    }
    if (this.creditRespObj && this.creditRespObj.payload && this.creditRespObj.payload.accountInfo) {
      this.accRespObj = this.creditRespObj.payload.accountInfo;
    } else {
      this.accRespObj = this.ExtFlowObj.existingProductsAndServices[0].accountInfo;
    }

    if(this.creditRespObj) this.otcData1 = this.creditRespObj.payload.addlOrderAttributes;
    this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup && this.otcData1[0].orderAttributeGroup.map(group => {
      if (group.orderAttributeGroupName === 'otcInstallmentInfo') {
        this.isOTCAvail = true;
      }
    });
    this.otcDataResponse = cloneDeep(this.otcData1);
  }

  /** On installment option selection calculate total deposit */
  public calculateTotalDeposit() {
    let tot = 0;
    if (this.depositInfoObj && this.depositInfoObj.products) {
      for (let prd of this.depositInfoObj.products) {
        tot += parseInt(prd.depositAmount.amount, 10);
      }
    }
    this.refObj.totalDepositAmount = tot;
    this.payobj.amount = tot;
  }

  // call DTV Acc Service
  public callDtvSave() {
    this.dtvAcc.toNextStage();
  }

  public popupCenter(url, w, h) {
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);
    return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
  }

  public showOption(installmentOptions) {
    if (installmentOptions && installmentOptions.noOfInstallments && installmentOptions.noOfInstallments > 1) {
      return true;
    } else {
      return false;
    }
  }

  public retryPopup(retry: boolean) {
    this.retry = retry;
  }
  /** Set content for deposit modal */
  public setModalDepositData(flag) {
    this.retryButtonEnabled = true;
    this.visible = true;
    this.refObj.disableDepositBtn = true;
    this.invokeDialog = 'Pay Deposit';
    this.payobj.paymentStatement = 'Total Deposit Due Today';
    this.payobj.paymentheader = 'Advance Payment required';
    this.payobj.name = this.usrData.firstName + ' ' + this.usrData.lastName;
    if (this.ExtFlowObj && this.ExtFlowObj.existingProductsAndServices && this.ExtFlowObj.existingProductsAndServices[0] &&
      this.ExtFlowObj.existingProductsAndServices[0].serviceAddress) {
      this.payobj.address = this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.streetAddress + " " + this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.locality + "," + this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.stateOrProvince + " " + this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.postCode;
    }
    if (this.ExtFlowObj && this.ExtFlowObj.existingProductsAndServices && this.ExtFlowObj.existingProductsAndServices[0] &&
      this.ExtFlowObj.existingProductsAndServices[0].accountInfo.contact) {
      this.payobj.contactNumber = this.ExtFlowObj.existingProductsAndServices[0].accountInfo.contact.contactNumber;
    }
    this.payobj.isDepositModal = true;
    this.payobj.amount = this.refObj && this.refObj.totalDepositAmount;
    this.payobj.depositURL = "";
    this.paymentURLBMCall(flag);
  }

  /** Set content for past due modal */
  public setModalBalanceData(balanceAccDet) {
    this.visible = true;
    this.refObj.disablePastDueBtn = true;
    this.invokeDialog = 'Pay Due';
    this.payobj.paymentStatement = 'Total Payment Due Today';
    this.payobj.paymentheader = 'Advance Payment required';
    this.payobj.name = this.usrData.firstName + ' ' + this.usrData.lastName;
    if (this.ExtFlowObj && this.ExtFlowObj.existingProductsAndServices && this.ExtFlowObj.existingProductsAndServices[0] &&
      this.ExtFlowObj.existingProductsAndServices[0].serviceAddress) {
      this.payobj.address = this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.streetAddress + " " + this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.locality + "," + this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.stateOrProvince + " " + this.ExtFlowObj.existingProductsAndServices[0].serviceAddress.postCode;
    }
    if (this.ExtFlowObj && this.ExtFlowObj.existingProductsAndServices && this.ExtFlowObj.existingProductsAndServices[0] &&
      this.ExtFlowObj.existingProductsAndServices[0].accountInfo.contact) {
      this.payobj.contactNumber = this.ExtFlowObj.existingProductsAndServices[0].accountInfo.contact.contactNumber;
    }
    this.payobj.isDepositModal = false;
    this.payobj.acctNumber = balanceAccDet && balanceAccDet.btn;
    this.payobj.amount = balanceAccDet && balanceAccDet.finalBillAmt && balanceAccDet.finalBillAmt.amount;
    this.paymentURLBMCall();
  }

  public paymentURLBMCall(flag?): any {
    let paymentReq = {
      "orderRefNumber": this.creditRespObj.orderRefNumber,
      "processInstanceId": this.creditRespObj.processInstanceId,
      "taskId": this.usrData.taskId,
      "taskName": this.creditRespObj.taskName,
      "payload": {
        "creditReviewAction": "PAYDEPOSIT",
        "addlOrderAttributes": [
          {
            "orderAttributeGroup": [
              {
                "orderAttributeGroupName": "paymentCallbackURL",
                "orderAttributeGroupInfo": [
                  {
                    "orderAttributes": [
                      {
                        "orderAttributeName": "hostname",
                        "orderAttributeValue": 'https://' + window.location.hostname + (window.location.port ? ":" + window.location.port : "") + '/'
                      }
                    ]
                  }
                ]
              },
              {
                "orderAttributeGroupName": "depositOnOrder",
                "orderAttributeGroupInfo": [
                  {
                    "orderAttributes": [
                      {
                        "orderAttributeName": "depositDueToday",
                        "orderAttributeValue": this.creditRespObj && this.creditRespObj.payload &&
                          this.creditRespObj.payload.depositInfo &&
                          this.creditRespObj.payload.depositInfo.products &&
                          this.creditRespObj.payload.depositInfo.products[0] &&
                          this.creditRespObj.payload.depositInfo.products[0].depositAmount &&
                          this.creditRespObj.payload.depositInfo.products[0].depositAmount.amount
                      }
                    ]
                  }
                ]
              },
              {
                'orderAttributeGroupName': 'depositCreated',
                'orderAttributeGroupInfo': [{
                  'orderAttributes':
                    [{
                      'orderAttributeName': 'depositCreatedInd',
                      'orderAttributeValue': flag === 'retry' ? true : false
                    }]
                }]
              }
            ]
          }
        ]
      }
    };
    this.loading = true;
    if (this.currentUrl === '/move-account') {
      this.logger.log("info", "credit-check.component.ts", "movePaymentRequest", JSON.stringify(paymentReq));
      let errorResolved = false;
      this.logger.startTime();
      this.creditService.paymentRequestMove(paymentReq)
        .catch((error: any) => {
          this.logger.endTime();
          this.logger.log("error", "credit-check.component.ts", "movePaymentErrorResponse", error);
          this.logger.log("error", "credit-check.component.ts", "movePaymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          errorResolved = true;
          this.loading = false;
          this.ctlHelperService.setLocalStorage('error', error);
          return Observable.throwError(error._body);
        })
        .subscribe(
          (respData) => {
            this.logger.endTime();
            this.logger.log("info", "credit-check.component.ts", "movePaymentResponse", JSON.stringify(respData));
            this.logger.log("info", "credit-check.component.ts", "movePaymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            let sessionId = respData && respData.payload && respData.payload.depositBillpaymentURL && respData.payload.depositBillpaymentURL.sessionId;
            let sessionUrl = respData && respData.payload && respData.payload.depositBillpaymentURL && respData.payload.depositBillpaymentURL.paymentURL;
            this.paymentURL = `${env.DEPOSIT_AND_FINAL_BILL_URL}` + sessionUrl + sessionId;
            this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
            this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
            this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(this.paymentURL);
            this.payDeposit.open();
            this.loading = false;
          },
          (error) => {
            if (!errorResolved) {
              this.logger.endTime();
              this.logger.log("error", "credit-check.component.ts", "movePaymentErrorResponse", error);
              this.logger.log("error", "credit-check.component.ts", "movePaymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            }
            this.loading = false;
            if (error !== undefined) {
              let msg = error;
              if (msg.errorResponse !== undefined && msg.errorResponse.length > 0) {
                this.logger.log('payment error - credit-check.component.ts: ' + msg.errorResponse[0].message);
              }
            }

            let unexpectedError = false;
            if (this.ctlHelperService.isJson(error)) {
              this.apiResponseError = JSON.parse(error);
              if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                this.apiResponseError.errorResponse.length > 0) {
                this.systemErrorService.logAndeRouteToSystemError("error", "paymentRequestMove", "credit-check.component.ts", "Credit Check Page", this.apiResponseError);
              } else { unexpectedError = true; }
            } else { unexpectedError = true; }
            if (unexpectedError) {
              let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
              this.systemErrorService.logAndeRouteToSystemError("error", "paymentRequestMove", "credit-check.component.ts", "Credit Check Page", lAPIErrorLists);
            }
          });
    } else {
      this.logger.log("info", "credit-check.component.ts", "paymentRequest", JSON.stringify(paymentReq));
      let errorResolved = false;
      this.logger.startTime();
      this.creditService.paymentRequest(paymentReq)
        .catch((error: any) => {
          this.logger.endTime();
          this.logger.log("error", "credit-check.component.ts", "paymentResponse", error);
          this.logger.log("error", "credit-check.component.ts", "paymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          this.loading = false;
          errorResolved = true;
          this.ctlHelperService.setLocalStorage('error', error);
          return Observable.throwError(error._body);
        })
        .subscribe(
          (respData) => {
            this.logger.endTime();
            this.logger.log("info", "credit-check.component.ts", "paymentResponse", JSON.stringify(respData));
            this.logger.log("info", "credit-check.component.ts", "paymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            let sessionId = respData && respData.payload && respData.payload.depositBillpaymentURL && respData.payload.depositBillpaymentURL.sessionId;
            let sessionUrl = respData && respData.payload && respData.payload.depositBillpaymentURL && respData.payload.depositBillpaymentURL.paymentURL;
            this.paymentURL = `${env.DEPOSIT_AND_FINAL_BILL_URL}` + sessionUrl + sessionId;
            this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
            this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
            this.payobj.depositURL = this.sanitizer.bypassSecurityTrustResourceUrl(this.paymentURL);
            this.payDeposit.open();
            this.loading = false;
          },
          (error) => {
            if (!errorResolved) {
              this.logger.endTime();
              this.logger.log("error", "credit-check.component.ts", "paymentResponse", error);
              this.logger.log("error", "credit-check.component.ts", "paymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            }
            this.loading = false;
            if (error !== undefined) {
              let msg = error;
              if (msg.errorResponse !== undefined && msg.errorResponse.length > 0) {
                this.logger.log('payment error - credit-check.component.ts: ' + msg.errorResponse[0].message);
              }
            }
            let unexpectedError = false;
            if (this.ctlHelperService.isJson(error)) {
              this.apiResponseError = JSON.parse(error);
              if (this.apiResponseError !== undefined && this.apiResponseError !== null && this.apiResponseError.errorResponse &&
                this.apiResponseError.errorResponse.length > 0) {
                this.systemErrorService.logAndeRouteToSystemError("error", "changeSubmitTask", "credit-check.component.ts", "Credit Check Page", this.apiResponseError);
              } else { unexpectedError = true; }
            } else { unexpectedError = true; }
            if (unexpectedError) {
              let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
              this.systemErrorService.logAndeRouteToSystemError("error", "changeSubmitTask", "credit-check.component.ts", "Credit Check Page", lAPIErrorLists);
            }
          });
    }
  }

  /**
   * Function to prepare deposit products request
   * @param paidDepositProd
   */
  public prepareDepositRequest() {
    let paymentObj: PaymentInfo = {
      sessionId: this.refObj.sessionId,
      paymentCategory: 'DEPOSIT',
      paymentStatus: 'SUCCESS',
      paymentErr: null
    };
    this.paymentReqObj.push(paymentObj);
    this.updatePaymentDetails.emit(paymentObj);
  }

  /**
   * Function to prepare Past due account request
   * @param paidPastAccount
   */
  public preparePastDueRequest() {
    let paymentObj: PaymentInfo = {
      sessionId: this.refObj.sessionId,
      paymentCategory: 'PASTDUE',
      paymentStatus: 'SUCCESS',
      paymentErr: null
    };
    this.paymentReqObj.push(paymentObj);
    this.updatePaymentDetails.emit(paymentObj);
  }

  public enteredDtvId(dtv: number) {
    this.dtvAccNo.emit(dtv);
  }

  public updatePaidDetails(paymentRespAttrs) {
    this.refObj.invokeCallTo = paymentRespAttrs.invokeCall;
    if (paymentRespAttrs.paymentStatus === 'success') {
      this.allProductsPaid = true;
      if (this.allProductsPaid) {
        this.otcData1 && this.otcData1[0] && this.otcData1[0].orderAttributeGroup.map(data => {
          if (data && data.orderAttributeGroupName === "depositData") {
            data.orderAttributeGroupInfo && data.orderAttributeGroupInfo.map(addatrData => {
              addatrData && addatrData.orderAttributes && addatrData.orderAttributes.map(dat => {
                if (dat && dat.orderAttributeName === "depositPayStatus") {
                  dat.orderAttributeValue = 'PAID';
                }
              });
            });
          }
        });
      }
      let reqObj: any = {
        orderRefNumber: this.creditRespObj && this.creditRespObj.orderRefNumber,
        processInstanceId: this.creditRespObj && this.creditRespObj.processInstanceId,
        taskId: this.usrData.taskId,
        taskName: 'Payments',
        payload: {
          paymentStatus: [{
            sessionId: paymentRespAttrs.sessionId,
            paymentCategory: paymentRespAttrs.invokeCall === 'Pay Deposit' ? 'DEPOSIT' : 'PASTDUE',
            paymentStatus: paymentRespAttrs.error === 'success' ? 'SUCCESS' : 'FAIL',
            paymentErr: [{
              errorCode: '',
              errorDesc: ''
            }]
          }]
        }
      };

      this.loading = true;
      if (this.currentUrl === '/move-account') {
        this.logger.log("info", "credit-check.component.ts", "movePaymentRequest", JSON.stringify(reqObj));
        let errorResolved = false;
        this.logger.startTime();
        this.creditService.paymentRequestMove(reqObj)
          .catch((error: any) => {
            this.logger.endTime();
            this.logger.log("error", "credit-check.component.ts", "movePaymentErrorResponse", error);
            this.logger.log("error", "credit-check.component.ts", "movePaymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            errorResolved = true;
            this.ctlHelperService.setLocalStorage('error', error);
            this.loading = false;
            return Observable.throwError(error._body);
          })
          .subscribe(
            (respData) => {
              this.logger.endTime();
              this.logger.log("info", "credit-check.component.ts", "movePaymentResponse", JSON.stringify(respData));
              this.logger.log("info", "credit-check.component.ts", "movePaymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
              this.apiResponseError = null;
              this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
              this.store.dispatch({ type: 'CREDIT_REVIEW_PAYLOAD', payload: respData.payload.billingAddress });
              if (respData && respData.payload && respData.payload.paymentDetails) {
                this.store.dispatch({ type: 'CREDIT_REVIEW_PAYMENT_STATUS', payload: respData.payload.paymentDetails.depositPaymentStatus === "PAID" ? true : false });
              }
              this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
              this.store.dispatch({ type: 'ACCOUNT_INFORMATION', payload: respData.taskId });
              this.loading = false;
            },
            (error) => {
              if (!errorResolved) {
                this.logger.endTime();
                this.logger.log("error", "credit-check.component.ts", "movePaymentErrorResponse", error);
                this.logger.log("error", "credit-check.component.ts", "movePaymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
              }
              this.loading = false;
              let unExpectedError = false;
              if (this.ctlHelperService.isJson(error)) {
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                  this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                  this.systemErrorService.logAndeRouteToSystemError("error", 'paymentRequestMove', "credit-check.component.ts", "Credit Check Page", this.apiResponseError);
                  this.logger.log("error", "credit-check.component.ts", "paymentRequestMove", JSON.stringify(this.apiResponseError));
                } else { unExpectedError = true; }
              } else { unExpectedError = true; }
              if (unExpectedError) {
                let errorResponseCustom: ErrorResponse = {
                  statusCode: serverErrorMessages.statusCode,
                  message: serverErrorMessages.serverDown
                };
                if (this.apiResponseError && this.apiResponseError.errorResponse) {
                  this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                  this.logger.log("error", "credit-check.component.ts", "paymentRequestMove", JSON.stringify(this.apiResponseError));
                }
                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                this.systemErrorService.logAndeRouteToSystemError("error", 'paymentRequestMove', "credit-check.component.ts", "Credit Check Page", lAPIErrorLists);
              }
            });
      } else {
        this.logger.log("info", "credit-check.component.ts", "paymentRequest", JSON.stringify(reqObj));
        let errorResolved = false;
        this.logger.startTime();
        this.creditService.paymentRequest(reqObj)
          .catch((error: any) => {
            this.logger.endTime();
            this.logger.log("error", "credit-check.component.ts", "paymentResponse", error);
            this.logger.log("error", "credit-check.component.ts", "paymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            errorResolved = true;
            this.loading = false;
            return Observable.throwError(error._body);
          })
          .subscribe(
            (respData) => {
              this.logger.endTime();
              this.logger.log("info", "credit-check.component.ts", "paymentResponse", JSON.stringify(respData));
              this.logger.log("info", "credit-check.component.ts", "paymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
              this.apiResponseError = null;
              this.store.dispatch({ type: 'TASK_ID', payload: respData.taskId });
              this.store.dispatch({ type: 'UPDATE_CREDIT_REVIEW', payload: respData.taskId });
              if (respData && respData.payload && respData.payload.paymentDetails) {
                this.store.dispatch({ type: 'CREDIT_REVIEW_PAYMENT_STATUS', payload: respData.payload.paymentDetails.depositPaymentStatus === "PAID" ? true : false });
              }
              this.loading = false;
            },
            (error) => {
              if (!errorResolved) {
                this.logger.endTime();
                this.logger.log("error", "credit-check.component.ts", "paymentResponse", error);
                this.logger.log("error", "credit-check.component.ts", "paymentSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
              }
              this.loading = false;
              let unExpectedError = false;
              if (this.ctlHelperService.isJson(error)) {
                this.apiResponseError = JSON.parse(error);
                if (this.apiResponseError !== undefined && this.apiResponseError !== null &&
                  this.apiResponseError.errorResponse && this.apiResponseError.errorResponse.length > 0) {
                  this.systemErrorService.logAndeRouteToSystemError("error", 'paymentRequest', "credit-check.component.ts", "Credit Check Page", this.apiResponseError);
                  this.logger.log("error", "credit-check.component.ts", "paymentRequest", JSON.stringify(this.apiResponseError));
                } else { unExpectedError = true; }
              } else { unExpectedError = true; }
              if (unExpectedError) {
                let errorResponseCustom: ErrorResponse = {
                  statusCode: serverErrorMessages.statusCode,
                  message: serverErrorMessages.serverDown
                };
                if (this.apiResponseError && this.apiResponseError.errorResponse) {
                  this.apiResponseError.errorResponse.unshift(errorResponseCustom);
                  this.logger.log("error", "credit-check.component.ts", "paymentRequest", JSON.stringify(this.apiResponseError));
                }
                let lAPIErrorLists = this.systemErrorService.lAPIErrorLists(null);
                this.systemErrorService.logAndeRouteToSystemError("error", 'paymentRequest', "credit-check.component.ts", "Credit Check Page", lAPIErrorLists);
              }
            });
      }
    }

    //Status update for payment
    if (this.refObj.invokeCallTo === 'Pay Deposit') {
      if (paymentRespAttrs.error === 'success') {
        this.refObj.isPaymentSuccess = true;
        this.refObj.displayPaidDeposit = true;
        this.refObj.paymentFailed = false;
        this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
        let currDate = new Date();
        this.refObj.sessionId = paymentRespAttrs.sessionId;
        this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
      } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled'
        || paymentRespAttrs.error === 'CANCELLED') {
        this.refObj.isPaymentSuccess = true;
        this.refObj.paymentFailed = false;
        this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
        let currDate = new Date();
        this.refObj.sessionId = paymentRespAttrs.sessionId;
        this.refObj.depositPaidDate = currDate.getMonth() + 1 + '/' + currDate.getDate();
      } else {
        this.refObj.isPaymentSuccess = false;
        this.refObj.paymentFailed = true;
        this.refObj.paymentStatus = paymentRespAttrs.paymentStatus;
        paymentRespAttrs.isDepositCallback ?
          this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
      }
      this.prepareDepositRequest();
    } else {
      if (paymentRespAttrs.error === 'success') {
        this.refObj.isPaymentSuccessPD = true;
        this.refObj.displayPaidPD = true;
        this.refObj.paymentFailedPD = false;
        this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
        let currDate = new Date();
        this.refObj.sessionId = paymentRespAttrs.sessionId;
        this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
      } else if (paymentRespAttrs.error === 'cancelled' || paymentRespAttrs.error === 'Cancelled'
        || paymentRespAttrs.error === 'CANCELLED') {
        this.refObj.isPaymentSuccessPD = true;
        this.refObj.paymentFailedPD = false;
        this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
        let currDate = new Date();
        this.refObj.sessionId = paymentRespAttrs.sessionId;
        this.refObj.paidDatePD = currDate.getMonth() + 1 + '/' + currDate.getDate();
      } else {
        this.refObj.isPaymentSuccessPD = false;
        this.refObj.paymentFailedPD = true;
        this.refObj.paymentStatusPD = paymentRespAttrs.paymentStatus;
        paymentRespAttrs.isDepositCallback ?
          this.refObj.displayPaidDeposit = false : this.refObj.displayPaidPD = false;
      }
      this.preparePastDueRequest();
    }
  }

  public udpateServiceGroup(creditReviewResp) {
    if (creditReviewResp && creditReviewResp.payload && creditReviewResp.payload.depositInfo && creditReviewResp.payload.depositInfo.products) {
      for (let product of creditReviewResp.payload.depositInfo.products) {
        if (product.productType) {
          switch (product.productType) {
            case "INTERNET":
              product.serviceGroup = "Internet";
              break;
            case "VOICE-HP":
              product.serviceGroup = "Home Phone";
              break;
            case "VOICE-DHP":
              product.serviceGroup = "Digital Home Phone";
              break;
            case "VIDEO-DTV":
              product.serviceGroup = "DIRECTV";
              break;
            case "VIDEO-PRISM":
              product.serviceGroup = "Prism";
              break;
          }
        }
      }
    }
    return creditReviewResp;
  }

  public actPopup(w, h) {
    let url;
    const left = (screen.width / 2) - (w / 2);
    const top = (screen.height / 2) - (h / 2);
    if (this.legacy === 'CENTURYLINK') {
      url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22clickedChannel%22%3A%22-lpuw-chat%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Atrue%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%2216%22%2C%22cid%22%3A1570083412%2C%22eid%22%3A1570086412%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22Y5YzQ2MWM0YjIzMTExYmRi%22%2C%22ssid%22%3A%22rI28qh_OTFKTGfGQbOQIFA%22%2C%22lewid%22%3A1570246712%2C%22allowUnauthMsg%22%3Afalse%2C%22availabilityPolicy%22%3A1%2C%22skill%22%3A%22credit-service-ens%22%7D%7D&parentWindowOrigin=https://rmodkit.corp.intranet';
    } else {
      url = 'https://lpcdn.lpsnmedia.net/le_unified_window/index.html?lpUnifiedWindowConfig=%7B%22accountId%22%3A%2292090725%22%2C%22env%22%3A%22prod%22%2C%22external%22%3Atrue%2C%22supportBlockCCPattern%22%3Afalse%2C%22scp%22%3A%22uw%22%2C%22secureStorageType%22%3A%22indexedDB%22%2C%22engConf%22%3A%7B%22async%22%3Afalse%2C%22scid%22%3A%228%22%2C%22cid%22%3A1570083512%2C%22eid%22%3A1570086812%2C%22lang%22%3A%22en-US%22%2C%22svid%22%3A%22AzY2QxNDAyNDE2YTdhMGI1%22%2C%22ssid%22%3A%22C-xqYDpuQr692Su1zOt-6Q%22%2C%22lewid%22%3A1570246912%2C%22skill%22%3A%22credit-service-cris%22%7D%7D';
    }
    return window.open(url, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + String(top) + ', left=' + String(left));
  }

  public selectBypass(e: any, value?) {
    if (e.target.checked === true) {
      this.store.dispatch({ type: 'BYPASSED-VALUE', payload: true });
    }
    else {
      this.store.dispatch({ type: 'BYPASSED-VALUE', payload: false });
    }
  }
  /** unsubscribe on destroy */
  public ngOnDestroy() {
  }

}
