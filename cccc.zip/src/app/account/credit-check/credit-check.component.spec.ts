import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MockServer } from 'app/MockServer.test';
import { Observable, of } from 'rxjs';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { SharedModule } from 'app/shared/shared.module';
import { MockLogger, MockAccountService, MockAddressService, MockReviewOrderService, MockSystemErrorService, MockHelperService, MockDirectvService, MockVacationService, MockPendingOrderService, MockDisconnectService, MockProductService, MockBlueMarbleService, MockPropertiesHelperService } from 'app/common/service/mockServices.test';
import { Logger } from 'app/common/logging/default-log.service';
import { Store } from '@ngrx/store';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { VacationService } from 'app/common/service/vacation.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ReviewOrderService } from 'app/common/service/review-order.service';
import { PendingOrderService } from 'app/common/service/pending-order.service';
import { DisconnectService } from 'app/common/service/disconnect.service';
import { AccountService } from 'app/common/service/account.service';
import { ProductService } from 'app/common/service/product.service';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { AddressService } from 'app/common/service/address.service';
import { PropertiesHelperService } from 'app/common/service/propertiesHelper.service';
import { CreditCheckComponent } from './credit-check.component';
import { creditService } from 'app/common/service/credit-check.service';
import { HelperService } from 'app/common/service/helper.service';
import { CountryStateService } from 'app/common/service/country-state.service';
import { DirectvService } from 'app/common/service/directv.services';

describe('CreditCheckComponent', () => {
  let component: CreditCheckComponent;
  let fixture: ComponentFixture<CreditCheckComponent>;
  const mockServer = new MockServer();

  const imports = [
    FormsModule,
	ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
	TextMaskModule,
	SharedCommonModule,
    SharedModule,
    RouterTestingModule.withRoutes([])
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
        return of(
            mockServer.getMockStore("CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE")[reducer]
        );
    },
    take<T>(this: Observable<T>, count: number) {
        return of(null);
    }
  }
  class MockAppStateService {
	setLocationURLs() {
        return null;
    }
    getState () {
        return mockServer.getMockStore('CHANGE_HSI_TILL_ORDER_CONFIRMATION_PAGE');
    }
  } 

  const logger = { provide: Logger, useClass: MockLogger };
  const store = { provide: Store, useValue: mockRedux };
  const appStateService = { provide: AppStateService, useClass: MockAppStateService };
  const vacationService = { provide: VacationService, useClass: MockVacationService };
  const systemErrorService = { provide: SystemErrorService, useClass: MockSystemErrorService };
  
  const reviewOrderService = { provide: ReviewOrderService, useClass: MockReviewOrderService };
  const pendingOrderService = { provide: PendingOrderService, useClass: MockPendingOrderService };
  const disconnectService = { provide: DisconnectService, useClass: MockDisconnectService };
  const accountService = { provide: AccountService, useClass: MockAccountService };
  const productService = { provide: ProductService, useClass: MockProductService };
  const blueMarbleService = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  const propertiesHelperService = { provide: PropertiesHelperService, useClass: MockPropertiesHelperService };
  const addressService = { provide: AddressService, useClass: MockAddressService };
  const CreditService = creditService;
  const helperService = { provide: HelperService, useClass: MockHelperService };
  const directvService = { provide: DirectvService, useClass: MockDirectvService };

  const providers = [
	logger, store, appStateService, vacationService, 
    systemErrorService, CTLHelperService , pendingOrderService, reviewOrderService,
    disconnectService, accountService, productService, blueMarbleService, propertiesHelperService, 
    addressService, CreditService, helperService, CountryStateService, directvService
  ];

  const baseConfig = {
    imports: imports,
    declarations: [ CreditCheckComponent ],
    providers: providers
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
});
