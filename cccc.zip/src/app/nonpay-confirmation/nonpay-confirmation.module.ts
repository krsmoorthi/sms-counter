import { NgModule } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { nonPaySuspendConfirmationComponent } from '../nonpay-confirmation/nonpay-confirmation.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: nonPaySuspendConfirmationComponent
    }
];

@NgModule({
    imports: [       
        RouterModule.forChild(COMPONENT_ROUTER),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,        
        SharedCommonModule,
        SharedModule
    ],
    exports: [nonPaySuspendConfirmationComponent],
    declarations: [nonPaySuspendConfirmationComponent],
    providers: [
        
        
    ]
})
export class NonPaySuspendConfirmModule { }
