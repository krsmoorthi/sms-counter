import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { Observable } from "rxjs";
import "rxjs/add/observable/of";
import "rxjs/add/observable/throw";
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { GenericValues } from '../common/models/common.model';
import { HelperService } from 'app/common/service/helper.service';

@Component({
  selector: 'nonpay-suspend-confirmation',
  templateUrl: './nonpay-confirmation.component.html',
  styleUrls: ['./nonpay-confirmation.component.scss']
})
export class nonPaySuspendConfirmationComponent {
  public showCarrierList: any;
  public selectedCarrierRestoredList: any;
  public selectedCarrierSuspendedList: any;
  public showDtvRestoreProd: boolean = false;
  public showInternetRestoreProd: boolean = false;
  public showDhpRestoreProd: boolean = false;
  public showLDRestoreProd: boolean = false;
  public showPotsRestoreProd: boolean = false;
  public suspendedAccountnum: any;
  public suspendTelephoneNumber: any;
  public showDtvSuspendProd: boolean = false;
  public showInternetSuspendProd: boolean = false;
  public showDhpSuspendProd: boolean = false;
  public showLDsuspendProd: boolean = false;
  public showPotsSuspendProd: boolean = false;
  public suspendedProducts: any;
  public exisitngProduct: any;
  public ornConfirmNum: any;
  public orderSubmitted: any;

  constructor(private store: Store<AppStore>, public helperService: HelperService, public ctlHelperService: CTLHelperService) {
    let nonPaySusData = <Observable<any>>this.store.select('existingProducts');
    nonPaySusData.subscribe((data) => {
      if (data && data.nonPaySuspendProductsSubmitres && data.nonPaySuspendProductsSubmitres !== undefined) {
        this.orderSubmitted = data.nonPaySuspendProductsSubmitres.payload.message;
        this.ornConfirmNum = data.nonPaySuspendProductsSubmitres.payload.customerOrderNumber;
      }
      this.exisitngProduct = data;
      this.suspendedAccountnum = this.exisitngProduct && this.exisitngProduct.existingProductsAndServices !== undefined && this.exisitngProduct.existingProductsAndServices[0].accountInfo !== null && this.exisitngProduct.existingProductsAndServices[0].accountInfo.ban;
      this.suspendTelephoneNumber = this.exisitngProduct && this.exisitngProduct.existingProductsAndServices && this.exisitngProduct.existingProductsAndServices[0] && this.exisitngProduct.existingProductsAndServices[0].telephoneNumber;
      if (this.exisitngProduct && this.exisitngProduct.nonPaySuspendProductsReq && this.exisitngProduct.nonPaySuspendProductsReq !== undefined) {        
        this.suspendedProducts = this.exisitngProduct.nonPaySuspendProductsReq.payload.cart.customerOrderItems;
        this.suspendedProducts.map(data => {
          if (data.offerCategory === GenericValues.cHP) {
            if (data.action === "SUSPEND") {
              this.showPotsSuspendProd = true;
            } else if (data.action === "RESTORE") {
              this.showPotsRestoreProd = true;
              this.showPotsSuspendProd = false;
            } else {
              this.showPotsRestoreProd = false;
            }
            data.customerOrderSubItems.map(subData => {
              if (subData.productName.indexOf('Long Distance') > -1 || subData.productName === "Easy Talk 2" || subData.productName === "CenturyLink Unlimited") {
                if (subData.action === "SUSPEND") {
                  this.showLDsuspendProd = true;
                } else if(subData.action === "RESTORE"){
                  this.showLDRestoreProd = true;  
                } else {
                  this.showLDsuspendProd = false;
                  this.showLDRestoreProd = false;  
                }
              }
              if(subData.productName === "Selective Carrier Denial"){
                if (subData.action === "ADD") {
                  this.showLDsuspendProd = true;
                } else {
                  this.showLDRestoreProd = true;  
                }
              }
            })
          }
          if (data.offerCategory === GenericValues.cDHP) {
            if (data.action === "SUSPEND") {
              this.showDhpSuspendProd = true;
            } else if(data.action === "RESTORE"){           
              this.showDhpRestoreProd = true;  
            } else {
              this.showDhpSuspendProd = false;
              this.showDhpRestoreProd = false;
            }
          }
          if (data.offerCategory === GenericValues.iData) {
            if (data.action === "SUSPEND") {
              this.showInternetSuspendProd = true;
            } else if(data.action === "RESTORE"){
              this.showInternetRestoreProd = true;                          
            } else {
              this.showInternetSuspendProd = false;
              this.showInternetRestoreProd = false;  
            }
          }
          if (data.offerCategory === GenericValues.cDTV) {
            if (data.action === "SUSPEND") {
              this.showDtvSuspendProd = true;
            } else if(data.action === "RESTORE"){
              this.showDtvRestoreProd = true;                          
            } else {
              this.showDtvSuspendProd = false;
              this.showDtvRestoreProd = false; 
            }
          }
        })
        this.exisitngProduct.nonPaySuspendProductsReq.payload.addlOrderAttributes.map(addAttr =>{
          addAttr.orderAttributeGroup.map(data =>{            
              if (data.orderAttributeGroupName === "selectiveCarrierDenial") {
                   this.selectedCarrierSuspendedList = data.orderAttributeGroupInfo[0].orderAttributes;
              }
              if (data.orderAttributeGroupName === "selectiveCarrierRestore") {
                this.selectedCarrierRestoredList = data.orderAttributeGroupInfo[0].orderAttributes;
              }
                 if(this.showLDsuspendProd){
                   this.showCarrierList = this.selectedCarrierSuspendedList;
                 } else if(this.showLDRestoreProd){
                  this.showCarrierList = this.selectedCarrierRestoredList;
                 }            
          })
        })
      }
    });
  }
  public convert(value){  
    return value.replace("-",": ");
   }
}
