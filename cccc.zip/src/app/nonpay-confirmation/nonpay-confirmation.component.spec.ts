import { Routes, RouterModule } from "@angular/router";
import { nonPaySuspendConfirmationComponent } from './nonpay-confirmation.component';
import { ComponentFixture, async, TestBed } from '@angular/core/testing';
import { MockServer } from 'app/MockServer.test';
import { SharedModule } from 'app/shared/shared.module';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { TextMaskModule } from 'angular2-text-mask';
import { AccordionModule, TabsModule } from 'ngx-bootstrap';
import { Observable } from 'rxjs';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { Store } from "@ngrx/store";
import { HelperService } from 'app/common/service/helper.service';
import { MockHelperService } from 'app/common/service/mockServices.test';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

const routes: Routes = [
    {
      path: "",
      component: nonPaySuspendConfirmationComponent
    }
  ];


  describe("nonPayConfirmationComponent suspend scenario", () => {
    let component: nonPaySuspendConfirmationComponent;
    let fixture: ComponentFixture<nonPaySuspendConfirmationComponent>;
    let debugElement: DebugElement;
    const mockServer = new MockServer();
  
    const imports = [
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,        
        SharedCommonModule,
        SharedModule,
        RouterModule.forChild(routes),
    ]
  
    const mockRedux: any = {
      dispatch(obj) {return obj},
      configureStore() {},
      select(reducer) {
          return Observable.of(
            mockServer.getMockStore("NONPAY-SUSPEND-CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };


     // Default Provides
  const p1 = CTLHelperService
  const p2 = { provide: Store, useValue: mockRedux }
  const p3 = { provide: HelperService, useClass: MockHelperService };


  const baseConfig = {
    imports: imports,
    declarations: [nonPaySuspendConfirmationComponent],
    providers: [p1,p2,p3]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig).compileComponents();
    }));
	
  beforeEach(() => {
    
    fixture = TestBed.createComponent(nonPaySuspendConfirmationComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();

  });


  it("should create nonpay suspend confirmation component", () => {
    expect(component).toBeTruthy();
  });

  it("should update value when convert is called", ()=> {
    const value = "nonpay-suspend"  
    const convertedValue = component.convert(value);
    expect(convertedValue).toBeDefined;
    expect(convertedValue).toBe('nonpay: suspend');
  });


  it("should set suspend flags as true based on the offer suspended ", ()=> {
    expect(component.showInternetSuspendProd).toBe(true);
    expect(component.showPotsSuspendProd).toBe(true);
    expect(component.showLDsuspendProd).toBe(true);
    expect(component.showDhpSuspendProd).toBe(true);
    expect(component.showDtvSuspendProd).toBe(true);
  });
  
  it("should have internet UI changes when showInternetSuspendProd is true", ()=>{
    component.showInternetSuspendProd = true;
    const suspendedText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(suspendedText.innerHTML).toContain('Suspended');
    expect(productText.innerHTML).toContain('Internet');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });

  it("should have pots UI changes when showPotsSuspendProd is true", ()=>{
    component.showPotsSuspendProd = true;
    const suspendedText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(suspendedText.innerHTML).toContain('Suspended');
    expect(productText.innerHTML).toContain('Home Phone');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });

  it("should have dhp UI changes when showDhpSuspendProd is true", ()=>{
    component.showDhpSuspendProd = true;
    const suspendedText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(suspendedText.innerHTML).toContain('Suspended');
    expect(productText.innerHTML).toContain('DHP');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });

  it("should have dtv UI changes when showPotsSuspendProd is true", ()=>{
    component.showDtvSuspendProd = true;
    const suspendedText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(suspendedText.innerHTML).toContain('Suspended');
    expect(productText.innerHTML).toContain('DIRECTV');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });



  
  });

  describe("nonPayConfirmationComponent restore scenario", () => {
    let component: nonPaySuspendConfirmationComponent;
    let fixture: ComponentFixture<nonPaySuspendConfirmationComponent>;
    let debugElement: DebugElement;
    const mockServer = new MockServer();
  
    const imports = [
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,        
        SharedCommonModule,
        SharedModule,
        RouterModule.forChild(routes),
    ]
  
    const mockRedux: any = {
      dispatch(obj) {return obj},
      configureStore() {},
      select(reducer) {
          return Observable.of(
            mockServer.getMockStore("NONPAY-RESTORE-CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };


     // Default Provides
  const p1 = CTLHelperService
  const p2 = { provide: Store, useValue: mockRedux }
  const p3 = { provide: HelperService, useClass: MockHelperService };


  const baseConfig = {
    imports: imports,
    declarations: [nonPaySuspendConfirmationComponent],
    providers: [p1,p2,p3]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

  beforeEach(() => {
    fixture = TestBed.createComponent(nonPaySuspendConfirmationComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();

  });


  it("should create nonpay confirmation component", () => {
    expect(component).toBeTruthy();
  });

  it("should set suspend flags as true based on the offer suspended ", ()=> {
    expect(component.showInternetRestoreProd).toBe(true);
    expect(component.showPotsRestoreProd).toBe(true);
    expect(component.showLDRestoreProd).toBe(true);
    expect(component.showDhpRestoreProd).toBe(true);
    expect(component.showDtvRestoreProd).toBe(true);
  });
  
  it("should have internet UI changes when showInternetSuspendProd is true", ()=>{
    component.showInternetRestoreProd = true;
    const restoredText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(restoredText.innerHTML).toContain('Restored');
    expect(productText.innerHTML).toContain('Internet');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });

  it("should have pots UI changes when showPotsSuspendProd is true", ()=>{
    component.showPotsRestoreProd = true;
    const restoredText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(restoredText.innerHTML).toContain('Restored');
    expect(productText.innerHTML).toContain('Home Phone');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });

  it("should have dhp UI changes when showDhpSuspendProd is true", ()=>{
    component.showDhpRestoreProd = true;
    const restoredText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(restoredText.innerHTML).toContain('Restored');
    expect(productText.innerHTML).toContain('DHP');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });

  it("should have dtv UI changes when showPotsSuspendProd is true", ()=>{
    component.showDtvRestoreProd = true;
    const restoredText = debugElement.query(By.css('.nonpay-text')).nativeElement;
    const productText = debugElement.query(By.css('.nonpay-mrg')).nativeElement;
    expect(restoredText.innerHTML).toContain('Restored');
    expect(productText.innerHTML).toContain('DIRECTV');
    expect(productText.innerHTML).toContain(component.suspendTelephoneNumber.slice(0,3));
  });
  
  });

  describe("nonPayConfirmationComponent hsionly restored or suspended", () => {
    let component: nonPaySuspendConfirmationComponent;
    let fixture: ComponentFixture<nonPaySuspendConfirmationComponent>;
    let debugElement: DebugElement;
    const mockServer = new MockServer();
  
    const imports = [
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,        
        SharedCommonModule,
        SharedModule,
        RouterModule.forChild(routes),
    ]
  
    const mockRedux: any = {
      dispatch(obj) {return obj},
      configureStore() {},
      select(reducer) {
          return Observable.of(
            mockServer.getMockStore("NONPAY-HSIONLY-CONFIRMATION")[reducer]
          );
      },
      take<T>(this: Observable<T>, count: number) {
        return Observable.of(null);
      }
    };


     // Default Provides
  const p1 = CTLHelperService
  const p2 = { provide: Store, useValue: mockRedux }
  const p3 = { provide: HelperService, useClass: MockHelperService };


  const baseConfig = {
    imports: imports,
    declarations: [nonPaySuspendConfirmationComponent],
    providers: [p1,p2,p3]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule(baseConfig).compileComponents();
    }));

  beforeEach(() => {
    fixture = TestBed.createComponent(nonPaySuspendConfirmationComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();

  });

  it("should set hsi restore flags as true and others as false", ()=> {
    expect(component.showInternetSuspendProd).toBe(true);
    expect(component.showPotsSuspendProd).toBe(false);
    expect(component.showLDsuspendProd).toBe(false);
    expect(component.showDhpSuspendProd).toBe(false);
    expect(component.showDtvSuspendProd).toBe(false);
  });

  });

