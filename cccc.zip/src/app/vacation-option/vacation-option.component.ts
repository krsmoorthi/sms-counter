import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppStore } from 'app/common/models/appstore.model';
import { Observable } from 'rxjs';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { Logger } from '../common/logging/default-log.service';
import { Router } from '@angular/router';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { CustomerOrderItems } from 'app/common/models/cart.model';
import { AppStateService } from 'app/common/service/app-state.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { map, omit } from 'lodash';
import { ProfileEnums } from 'app/common/enums/profileEnums';
import { GenericValues } from 'app/common/models/common.model';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import { DisclosuresRes } from 'app/common/models/disclosures.model';
import { DialogComponent } from 'app/common/popup/dialog.component';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { HelperService } from 'app/common/service/helper.service';
import { VacationEnums } from 'app/common/enums/vacationEnums';
import "rxjs/add/operator/catch";
@Component({
  selector: 'vacation-option',
  templateUrl: './vacation-option.component.html',
  styleUrls: ['../product/offer.component.scss',
    './vacation-option.component.scss'
  ]
})
export class VacationOptionComponent implements OnInit, OnDestroy {
  public authorized: boolean = false;
  public isretentionOfferAllowed: boolean = false;
  public exeCatelogSpecId: any;
  public retainTaskId: any;
  public isReentrant: boolean = false;
  public showEnteredNewNum: any;
  private vacationObservable;
  private vacationSubscription;
  public isReferralAllowed: boolean = false;
  public isLifeLinePresent: boolean = false;
  private existingProductsObservable;
  private exisingProductsSubscribe;
  private existingProductItems = [];
  public existingTelephoneNo: string;
  public vacationOptionSelected = [];
  public callersWillHere: any;
  public callersWillHereOption = [];
  public eligibleProducts = [];
  public phoneMask: any;
  private hsiCustomerOrderItem: any;
  public loading: boolean = false;
  private vacSuspendRequest: any;
  private vacSusOrderRefNumber: any;
  private vacSusTaskId: any;
  private vacSusProcessInstanceId: any;
  private cartForVacOpt: any;
  private customerOrderItemsForPots: any[] = [];
  private vacSusVoiceHpOffers: any;
  private custOrderItemFromSusOffer: CustomerOrderItems = {
    customerOrderSubItems: [],
  };
  public isInputFieldActive: any;
  public newNumber: any;
  public isContinueBtnEnabled: boolean = true;
  public vacationreentrant: boolean;
  private iscartForVacOptExecuteOnce: boolean = true;  
  @ViewChild('orderDisclosures', { static: false, }) public orderDisclosures: DialogComponent;
  public isLCAddress: boolean = false;

  constructor(
    private logger: Logger,
    private store: Store<AppStore>,
    public ctlHelperService: CTLHelperService,   
    private offerHelperService: OfferHelperService, 
    private bMService: BlueMarbleService,
    private router: Router,
    private systemErrorService: SystemErrorService,
    private appStateService: AppStateService,
    private textMask: TextMaskService,    
    private disclosuresService: DisclosuresService,
    private helperService: HelperService,
  ) {
    this.phoneMask = this.textMask.getPhoneNumberMaskTN();
  }

  public ngOnInit(): void {
    this.logger.metrics('VacationOptionPage');
    this.appStateService.setLocationURLs();
    this.isLCAddress = this.helperService.isLCAddress();
    if(this.isLCAddress) this.loading = true;
    let userData = <Observable<any>>this.store.select('user');
    userData.subscribe((data) => {
    if(data.currentUrl === "/vacation-option" && data.previousUrl === "/customize-services"){
      this.isReentrant = true;
      this.retainTaskId = data.taskId;
    }
    this.authorized = this.helperService.isAuthorized(ProfileEnums.ALLOW_RETENTION_OFFERS);
    
    });
    this.callersWillHereOption = ['Out of Service', 'Refer to new TN'];
    this.vacationObservable = <Observable<any>>this.store.select('vacation');
    this.existingProductsObservable = <Observable<any>>this.store.select('existingProducts');

    this.vacationSubscription = this.vacationObservable.subscribe((data) => {
      if (data && data.vacSusInitRes && data.vacSusInitRes.payload && data.vacSusInitRes.payload.addlOrderAttributes[0] !== undefined) {
        data.vacSusInitRes.payload && data.vacSusInitRes.payload.addlOrderAttributes[0] && data.vacSusInitRes.payload.addlOrderAttributes[0].orderAttributeGroup[0] &&
          data.vacSusInitRes.payload.addlOrderAttributes[0].orderAttributeGroup.map((orderAttrGroupObj) => {
            orderAttrGroupObj.orderAttributeGroupInfo && orderAttrGroupObj.orderAttributeGroupInfo.map((orderAttrGroupInfoObj) => {
              orderAttrGroupInfoObj.orderAttributes && orderAttrGroupInfoObj.orderAttributes.map((orderAttrObj) => {
                if (orderAttrObj && orderAttrObj !== undefined && orderAttrObj.orderAttributeName && orderAttrObj.orderAttributeName !== undefined && orderAttrObj.orderAttributeName.toUpperCase() === 'REFERRALALLOWED' && orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                  this.isReferralAllowed = true;
                }
                if (orderAttrObj && orderAttrObj !== undefined && orderAttrObj.orderAttributeName && orderAttrObj.orderAttributeName !== undefined && orderAttrObj.orderAttributeName.toUpperCase() === 'LIFELINEPRESENT') {
                  if (orderAttrObj && orderAttrObj !== undefined && orderAttrObj.orderAttributeValue && orderAttrObj.orderAttributeValue !== undefined && orderAttrObj.orderAttributeValue.toUpperCase() === 'YES') {
                    this.isLifeLinePresent = true;
                  } else {
                    this.isLifeLinePresent = false;
                  }
                }
              });
            });
          });
      }
      if(data && data.vacReferralNumber !== undefined && data.vacReferralNumber){
         this.newNumber = data.vacReferralNumber;      
         this.callersWillHere = "Refer to new TN";         
         this.isInputFieldActive = true;      
      }
      if (data && data.vacSusInitRes && data.vacSusInitRes.orderRefNumber) {
        this.vacSusOrderRefNumber = data.vacSusInitRes.orderRefNumber;
      }
      if(data && data.vacSusInitRes && data.vacSusInitRes.payload && data.vacSusInitRes.payload.cart && data.vacSusInitRes.payload.cart.catalogSpecId) {
        this.exeCatelogSpecId = data.vacSusInitRes.payload.cart.catalogSpecId;
      }
      if (!this.isReentrant && data && data.vacSusInitRes && data.vacSusInitRes.taskId) {
        this.vacSusTaskId = data.vacSusInitRes.taskId;
      } else if (this.isReentrant) {
        this.vacSusTaskId = this.retainTaskId;
      }
      if (data && data.vacSusInitRes && data.vacSusInitRes.processInstanceId) {
        this.vacSusProcessInstanceId = data.vacSusInitRes.processInstanceId;
      }
      if (data && data.hsiCustomerOrderItem) {
        this.hsiCustomerOrderItem = data.hsiCustomerOrderItem;
      }
      if (data && data.cartForVacOpt) {
        if(this.iscartForVacOptExecuteOnce) {
          this.iscartForVacOptExecuteOnce = false;
          this.cartForVacOpt = data.cartForVacOpt;
          this.cartForVacOpt && this.cartForVacOpt.customerOrderItems.map((custOrderItemObj) => {
            if (custOrderItemObj && custOrderItemObj.offerCategory && custOrderItemObj.offerCategory.toUpperCase() === 'VOICE-HP' && custOrderItemObj.offerType !== 'SUBOFFER') {
              custOrderItemObj.action = 'VACSUS-REMOVE';
              custOrderItemObj.customerOrderSubItems && custOrderItemObj.customerOrderSubItems.map((custOrderSubItemObj) => {
                custOrderSubItemObj.action = 'VACSUS-REMOVE';
              });
              this.customerOrderItemsForPots.push(custOrderItemObj);
            } else if (custOrderItemObj && custOrderItemObj.offerCategory && custOrderItemObj.offerCategory.toUpperCase() === 'INTERNET' && custOrderItemObj.offerType !== 'SUBOFFER') {
              custOrderItemObj.action = 'VACSUS-REMOVE';
              custOrderItemObj.customerOrderSubItems && custOrderItemObj.customerOrderSubItems.map((custOrderSubItemObj) => {
                if(custOrderSubItemObj.productName.toUpperCase() === 'MODEM') {
                  custOrderSubItemObj.productAttributes && custOrderSubItemObj.productAttributes.map((prodAttribute) => {
                    prodAttribute.compositeAttribute && prodAttribute.compositeAttribute.map((compoAttr) => {
                      if(compoAttr.attributeName && compoAttr.attributeValue && compoAttr.attributeName.toUpperCase() === 'ACCOUNT TYPE' && compoAttr.attributeValue.toUpperCase() === 'PURCHASE') {
                        custOrderSubItemObj.action = 'NOCHANGE';
                      } else if (compoAttr.attributeName && compoAttr.attributeValue && compoAttr.attributeName.toUpperCase() === 'ACCOUNT TYPE' && compoAttr.attributeValue.toUpperCase() === 'LEASE') {
                        custOrderSubItemObj.action = 'VACSUS-REMOVE';
                      }
                    });
                  });
                } else {
                  custOrderSubItemObj.action = 'VACSUS-REMOVE';
                }
              });
              this.customerOrderItemsForPots.push(custOrderItemObj);
            } else if (custOrderItemObj && custOrderItemObj.offerType === 'SUBOFFER') {
              custOrderItemObj.action = 'NOCHANGE';
              custOrderItemObj.customerOrderSubItems && custOrderItemObj.customerOrderSubItems.map((custOrderSubItemObj) => {
                custOrderSubItemObj.action = 'NOCHANGE';
              });
              this.customerOrderItemsForPots.push(custOrderItemObj);
            } else if (custOrderItemObj && custOrderItemObj.offerCategory && (custOrderItemObj.offerCategory.toUpperCase() !== 'INTERNET' || custOrderItemObj.offerCategory.toUpperCase() !== 'VOICE-HP')) {
              this.customerOrderItemsForPots.push(custOrderItemObj);
            }
          });
        }
        
      }
      if (data && data.vacVoiceHpOffer) {
        this.vacSusVoiceHpOffers = data.vacVoiceHpOffer;
      }
    });

    this.exisingProductsSubscribe = this.existingProductsObservable.subscribe((data) => {
      this.existingProductItems = [];
      data.existingProductsAndServices[0].existingServices.existingServiceItems.forEach((existingServiceItemsObj, index) => {
        if (existingServiceItemsObj.offerType.toUpperCase() !== 'SUBOFFER') {
          existingServiceItemsObj.index = index;
          if(!this.isInputFieldActive){
            this.callersWillHere = 'Out of Service';            
          }
          if (existingServiceItemsObj.offerCategory.toUpperCase() !== 'INTERNET') {
            this.existingProductItems.push(existingServiceItemsObj);
          }
          if (existingServiceItemsObj.existingServiceSubItems) {
            existingServiceItemsObj.existingServiceSubItems.forEach((existingServiceSubItemsObj) => {
              if (existingServiceSubItemsObj.productName.toUpperCase().indexOf('WIRE MAINTENANCE') > -1 && existingServiceSubItemsObj.quantity > 0) {
                existingServiceSubItemsObj.productAttributes.forEach((productAttributesObj) => {
                  if (productAttributesObj.isPriceable && (productAttributesObj.prices !== null)) {
                    productAttributesObj.prices.forEach((priceObj) => {
                      if (priceObj.priceType === 'PRICE') {
                        let wireMaintenance = {
                          price: priceObj.rc,
                          frequency: priceObj.frequency,
                          displayName: 'Wire Maintenance',
                          offerCategory: existingServiceItemsObj.offerCategory
                        }
                        this.eligibleProducts.push(wireMaintenance);
                      }
                    });
                  }
                });
              }
              if (existingServiceSubItemsObj.productName.toUpperCase().indexOf('EASE') > -1 && existingServiceSubItemsObj.quantity > 0) {
                existingServiceSubItemsObj.productAttributes.forEach((productAttributesObj) => {
                  if (productAttributesObj.isPriceable && (productAttributesObj.prices !== null)) {
                    productAttributesObj.prices.forEach((priceObj) => {
                      if (priceObj.priceType === 'PRICE') {
                        let ease = {
                          price: priceObj.rc,
                          frequency: priceObj.frequency,
                          displayName: '',
                          offerCategory: existingServiceItemsObj.offerCategory
                        }
                        if (productAttributesObj.compositeAttribute[0] !== undefined) {
                          ease.displayName = productAttributesObj.compositeAttribute[0].attributeValue + ' ' + '@EASE';
                        }
                        this.eligibleProducts.push(ease);
                      }
                    });
                  }
                });
              }
            });
          }
        }
      });
      this.existingTelephoneNo = this.ctlHelperService.maskTelephone(data.existingProductsAndServices[0].telephoneNumber);
    });

    this.changeActionForVacSusCart();
    if(this.isLCAddress) this.onContinueFromVacOptionPage();
  }

  public getCustomerOrderItemsForPots(offer: any, offerName?: any) {
    offer && offer.retrievalTypes && offer.retrievalTypes.map((retrievalType) => {
      retrievalType && retrievalType.offers && retrievalType.offers.map((offerObj) => {
        let isCustomerOrderSubItemReq: boolean = false;
        offerObj.catalogs && offerObj.catalogs.map((catalogObj) => {
          catalogObj.catalogItems && catalogObj.catalogItems.map((catalogItemObj) => {
            if (catalogItemObj.productOffer.offerName.toUpperCase() === VacationEnums.POTS_VAC_SUS_OFFER_NAME.toUpperCase()) {
              this.custOrderItemFromSusOffer.action = 'VACSUS-ADD';
              this.custOrderItemFromSusOffer.catalogId = catalogObj.catalogId;
              this.custOrderItemFromSusOffer.contractTerm = catalogItemObj.productOffer.contract.contractTerm;
              this.custOrderItemFromSusOffer.productOfferingId = catalogItemObj.productOffer.productOfferingId;
              this.custOrderItemFromSusOffer.offerType = catalogItemObj.productOffer.offerType;
              this.custOrderItemFromSusOffer.offerName = catalogItemObj.productOffer.offerName;
              this.custOrderItemFromSusOffer.offerDisplayName = catalogItemObj.productOffer.offerDisplayName;
              this.custOrderItemFromSusOffer.offerSubType = catalogItemObj.productOffer.offerSubType;
              this.custOrderItemFromSusOffer.offerCategory = catalogItemObj.productOffer.offerCategory;
              this.custOrderItemFromSusOffer.quantity = null;
              this.custOrderItemFromSusOffer.customerOrderSubItems = [];
              catalogItemObj.productOffer && catalogItemObj.productOffer.productComponents.map((productComponentObj) => {
                productComponentObj.product.action = 'VACSUS-ADD';
                productComponentObj.product.componentType = productComponentObj.componentType;
                productComponentObj && productComponentObj.product && productComponentObj.product.productName.toUpperCase() === 'NEW NUMBER REFERRAL SERV TRK' && productComponentObj.product.productAttributes && productComponentObj.product.productAttributes.map((prodAttrObj) => {
                  prodAttrObj && prodAttrObj.compositeAttribute && prodAttrObj.compositeAttribute.map((compAttrObj) => {
                    if (compAttrObj && compAttrObj.attributeName && compAttrObj.attributeName.toUpperCase() === 'REFERRAL TYPE') {
                      if (this.newNumber) {
                        this.store.dispatch({ type: 'VACATION_REFERRAL_NUMBER', payload: this.newNumber });
                      }                                                              
                      compAttrObj.attributeValue = this.newNumber;
                    }
                  });
                });
                delete productComponentObj.product.isRegulated;
                delete productComponentObj.product.productCategoryDisplayName;
                delete productComponentObj.product.productDisplayName;
                productComponentObj.product && productComponentObj.product.productAttributes.map((productAttributeObj) => {
                  productAttributeObj.compositeAttribute && productAttributeObj.compositeAttribute.map((compositeAttributeObj) => {
                    if (catalogItemObj.productOffer.offerCategory.toUpperCase() === 'VOICE-HP')
                      isCustomerOrderSubItemReq = true;
                    else isCustomerOrderSubItemReq = false;
                  });
                });

                if (isCustomerOrderSubItemReq && this.newNumber && this.newNumber !== "") {
                  this.custOrderItemFromSusOffer.customerOrderSubItems.push(productComponentObj.product);
                } else if(productComponentObj.product.productName === "Vacation Num Reservation - Res"){
                  this.custOrderItemFromSusOffer.customerOrderSubItems.push(productComponentObj.product);
                }
              });
              if (catalogItemObj.defaultOfferPrice) {
                this.custOrderItemFromSusOffer.discountedRc = catalogItemObj.defaultOfferPrice.discountedRc;
                this.custOrderItemFromSusOffer.discountedOtc = catalogItemObj.defaultOfferPrice.discountedOtc;
                this.custOrderItemFromSusOffer.otc = catalogItemObj.defaultOfferPrice.otc;
                this.custOrderItemFromSusOffer.rc = catalogItemObj.defaultOfferPrice.rc;
              }
            }
          });
        });
      });
    });
    return this.custOrderItemFromSusOffer;
  }

  public changeActionForVacSusCart() {   
    this.vacSuspendRequest = {
      orderRefNumber: this.vacSusOrderRefNumber,
      taskId: this.vacSusTaskId,
      processInstanceId: this.vacSusProcessInstanceId,
      taskName: "Checkout & Scheduling",
      payload: {
        cart: {
          customerOrderItems: []
        }
      }
    }
    if (this.hsiCustomerOrderItem) {
      this.vacSuspendRequest.payload.cart.customerOrderItems.push(this.hsiCustomerOrderItem);
    }
    this.customerOrderItemsForPots.length > 0 && this.customerOrderItemsForPots.map((customerOrderItem) => {
      this.vacSuspendRequest.payload.cart.customerOrderItems.push(customerOrderItem);
    });
    let vacNumResOffer = this.getCustomerOrderItemsForPots(this.vacSusVoiceHpOffers);
    if (vacNumResOffer) {
      this.vacSuspendRequest.payload.cart.customerOrderItems.push(vacNumResOffer);
    }

    this.createCart();
  }

  public createCart() {
    let cartObject: any;
    let payload: any;
    payload = {
      cart: {
        customerOrderItems: this.vacSuspendRequest.payload.cart.customerOrderItems
      }
    };
    cartObject = {
      payload: payload,
    };
    this.store.dispatch({ type: 'CREATE_CART', payload: cartObject });
  }

  public viewRccsDisclosure() {
    let request = {
        orderRefNumber: this.vacSusOrderRefNumber,
        rccGroupId: "SHOPPING",
        salesChannel: "ESHOP - Customer Care",
        versionNumber: "",
        cart: this.cartForVacOpt
    }
    this.loading = true;
    let errorResolved = false;
    this.logger.log("info", "vacation-option.component.ts", "viewRccDisclosuresRequest", JSON.stringify(request));
    this.logger.startTime();
    this.disclosuresService.viewRccsDisclosure(request)
        .catch((error: any) => {
            this.logger.endTime();
            this.logger.log("error", "vacation-option.component.ts", "viewRccDisclosuresResponse", error);
            this.logger.log("error", "vacation-option.component.ts", "viewRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;
            errorResolved = true;
            this.onContinueFromVacOptionPage();
            return Observable.throwError(null);
        })
        .subscribe(
            (data: DisclosuresRes) => {
                this.logger.endTime();
                this.logger.log("info", "vacation-option.component.ts", "viewRccDisclosuresResponse", JSON.stringify(data));
                this.logger.log("info", "vacation-option.component.ts", "viewRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                this.loading = false;
                if (data && data.rccGroup && data.rccGroup.length > 0) {
                  this.store.dispatch({ type: 'ORDER_DISCLOSERS', payload: data });
                  this.orderDisclosures.open();
              } else {
                  this.onContinueFromVacOptionPage();
              }
            },
            (error) => {
                this.logger.endTime();
                this.logger.log("error", "vacation-option.component.ts", "viewRccDisclosuresResponse", error);
                this.logger.log("error", "vacation-option.component.ts", "viewRccDisclosuresSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
                if(!errorResolved) {
                  this.onContinueFromVacOptionPage();
                  this.loading = false;
                }
            })
  }
  
  public isDisclosureAllowed: boolean = true;
  public toContinue() {
      if (this.isDisclosureAllowed) {
          this.viewRccsDisclosure();
      } else {
          this.onContinueFromVacOptionPage();
      }
  }

  public onContinueFromVacOptionPage() {  
    this.vacationreentrant = true; 
    this.store.dispatch({ type: 'REENTRANT_OPTION', payload: this.vacationreentrant });
    if(this.newNumber && this.newNumber !== undefined) {
    this.newNumber =  this.newNumber.replace(/-/g, '');
    }
    if(this.authorized){
    this.loading = true;
    this.changeActionForVacSusCart();
    this.store.dispatch({ type: 'FINAL_VAC_CART', payload: this.vacSuspendRequest.payload.cart });
    let req = {
      orderRefNumber: this.vacSusOrderRefNumber,
      taskId: this.vacSusTaskId,
      processInstanceId: this.vacSusProcessInstanceId,
      taskName: "Get Addon Offers",
      payload: {
        cart: {
          catalogSpecId: this.exeCatelogSpecId,
          customerOrderItems: []
        },
        productConfiguration: [],
        dhpAdditionalInfo: {}
      }
    }
    let customerOrderItems = map(this.vacSuspendRequest.payload.cart.customerOrderItems, (obj) => {
      return omit(obj, ['offerDisplayName']);
    });
    let custObj: any[] = [];
    if(customerOrderItems) {
      customerOrderItems.forEach(cust => {
          if(cust && cust.offerCategory === GenericValues.cHP && cust.action === 'VACSUS-REMOVE') {
            customerOrderItems.forEach(cust => {
              if(cust && cust.offerCategory === GenericValues.cHP && cust.offerType === 'SUBOFFER') {
                cust.customerOrderSubItems && cust.customerOrderSubItems.map(sub => {
                  if(sub.productName.indexOf('Directory List') === -1) {
                    cust.action = 'VACSUS-REMOVE';
                    sub.action = 'VACSUS-REMOVE';
                  }
                })
              }
            })
            custObj.push(cust);
          } else if (cust && cust.customerOrderSubItems && cust.customerOrderSubItems.length > 0 && cust.offerName) {
            custObj.push(cust);
          }
      })
  }
    req.payload.cart.customerOrderItems = custObj;
    this.logger.log("info", "vacation-option.component.ts", "scheduleVacationCallRequest", JSON.stringify(req));  
    this.logger.startTime();
    this.store.dispatch({ type: 'VACATION_CART', payload: req.payload.cart.customerOrderItems });
    this.bMService.scheduleVacationCall(req)
      .catch((error: any) => {
        this.logger.endTime();
        this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallResponse", error);
        this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
        this.loading = false;
        return Observable.throwError(error);
      })
      .subscribe(
        (data) => {
	      	this.logger.endTime();
          this.logger.log("info", "vacation-option.component.ts", "scheduleVacationCallResponse", JSON.stringify(data));
	      	this.logger.log("info", "vacation-option.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
          this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
          if(data) this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
          this.store.dispatch({ type: 'CREATE_CUSTOMIZE_ADDONS', payload: data });
         let hmpOffer = this.offerHelperService.staticPotsOffer();
         let subOrderItem: any;
         let subOrderItems: any[] = []; 
          hmpOffer.productOffer.productComponents.forEach(products => {
          if (products.componentType !== GenericValues.cPrimary) {             
                  subOrderItem = products;
                  subOrderItems.push(subOrderItem);                          
          }
        });
        let orderItem = {         
          productOfferingId: hmpOffer === undefined ? '' : hmpOffer.productOfferingId,
          offerType: hmpOffer === undefined ? '' : hmpOffer.productOffer.offerType,
          offerSubType: hmpOffer === undefined ? '' : hmpOffer.productOffer.offerSubType,
          offerCategory: hmpOffer === undefined ? '' : hmpOffer.productOffer.offerCategory,
          quantity: 1,
          rc: hmpOffer && hmpOffer.defaultOfferPrice !== null ? hmpOffer.defaultOfferPrice.rc : 0,
          discountedRc: hmpOffer && hmpOffer.defaultOfferPrice !== null ? hmpOffer.defaultOfferPrice.discountedRc : 0,
          otc: hmpOffer && hmpOffer.defaultOfferPrice !== null ? hmpOffer.defaultOfferPrice.otc : 0,
          discountedOtc: hmpOffer && hmpOffer.defaultOfferPrice !== null ? hmpOffer.defaultOfferPrice.discountedOtc : 0,
          customerOrderSubItems: subOrderItems
      };
      this.store.dispatch({ type: 'POTS_OFFER', payload: orderItem });
      this.ctlHelperService.storeRequestProcessData(data, 'customize-services', 'submit', 'vacation');
       this.router.navigate(['/customize-services']);          
        },
        (error) => {
          this.logger.endTime();
          this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallResponse", error);
          this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          this.loading = false;        
          this.systemErrorService.getAPIResponseError(error, 'INIT', 'vacation-option.component.ts', 'Existing Product Page');
        }
      )
    }
    else if(!this.authorized){
      this.loading = true;
      this.changeActionForVacSusCart();
      this.store.dispatch({ type: 'FINAL_VAC_CART', payload: this.vacSuspendRequest.payload.cart });
      let req = {
        orderRefNumber: this.vacSusOrderRefNumber,
        taskId: this.vacSusTaskId,
        processInstanceId: this.vacSusProcessInstanceId,
        taskName: "Checkout & Scheduling",
        payload: {
          cart: {
            customerOrderItems: []
          }
        }
      }
      let customerOrderItems = map(this.vacSuspendRequest.payload.cart.customerOrderItems, (obj) => {
        return omit(obj, ['offerDisplayName']);
      });
      let custObj: any[] = [];
      if(customerOrderItems) {
        customerOrderItems.forEach(cust => {
            if(cust && cust.offerCategory === GenericValues.cHP && cust.action === 'VACSUS-REMOVE') {
              customerOrderItems.forEach(cust => {
                if(cust && cust.offerCategory === GenericValues.cHP && cust.offerType === 'SUBOFFER') {
                  cust.customerOrderSubItems && cust.customerOrderSubItems.forEach(sub => {
                    if(sub.productName.indexOf('Directory List') === -1) {
                      cust.action = 'VACSUS-REMOVE';
                      sub.action = 'VACSUS-REMOVE';
                    }
                  });
                }
              });
              custObj.push(cust);
            } else if (cust && cust.customerOrderSubItems && (cust.customerOrderSubItems.length > 0)) {
              custObj.push(cust);
            }
        });
    }
      req.payload.cart.customerOrderItems = custObj;
      this.loading = true;
      this.logger.log("info", "vacation-option.component.ts", "scheduleVacationCallRequest", JSON.stringify(req));  
      this.logger.startTime();
      this.store.dispatch({ type: 'VACATION_CART', payload: req.payload.cart.customerOrderItems });
      this.bMService.scheduleVacationCall(req)
        .catch((error: any) => {
          this.logger.endTime();
          this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallResponse", error);
          this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
          this.loading = false;
          return Observable.throwError(error);
        })
        .subscribe(
          (data) => {
            this.logger.endTime();
            this.logger.log("info", "vacation-option.component.ts", "scheduleVacationCallResponse", JSON.stringify(data));
            this.logger.log("info", "vacation-option.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');      
            this.store.dispatch({ type: 'VACATION_SCHEDULE_RESPONSE', payload: data });
            this.store.dispatch({ type: 'SCHEDULE_SHIPPING', payload: data });
            if(data) this.store.dispatch({ type: 'TASK_ID', payload: data.taskId });
            this.ctlHelperService.storeRequestProcessData(data, 'vacation-schedule-appt-ship', 'submit', 'vacation');
            this.router.navigate(['/vacation-schedule-appt-ship']);
          },
          (error) => {
            this.logger.endTime();
            this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallResponse", error);
            this.logger.log("error", "vacation-option.component.ts", "scheduleVacationCallSrvc", '{"elapsedTime" : "' + this.logger.calculateDifference('Seconds') + '"}');
            this.loading = false;                              
            this.systemErrorService.getAPIResponseError(error, 'INIT', 'vacation-option.component.ts', 'Existing Product Page');
          }
        )
  
    }
  }

  public onReferralObjectChange(value) {
    if (value === 'Refer to new TN') {
      this.isInputFieldActive = true;
      this.isContinueBtnEnabled = false;
    } else {
      this.callersWillHere = 'Out of Service';
      this.newNumber = ""   ;
      this.isInputFieldActive = false;
      this.isContinueBtnEnabled = true;
      this.store.dispatch({ type: 'VACATION_REFERRAL_NUMBER', payload: this.newNumber });
    }
  }

  public onKeyUpReferralNum() {
    if (this.newNumber) {
      this.isContinueBtnEnabled = true;
    } else {
      this.isContinueBtnEnabled = false;
    }
  }

  public ngOnDestroy(): void {
    if (this.vacationSubscription !== undefined) {
      this.vacationSubscription.unsubscribe();
    }
    if (this.exisingProductsSubscribe !== undefined) {
      this.exisingProductsSubscribe.unsubscribe();
    }
  }

}