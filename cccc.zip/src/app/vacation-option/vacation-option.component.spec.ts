import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { VacationOptionComponent } from './vacation-option.component';
import { Logger } from 'app/common/logging/default-log.service';
import { MockLogger, MockRouter, MockHelperService, MockDisclosuresService, MockTextMaskService, MockAppStateService, MockSystemErrorService, MockOfferHelperService, MockBlueMarbleService } from 'app/common/service/mockServices.test';
import { Router, RouterModule, Routes } from '@angular/router';
import { Store } from '@ngrx/store';
import { HelperService } from 'app/common/service/helper.service';
import { TextMaskService } from 'app/common/service/text-mask.service';
import { AppStateService } from 'app/common/service/app-state.service';
import { SystemErrorService } from 'app/common/service/system-error.service';
import { OfferHelperService } from 'app/common/service/offerHelper.service';
import { CTLHelperService } from 'app/common/service/ctlHelperService';
import { BlueMarbleService } from 'app/common/service/bm.service';
import { TabsModule, AccordionModule } from 'ngx-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedCommonModule } from 'app/shared/shared-common.module';
import { Observable } from 'rxjs/Observable';
import { MockServer } from 'app/MockServer.test';
import { SharedModule } from 'app/shared/shared.module';
import { DisclosuresService } from 'app/common/service/disclosures.service';
import 'rxjs/add/observable/of';

describe('VacationOptionComponent', () => {
  let component: VacationOptionComponent;
  let fixture: ComponentFixture<VacationOptionComponent>;

  let mockServer = new MockServer();

   const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: VacationOptionComponent
    }
  ];

  const mockRedux: any = {
    dispatch(action) {},
    configureStore() {},
    select(reducer) {
      if (reducer === "user")
        return Observable.of(
          mockServer.getMockStore("onload-vacationOption").user
        );
      else if (reducer === "vacation")
        return Observable.of(
          mockServer.getMockStore("onload-vacationOption").vacation
        );
      else if (reducer === "existingProducts")
        return Observable.of(
          mockServer.getMockStore("onload-vacationOption").existingProducts
        );
    },
    take<T>(this: Observable<T>, count: number) {
      return Observable.of(null);
    }
  };

  let p1 = { provide: Logger, useClass: MockLogger };
  let p2 = { provide: Store, useValue: mockRedux };
  let p3 = CTLHelperService;
  let p4 = { provide: OfferHelperService, useClass: MockOfferHelperService };
  let p5 = { provide: BlueMarbleService, useClass: MockBlueMarbleService };
  let p6 = { provide: Router, useClass: MockRouter };
  let p7 = { provide: SystemErrorService, useClass: MockSystemErrorService };
  let p8 = { provide: AppStateService, useClass: MockAppStateService };
  let p9 = { provide: TextMaskService, useClass: MockTextMaskService };
  let p10 = { provide: DisclosuresService, useClass: MockDisclosuresService };
  let p11 = { provide: HelperService, useClass: MockHelperService };
  
  let baseConfig = {
    imports: [
      SharedCommonModule,
      TextMaskModule,
      RouterModule.forChild(COMPONENT_ROUTER),
      TabsModule.forRoot(),
      AccordionModule.forRoot(),
      TextMaskModule,
      SharedModule
    ],
    declarations: [VacationOptionComponent],
    providers: [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11]
  };

  beforeEach(async(() => {
    TestBed.resetTestingModule()
    TestBed.configureTestingModule(baseConfig)
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VacationOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not show the vacation-option page for LC flow', () => {
    expect((component as any).isLCAddress).toBeTruthy();
    expect(component.loading).toBe(true);
  });
});
