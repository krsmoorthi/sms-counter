import { NgModule } from '@angular/core';
// tslint:disable-next-line:no-unused-variable
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TextMaskService } from '../common/service/text-mask.service';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { FirstCustomizePipe } from '../common/pipes/firstcapcustom.pipe';
import { VacationOptionComponent } from './vacation-option.component';
import { SharedCommonModule } from 'app/shared/shared-common.module';

export const COMPONENT_ROUTER: Routes = [
    {
        path: '',
        component: VacationOptionComponent
    }
];

@NgModule({
    imports: [
        // CommonModule,
        RouterModule.forChild(COMPONENT_ROUTER),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        TextMaskModule,
        // CustomDatepickerModule,
        SharedCommonModule,
        SharedModule
    ],
    exports: [VacationOptionComponent],
    declarations: [VacationOptionComponent],
    providers: [
        TextMaskService,
        FirstCustomizePipe
    ]
})
export class VacationOptionModule { }
