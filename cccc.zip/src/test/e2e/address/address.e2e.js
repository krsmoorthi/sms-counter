var HomePage = require('./address.po.js');
	

describe(' CTL EShop E2E validation: ', function() {

	var homePage = new HomePage();
	
	
	beforeEach(function() {
        browser.get ("/#/");
        browser.manage().window().maximize();
    });

    afterEach(function() {
        browser.manage().deleteAllCookies();
    });
   
  
	it("No Match address validation", function(){

	homePage.nomatchAddress();
	});
	
	it ("Partial Match address validation", function(){

	homePage.partialAddress();
	
	}); 
	
	it ("Exact Match address validation", function(){

	homePage.fillingAddress();
	
	browser.getCurrentUrl().then(function(newURL) {
				expect(newURL).toContain('#/product-offer');
	});
	});
	
	it("Build your offer page - HSI offers validation", function(){
	
	homePage.hsioffers();
	
	browser.getCurrentUrl().then(function(newURL) {
				expect(newURL).toContain('#/product-offer');
	
	
	});
	});
	
	it("Build your offer page - HSI options validation", function(){
	
	homePage.hsioptions(); 
	
	browser.getCurrentUrl().then(function(newURL) {
				expect(newURL).toContain('#/product-offer');
	
	});
	});
	
	it ("E2E HSI Order Submit validation",function(){
	
	homePage.submitorder();
	
		
	browser.getCurrentUrl().then(function(newURL) {
				expect(newURL).toContain('#/order-confirmation');
	
	
  });
  });
  });