var faker = require('faker');
var HomePage = function () {

	this.fillingAddress = function () {
		var randomFirstName = faker.name.firstName();
		var randomLastName = faker.name.lastName();
		var randomPhoneNumber = faker.phone.phoneNumberFormat(10);
		var randomCity = faker.address.city();
		var randomLocationName = faker.address.streetName();
		var randomAddressLine1 = faker.address.streetAddress();
		var randomAddressLine2 = faker.address.secondaryAddress();
		var randomZipCode = faker.address.zipCode();
		var randomState = faker.address.stateAbbr();
		element(by.id("firstName")).clear();
		element(by.id("firstName")).sendKeys(randomFirstName);
		element(by.id("lastName")).clear();
		element(by.id("lastName")).sendKeys(randomLastName);
		element(by.id("phoneNumber")).clear();
		element(by.id("phoneNumber")).sendKeys(randomPhoneNumber);
		element(by.linkText("Show single line address fields")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="address"]')).clear();
		var elm = element(by.xpath('//*[@id="address"]'));
		elm.sendKeys("1176 9TH ST,DES MOINES,IA 50314,USA");
		element(by.buttonText("Let's Go")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		expect(browser.getCurrentUrl()).toContain('#/product-offer');
	}

	this.partialAddress = function () {
		var randomFirstName = faker.name.firstName();
		var randomLastName = faker.name.lastName();
		var randomPhoneNumber = faker.phone.phoneNumberFormat(10);
		var randomCity = faker.address.city();
		var randomLocationName = faker.address.streetName();
		var randomAddressLine1 = faker.address.streetAddress();
		var randomAddressLine2 = faker.address.secondaryAddress();
		var randomZipCode = faker.address.zipCode();
		var randomState = faker.address.stateAbbr();
		element(by.id("firstName")).clear();
		element(by.id("firstName")).sendKeys(randomFirstName);
		element(by.id("lastName")).clear();
		element(by.id("lastName")).sendKeys(randomLastName);
		element(by.id("phoneNumber")).clear();
		element(by.id("phoneNumber")).sendKeys(randomPhoneNumber)
		element(by.linkText("Show all address fields")).click();
		element(by.id("addressLine")).sendKeys("8976");
		element(by.id("floor")).sendKeys(randomAddressLine1);
		element(by.id("floor")).sendKeys(randomAddressLine2);
		element(by.id("state")).$('[value="' + randomState + '"]').click();
		element(by.id("city")).sendKeys(randomCity);
		element(by.id("zipCode")).sendKeys(randomZipCode);
		element(by.buttonText("Let's Go")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.id("search")).sendKeys("1172");
		browser.driver.sleep(1000);
		browser.waitForAngular();
		var elm = element.all(by.xpath('//li[@class="radio"]/label/div[1]')).last();
		elm.click();
		element(by.buttonText("Continue")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		expect(browser.getCurrentUrl()).toContain('product-offer');
	}
	this.nomatchAddress = function () {
		var randomFirstName = faker.name.firstName();
		var randomLastName = faker.name.lastName();
		var randomPhoneNumber = faker.phone.phoneNumberFormat(10);
		var randomCity = faker.address.city();
		var randomLocationName = faker.address.streetName();
		var randomAddressLine1 = faker.address.streetAddress();
		var randomAddressLine2 = faker.address.secondaryAddress();
		var randomZipCode = faker.address.zipCode();
		var randomState = faker.address.stateAbbr();
		element(by.id("firstName")).sendKeys(randomFirstName);
		element(by.id("lastName")).sendKeys(randomLastName);
		element(by.id("phoneNumber")).sendKeys(randomPhoneNumber)
		element(by.linkText("Show all address fields")).click();
		element(by.id("addressLine")).sendKeys("7845");
		element(by.id("floor")).sendKeys(randomAddressLine1);
		element(by.id("floor")).sendKeys(randomAddressLine2);
		element(by.id("state")).$('[value="' + randomState + '"]').click();
		element(by.id("city")).sendKeys(randomCity);
		element(by.id("zipCode")).sendKeys(randomZipCode);
		element(by.buttonText("Let's Go")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.buttonText("Try Again")).click()
		expect(browser.getCurrentUrl()).toContain('#/');
	}
	this.hsioffers = function () {
		var randomFirstName = faker.name.firstName();
		var randomLastName = faker.name.lastName();
		var randomPhoneNumber = faker.phone.phoneNumberFormat(10);
		var randomCity = faker.address.city();
		var randomLocationName = faker.address.streetName();
		var randomAddressLine1 = faker.address.streetAddress();
		var randomAddressLine2 = faker.address.secondaryAddress();
		var randomZipCode = faker.address.zipCode();
		var randomState = faker.address.stateAbbr();
		element(by.id("firstName")).clear();
		element(by.id("firstName")).sendKeys(randomFirstName);
		element(by.id("lastName")).clear();
		element(by.id("lastName")).sendKeys(randomLastName);
		element(by.id("phoneNumber")).clear();
		element(by.id("phoneNumber")).sendKeys(randomPhoneNumber);
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="address"]')).clear();
		var elm = element(by.xpath('//*[@id="address"]'));
		elm.sendKeys("1176 9TH ST,DES MOINES,IA 50314,USA");
		element(by.buttonText("Let's Go")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		var matchoffers = element(by.xpath('//*[@id="matching-offers-block"]/div[1]/h3'));
		matchoffers.getText().then(function (text) {
			var hsi = element(by.xpath('//*[@id="matching-offers-block"]/div[1]/div/div/div[1]'));
			hsi.getText().then(function (text) {
			});
			var offerdetails = element(by.xpath('//*[@id="matching-offers-block"]/div[2]/h3'));
			offerdetails.getText().then(function (text) {
				var listprice = element(by.xpath('//*[@id="matching-offers-block"]/div[2]/div[2]/div[1]/strong'));
				listprice.getText().then(function (text) {
					var discount = element(by.xpath('//*[@id="matching-offers-block"]/div[2]/div[1]/div[1]'));
					discount.getText().then(function (text) {
					});
				});
			});
		});
	}
	this.hsioptions = function () {
		var randomFirstName = faker.name.firstName();
		var randomLastName = faker.name.lastName();
		var randomPhoneNumber = faker.phone.phoneNumberFormat(10);
		var randomCity = faker.address.city();
		var randomLocationName = faker.address.streetName();
		var randomAddressLine1 = faker.address.streetAddress();
		var randomAddressLine2 = faker.address.secondaryAddress();
		var randomZipCode = faker.address.zipCode();
		var randomState = faker.address.stateAbbr();
		element(by.id("firstName")).clear();
		element(by.id("firstName")).sendKeys(randomFirstName);
		element(by.id("lastName")).clear();
		element(by.id("lastName")).sendKeys(randomLastName);
		element(by.id("phoneNumber")).clear();
		element(by.id("phoneNumber")).sendKeys(randomPhoneNumber);
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="address"]')).clear();
		var elm = element(by.xpath('//*[@id="address"]'));
		elm.sendKeys("1176 9TH ST,DES MOINES,IA 50314,USA");
		element(by.buttonText("Let's Go")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		var internetoptions = element(by.xpath('//*[@id="internet-options-block"]/div/h2'));
		internetoptions.getText().then(function (text) {
		});
	}

	this.submitorder = function () {
		var randomFirstName = faker.name.firstName();
		var randomLastName = faker.name.lastName();
		var randomPhoneNumber = faker.phone.phoneNumberFormat(10);
		var randomCity = faker.address.city();
		var randomLocationName = faker.address.streetName();
		var randomAddressLine1 = faker.address.streetAddress();
		var randomAddressLine2 = faker.address.secondaryAddress();
		var randomZipCode = faker.address.zipCode();
		var randomState = faker.address.stateAbbr();
		element(by.id("firstName")).clear();
		element(by.id("firstName")).sendKeys(randomFirstName);
		element(by.id("lastName")).clear();
		element(by.id("lastName")).sendKeys(randomLastName);
		element(by.id("phoneNumber")).clear();
		element(by.id("phoneNumber")).sendKeys(randomPhoneNumber);
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="address"]')).clear();
		var elm = element(by.xpath('//*[@id="address"]'));
		elm.sendKeys("1176 9TH ST,DES MOINES,IA 50314,USA");
		element(by.buttonText("Let's Go")).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		browser.getCurrentUrl().then(function (newURL) {
			expect(newURL).toContain('#/product-offer');
		});
		element(by.xpath('//*[@id="btn-pricing-summary"]/span[2]/span[2]')).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="btn-pricing-summary"]/span[2]/span[2]')).click();
		element(by.buttonText('Continue')).click();
		browser.getCurrentUrl().then(function (newURL) {
			expect(newURL).toContain('#/customize-services');
		});
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('/html/body/app/main/product-customize-services/div/div/div/div/div/span/button[1]')).click();
		browser.getCurrentUrl().then(function (newURL) {
			expect(newURL).toContain('#/schedule-appt');
		});
		browser.driver.sleep(5000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="contBtnDiv"]')).click();
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('//*[@id="contBtnDiv"]')).click();
		browser.getCurrentUrl().then(function (newURL) {
			expect(newURL).toContain('#/account');
		});
		browser.driver.sleep(1000);
		browser.waitForAngular();
		var ssn = element(by.xpath('/html/body/app/main/account/section/div/div[1]/section[2]/div[2]/input'));
		ssn.sendKeys('12345678987');
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('/html/body/app/main/account/section/div/div[2]/button[1]')).click();
		browser.getCurrentUrl().then(function (newURL) {
			expect(newURL).toContain('#/account');
		});
		browser.driver.sleep(1000);
		browser.waitForAngular();
		element(by.xpath('/html/body/app/main/account/section/div/div[2]/button[1]')).click();
		browser.getCurrentUrl().then(function (newURL) {
			expect(newURL).toContain('#/review-order');
		});
		var elm = element(by.xpath('//*[@id="review-pricing"]/div[2]/label[1]/input'));
		elm.click();
		element(by.buttonText('Submit Order')).click();
		var Submitorder = element(by.xpath('/html/body/app/main/review-order/section/div[1]/div[1]/div[1]/p'));
		Submitorder.getText().then(function (text) {
		});
	}
}

module.exports = HomePage;